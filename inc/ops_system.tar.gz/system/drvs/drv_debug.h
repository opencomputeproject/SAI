#ifndef __DRV_DEBUG__
#define __DRV_DEBUG__

#include "genlog.h"
#include "ctclib_debug.h"
#include "sal_common.h"
#include "drv_specific.h"

#define DRV_MALLOC(type,size) XMALLOC(type,size)
#define DRV_CALLOC(type,size) XCALLOC(type, size)
#define DRV_FREE(type,ptr)    XFREE(type,ptr)

#define DRV_CTC_CHK_PTR(_PTR)                                                   \
do {                                                                        \
    if ((_PTR) == NULL)                                                     \
    {                                                                       \
        DRV_LOG_ERR("%s NULL pointer", __FUNCTION__);                       \
        return -1;                                                          \
    }                                                                       \
}while(0)

#define DRV_CTC_CHK_PTR_NULL(_PTR)                                                   \
    do {                                                                        \
        if ((_PTR) == NULL)                                                     \
        {                                                                       \
            DRV_LOG_ERR("%s NULL pointer", __FUNCTION__);                       \
            return NULL;                                                          \
        }                                                                       \
    }while(0)



#define DRV_LOG_EMERG(fmt, args...)   log_diag(M_MOD_DRV, E_EMERGENCY, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_ALERT(fmt, args...)   log_diag(M_MOD_DRV, E_ALERT, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_CRIT(fmt, args...)   log_diag(M_MOD_DRV, E_CRITICAL, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_ERR(fmt, args...)   log_diag(M_MOD_DRV, E_ERROR, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_WARN(fmt, args...)   log_diag(M_MOD_DRV, E_WARNING, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_NOTICE(fmt, args...)  log_diag(M_MOD_DRV, E_NOTICE, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_INFO(fmt, args...)   log_diag(M_MOD_DRV, E_INFORMATIONAL, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)

#define DRV_LOG_DEBUG(sub, typeenum, fmt, args...)\
    CTCLIB_DEBUG_OUT_INFO(DRV, drv, sub, typeenum, fmt, ##args); 


CTCLIB_DEBUG_ENUM(DRV, drv, bus, DRV_BUS_SPI, DRV_BUS_I2C, DRV_BUS_MDIO);
CTCLIB_DEBUG_ENUM(DRV, drv, clkgen, DRV_CLK_GEN_READ, DRV_CLK_GEN_WRITE, DRV_CLK_GEN_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, ds3104, DRV_DS3104_READ, DRV_DS3104_WRITE, DRV_DS3104_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, phy, DRV_PHY_READ, DRV_PHY_WRITE, DRV_PHY_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, poe, DRV_POE_READ, DRV_POE_WRITE, DRV_POE_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, l2switch, DRV_L2SWITCH_READ, DRV_L2SWITCH_WRITE, DRV_L2SWITCH_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, epld, DRV_EPLD_READ, DRV_EPLD_WRITE, DRV_EPLD_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, fiber, DRV_FIBER_READ, DRV_FIBER_WRITE, DRV_FIBER_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, sensor, DRV_SENSOR_READ, DRV_SENSOR_WRITE, DRV_SENSOR_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, gpio, DRV_GPIO_READ, DRV_GPIO_WRITE, DRV_GPIO_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, mux, DRV_MUX_READ, DRV_MUX_WRITE, DRV_MUX_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, fan, DRV_FAN_READ, DRV_FAN_WRITE, DRV_FAN_NORMAL);
/* added by liuht for bug 24525,2013-10-24 */
CTCLIB_DEBUG_ENUM(DRV, drv, power, DRV_POWER_READ, DRV_POWER_WRITE, DRV_POWER_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, vsc3308, DRV_VSC3308_READ, DRV_VSC3308_WRITE, DRV_VSC3308_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, eeprom, DRV_EEPROM_READ, DRV_EEPROM_WRITE, DRV_EEPROM_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, ds21348, DRV_DS21348_READ, DRV_DS21348_WRITE, DRV_DS21348_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, ds26503, DRV_DS26503_READ, DRV_DS26503_WRITE, DRV_DS26503_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, ad9559, DRV_AD9559_READ, DRV_AD9559_WRITE, DRV_AD9559_NORMAL);  /* chani 20130930 */


#endif /*__DRV_DEBUG__*/
