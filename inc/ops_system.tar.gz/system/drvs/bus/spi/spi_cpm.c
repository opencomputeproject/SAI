/****************************************************************************
* $Id$
*  SPI driver implemented by SPI controller in CPM
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2010-08-04
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
* 
****************************************************************************/
#include "sal_common.h"
#include "ctc_spi.h"
#include "spi_cpm.h"
#include "drv_debug.h"
#include "spi_err.h"

/*--------------------------------------------------------------------------------------------
caution:
For now we don't use ppc8247 spi controller, so spi_cpm.c codes don't verify. Those codes are just for you 
information , maybe later we would use ppc8247 spi controller..
---------------------------------------------------------------------------------------------*/


/****************************************************************************
 *
* Defines and Macros
* 
****************************************************************************/
static volatile immap_t *g_spi_cpm2_immr ;

/* ---------------------------------------------------------------
 * Offset for initial SPI buffers in DPRAM:
 * We need a 520 byte scratch DPRAM area to use at an early stage.
 * It is used between the two initialization calls (spi_init_f()
 * and spi_init_r()).
 * The value 0x2000 makes it far enough from the start of the data
 * area (as well as from the stack pointer).
 * --------------------------------------------------------------- */

#define	CONFIG_SYS_SPI_INIT_OFFSET	0x2000


#define CPM_SPI_BASE 0x100
#define MAX_BUFFER	0x104

#define SPI_EEPROM_WREN     0x06
#define SPI_EEPROM_RDSR     0x05
#define SPI_EEPROM_READ     0x03
#define SPI_EEPROM_WRITE    0x02

/* ----------------------------------------------------------------------
 * Initially we place the RX and TX buffers at a fixed location in DPRAM!
 * ---------------------------------------------------------------------- */
static uint8 *rxbuf ;
static uint8 *txbuf ;


#ifdef	DEBUG

#define	DPRINT(a)	printf a;
/* -----------------------------------------------
 * Helper functions to peek into tx and rx buffers
 * ----------------------------------------------- */
static const char * const hex_digit = "0123456789ABCDEF";

static char quickhex (int32 i)
{
    return hex_digit[i];
}

static void memdump (void *pv, int32 num)
{
    int32 i;
    uint8 *pc = (uint8 *) pv;

    for (i = 0; i < num; i++)
    printf ("%c%c ", quickhex (pc[i] >> 4), quickhex (pc[i] & 0x0f));
    printf ("\t");
    for (i = 0; i < num; i++)
    printf ("%c", isprint (pc[i]) ? pc[i] : '.');
    printf ("\n");
}
#else   /* !DEBUG */

#define DPRINT(a)

#endif  /* DEBUG */


/****************************************************************************
 *
* Global and Declaration
* 
****************************************************************************/

sal_mutex_t * g_spi_cpm_mutex;


/****************************************************************************
 *
* Function
* 
****************************************************************************/

static void SIDELAY()
{ 
#if 1
    struct timespec delay_time;
    delay_time.tv_sec = 0;
    delay_time.tv_nsec = 1;
    nanosleep(&delay_time,NULL);
#endif
}


static int32 gpio_init(spi_gen_t  *spi_pgen)
{ 

    DRV_CTC_CHK_PTR(spi_pgen);
    
    volatile ioport_t *iop = ioport_addr(g_spi_cpm2_immr, spi_pgen->spi_info.spi_cpm_info.cs.prot_index);

    iop->pdat |= spi_pgen->spi_info.spi_cpm_info.cs.bit;
    iop->pdir |= spi_pgen->spi_info.spi_cpm_info.cs.bit;
    
    return 0;
}


/* **************************************************************************
 *
 *  Function:    spi_init_f
 *
 *  Description: Init SPI-Controller (ROM part)
 *
 *  return:      ---
 *
 * *********************************************************************** */
void spi_init_f (spi_gen_t *spi_pgen)
{
    uint32 dpaddr;

    volatile spi_t *spi;
    volatile immap_t *immr;
    volatile cpm8260_t *cp;
    volatile cbd_t *tbdf, *rbdf;

    immr = g_spi_cpm2_immr;
    cp   = (cpm8260_t *) &immr->im_cpm;

    *(uint16 *)(&immr->im_dprambase[PROFF_SPI_BASE]) = PROFF_SPI;
    spi  = (spi_t *)&immr->im_dprambase[PROFF_SPI];

/* 1 */
    /* ------------------------------------------------
     * Initialize Port D SPI pins
     * (we are only in Master Mode !)
     * ------------------------------------------------ */

    /* --------------------------------------------
     * GPIO or per. Function
     * PPARD[16] = 1 [0x00008000] (SPIMISO)
     * PPARD[17] = 1 [0x00004000] (SPIMOSI)
     * PPARD[18] = 1 [0x00002000] (SPICLK)
     * PPARD[12] = 0 [0x00080000] -> GPIO: (CS for ATC EEPROM)
     * -------------------------------------------- */
    immr->im_ioport.iop_ppard |=  0x0000E000;   /* set  bits	*/
    immr->im_ioport.iop_ppard &= ~0x00080000;   /* reset bit	*/

    /* ----------------------------------------------
     * In/Out or per. Function 0/1
     * PDIRD[16] = 0 [0x00008000] -> PERI1: SPIMISO
     * PDIRD[17] = 0 [0x00004000] -> PERI1: SPIMOSI
     * PDIRD[18] = 0 [0x00002000] -> PERI1: SPICLK
     * PDIRD[12] = 1 [0x00080000] -> GPIO OUT: CS for ATC EEPROM
     * ---------------------------------------------- */
    immr->im_ioport.iop_pdird &= ~0x0000E000;
    immr->im_ioport.iop_pdird |= 0x00080000;

    /* ----------------------------------------------
     * special option reg.
     * PSORD[16] = 1 [0x00008000] -> SPIMISO
     * PSORD[17] = 1 [0x00004000] -> SPIMOSI
     * PSORD[18] = 1 [0x00002000] -> SPICLK
     * ---------------------------------------------- */
    immr->im_ioport.iop_psord |= 0x0000E000;

    /* Initialize the parameter ram.
     * We need to make sure many things are initialized to zero
     */
    spi->spi_rstate	= 0;
    spi->spi_rdp	= 0;
    spi->spi_rbptr	= 0;
    spi->spi_rbc	= 0;
    spi->spi_rxtmp	= 0;
    spi->spi_tstate	= 0;
    spi->spi_tdp	= 0;
    spi->spi_tbptr	= 0;
    spi->spi_tbc	= 0;
    spi->spi_txtmp	= 0;

    /* Allocate space for one transmit and one receive buffer
     * descriptor in the DP ram
     */
#ifdef CONFIG_SYS_ALLOC_DPRAM
    dpaddr = m8260_cpm_dpalloc (sizeof(cbd_t)*2, 8);
#else
    dpaddr = CPM_SPI_BASE;
#endif

/* 3 */
    /* Set up the SPI parameters in the parameter ram */
    spi->spi_rbase = dpaddr;
    spi->spi_tbase = dpaddr + sizeof (cbd_t);

    /***********IMPORTANT******************/

    /*
     * Setting transmit and receive buffer descriptor pointers
     * initially to rbase and tbase. Only the microcode patches
     * documentation talks about initializing this pointer. This
     * is missing from the sample I2C driver. If you dont
     * initialize these pointers, the kernel hangs.
     */
    spi->spi_rbptr = spi->spi_rbase;
    spi->spi_tbptr = spi->spi_tbase;

/* 4 */
    /* Init SPI Tx + Rx Parameters */
    while (cp->cp_cpcr & CPM_CR_FLG);
    cp->cp_cpcr = mk_cr_cmd(CPM_CR_SPI_PAGE, CPM_CR_SPI_SBLOCK,
                            0, CPM_CR_INIT_TRX) | CPM_CR_FLG;
    while (cp->cp_cpcr & CPM_CR_FLG);

/* 6 */
    /* Set to big endian. */
    spi->spi_tfcr = CPMFCR_EB;
    spi->spi_rfcr = CPMFCR_EB;

/* 7 */
    /* Set maximum receive size. */
    spi->spi_mrblr = MAX_BUFFER;

/* 8 + 9 */
    /* tx and rx buffer descriptors */
    tbdf = (cbd_t *) & immr->im_dprambase[spi->spi_tbase];
    rbdf = (cbd_t *) & immr->im_dprambase[spi->spi_rbase];

    tbdf->cbd_sc &= ~BD_SC_READY;
    rbdf->cbd_sc &= ~BD_SC_EMPTY;

    /* Set the bd's rx and tx buffer address pointers */
    rbdf->cbd_bufaddr = (ulong) rxbuf;
    tbdf->cbd_bufaddr = (ulong) txbuf;

/* 10 + 11 */
    immr->im_spi.spi_spie = SPI_EMASK;  /* Clear all SPI events	*/
    immr->im_spi.spi_spim = 0x00;   /* Mask  all SPI events */


    return;
}

/* **************************************************************************
 *
 *  Function:    spi_init_r
 *
 *  Description: Init SPI-Controller (RAM part) -
 *  The malloc engine is ready and we can move our buffers to
 *  normal RAM
 *
 *  return:      ---
 *
 * *********************************************************************** */
void spi_init_r (void)
{
    volatile spi_t *spi;
    volatile immap_t *immr;
    volatile cpm8260_t *cp;
    volatile cbd_t *tbdf, *rbdf;

    immr = g_spi_cpm2_immr;
    cp   = (cpm8260_t *) &immr->im_cpm;

    spi  = (spi_t *)&immr->im_dprambase[PROFF_SPI];

    /* tx and rx buffer descriptors */
    tbdf = (cbd_t *) & immr->im_dprambase[spi->spi_tbase];
    rbdf = (cbd_t *) & immr->im_dprambase[spi->spi_rbase];

    /* Allocate memory for RX and TX buffers */
    rxbuf = (unsigned char *) malloc (MAX_BUFFER);
    txbuf = (unsigned char *) malloc (MAX_BUFFER);

    rbdf->cbd_bufaddr = (ulong) rxbuf;
    tbdf->cbd_bufaddr = (ulong) txbuf;

    return;
}



/*********************************************************************
 * Name    : spi_cpm_close
 * Purpose :  free memory and pointer
 * Input   : spi_handle_t *phdl       - the handler of the spi bus
          
 * Output  : N/A
 * Return  : SPI_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/


int32 
spi_cpm_close(spi_handle_t *phdl)
{    
    DRV_CTC_CHK_PTR(phdl);
    
    sal_mutex_destroy(g_spi_cpm_mutex);
    
    if (NULL != phdl->data)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO,phdl->data);
        phdl->data = NULL;
    }
    DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO, phdl);
    phdl = NULL;
    
    return SPI_SUCCESS;
}

/****************************************************************************
 *  Function:    spi_xfer
 **************************************************************************** */
ssize_t spi_xfer (spi_gen_t *spi_pgen, size_t count)
{
    volatile immap_t *immr;
    volatile cpm8260_t *cp;
    volatile spi_t *spi;
    cbd_t *tbdf, *rbdf;
    int32 tm;

    DRV_CTC_CHK_PTR(spi_pgen);
    
    DPRINT (("*** spi_xfer entered ***\n"));

    immr = g_spi_cpm2_immr;
    cp   = (cpm8260_t *) &immr->im_cpm;

    spi  = (spi_t *)&immr->im_dprambase[PROFF_SPI];

    tbdf = (cbd_t *) & immr->im_dprambase[spi->spi_tbase];
    rbdf = (cbd_t *) & immr->im_dprambase[spi->spi_rbase];

    /* Board-specific: Set CS for device (ATC EEPROM) */
    immr->im_ioport.iop_pdatd &= ~0x00080000;

    /* Setting tx bd status and data length */
    tbdf->cbd_sc  = BD_SC_READY | BD_SC_LAST | BD_SC_WRAP;
    tbdf->cbd_datlen = count;

    DPRINT (("*** spi_xfer: Bytes to be xferred: %d ***\n",tbdf->cbd_datlen));

    /* Setting rx bd status and data length */
    rbdf->cbd_sc = BD_SC_EMPTY | BD_SC_WRAP;
    rbdf->cbd_datlen = 0;	 /* rx length has no significance */

    immr->im_spi.spi_spmode = SPMODE_REV    |
                              SPMODE_MSTR   |
                              SPMODE_EN     |
                              SPMODE_LEN(8) |   /* 8 Bits per char */
                               SPMODE_PM(0x8) ; /* medium speed */
    immr->im_spi.spi_spie = SPI_EMASK;      /* Clear all SPI events	*/
    immr->im_spi.spi_spim = 0x00;           /* Mask  all SPI events */

    /* start spi transfer */
    DPRINT (("*** spi_xfer: Performing transfer ...\n"));
    immr->im_spi.spi_spcom |= SPI_STR;  /* Start transmit */

    /* --------------------------------
     * Wait for SPI transmit to get out
     * or time out (1 second = 1000 ms)
     * -------------------------------- */
    for (tm=0; tm<1000; ++tm) 
    {
        if (immr->im_spi.spi_spie & SPI_TXB) 
        {  /* Tx Buffer Empty */
            DPRINT (("*** spi_xfer: Tx buffer empty\n"));
            break;
        }
        if ((tbdf->cbd_sc & BD_SC_READY) == 0) 
        {
            DPRINT (("*** spi_xfer: Tx BD done\n"));
            break;
        }
        //usleep (1000);
        SIDELAY();
    }
    if (tm >= 1000) 
    {
        DPRINT ("*** spi_xfer: Time out while xferring to/from SPI!\n");
    }
    DPRINT (("*** spi_xfer: ... transfer ended\n"));

#ifdef  DEBUG
    printf ("\nspi_xfer: txbuf after xfer\n");
    memdump ((void *) txbuf, 16);   /* dump of txbuf before transmit */
    printf ("spi_xfer: rxbuf after xfer\n");
    memdump ((void *) rxbuf, 16);   /* dump of rxbuf after transmit */
    printf ("\n");
#endif

    /* Clear CS for device */
    immr->im_ioport.iop_pdatd |= 0x00080000;

    return count;
}


/****************************************************************************
 *  Function:    spi_write
 **************************************************************************** */
static int32 spi_write (spi_gen_t *spi_pgen, uint8 *addr,uint8 *buffer)
{
    int32 i;
    uint32 alen ,len;

    DRV_CTC_CHK_PTR(spi_pgen);
    DRV_CTC_CHK_PTR(addr);
    DRV_CTC_CHK_PTR(buffer);
    
    alen = spi_pgen->alen;
    len = spi_pgen->len;
    
    memset(rxbuf, 0, MAX_BUFFER);
    memset(txbuf, 0, MAX_BUFFER);
    
    *txbuf = SPI_EEPROM_WREN;   /* write enable */
    
    spi_xfer(spi_pgen, 1);
    
    memcpy(txbuf, addr, alen);
    
    *txbuf = SPI_EEPROM_WRITE;  /* WRITE memory array	*/
    
    memcpy(alen + txbuf, buffer, len);
    
    spi_xfer(spi_pgen, alen + len);
    
    /* ignore received data	*/
    for (i = 0; i < 1000; i++) 
    {
        *txbuf = SPI_EEPROM_RDSR;   /* read status  */
        txbuf[1] = 0;
        spi_xfer(spi_pgen, 2);
        if (!(rxbuf[1] & 1)) 
        {
            break;
        }
        //usleep (1000);
        SIDELAY();
    }
    if (i >= 1000) 
    {
        DPRINT ("*** spi_write: Time out while writing!\n");
    }

    return len;
}

/****************************************************************************
 *  Function:    spi_read
 **************************************************************************** */
static int32 spi_read (spi_gen_t *spi_pgen, uint8 *addr,uint8 *buffer)
{
    uint32 alen ,len;

    DRV_CTC_CHK_PTR(spi_pgen);
    DRV_CTC_CHK_PTR(addr);
    DRV_CTC_CHK_PTR(buffer);
        
    alen = spi_pgen->alen;
    len = spi_pgen->len;
    
    memset(rxbuf, 0, MAX_BUFFER);
    memset(txbuf, 0, MAX_BUFFER);
    memcpy(txbuf, addr, alen);
    *txbuf = SPI_EEPROM_READ;   /* READ memory array	*/

    /*
     * There is a bug in 860T (?) that cuts the last byte of input
     * if we're reading into DPRAM. The solution we choose here is
     * to always read len+1 bytes (we have one extra byte at the
     * end of the buffer).
     */
    spi_xfer(spi_pgen, alen + len + 1);
    memcpy(buffer, alen + rxbuf, len);

	return len;
}


/*********************************************************************
 * Name    : spi_cpm_read
 * Purpose :  read spi bus
 * Input   : const spi_handle_t *phdl       - the handler of the spi bus
          spi_op_para_t *ppara     - some info about spi bus layer operation
                                       
 * Output  : N/A
 * Return  : SPI_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
spi_cpm_read(const spi_handle_t *phdl, spi_op_para_t *ppara)
{
    spi_gen_t *spi_pgen = NULL;
    spi_op_para_t *spi_ppara = NULL;        
    int32 ret;
        
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(ppara);
    
    spi_pgen = (spi_gen_t *)phdl->data;
    spi_ppara = ppara;
   
     /* for gpio operation safety, add read and write mutex, each time only one spi device W/R can be excuted */
    sal_mutex_lock (g_spi_cpm_mutex);        
    ret = spi_read(spi_pgen, (uint8 *)&(spi_ppara->addr), (uint8 *)spi_ppara->val);
    sal_mutex_unlock (g_spi_cpm_mutex);

    return ret;
}

/*********************************************************************
 * Name    : spi_cpm_write
 * Purpose :  write spi bus
 * Input   : const spi_handle_t *phdl       - the handler of the spi bus
          spi_op_para_t *ppara     - some info about spi bus layer operation
                                       
 * Output  : N/A
 * Return  : SPI_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
spi_cpm_write(const spi_handle_t *phdl, spi_op_para_t *ppara)
{
    spi_gen_t *spi_pgen = NULL;
    spi_op_para_t *spi_ppara = NULL;    
    int32 ret;
        
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(ppara);
    
    spi_pgen = (spi_gen_t *)phdl->data;
    spi_ppara = ppara;
    
     /* for gpio operation safety, add read and write mutex, each time only one spi device W/R can be excuted */
    sal_mutex_lock (g_spi_cpm_mutex);        
    ret = spi_write(spi_pgen, (uint8 *)&(spi_ppara->addr),(uint8 *)(spi_ppara->val));
    sal_mutex_unlock(g_spi_cpm_mutex);
    
    return ret;    
}

/*********************************************************************
 * Name    : spi_cpm_create_handle
 * Purpose :  create low level I/O handle
 * Input   : const spi_gen_t *spi_info     - some info about the spi bus implement
 
 * Output  : N/A
 * Return  : spi bus handle
           
 * Note    : N/A
*********************************************************************/

spi_handle_t *spi_cpm_create_handle(const spi_gen_t *spi_info)
{
    spi_handle_t *phdl = NULL;    
    spi_gen_t * spi_pgen;

    g_spi_cpm2_immr = (volatile immap_t *)(spi_info->spi_info.spi_cpm_info.cpm_base);
    
    rxbuf = (uint8 *)&(g_spi_cpm2_immr->im_dprambase)[CONFIG_SYS_SPI_INIT_OFFSET];
    txbuf =( uint8 *)&(g_spi_cpm2_immr->im_dprambase)[CONFIG_SYS_SPI_INIT_OFFSET+MAX_BUFFER];
    
    phdl = (spi_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_SPI_INFO,sizeof(spi_handle_t));
    if (NULL == phdl)
    {
        DRV_LOG_ERR( "spi_cpm_create_handle malloc fail!\n");
        goto err_out;
    }

    phdl->data = (spi_gen_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_SPI_INFO,sizeof(spi_gen_t));
    if (NULL == phdl->data)
    {
        DRV_LOG_ERR( "spi_cpm_create_handle malloc fail!\n");
        goto err_out;
    }

    memcpy((int8 *)phdl->data, (int8 *)spi_info, sizeof(spi_gen_t));
    
    spi_pgen = ((spi_gen_t *)phdl->data);

    sal_mutex_create(&g_spi_cpm_mutex);

    gpio_init(spi_pgen);
    
    phdl->close = spi_cpm_close;
    phdl->read = spi_cpm_read;
    phdl->write = spi_cpm_write;

    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        sal_mutex_destroy(g_spi_cpm_mutex);

        if (NULL != phdl->data)
        {
            DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO, phdl->data);
            phdl->data = NULL;
        }
        
        DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO, phdl);
        phdl = NULL;
    }

    return NULL;
}

