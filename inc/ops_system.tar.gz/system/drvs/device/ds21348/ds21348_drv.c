/****************************************************************************
 * ds21348_drv.c   ds21348 access interface
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2011-03-30.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "ctc_spi.h"
#include "drv_debug.h"
#include "ds21348_drv.h"
#include "ds21348_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static ds21348_handle_t* ds21348_spi_create_handle();
static ds21348_handle_t* ds21348_spi_register(spi_gen_t* spi_pgen);

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
static void
_msb_to_lsb(uint8* addr)
{
    uint32 i = 0;
    uint8 new_addr = 0,temp = 1;
    
    for (i=0;i<8;i++)
    {
        
		if((*addr)&0x1)
		{
            temp <<= (7-i);
            new_addr |=temp;
		}
        
        
        temp = 1;
		*addr >>= 1;
	}
    *addr  = new_addr;
    return;
}

#define BIT_SWAP(x) \
 ((uint8)( \
 (((uint8)(x) &  0x1) << 7) | \
 (((uint8)(x) &  0x2) << 5) | \
 (((uint8)(x) &  0x4) << 3) | \
 (((uint8)(x) &  0x8) << 1) | \
 (((uint8)(x) &  0x10) >> 1) | \
 (((uint8)(x) &  0x20) >> 3) | \
 (((uint8)(x) &  0x40) >> 5) | \
 (((uint8)(x) & 0x80) >>7) ))

/*********************************************************************
 * Name    : ds21348_spi_close
 * Purpose :  free memory and pointer
 * Input   : ds21348_handle_t *phdl       - the handler of the ds21348
          
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds21348_spi_close(ds21348_handle_t* phdl)
{
    spi_handle_t* spi_phdl = NULL;
    int32 ret = 0;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(phdl->handle);
    
    spi_phdl = (spi_handle_t*)phdl->handle;
    ret = spi_phdl->close(spi_phdl);

    DRV_FREE( CTCLIB_MEM_DRIVER_DS21348_INFO, phdl);
    phdl = NULL;

    return ret;
}

/*********************************************************************
 * Name    : ds21348_spi_write
 * Purpose :  write a spi type ds21348 register
 * Input   : const ds21348_handle_t *phdl       - the handler of the ds21348
          ds21348_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds21348_spi_write(const ds21348_handle_t* phdl, ds21348_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;
    uint32 value = 0;
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
    sal_memset(&spi_para, 0, sizeof(spi_op_para_t)); 
    _msb_to_lsb(&(paccess->addr));
    spi_para.addr= (DS21348_SPI_WRITE<<7) | (((paccess->addr) >> 1) & 0xff) | (DS21348_SPI_ACCESS_MODE) ;
    value = *(paccess->val);
    DRV_LOG_DEBUG(ds21348, DRV_DS21348_WRITE, "ds21348_spi_write value %x",value);
    value = BIT_SWAP(value);    
    DRV_LOG_DEBUG(ds21348, DRV_DS21348_WRITE, "ds21348_spi_write value %x",value);
    spi_para.val = &value;
     

    DRV_LOG_DEBUG(ds21348, DRV_DS21348_WRITE, "ds21348_spi_write addr %x, val %x",
                            spi_para.addr, *(spi_para.val));
    
    return spi_phdl->write(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ds21348_spi_read
 * Purpose :  read a spi type ds21348 register
 * Input   : const ds21348_handle_t *phdl       - the handler of the ds21348
          ds21348_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds21348_spi_read(const ds21348_handle_t* phdl, ds21348_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;    
    
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);

    sal_memset(&spi_para, 0, sizeof(spi_op_para_t));   
    spi_phdl = (spi_handle_t *)phdl->handle;
    _msb_to_lsb(&(paccess->addr));
    spi_para.addr= (DS21348_SPI_READ<<7) | (((paccess->addr) >> 1) & 0xff) | (DS21348_SPI_ACCESS_MODE) ;

    spi_para.val = (paccess->val);

    DRV_LOG_DEBUG(ds21348, DRV_DS21348_READ,"ds21348_spi_read addr %x, val %x",
                            spi_para.addr, *(spi_para.val));    
    
    return spi_phdl->read(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ds21348_spi_create_handle
 * Purpose :  create a ds21348 device handler
 * Input   : spi_handle_t *spi_phdl       - the handler of the spi bus layer          
                                       
 * Output  : N/A
 * Return  : the handler of the ds21348
          
 * Note    : N/A
*********************************************************************/

static ds21348_handle_t*
ds21348_spi_create_handle(spi_handle_t* spi_phdl)
{
    ds21348_handle_t* phdl = NULL; 
    
    DRV_CTC_CHK_PTR_NULL(spi_phdl);
    
    phdl = (ds21348_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_DS21348_INFO,sizeof(ds21348_handle_t));

    if (NULL == phdl)
    {
        goto err_out;
    }

    phdl->handle = (void *)spi_phdl;

    phdl->close = ds21348_spi_close;
    phdl->read = ds21348_spi_read;
    phdl->write = ds21348_spi_write;
    
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        DRV_FREE( CTCLIB_MEM_DRIVER_DS21348_INFO,phdl);
        phdl = NULL;
    }

    return NULL;
}

/*********************************************************************
 * Name    : ds21348_spi_register
 * Purpose :  register spi type ds21348
 * Input   : spi_gen_t *spi_pgen      - some info about the way of ds21348'spi bus implement, 
                                        such as gpio, fpga etc
                                       
 * Output  : N/A
 * Return  : the handler of the ds21348
          
 * Note    : N/A
*********************************************************************/

static ds21348_handle_t*
ds21348_spi_register(spi_gen_t* spi_pgen)
{
    spi_handle_t* spi_phdl = NULL;
    
    /* the spi ds21348 */
  
    spi_pgen->alen = DS21348_ADDRESS_LENTH;
    spi_pgen->len = DS21348_DATA_LENTH;
    
    spi_phdl = spi_create_handle(spi_pgen);

    return ds21348_spi_create_handle(spi_phdl);      
}


/*********************************************************************
 * Name    : ds21348_register
 * Purpose :  register a ds21348 device handler
 * Input   : const void *pgen        - some info about the way of ds21348'spi bus implement, 
                                       such as gpio, fpga etc
          ds21348_type_t type         - the type of accessing ds21348, now just have one type ds21348
          
 * Output  : N/A
 * Return  : the handler of the ds21348
           
 * Note    : N/A
*********************************************************************/

ds21348_handle_t*
ds21348_register(ds21348_type_t type, const void* pgen)
{       
    spi_gen_t* spi_pgen = (spi_gen_t*)pgen;
    
    DRV_CTC_CHK_PTR_NULL(pgen);
    
    switch(type)
    {
        case E_DS21348_SPI:           
            return ds21348_spi_register(spi_pgen);

        default:
            break;        
    }
    
    return NULL;
}


