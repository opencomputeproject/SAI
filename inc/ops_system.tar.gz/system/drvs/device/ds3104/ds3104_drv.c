/****************************************************************************
 * ds3104_drv.c   ds3104 access interface
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2011-02-17.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "ctc_spi.h"
#include "drv_debug.h"
#include "ds3104_drv.h"
#include "ds3104_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static ds3104_handle_t* ds3104_spi_create_handle();
static ds3104_handle_t* ds3104_spi_register(spi_gen_t* spi_pgen);

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
/*********************************************************************
 * Name    : ds3104_spi_close
 * Purpose :  free memory and pointer
 * Input   : ds3104_handle_t *phdl       - the handler of the ds3104
          
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds3104_spi_close(ds3104_handle_t* phdl)
{
    spi_handle_t* spi_phdl = NULL;
    int32 ret = 0;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(phdl->handle);
    
    spi_phdl = (spi_handle_t*)phdl->handle;
    ret = spi_phdl->close(spi_phdl);

    DRV_FREE( CTCLIB_MEM_DRIVER_DS3104_INFO, phdl);
    phdl = NULL;

    return ret;
}

/*********************************************************************
 * Name    : ds3104_spi_write
 * Purpose :  write a spi type ds3104 register
 * Input   : const ds3104_handle_t *phdl       - the handler of the ds3104
          ds3104_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds3104_spi_write(const ds3104_handle_t* phdl, ds3104_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
    
    spi_para.addr= ((paccess->addr) << 1) | (DS3104_SPI_ACCESS_MODE) | (DS3104_SPI_WRITE<<15);
    spi_para.val = paccess->val;    

//    DRV_LOG_DEBUG(ds3104, DRV_DS3104_WRITE, "ds3104_spi_write addr %d, val pointer %p",
//                            spi_para.addr, spi_para.val);
    
    return spi_phdl->write(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ds3104_spi_read
 * Purpose :  read a spi type ds3104 register
 * Input   : const ds3104_handle_t *phdl       - the handler of the ds3104
          ds3104_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds3104_spi_read(const ds3104_handle_t* phdl, ds3104_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;    

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
      
    spi_para.addr= ((paccess->addr) << 1) | (DS3104_SPI_ACCESS_MODE) | (DS3104_SPI_READ<<15);
    spi_para.val = paccess->val;

//    DRV_LOG_DEBUG(ds3104, DRV_DS3104_WRITE,"ds3104_spi_read addr %d, val pointer %p",
//                            spi_para.addr, spi_para.val);    
    
    return spi_phdl->read(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ds3104_spi_create_handle
 * Purpose :  create a ds3104 device handler
 * Input   : spi_handle_t *spi_phdl       - the handler of the spi bus layer          
                                       
 * Output  : N/A
 * Return  : the handler of the ds3104
          
 * Note    : N/A
*********************************************************************/

static ds3104_handle_t*
ds3104_spi_create_handle(spi_handle_t* spi_phdl)
{
    ds3104_handle_t* phdl = NULL; 
    
    DRV_CTC_CHK_PTR_NULL(spi_phdl);
    
    phdl = (ds3104_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_DS3104_INFO,sizeof(ds3104_handle_t));

    if (NULL == phdl)
    {
        goto err_out;
    }

    phdl->handle = (void *)spi_phdl;

    phdl->close = ds3104_spi_close;
    phdl->read = ds3104_spi_read;
    phdl->write = ds3104_spi_write;
    
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        DRV_FREE( CTCLIB_MEM_DRIVER_DS3104_INFO,phdl);
        phdl = NULL;
    }

    return NULL;
}

/*********************************************************************
 * Name    : ds3104_spi_register
 * Purpose :  register spi type ds3104
 * Input   : spi_gen_t *spi_pgen      - some info about the way of ds3104'spi bus implement, 
                                        such as gpio, fpga etc
                                       
 * Output  : N/A
 * Return  : the handler of the ds3104
          
 * Note    : N/A
*********************************************************************/

static ds3104_handle_t*
ds3104_spi_register(spi_gen_t* spi_pgen)
{
    spi_handle_t* spi_phdl = NULL;
    
    /* the spi ds3104 */
  
    spi_pgen->alen = DS3104_ADDRESS_LENTH;
    spi_pgen->len = DS3104_DATA_LENTH;
    
    spi_phdl = spi_create_handle(spi_pgen);

    return ds3104_spi_create_handle(spi_phdl);      
}


/*********************************************************************
 * Name    : ds3104_register
 * Purpose :  register a ds3104 device handler
 * Input   : const void *pgen        - some info about the way of ds3104'spi bus implement, 
                                       such as gpio, fpga etc
          ds3104_type_t type         - the type of accessing ds3104, now just have one type ds3104
          
 * Output  : N/A
 * Return  : the handler of the ds3104
           
 * Note    : N/A
*********************************************************************/

ds3104_handle_t*
ds3104_register(ds3104_type_t type, const void* pgen)
{       
    spi_gen_t* spi_pgen = (spi_gen_t*)pgen;
    
    DRV_CTC_CHK_PTR_NULL(pgen);
    
    switch(type)
    {
        case E_DS3104_SPI:           
            return ds3104_spi_register(spi_pgen);

        default:
            break;        
    }
    
    return NULL;
}


