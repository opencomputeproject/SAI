/****************************************************************************
 * $Id$
 *  ds3104 err
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Jcao
 * Date          : 2011-02-17 
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __DS3104_ERR_H__
#define __DS3104_ERR_H__
enum ds3104_error_e
{
    DS3104_SUCCESS = 0,
    DS3104_E_ERROR = -999,
    DS3104_E_NO_MEMORY,
    DS3104_E_NOT_INIT,
    DS3104_E_INIT_FAILED,
    DS3104_E_TIMEOUT,    
    DS3104_E_READ,    
    DS3104_E_WRITE,
    /* parameter check error */
    DS3104_E_INVALID_PARAM,
    DS3104_E_INVALID_PTR,
    DS3104_E_INVALID_INDEX,    
    DS3104_E_INVALID_LENGTH,
    DS3104_E_INVALID_CHIP,

};

#endif /*!__ds3104_ERR_H__*/
