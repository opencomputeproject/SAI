#ifndef __LED_API_H__
#define __LED_API_H__

#include "led_drv.h"


enum led_api_mode_e
{
    LED_MODE_1_RXLNK_BIACT,       /* One LED, rxlink + biactivity */
    LED_MODE_1_FORCE_ON,          /* One LED, force on */
    LED_MODE_1_FORCE_OFF,         /* One LED, force off */
    
    LED_MODE_2_RXLNK_BIACT,       /* Two LEDs, first: rxlink; second: biactivity */
    LED_MODE_2_OFF_RXLNKBIACT,    /* Two LEDs, first: off; second: rxlink + biactivity */
    LED_MODE_2_RXLNKBIACT_OFF,    /* Two LEDs, first: rxlink + biactivity; second: off */
    LED_MODE_2_FORCE_OFF,         /* Two LEDs, all force off */
    
    LED_MAX_LED_MODE,
};
typedef enum led_api_mode_e led_api_mode_t;

struct gb_mac_led_api_para_s
{
    uint16 port_id;  /* High 8-bit indicates chip id, low 8-bit indicate logic port id */
    uint8  lchip;    /* local chip id */
    uint8  ctl_id;   /* GG slice id*/
    led_api_mode_t mode;    
};
typedef struct gb_mac_led_api_para_s mac_led_api_para_t;

struct mac_led_info_s
{
    uint8 table_num;        /* table num */
    uint8 slice0_mac_num;   /* mac numbers belong to slice0 */
    uint8 mac_num;          /* mac numbers belong to slice0 and slice1 */
    mac_led_api_para_t** mac_led_api_para;
};
typedef struct mac_led_info_s mac_led_info_t;

int32 mac_led_init(mac_led_api_para_t* port_led, uint8 port_num_per_slice);
int32 led_api_op(glb_led_type_t type, glb_led_stat_t led_stat);
int32 led_init(led_info_t* p_led_info);
int32 led_cfg_port_mode(mac_led_api_para_t* port_led);
int32 mac_led_info_register(mac_led_info_t* p_mac_led_info);
int32 led_mgt_port_led();
int32 mac_led_info_modify(mac_led_api_para_t* port_led);
#endif
