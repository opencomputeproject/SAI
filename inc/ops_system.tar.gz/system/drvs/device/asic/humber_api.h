/****************************************************************************
* $Id$
*  The header file of the asic core chip api.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Jian Zhu
* Date          : 2008-07-21 
* Reason        : First Create.
****************************************************************************/
#ifndef __HUMBER_API_H__
#define __HUMBER_API_H__

//GE PHY0-2
//#define HUMBER_MDIO_BUS0_BASE_ADDR  0xa00
#define HUMBER_MDIO_BUS0_BASE_ADDR  0x4a0000

//GE PHY3-5
//#define HUMBER_MDIO_BUS1_BASE_ADDR  0xb00
#define HUMBER_MDIO_BUS1_BASE_ADDR  0x4b0000

//XG PHY0-7
//#define HUMBER_MDIO_BUS2_BASE_ADDR  0xc00
#define HUMBER_MDIO_BUS2_BASE_ADDR  0x4c0000

int32 asic_reg_read(uint32 chip_id, uint32 offset, uint32* val);
int32 asic_reg_write(uint32 chip_id, uint32 offset, uint32 val);
int32 asic_init(uint8 chip_num);
#endif /* __ASIC_API_H__ */

