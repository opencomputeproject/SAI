/****************************************************************************
 * asic_drv.c    centec asic core chip access
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Zhu Jian
 * Date:         2008-7-23.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "asic_drv.h"
#include "sal_usrctrl.h"

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
int32 
drv_asic_reg_read(asic_dev_t* p_asic_dev, uint32 reg_addr, uint32* value)
{    
    if(NULL == p_asic_dev)
    {
        return -1;
    }
    
    return ctckal_usrctrl_read_bay(p_asic_dev->idx, 0, reg_addr, (uint32)value);
}

int32 
drv_asic_reg_write(asic_dev_t* p_asic_dev, uint32 reg_addr, uint32 value)
{
    if(NULL == p_asic_dev)
    {
        return -1;
    }
    
    return ctckal_usrctrl_write_bay(p_asic_dev->idx, 0, reg_addr, value);
}


/****************************************************************************
 * Name	: asic_dev_register
 * Purpose: register a asic device, initialize the handler
 * Input	:  the chip index, the pointer of chip infomation struct
 * Output:  
 * Return:  the devices handler of the asic
 * Note	:
****************************************************************************/	
asic_dev_t*
asic_dev_register(uint8_t idx)
{
    asic_dev_t* p_drv;
    
    p_drv = (asic_dev_t*)sal_calloc(sizeof(asic_dev_t));
    if(NULL == p_drv)
    {
        return NULL;
    }

    p_drv->idx = idx;
    p_drv->reg_read = drv_asic_reg_read;
    p_drv->reg_write = drv_asic_reg_write;        
 
    return p_drv;
}

