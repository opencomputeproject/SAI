/****************************************************************************
 * asic_api.c    asic core chip api
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Zhu Jian
 * Date:         2008-7-18.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "asic_drv.h"
#include "humber_api.h"
#include "drv_debug.h"
/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
#define GET_ASIC_DRV(chip_id, p_asic_dev)  \
do{        \
    p_asic_dev = g_asic_dev[chip_id];   \
}while(0)

 
/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
asic_dev_t **g_asic_dev;
uint32 g_asic_max_nums; 

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
int32
asic_reg_read(uint32 chip_id, uint32 offset, uint32 *val)
{
    asic_dev_t* p_asic_dev;
    
    GET_ASIC_DRV(chip_id, p_asic_dev);
    if(p_asic_dev == NULL)
        return -1;

    return p_asic_dev->reg_read(p_asic_dev, offset, val);    
}

int32
asic_reg_write(uint32 chip_id, uint32 offset, uint32 val)
{
    asic_dev_t* p_asic_dev;
    
    GET_ASIC_DRV(chip_id, p_asic_dev);
    if(p_asic_dev == NULL)
        return -1;
    
    return p_asic_dev->reg_write(p_asic_dev, offset, val);    
}

int32 
asic_init(uint8 chip_num)
{
    asic_dev_t** pp_asic_dev;
    uint8 chip_id;

    pp_asic_dev = DRV_MALLOC(CTCLIB_MEM_DRIVER_MDIO_INFO, sizeof(asic_dev_t* )*chip_num);
    for(chip_id = 0; chip_id < chip_num; chip_id++)    
    {
        pp_asic_dev[chip_id] = asic_dev_register(chip_id);
        if(NULL == pp_asic_dev[chip_id])
        {
            return -1;
        }
    }
    g_asic_dev = pp_asic_dev;

    return 0;
}

