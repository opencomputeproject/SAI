/****************************************************************************
 * fan_api.c    power api 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2010-10-11.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "power_drv.h"
#include "power_api.h"
#include "epld_api.h"
#include "drv_log.h"
#include "ctc_i2c.h"
#include "gpio_api.h"
/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
static psu_handle_t* g_power_hdl;
static uint8 g_power_num;

static psu_id_info_t g_psu_id_info[] = {
    [PSU_MFR_GREATWALL_AC]     =    {
        .id_table          = {0x08,0x08,0x08,0x08},
        .psu_mode	       = PSU_AC,  //AC
    },
    [PSU_MFR_3Y_DC]        =    {
        .id_table          = {0x06,0x04,0x01,0x03},
        .psu_mode	       = PSU_DC,  //DC
    },
    [PSU_MFR_ETASIS_AC]    = {
        .id_table          = {0x09,0x54,0x46,0x52,0x4b,0x2d,0x47,0x33,0x35,0x36},
        .psu_mode	       = PSU_AC,  //AC
    },
    [PSU_MFR_CPR_AC]       = {
        .id_table          = {0x43,0x50,0x52,0x2d,0x34,0x30,0x31,0x31,0x2d,0x34,0x4d,0x31,0x31},
        .psu_mode	       = PSU_AC,  //AC
    },
    [PSU_MFR_UM_DC]        = {
        .id_table          = {0x75,0x6d,0x34,0x30,0x30,0x64,0x30,0x31},
        .psu_mode	       = PSU_DC,  //DC
    },
};

static psu_mode_info_t g_psu_mode_info[] = {
	[PSU_MODE_TYPE_REG_50_01_04] =   {
    	.dev_addr          = 0x50,
		.id_reg	           = 1,
        .id_len	           = 4,
        .id_info	       = {
            [0]     =    &g_psu_id_info[PSU_MFR_GREATWALL_AC],
            [1]     =    &g_psu_id_info[PSU_MFR_3Y_DC],
            [2]     =    NULL,
            [3]     =    NULL,
        },
    },
	[PSU_MODE_TYPE_REG_51_01_04] =   {
    	.dev_addr          = 0x51,
		.id_reg	           = 1,
        .id_len	           = 4,
        .id_info	       = {
            [0]     =    &g_psu_id_info[PSU_MFR_GREATWALL_AC],
            [1]     =    &g_psu_id_info[PSU_MFR_3Y_DC],
            [2]     =    NULL,
            [3]     =    NULL,
        },
    },
	[PSU_MODE_TYPE_REG_5b_9a_0a] =   {
    	.dev_addr          = 0x5b,
		.id_reg	           = 0x9a,
        .id_len	           = 0xa,
        .id_info	       = {
            [0]     =    &g_psu_id_info[PSU_MFR_ETASIS_AC],
            [1]     =    NULL,
            [2]     =    NULL,
            [3]     =    NULL,
        },
	},
	[PSU_MODE_TYPE_REG_38_26_0d] =   {
	    .dev_addr          = 0x38,
		.id_reg	           = 0x26,
        .id_len	           = 0xd,
        .id_info	       = {
            [0]     =    &g_psu_id_info[PSU_MFR_CPR_AC],
            [1]     =    NULL,
            [2]     =    NULL,
            [3]     =    NULL,
        },
	},
	[PSU_MODE_TYPE_REG_50_50_08] =   {
	    .dev_addr          = 0x50,
		.id_reg	           = 0x50,
        .id_len	           = 0x8,
        .id_info	       = {
            [0]     =    &g_psu_id_info[PSU_MFR_UM_DC],
            [1]     =    NULL,
            [2]     =    NULL,
            [3]     =    NULL,
        },
	},
};

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/



/****************************************************************************
 *
* Functions  
*
****************************************************************************/
static psu_handle_t*
_get_power_handle(uint8 psu_idx)
{
    if(g_power_num <= psu_idx)
    {
        return NULL;
    }
    return &g_power_hdl[psu_idx];
}

static int32
_psu_epld_init(psu_handle_t* handle)
{
    return RESULT_OK;
}

/*shutdown: 1 mean shutdown, 0 mean undo shutdown*/
static int32
_psu_epld_set_shutdown(psu_handle_t* handle, uint8 psu_idx, uint8 shutdown)
{
    uint8 epld_idx;
    epld_idx = *((uint8 *)handle->io_hdl->p_data_epld);
    epld_set_psu_shutdown(psu_idx, epld_idx, shutdown);
    return RESULT_OK;
}

static int32
_psu_epld_get_status(psu_handle_t* handle, uint8 psu_idx, psu_status_t* status)
{
    uint8 epld_idx, psu_type;
    epld_psu_status_t epld_psu_status = {0};
    
    psu_type = handle->p_data->psu_type;
    epld_idx = *((uint8 *)handle->io_hdl->p_data_epld);
    epld_get_psu_status(psu_idx, &epld_psu_status, epld_idx, psu_type);
    /* deleted by liuht for bug 24525,e350 don't support psu fan, 2013-10-24 */	   	
#if 0	
    status->psu_fan = epld_psu_status.psu_fan;
#endif
    status->psu_mode = epld_psu_status.psu_mode;
    status->psu_absent = epld_psu_status.psu_absent;
    status->psu_work_status = epld_psu_status.psu_work_status;
    status->psu_alert = epld_psu_status.psu_alert;
    /* deleted by liuht for bug 24525,e350 don't support psu shutdown, 2013-10-24 */	
#if 0	
    status->shutdown = epld_psu_status.psu_shutdown;
#endif
    status->psu_type = handle->p_data->psu_type;
	
    return RESULT_OK;
}

/* added by liuht for bug 24525,2013-10-24 */
static int32
_psu_reg_read(psu_handle_t* handle, uint8 reg, uint8* value, uint8 len)
{
    psu_access_t access;
    int ret;

    access.reg = reg;
    access.val = value;
    access.len = len;
    ret = handle->io_hdl->read(handle->io_hdl, &access);
    if(ret < 0)
    {
        DRV_LOG_ERR("psu reg read fail. reg 0x%x", reg);
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

/* Added by liuht  for bug26772 to write power eeprom, 2013-01-11 */
static int32
_psu_reg_write(psu_handle_t* handle, uint8 reg, uint8* value, uint8 len)
{
    psu_access_t access;
    int ret;

    access.reg = reg;
    access.val = value;
    access.len = len;
    ret = handle->io_hdl->write(handle->io_hdl, &access);
    if(ret < 0)
    {
        DRV_LOG_ERR("psu reg write fail. reg 0x%x", reg);
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

static int32
_psu_attr_mod(psu_handle_t* handle, uint8 dev_addr)
{
    int ret;

    ret = handle->io_hdl->mattr(handle->io_hdl, dev_addr);
    if(ret < 0)
    {
        DRV_LOG_ERR("modify power attr dev_addr 0x%x", dev_addr);
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

static int32
_psu_i2c_get_mode(psu_handle_t* handle, uint8 psu_idx, uint8* mode)
{
    uint8 buf[PSU_ID_LEN_MAX];
    uint8 i, j;
    uint8 dev_addr;
    uint8 id_match = 0;
    uint8 id_reg, id_len;
    uint32 psu_mode_type;
    psu_id_info_t* p_psu_id_info;
    int ret = RESULT_OK;

    psu_mode_type = handle->p_data->psu_mode_type;
    for(i=0; i<PSU_MODE_TYPE_REG_MAX; i++)
    {
        if((psu_mode_type>>i) & 0x1)
        {
            dev_addr = g_psu_mode_info[i].dev_addr;
            id_reg = g_psu_mode_info[i].id_reg;
            id_len = g_psu_mode_info[i].id_len;
            ret = handle->attr_mod(handle, dev_addr);
            if(ret < 0)
            {
                continue;
            }
            sal_memset(buf, 0, PSU_ID_LEN_MAX);
            ret = handle->reg_read(handle, id_reg, buf, id_len);
            if(ret < 0)
            {
                continue;
            }

            for(j=0; j<PSU_ID_TABLE_LEN_MAX; j++)
            {
                p_psu_id_info = g_psu_mode_info[i].id_info[j];
                if(!p_psu_id_info)
                    continue;

                if(sal_strncmp((char*)p_psu_id_info->id_table, (char*)buf, id_len) == 0)    
                {
                    *mode = p_psu_id_info->psu_mode;
                    id_match = 1;
                    break;
                }
            }
        }
        if(id_match)
        {
            break;
        }
    }
    if(!id_match)
    {
        *mode = PSU_AC;
    }

    return RESULT_OK;
}

static int32
_psu_i2c_epld_get_status(psu_handle_t* handle, uint8 psu_idx, psu_status_t* status)
{
    uint32 ret = RESULT_OK;
    uint8 epld_idx, psu_type;
    epld_psu_status_t epld_psu_status;

    /* 1. get psu status from epld */
    psu_type = handle->p_data->psu_type;
    epld_idx = *((uint8 *)handle->io_hdl->p_data_epld);
    epld_get_psu_status(psu_idx, &epld_psu_status, epld_idx, psu_type);    
    status->psu_absent = epld_psu_status.psu_absent;
    status->psu_work_status = epld_psu_status.psu_work_status;
    status->psu_alert = epld_psu_status.psu_alert;
    status->psu_type = handle->p_data->psu_type;
    
    /*2. get psu mode from psu eeprom when power supply ok twice*/
    if(status->psu_work_status == 0)
    {
        if(handle->p_data->psu_ok_cnt<2)
            handle->p_data->psu_ok_cnt++;
    }
    else
    {
        handle->p_data->psu_ok_cnt=0;
    }

    if(handle->p_data->psu_ok_cnt<2)
    {
        handle->p_data->psu_mode = PSU_UNKNOWN;
        status->psu_mode = PSU_UNKNOWN;
    }
    else if(handle->p_data->psu_mode == PSU_UNKNOWN)
    {
        _psu_i2c_get_mode(handle,psu_idx,&(status->psu_mode));
        handle->p_data->psu_mode = status->psu_mode;
    }
    else
    {
        status->psu_mode = handle->p_data->psu_mode;
    }

    return ret;
}

static int32
_psu_i2c_gpio_get_status(psu_handle_t* handle, uint8 psu_idx, psu_status_t* status)
{
    int32 ret;
    psu_data_gpio *psu_data;
    uint8 value;
    
    /*1. get psu status by gpio*/
    psu_data = handle->io_hdl->p_data_gpio;
    /*raw value 1 means absent.*/
    ret = gpio_get_scan_special_bit_value(psu_data->present_chip, psu_data->present_no, &value);
    if(value)
    {
        status->psu_absent = 1;
    }
    else
    {
        status->psu_absent = 0;
    }
    /*raw value 0 means good.*/
    ret = gpio_get_scan_special_bit_value(psu_data->workstate_chip, psu_data->workstate_no, &value);
    if(value)
    {
        status->psu_work_status = 1;
    }
    else
    {
        status->psu_work_status = 0;
    }
    /*raw value 1 means alert.*/
    ret = gpio_get_scan_special_bit_value(psu_data->alert_chip, psu_data->alert_no, &value);
    if(value)
    {
        status->psu_alert = 1;
    }
    else
    {
        status->psu_alert = 0;
    }
    status->psu_type = handle->p_data->psu_type;
    
    /*2. get psu mode from psu eeprom when power supply ok twice*/
    if(status->psu_work_status == 0)
    {
        if(handle->p_data->psu_ok_cnt<2)
            handle->p_data->psu_ok_cnt++;
    }
    else
    {
        handle->p_data->psu_ok_cnt=0;
    }

    if(handle->p_data->psu_ok_cnt<2)
    {
        handle->p_data->psu_mode = PSU_UNKNOWN;
        status->psu_mode = PSU_UNKNOWN;
    }
    else if(handle->p_data->psu_mode == PSU_UNKNOWN)
    {
        _psu_i2c_get_mode(handle,psu_idx,&(status->psu_mode));
        handle->p_data->psu_mode = status->psu_mode;
    }
    else
    {
        status->psu_mode = handle->p_data->psu_mode;
    }
    return ret;
}

static int32
_psu_EPLD_register_driver(psu_handle_t* handle)
{
    handle->psu_init = _psu_epld_init;
    handle->set_shutdown = _psu_epld_set_shutdown;
    handle->get_status = _psu_epld_get_status;
    return RESULT_OK;
}

/* added by liuht for bug 24525,2013-10-24 */
static int32
_psu_I2C_EPLD_register_driver(psu_handle_t* handle)
{
    handle->psu_init = _psu_epld_init;
    handle->set_shutdown = _psu_epld_set_shutdown;
    handle->reg_read = _psu_reg_read;
    handle->reg_write = _psu_reg_write;
    handle->attr_mod = _psu_attr_mod;
    handle->get_status = _psu_i2c_epld_get_status;
    return RESULT_OK;
}
static int32
_psu_I2C_GPIO_register_driver(psu_handle_t* handle)
{
    handle->psu_init = NULL;
    handle->set_shutdown = NULL;
    handle->reg_read = _psu_reg_read;
    handle->reg_write = _psu_reg_write;
    handle->attr_mod = _psu_attr_mod;
    handle->get_status = _psu_i2c_gpio_get_status;
    return RESULT_OK;    
}

/*shutdown: 1 mean shutdown, 0 mean undo shutdown*/
int32 
psu_set_shutdown(uint8 psu_idx, uint8 shutdown)
{    
    psu_handle_t* p_hdl = NULL;

    p_hdl = _get_power_handle(psu_idx);
    
    DRV_CTC_CHK_PTR(p_hdl);
    if(NULL == p_hdl->set_shutdown)
        return RESULT_OK;
    return p_hdl->set_shutdown(p_hdl, psu_idx, shutdown);
}

int32 
psu_get_status(uint8 psu_idx, psu_status_t * p_psu_status)
{
    psu_handle_t* p_hdl = NULL;

    p_hdl = _get_power_handle(psu_idx);
    
    DRV_CTC_CHK_PTR(p_hdl);
    DRV_CTC_CHK_PTR(p_psu_status);
    
    return p_hdl->get_status(p_hdl, psu_idx, p_psu_status);
}

/* Added by liuht  for bug26772 to read power eeprom, 2013-01-11 */
int32
psu_reg_read(uint32 psu_id, uint8 reg, uint8* value, uint8 len)
{
    if(psu_id >= g_power_num)
    {
        DRV_LOG_ERR("Psu id %d is error!, max is %d\n", psu_id, g_power_num);
        return RESULT_ERROR;
    }
    DRV_CTC_CHK_PTR(g_power_hdl[psu_id].reg_read);
    return g_power_hdl[psu_id].reg_read(&g_power_hdl[psu_id], reg, value, len);
}

/* Added by liuht  for bug26772 to write power eeprom, 2013-01-11 */
int32
psu_reg_write(uint32 psu_id, uint8 reg, uint8 value, uint8 len)
{
    if(psu_id >= g_power_num)
    {
        DRV_LOG_ERR("Psu id %d is error!, max is %d\n", psu_id, g_power_num);
        return RESULT_ERROR;
    }
    DRV_CTC_CHK_PTR(g_power_hdl[psu_id].reg_write);
    return g_power_hdl[psu_id].reg_write(&g_power_hdl[psu_id], reg, &value, len);
}


/*********************************************************************
 * Name    : psu_init
 * Purpose :  init some data structure 
 * Input   : psu_chip_t power_type    - operate power type
          uint8 power_num         - the number of power
 * Output  : N/A
 * Return  : RESULT_OK   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/
int32
psu_init(psu_private_t* p_data, psu_chip_t* type, uint8 power_num)
{
    int32 i = 0;
    psu_private_data_t* private_data;

    DRV_CTC_CHK_PTR(p_data);
    DRV_CTC_CHK_PTR(type);
    
    g_power_hdl = (psu_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_POWER_INFO,sizeof(psu_handle_t)*power_num);
    if(NULL == g_power_hdl)
    {
        DRV_LOG_ERR("Power alloc handler fail!\n");
        return RESULT_ERROR;
    }
    for (i = 0; i < power_num; i++)
    {
        private_data = (psu_private_data_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_POWER_INFO, sizeof(psu_private_data_t));
        if(NULL == private_data)
        {
            DRV_LOG_ERR("Power alloc private data fail!\n");
            return RESULT_ERROR;
        }

        g_power_hdl[i].p_data = private_data;
        private_data->psu_type = type[i].psu_type;
        private_data->psu_mode_type = type[i].psu_mode_type;	
        private_data->psu_mode = PSU_UNKNOWN;	
        private_data->psu_ok_cnt = 0;
        g_power_hdl[i].io_hdl = psu_io_register(type[i].io_type, &p_data[i]);
        if(NULL == g_power_hdl[i].io_hdl)
        {
            DRV_LOG_ERR("Power alloc io handler fail!\n");
            return RESULT_ERROR;
        }
        switch(type[i].chip_type)
        {
            case PSU_EPLD:
                _psu_EPLD_register_driver(&g_power_hdl[i]);
                break;
            case PSU_I2C_EPLD:
                _psu_I2C_EPLD_register_driver(&g_power_hdl[i]);
                break;
            case PSU_I2C_GPIO:
                _psu_I2C_GPIO_register_driver(&g_power_hdl[i]);
                break;
            default:
                DRV_LOG_ERR("Unsupport power chip type %d!\n", type[i].chip_type);
                DRV_LOG_USER(E_ERROR, DRV_3_PSU_TYPE_UNKNOWN, type[i].chip_type);
                break;
        }
    }
    g_power_num = power_num;

    //psu_status_t p_psu_status;
    //psu_get_status(0, &p_psu_status);
    //psu_get_status(1, &p_psu_status);
    
    return RESULT_OK;
}

#ifdef BOOTUP_DIAG
int32 
psu_diagnostic_test(uint8 *psu_num, psu_diag_result_t* diag_result)
{
    uint8 idx;
    int32 ret1 = RESULT_OK, ret2 = RESULT_OK;
    psu_status_t p_psu_status[MAX_PSU_NUM];

    DRV_CTC_CHK_PTR(diag_result);
    DRV_CTC_CHK_PTR(psu_num);

    *psu_num = g_power_num;
    for(idx = 0; idx < g_power_num; idx++)
    {
        ret1 = psu_get_status(idx, &p_psu_status[idx]);
        if(ret1)
        {
            DRV_LOG_ERR("psu get status index %d is fail!\n", idx);
            diag_result[idx].access_fail = 1;
            ret2 = RESULT_ERROR;
            continue;
        }
        
        if(p_psu_status->psu_absent)
        {
            DRV_LOG_ERR("psu_absent index %d is absent!\n", idx);
            diag_result[idx].absent = 1;
            ret2 = RESULT_ERROR;
            continue;
        }
        if(p_psu_status->psu_work_status)
        {
            DRV_LOG_ERR("psu_work_status index %d is abnormal!\n", idx);
            diag_result[idx].status_fail = 1;
            ret2 = RESULT_ERROR;
        }
        if(p_psu_status->psu_alert)
        {
            DRV_LOG_ERR("psu_alert index %d is alert!\n", idx);
            diag_result[idx].alert = 1;
            ret2 = RESULT_ERROR;
        }  
    }

    return ret2;
}

#endif



