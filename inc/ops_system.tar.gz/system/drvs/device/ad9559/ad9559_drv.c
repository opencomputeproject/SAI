/****************************************************************************
 * ad9559_drv.c   ad9559 access interface
 *
 * Copyright:    (c)2005 Actus Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Chani
 * Date:         2013-09-30.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "ctc_spi.h"
#include "drv_debug.h"
#include "ad9559_drv.h"
#include "ad9559_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static ad9559_handle_t* ad9559_spi_create_handle();
static ad9559_handle_t* ad9559_spi_register(spi_gen_t* spi_pgen);

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
/*********************************************************************
 * Name    : ad9559_spi_close
 * Purpose :  free memory and pointer
 * Input   : ad9559_handle_t *phdl       - the handler of the ad9559
          
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9559_spi_close(ad9559_handle_t* phdl)
{
    spi_handle_t* spi_phdl = NULL;
    int32 ret = 0;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(phdl->handle);
    
    spi_phdl = (spi_handle_t*)phdl->handle;
    ret = spi_phdl->close(spi_phdl);

    DRV_FREE( CTCLIB_MEM_DRIVER_AD9559_INFO, phdl);
    phdl = NULL;

    return ret;
}

/*********************************************************************
 * Name    : ad9559_spi_write
 * Purpose :  write a spi type ad9559 register
 * Input   : const ad9559_handle_t *phdl       - the handler of the ad9559
          ad9559_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9559_spi_write(const ad9559_handle_t* phdl, ad9559_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
    
    spi_para.addr= (paccess->addr) | (AD_SPI_WIDTH_1<<13) | (AD_SPI_WRITE<<15);//from AD9559 DATASHEET
    spi_para.val = paccess->val;    

    DRV_LOG_DEBUG(ad9559, DRV_AD9559_WRITE, "ad9559_spi_write addr %d, val pointer %p",
                            spi_para.addr, spi_para.val);
    
    return spi_phdl->write(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ad9559_spi_read
 * Purpose :  read a spi type ad9559 register
 * Input   : const ad9559_handle_t *phdl       - the handler of the ad9559
          ad9559_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9559_spi_read(const ad9559_handle_t* phdl, ad9559_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;    

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
      
    spi_para.addr = (paccess->addr) | (AD_SPI_WIDTH_1<<13) | (AD_SPI_READ<<15);//from AD9559 DATASHEET    
    spi_para.val  = paccess->val;

    DRV_LOG_DEBUG(ad9559, DRV_AD9559_WRITE,"ad9559_spi_read addr %d, val pointer %p",
                            spi_para.addr, spi_para.val);    
    
    return spi_phdl->read(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ad9559_spi_create_handle
 * Purpose :  create a ad9559 device handler
 * Input   : spi_handle_t *spi_phdl       - the handler of the spi bus layer          
                                       
 * Output  : N/A
 * Return  : the handler of the ad9559
          
 * Note    : N/A
*********************************************************************/

static ad9559_handle_t*
ad9559_spi_create_handle(spi_handle_t* spi_phdl)
{
    ad9559_handle_t* phdl = NULL; 
    
    DRV_CTC_CHK_PTR_NULL(spi_phdl);
    
    phdl = (ad9559_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_AD9559_INFO,sizeof(ad9559_handle_t));

    if (NULL == phdl)
    {
        goto err_out;
    }

    phdl->handle = (void *)spi_phdl;

    phdl->close = ad9559_spi_close;
    phdl->read = ad9559_spi_read;
    phdl->write = ad9559_spi_write;
    
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        DRV_FREE( CTCLIB_MEM_DRIVER_AD9559_INFO,phdl);
        phdl = NULL;
    }

    return NULL;
}

/*********************************************************************
 * Name    : ad9559_spi_register
 * Purpose :  register spi type ad9559
 * Input   : spi_gen_t *spi_pgen      - some info about the way of ad9559'spi bus implement, 
                                        such as gpio, fpga etc
                                       
 * Output  : N/A
 * Return  : the handler of the ad9559
          
 * Note    : N/A
*********************************************************************/

static ad9559_handle_t*
ad9559_spi_register(spi_gen_t* spi_pgen)
{
    spi_handle_t* spi_phdl = NULL;
    
    /* the spi ad9559 */
  
    spi_pgen->alen = AD9559_ADDRESS_LENTH;
    spi_pgen->len = AD9559_DATA_LENTH;
    
    spi_phdl = spi_create_handle(spi_pgen);

    return ad9559_spi_create_handle(spi_phdl);      
}


/*********************************************************************
 * Name    : ad9559_register
 * Purpose :  register a ad9559 device handler
 * Input   : const void *pgen        - some info about the way of ad9559'spi bus implement, 
                                       such as gpio, fpga etc
          ad9559_type_t type         - the type of accessing ad9559, now just have one type ad9559
          
 * Output  : N/A
 * Return  : the handler of the ad9559
           
 * Note    : N/A
*********************************************************************/

ad9559_handle_t*
ad9559_register(ad9559_type_t type, const void* pgen)
{       
    spi_gen_t* spi_pgen = (spi_gen_t*)pgen;
    
    DRV_CTC_CHK_PTR_NULL(pgen);
    
    switch(type)
    {
        case E_AD9559_SPI:           
            return ad9559_spi_register(spi_pgen);

        default:
            break;        
    }
    
    return NULL;
}


