/****************************************************************************
 * $Id$
 *  AD9559 err
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Chani
 * Date          : 2013-09-30 
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __AD9559_ERR_H__
#define __AD9559_ERR_H__
enum ad9559_error_e
{
    AD9559_SUCCESS = 0,
    AD9559_E_ERROR = -999,
    AD9559_E_NO_MEMORY,
    AD9559_E_NOT_INIT,
    AD9559_E_INIT_FAILED,
    AD9559_E_TIMEOUT,    
    AD9559_E_READ,    
    AD9559_E_WRITE,
    /* parameter check error */
    AD9559_E_INVALID_PARAM,
    AD9559_E_INVALID_PTR,
    AD9559_E_INVALID_INDEX,    
    AD9559_E_INVALID_LENGTH,
    AD9559_E_INVALID_CHIP,

};

#endif /*!__AD9559_ERR_H__*/
