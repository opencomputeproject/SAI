/****************************************************************************
* $Id$
*  The header file of the ad9559 api.
*
* (C) Copyright Actus Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Chani
* Date          : 2013-09-30 
* Reason        : First Create.
****************************************************************************/
#ifndef __AD9559_API_H__
#define __AD9559_API_H__

#include "ctc_spi.h"

typedef enum
{
    E_AD9559_CLOCK_TYPE_0 = 0,        
    E_AD9559_CLOCK_TYPE_1 ,          
    E_AD9559_CLOCK_TYPE_2 ,          
    E_AD9559_CLOCK_TYPE_3 ,           
} ad9559_clock_type_e;

#define AD9559_NUM   0x1

#define AD9559_SPI_DO_BIT       0x4000                  /*PD17*/
#define AD9559_SPI_DI_BIT       0x8000                  /*PD16*/
#define AD9559_SPI_CLK_BIT      0x2000                  /*PD18*/
#define AD9559_SPI_CS_BIT       0x40                    /*PD25*/



int32 ad9559_read(uint32 idx, uint16 addr, uint32  *val);
int32 ad9559_write(uint32 idx, uint16 addr, uint32  val);
int32 ad9559_close(uint32 idx);
int32 ad9559_init(spi_gen_t *spi_gen, uint32 num);

#endif 

