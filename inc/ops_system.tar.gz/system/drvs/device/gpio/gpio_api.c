/****************************************************************************
 * gpio_api.c    gpio api 
 *
 * Copyright:    (c)2014 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       liuht
 * Date:         2014-12-06.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "gpio_api.h"
#include "gpio_drv.h"
#include "epld_api.h"
/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
/* gpio device handler */
static gpio_handle_t* g_gpio_hdl;
static uint32 g_gpio_chip_num;

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/



/****************************************************************************
 *
* Functions  
*
****************************************************************************/
static int32
_gpio_pca9505_reg_read(gpio_handle_t* handle, uint8 reg, uint8* value, uint8 len)
{
    gpio_access_t access;
    
    access.reg = reg;
    access.val = value;
    access.len = len;
    return handle->io_hdl->read(handle->io_hdl, &access);
}

static int32
_gpio_pca9505_reg_write(gpio_handle_t* handle, uint8 reg, uint8* value, uint8 len)
{
    gpio_access_t access;
    
    access.reg = reg;
    access.val = value;
    access.len = len;
    return handle->io_hdl->write(handle->io_hdl, &access);    
}

static int32 
_gpio_pca9505_register_driver(gpio_handle_t* handle)
{
    handle->reg_read = _gpio_pca9505_reg_read;
    handle->reg_write = _gpio_pca9505_reg_write;

    return RESULT_OK;
}

int32
gpio_reg_read(uint32 chip_id, uint8 reg, uint8* value, uint8 len)
{
    if(chip_id >= g_gpio_chip_num)
    {
        DRV_LOG_ERR("Gpio chip id %d is error!, max is %d\n", chip_id, g_gpio_chip_num);
        return RESULT_ERROR;
    }
    DRV_CTC_CHK_PTR(g_gpio_hdl[chip_id].reg_read);
    return g_gpio_hdl[chip_id].reg_read(&g_gpio_hdl[chip_id], reg, value, len);
}

int32
gpio_reg_write(uint32 chip_id, uint8 reg, uint8* value, uint8 len)
{
    if(chip_id >= g_gpio_chip_num)
    {
        DRV_LOG_ERR("Gpio chip id %d is error!, max is %d\n", chip_id, g_gpio_chip_num);
        return RESULT_ERROR;
    }
    DRV_CTC_CHK_PTR(g_gpio_hdl[chip_id].reg_read);
    return g_gpio_hdl[chip_id].reg_write(&g_gpio_hdl[chip_id], reg, value, len);
}
/*****************************************************************************
 * Name         :   gpio_get_scan_special_bit_value
 * Purpose      :   gpio get special bit value when gpio_scan_real_time_value func is periodly called.
 * Input        :   gpio chip id, bit No.  
 *              :   value   : 1/0
 * Return       :    
 * Note         :   This func just get value stored in buffer, will not access real register.
 *****************************************************************************/
int32
gpio_get_scan_special_bit_value(uint8 chip, uint8 no, uint8 *value)
{
    uint8 val;

    if(chip >= g_gpio_chip_num)
    {
        DRV_LOG_ERR("Gpio chip id %d is error!, max is %d\n", chip, g_gpio_chip_num);
        return RESULT_ERROR;
    }
    val = g_gpio_hdl[chip].scan_value[no/PCA9505_PORTS_PER_BANK];
    
    if(val & (1<<(no%PCA9505_PORTS_PER_BANK)))
    {
        *value = 1;
    }
    else
    {
        *value = 0;
    }
    return RESULT_OK;     
}

/*****************************************************************************
 * Name         :   gpio_set_special_bit
 * Purpose      :   gpio set special bit value 
 * Input        :   gpio chip id, bit No.  
 *              :   value   : 1/0
 * Return       :    
 * Note         :
 *****************************************************************************/
int32
gpio_set_special_bit(uint8 chip, uint8 no, uint8 value)
{
    int ret = 0;
    uint8 val, reg;

    reg = PCA9505_OUTPUT_PORT_REG_BANK0+no/PCA9505_PORTS_PER_BANK;
    ret = gpio_reg_read(chip, reg, &val, 1);
    if(value)
    {
        val |= (1<<(no%PCA9505_PORTS_PER_BANK));
    }
    else
    {
        val &= ~(1<<(no%PCA9505_PORTS_PER_BANK));        
    }
    ret += gpio_reg_write(chip, reg, &val, 1);
    return ret;  
}

/*****************************************************************************
 * Name         :   gpio_scan_real_time_value
 * Purpose      :   polling thread should call this func periodly to get real time value from gpio chip
 * Input        :      
 * Output       :   
 * Return       :   
 * Note         :   scan all of gpio chip
 *****************************************************************************/
void
gpio_scan_real_time_value()
{
    uint8 i, j;
    uint8 value;
    
    for(i=0; i<g_gpio_chip_num; i++)
    {
        for(j=0; j<PCA9505_BANK_NUM; j++)
        {
            /*need scan this bank*/
            if(g_gpio_hdl[i].scan_group_bitmap & (1<<j))
            {
                if(RESULT_OK == gpio_reg_read(i, PCA9505_INPUT_PORT_REG_BANK0+j, &value, 1))
                {
                    g_gpio_hdl[i].scan_value[j] = value;
                }
            }
            else
            {
                g_gpio_hdl[i].scan_value[j] = 0;
            }
        }
    }    
}


/*********************************************************************
 * Name    : gpio_init
 * Purpose : init some data structure and register gpio dev
 * Input   : i2c_gen_t *i2c_gen     - some info about the way of gpio'i2c bus implement
             uint32 num             - the number of gpio device
 * Output  : N/A
 * Return  : RESULT_OK   = SUCCESS
             other       = ErrCode
 * Note    : N/A
*********************************************************************/
int32
gpio_init(void** p_data, gpio_chip_t* type, uint32 num)
{
    int32 i = 0;

    DRV_CTC_CHK_PTR(p_data);  
    DRV_CTC_CHK_PTR(type);
    
    g_gpio_hdl = (gpio_handle_t* )DRV_CALLOC(CTCLIB_MEM_DRIVER_GPIO_INFO, sizeof(gpio_handle_t)*num);
    if(NULL == g_gpio_hdl)
    {
        DRV_LOG_ERR("Gpio alloc handler fail!\n");
        return RESULT_ERROR;
    }

    /* register gpio dev */
    for (i = 0; i < num; i++)
    {      
        g_gpio_hdl[i].io_hdl = gpio_io_register(type[i].io_type, p_data[i]);
        g_gpio_hdl[i].scan_group_bitmap = type[i].scan_group_bitmap;
        switch(type[i].chip_type)
        {
            case GPIO_PCA9505:
            case GPIO_PCA9506:
                _gpio_pca9505_register_driver(&g_gpio_hdl[i]);
                break;
            default:
                DRV_LOG_ERR("Unsupport gpio chip type %d!\n", type[i].chip_type);
                return RESULT_ERROR;
        }
    }

    g_gpio_chip_num = num;
    return RESULT_OK;
}

/*****************************************************************************
 * Name         :   gpio_diagnostic_test
 * Purpose      :   gpio device diagnostic test 
 * Input        :   chip_num  
 * Return       :   
 * Note         :
 *****************************************************************************/
#ifdef BOOTUP_DIAG
int32 
gpio_diagnostic_test(uint8 reg, gpio_diag_result_t *diag_result, uint8 *chip_num)
{
    uint8 value, org_val, test_val = 0x5a;
    uint8 chip_id;
    uint8 ret1 = RESULT_OK, ret2 = RESULT_OK;

    DRV_CTC_CHK_PTR(diag_result);
    DRV_CTC_CHK_PTR(chip_num);

    *chip_num = g_gpio_chip_num;
    
    for(chip_id = 0; chip_id < g_gpio_chip_num; chip_id++)
    {
        /*1. read original value */
        ret1 = gpio_reg_read(chip_id, reg, &org_val, 1);
        if(ret1)
        {
            DRV_LOG_ERR("Gpio diag read original value fail!\n");
            diag_result[chip_id].rd_fail = 1;
            ret2 = RESULT_ERROR;
        }
        /*2. write test value */
        ret1 = gpio_reg_write(chip_id, reg, &test_val, 1);
        if(ret1)
        {
            DRV_LOG_ERR("Gpio diag write test value fail!\n");
            diag_result[chip_id].wr_fail = 1;
            ret2 = RESULT_ERROR;
        }
        /*3. read test value */
        ret1 = gpio_reg_read(chip_id, reg, &value, 1);
        if(ret1)
        {
            DRV_LOG_ERR("Gpio diag read test value fail!\n");
            diag_result[chip_id].rd_fail = 1;
            ret2 = RESULT_ERROR;
        }
        /*4. compare write value with read value */
        if(test_val != value)
        {
            DRV_LOG_ERR("Gpio diag cmp fail!\n");
            diag_result[chip_id].cmp_fail = 1;
            ret2 = RESULT_ERROR;
        }
        /*5. write original value */
        ret1 = gpio_reg_write(chip_id, reg, &org_val, 1);
        if(ret1)
        {
            DRV_LOG_ERR("Gpio diag write original value fail!\n");
            diag_result[chip_id].wr_fail = 1;
            ret2 = RESULT_ERROR;
        }
    }    
    return ret2;
}

#endif

