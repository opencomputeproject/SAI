/****************************************************************************
* $Id$
*  The header file of the l2 switch api.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2010-08-17 
* Reason        : First Create.
****************************************************************************/
#ifndef __L2SWITCH_API_H__
#define __L2SWITCH_API_H__

#include "l2switch_drv.h"
#include "ctc_spi.h"

#define MAX_L2SWITCH_PORT			24

#define PTR_NULL_CHECK(ptr) (NULL == (ptr))


#define API_L2SWITCH_OPT_PTR_CHECK(chip_dev, opt) \
do { \
    if ((PTR_NULL_CHECK(chip_dev)) \
        ||(PTR_NULL_CHECK(chip_dev->l2switch_info)) \
        ||(PTR_NULL_CHECK(chip_dev->opt)))   \
    {\
        return(-1); \
} }while(0)

int32 l2switch_port_get_stats(uint8 l2switch_id, uint8 port, l2switch_port_stats_t *stats);
int32 l2switch_clear_port_stat(uint8 l2switch_id, uint8 port_id);
int32 l2switch_clear_allport_stat(uint8 l2switch_id);
int32 l2switch_phy_read(uint8 l2switch_id, uint32 local_portid, uint32 address, uint16 *value);
int32 l2switch_phy_write(uint8 l2switch_id, uint32 local_portid, uint32 address, uint16 value);
int32 l2switch_enable_port(uint8 l2switch_id, uint8 port, uint8 enable);
/*regAddr:  bit15-12: block, bit11-8: subblock, bit7-0:regAddr*/
int32 l2switch_register_read(uint8 l2switch_id, uint32 regAddr, uint32* value);
int32 l2switch_register_write(uint8 l2switch_id, uint32 regAddr, uint32 value);
int32 l2switch_init(l2switch_info_t *l2switch_info, uint8 l2switch_nums,l2switch_fixup_t *l2switch_fixup);
int32 dump_l2switch_key_register(uint8 l2switch_id,uint32 local_portid);
int32 l2switch_get_port_num(uint8 l2switch_id);
int32 l2switch_add_static_mac(uint8 l2switch_id, uint8 port_id, uint8 *mac);
#ifdef BOOTUP_DIAG
int32 l2switch_diagnostic_test();
#endif
int32 l2switch_mgt_port_status(uint8 l2switch_id);
int32 l2switch_agg_members_set(uint8 l2switch_id, uint8 agg_id, uint8 members[]);
int32 l2switch_check_work_status(uint8 l2switch_id);
int32 l2switch_re_init(uint8 l2switch_id);


#endif /* __L2SWITCH_API_H__ */
