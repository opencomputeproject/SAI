/****************************************************************************
 * $Id$
 *  L2switch drv
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Jcao
 * Date          : 2010-08-19 
 * Reason        : First Create.
 ****************************************************************************/

#ifndef __L2SWITCH_DRV__
#define __L2SWITCH_DRV__

#include "ctc_spi.h"

#define L2SWITCH_FPGA_SPI_BUSY      0x3000000

#define L2SWITCH_MPC8247_SPI_DO_BIT       0x4000                  /*PD17*/
#define L2SWITCH_MPC8247_SPI_DI_BIT       0x8000                  /*PD16*/
#define L2SWITCH_MPC8247_SPI_CLK_BIT      0x2000                  /*PD18*/
#define L2SWITCH_MPC8247_SPI_CS_BIT       0x80                    /*PD24*/

#define DIAG_L2SWITCH_VLAN_START   100
#define L2SWITCH_DEFAULT_MAX_FRAME_SIZE       1534


#define L2SWITCH_DATA_LENTH 4    /* data length (byte)*/  
#define L2SWITCH_ADDRESS_LENTH 2  /* address length (byte)*/ 

#define L2_SWITCH_VSC7390_PORT_NUM    24
#define L2_SWITCH_VSC7395_PORT_NUM    6
#define L2_SWITCH_VSC7398_PORT_NUM    8
#define L2_SWITCH_VSC74070_PORT_NUM    24

#define CPU_MAC0    0xFE
#define CPU_MAC1    0xFD
#define CPU_MAC2    0x00
#define CPU_MAC3    0x00
#define CPU_MAC4    0x00
#define CPU_MAC5    0x00

#define DIAG_L2SWITCH_PORT_MAX 6
#define DIAG_L2SWITCH_TO_CPU_PORT    1
#define DIAG_L2SWITCH_MIN_DNPORT 2
#define DIAG_L2SWITCH_MAX_DNPORT 8
#define DIAG_L2SWITCH_BAY0_PORT 2
#define DIAG_L2SWITCH_BAY1_PORT 3
#define DIAG_L2SWITCH_IXIA_PORT 4



#define L2SWITCH_DEV_PTR_CHECK(chip_dev) \
do { \
    if ((PTR_NULL_CHECK(chip_dev)) \
        ||(PTR_NULL_CHECK(chip_dev->l2switch_info))\
        ||(PTR_NULL_CHECK(chip_dev->l2switch_info->data))) \
    {\
        return(-1); \
} }while(0)

typedef struct
{
/*RMON counters (RFC 2819)*/    
    /*Rx counters*/    
    uint64 rx_dropped;
    uint64 rx_bytes;
    uint64 rx_packets;
    uint64 rx_brdc_packets;
    uint64 rx_mc_packets;
    uint64 rx_under_size_packets;
    uint64 rx_over_size_packets;
    uint64 rx_fragment_packets;
    uint64 rx_jabber_packets;
    uint64 rx_64_bytes_packets;
    uint64 rx_65_127_bytes_packets;
    uint64 rx_128_255_bytes_packets;
    uint64 rx_256_511_bytes_packets;
    uint64 rx_512_1023_bytes_packets;
    uint64 rx_1024_1518_bytes_packets;
    uint64 rx_1519_max_bytes_packets;
    /*Tx counters*/    
    uint64 tx_dropped;
    uint64 tx_bytes;
    uint64 tx_packets;
    uint64 tx_brdc_packets;
    uint64 tx_mc_packets;
    uint64 tx_collision_packets;
/* Interfaces Group counters (RFC 2863) */         
    uint64 rx_errors;
    uint64 tx_errors;
/* Ethernet-like Interface counters (RFC 3635) */
    /*Rx counters*/
    uint64 rx_alignment_error_packets;
    uint64 rx_fcs_error_packets;
    uint64 rx_frame_too_long_packets;
    uint64 rx_symbol_error_packets;
    uint64 rx_control_unknown_opcode_packets;
    uint64 rx_pause_frame_packets;
    /*Tx counters*/
    uint64 tx_single_collision_packets;
    uint64 tx_multiple_collision_packets;
    uint64 tx_deferred_transmissions_packets; 
    uint64 tx_late_collision_packets;
    uint64 tx_excessive_collision_packets;
    uint64 tx_carrier_sense_error_packets;
    uint64 tx_pause_frame_packets;
    /*others*/
    uint64 tx_no_carrier_packets; /*no carrier from excessive and deferral*/
    uint64 rx_bad_packets; /* from undersize, oversize, jabber*/    
} l2switch_port_stats_t;

typedef enum pal_vlan_frame_t 
{
    VLAN_FRAME_ALL,    /* Accept all frames */
    VLAN_FRAME_TAGGED,  /* Accept tagged frames only */
    VLAN_FRAME_UNTAGGED  /* Accept untagged frames only */
} vlan_frame_t;

struct vlan_mode_s
{
    int32             aware;          
    uint32    pvid; 
    uint32    untagged_vid;
    vlan_frame_t    frame_type;
    int32 ingress_filter;
} ;

typedef struct vlan_mode_s vlan_mode_t;


typedef enum
{
    L2_SWITCH_VSC7390 = 0,
    L2_SWITCH_VSC7398,
    L2_SWITCH_VSC7395, 
    L2_SWITCH_VSC7407//not support currently
} l2switch_type_t;

struct switch_port_vlan_s
{
    int32 chip_port;          /* chip port */
    int32 vlan_enable;        /* vlan enable */
    vlan_mode_t vlan_mode;  /* vlan mode, */
    int32 group_port_no;      /* group_port_no */
    int32 ingress_filter;     /* Ingress filtering */
};
typedef struct switch_port_vlan_s switch_port_vlan_t;


struct l2switch_info_s
{
    int8 port_nums;   /*l2switch port number*/
    l2switch_type_t switch_type; /*l2switch type, such as vsc7407,vsc7390 etc*/
    spi_gen_t spi_info; /*l2switch spi bus infomation*/
    void *data; /*information needed by vtss api*/
} ;

typedef struct l2switch_info_s l2switch_info_t;


typedef struct switch_handle_s switch_handle_t;
struct switch_handle_s
{
    int32 (* switch_init)(switch_handle_t*,spi_handle_t * );
    int32 (* switch_reinit)(switch_handle_t*);
    int32 (* get_counter)(switch_handle_t*, uint8, l2switch_port_stats_t *);
    int32 (* clear_counter)(switch_handle_t*, uint8);
    int32 (* enable_port)(switch_handle_t*, uint8, uint8);
    int32 (* reg_read)(switch_handle_t*, uint32, uint32*);
    int32 (* reg_write)(switch_handle_t*, uint32, uint32);
    int32 (* phy_read)(switch_handle_t*, uint32, uint32, uint16*);
    int32 (* phy_write)(switch_handle_t*, uint32, uint32, uint16);
    int32 (* add_static_mac)(switch_handle_t*, uint8, uint8 *);
    int32 (* mgt_port_status)(switch_handle_t*);
    int32 (* agg_port_members_set)(switch_handle_t*, uint8, uint8*);
    void (*l2switch_fixup)(void);
#ifdef BOOTUP_DIAG    
    int32 (* self_diagnostic)(switch_handle_t*);
#endif
    l2switch_info_t *l2switch_info;
};

typedef void (*l2switch_fixup_t)(void) ;


switch_handle_t *
l2switch_register(l2switch_info_t *l2switch_info, void (*l2switch_fixup)(void));


#endif /* !__L2SWITCH_DRV__ */


