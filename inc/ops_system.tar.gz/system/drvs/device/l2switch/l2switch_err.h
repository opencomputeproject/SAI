/****************************************************************************
 * $Id$
 *  L2switch err
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Jcao
 * Date          : 2010-08-17 
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __L2SWITCH_ERR_H__
#define __L2SWITCH_ERR_H__

enum l2switch_error_e
{
    L2SWITCH_SUCCESS = 0,
    L2SWITCH_E_ERROR = -999,
    L2SWITCH_E_NO_MEMORY,
    L2SWITCH_E_NOT_INIT,
    L2SWITCH_E_INIT_FAILED,
    L2SWITCH_E_TIMEOUT,    
    L2SWITCH_E_READ,    
    L2SWITCH_E_WRITE,
    /* parameter check error */
    L2SWITCH_E_INVALID_PARAM,
    L2SWITCH_E_INVALID_PTR,
    L2SWITCH_E_INVALID_INDEX,    
    L2SWITCH_E_INVALID_LENGTH,
    L2SWITCH_E_INVALID_CHIP,

};

#endif /*!__L2SWITCH_ERR_H__*/
