/****************************************************************************
 * $Id$
 *  l2switch vsc7398 drv
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Jcao
 * Date          : 2010-08-19 
 * Reason        : First Create.
 ****************************************************************************/

#ifndef __L2SWITCH_VSC7398_DRV__
#define __L2SWITCH_VSC7398_DRV__

#define SPARX_G8

#include "vtss_switch_api.h"

struct switch_7398_port_s
{
    switch_port_vlan_t * p_port_vlan;        /* port's vlan info */
    uint8 * p_port_down;                     /* Disable and power down the port */
    vtss_speed_t * p_port_speed;             /*port mac speed */
    vtss_port_interface_t * p_port_intf;     /* port mac interface */
};
typedef struct switch_7398_port_s switch_7398_port_t;


struct vtss7398_switch_data_s
{
    int32 reserved_port_id;  /* the index of the reserved port (counter based on 0) */
    vtss_mapped_port_t *port_map;  /*Port mapping*/
    switch_7398_port_t port;     /* l2switch port information bug25693.*/
    vtss_state_t *vtss_api_state; /* State information handle allocated */
};
typedef struct vtss7398_switch_data_s vtss7398_switch_data_t;

switch_handle_t *register_vsc7398_l2switch_dev(l2switch_info_t *l2switch_info, void (*l2switch_fixup)(void));
#endif /* !__L2SWITCH_VSC7398_DRV__ */
