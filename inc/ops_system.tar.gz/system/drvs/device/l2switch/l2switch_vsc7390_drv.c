/****************************************************************************
 * l2switch_vsc7390.c  
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jqiu
 * Date:         2013-07-27.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#define SPARX_G24
#define VTSS_MEMORYMAPPEDIO

#include "ctc_spi.h"
#include "l2switch_api.h"
#include "l2switch_drv.h"
#include "vtss_switch_api.h"
#include "vtss_phy.h"
//#include "l2-switch-g5.h"
#include "vsc7390.h"
#include "l2switch_vsc7390_drv.h"
#include "drv_debug.h"
#include "l2switch_err.h"



/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

    
/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static vtss_port_status_t g_port_status[VTSS_PORT_NO_END];

/****************************************************************************
 *
* Functions  
*
****************************************************************************/        
#if 1
static int32 _vsc7390_port_with_phy(vtss_mapped_port_t * map, uint32 port_no)
{
    return map[port_no].miim_controller != VTSS_MIIM_CONTROLLER_NONE;
}


BOOL vsc7390_get_port_down(vtss7390_switch_data_t* vtss_data, vtss_port_no_t port_no) 
{
    if (port_no >= VTSS_PORT_NO_END)
    {
        return FALSE;
    }
    
    return vtss_data->port.p_port_down[port_no];
}

vtss_port_interface_t vsc7390_get_port_mac_speed(vtss7390_switch_data_t* vtss_data, vtss_port_no_t port_no) 
{
    vtss_speed_t *p_port_speed = NULL;
    
    p_port_speed = vtss_data->port.p_port_speed;
    if(p_port_speed != NULL)
        return p_port_speed[port_no];
    else
        return VTSS_SPEED_100M;
}

vtss_port_interface_t vsc7390_port_mac_interface(vtss7390_switch_data_t* vtss_data, vtss_port_no_t port_no) 
{
    vtss_port_interface_t *p_port_intf = NULL;

    p_port_intf =vtss_data->port.p_port_intf;
    if(p_port_intf != NULL)
        return p_port_intf[port_no];
    else
        return VTSS_PORT_INTERFACE_NO_CONNECTION;
}

int32
vsc7390_reg_read(switch_handle_t* switch_handle, uint32 reg, uint32 *value)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc7390 register read: reg %x, value pointer %p", 
                                reg, value);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    return vtss7390_register_read(reg, (ulong*)value);
}

int32
vsc7390_reg_write(switch_handle_t* switch_handle, uint32 reg, const uint32 value)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc73905 register write: reg %x, value %x", 
                                reg, value);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    return vtss7390_register_write(reg, value);
}


int32 
vsc7390_allocMem(switch_handle_t* switch_dev,spi_handle_t *spi_phdl)
{
    vtss_state_t *api_state;
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info; 
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_allocMem start!");
    L2SWITCH_DEV_PTR_CHECK(switch_dev);

    p_l2_switch_info = switch_dev->l2switch_info;
    
    /* Allocate API state memory */
    /* modified by kcao for bug 13571, 2010-11-22 : sizeof(vtss_state_info_t) > 128k, not support for DRV_MALLOC */
    if ((api_state = DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, sizeof(vtss_state_t)))==NULL ||
        (api_state->al = sal_malloc(vtss7390_sizeof_al()))==NULL) 
    {
        DRV_LOG_ERR("malloc api_state failed\n");
        return L2SWITCH_E_NO_MEMORY;
    }
    vtss_data = (vtss7390_switch_data_t*)p_l2_switch_info->data;
    vtss_data->vtss_api_state = api_state;

    /* Allocate PHY API state memory */
    if ((api_state->phy = DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, sizeof(vtss_phy_state_t)))==NULL ||
        (((vtss_phy_state_t*)(api_state->phy))->al = 
        DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, vtss7390_phy_sizeof_al(VTSS_PORTS)))==NULL) 
    {
        DRV_LOG_ERR("malloc phy_api_state failed\n");
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO,api_state->al);
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO,api_state);
        return L2SWITCH_E_NO_MEMORY;
    }
 
    api_state->io.spi_handle = (void *)spi_phdl;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_allocMem end!");
    return L2SWITCH_SUCCESS;    
}

int32 
vsc7390_initChip(switch_handle_t* switch_handle)
{
    vtss7390_switch_data_t* vtss_data;    
    l2switch_info_t *p_l2_switch_info;  
    vtss_chipid_t chipid;
    vtss_mapped_port_t *p_map_port = NULL;
    int32 ret;
    vtss_port_no_t    port_no;
    uint32 reg, value;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_initChip start!");
    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t*)p_l2_switch_info->data;

    if ((vtss_data == NULL) || (vtss_data->vtss_api_state == NULL) || 
        (vtss_data->port_map == NULL) || (vtss_data->port.p_port_down == NULL))
    {
        DRV_LOG_ERR("VSC7390 vtss_data null pointer error!\n");
        return L2SWITCH_E_ERROR;
    }    
    
    vtss7390_select_chip(vtss_data->vtss_api_state);
    
    /* Reset chip and use serial interface */    
    vtss_init_setup_t setup;
    setup.reset_chip = 1;
    setup.use_cpu_si = 1;
    vtss7390_init(&setup);
    
    /* Read chip ID */
    if (vtss7390_chipid_get(&chipid)<0) {
        DRV_LOG_ERR("vtss7390 chip id get failed\n");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vtss7390 chip id get failed!");
        VTSS_E(("vtss_chipid_get failed"));
    } else {
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "chip id get success,part_number: 0x%04x, revision: %d\n",
                                                                                 chipid.part_number, chipid.revision);
        VTSS_D(("part_number: 0x%04x, revision: %d",
                chipid.part_number, chipid.revision));
    }

    /*port map set*/
    p_map_port = vtss_data->port_map ;
    
    vtss7390_port_map_set(p_map_port);
    
    /*force speed and duplex for debug */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
    {
        if (_vsc7390_port_with_phy(p_map_port, port_no) ) 
        {
            vtss_phy_reset_setup_t reset;
            vtss_phy_setup_t       setup;
            
            /* 1G port, reset PHY and start auto negotiation */
            reset.mac_if = vsc7390_port_mac_interface(vtss_data, port_no);
            /* Media interface: Copper by default */
            reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;

            vtss7390_phy_reset(port_no, &reset);

            /* Setup PHY for fix speed */
            /*jqiu modify to auto.*/
            setup.mode = VTSS_PHY_MODE_ANEG;
            setup.forced.speed = vsc7390_get_port_mac_speed(vtss_data, port_no);
            setup.forced.fdx = 1;
            setup.aneg.speed_1g_fdx = 1;
            setup.aneg.speed_100m_fdx = 1;
            setup.aneg.speed_100m_hdx = 1;
            ret = vtss7390_phy_setup(port_no, &setup);
            if(ret < 0)
            {
                DRV_LOG_ERR("ERROR vtss_phy_setup\n");
                return ret;
            }
        }
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
    {
        vtss_port_setup_t setup;
        vtss_learn_mode_t learn_mode;

    	learn_mode.automatic = 1;
    	learn_mode.cpu = 0;
    	learn_mode.discard = 0;

        vtss7390_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);

        sal_memset(&setup, 0, sizeof(setup));
        setup.interface_mode.interface_type = vsc7390_port_mac_interface(vtss_data, port_no);
        setup.interface_mode.speed = vsc7390_get_port_mac_speed(vtss_data, port_no);
        setup.powerdown = vsc7390_get_port_down(vtss_data, port_no);
        setup.fdx = 1;
        setup.flowcontrol.obey = 0;
        setup.flowcontrol.generate = 0;
        setup.flowcontrol.smac.addr[5] = port_no;
        setup.maxframelength = VTSS_MAXFRAMELENGTH_MAX;
        setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
        setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
        setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
        setup.port_enable = setup.powerdown ? FALSE : TRUE;
        vtss7390_port_setup(port_no, &setup);
        ret = vtss7390_poag_counters_clear(port_no);
        vtss7390_learn_port_mode_set(port_no, &learn_mode);
        g_port_status[port_no-1].link = 0;
        g_port_status[port_no-1].speed = setup.interface_mode.speed;        
    } /* Port loop */        

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) 
    { 
        if(port_no <= 16) 
        {
            reg =((1&0x7)<<12) | (((port_no-1)&0xf)<<8);
        } 
        else 
        { 
            reg =((6&0x7)<<12) | (((port_no-17)&0xf)<<8);
        }
        /*cfg stats counter CNT_CTRL_CFG*/
        /* TX2:TotalDrop, TX1:Collion, TX0: Pkt, RX2: Fragment, RX1:Undersize, RX0:PKT*/ 
        value = 0x79e04e20; 
        vsc7390_reg_write(switch_handle, reg | 0x5c, value); 
        /*cfg stats counter CNT_CTRL_CFG2*/ 
        /*TX4:ERROR, TX3:Drop, RX4:ERROR, RX3:FCSErr*/ 
        value = 0x004e0050; 
        vsc7390_reg_write(switch_handle, reg | 0x5d, value); 
    } 
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_initChip end!");
    return L2SWITCH_SUCCESS;
}


/*used when system running, could be called many times*/
int32 
vsc7390_runningInit(switch_handle_t* switch_handle)
{
    return vsc7390_initChip(switch_handle);
}

int32 
vsc7390_switch_init(switch_handle_t* switch_handle,spi_handle_t *spi_phdl)
{   
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_switch_init start!");
    vsc7390_allocMem(switch_handle,spi_phdl);
    vsc7390_runningInit(switch_handle);

    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_switch_init fixup start!");
    if(switch_handle->l2switch_fixup != NULL)
    {
       DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_switch_init fixup !");    
       switch_handle->l2switch_fixup(); 
    }
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_switch_init fixup end!");
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7390_switch_init end!");
    return L2SWITCH_SUCCESS;
}

/*Bug29433 work around, resolve l2switch access problem. 2014-09-03*/
int32
vsc7390_switch_reinit(switch_handle_t* switch_handle)
{
    vtss_state_t *api_state;
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info; 
    void* spi_phdl;
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t*)p_l2_switch_info->data;
    api_state = vtss_data->vtss_api_state;
    spi_phdl = api_state->io.spi_handle;
    if(api_state->al != NULL)
    {
        sal_free(api_state->al);
    }
    if(api_state->phy != NULL)
    {
        if(((vtss_phy_state_t*)(api_state->phy))->al != NULL)
        {
            DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, ((vtss_phy_state_t*)(api_state->phy))->al);
        }
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, api_state->phy);
    }
    DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO,api_state);
    vtss_data->vtss_api_state=NULL;
       
    vsc7390_switch_init(switch_handle, spi_phdl);
    return L2SWITCH_SUCCESS;
}

int32
vsc7390_get_counter(switch_handle_t* switch_handle, uint8 chip_port, l2switch_port_stats_t *counter)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    vtss_poag_no_t poag_no;    
    vtss_poag_counters_t big_counters;
    
    L2SWITCH_DEV_PTR_CHECK(switch_handle);

    p_l2_switch_info = switch_handle->l2switch_info;

    poag_no = chip_port ;
    sal_memset(&big_counters,0,sizeof(vtss_poag_counters_t));
    vtss_data = p_l2_switch_info->data;
    vtss7390_select_chip(vtss_data->vtss_api_state);
    vtss7390_poag_counters_get(poag_no, &big_counters);

/*    counter->rx_bytes = big_counters.rmon.rx_etherStatsOctets;
    counter->rx_dropped = big_counters.rmon.rx_etherStatsDropEvents;
    counter->rx_errors = big_counters.if_group.ifInErrors;
    counter->rx_packets = big_counters.rmon.rx_etherStatsPkts;
    counter->tx_bytes = big_counters.rmon.tx_etherStatsOctets;
    counter->tx_dropped = big_counters.rmon.tx_etherStatsDropEvents;
    counter->tx_errors = big_counters.if_group.ifOutErrors;
    counter->tx_packets = big_counters.rmon.tx_etherStatsPkts;*/

    counter->rx_bytes = big_counters.rmon.rx_etherStatsOctets;
    counter->rx_packets = big_counters.rmon.rx_etherStatsPkts;
    counter->rx_under_size_packets = big_counters.rmon.rx_etherStatsBroadcastPkts;
    counter->rx_fragment_packets = big_counters.rmon.rx_etherStatsMulticastPkts;
    counter->rx_fcs_error_packets = big_counters.rmon.rx_etherStatsDropEvents;
    counter->rx_errors = big_counters.if_group.ifInErrors+big_counters.rmon.rx_etherStatsDropEvents;

    counter->tx_dropped = big_counters.rmon.tx_etherStatsDropEvents;
    counter->tx_bytes = big_counters.rmon.tx_etherStatsOctets;
    counter->tx_packets = big_counters.rmon.tx_etherStatsPkts;
    counter->tx_collision_packets = big_counters.rmon.tx_etherStatsBroadcastPkts;
    counter->tx_late_collision_packets = big_counters.rmon.tx_etherStatsDropEvents - big_counters.rmon.tx_etherStatsBroadcastPkts;
    counter->tx_errors = big_counters.if_group.ifOutErrors;
    return L2SWITCH_SUCCESS;
}




int32
vsc7390_clear_counter(switch_handle_t* switch_handle, uint8 chip_port)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    vtss7390_poag_counters_clear(chip_port );
    return L2SWITCH_SUCCESS;
}



int32
vsc7390_enable_port(switch_handle_t* switch_handle, uint8 chip_port, uint8 enable)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    
    /* Modified by kcao 2010-06-18 for bug 11772 : use vtss driver do enable/disable */
    return vtss7390_port_enable(chip_port , enable);
}

int32 
vsc7390_phy_read(switch_handle_t* switch_handle, uint32 port, uint32 reg, uint16* value)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    
    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc7390 phy read: port %d, reg %x, value pointer %p", 
                                port, reg, value);
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    return vtss7390_phy_read(port, reg, value);
}

int32 
vsc7390_add_static_mac(switch_handle_t* switch_handle, uint8 port, uint8 * mac)
{
    uint32 dst_portid;    
    vtss_mac_table_entry_t entry;

    sal_memset(entry.destination, 0, sizeof(entry.destination));
    entry.copy_to_cpu = 0;
    entry.locked = 1;
    entry.aged = 0;    

    dst_portid = port;
    entry.vid_mac.vid = VTSS_VID_DEFAULT;
    entry.vid_mac.mac.addr[0] = mac[0];
    entry.vid_mac.mac.addr[1] = mac[1];
    entry.vid_mac.mac.addr[2] = mac[2];
    entry.vid_mac.mac.addr[3] = mac[3];
    entry.vid_mac.mac.addr[4] = mac[4];
    entry.vid_mac.mac.addr[5] = mac[5];
    entry.destination[dst_portid] = 1;


    vtss7390_mac_table_learn(&entry);
    return 0; 
}


int32 
vsc7390_phy_write(switch_handle_t* switch_handle, uint32 port, uint32 reg, const uint16 value)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc7390 phy write:port %d, reg %x, value %x", 
                                port, reg, value);
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    return vtss7390_phy_write(port, reg, value);
}

/*bug25693 manage l2switch port status change.*/
int32
vsc7390_update_port(vtss7390_switch_data_t* vtss_data, uint8 port_no, vtss_port_status_t* status)
{
    vtss_port_setup_t setup;
    sal_memset(&setup, 0, sizeof(setup));
    setup.interface_mode.interface_type = vsc7390_port_mac_interface(vtss_data, port_no);
    setup.interface_mode.speed = status->speed;
    setup.powerdown = vsc7390_get_port_down(vtss_data, port_no);
    setup.fdx = status->fdx;
    setup.flowcontrol.obey = 0;
    setup.flowcontrol.generate = 0;
    setup.flowcontrol.smac.addr[5] = port_no;
    setup.maxframelength = VTSS_MAXFRAMELENGTH_MAX;
    setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
    setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
    setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
    setup.port_enable = setup.powerdown ? FALSE : TRUE;
    return vtss7390_port_setup(port_no, &setup);
}

int32
vsc7390_mgt_port_status(switch_handle_t* switch_handle)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    uint8 port_no;
    uint32 reg, value, linkup_bitmap=0;
    vtss_port_status_t status;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) 
    { 
        if(port_no >=9 && port_no <=16)
        {
            vtss7390_port_status_get(port_no, &status);
            if(status.link)
            {
                linkup_bitmap |= 1<<(port_no-1);
                /*old status is */
                if(g_port_status[port_no-1].speed != status.speed)
                {
                    vsc7390_update_port(vtss_data, port_no, &status);
                }
            }
            memcpy(&(g_port_status[port_no-1]), &status, sizeof(vtss_port_status_t));            
        }
        else 
        {
            if(port_no <= 16) 
            {
                reg =((1&0x7)<<12) | (((port_no-1)&0xf)<<8);
            } 
            else 
            { 
                reg =((6&0x7)<<12) | (((port_no-17)&0xf)<<8);
            }
            vsc7390_reg_read(switch_handle, reg | 0x1c, &value);

            /*Fix bug 29433. when port doesn't finish auto, triger it by pcs reset. jqiu 2014-07-22*/
            if((value & 0x1c0000)==0x1c0000)
            {
                /*port is up*/
                if((value & 0x1f0000)==0x1f0000)
                {
                    linkup_bitmap |= 1<<(port_no-1);
                }
                else /*Auto-neg not end, need triger it.*/
                {
                    vsc7390_reg_read(switch_handle, reg | 0x0, &value);
                    value |= 0xc;
                    vsc7390_reg_write(switch_handle, reg | 0x0, value);
                    usleep(10);
                    value &= 0xfffffff3;
                    vsc7390_reg_write(switch_handle, reg | 0x0, value);
                }
            }        
        }
    }    
    /*read port mask for flooding of frames with unknown unicast DMAC */
    vsc7390_reg_read(switch_handle, 2<<12 | 0xe, &value);
    
    if(value != linkup_bitmap)
    {
        vsc7390_reg_write(switch_handle, 2<<12 | 0x4, linkup_bitmap);
        vsc7390_reg_write(switch_handle, 2<<12 | 0xe, linkup_bitmap);
        vsc7390_reg_write(switch_handle, 2<<12 | 0xf, linkup_bitmap);
    }
    return 0;
}

int32
vsc7390_agg_port_members_set(switch_handle_t * switch_handle, uint8 agg_id, uint8 member[])
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    vtss_aggr_mode_t mode;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);

    mode.dmac_enable = 1;
    mode.smac_enable = 1;
    vtss7390_aggr_mode_set(&mode);
    vtss7390_aggr_port_members_set(agg_id, member);
    return 0;
}

#ifdef BOOTUP_DIAG
/*result: bit[30:30] 0-pass,1-fail; bit[29:28] chip id; bit[27:0] error port; */
int32 
vsc7390_self_diagnostic(switch_handle_t * switch_handle)
{
    vtss7390_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    vtss_chipid_t chipid;
    vtss_rc ret;
    int32 result=0;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7390_switch_data_t* )(p_l2_switch_info->data);
    vtss7390_select_chip(vtss_data->vtss_api_state);
    ret = vtss7390_chipid_get(&chipid);
    if(ret != VTSS_OK)
        result = (1<<30);
    return result;
}
#endif

#else
int32 
vsc7390_switch_init(switch_handle_t* switch_handle,spi_handle_t *spi_phdl)
{   
    return L2SWITCH_SUCCESS;
}


int32
vsc7390_get_counter(switch_handle_t* switch_handle, uint8 chip_port, l2switch_port_stats_t *counter)
{
    return L2SWITCH_SUCCESS;
}




int32
vsc7390_clear_counter(switch_handle_t* switch_handle, uint8 chip_port)
{
    return L2SWITCH_SUCCESS;
}



int32
vsc7390_enable_port(switch_handle_t* switch_handle, uint8 chip_port, uint8 enable)
{
    return L2SWITCH_SUCCESS;
}




int32
vsc7390_reg_read(switch_handle_t* switch_handle, uint32 reg, uint32 *value)
{

    return L2SWITCH_SUCCESS;
}



int32
vsc7390_reg_write(switch_handle_t* switch_handle, uint32 reg, const uint32 value)
{
    return L2SWITCH_SUCCESS;
}




int32 
vsc7390_phy_read(switch_handle_t* switch_handle, uint32 port, uint32 reg, uint16* value)
{
    return L2SWITCH_SUCCESS;
}

int32 
vsc7390_add_static_mac(switch_handle_t* switch_handle, uint8 port, uint8 * mac)
{
    return 0; 
}


int32 
vsc7390_phy_write(switch_handle_t* switch_handle, uint32 port, uint32 reg, const uint16 value)
{

    return L2SWITCH_SUCCESS;
}

#ifdef BOOTUP_DIAG
/*result: bit[30:30] 0-pass,1-fail; bit[29:28] chip id; bit[27:0] error port; */
int32 
vsc7390_self_diagnostic(switch_handle_t * switch_handle)
{
    return L2SWITCH_SUCCESS;
}
#endif

#endif
/****************************************************************************
 * Name	: register_vsc7390_l2switch_dev
 * Purpose: register VSC7390 l2switch device handler
 * Input	:  the pointer to l2switch infomation struct
 * Output:  
 * Return:  the handler of the L2switch
 * Note	:
****************************************************************************/	
switch_handle_t *
register_vsc7390_l2switch_dev(l2switch_info_t *l2switch_info, void (*l2switch_fixup)(void))
{
    switch_handle_t *p_switch_hdl;
    l2switch_info_t *p_l2switch_info;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "register_vsc7390_l2switch_dev start!");
    p_switch_hdl = (switch_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, 
                                          sizeof(switch_handle_t));
    if(NULL == p_switch_hdl)
    {
        DRV_LOG_ERR("switch handle malloc fail!\n");
        return NULL;
    }

    p_l2switch_info = (l2switch_info_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, 
                                          sizeof(l2switch_info_t));
    if(NULL == p_l2switch_info)
    {
        DRV_LOG_ERR("l2switch info malloc fail!\n");
        goto err_out1;
    }

    sal_memcpy((uint8 *)p_l2switch_info, (uint8 *)l2switch_info, 
                sizeof(l2switch_info_t));
    
    p_l2switch_info->data = DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, sizeof(vtss7390_switch_data_t));
    if(NULL == p_l2switch_info->data)
    {
        DRV_LOG_ERR("l2switch info data malloc fail!\n");
        goto err_out2;
    }    
    sal_memcpy((uint8_t *)(p_l2switch_info->data), (uint8_t *)(l2switch_info->data), 
                sizeof(vtss7390_switch_data_t));
    p_switch_hdl->l2switch_info = p_l2switch_info;
    p_switch_hdl->switch_init = vsc7390_switch_init;
    p_switch_hdl->switch_reinit = vsc7390_switch_reinit;
    p_switch_hdl->get_counter = vsc7390_get_counter;
    p_switch_hdl->clear_counter = vsc7390_clear_counter;
    p_switch_hdl->enable_port = vsc7390_enable_port;
    p_switch_hdl->reg_read = vsc7390_reg_read;
    p_switch_hdl->reg_write = vsc7390_reg_write;
    p_switch_hdl->phy_read = vsc7390_phy_read;
    p_switch_hdl->phy_write = vsc7390_phy_write;
#ifdef BOOTUP_DIAG    
    p_switch_hdl->self_diagnostic = vsc7390_self_diagnostic;
#endif
    p_switch_hdl->l2switch_fixup = l2switch_fixup;
    p_switch_hdl->add_static_mac = vsc7390_add_static_mac;
    p_switch_hdl->mgt_port_status = vsc7390_mgt_port_status;
    p_switch_hdl->agg_port_members_set = vsc7390_agg_port_members_set; 
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "register_vsc7390_l2switch_dev end!");    
    return p_switch_hdl;
    
err_out2:
    if(NULL != p_l2switch_info)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO , p_l2switch_info);
        p_l2switch_info = NULL;
    }
err_out1:
    if (NULL != p_switch_hdl)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO , p_switch_hdl);
        p_switch_hdl = NULL;
    }

    return NULL;
}


