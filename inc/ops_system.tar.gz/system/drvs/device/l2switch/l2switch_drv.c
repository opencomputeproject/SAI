/****************************************************************************
 * l2switch_drv.c    l2 switch dev register 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2010-08-17.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "ctc_spi.h"
#include "l2switch_drv.h"
#include "l2switch_vsc7398_drv.h"
#include "l2switch_vsc7390_drv.h"
#include "l2switch_vsc7395_drv.h"
//#include "l2switch_vsc7407_drv.h"

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
    
/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/

/****************************************************************************
 *
* Functions  
*
****************************************************************************/

/****************************************************************************
 * Name	: l2switch_register
 * Purpose: register  l2switch device handler
 * Input:  l2switch_info_t * l2switch_info             the pointer to l2switch infomation struct
         void (*l2switch_fixup)(void)                  the pointer to user fixup function
 * Output: N/A 
 * Return:  the handler of the L2switch
 * Note	: N/A
****************************************************************************/	        
switch_handle_t *
l2switch_register(l2switch_info_t *l2switch_info, void (*l2switch_fixup)(void))
{    
    if (NULL == l2switch_info)
    {
        return NULL;
    }
    
    switch (l2switch_info->switch_type)
    {
        case L2_SWITCH_VSC7398:
            return register_vsc7398_l2switch_dev(l2switch_info, l2switch_fixup);
        case L2_SWITCH_VSC7390:
            return register_vsc7390_l2switch_dev(l2switch_info, l2switch_fixup);
        case L2_SWITCH_VSC7395:
            return register_vsc7395_l2switch_dev(l2switch_info, l2switch_fixup);    
//		case L2_SWITCH_VSC7407:
//			return register_vsc7407_l2switch_dev(l2switch_info, l2switch_fixup);	
        default:
            break;        
    }
    
    return NULL;
}


