/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_switch_api.h,v 1.151 2007/10/18 09:42:56 cpj Exp $
 $Revision: 1.151 $

*/

#ifndef _VTSS_AL_H_
#define _VTSS_AL_H_

#ifndef VTSS_API
#define VTSS_API 1
#endif

#include "vtss_os.h"

//#ifndef SPARX_G5
//#define SPARX_G5
//#endif
//#ifndef SPARX_G8
//#define SPARX_G8
//#endif

/* ================================================================= *
 *  Features
 * ================================================================= */

/* SparX-G8, SparX-G8e, SparX-G5, SparX-G5e and SparX-G5m features,
   the 'e' and 'm' revisions are detected runtime */
#if defined(SPARX_G5) || defined(SPARX_G8)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#define VTSS_ARCH_SPARX                     /* SparX chip architecture */
#define VTSS_ARCH_SPARX_G8                  /* SparX-G8 chip architecture */
#define VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#define VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#define VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#undef  VTSS_FEATURE_TBI                    /* TBI */
#undef  VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#undef  VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#undef  VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#undef  VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#undef  VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#undef  VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#if defined(SPARX_G5)
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#define VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#else
#undef  VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#endif /* SPARX_G5 */
#undef  VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#undef  VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_L4_SWITCH          /* QoS: Layer 4 per switch */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#undef  VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#undef  VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#undef  VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#undef  VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#define VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#undef  VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#define VTSS_FEATURE_CPU_RX_REG_GARP_ADV    /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#if defined(SPARX_G5)
#define VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#define VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#else
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#endif /* SPARX_G5 */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#define VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#define VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode (actually only the 'e') */
#undef  VTSS_FEATURE_LEARN_PORT             /* Learning per port */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#define VTSS_FEATURE_LEARN_SWITCH
#endif /* SPARX_G5/SPARX_G8 */

/* SparX-G16 and SparX-G24 features */
#if defined(SPARX_G16) || defined(SPARX_G24)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#define VTSS_ARCH_SPARX                     /* SparX chip architecture */
#define VTSS_ARCH_SPARX_G24                 /* SparX-G24 chip architecture */
#define VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#define VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#define VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#undef  VTSS_FEATURE_TBI                    /* TBI */
#define VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#define VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#undef  VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#undef  VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#undef  VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#define VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#undef  VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#undef  VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_L4_SWITCH          /* QoS: Layer 4 per switch */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#undef  VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#undef  VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#define VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#define VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#define VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#define VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#undef  VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#define VTSS_FEATURE_CPU_RX_REG_GARP_ADV    /* CPU redirect of each of 16 GARP addresses */
#define VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#define VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#undef  VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode */
#define VTSS_FEATURE_LEARN_PORT             /* Learning per port */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#endif /* SPARX_G16/SPARX_G24 */

/* SparX-28 features */
#if defined(SPARX_II_16) || defined(SPARX_II_24) || defined(E_STAX_26) || defined(E_STAX_34) || defined(G_ROCX)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#define VTSS_ARCH_SPARX                     /* SparX chip architecture */
#define VTSS_ARCH_SPARX_28                  /* SparX-28 chip architecture */
#if defined(G_ROCX)
#undef  VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#undef  VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#undef  VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_TBI                    /* TBI */
#undef  VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#else
#define VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#define VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#define VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#define VTSS_FEATURE_TBI                    /* TBI */
#define VTSS_FEATURE_SGMII                  /* SGMII */
#define VTSS_FEATURE_SERDES                 /* SERDES */
#define VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#define VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#endif /* G_ROCX */
#define VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#if defined(E_STAX_26) || defined(E_STAX_34)
#define VTSS_FEATURE_VAUI                   /* VAUI */
#else
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#endif /* E_STAX_26/E_STAX_34 */
#define VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#define VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#define VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#define VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#define VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#define VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#define VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_L4_SWITCH          /* QoS: Layer 4 per switch */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#undef  VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#define VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#undef  VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#define VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#define VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#define VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#define VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#define VTSS_FEATURE_ACL                    /* Access Control Lists */
#undef  VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#define VTSS_FEATURE_CPU_RX_REG_GARP_ADV    /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#define VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#define VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#define VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#define VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode */
#define VTSS_FEATURE_LEARN_PORT             /* Learning per port */
#define VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#endif /* SPARX_II_16/SPARX_II_24/E_STAX_26/E_STAX_34/G_ROCX */

/* Elstree/Stansted features */
#if defined(ELSTREE) || defined(STANSTED)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#define VTSS_ARCH_STANSTED                  /* Stansted chip architecture */
#define VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#define VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#define VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#undef  VTSS_FEATURE_TBI                    /* TBI */
#undef  VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#define VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#undef  VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#undef  VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#define VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#define VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#undef  VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#define VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#define VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#undef  VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#undef  VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_GARP_ADV    /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#undef  VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#undef  VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode */
#define VTSS_FEATURE_LEARN_SWITCH           /* Learning per switch */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#endif /* ELSTREE/STANSTED */

/* Heathrow-II features */
#if defined(HEATHROW2)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#undef  VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#undef  VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#undef  VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#define VTSS_FEATURE_TBI                    /* TBI */
#undef  VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#undef  VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#undef  VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#undef  VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#define VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#define VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#undef  VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#undef  VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#undef  VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#undef  VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#undef  VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#undef  VTSS_FEATURE_GARP_REDIR_ADV         /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#undef  VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#undef  VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#undef  VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode */
#undef  VTSS_FEATURE_LEARN_SWITCH           /* Learning per switch */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#endif /* HEATHROW2 */

/* Heathrow-3 and Stapleford features */
#if defined(HEATHROW3) || defined(STAPLEFORD)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#define VTSS_ARCH_STAPLEFORD                /* Stapleford chip architecture */
#define VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#define VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#define VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#define VTSS_FEATURE_TBI                    /* TBI */
#undef  VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#undef  VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#undef  VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#undef  VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#define VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#define VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#undef  VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#define VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#define VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#undef  VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#undef  VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#undef  VTSS_FEATURE_GARP_REDIR_ADV         /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#undef  VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#undef  VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode */
#undef  VTSS_FEATURE_LEARN_SWITCH           /* Learning per switch */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#endif /* HEATHROW3/STAPLEFORD */

#if defined(HAWX_G16) || defined(HAWX_G24) || defined(HAWX_G26)
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_ARCH_HEATHROW                  /* Heathrow chip architecture */
#define VTSS_ARCH_HAWX                      /* HawX chip architecture */
#define VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#define VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#define VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#define VTSS_FEATURE_TBI                    /* TBI (for SERDES interface) */
#define VTSS_FEATURE_SGMII                  /* SGMII */
#define VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#define VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#undef  VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#define VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#define VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#undef  VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#define VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#define VTSS_FEATURE_QOS_L4_PORT            /* QoS: Layer 4 per port */
#undef  VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#define VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#define VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#define VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#define VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#define VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#define VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#undef  VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#define VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE /* QoS: Policer with CIR & PIR per queue */
#define VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#define VTSS_FEATURE_CPU_RX_REG_GARP_ADV    /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#define VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#define VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#define VTSS_FEATURE_AGGR_MODE_RANDOM       /* HawX-B: Random aggregation mode */
#define VTSS_FEATURE_LEARN_PORT             /* HawX-B: Learning per port */
#define VTSS_FEATURE_LEARN_SWITCH           /* HawX-A: Learning per switch */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#endif /* HAWX_G16/HAWX_G24/HAWX_G26 */

/* GATWICK/FAIROAKS features */
#if defined(GATWICK) || defined(GATWICK48) || defined(FAIROAKS) || defined(FAIROAKS48)
#define VTSS_ARCH_GATWICK                   /* Gatwick chip architecture */
#undef  VTSS_FEATURE_PI_WIDTH               /* PI data width configurable */
#undef  VTSS_FEATURE_PI_TIMING_CS           /* PI CS wait timing configurable */
#undef  VTSS_FEATURE_PI_SLOWMODE            /* PI slow register access mode configurable */
#undef  VTSS_FEATURE_SERIAL_LED             /* Serial LED */
#if defined(GATWICK48) || defined(FAIROAKS48)
#define VTSS_CHIPS 2                        /* Multiple internal chips */
#undef  VTSS_FEATURE_10G                    /* 10G ports */
#else
#undef  VTSS_CHIPS                          /* Multiple internal chips */
#define VTSS_FEATURE_10G                    /* 10G ports */
#endif /* GATWICK/GATWICK48 */
#define VTSS_FEATURE_TBI                    /* TBI */
#undef  VTSS_FEATURE_SGMII                  /* SGMII */
#undef  VTSS_FEATURE_SERDES                 /* SERDES */
#undef  VTSS_FEATURE_VAUI                   /* VAUI */
#undef  VTSS_FEATURE_VSTAX                  /* VStaX stacking */
#undef  VTSS_FEATURE_EXC_COL_CONT           /* Excessive collision continuation */
#undef  VTSS_FEATURE_AGGR_GLAG              /* Global link aggregations across stack */
#define VTSS_FEATURE_PORT_CNT_PKT_CAST      /* Has separate counters for unicast/multicast */
#define VTSS_FEATURE_PORT_CNT_ETHER_LIKE    /* Ethernet-like counters */
#define VTSS_FEATURE_PORT_CNT_PAUSE         /* Pause counters */
#define VTSS_FEATURE_PORT_CNT_RMON_ADV      /* Advanced RMON counters */
#define VTSS_FEATURE_PORT_CNT_JUMBO         /* Jumbo frame (>1518) counters */
#undef  VTSS_FEATURE_PORT_CNT_QOS           /* QoS counters */
#undef  VTSS_FEATURE_PORT_CNT_BRIDGE        /* Bridge counters */
#undef  VTSS_FEATURE_QOS_WFQ_PORT           /* QoS: Weighted Fairness Queueing per port */
#undef  VTSS_FEATURE_QOS_WFQ_SWITCH         /* QoS: Weighted Fairness Queueing per switch */
#define VTSS_FEATURE_QOS_ETYPE_PORT         /* QoS: Ethernet Type per port */
#undef  VTSS_FEATURE_QOS_IP_TOS_PORT        /* QoS: Use 3 MSBit from TOS field per port */
#define VTSS_FEATURE_QOS_IP_PROTO_PORT      /* QoS: IP protocol per port */
#define VTSS_FEATURE_QOS_L4_SWITCH          /* QoS: Layer 4 per switch */
#define VTSS_FEATURE_QOS_MPLS_PORT          /* QoS: MPLS per port */
#undef  VTSS_FEATURE_QOS_DSAP_PORT          /* QoS: DSAP per port */
#undef  VTSS_FEATURE_QCL_PORT               /* QoS: QCLs per port */
#define VTSS_FEATURE_QOS_SHAPER_PORT        /* QoS: Shaper per port */
#define VTSS_FEATURE_QOS_SHAPER_QUEUE       /* QoS: Shaper per queue */
#define VTSS_FEATURE_QOS_POLICER_PORT       /* QoS: Policer per port */
#define VTSS_FEATURE_QOS_POLICER_MC_PORT    /* QoS: Multicast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_BC_PORT    /* QoS: Broadcast policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CIR_PORT   /* QoS: CIR policer per port */
#undef  VTSS_FEATURE_QOS_POLICER_CPU_SWITCH /* QoS: CPU policers per switch */
#undef  VTSS_FEATURE_QOS_POLICER_UC_SWITCH  /* QoS: Unicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_MC_SWITCH  /* QoS: Multicast policer per switch */
#undef  VTSS_FEATURE_QOS_POLICER_BC_SWITCH  /* QoS: Broadcast policer per switch */
#undef  VTSS_FEATURE_FILTER_SIP             /* SIP filters */
#undef  VTSS_FEATURE_FILTER_UDP_TCP         /* UDP/TCP filters */
#undef  VTSS_FEATURE_ACL                    /* Access Control Lists */
#define VTSS_FEATURE_CPU_RX_REG_BPDU_ADV    /* CPU redirect of each of 16 BPDU addresses */
#define VTSS_FEATURE_CPU_RX_REG_ARP_ADV     /* Advanced CPU copy of ARP messages */
#define VTSS_FEATURE_CPU_RX_REG_GARP_ADV    /* CPU redirect of each of 16 GARP addresses */
#undef  VTSS_FEATURE_CPU_RX_REG_IP_ADV      /* Advanced CPU copy of IP broadcast messages */
#undef  VTSS_FEATURE_CPU_RX_REG_MLD_ADV     /* Advanced CPU copy of IPv6 MLD messages */
#undef  VTSS_FEATURE_MAC_AGE_AUTO           /* Automatic MAC address ageing */
#define VTSS_FEATURE_VLAN_INGR_FILTER_PORT  /* VLAN: Ingr. filter per port */
#define VTSS_FEATURE_AGGR_MODE_ADV          /* Advanced aggregation mode */
#undef  VTSS_FEATURE_AGGR_MODE_RANDOM       /* Random aggregation mode */
#define VTSS_FEATURE_LEARN_SWITCH           /* Learning per switch */
#define VTSS_FEATURE_JUMBO_FRAME_PORT       /* Jumbo frames per port */
#undef  VTSS_FEATURE_ISOLATED_PORT          /* PVLAN port isolation */
#if defined(GATWICK) || defined(GATWICK48)
#define VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#else
#undef  VTSS_FEATURE_LAYER3                 /* Layer 3 (IPv4) */
#endif /* GATWICK/GATWICK48 */
#endif /* GATWICK/GATWICK48/FAIROAKS/FAIROAKS48 */

#if !defined(VTSS_ARCH_HEATHROW) && !defined(VTSS_ARCH_GATWICK)
#error Target SPARX_G5, SPARX_G8, SPARX_G16, SPARX_G24, SPARX_II_16, SPARX_II_24, E_STAX_26, E_STAX_34, G_ROCX, ELSTREE, STANSTED, HEATHROW2, HEATHROW3, STAPLEFORD, HAWX_G16, HAWX_G24, HAWX_G26, FAIROAKS, FAIROAKS48, GATWICK or GATWICK48 must be defined.
#endif /* !VTSS_ARCH_HEATHROW/GATWICK */

#include "vtss_options.h"
#include "vtss_os.h"
#include "vtss_types.h"

/* ================================================================= *
 *  General definitions, macros, types, variables and functions
 * ================================================================= */

/* - VLAN and 802.1Q Tag ------------------------------------------- */

/* VLAN Identifier */
typedef uint vtss_vid_t; /* 0-4095 */

#define VTSS_VID_NULL     ((const vtss_vid_t)0)     /* NULL VLAN ID */
#define VTSS_VID_DEFAULT  ((const vtss_vid_t)1)     /* Default VLAN ID */
#define VTSS_VID_RESERVED ((const vtss_vid_t)0xFFF) /* Reserved VLAN ID */
#define VTSS_VIDS         ((const vtss_vid_t)4096)  /* Number of VLAN IDs */
/* For use in vtss_vlan_port_mode_t.untagged_vid field only: */
#define VTSS_VID_ALL      ((const vtss_vid_t)0x1000)/* All VLAN IDs */

/* Tag Priority */
typedef uint vtss_tagprio_t;   /* 0-7 */

/* Tag Control Information (according to IEEE 802.1Q) */
typedef struct _vtss_tci_t {
    vtss_vid_t     vid;     /* VLAN ID */
    BOOL           cfi;     /* Canonical Format Indicator */
    vtss_tagprio_t tagprio; /* Tag priority */
} vtss_tci_t;

/* MAC Address */
typedef struct _vtss_mac_t {
    uchar addr[6]; /* Network byte order */
} vtss_mac_t;

/* For easy setup of structures */
#define VTSS_MAC_NULL {{0,0,0,0,0,0}}

/* MAC Address in specific VLAN */
typedef struct _vtss_vid_mac_t {
    vtss_vid_t  vid; /* VLAN ID */
    vtss_mac_t  mac; /* MAC address */
} vtss_vid_mac_t;

/* For easy setup of structures */
#define VTSS_VID_MAC_NULL {VTSS_VID_NULL,VTSS_MAC_NULL}

/* Ethernet Type */
typedef ushort vtss_etype_t; 

/* DSCP */
typedef uchar vtss_dscp_t;

/* IP address/mask */
typedef ulong vtss_ip_t;

/* UDP/TCP port number */
typedef ushort vtss_udp_tcp_t;

/* CPU queue Number */
typedef uint vtss_cpu_rx_queue_t;   /* 1..VTSS_CPU_RX_QUEUES */

/* - Compiler Hints ------------------------------------------------ */

#ifdef __GNUC__
/* "__attribute__ ((const))" informs the GNU C compiler that a
 * function does not change any states anywhere
 */
#define __VTSS_ATTRIB_CONST_FUNCTION__ __attribute__ ((const))
#else
#define __VTSS_ATTRIB_CONST_FUNCTION__ /* no "const" compiler hint */
#endif

/* ================================================================= *
 *  Supplemental
 * ================================================================= */

/******************************************************************************
 * Description: Return text string corresponding to return code.
 *
 * \param rc (input): Return code.
 *
 * \return : Return code text.
 ******************************************************************************/
const char *vtss_error_txt(vtss_rc rc);

#if defined(VTSS_CHIPS)
/* For targets including more than one internal chip.
   Chip number: 0..(VTSS_CHIPS-1). */
typedef uint vtss_chip_no_t;
#define VTSS_CHIP_NO_START   (0)
#define VTSS_CHIP_NO_END     (VTSS_CHIP_NO_START+VTSS_CHIPS)
#endif /* VTSS_CHIPS */


/* - Initialization ------------------------------------------------ */

#include "vtss_io.h"

/* State information handle allocated by application */
typedef struct _vtss_state_t {
#if defined(VTSS_CHIPS)
    vtss_io_state_t io[VTSS_CHIPS];   /* I/O layer state information */
#else
    vtss_io_state_t io;               /* I/O layer state information */
#endif /* VTSS_CHIPS */
    void            *al;              /* Pointer to API state memory, 
                                         size: vtss_sizeof_al() */ 
    void            *phy;             /* Pointer to PHY API state memory */
} vtss_state_t;

/******************************************************************************
 * Description : Get API state information size. 
 *
 * \return : Size of memory for Application Interface Layer state information.
 ******************************************************************************/
uint vtss_sizeof_al(void);


/******************************************************************************
 * Description: Select chip to change the API context.
 *
 * \param state (input): Pointer to memory allocated for API state information.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_select_chip(vtss_state_t * const state);

#if defined(VTSS_FEATURE_LAYER3)
/* IP multicast table size, also affects the ARP table size */
typedef enum _vtss_ipmc_size_t {
    VTSS_IPMC_SIZE_0,    /*    0 IP multicast entries, 8192 ARP entries used */
    VTSS_IPMC_SIZE_6,    /*    6 IP multicast entries, 8184 ARP entries used */
    VTSS_IPMC_SIZE_12,   /*   12 IP multicast entries, 8176 ARP entries used */
    VTSS_IPMC_SIZE_24,   /*   24 IP multicast entries, 8160 ARP entries used */
    VTSS_IPMC_SIZE_48,   /*   48 IP multicast entries, 8128 ARP entries used */
    VTSS_IPMC_SIZE_96,   /*   96 IP multicast entries, 8064 ARP entries used */
    VTSS_IPMC_SIZE_192,  /*  192 IP multicast entries, 7936 ARP entries used */
    VTSS_IPMC_SIZE_384,  /*  384 IP multicast entries, 7680 ARP entries used */
    VTSS_IPMC_SIZE_768,  /*  768 IP multicast entries, 7168 ARP entries used */
    VTSS_IPMC_SIZE_1536, /* 1536 IP multicast entries, 6144 ARP entries used */
    VTSS_IPMC_SIZE_3072, /* 3072 IP multicast entries, 4096 ARP entries used */
    VTSS_IPMC_SIZE_6144  /* 6144 IP multicast entries,    0 ARP entries used */
} vtss_ipmc_size_t;
#endif /* VTSS_FEATURE_LAYER3 */

#if defined(VTSS_FEATURE_PI_WIDTH)    
/* Parallel Interface data width */
typedef enum _vtss_pi_width_t {
    VTSS_PI_WIDTH_16 = 0, /* 16 bit (default) */
    VTSS_PI_WIDTH_8       /* 8 bit */
#if defined(VTSS_ARCH_HAWX)
    ,
    VTSS_PI_WIDTH_32      /* 32 bit */
#endif /* VTSS_ARCH_HAWX */
} vtss_pi_width_t;
#endif /* VTSS_FEATURE_PI_WIDTH */

/* Initialization setup */
typedef struct _vtss_init_setup_t {
    BOOL             reset_chip; /* TRUE if chip must be reset (recommended) */
    BOOL             use_cpu_si; /* TRUE if CPU Serial Interface is used.
                                    FALSE if CPU Parallel Interface is used. */
    BOOL             use_diff_clock; /* TRUE if use differential clock mode*/                                    
#if defined(VTSS_FEATURE_PI_WIDTH)    
    vtss_pi_width_t  pi_width;   /* PI data width */
#endif /* VTSS_FEATURE_PI_WIDTH */
#if defined(VTSS_FEATURE_PI_TIMING_CS)
#define VTSS_PI_CS_WAIT_MAX ((uint)-1)
    uint             pi_cs_wait_ns; /* PI minimum CS wait timing in nanoseconds */
#endif /* VTSS_FEATURE_PI_TIMING_CS */
#if defined(VTSS_FEATURE_PI_SLOWMODE)
    BOOL             pi_use_extended_buscycle; /* PI use extended bus cycle for slow registers */
#endif /* VTSS_FEATURE_PI_SLOWMODE */
#if defined(VTSS_FEATURE_LAYER3)
    vtss_ipmc_size_t ipmc_size;  /* IP multicast/ARP table size allocation */
#endif /* VTSS_FEATURE_LAYER3 */
} vtss_init_setup_t;

/******************************************************************************
 * Description: Initialize chip and API.
 *
 * \param setup (input): Pointer to initialization setup.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_init(const vtss_init_setup_t * const setup);


/* - Chip ID and revision ------------------------------------------ */

/* Chip ID */
typedef struct _vtss_chipid_t {
    ushort  part_number; /* BCD encoded part number */
    uint    revision;    /* Chip revision */
} vtss_chipid_t;

/******************************************************************************
 * Description: Get chip ID and revision.
 *
 * \param chipid (output): Pointer to chip ID structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_chipid_get(vtss_chipid_t * const chipid);


/* - Optimization functions ---------------------------------------- */

/******************************************************************************
 * Description: Optimization function called every second.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_optimize_1sec(void);

/******************************************************************************
 * Description: Optimization function called every 100th millisecond.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_optimize_100msec(void);


/* - GPIOs --------------------------------------------------------- */

/* GPIO number: VTSS_GPIO_NO_START..(VTSS_GPIO_NO_END-1) */
typedef uint vtss_gpio_no_t;

#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
#define VTSS_GPIO_NO_START ((vtss_gpio_no_t)0)
#define VTSS_GPIOS (4)
/* Use IRQ pins as GPO pins */
#define VTSS_GPO_IRQS (2)
#endif /* VTSS_ARCH_SPARX_G8/SPARX_G24 */

#if defined(VTSS_ARCH_SPARX_28) && !defined(G_ROCX)
#define VTSS_GPIO_NO_START ((vtss_gpio_no_t)0)
#define VTSS_GPIOS (16)
#endif /* VTSS_ARCH_SPARX_28 && !G_ROCX */

#if defined(VTSS_ARCH_STANSTED)
#define VTSS_GPIOS (5)
#define VTSS_GPIO_NO_START ((vtss_gpio_no_t)0)
#endif /* VTSS_ARCH_STANSTED */

#if defined(VTSS_ARCH_STAPLEFORD)
#define VTSS_GPIOS (4)
#define VTSS_GPIO_NO_START ((vtss_gpio_no_t)1)
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX)
#define VTSS_GPIOS (8)
#define VTSS_GPIO_NO_START ((vtss_gpio_no_t)0)
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_GPIOS (16)
#define VTSS_GPIO_NO_START ((vtss_gpio_no_t)0)
#endif /* VTSS_ARCH_GATWICK */

#ifndef VTSS_GPO_IRQS
/* Use IRQ pins as GPO pins not supported */
#define VTSS_GPO_IRQS (0)
#endif /* VTSS_GPO_IRQS */

#define VTSS_GPIO_NO_END   (VTSS_GPIO_NO_START+VTSS_GPIOS)
#define VTSS_GPO_IRQ(x)    (VTSS_GPIO_NO_END+(vtss_gpio_no_t)(x))

#if defined(VTSS_GPIOS)
/******************************************************************************
 * Description: Set GPIO direction to input or output.
 *
 * \param chip_no (input): Chip number (for multi chip targets only).
 * \param gpio_no (input): GPIO pin number.
 * \param output (input) : TRUE if output, FALSE if input.
 *
 * \return : Return code.
 ******************************************************************************/
#if defined(VTSS_CHIPS)
vtss_rc vtss_gpio_direction_set(const vtss_chip_no_t chip_no,
                                const vtss_gpio_no_t gpio_no,
                                const BOOL output);
#else
vtss_rc vtss_gpio_direction_set(const vtss_gpio_no_t gpio_no,
                                const BOOL output);
#endif /* VTSS_CHIPS */


/******************************************************************************
 * Description: Read from GPIO input pin.
 *
 * \param chip_no (input): Chip number (for multi chip targets only).
 * \param gpio_no (input): GPIO pin number.
 * \param value (output) : TRUE if pin is high, FALSE if it is low.
 *
 * \return : Return code.
 ******************************************************************************/
#if defined(VTSS_CHIPS)
vtss_rc vtss_gpio_input_read(const vtss_chip_no_t chip_no,
                             const vtss_gpio_no_t gpio_no,
                             BOOL * const value);
#else
vtss_rc vtss_gpio_input_read(const vtss_gpio_no_t gpio_no,
                            BOOL * const value);
#endif /* VTSS_CHIPS */


/******************************************************************************
 * Description: Write to GPIO output pin.
 *
 * \param chip_no (input): Chip number (for multi chip targets only).
 * \param gpio_no (input): GPIO pin number.
 * \param value (input)  : TRUE to set pin high, FALSE to set pin low.
 *
 * \return : Return code.
 ******************************************************************************/
#if defined(VTSS_CHIPS)
/* Write to GPIO output pin */
vtss_rc vtss_gpio_output_write(const vtss_chip_no_t chip_no,
                               const vtss_gpio_no_t gpio_no, 
                               const BOOL value);
#else
vtss_rc vtss_gpio_output_write(const vtss_gpio_no_t gpio_no, 
                               const BOOL value);
#endif /* VTSS_CHIPS */
#endif /* GPIOS */

/* - Serial LED ---------------------------------------------------- */

#if defined(VTSS_FEATURE_SERIAL_LED)

/* LED mode */
typedef enum {
    VTSS_LED_MODE_DISABLED, /* Disabled */
    VTSS_LED_MODE_OFF,      /* Off */
    VTSS_LED_MODE_ON,       /* On */
    VTSS_LED_MODE_2_5,      /* 2.5 Hz */
    VTSS_LED_MODE_5,        /* 5 Hz */
    VTSS_LED_MODE_10,       /* 10 Hz */
    VTSS_LED_MODE_20        /* 20 Hz */
} vtss_led_mode_t;

/* LED port number */
typedef uint vtss_led_port_t;

/******************************************************************************
 * Description: Setup serial LED mode.
 *
 * \param port (input): Serial LED port, 0-29 or 0-15 (G_ROCX).
 * \param mode (input): Serial LED mode for three LEDs.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_serial_led_set(const vtss_led_port_t port, 
                            const vtss_led_mode_t mode[3]);

#endif /* VTSS_FEATURE_SERIAL_LED */

/* - Direct register access (for debugging only) ------------------- */

/******************************************************************************
 * Description: Read value from target register.
 *
 * \param chip_no (input): Chip number (for multi chip targets only).
 * \param reg (input)    : Target ID (bit 8-15) and address (bit 0-7) to read.
 * \param value (output) : Register value.
 *
 * \return : Return code.
 ******************************************************************************/
#if defined(VTSS_CHIPS)
vtss_rc vtss_register_read(const vtss_chip_no_t chip_no,
                           const ulong reg,
                           ulong * const value);
#else
vtss_rc vtss_register_read(const ulong reg, ulong * const value);
#endif /* VTSS_CHIPS */


/******************************************************************************
 * Description: Write value to target register.
 *
 * \param chip_no (input): Chip number (for multi chip targets only).
 * \param reg (input)    : Target ID (bit 8-15) and address (bit 0-7) to read.
 * \param value (input)  : Register value.
 *
 * \return : Return code.
 ******************************************************************************/
#if defined(VTSS_CHIPS)
vtss_rc vtss_register_write(const vtss_chip_no_t chip_no,
                            const ulong reg, 
                            const ulong value);
#else
vtss_rc vtss_register_write(const ulong reg, 
                            const ulong value);
#endif /* VTSS_CHIPS */

/******************************************************************************
 * Description: Read, modify and write value to target register.
 *
 * \param chip_no (input): Chip number (for multi chip targets only).
 * \param reg (input)    : Target ID (bit 8-15) and address (bit 0-7) to read.
 * \param value (input)  : Register value.
 * \param mask (input)   : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
#if defined(VTSS_CHIPS)
vtss_rc vtss_register_writemasked(const vtss_chip_no_t chip_no,
                                  const ulong reg, 
                                  const ulong value, 
                                  const ulong mask);
#else
vtss_rc vtss_register_writemasked(const ulong reg, 
                                  const ulong value, 
                                  const ulong mask);
#endif /* VTSS_CHIPS */

/* ================================================================= *
 *  Port Control
 * ================================================================= */

/* - Port Numbers -------------------------------------------------- */

#if defined(SPARX_G5)
#define VTSS_PORT_COUNT      (6) /* Yes, there are actually 6 ports */
#endif /* SPARX_G5 */

#if defined(SPARX_G8)
#define VTSS_PORT_COUNT      (8)
#endif /* SPARX_G8 */

#if defined(SPARX_G16)
#define VTSS_PORT_COUNT      (16)
#define VTSS_MII_PORT_NO     (24) /* Physical port on chip number */
#endif /* SPARX_G16 */

#if defined(SPARX_G24)
#define VTSS_PORT_COUNT      (24)
#define VTSS_MII_PORT_NO     (24) /* Physical port on chip number */
#endif /* SPARX_G24 */

#if defined(SPARX_II_16)
#define VTSS_PORT_COUNT      (16)
#endif /* SPARX_II_16 */

#if defined(SPARX_II_24)
#define VTSS_PORT_COUNT      (24)
#endif /* SPARX_II_24 */

#if defined(E_STAX_26)
#if VTSS_OPT_INT_AGGR
#define VTSS_PORT_COUNT      (18)  /* 16x1G + 2x5G */
#else
#define VTSS_PORT_COUNT      (20)  /* 16x1G + 4x2.5G */
#endif /* VTSS_OPT_INT_AGGR */
#endif /* E_STAX_26 */

#if defined(E_STAX_34)
#if VTSS_OPT_INT_AGGR
#define VTSS_PORT_COUNT      (26)  /* 24x1G + 2x5G */
#else
#define VTSS_PORT_COUNT      (28)  /* 24x1G + 4x2.5G */
#endif /* VTSS_OPT_INT_AGGR */
#endif /* E_STAX_34 */

#if defined(G_ROCX)
#define VTSS_PORT_COUNT      (7)
#endif /* G_ROCX */

#if defined(ELSTREE)
#define VTSS_PORT_COUNT      (8)
#endif /* ELSTREE */

#if defined(STANSTED)
#define VTSS_PORT_COUNT      (12)
#endif /* STANSTED */

#if defined(HEATHROW2)
#define VTSS_PORT_COUNT      (16)
#endif /* HEATHROW2 */

#if defined(HEATHROW3)
#define VTSS_PORT_COUNT      (16)
#endif /* HEATHROW3 */

#if defined(STAPLEFORD)
#define VTSS_PORT_COUNT      (24)
#endif /* STAPLEFORD */

#if defined(HAWX_G16)
#define VTSS_PORT_COUNT      (16)
#endif /* HAWX_G16 */

#if defined(HAWX_G24)
#define VTSS_PORT_COUNT      (24)
#endif /* HAWX_G24 */

#if defined(HAWX_G26)
#define VTSS_PORT_COUNT      (26)
#endif /* HAWX_G26 */

/* Number of ports and number of 10G ports */
#if defined(GATWICK) || defined(FAIROAKS)
#define VTSS_PORT_COUNT      (24+2)
#define VTSS_PORTS_10G       (2)
#endif /* GATWICK/FAIROAKS */

#if defined(GATWICK48) || defined(FAIROAKS48)
#define VTSS_PORT_COUNT      (48)
#define VTSS_PORTS_10G       (0)
#endif /* GATWICK48/FAIROAKS48 */

/* Number of ports may optionally be less than number of chip ports */
#if VTSS_OPT_PORT_COUNT
#define VTSS_PORTS VTSS_OPT_PORT_COUNT
#else
#define VTSS_PORTS VTSS_PORT_COUNT
#endif /* VTSS_OPT_PORT_COUNT */

/* The first logical port number is 1. */
#define VTSS_PORT_NO_START   ((vtss_port_no_t)1) 
#define VTSS_PORT_NO_END     (VTSS_PORT_NO_START+VTSS_PORTS)
#define VTSS_PORT_ARRAY_SIZE VTSS_PORT_NO_END

#define VTSS_PORT_IS_PORT(x) (x>=VTSS_PORT_NO_START && x<VTSS_PORT_NO_END)

/* Port or Aggregation Number identifying a port or aggregation.
   The same Aggregation Number is shared by all the ports in an aggregation.
   Non-aggregated ports use their port_no. */
typedef vtss_port_no_t vtss_poag_no_t; /* not aggregated: port_no, aggregated: VTSS_AGGR_NO_START..(VTSS_AGGR_NO_END-1) */

/* Number of aggregations and number of ports/aggregations */
#define VTSS_AGGRS           (VTSS_PORTS/2)
#define VTSS_POAGS           (VTSS_PORTS+VTSS_AGGRS)

#define VTSS_AGGR_NO_START   ((vtss_poag_no_t)VTSS_PORT_NO_END)
#define VTSS_AGGR_NO_END     (VTSS_AGGR_NO_START+VTSS_AGGRS)
#define VTSS_POAG_NO_START   VTSS_PORT_NO_START
#define VTSS_POAG_NO_END     VTSS_AGGR_NO_END
#define VTSS_POAG_ARRAY_SIZE VTSS_AGGR_NO_END
#define VTSS_POAG_IS_POAG(x) ((x>=VTSS_POAG_NO_START) && (x<VTSS_POAG_NO_END))

#define VTSS_POAG_IS_PORT(x) (x<VTSS_AGGR_NO_START)
#define VTSS_POAG_IS_AGGR(x) (x>=VTSS_AGGR_NO_START)

#if defined(VTSS_FEATURE_AGGR_GLAG)

/* GLAG number, 1-2 */
typedef uint vtss_glag_no_t;
#define VTSS_GLAG_NO_START 1
#define VTSS_GLAGS         2
#define VTSS_GLAG_NO_END   (VTSS_GLAG_NO_START+VTSS_GLAGS)

/* Maximum 8 ports per GLAG */
#define VTSS_GLAG_PORT_START      1
#define VTSS_GLAG_PORTS           8
#define VTSS_GLAG_PORT_END        (VTSS_GLAG_PORT_START+VTSS_GLAG_PORTS)
#define VTSS_GLAG_PORT_ARRAY_SIZE VTSS_GLAG_PORT_END 

#endif /* VTSS_FEATURE_AGGR_GLAG */

/* MII Management controller */
typedef enum _vtss_miim_controller_t {
#if defined(VTSS_ARCH_GATWICK)
    VTSS_MIIM_CONTROLLER_0    = 0, /* MIIM controller 0, clause 22 only */
    VTSS_MIIM_CONTROLLER_1    = 1, /* MIIM controller 1, clause 22 and 45 */
    VTSS_MIIM_CONTROLLER_2    = 2, /* MIIM controller 2, clause 22 and 45 */
#endif /* VTSS_ARCH_GATWICK */
#if defined(HEATHROW2) || defined(VTSS_ARCH_STAPLEFORD) || defined(VTSS_ARCH_HAWX)
    VTSS_MIIM_CONTROLLER_0    = 0, /* MIIM controller 0, clause 22 only */
    VTSS_MIIM_CONTROLLER_1    = 1, /* MIIM controller 1, clause 22 only */
#endif /* HEATHROW2/VTSS_ARCH_STAPLEFORD/VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_STANSTED)
    VTSS_MIIM_CONTROLLER_0    = 0, /* MIIM controller 0, clause 22 only */
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_SPARX)
    VTSS_MIIM_CONTROLLER_0    = 0, /* MIIM controller 0 (internal), clause 22 only */
    VTSS_MIIM_CONTROLLER_1    = 1, /* MIIM controller 1 (external), clause 22 only */
#endif /* VTSS_ARCH_SPARX */
    VTSS_MIIM_CONTROLLERS,         /* Number of MIIM controllers */
    VTSS_MIIM_CONTROLLER_NONE = -1 /* Unassigned MIIM controller */
} vtss_miim_controller_t;


/* - Port mapping -------------------------------------------------- */

typedef struct _vtss_mapped_port_t {
#if defined(VTSS_CHIPS)
    vtss_chip_no_t         chip_no;         /* Chip number */
#endif /* VTSS_CHIPS */
    int                    chip_port;       /* Set to -1 if not used */
    vtss_miim_controller_t miim_controller; /* MII Management controller */
    int                    phy_addr;        /* PHY address, ignored for 
                                               VTSS_MIIM_CONTROLLER_NONE */
} vtss_mapped_port_t;

/******************************************************************************
 * Description: Setup port mapping.
 *
 * \param mapped_ports (input): Port map array indexed by vtss_port_no_t.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_map_set(
    const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE]);


/* - IEEE 802.3 clause 22 PHY access functions --------------------- */

/******************************************************************************
 * Description: Read value from PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param addr (input)           : PHY address on MIIM bus.
 * \param reg (input)            : PHY register address.
 * \param value (output)         : PHY register value.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_miim_phy_read(
#if defined(VTSS_CHIPS)
                            const vtss_chip_no_t            chip_no,
#endif
                            const vtss_miim_controller_t    miim_controller,
                            const uint                      addr,
                            const uint                      reg,
                            ushort *const                   value );

/******************************************************************************
 * Description: Write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param addr (input)           : PHY address on MIIM bus.
 * \param reg (input)            : PHY register address.
 * \param value (input)          : PHY register value.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_miim_phy_write(
#if defined(VTSS_CHIPS)
                            const vtss_chip_no_t            chip_no,
#endif
                            const vtss_miim_controller_t    miim_controller,
                            const uint                      addr,
                            const uint                      reg,
                            const ushort                    value );

/******************************************************************************
 * Description: Read, modify and write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register address.
 * \param value  (input)         : Register value (16 bit).
 * \param mask (input)           : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_miim_phy_writemasked(
#if defined(VTSS_CHIPS)
                                    const vtss_chip_no_t            chip_no,
#endif
                                    const vtss_miim_controller_t    miim_controller,
                                    const uint                      addr,
                                    const uint                      reg,
                                    const ushort                    value,
                                    const ushort                    mask );

/* Include PHY API functions */
#include "vtss_phy.h"


/******************************************************************************
 * Description: Read value from PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register (page and) address.
 *
 * \return : If negative, a vtss_rc_t error code. Else 16-bit register value.
 ******************************************************************************/
vtss_rc vtss_register_phy_read(
#if defined(VTSS_CHIPS)
                               const vtss_chip_no_t         chip_no,
#endif
                               const vtss_miim_controller_t miim_controller,
                               const uint                   phy_addr,
                               const uint                   phy_reg,
                               ushort *const                value);


/******************************************************************************
 * Description: Write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register (page and) address.
 * \param value  (input)         : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_register_phy_write(
#if defined(VTSS_CHIPS)
                                const vtss_chip_no_t         chip_no,
#endif
                                const vtss_miim_controller_t miim_controller,
                                const uint                   phy_addr,
                                const uint                   phy_reg,
                                const ushort                 value);


/******************************************************************************
 * Description: Read, modify and write value to PHY register.
 *
 * \param chip_no (input)        : Chip number (for multi chip targets only).
 * \param miim_controller (input): MII Management controller.
 * \param phy_addr (input)       : PHY address on MIIM bus.
 * \param phy_reg (input)        : PHY register (page and) address.
 * \param value  (input)         : Register value (16 bit).
 * \param mask (input)           : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_register_phy_writemasked(
#if defined(VTSS_CHIPS)
                                      const vtss_chip_no_t         chip_no,
#endif
                                      const vtss_miim_controller_t miim_controller,
                                      const uint                   phy_addr,
                                      const uint                   phy_reg,
                                      const ushort                 value,
                                      const ushort                 mask);


#if defined(VTSS_FEATURE_10G) || defined(BOARD_JETWAY48)

/******************************************************************************
 * Description: Determine if port is 10G (based on port map).
 *
 * \param port_no (input): Port number.
 *
 * \return : TRUE if 10G port.
 ******************************************************************************/
BOOL vtss_port_no_is_10g(const vtss_port_no_t port_no);


/* MMD definitions, 0 and 6-29 are reserved. */
#define VTSS_MMD_PMA_PMD  1 
#define VTSS_MMD_WIS      2
#define VTSS_MMD_PCS      3
#define VTSS_MMD_PHY_XS   4
#define VTSS_MMD_DTE_XS   5
#define VTSS_MMD_VENDOR_1 30
#define VTSS_MMD_VENDOR_2 31
#endif /* VTSS_FEATURE_10G || BOARD_JETWAY48 */

#if defined(VTSS_FEATURE_10G)
/* - IEEE 802.3 clause 45 PHY access functions --------------------- */

/******************************************************************************
 * Description: Reset MMD 1-5 using Control register (register 1).
 *
 * \param port_no (input): Port number connected to MMD.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_reset(const vtss_port_no_t port_no);


/******************************************************************************
 * Description: Read value from MMD register.
 *
 * \param port_no (input): Port number connected to MMD.
 * \param mmd (input)    : MMD number.
 * \param phy_reg (input): PHY register address.
 * \param value (output) : PHY register value.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_read(const vtss_port_no_t port_no,
                      const uint           mmd,
                      const uint           phy_reg,
                      ushort *const        value);


/******************************************************************************
 * Description: Write value to MMD register.
 *
 * \param port_no (input): Port number connected to MMD.
 * \param mmd (input)    : MMD number.
 * \param phy_reg (input): PHY register address.
 * \param value  (input) : Register value (16 bit).
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_write(const vtss_port_no_t port_no,
                       const uint           mmd,
                       const uint           phy_reg,
                       const ushort         value);


/******************************************************************************
 * Description: Read, modify and Write value to MMD register.
 *
 * \param port_no (input): Port number connected to MMD.
 * \param mmd (input)    : MMD number.
 * \param phy_reg (input): PHY register address.
 * \param value  (input) : Register value (16 bit).
 * \param mask (input)   : Register mask, only bits enabled are changed.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_writemasked(const vtss_port_no_t port_no,
                             const uint           mmd,
                             const uint           phy_reg,
                             const ushort         value,
                             const ushort         mask);


/* MDIO devices present (register mmd.5) */
typedef struct _vtss_mmd_devices_t {
    BOOL dte_xs;  /* mmd.5.5 */
    BOOL phy_xs;  /* mmd.5.4 */
    BOOL pcs;     /* mmd.5.3 */
    BOOL wis;     /* mmd.5.2 */
    BOOL pma_pmd; /* mmd.5.1 */
    BOOL cl_22;   /* mmd.5.0 */
} vtss_mmd_devices_t;

/******************************************************************************
 * Description: Get MMD devices present (register mmd.5).
 *
 * \param port_no (input) : Port number connected to MMD.
 * \param devices (output): Devices present structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_devices_get(const uint         port_no, 
                             const uint         mmd, 
                             vtss_mmd_devices_t *devices);


/* PMA/PMD capability (register 1.1, 1.4 and 1.8) */
typedef struct _vtss_mmd_pma_pmd_capability_t {
    BOOL lowpower;            /* 1.1.1 */
    BOOL ability_10g;         /* 1.4.0 */
    BOOL transmit_fault;      /* 1.8.13 */
    BOOL receive_fault;       /* 1.8.12 */
    BOOL tx_disable;          /* 1.8.8 */
    BOOL ability_10gbase_sr;  /* 1.8.7 */
    BOOL ability_10gbase_lr;  /* 1.8.6 */
    BOOL ability_10gbase_er;  /* 1.8.5 */
    BOOL ability_10gbase_lx4; /* 1.8.4 */
    BOOL ability_10gbase_sw;  /* 1.8.3 */
    BOOL ability_10gbase_lw;  /* 1.8.2 */
    BOOL ability_10gbase_ew;  /* 1.8.1 */
    BOOL loopback;            /* 1.8.0 */
} vtss_mmd_pma_pmd_capability_t;

/******************************************************************************
 * Description: Get PMA/PMD capability (register 1.1, 1.4 and 1.8).
 *
 * \param port_no (input)    : Port number connected to MMD.
 * \param capability (output): Capability structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_pma_pmd_capability_get(
    const uint                    port_no,
    vtss_mmd_pma_pmd_capability_t *capability);


/* PMA/PMD status (register 1.1, 1.6 and 1.10) */
typedef struct _vtss_mmd_pma_pmd_status_t {
    BOOL fault_detected;   /* 1.1.7 */
    BOOL link_up;          /* 1.1.2 */
    BOOL transmit_fault;   /* 1.8.11 */
    BOOL receive_fault;    /* 1.8.10 */
    BOOL receive_signal_3; /* 1.10.4 */
    BOOL receive_signal_2; /* 1.10.3 */
    BOOL receive_signal_1; /* 1.10.2 */
    BOOL receive_signal_0; /* 1.10.1 */
} vtss_mmd_pma_pmd_status_t;

/******************************************************************************
 * Description: Get PMA/PMD status (register 1.1, 1.6 and 1.10).
 *
 * \param port_no (input): Port number connected to MMD.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_pma_pmd_status_get(const uint                port_no,
                                    vtss_mmd_pma_pmd_status_t *status);

/* WIS capability (register 2.1, 2.4 and 2.8) */
typedef struct _vtss_mmd_wis_capability_t {
    BOOL lowpower;          /* 2.1.1 */
    BOOL ability_10g;       /* 2.4.0 */
    BOOL test_pattern;      /* 2.8.1 */
    BOOL ability_10gbase_r; /* 2.8.0 */
} vtss_mmd_wis_capability_t;

/******************************************************************************
 * Description: Get WIS capability (register 2.1, 2.4 and 2.8).
 *
 * \param port_no (input)    : Port number connected to MMD.
 * \param capability (output): Capability structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_wis_capability_get(const uint                port_no, 
                                    vtss_mmd_wis_capability_t *capability);


/* WIS status (register 2.1) */
typedef struct _vtss_mmd_wis_status_t {
    BOOL fault_detected; /* 2.1.7 */
    BOOL link_up;        /* 2.1.2 */
} vtss_mmd_wis_status_t;

/******************************************************************************
 * Description: Get WIS status (register 2.1).
 *
 * \param port_no (input): Port number connected to MMD.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_wis_status_get(const uint            port_no, 
                                vtss_mmd_wis_status_t *status);


/* PCS capability (register 3.1, 3.4, 3.8 and 3.24) */
typedef struct _vtss_mmd_pcs_capability_t {
    BOOL lowpower;          /* 3.1.1 */
    BOOL ability_10g;       /* 3.4.0 */
    BOOL ability_10gbase_w; /* 3.8.2 */
    BOOL ability_10gbase_x; /* 3.8.1 */
    BOOL ability_10gbase_r; /* 3.8.0 */
    BOOL test_pattern;      /* 3.24.11 */
} vtss_mmd_pcs_capability_t;

/******************************************************************************
 * Description: Get PCS capability (register 3.1, 3.4, 3.8 and 3.24).
 *
 * \param port_no (input)    : Port number connected to MMD.
 * \param capability (output): Capability structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_pcs_capability_get(const uint                port_no,
                                    vtss_mmd_pcs_capability_t *capability);


/* PCS status (register 3.1, 3.8, 3.24, 3.32 and 3.33) */
typedef struct _vtss_mmd_pcs_status_t {
    BOOL fault_detected;          /* 3.1.7 */ 
    BOOL link_up;                 /* 3.1.2 */
    BOOL transmit_fault;          /* 3.8.11 */
    BOOL receive_fault;           /* 3.8.10 */
    BOOL lanes_10gbase_x_aligned; /* 3.24.12 */
    BOOL lane_3_sync;             /* 3.24.3 */
    BOOL lane_2_sync;             /* 3.24.2 */
    BOOL lane_1_sync;             /* 3.24.1 */
    BOOL lane_0_sync;             /* 3.24.0 */
    BOOL receive_up_10gbase_r;    /* 3.32.12 */
    BOOL block_lock_10gbase_r;    /* 3.33.15 */
    BOOL high_ber_10gbase_r;      /* 3.33.14 */
    uint ber;                     /* 3.33.8-13 */
    uint errored_blocks;          /* 3.33.0-7 */
} vtss_mmd_pcs_status_t;

/******************************************************************************
 * Description: Get PCS status (register 3.1, 3.8, 3.24, 3.32 and 3.33).
 *
 * \param port_no (input): Port number connected to MMD.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_pcs_status_get(const uint            port_no, 
                                vtss_mmd_pcs_status_t *status);


/* PHY XS capability (register 4.1, 4.4 and 4.24) */
typedef struct _vtss_mmd_phy_xs_capability_t {
    BOOL lowpower;     /* 4.1.1 */
    BOOL ability_10g;  /* 4.4.0 */
    BOOL test_pattern; /* 4.24.11 */
    BOOL loopback;     /* 4.24.10 */
} vtss_mmd_phy_xs_capability_t;

/******************************************************************************
 * Description: Get PHY XS capability (register 4.1, 4.4, and 4.24).
 *
 * \param port_no (input)    : Port number connected to MMD.
 * \param capability (output): Capability structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_phy_xs_capability_get(
    const uint                   port_no, 
    vtss_mmd_phy_xs_capability_t *capability);


/* PHY XS status (register 4.1, 4.8 and 4.24) */
typedef struct _vtss_mmd_phy_xs_status_t {
    BOOL fault_detected;   /* 4.1.7 */
    BOOL link_up;          /* 4.1.2 */
    BOOL transmit_fault;   /* 4.8.11 */
    BOOL receive_fault;    /* 4.8.10 */
    BOOL phy_xgxs_aligned; /* 4.24.12 */
    BOOL lane_3_sync;      /* 4.24.3 */
    BOOL lane_2_sync;      /* 4.24.2 */
    BOOL lane_1_sync;      /* 4.24.1 */
    BOOL lane_0_sync;      /* 4.24.0 */
} vtss_mmd_phy_xs_status_t;

/******************************************************************************
 * Description: Get PHY XS status (register 4.1, 4.8 and 4.24).
 *
 * \param port_no (input): Port number connected to MMD.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_phy_xs_status_get(const uint               port_no,
                                   vtss_mmd_phy_xs_status_t *status);


/* DTE XS capability (register 5.1, 5.4 and 5.24) */
typedef struct _vtss_mmd_dte_xs_capability_t {
    BOOL lowpower;     /* 5.1.1 */
    BOOL ability_10g;  /* 5.4.0 */
    BOOL test_pattern; /* 5.24.11 */
} vtss_mmd_dte_xs_capability_t;

/******************************************************************************
 * Description: Get DTE XS capability (register 5.1, 5.4, and 5.24).
 *
 * \param port_no (input)    : Port number connected to MMD.
 * \param capability (output): Capability structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_dte_xs_capability_get(
    const uint                   port_no, 
    vtss_mmd_dte_xs_capability_t *capability);


/* DTE XS status (register 5.1, 5.8 and 5.24) */
typedef struct _vtss_mmd_dte_xs_status_t {
    BOOL fault_detected;   /* 5.1.7 */
    BOOL link_up;          /* 5.1.2 */
    BOOL transmit_fault;   /* 5.8.11 */
    BOOL receive_fault;    /* 5.8.10 */
    BOOL dte_xgxs_aligned; /* 5.24.12 */
    BOOL lane_3_sync;      /* 5.24.3 */
    BOOL lane_2_sync;      /* 5.24.2 */
    BOOL lane_1_sync;      /* 5.24.1 */
    BOOL lane_0_sync;      /* 5.24.0 */
} vtss_mmd_dte_xs_status_t;

/******************************************************************************
 * Description: Get DTE XS status (register 5.1, 5.8 and 5.24).
 *
 * \param port_no (input): Port number connected to MMD.
 * \param status (output): Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mmd_dte_xs_status_get(const uint               port_no, 
                                   vtss_mmd_dte_xs_status_t *status);
#endif /* VTSS_FEATURE_10G */


/* - TBI Auto-Negotiation and Status ------------------------------- */

#if defined(VTSS_FEATURE_TBI)

/* Advertisement Word (Refer to IEEE 802.3 Clause 37):
 *  MSB                                                                         LSB
 *  D15  D14  D13  D12  D11  D10   D9   D8   D7   D6   D5   D4   D3   D2   D1   D0 
 * +----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
 * | NP | Ack| RF2| RF1|rsvd|rsvd|rsvd| PS2| PS1| HD | FD |rsvd|rsvd|rsvd|rsvd|rsvd|
 * +----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
 */

/* Remote fault type */
typedef enum _vtss_autoneg_1000base_x_remote_fault_t {
                                  /* RF2 */ /* RF1 */
    VTSS_1000BASEX_LINK_OK       = ((0<<1) | (0<<0)),
    VTSS_1000BASEX_OFFLINE       = ((1<<1) | (0<<0)),
    VTSS_1000BASEX_LINK_FAILURE  = ((0<<1) | (1<<0)),
    VTSS_1000BASEX_AUTONEG_ERROR = ((1<<1) | (1<<0))
} vtss_autoneg_1000base_x_remote_fault_t;

/* Advertisement */
typedef struct _vtss_autoneg_1000base_x_advertisement_t {
    BOOL                                   fdx;
    BOOL                                   hdx;
    BOOL                                   symmetric_pause; /* PAUSE (PS1) */
    BOOL                                   asymmetric_pause;/* ASM_DIR (PS2) */
    vtss_autoneg_1000base_x_remote_fault_t remote_fault;
    BOOL                                   acknowledge;
    BOOL                                   next_page;
} vtss_autoneg_1000base_x_advertisement_t;

/* Auto-Negotiation control */
typedef struct _vtss_tbi_autoneg_control_t {
    BOOL                                    enable;
    vtss_autoneg_1000base_x_advertisement_t advertisement;
} vtss_tbi_autoneg_control_t;

/******************************************************************************
 * Description: Get TBI Auto-Negotiation Control word.
 *
 * \param port_no (input) : Port number.
 * \param control (output): Control structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_tbi_autoneg_control_get(
    const vtss_port_no_t               port_no,
    vtss_tbi_autoneg_control_t * const control);


/******************************************************************************
 * Description: Set TBI Auto-Negotiation Control word.
 *
 * \param port_no (input): Port number.
 * \param control (input): Control structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_tbi_autoneg_control_set(
    const vtss_port_no_t                     port_no,
    const vtss_tbi_autoneg_control_t * const control);


/******************************************************************************
 * Description: Restart TBI Auto-Negotiation.
 *
 * \param port_no (input): Port number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_tbi_autoneg_restart(const vtss_port_no_t port_no);


/* TBI Status, current state of the PCS */
typedef enum _vtss_tbi_pcs_state_t {
    VTSS_TBI_PCS_STATE_IDLE,   /* Idle */
    VTSS_TBI_PCS_STATE_CONFIG, /* Config (i.e. ANEG in progress) */
    VTSS_TBI_PCS_STATE_DATA    /* Data */
} vtss_tbi_pcs_state_t;

typedef struct _vtss_tbi_status_t {
    BOOL link_status; /* FALSE if link has been down since last status read */
    uint link_down_counter;  /* Note: Saturates when reaching
                                VTSS_TBI_LINK_DOWN_COUNTER_SATURATED. */
    struct {
        vtss_tbi_pcs_state_t                    pcs_state;
        BOOL                                    priority_resolution;
        BOOL                                    complete;
        vtss_autoneg_1000base_x_advertisement_t partner_advertisement;
    } autoneg;
} vtss_tbi_status_t;

#define VTSS_TBI_LINK_DOWN_COUNTER_SATURATED 255

/******************************************************************************
 * Description: Get TBI status.
 *
 * \param port_no (input): Port number.
 * \param status (input) : Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_tbi_status_get(const vtss_port_no_t      port_no,
                            vtss_tbi_status_t * const status);

#endif /* VTSS_FEATURE_TBI */


/* - Port configuration and reset ---------------------------------- */

/* Interface type and speed */
typedef struct _vtss_port_interface_mode_t {
    vtss_port_interface_t interface_type; 
    vtss_speed_t          speed;
} vtss_port_interface_mode_t;

/* Flow control */
typedef struct _vtss_flowcontrol_setup_t {
    BOOL       obey;     /* TRUE if PAUSE frames should be obeyed */
    BOOL       generate; /* TRUE if PAUSE frames should generated */
    vtss_mac_t smac;     /* Port MAC address used as SMAC in PAUSE frames */
} vtss_flowcontrol_setup_t;

/* Use this value for all frame gaps to get default values */
#define VTSS_FRAME_GAP_DEFAULT 0

/* Inter frame gap structure */
typedef struct _vtss_frame_gaps_t {
#if defined(HEATHROW2)
    uint gap_1;
    uint gap_2;
#else
    uint hdx_gap_1;        /* Half duplex: First part of Rx to Tx gap */
    uint hdx_gap_2;        /* Half duplex: Second part of Rx to Tx gap */
    uint fdx_gap;          /* Full duplex: Tx to Tx gap */
#endif /* HEATHROW2 */
} vtss_frame_gaps_t;

/* A selection of max frame lengths */
#define VTSS_MAXFRAMELENGTH_STANDARD 1518    /* IEEE 802.3 standard */
#define VTSS_MAXFRAMELENGTH_TAGGED   (VTSS_MAXFRAMELENGTH_STANDARD+4)

#if defined(VTSS_ARCH_SPARX)
#define VTSS_MAXFRAMELENGTH_MAX      9600
#endif /* VTSS_ARCH_SPARX */

#if defined(VTSS_ARCH_STANSTED)
#define VTSS_MAXFRAMELENGTH_MAX      9600
#endif /* VTSS_ARCH_STANSTED */

#if defined(HEATHROW2)
#define VTSS_MAXFRAMELENGTH_MAX      1528
#endif

#if defined(VTSS_ARCH_STAPLEFORD)
#define VTSS_MAXFRAMELENGTH_MAX      9216
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX)
#define VTSS_MAXFRAMELENGTH_MAX      9600
#endif

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_MAXFRAMELENGTH_MAX      10240
#endif /* VTSS_ARCH_GATWICK */

/* Port setup, which may change dynamically, e.g. after auto-negotiation */
typedef struct _vtss_port_setup_t {
    vtss_port_interface_mode_t interface_mode; /* Interface type and speed */
    BOOL                       powerdown;      /* Disable and power down the port */
    BOOL                       fdx;            /* TRUE if full duplex */
    vtss_flowcontrol_setup_t   flowcontrol;    /* Flow control setup */
    uint                       maxframelength; /* Maximum frame length */
    vtss_frame_gaps_t          frame_gaps;     /* Not XGMII: Interframe gaps */

#if defined(VTSS_FEATURE_EXC_COL_CONT)
    BOOL                       exc_col_cont;   /* Excessive collision continuation */
#endif /* VTSS_FEATURE_EXC_COL_CONT */

#if defined(HEATHROW2)
    BOOL tbi_swap_rbc;                /* TBI/RTBI: Swap RBC clocks */
#endif
#if defined(VTSS_ARCH_STAPLEFORD) || defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    BOOL tbi_use_signaldetect;        /* TBI/RTBI: Enable Signal Detect */
    BOOL tbi_signaldetect_activehigh; /* TBI/RTBI: Signal detect polarity */
#endif
#if defined(VTSS_FEATURE_SGMII)
    BOOL sgmii_dc_coupled;            /* SGMII: TRUE: DC coupled connection to PHY (Vitesse PHY special mode). FALSE: LVDS AC coupled connection to PHY */
#endif
#if defined(VTSS_FEATURE_SERDES)
    BOOL serdes_low_drive;            /* SERDES: Low Drive mode (FALSE: High Drive mode) */
#endif
#if defined(VTSS_ARCH_GATWICK)
    BOOL xgmii_swap_rx_pins;          /* XGMII: Swap XGMII Rx pins */
    BOOL xgmii_swap_tx_pins;          /* XGMII: Swap XGMII Tx pins */
#endif
    BOOL                      port_enable;
} vtss_port_setup_t;

/******************************************************************************
 * Description: Setup port.
 *
 * \param port_no (input): Port number.
 * \param setup (input)  : Port setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_setup(const vtss_port_no_t            port_no,
                        const vtss_port_setup_t * const setup);

vtss_rc vtss_port_enable(const vtss_port_no_t port_no, const BOOL enable);

/* - Port Link Status ---------------------------------------------- */

/******************************************************************************
 * Description: Get port status.
 *
 * \param port_no (input): Port number.
 * \param setup (output) : Status structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_status_get(const vtss_port_no_t       port_no,
                             vtss_port_status_t * const status);


/* - Number of priorities (for QoS statistics) --------------------- */

#if defined(VTSS_ARCH_SPARX)
#define VTSS_PRIOS  4
#define VTSS_QUEUES 4
#endif /* VTSS_ARCH_SPARX */

#if defined(VTSS_ARCH_STANSTED)
#define VTSS_PRIOS  4
#define VTSS_QUEUES 2
#endif /* VTSS_ARCH_STANSTED */

#if defined(HEATHROW2) || defined(VTSS_ARCH_STAPLEFORD)
#define VTSS_PRIOS  2
#define VTSS_QUEUES 2
#endif /* HEATHROW2/VTSS_ARCH_STAPLEFORD */ 

#if defined(VTSS_ARCH_HAWX)
#define VTSS_PRIOS  8
#define VTSS_QUEUES 4
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_PRIOS  4
#define VTSS_QUEUES 4
#endif /* VTSS_ARCH_GATWICK */

/* - Counters ----------------------------------------------------- */

typedef struct _vtss_poag_counters_t {
    /* RMON counters (RFC 2819) */
    struct {
        /* Rx counters */
        vtss_counter_t rx_etherStatsDropEvents;
        vtss_counter_t rx_etherStatsOctets;
        vtss_counter_t rx_etherStatsPkts;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
        vtss_counter_t rx_etherStatsBroadcastPkts;
        vtss_counter_t rx_etherStatsMulticastPkts;
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        vtss_counter_t rx_etherStatsCRCAlignErrors;
        vtss_counter_t rx_etherStatsUndersizePkts;
        vtss_counter_t rx_etherStatsOversizePkts;
        vtss_counter_t rx_etherStatsFragments;
        vtss_counter_t rx_etherStatsJabbers;
        vtss_counter_t rx_etherStatsPkts64Octets;
        vtss_counter_t rx_etherStatsPkts65to127Octets;
        vtss_counter_t rx_etherStatsPkts128to255Octets;
        vtss_counter_t rx_etherStatsPkts256to511Octets;
        vtss_counter_t rx_etherStatsPkts512to1023Octets;
        vtss_counter_t rx_etherStatsPkts1024to1518Octets;
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#if defined(VTSS_FEATURE_PORT_CNT_JUMBO)
        vtss_counter_t rx_etherStatsPkts1519toMaxOctets;  /* Proprietary */
#endif /* VTSS_FEATURE_PORT_CNT_JUMBO */

        /* Tx counters */
        vtss_counter_t tx_etherStatsDropEvents;
        vtss_counter_t tx_etherStatsOctets;
        vtss_counter_t tx_etherStatsPkts;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
        vtss_counter_t tx_etherStatsBroadcastPkts;
        vtss_counter_t tx_etherStatsMulticastPkts;
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
        vtss_counter_t tx_etherStatsCollisions;
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        vtss_counter_t tx_etherStatsPkts64Octets;
        vtss_counter_t tx_etherStatsPkts65to127Octets;
        vtss_counter_t tx_etherStatsPkts128to255Octets;
        vtss_counter_t tx_etherStatsPkts256to511Octets;
        vtss_counter_t tx_etherStatsPkts512to1023Octets;
        vtss_counter_t tx_etherStatsPkts1024to1518Octets;
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#if defined(VTSS_FEATURE_PORT_CNT_JUMBO)
        vtss_counter_t tx_etherStatsPkts1519toMaxOctets;  /* Proprietary */
#endif /* VTSS_FEATURE_PORT_CNT_JUMBO */
    } rmon;
	
    /* Interfaces Group counters (RFC 2863) */ 
    struct {
        /* Rx counters */
        vtss_counter_t ifInOctets;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
        vtss_counter_t ifInUcastPkts;
        vtss_counter_t ifInMulticastPkts;
        vtss_counter_t ifInBroadcastPkts;
        vtss_counter_t ifInNUcastPkts;
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
        vtss_counter_t ifInDiscards;
        vtss_counter_t ifInErrors;

        /* Tx counters */
        vtss_counter_t ifOutOctets;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
        vtss_counter_t ifOutUcastPkts;
        vtss_counter_t ifOutMulticastPkts;
        vtss_counter_t ifOutBroadcastPkts;
        vtss_counter_t ifOutNUcastPkts;
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
        vtss_counter_t ifOutDiscards;
        vtss_counter_t ifOutErrors;
    } if_group;

#if defined(VTSS_FEATURE_PORT_CNT_ETHER_LIKE) || defined(VTSS_FEATURE_PORT_CNT_PAUSE)
    /* Ethernet-like Interface counters (RFC 3635) */ 
    struct {
        /* Rx counters */
#if defined(VTSS_FEATURE_PORT_CNT_ETHER_LIKE)
        vtss_counter_t dot3StatsAlignmentErrors;
        vtss_counter_t dot3StatsFCSErrors;
        vtss_counter_t dot3StatsFrameTooLongs;
        vtss_counter_t dot3StatsSymbolErrors;
        vtss_counter_t dot3ControlInUnknownOpcodes;
#endif /* VTSS_FEATURE_PORT_CNT_ETHER_LIKE */
#if defined(VTSS_FEATURE_PORT_CNT_PAUSE)
        vtss_counter_t dot3InPauseFrames;
#endif /* VTSS_FEATURE_PORT_CNT_PAUSE */

        /* Tx counters */
#if defined(VTSS_FEATURE_PORT_CNT_ETHER_LIKE)
        vtss_counter_t dot3StatsSingleCollisionFrames;
        vtss_counter_t dot3StatsMultipleCollisionFrames;
        vtss_counter_t dot3StatsDeferredTransmissions;
        vtss_counter_t dot3StatsLateCollisions;
        vtss_counter_t dot3StatsExcessiveCollisions;
        vtss_counter_t dot3StatsCarrierSenseErrors;
#endif /* VTSS_FEATURE_PORT_CNT_ETHER_LIKE */
#if defined(VTSS_FEATURE_PORT_CNT_PAUSE)
        vtss_counter_t dot3OutPauseFrames;
#endif /* VTSS_FEATURE_PORT_CNT_PAUSE */
    } ethernet_like;
#endif /* VTSS_FEATURE_PORT_CNT_ETHER_LIKE/VTSS_FEATURE_PORT_CNT_PAUSE */

#if defined(VTSS_FEATURE_PORT_CNT_BRIDGE)
    /* Bridge counters (RFC 4188) */
    struct {
        vtss_counter_t dot1dTpPortInDiscards;
    } bridge;
#endif /* VTSS_FEATURE_PORT_CNT_BRIDGE */
    
#if defined(VTSS_FEATURE_PORT_CNT_QOS)
    /* Proprietary counters */
    struct {
        vtss_counter_t rx_prio[VTSS_PRIOS];
        vtss_counter_t tx_prio[VTSS_PRIOS];
    } prop;
#endif /* VTSS_FEATURE_PORT_CNT_QOS */
} vtss_poag_counters_t;

/******************************************************************************
 * Description: Update counters for port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_counters_update(const vtss_port_no_t port_no);


/******************************************************************************
 * Description: Clear counters for port.
 *
 * \param poag_no (input): Port/aggregation number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_poag_counters_clear(const vtss_poag_no_t poag_no);


/******************************************************************************
 * Description: Get counters for port.
 *
 * \param poag_no (input)  : Port/aggregation number.
 * \param counters (output): Counter structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_poag_counters_get(const vtss_poag_no_t         poag_no,
                               vtss_poag_counters_t * const counters);

/* ================================================================= *
 *  Stacking
 * ================================================================= */

#if defined(VTSS_FEATURE_VSTAX)

/* VStaX Unit ID, 1-32 */
typedef uint vtss_vstax_uid_t;

#define VTSS_VSTAX_UID_START 1
#define VTSS_VSTAX_UIDS      32
#define VTSS_VSTAX_UID_END   (VTSS_VSTAX_UID_START+VTSS_VSTAX_UIDS)

/* VStaX setup for switch */
typedef struct _vtss_vstax_setup_t {
#if defined(VTSS_CHIPS)
    vtss_vstax_uid_t uid[VTSS_CHIPS]; /* Unit IDs */
#else
    vtss_vstax_uid_t uid;             /* Unit ID */
#endif /* VTSS_CHIPS */
} vtss_vstax_setup_t;

/******************************************************************************
 * Description: Setup VStaX for switch.
 *
 * \param setup (input): VStaX switch setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vstax_setup_set(const vtss_vstax_setup_t * const setup);

/* VStaX setup for port */
typedef struct _vtss_vstax_port_setup_t {
    BOOL enable; /* VStaX enabled */
    uint ttl;    /* TTL, 0-31 */
    BOOL mirror; /* Mirror port reachable via VStaX port */
} vtss_vstax_port_setup_t;

/******************************************************************************
 * Description: Setup VStaX for port.
 *
 * \param port_no (input): Port number.
 * \param setup (input)  : VStaX port setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vstax_port_setup_set(const vtss_port_no_t                  port_no,
                                  const vtss_vstax_port_setup_t * const setup);

#endif /* VTSS_FEATURE_VSTAX */

/* ================================================================= *
 *  Quality of Service                                                   
 * ================================================================= */

/* Priority number: 1..VTSS_PRIOS */
typedef uint vtss_prio_t; /* VTSS_PRIO_START..(VTSS_PRIO_END-1) */

/* Queue number: 1..VTSS_QUEUES */
typedef uint vtss_queue_t; /* VTSS_QUEUE_START..(VTSS_QUEUE_END-1) */

#define VTSS_PRIO_START ((vtss_prio_t)1)             /* Lowest priority */
#define VTSS_PRIO_END   (VTSS_PRIO_START+VTSS_PRIOS) 
#define VTSS_PRIO_ARRAY_SIZE VTSS_PRIO_END

#define VTSS_QUEUE_START ((vtss_queue_t)1)
#define VTSS_QUEUE_END   (VTSS_QUEUE_START+VTSS_QUEUES)
#define VTSS_QUEUE_ARRAY_SIZE VTSS_QUEUE_END

/* Policer/Shaper bit rate. 
   Multiply vtss_bitrate_t value by 1000 to get the rate in BPS. */
typedef ulong vtss_bitrate_t; 

/* Special value that disables policer/shaper feature */
#define VTSS_BITRATE_FEATURE_DISABLED   ((ulong)-1)

/* Policer packet rate in PPS */
typedef ulong vtss_packet_rate_t;

/* Special value for disabling packet policer */
#define VTSS_PACKET_RATE_DISABLED ((ulong)-1)

/* Weight for port WFQ: 1, 2, 4 or 8 */
typedef enum {
    VTSS_WEIGHT_1,
    VTSS_WEIGHT_2,
    VTSS_WEIGHT_4,
    VTSS_WEIGHT_8
} vtss_weight_t;

/* - Per Chip ------------------------------------------------------ */

/******************************************************************************
 * Description: Set the number of active priority queues/traffic classes.
 *
 * \param prios (input): Number of priorities.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_qos_prios_set(const vtss_prio_t prios);

/* All parameters below are defined per chip */
typedef struct _vtss_qos_setup_t {

#if defined(VTSS_FEATURE_QOS_L4_SWITCH)
    /* UDP/TCP port classification */
    vtss_udp_tcp_t udp_tcp_val[10];   /* UDP/TCP port numbers */     
    vtss_prio_t    udp_tcp_prio[10];  /* Priorities for UDP/TCP port numbers */
    vtss_prio_t    udp_tcp_prio_def;  /* Priority for other UDP/TCP port numbers */
#endif /* VTSS_FEATURE_QOS_L4_SWITCH */

#if defined(VTSS_FEATURE_QOS_POLICER_CPU_SWITCH)
    vtss_packet_rate_t policer_mac;   /* MAC table CPU policer */
    vtss_packet_rate_t policer_cat;   /* BPDU, GARP, IGMP, IP MC Control and MLD CPU policer */
    vtss_packet_rate_t policer_learn; /* Learn frame policer */
#endif /* VTSS_FEATURE_QOS_POLICER_CPU_SWITCH */

#if defined(VTSS_FEATURE_QOS_POLICER_UC_SWITCH)
    vtss_packet_rate_t policer_uc;    /* Unicast packet policer */
#endif /* VTSS_FEATURE_QOS_POLICER_UC_SWITCH */

#if defined(VTSS_FEATURE_QOS_POLICER_MC_SWITCH)
    vtss_packet_rate_t policer_mc;    /* Multicast packet policer */
#endif /* VTSS_FEATURE_QOS_POLICER_MC_SWITCH */

#if defined(VTSS_FEATURE_QOS_POLICER_BC_SWITCH)
    vtss_packet_rate_t policer_bc;    /* Broadcast packet policer */
#endif /* VTSS_FEATURE_QOS_POLICER_BC_SWITCH */

#if defined(VTSS_FEATURE_QOS_WFQ_SWITCH)
    BOOL        weighted_fairness_queueing; /* (Otherwise strict fairness queueing) */
#endif /* VTSS_FEATURE_QOS_WFQ_SWITCH */

#if defined(VTSS_ARCH_HEATHROW)
    ulong       dummy;              /* Unused. Ensures that struct is not empty */
#endif

} vtss_qos_setup_t;


/******************************************************************************
 * Description: Get QoS setup for switch.
 *
 * \param qos (output): QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_qos_setup_get(vtss_qos_setup_t * const qos);


/******************************************************************************
 * Description: Set QoS setup for switch.
 *
 * \param qos (input): QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_qos_setup_set(const vtss_qos_setup_t * const qos);


/* - Per Port ------------------------------------------------------ */

#if defined(VTSS_FEATURE_QCL_PORT)
/* QCL ID type */
typedef uint vtss_qcl_id_t; 
#define VTSS_QCL_ID_NONE  0 /* Means QCLs disabled for port */
#define VTSS_QCL_ID_START 1
#define VTSS_QCL_IDS      (VTSS_PORTS)
#define VTSS_QCL_ID_END   (VTSS_QCL_ID_START+VTSS_QCL_IDS)
#define VTSS_QCL_ARRAY_SIZE VTSS_QCL_ID_END
#endif /* VTSS_FEATURE_QCL_PORT */


/* All parameters below are defined per port */
typedef struct _vtss_port_qos_setup_t {
    /* Basic classification mode */

#if defined(VTSS_FEATURE_QCL_PORT)
    vtss_qcl_id_t  qcl_id;               /* QCL ID or VTSS_QCL_ID_NONE */
#endif /* VTSS_FEATURE_QCL_PORT */

#if defined(VTSS_FEATURE_QOS_L4_PORT) || defined(VTSS_FEATURE_QOS_L4_SWITCH)
    BOOL           udp_tcp_enable;       /* Classification on UDP/TCP ports */
#endif /* VTSS_FEATURE_QOS_L4_PORT/VTSS_FEATURE_QOS_L4_SWITCH */

    BOOL           dscp_enable;          /* Classification on DSCP */

#if defined(VTSS_FEATURE_QOS_IP_TOS_PORT)
    BOOL           tos_enable;           /* Classification on DSCP 3 MSBit - overrules dscp_enable */
#endif /* VTSS_FEATURE_QOS_IP_TOS_PORT */

#if defined(VTSS_FEATURE_QOS_IP_PROTO_PORT)
    BOOL           ip_proto_enable;      /* Classification on IP protocol */
#endif /* VTSS_FEATURE_QOS_IP_PROTO_PORT */

    BOOL           tag_enable;           /* Classification on VLAN tag prio */

#if defined(VTSS_FEATURE_QOS_MPLS_PORT)
    BOOL           mpls_enable;          /* Classification on MPLS EXP field */
#endif /* VTSS_FEATURE_QOS_MPLS_PORT */

#if defined(VTSS_FEATURE_QOS_DSAP_PORT)
    BOOL           dsap_enable;          /* Classification on DSAP */
#endif /* VTSS_FEATURE_QOS_DSAP_PORT */

#if defined(VTSS_FEATURE_QOS_ETYPE_PORT)
    BOOL           etype_enable;         /* Classification on Ethernet type */
#endif /* VTSS_FEATURE_QOS_ETYPE_PORT */

#if defined(VTSS_FEATURE_QOS_L4_PORT)
    vtss_udp_tcp_t udp_tcp_val[10];      /* UDP/TCP port numbers */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_prio_t    udp_tcp_prio[10];     /* Priority for UDP/TCP port numbers */
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_FEATURE_QOS_L4_PORT */

    vtss_prio_t    dscp_prio[64];        /* Map from DSCP to priority */

#if defined(VTSS_FEATURE_QOS_IP_PROTO_PORT)
    uchar          ip_proto_val;         /* IP protocol value */
#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_HAWX)
    vtss_prio_t    ip_proto_prio;        /* Priority for IP protocol value */
#endif /* VTSS_ARCH_GATWICK/VTSS_ARCH_HAWX */
#endif /* VTSS_FEATURE_QOS_IP_PROTO_PORT */
    
    vtss_prio_t    tag_prio[8];          /* Map from VLAN tag prio. to prio. */

#if defined(VTSS_FEATURE_QOS_MPLS_PORT)
    vtss_prio_t    mpls_prio[8];         /* Map from MPLS EXP field to prio. */
#endif /* VTSS_FEATURE_QOS_MPLS_PORT */

#if defined(VTSS_FEATURE_QOS_DSAP_PORT)
    uchar          dsap_val;            /* DSAP value */
    vtss_prio_t    dsap_prio;           /* Priority for DSAP value */
#endif /* VTSS_FEATURE_QOS_DSAP_PORT */
    
#if defined(VTSS_FEATURE_QOS_ETYPE_PORT)
#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD) || defined(VTSS_ARCH_SPARX)
    ushort         etype_val;            /* Ethernet type value */
    vtss_prio_t    etype_prio;           /* Priority for Ethernet type value */
#endif /* VTSS_ARCH_GATWICK/STANSTED/STAPLEFORD/SPARX */
#if defined(VTSS_ARCH_HAWX)
    ushort         etype_val[2];          /* Ethernet type value */
    vtss_prio_t    etype_prio[2];         /* Priority for Ethernet type value */
#endif /* VTSS_ARCH_HAWX */
#endif /* VTSS_FEATURE_QOS_ETYPE_PORT */
    
    vtss_prio_t    default_prio;         /* Default port priority */

#if defined(VTSS_ARCH_HEATHROW)
    vtss_tagprio_t usr_prio;             /* Default ingress VLAN tag priority */
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_ARCH_GATWICK)
    vtss_tagprio_t usr_prio[VTSS_PRIO_ARRAY_SIZE]; /* Ingress map from priority to 
                                            VLAN tag priority */
    BOOL           tag_map_enable;       /* Enable/disable ingress mapping for 
                                            tagged frames */ 
    vtss_tagprio_t remap_prio[8];        /* Egress remapping of VLAN tag prio.*/
#endif /* VTSS_ARCH_GATWICK */

#if defined(VTSS_FEATURE_QOS_POLICER_PORT)
    vtss_bitrate_t policer_port;          /* Ingress port policer, all frames */
#endif /* VTSS_FEATURE_QOS_POLICER_PORT */

#if defined(VTSS_FEATURE_QOS_POLICER_MC_PORT)
    vtss_bitrate_t mc_policer_port;       /* Ingress port policer, multicast */
#if defined(VTSS_ARCH_GATWICK)
    BOOL           mc_policer_port_bc_only;/* Only broadcasts in mc_policer_port */
#endif /* VTSS_ARCH_GATWICK */
#endif /* VTSS_FEATURE_QOS_POLICER_MC_PORT */

#if defined(VTSS_FEATURE_QOS_POLICER_BC_PORT)
    vtss_bitrate_t bc_policer_port;       /* Ingress port policer, broadcast */
#endif /* VTSS_FEATURE_QOS_POLICER_BC_PORT */

#if defined(VTSS_FEATURE_QOS_POLICER_CIR_PORT)
    vtss_bitrate_t policer_cir_port;      /* Ingress port policer, CIR */
#endif /* VTSS_FEATURE_QOS_POLICER_CIR_PORT */

#if defined(VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE)
#if defined(VTSS_ARCH_HAWX)
    /* There are 8 prios, but the policers are grouped in 2 prios per queue. */
#endif /* VTSS_ARCH_HAWX */
    vtss_bitrate_t policer_cir_queue[VTSS_QUEUE_ARRAY_SIZE];/* Ingress policer, CIR */
    vtss_bitrate_t policer_pir_queue[VTSS_QUEUE_ARRAY_SIZE];/* Ingress policer, PIR */
#endif /* VTSS_FEATURE_QOS_POLICER_CIR_PIR_QUEUE */

#if defined(VTSS_FEATURE_QOS_SHAPER_PORT)
    vtss_bitrate_t shaper_port;           /* Egress shaping */
#endif /* VTSS_FEATURE_QOS_SHAPER_PORT */

#if defined(VTSS_FEATURE_QOS_SHAPER_QUEUE)
#if defined(VTSS_ARCH_GATWICK)
    /* If the port shaper is enabled, the queue shapers are bypassed. */
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_ARCH_HAWX)
    /* There are 8 prios, but the shapers are grouped in 2 prios per queue. */
#endif /* VTSS_ARCH_HAWX */
    vtss_bitrate_t shaper_queue[VTSS_QUEUE_ARRAY_SIZE]; /* Egress shaping */
    BOOL           shaper_queue_excss_enable[VTSS_QUEUE_ARRAY_SIZE]; /* Allow consuming 
                                                                        excess bandwidth */
#endif /* VTSS_FEATURE_QOS_SHAPER_QUEUE */
#if defined(VTSS_FEATURE_QOS_WFQ_PORT)
    /* Weighted fairness queueing */
    BOOL           wfq_enable; 
    vtss_weight_t  weight[VTSS_QUEUE_ARRAY_SIZE];
#endif /* VTSS_FEATURE_QOS_WFQ_PORT */
} vtss_port_qos_setup_t;

/******************************************************************************
 * Description: Get QoS setup for port.
 *
 * \param port_no (input): Port number.
 * \param qos (output)   : QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_qos_get(const vtss_port_no_t          port_no,
                          vtss_port_qos_setup_t * const qos);


/******************************************************************************
 * Description: Set QoS setup for port.
 *
 * \param port_no (input): Port number.
 * \param qos (input)    : QoS setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_qos_set(const vtss_port_no_t                port_no,
                          const vtss_port_qos_setup_t * const qos);

/* - QoS Control Lists --------------------------------------------- */

#if defined(VTSS_FEATURE_QCL_PORT)

/* QCE ID */
typedef ulong vtss_qce_id_t;
#define VTSS_QCE_ID_LAST 0 /* Special value used to add last in list */

/* QCE type */
typedef enum _vtss_qce_type_t {
    VTSS_QCE_TYPE_ETYPE,   /* Ethernet Type */
    VTSS_QCE_TYPE_VLAN,    /* VLAN ID */
    VTSS_QCE_TYPE_UDP_TCP, /* UDP/TCP port */
    VTSS_QCE_TYPE_DSCP,    /* IP DSCP */
    VTSS_QCE_TYPE_TOS,     /* IP ToS */
    VTSS_QCE_TYPE_TAG      /* VLAN Tag */
} vtss_qce_type_t;

/* QoS Control Entry */
typedef struct _vtss_qce_t {
    vtss_qce_id_t   id;
    vtss_qce_type_t type;

    union {
        /* Type VTSS_QCE_TYPE_ETYPE */
        struct {
            vtss_etype_t val;  /* Ethernet Type */ 
            vtss_prio_t  prio; /* Priority mapping */
        } etype;
        
        /* Type VTSS_QCE_TYPE_VLAN_ID */
        struct {
            vtss_vid_t  vid;  /* VLAN ID value */
            vtss_prio_t prio; /* Priority mapping */
        } vlan;
    
        /* Type VTSS_QCE_TYPE_UDP_TCP */
        struct {
            vtss_udp_tcp_t low;  /* UDP/TCP port range low value */
            vtss_udp_tcp_t high; /* UDP/TCP port range high value */
            vtss_prio_t prio;    /* Priority mapping */
        } udp_tcp;
        
        /* Type VTSS_QCE_TYPE_DSCP */
        struct {
            vtss_dscp_t dscp_val; /* DSCP value */
            vtss_prio_t prio; /* Priority mapping */
        } dscp;
        
        /* Type VTSS_QCE_TYPE_TOS */
        vtss_prio_t tos_prio[8]; /* ToS priority mapping */
        
        /* Type VTSS_QCE_TYPE_TAG */
        vtss_prio_t tag_prio[8]; /* Tag priority mapping */
    } frame;
} vtss_qce_t;

/******************************************************************************
 * Description: Add QCE to QCL.
 *
 * \param qcl_id (input): QCL ID. 
 * \param qce_id (input): QCE ID. The QCE will be added before the entry with 
 *                        this ID. VTSS_QCE_ID_LAST is reserved for inserting
 *                        last.
 * \param qce (input)   : QCE setup structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_qce_add(const vtss_qcl_id_t      qcl_id,
                     const vtss_qce_id_t      qce_id,
                     const vtss_qce_t * const qce);

/******************************************************************************
 * Description: Delete QCE from QCL.
 *
 * \param qcl_id (input): QCL ID.
 * \param qce_id (input): QCE ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_qce_del(const vtss_qcl_id_t qcl_id,
                     const vtss_qce_id_t qce_id);

#endif /* VTSS_FEATURE_QCL_PORT */

/* ================================================================= *
 *  Security
 * ================================================================= */

/* - Port Based Network Access Control, 802.1X --------------------- */

/* Authentication state */
typedef enum _vtss_auth_state_t {
    VTSS_AUTH_STATE_NONE,   /* Not authenticated */
    VTSS_AUTH_STATE_EGRESS, /* Authenticated in egress direction */
    VTSS_AUTH_STATE_BOTH    /* Authenticated in both directions */
} vtss_auth_state_t;

/******************************************************************************
 * Description: Set 802.1X Authentication state for a port.
 *
 * \param port_no (input)   : Port number.
 * \param auth_state (input): Authentication state.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_auth_state_set(const vtss_port_no_t    port_no,
                                 const vtss_auth_state_t auth_state);


/* - SIP filters --------------------------------------------------- */

#if defined(VTSS_FEATURE_FILTER_SIP)
/******************************************************************************
 * Description: Set source IP filter for a port.
 *
 * \param port_no (input): Port number.
 * \param sip (input)    : Source IP address.
 * \param mask (input)   : Source IP mask.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_filter_sip_set(const vtss_port_no_t port_no,
                            const vtss_ip_t      sip,
                            const vtss_ip_t      mask);
#endif /* VTSS_FEATURE_FILTER_SIP */


/* - UDP/TCP filters ----------------------------------------------- */

#if defined(VTSS_FEATURE_FILTER_UDP_TCP)
/* Filter action */
typedef struct _vtss_filter_action_t {
    BOOL forward; /* Forward to switch ports */
    BOOL cpu;     /* Forward to CPU */
} vtss_filter_action_t;

/******************************************************************************
 * Description: Set UDP/TCP filter.
 *
 * \param action (input): Filter action structure.
 * \param port_1 (input): First UDP/TCP port.
 * \param port_2 (input): Second UDP/TCP port.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_filter_udp_tcp_set(const vtss_filter_action_t * const action,
                                const vtss_udp_tcp_t               port_1,
                                const vtss_udp_tcp_t               port_2);
#endif /* VTSS_FEATURE_FILTER_UDP_TCP */


/* - Access Control Lists ------------------------------------------ */

#if defined(VTSS_FEATURE_ACL)

/* ACL policer number, 1-16 */
typedef uint vtss_acl_policer_no_t;
#define VTSS_ACL_POLICER_NO_START 1
#define VTSS_ACL_POLICERS         16
#define VTSS_ACL_POLICER_NO_END   (VTSS_ACL_POLICER_NO_START+VTSS_ACL_POLICERS)

/******************************************************************************
 * Description: Set rate for ACL policer.
 *
 * \param policer_no (input): ACL policer number.
 * \param rate (input)      : ACL policer rate.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_acl_policer_rate_set(const vtss_acl_policer_no_t policer_no,
                                  const vtss_packet_rate_t    rate);

/* ACL Action */
typedef struct _vtss_acl_action_t {
    BOOL                  forward;      /* Allow forwarding */
    BOOL                  learn;        /* Allow learning */
    BOOL                  cpu;          /* Forward to CPU */
    BOOL                  cpu_once;     /* Only first frame forwarded to CPU */
    vtss_cpu_rx_queue_t   cpu_queue;    /* CPU queue */
    BOOL                  police;       /* Enable policer */
    vtss_acl_policer_no_t policer_no;   /* Policer number */
    BOOL                  port_forward; /* Forward to specific port */
    vtss_port_no_t        port_no;      /* Specified port */
} vtss_acl_action_t;

/******************************************************************************
 * Description: Set default ACL action for port.
 *
 * \param port_no (input): Port number.
 * \param action (input) : Default action for port.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_acl_port_action_set(const vtss_port_no_t            port_no,
                                 const vtss_acl_action_t * const action);

/* ACL port counter */
typedef ulong vtss_acl_port_counter_t; 

/******************************************************************************
 * Description: Get default action counter for port.
 *
 * \param port_no (input) : Port number.
 * \param counter (output): Default action counter for port.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_acl_port_counter_get(const vtss_port_no_t            port_no,
                                  vtss_acl_port_counter_t * const counter);

/******************************************************************************
 * Description: Clear default action counter for port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_acl_port_counter_clear(const vtss_port_no_t port_no);


/* ACL policy number, 1-8 */
typedef uint vtss_acl_policy_no_t;
#define VTSS_ACL_POLICY_NO_NONE  0 /* Means ACLs disabled on port */
#define VTSS_ACL_POLICY_NO_START 1
#define VTSS_ACL_POLICIES        8
#define VTSS_ACL_POLICY_NO_END   (VTSS_ACL_POLICY_NO_START+VTSS_ACL_POLICIES)

/******************************************************************************
 * Description: Setup policy number for port.
 *
 * \param port_no (input)  : Port number.
 * \param policy_no (input): Policy number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_acl_policy_no_set(const vtss_port_no_t       port_no,
                               const vtss_acl_policy_no_t policy_no);

/* ACE rule type */
typedef enum _vtss_ace_rule_t {
    VTSS_ACE_RULE_PORT,    /* Port rule */
    VTSS_ACE_RULE_POLICY,  /* Policy rule */
    VTSS_ACE_RULE_SWITCH   /* Switch rule */
} vtss_ace_rule_t;

/* ACE frame type */
typedef enum _vtss_ace_type_t {
    VTSS_ACE_TYPE_ANY,     /* Any frame type */
    VTSS_ACE_TYPE_ETYPE,   /* Ethernet Type */
    VTSS_ACE_TYPE_LLC,     /* LLC */
    VTSS_ACE_TYPE_SNAP,    /* SNAP */
    VTSS_ACE_TYPE_ARP,     /* ARP/RARP */
    VTSS_ACE_TYPE_IPV4,    /* IPv4 */
    VTSS_ACE_TYPE_IPV6     /* IPv6 */
} vtss_ace_type_t;

/* ACE ID type */
typedef ulong vtss_ace_id_t;
#define VTSS_ACE_ID_LAST 0 /* Special value used to add last in list */

/* ACE 1 bit */
typedef enum _vtss_ace_bit_t {
    VTSS_ACE_BIT_ANY, /* Value 0 or 1 */
    VTSS_ACE_BIT_0,   /* Value 0 */
    VTSS_ACE_BIT_1    /* Value 1 */
} vtss_ace_bit_t;

/* ACE 8 bit value and mask */
typedef struct _vtss_ace_uchar_t {
    uchar value; /* Value */
    uchar mask;  /* Mask, cleared bits are wildcards */
} vtss_ace_uchar_t;

/* ACE 16 bit value and mask */
typedef struct _vtss_ace_uchar2_t {
    uchar value[2]; /* Value */
    uchar mask[2];  /* Mask, cleared bits are wildcards */
} vtss_ace_uchar2_t;

/* ACE 32 bit value and mask */
typedef struct _vtss_ace_uchar4_t {
    uchar value[4]; /* Value */
    uchar mask[4];  /* Mask, cleared bits are wildcards */
} vtss_ace_uchar4_t;

/* ACE 40 bit value and mask */
typedef struct _vtss_ace_uchar5_t {
    uchar value[5]; /* Value */
    uchar mask[5];  /* Mask, cleared bits are wildcards */
} vtss_ace_uchar5_t;

/* ACE 48 bit value and mask */
typedef struct _vtss_ace_uchar6_t {
    uchar value[6]; /* Value */
    uchar mask[6];  /* Mask, cleared bits are wildcards */
} vtss_ace_uchar6_t;

/* ACE 128 bit value and mask */
typedef struct _vtss_ace_uchar16_t {
    uchar value[16]; /* Value */
    uchar mask[16];  /* Mask, cleared bits are wildcards */
} vtss_ace_uchar16_t;

/* ACE VLAN ID value and mask */
typedef struct _vtss_ace_vid_t {
    ushort value; /* Value */
    ushort mask;  /* Mask, cleared bits are wildcards */
} vtss_ace_vid_t;

/* ACE IP address value and mask */
typedef struct _vtss_ace_ip_t {
    vtss_ip_t value; /* Value */
    vtss_ip_t mask;  /* Mask, cleared bits are wildcards */
} vtss_ace_ip_t; 

/* ACE UDP/TCP port range */
typedef struct _vtss_ace_udp_tcp_t {
    BOOL           in_range; /* Port in range match */
    vtss_udp_tcp_t low;      /* Port low value */
    vtss_udp_tcp_t high;     /* Port high value */
} vtss_ace_udp_tcp_t;

/* Access Control Entry */
typedef struct _vtss_ace_t {
    vtss_ace_id_t        id;        /* ACE ID */
    vtss_ace_rule_t      rule;      /* ACE rule type */
    vtss_poag_no_t       port_no;   /* Port number: VTSS_ACL_RULE_PORT */
    vtss_acl_policy_no_t policy_no; /* Policy number: VTSS_ACL_RULE_POLICY */
    vtss_ace_type_t      type;      /* ACE frame type */
    vtss_acl_action_t    action;    /* ACE action */

    /* DMAC information */
    vtss_ace_bit_t      dmac_mc;  /* Multicast DMAC */
    vtss_ace_bit_t      dmac_bc;  /* Broadcast DMAC */

    /* VLAN Tag */
    struct {
        vtss_ace_vid_t   vid;      /* VLAN ID (12 bit) */
        vtss_ace_uchar_t usr_prio; /* User priority (3 bit) */
        vtss_ace_bit_t   cfi;      /* CFI */
    } vlan;

    /* Frame type specific data */
    union {
        /* VTSS_ACE_TYPE_ANY: No specific fields */

        /* VTSS_ACE_TYPE_ETYPE */
        struct {
            vtss_ace_uchar6_t dmac;  /* DMAC */
            vtss_ace_uchar6_t smac;  /* SMAC */
            vtss_ace_uchar2_t etype; /* Ethernet Type value */
            vtss_ace_uchar2_t data;  /* MAC data */ 
        } etype;

        /* VTSS_ACE_TYPE_LLC */
        struct {
            vtss_ace_uchar6_t dmac; /* DMAC */
            vtss_ace_uchar6_t smac; /* SMAC */
            vtss_ace_uchar4_t llc;  /* LLC */
        } llc;

        /* VTSS_ACE_TYPE_SNAP */
        struct {
            vtss_ace_uchar6_t dmac; /* DMAC */
            vtss_ace_uchar6_t smac; /* SMAC */
            vtss_ace_uchar5_t snap; /* SNAP */
        } snap;

        /* VTSS_ACE_TYPE_ARP */
        struct {
            vtss_ace_uchar6_t smac;       /* SMAC */
            vtss_ace_bit_t    arp;        /* Opcode ARP/RARP */
            vtss_ace_bit_t    req;        /* Opcode request/reply */
            vtss_ace_bit_t    unknown;    /* Opcode unknown */
            vtss_ace_bit_t    smac_match; /* Sender MAC matches SMAC */
            vtss_ace_bit_t    dmac_match; /* Target MAC matches DMAC */
            vtss_ace_bit_t    length;     /* Protocol addr. length 4, hardware length 6 */
            vtss_ace_bit_t    ip;         /* Protocol address type IP */
            vtss_ace_bit_t    ethernet;   /* Hardware address type Ethernet */
            vtss_ace_ip_t     sip;        /* Sender IP address */
            vtss_ace_ip_t     dip;        /* Target IP address */
        } arp;
        
        /* IPv4: Type VTSS_ACE_TYPE_IPV4 */
        struct {
            vtss_ace_bit_t     ttl;       /* TTL zero */
            vtss_ace_bit_t     fragment;  /* Fragment */
            vtss_ace_bit_t     options;   /* Header options */
            vtss_ace_uchar_t   ds;        /* DS field */
            vtss_ace_uchar_t   proto;     /* Protocol */
            vtss_ace_ip_t      sip;       /* Source IP address */
            vtss_ace_ip_t      dip;       /* Destination IP address */
            vtss_ace_uchar6_t  data;      /* Not UDP/TCP: IP data */
            vtss_ace_udp_tcp_t sport;     /* UDP/TCP: Source port */
            vtss_ace_udp_tcp_t dport;     /* UDP/TCP: Destination port */
            vtss_ace_bit_t     tcp_fin;   /* TCP FIN */
            vtss_ace_bit_t     tcp_syn;   /* TCP SYN */
            vtss_ace_bit_t     tcp_rst;   /* TCP RST */
            vtss_ace_bit_t     tcp_psh;   /* TCP PSH */
            vtss_ace_bit_t     tcp_ack;   /* TCP ACK */
            vtss_ace_bit_t     tcp_urg;   /* TCP URG */
        } ipv4;
        
        /* IPv6: Type VTSS_ACE_TYPE_IPV6 */
        struct {
            vtss_ace_uchar_t   proto; /* IPv6 protocol */
            vtss_ace_uchar16_t sip;   /* IPv6 source address */
        } ipv6;
    } frame;
} vtss_ace_t;

/******************************************************************************
 * Description: Initialize ACE to default values.
 *
 * \param type (input): ACE type.
 * \param ace (output): ACE structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ace_init(const vtss_ace_type_t type,
                      vtss_ace_t * const    ace);

/******************************************************************************
 * Description: Add/modify ACE.
 *
 * \param ace_id (input): ACE ID. The ACE will be added after the entry with 
 *                        this ID. VTSS_ACE_ID_LAST is reserved for inserting 
 *                        last.
 * \param ace (input)   : ACE structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ace_add(const vtss_ace_id_t      ace_id,
                     const vtss_ace_t * const ace);

/******************************************************************************
 * Description: Delete ACE.
 *
 * \param ace_id (input): ACE ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ace_del(const vtss_ace_id_t ace_id);

/* ACE hit counter */
typedef ulong vtss_ace_counter_t; 

/******************************************************************************
 * Description: Get ACE counter.
 *
 * \param ace_id (input)  : ACE ID.
 * \param counter (output): ACE counter.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ace_counter_get(const vtss_ace_id_t        ace_id,
                             vtss_ace_counter_t * const counter);

/******************************************************************************
 * Description: Clear ACE counter.
 *
 * \param ace_id (input): ACE ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ace_counter_clear(const vtss_ace_id_t ace_id);

#endif /* VTSS_FEATURE_ACL */

/* ================================================================= *
 *  Packet Control
 * ================================================================= */

#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
#define VTSS_CPU_RX_QUEUES      2
#endif /* VTSS_ARCH_SPARX_G8/G24 */

#if defined(VTSS_ARCH_SPARX_28)
#define VTSS_CPU_RX_QUEUES      4
#endif /* VTSS_ARCH_SPARX_28 */

#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD) || defined(HEATHROW2)
#define VTSS_CPU_RX_QUEUES      1
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD/HEATHROW2 */

#if defined(VTSS_ARCH_HAWX)
#define VTSS_CPU_RX_QUEUES      4 /* HawX-A: Only 2 queues */
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_GATWICK)
#if defined(VTSS_CHIPS)
#define VTSS_CPU_RX_QUEUES      15 /* One queue reserved for internal purposes */
#else
#define VTSS_CPU_RX_QUEUES      16
#endif /* VTSS_CHIPS */
#endif /* VTSS_ARCH_GATWICK */

#define VTSS_CPU_RX_QUEUE_START ((vtss_cpu_rx_queue_t)1)
#define VTSS_CPU_RX_QUEUE_END   (VTSS_CPU_RX_QUEUE_START+VTSS_CPU_RX_QUEUES)

/* - Rx frame registration ----------------------------------------- */

#if (VTSS_CPU_RX_QUEUES>1)
/* CPU Rx queue map */
typedef struct _vtss_cpu_rx_queue_map_t {
#if defined(VTSS_ARCH_HEATHROW) || defined(VTSS_ARCH_SPARX)
    vtss_cpu_rx_queue_t bpdu_queue;      /* BPDUs */
    vtss_cpu_rx_queue_t garp_queue;      /* GARP frames */
#endif /* VTSS_ARCH_HEATHROW || VTSS_ARCH_SPARX */
#if defined(VTSS_ARCH_GATWICK)
    vtss_cpu_rx_queue_t bpdu_garp_queue; /* BPDU and GARP frames */
#endif /* VTSS_ARCH_GATWICK */    
    vtss_cpu_rx_queue_t learn_queue;     /* Learn frames */
    vtss_cpu_rx_queue_t igmp_queue;      /* IGMP/MLD frames */
    vtss_cpu_rx_queue_t ipmc_ctrl_queue; /* IP multicast control frames */
    vtss_cpu_rx_queue_t mac_vid_queue;   /* MAC address table */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_FEATURE_CPU_RX_REG_ARP_ADV)
    vtss_cpu_rx_queue_t arp_bc_queue;    /* ARP broadcasts */
#endif /* VTSS_ARCH_HAWX/SPARX_G8/VTSS_FEATURE_CPU_RX_REG_ARP_ADV */
#if defined(VTSS_ARCH_HAWX)
    vtss_cpu_rx_queue_t ip_bc_queue;     /* IP broadcasts */
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_FEATURE_FILTER_UDP_TCP)
    vtss_cpu_rx_queue_t udp_tcp_queue;   /* UDP/TCP filter matches */
#endif /* VTSS_FEATURE_FILTER_UDP_TCP */
#if defined(VTSS_FEATURE_LAYER3)
    vtss_cpu_rx_queue_t rl_match_queue;  /* Router Leg matches */
    vtss_cpu_rx_queue_t ip_error_queue;  /* IP header error */
    vtss_cpu_rx_queue_t ip_opt_queue;    /* IP options */
    vtss_cpu_rx_queue_t ipuc_fail_queue; /* IP unicast or ARP lookup failure */
    vtss_cpu_rx_queue_t ipuc_dmac_queue; /* IP unicast, zero DMAC in ARP table */
    vtss_cpu_rx_queue_t ipuc_ttl_queue;  /* IP unicast with TTL less than 2 */
    vtss_cpu_rx_queue_t ipuc_sec_queue;  /* IP unicast security failure */
    vtss_cpu_rx_queue_t ipmc_fail_queue; /* IP multicast lookup failure */
#endif /* VTSS_FEATURE_LAYER3 */
} vtss_cpu_rx_queue_map_t;

/******************************************************************************
 * Description: Set CPU Rx queue map.
 *
 * \param map (input): CPU Rx queue map structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map);

#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
/* CPU Rx queue buffer size in bytes */
typedef uint vtss_cpu_rx_queue_size_t;

/* Example buffer sizes for low and high priority */
#if defined(VTSS_ARCH_GATWICK)
#define VTSS_CPU_RX_QUEUE_SIZE_LOW  (32*768) /* 32 slices/24 kB */
#define VTSS_CPU_RX_QUEUE_SIZE_HIGH (64*768) /* 64 slices/48 kB */
#endif /* VTSS_ARCH_GATWICK */

#if defined(VTSS_ARCH_HAWX)
/* For HawX-B, the sum of the queue sizes must be 32*1024 (32 kB).
   The default configuration is:
   Queue 1: 20 kB
   Queue 2: 12 kB
   Queue 3:  0 kB
   Queue 4:  0 kB */
#define VTSS_CPU_RX_QUEUE_SIZE_LOW  (12*1024) /* 12 kB */
#define VTSS_CPU_RX_QUEUE_SIZE_HIGH (20*1024) /* 20 kB */
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_SPARX_28)
/* For SparX-28, the total queue size is 48*1024 (48 kB).
   The default configuration is:
   Queue 1: 32 kB
   Queue 2: 16 kB
   Queue 3:  0 kB
   Queue 4:  0 kB */
#define VTSS_CPU_RX_QUEUE_SIZE_LOW  (16*1024) /* 16 kB */
#define VTSS_CPU_RX_QUEUE_SIZE_HIGH (32*1024) /* 32 kB */
#endif /* VTSS_ARCH_SPARX_28 */

/******************************************************************************
 * Description: Set CPU Rx queue size.
 *
 * \param queue_no (input): CPU queue number.
 * \param size (input)    : CPU queue size in bytes.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_queue_size_set(const vtss_cpu_rx_queue_t      queue_no, 
                                   const vtss_cpu_rx_queue_size_t size);
#endif /* VTSS_ARCH_GATWICK/HAWX/SPARX_28 */    
#endif /* VTSS_CPU_RX_QUEUES>1 */

/* VTSS_ARCH_GATWICK: 
   If Fairoaks/Gatwick is used (not Fairoaks-Ie/Gatwick-Ie), 
   bpdu_cpu_only[0] determines the registration for all BPDU addresses. 
   For these chips, the ARP registration is not supported */

/* CPU frame registration */
typedef struct _vtss_cpu_rx_registration_t {
#if defined(VTSS_FEATURE_CPU_RX_REG_BPDU_ADV)
    BOOL bpdu_cpu_only[16];     /* Redirect BPDUs (DMAC 01-80-C2-00-00-0X) */
#else
    BOOL bpdu_cpu_only;         /* Redirect BPDUs (DMAC 01-80-C2-00-00-0X) */
#endif /* VTSS_FEATURE_CPU_RX_REG_BPDU_ADV */
#if defined(VTSS_FEATURE_CPU_RX_REG_GARP_ADV)
    BOOL garp_cpu_only[16];     /* Redirect GARPs (DMAC 01-80-C2-00-00-2X) */
#endif /* VTSS_FEATURE_CPU_RX_REG_GARP_ADV */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    BOOL bcast_iparp_cpu_copy;  /* Copy IP broadcast and 
                                   ARP broadcast frames to the CPU */
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_FEATURE_CPU_RX_REG_IP_ADV)
    BOOL bcast_ip_cpu_copy;     /* Copy IP broadcast frames to the CPU */
#endif /* VTSS_FEATURE_CPU_RX_REG_IP_ADV */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8)
    BOOL bcast_arp_cpu_copy;    /* Copy ARP broadcast frames to the CPU */
#endif /* VTSS_ARCH_HAWX/SPARX_G8 */
#if defined(VTSS_FEATURE_CPU_RX_REG_ARP_ADV)
    BOOL bcast_arp_cpu_copy_all; /* Copy all ARP broadcasts to CPU */
    BOOL bcast_arp_cpu_copy_sel; /* Copy selected ARP broadcasts to CPU */
    vtss_ip_t arp_ip;            /* Target IP address in ARP packets selected */
#endif /* VTSS_FEATURE_CPU_RX_REG_ARP_ADV */
#if defined(VTSS_FEATURE_LAYER3)
    BOOL bcast_rl_match_all;    /* Copy all broadcasts from Router Legs */
    BOOL bcast_rl_match_sel;    /* Copy selected broadcasts from Router Legs */
#endif /* VTSS_FEATURE_LAYER3 */
    BOOL ipmc_ctrl_cpu_copy;    /* Copy IP MC control (DIP 224.0.0.x) to CPU */
    BOOL mcast_igmp_cpu_only;   /* Redirect IGMP frames to the CPU */
#if defined(VTSS_FEATURE_CPU_RX_REG_MLD_ADV)
    BOOL mcast_mld_cpu_only;    /* Redirect MLD frames to the CPU */
#endif /* VTSS_FEATURE_CPU_RX_REG_MLD_ADV */
} vtss_cpu_rx_registration_t;

/******************************************************************************
 * Description: Get CPU frame registration.
 *
 * \param registration (output): Frame registration structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_registration_get(
    vtss_cpu_rx_registration_t * const registration);


/******************************************************************************
 * Description: Set CPU frame registration.
 *
 * \param registration (input): Frame registration structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_registration_set(
    const vtss_cpu_rx_registration_t * const registration);


/* - Rx frames ----------------------------------------------------- */

/******************************************************************************
 * Description: Enable interrupt if a frame is ready in a CPU queue.
 *
 * \param queue_no (input): CPU queue number.
 * \param enable (input)  : Boolean, TRUE to enable interrupt.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_frameready_int_enable(const vtss_cpu_rx_queue_t queue_no,
                                          const BOOL                enable);

#if defined(VTSS_FEATURE_VSTAX)
/* VStaX frame header used for reception */
typedef struct _vtss_vstax_rx_header_t {
    BOOL             valid;    /* TRUE if frame was VStaX tagged */
    vtss_vstax_uid_t uid;      /* Ingress Unit ID */
    vtss_port_no_t   port_no;  /* Ingress Unit port number (or zero) */
#if defined(VTSS_FEATURE_AGGR_GLAG)
    vtss_glag_no_t   glag_no;  /* Ingress GLAG (or zero) */
#endif /* VTSS_FEATURE_AGGR_GLAG */
} vtss_vstax_rx_header_t;
#endif /* VTSS_FEATURE_VSTAX */

/* System frame header describing received frame */
typedef struct _vtss_system_frame_header_t {
    uint                   length;         /* Frame length excluding CRC */
    vtss_port_no_t         source_port_no; /* Source port number */
    BOOL                   arrived_tagged; /* TRUE is frame was tagged */
    vtss_tci_t             tag;            /* VLAN tag from frame or VLAN port setup */
#if defined(VTSS_FEATURE_VSTAX)
    vtss_vstax_rx_header_t vstax;
#endif /* VTSS_FEATURE_VSTAX */
} vtss_system_frame_header_t;

/******************************************************************************
 * Description: Determine if a frame is ready in a CPU queue.
 *
 * \param queue_no (input): CPU queue number.
 *
 * \return : Negative value (error), 0 (no frame ready) or 1 (frame ready).
 ******************************************************************************/
vtss_rc vtss_cpu_rx_frameready(const vtss_cpu_rx_queue_t queue_no);


/******************************************************************************
 * Description: Copy a received frame from a CPU queue. If the frame buffer
 *              is NULL or too small, the system header is filled out and 
 *              VTSS_PACKET_BUF_SMALL is returned. The application can then 
 *              allocate a buffer and call this function again.
 *
 * \param queue_no (input)   : CPU queue number.
 * \param sys_header (output): Frame header.
 * \param frame (output)     : Frame buffer. 
 * \param maxlength (input)  : Length of frame buffer.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_frame(const vtss_cpu_rx_queue_t          queue_no,
                          vtss_system_frame_header_t * const sys_header,
                          uchar * const                      frame,
                          const uint                         maxlength);


/******************************************************************************
 * Description: Discard a received frame from a CPU queue.
 *
 * \param queue_no (input)   : CPU queue number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_rx_discard_frame(const vtss_cpu_rx_queue_t queue_no);


/* - Tx frames ----------------------------------------------------- */

/******************************************************************************
 * Description: Send frame unmodified on port/aggregation.
 *
 * \param poag_no (input): Port/aggregation number.
 * \param frame (input)  : Frame buffer excluding room for CRC.
 * \param length (input) : Frame length excluding CRC.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_tx_raw_frame(const vtss_poag_no_t poag_no,
                              const uchar * const  frame,
                              const uint           length);


/******************************************************************************
 * Description: Send frame on port/aggregation applying VLAN, STP and 
 *              aggregation rules.
 *
 * \param poag_no (input): Port/aggregation number.
 * \param vid (input)    : VLAN ID inserted if the frame is tagged on egress.
 * \param frame (input)  : Frame buffer excluding room for CRC.
 * \param length (input) : Frame length excluding CRC.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_tx_poag_frame(const vtss_poag_no_t poag_no,
                               const vtss_vid_t    vid,
                               const uchar * const frame,
                               const uint          length);


/******************************************************************************
 * Description: Send frame on port/aggregation applying VLAN, STP, 
 *              aggregation rules and (DMAC, VID) lookup.
 *
 * \param vid (input)   : VLAN ID inserted if the frame is tagged on egress.
 * \param frame (input) : Frame buffer excluding room for CRC.
 * \param length (input): Frame length excluding CRC.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_tx_vlan_frame(const vtss_vid_t    vid,
                               const uchar * const frame,
                               const uint          length);

/* Information about frame */
typedef struct _vtss_cpu_frame_info_t {
    vtss_port_no_t port_no; /* Ingress port (or zero) */
#if defined(VTSS_FEATURE_AGGR_GLAG)
    vtss_glag_no_t glag_no; /* Ingress GLAG (or zero) */
#endif /* VTSS_FEATURE_AGGR_GLAG */
    vtss_vid_t     vid;     /* Egress VID (or VTSS_VID_NULL) */
    vtss_port_no_t port_tx; /* Egress port (or zero) */
} vtss_cpu_frame_info_t;

/* CPU filter */
typedef enum {
    VTSS_CPU_FILTER_DISCARD, /* Discard */
    VTSS_CPU_FILTER_TAGGED,  /* Tagged transmission */
    VTSS_CPU_FILTER_UNTAGGED /* Untagged transmission */
} vtss_cpu_filter_t;

/******************************************************************************
 * Description: Determine ingress/egress filter for frame. The function may be 
 *              used for ingress filtering, egress filtering or both.
 *
 * \param info (input)   : Frame information.
 * \param filter (output): Frame filter.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_cpu_filter(const vtss_cpu_frame_info_t * const info,
                        vtss_cpu_filter_t * const           filter);

#if defined(VTSS_FEATURE_VSTAX)

/* VStaX frame forward mode */
typedef enum _vtss_vstax_fwd_mode_t {
    VTSS_VSTAX_FWD_MODE_LOOKUP   = 0, /* Local lookup in all units */
    VTSS_VSTAX_FWD_MODE_UID_PORT = 2, /* Physical port on UID */
    VTSS_VSTAX_FWD_MODE_CPU_UID  = 5, /* CPU queue on UID */
    VTSS_VSTAX_FWD_MODE_CPU_ALL  = 6  /* CPU queue on all UIDs */
} vtss_vstax_fwd_mode_t;

/* VStaX TTL value, 0-31 */
typedef uint vtss_vstax_ttl_t;
#define VTSS_VSTAX_TTL_PORT 0 /* TTL value configured for port is used */

/* VStaX super priority */
#define VTSS_PRIO_SUPER VTSS_PRIO_END

/* VStaX frame header used for transmission */
typedef struct _vtss_vstax_tx_header_t {
    vtss_vstax_fwd_mode_t fwd_mode; /* Frame forward mode */
    vtss_vstax_ttl_t      ttl;      /* TTL value or VTSS_VSTAX_TTL_PORT */
    vtss_prio_t           prio;     /* Priority, VTSS_PRIO_SUPER allowed */
    vtss_vstax_uid_t      uid;      /* Dest. unit: FWD_MODE_UID_PORT/CPU_UID */
    vtss_tci_t            tci;      /* VLAN tag information */
    vtss_port_no_t        port_no;  /* Dest. port: FWD_MODE_UID_PORT
                                       Src. port : FWD_MODE_CPU_UID/ALL */
#if defined(VTSS_FEATURE_AGGR_GLAG)
    vtss_glag_no_t        glag_no;  /* GLAG number: FWD_MODE_CPU_UID/ALL */
#endif /* VTSS_FEATURE_AGGR_GLAG */
    vtss_cpu_rx_queue_t   queue_no; /* CPU queue : FWD_MODE_CPU_UID/ALL */
} vtss_vstax_tx_header_t;

/******************************************************************************
 * Description: Send frame on VStaX port. 
 *
 * \param port_no (input)     : Port number.
 * \param vstax_header (input): VStaX header structure.
 * \param frame (input)       : Frame buffer excluding room for CRC.
 * \param length (input)      : Frame length excluding CRC.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_tx_vstax_frame(const vtss_port_no_t                 port_no,
                            const vtss_vstax_tx_header_t * const vstax_header,
                            const uchar * const                  frame,
                            const uint                           length);


#define VTSS_VSTAX_HDR_SIZE  12     /* VStaX header size */
/******************************************************************************
 * Description: Build 12 bytes VStaX header. 
 *
 * \param port_no (input)     : Port number.
 * \param vstax_header (input): VStaX header structure.
 * \param frame (output)      : Frame buffer with room for 12 bytes.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vstax_header_get(const vtss_port_no_t                 port_no,
                              const vtss_vstax_tx_header_t * const vstax_header,
                              uchar * const                        frame);

/******************************************************************************
 * Description: Extract 12 bytes VStaX header. 
 *
 * \param frame (input)        : Frame buffer with room for 12 bytes.
 * \param vstax_header (output): VStaX header structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vstax_header_put(const uchar * const            frame,
                              vtss_vstax_rx_header_t * const vstax_header);

#endif /* VTSS_FEATURE_VSTAX */

/* ================================================================= *
 *  Layer 2
 * ================================================================= */

/* - MAC address table --------------------------------------------- */

/* MAC address entry */
typedef struct _vtss_mac_table_entry_t {
    vtss_vid_mac_t vid_mac;                           /* VLAN ID and MAC addr */
    BOOL           destination[VTSS_POAG_ARRAY_SIZE]; /* Dest. ports */
    BOOL           copy_to_cpu;                       /* CPU copy flag */
    BOOL           locked;                            /* Locked/static flag */
    BOOL           aged;                              /* Age flag */
} vtss_mac_table_entry_t;

/******************************************************************************
 * Description: Learn MAC address entry. 
 *
 * \param entry (input): MAC address entry structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_learn(const vtss_mac_table_entry_t * const entry);


/******************************************************************************
 * Description: Forget/unlearn MAC address entry. 
 *
 * \param vid_mac (input): VLAN ID and MAC address structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_forget_vid_mac(const vtss_vid_mac_t * const vid_mac);

/* The following flush/age/forget function can only be used if unlocked 
   entries have been not been learned from the CPU. Such entries can only
   be removed using vtss_mac_table_forget_vid_mac. */


/******************************************************************************
 * Description: Flush MAC address table, i.e. remove all unlocked entries.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_flush(void);

#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
typedef ulong vtss_mac_age_time_t;

/******************************************************************************
 * Description: Set MAC address table age time.
 *
 * \param age_time (input): MAC age time in seconds. Value zero disables aging. 
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_age_time_set(const vtss_mac_age_time_t age_time);
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */

/******************************************************************************
 * Description: Do age scan of the MAC address table. This should be done 
 *              periodically with interval T/2, where T is the age timer.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_age(void);


/******************************************************************************
 * Description: Do VLAN specific age scan of the MAC address table.
 *              This can be used if the age time is VLAN specific.
 *
 * \param vid (input): VLAN ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_age_vlan(const vtss_vid_t vid);


/******************************************************************************
 * Description: Forget MAC address entries learned on port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_forget_port(const vtss_port_no_t port_no);

#if defined(VTSS_FEATURE_AGGR_GLAG)
/******************************************************************************
 * Description: Forget MAC address entries learned on GLAG.
 *
 * \param glag_no (input): GLAG number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_forget_glag(const vtss_glag_no_t glag_no);
#endif /* VTSS_FEATURE_AGGR_GLAG */

/******************************************************************************
 * Description: Forget MAC address entries learned on VLAN ID.
 *
 * \param vid (input)    : VLAN ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_forget_vlan(const vtss_vid_t vid);

/******************************************************************************
 * Description: Forget MAC address entries learned on port and VLAN ID.
 *
 * \param port_no (input): Port number.
 * \param vid (input)    : VLAN ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_forget_port_in_vlan(const vtss_port_no_t port_no,
                                           const vtss_vid_t     vid);

/* Maximum number entries in the MAC address table */

#if defined(VTSS_ARCH_SPARX)
#define VTSS_MAC_ADDRS 8192
#endif /* VTSS_ARCH_SPARX */

#if defined(VTSS_ARCH_STANSTED)
#define VTSS_MAC_ADDRS 8192
#endif /* VTSS_ARCH_STANSTED */

#if defined(HEATHROW2)
#define VTSS_MAC_ADDRS 4096
#endif /* HEATHROW2 */

#if defined(VTSS_ARCH_STAPLEFORD)
#define VTSS_MAC_ADDRS 8192
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX)
#define VTSS_MAC_ADDRS 8192
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_MAC_ADDRS    16384 /* Fairoaks-Ie/Gatwick-Ie */
#define VTSS_MAC_ADDRS_GW 8192  /* Fairoaks/Gatwick */
#endif /* VTSS_ARCH_GATWICK */

#define VTSS_MAC_ADDR_START 1
#define VTSS_MAC_ADDR_END   (VTSS_MAC_ADDR_START+VTSS_MAC_ADDRS)

/******************************************************************************
 * Description: Read MAC address entry on a specific index.
 *
 * \param idx (input)   : MAC address table index.
 * \param entry (output): MAC address entry.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_read(const uint                     idx,
                            vtss_mac_table_entry_t * const entry);


/******************************************************************************
 * Description: Lookup MAC address entry.
 *
 * \param vid_mac (input): VLAN ID and MAC address.
 * \param entry (output) : MAC address entry.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_lookup(const vtss_vid_mac_t * const   vid_mac,
                              vtss_mac_table_entry_t * const entry);


/* MAC address table status */
typedef struct _vtss_mac_table_status_t {
    vtss_event_t learned;  /* One or more entries were learned */
    vtss_event_t replaced; /* One or more entries were replaced */
    vtss_event_t moved;    /* One or more entries moved to another port */
    vtss_event_t aged;     /* One or more entries were aged */
} vtss_mac_table_status_t;

/******************************************************************************
 * Description: Get MAC address table status.
 *
 * \param status (output): MAC address table status. 
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_status_get(vtss_mac_table_status_t * const status);

/******************************************************************************
 * Description: Lookup next MAC address entry.
 *
 * \param vid_mac (input): VLAN ID and MAC address.
 * \param entry (output) : MAC address entry.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mac_table_get_next(const vtss_vid_mac_t * const   vid_mac,
                                vtss_mac_table_entry_t * const entry);


/* - Learning options ---------------------------------------------- */

/* Learning mode */
typedef struct _vtss_learn_mode_t {
    BOOL automatic; /* Automatic learning done by switch chip (default enabled) */
    BOOL cpu;       /* Learn frames copied to CPU (default disabled) */
    BOOL discard;   /* Learn frames discarded (default disabled) */
} vtss_learn_mode_t;

#if defined(VTSS_FEATURE_LEARN_PORT)
/******************************************************************************
 * Description: Set the learn mode for a port.
 *
 * \param port_no (input)   : Port number.
 * \param learn_mode (input): Learn mode.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_learn_port_mode_set(const vtss_port_no_t      port_no,
                                 vtss_learn_mode_t * const learn_mode);
#endif /* VTSS_FEATURE_LEARN_PORT */ 

#if defined(VTSS_FEATURE_LEARN_SWITCH)
/******************************************************************************
 * Description: Set the learn mode for the switch.
 *
 * \param learn_mode (input): Learn mode.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_learn_mode_set(vtss_learn_mode_t * const learn_mode);
#endif /* VTSS_FEATURE_LEARN_SWITCH */ 


/* - Port STP State ------------------------------------------------ */

/* Spanning Tree state */
typedef enum _vtss_stp_state_t {
    VTSS_STP_STATE_DISABLED,   /* STP state disabled (admin/operational down) */
    VTSS_STP_STATE_BLOCKING,   /* STP state blocking */
    VTSS_STP_STATE_LISTENING,  /* STP state listening */
    VTSS_STP_STATE_LEARNING,   /* STP state learning */
    VTSS_STP_STATE_FORWARDING, /* STP state forwarding */
    VTSS_STP_STATE_ENABLED     /* STP unaware */
} vtss_stp_state_t;

/******************************************************************************
 * Description: Get Spanning Tree state for a port.
 *
 * \param port_no (input)   : Port number.
 * \param stp_state (output): STP state.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_stp_state_get(const vtss_port_no_t     port_no,
                                vtss_stp_state_t * const stp_state);

/******************************************************************************
 * Description: Set Spanning Tree state for a port.
 *
 * \param port_no (input)  : Port number.
 * \param stp_state (input): STP state.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_stp_state_set(const vtss_port_no_t   port_no,
                                const vtss_stp_state_t stp_state);


/* MSTP instance number: VTSS_MSTI_START..(VTSS_MSTI_END-1) */
typedef uint vtss_msti_t;

/* Number of MSTP instances */
#define VTSS_MSTIS           (65) /* Fairoaks-Ie/Gatwick-Ie */
#define VTSS_MSTIS_GW        (16) /* Fairoaks/Gatwick */
#define VTSS_MSTI_START      ((vtss_msti_t)1)
#define VTSS_MSTI_END        (VTSS_MSTI_START+VTSS_MSTIS)
#define VTSS_MSTI_ARRAY_SIZE VTSS_MSTI_END

/* MSTP state */
typedef enum _vtss_mstp_state_t {
    VTSS_MSTP_STATE_DISCARDING,
    VTSS_MSTP_STATE_LEARNING,
    VTSS_MSTP_STATE_FORWARDING
} vtss_mstp_state_t;

/******************************************************************************
 * Description: Set MSTP instance mapping for a VLAN.
 *
 * \param vid (input) : VLAN ID.
 * \param msti (input): MSTP instance.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mstp_vlan_set(const vtss_vid_t vid, 
                           const vtss_msti_t msti);

/******************************************************************************
 * Description: Set MSTP state for a port and MSTP instance.
 *
 * \param port_no (input): Port number.
 * \param msti (input)   : MSTP instance.
 * \param state (input)  : MSTP state.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_port_mstp_state_set(const vtss_port_no_t port_no, 
                                 const vtss_msti_t msti, 
                                 const vtss_mstp_state_t state);


/* - VLAN Port Mode ------------------------------------------------ */

/* VLAN port modes according to 802.1Q section 12.10.1 */

/* VLAN acceptable frame type */
typedef enum _vtss_vlan_frame_t {
    VTSS_VLAN_FRAME_ALL,    /* Accept all frames */
    VTSS_VLAN_FRAME_TAGGED  /* Accept tagged frames only */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    ,VTSS_VLAN_FRAME_UNTAGGED  /* Accept untagged frames only */
#endif /* VTSS_ARCH_HAWX/SPARX */
} vtss_vlan_frame_t;

/* VLAN port parameters */
typedef struct _vtss_vlan_port_mode_t {
    BOOL              aware;          /* VLAN awareness */
    vtss_vid_t        pvid;           /* Port VLAN ID (ingress) */
    vtss_vid_t        untagged_vid;   /* Port untagged VLAN ID  (egress) */
    vtss_vlan_frame_t frame_type;     /* Acceptable frame type (ingress) */
#if defined(VTSS_FEATURE_VLAN_INGR_FILTER_PORT)
    BOOL              ingress_filter; /* Ingress filtering */
#endif
} vtss_vlan_port_mode_t;

/******************************************************************************
 * Description: Get VLAN mode for port.
 *
 * \param port_no (input)   : Port number.
 * \param vlan_mode (output): VLAN port mode structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vlan_port_mode_get(const vtss_port_no_t          port_no,
                                vtss_vlan_port_mode_t * const vlan_mode);


/******************************************************************************
 * Description: Set VLAN mode for port.
 *
 * \param port_no (input)  : Port number.
 * \param vlan_mode (input): VLAN port mode structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vlan_port_mode_set(const vtss_port_no_t                port_no,
                                const vtss_vlan_port_mode_t * const vlan_mode);


/* - VLAN table ---------------------------------------------------- */

/******************************************************************************
 * Description: Get VLAN membership.
 *
 * \param vid (input)    : VLAN ID.
 * \param member (output): VLAN port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vlan_port_members_get(
    const vtss_vid_t vid,
    BOOL             member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Set VLAN membership.
 *
 * \param vid (input)   : VLAN ID.
 * \param member (input): VLAN port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vlan_port_members_set(
    const vtss_vid_t vid,
    BOOL             member[VTSS_PORT_ARRAY_SIZE]);


/* - Port Isolation------------------------------------------------- */

#if defined(VTSS_FEATURE_ISOLATED_PORT)

/******************************************************************************
 * Description: Enable/disable port isolation for VLAN.   
 *
 * \param vid (input)     : VLAN ID.
 * \param isolated (input): VLAN isolation enable/disable option.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_isolated_vlan_set(const vtss_vid_t vid,
                               const BOOL       isolated);

/******************************************************************************
 * Description: Set the isolated port set.   
 *
 * \param member (input): Port members.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

#endif /* VTSS_FEATURE_ISOLATED_PORT */


/* - Private VLAN (PVLAN) ------------------------------------------ */

/* Private VLAN Number: 1..VTSS_PVLANS */
typedef uint vtss_pvlan_no_t;  /* VTSS_PVLAN_NO_START..(VTSS_PVLAN_NO_END-1) */

#define VTSS_PVLANS            (VTSS_PORTS)

#define VTSS_PVLAN_NO_START    ((vtss_pvlan_no_t)1)
#define VTSS_PVLAN_NO_END      (VTSS_PVLAN_NO_START+VTSS_PVLANS)
#define VTSS_PVLAN_ARRAY_SIZE  VTSS_PVLAN_NO_END

#define VTSS_PVLAN_NO_DEFAULT  ((vtss_pvlan_no_t)1)


/******************************************************************************
 * Description: Get Private VLAN membership.
 *
 * \param pvlan_no (input): Private VLAN group number.
 * \param member (output) : Private VLAN port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_pvlan_port_members_get(
    const vtss_pvlan_no_t pvlan_no,
    BOOL                  member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Set Private VLAN membership.
 *
 * \param pvlan_no (input): Private VLAN group number.
 * \param member (input)  : Private VLAN port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_pvlan_port_members_set(
    const vtss_pvlan_no_t pvlan_no,
    const BOOL            member[VTSS_PORT_ARRAY_SIZE]);


/* - Aggregation --------------------------------------------------- */

/******************************************************************************
 * Description: Get aggregation port members.
 *
 * \param poag_no (input): Port/aggregation number.
 * \param member (output): Aggregation port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_aggr_port_members_get(
    const vtss_poag_no_t poag_no,
    BOOL                 member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Set aggregation port members.
 *
 * \param poag_no (input): Port/aggregation number.
 * \param member (input) : Aggregation port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_aggr_port_members_set(
    const vtss_poag_no_t poag_no,
    const BOOL           member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Get aggregation number for port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Port/aggregation number. If the port is not a member of an 
 *           aggregation, the port number itself is returned.
 ******************************************************************************/
vtss_poag_no_t vtss_aggr_port_member_get(const vtss_port_no_t port_no);


/******************************************************************************
 * Description: Set aggregation number for port.
 *
 * \param port_no (input): Port number.
 * \param poag_no (input): Port/aggregation number. If the port number itself
 *                         is used, the port is not a member of an aggregation.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_aggr_port_member_set(const vtss_port_no_t port_no,
                                  const vtss_poag_no_t poag_no);


/* Aggregation traffic distribution mode */
typedef struct _vtss_aggr_mode_t {
    BOOL smac_enable;        /* Source MAC address */
    BOOL dmac_enable;        /* Destination MAC address */   
#if defined(VTSS_FEATURE_AGGR_MODE_ADV)
#if defined(VTSS_ARCH_GATWICK)
    BOOL etype_enable;       /* Ethernet type */
    BOOL vlan_enable;        /* VLAN ID */
    BOOL mpls_enable;        /* MPLS label */
    BOOL ip_proto_enable;    /* IP protocol */
    BOOL sip_enable;         /* Source IP address */
    BOOL dip_enable;         /* Destination IP address */
    BOOL sport_enable;       /* Source UDP/TCP port */
    BOOL dport_enable;       /* Destination UDP/TCP port */
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_ARCH_HEATHROW)
    BOOL sip_dip_enable;     /* Source and destination IP address */
    BOOL sport_dport_enable; /* Source and destination UDP/TCP port */
#endif /* VTSS_ARCH_HEATHROW */
#endif /* VTSS_FEATURE_AGGR_MODE_ADV */
#if defined(VTSS_FEATURE_AGGR_MODE_RANDOM)
    BOOL random;             /* Pseudo random distribution */
#endif /* VTSS_FEATURE_AGGR_MODE_RANDOM */
} vtss_aggr_mode_t;

/******************************************************************************
 * Description: Set aggregation traffic distribution mode.
 *
 * \param mode (input): Distribution mode structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_aggr_mode_set(const vtss_aggr_mode_t * const mode);    

/* - Global link aggregations across stack ------------------------- */

#if defined(VTSS_FEATURE_AGGR_GLAG)

/******************************************************************************
 * Description: Get global aggregation port members.
 *
 * \param glag_no (input): GLAG number.
 * \param member (output): GLAG port member array.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_aggr_glag_members_get(const vtss_glag_no_t glag_no,
                                   BOOL member[VTSS_PORT_ARRAY_SIZE]);

/******************************************************************************
 * Description: Set global aggregation port members.
 *
 * \param glag_no (input): GLAG number.
 * \param member (input) : GLAG port member array.
 *                         Port number zero terminates the array.
 *                         The array includes the following ports:
 *                         - Local GLAG member ports in any state.
 *                         - Stack ports on the shortst path to each GLAG member
 *                           port in forwarding state on other unit. 
 *                         The ports must be sorted in a manner providing a 
 *                         unique index for each GLAG port member in the stack,
 *                         for example sorted by (unit, port).
 *
 *                         Example 1: 4-port GLAG
 *                         member[1] = 25; # Unit 1, port 2: Via stack port 25
 *                         member[2] = 7;  # Unit 2, port 7: Local port
 *                         member[3] = 26; # Unit 3, port 1: Via stack port 26
 *                         member[4] = 26; # Unit 3, port 2: Via stack port 26
 *                         member[5] = 0;  # Termination
 *                         
 *                         Example 2: Deleting a GLAG
 *                         member[1] = 0;
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_aggr_glag_set(vtss_glag_no_t glag_no,
                           vtss_port_no_t member[VTSS_GLAG_PORT_ARRAY_SIZE]);

#endif /* VTSS_FEATURE_AGGR_GLAG */

/* - Mirroring ----------------------------------------------------- */

/******************************************************************************
 * Description: Set the mirror destination port.
 *
 * \param port_no (input): Port number.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mirror_monitor_port_set(const vtss_port_no_t port_no);


/******************************************************************************
 * Description: Set the mirror ingress ports.
 *
 * \param member (input): Port number array. If a port is enabled in this array,
 *                        frames received on the port are mirrored.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mirror_ingress_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);


/******************************************************************************
 * Description: Set the mirror egress ports.
 *
 * \param member (input): Port number array. If a port is enabled in this array,
 *                        frames transmitted on the port are mirrored.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_mirror_egress_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);


#if !defined(HEATHROW2)

/* - IGMP  ----------------------------------------------------- */

/******************************************************************************
 * Description: Set IPv4 multicast flood mask.
 *
 * \param member (input): Port number array. Ports connected to IPv4 multicast
 *                        routers should be enabled.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipv4_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* - MLD  ----------------------------------------------------- */

#if defined(VTSS_FEATURE_CPU_RX_REG_MLD_ADV)

/******************************************************************************
 * Description: Set IPv6 multicast flood mask.
 *
 * \param member (input): Port number array. Ports connected to IPv6 multicast
 *                        routers should be enabled.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipv6_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

/******************************************************************************
 * Description: Set IPv6 multicast control flooding. This controls whether 
 *              unknown Link-Local scope IPv6 multicasts (FF02::/16) are flooded
 *              to all ports or to the ports in the IPv6 multicast flood mask.
 *
 * \param scope (input): IPv6 multicast control flood.
 *                       0: Flood to all ports.
 *                       1: Flood using IPv6 flood mask.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipv6_mc_ctrl_flood_set(const BOOL scope);

#endif /* VTSS_FEATURE_CPU_RX_REG_MLD_ADV */

#endif /* !HEATHROW2 */


#if defined(VTSS_FEATURE_LAYER3)
/* ================================================================= *
 *  Layer 3     
 * ================================================================= */

/* - IP forwarding ------------------------------------------------- */

/******************************************************************************
 * Description: Enable/disable L3 forwarding of IP frames (default enabled).
 *
 * \param enable (input): Boolean, TRUE to enable IP forwarding. 
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ip_forwarding_set(const BOOL enable);


/* - Router Legs --------------------------------------------------- */

/* Router Leg ID:  VTSS_RLID_START..(VTSS_RLID_END-1) */ 
typedef uint vtss_rlid_t;

/* Number of Router Legs */
#if defined(GATWICK) || defined(GATWICK48)
#define VTSS_RLIDS           (32) /* Gatwick, Gatwick-Ie or Gatwick-Ie 48-port */
#define VTSS_RLIDS_GW        (8)  /* Gatwick 48-port */ 
#endif 
#define VTSS_RLID_START      ((vtss_rlid_t)1)
#define VTSS_RLID_END        (VTSS_RLID_START+VTSS_RLIDS)
#define VTSS_RLID_ARRAY_SIZE VTSS_RLID_END

/* Router Leg control structure */
typedef struct _vtss_rl_t {
    vtss_vid_mac_t vid_mac;     /* VLAN ID and MAC address */
    BOOL           icmp_redir;  /* Enable ICMP redirect by CPU */
    BOOL           ipmc_enable; /* IP multicast enable */
    uchar          ipmc_ttl;    /* IP multicast TTL limit */
} vtss_rl_t;

/******************************************************************************
 * Description: Add Router Leg.
 *
 * \param rlid (input): Router Leg ID, unique number identifying a Router Leg.
 * \param rl (input)  : Router Leg structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_rl_add(const vtss_rlid_t rlid,
                    const vtss_rl_t * const rl);


/******************************************************************************
 * Description: Delete Router Leg.
 *
 * \param rlid (input): Router Leg ID, unique number identifying a Router Leg.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_rl_del(const vtss_rlid_t rlid);


/* - VRRP ---------------------------------------------------------- */

/* Virtual Router ID, 1-255 */ 
typedef uint vtss_vrid_t;

/* Maximum number of VRIDs per Router Leg */
#define VTSS_VRIDS (2)

/******************************************************************************
 * Description: Set VRRP base address (default 00-00-5E-00-01-00).
 *
 * \param mac (input): MAC address, the upper 40 bit are used.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vrrp_addr_set(const vtss_mac_t mac);


/******************************************************************************
 * Description: Add Virtual Router on Router Leg.
 *
 * \param vrid (input): Virtual Router ID.
 * \param rlid (input): Router Leg ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vrrp_vrid_add(const vtss_vrid_t vrid, const vtss_rlid_t rlid);


/******************************************************************************
 * Description: Delete Virtual Router from Router Leg.
 *
 * \param vrid (input): Virtual Router ID.
 * \param rlid (input): Router Leg ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_vrrp_vrid_del(const vtss_vrid_t vrid, const vtss_rlid_t rlid);


/* - IP Unicast table ---------------------------------------------- */

#define VTSS_ROUTER_NONE    (vtss_ip_t)0x00000000 /* Local/direct routes */
#define VTSS_ROUTER_DISCARD (vtss_ip_t)0xFFFFFFFF /* Discard route, to CPU */

/******************************************************************************
 * Description: Add IP unicast forwarding entry.
 *
 * \param net (input)   : IP network address.
 * \param mask (input)  : IP network mask.
 * \param router (input): IP address of next hop router, zero if local route.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipuc_add(const vtss_ip_t net,
                      const vtss_ip_t mask,
                      const vtss_ip_t router);


/******************************************************************************
 * Description: Delete IP unicast forwarding entry.
 *
 * \param net (input) : IP network address.
 * \param mask (input): IP network mask.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipuc_del(const vtss_ip_t net,
                      const vtss_ip_t mask);


/* - ARP table ----------------------------------------------------- */

/* ARP control structure */
typedef struct _vtss_arp_t {
    vtss_mac_t  dmac; /* Destination MAC address */
    vtss_rlid_t rlid; /* Egress Router Leg ID */
} vtss_arp_t;

/******************************************************************************
 * Description: Add ARP entry.
 *
 * \param dip (input): Destination IP address.
 * \param arp (input): ARP structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_arp_add(const vtss_ip_t dip,
                     const vtss_arp_t *arp);


/******************************************************************************
 * Description: Delete ARP entry.
 *
 * \param dip (input): Destination IP address.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_arp_del(const vtss_ip_t dip);


/* - IP Unicast security ------------------------------------------- */

/******************************************************************************
 * Description: Enable/disable IP unicast security.
 *
 * \param enable (input): Boolean, TRUE to enable IP unicast security.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipuc_security_set(const BOOL enable);


/******************************************************************************
 * Description: Enable/disable IP unicast forwarding between Router Legs.
 *
 * \param irlid (input) : Ingress Router Leg ID.
 * \param erlid (input) : Egress Router Leg ID.
 * \param enable (input): Boolean, TRUE to allow forwarding.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipuc_secur_rl_set(const vtss_rlid_t irlid,
                               const vtss_rlid_t erlid,
                               const BOOL enable);


/* - IP Multicast table -------------------------------------------- */

/* IP multicast control structure */
typedef struct _vtss_ipmc_t {
    BOOL        rpf_enable;                  /* Reverse Path Forwarding check */
    vtss_rlid_t irlid;                       /* Ingress Router Leg, RPF check */
    BOOL        erlid[VTSS_RLID_ARRAY_SIZE]; /* Egress Router Leg list */
} vtss_ipmc_t;

/******************************************************************************
 * Description: Add IP multicast entry for (SIP, DIP) pair.
 *
 * \param sip (input) : Source IP address.
 * \param dip (input) : Destination IP address.
 * \param ipmc (input): IP multicast structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipmc_add(const vtss_ip_t sip,
                      const vtss_ip_t dip,
                      const vtss_ipmc_t *ipmc);


/******************************************************************************
 * Description: Delete IP multicast entry for (SIP, DIP) pair.
 *
 * \param sip (input) : Source IP address.
 * \param dip (input) : Destination IP address.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ipmc_del(const vtss_ip_t sip,
                      const vtss_ip_t dip);


/* - IP counters per switch ---------------------------------------- */

/* IP counters per switch */
typedef struct _vtss_ip_counters_t {
    vtss_counter_t rx_packets;         /* Received packets */
    vtss_counter_t tx_uc_packets;      /* Forwarded IP unicast packets */
    vtss_counter_t tx_mc_packets;      /* Forwarded IP multicast packets */
    vtss_counter_t secur_fail_packets; /* IP unicast security fails */
} vtss_ip_counters_t;

/******************************************************************************
 * Description: Update IP counters.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ip_counters_update(void);


/******************************************************************************
 * Description: Clear IP counters.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ip_counters_clear(void);


/******************************************************************************
 * Description: Get IP counters.
 *
 * \param counters (output): IP counters structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_ip_counters_get(vtss_ip_counters_t * const counters);


/* - IP counters per Router Leg ------------------------------------ */

/* IP counters per Router Leg */
typedef struct _vtss_rl_counters_t {
    vtss_counter_t rx_octets;      /* Received IP bytes */
    vtss_counter_t tx_uc_octets;   /* Forwarded IP unicast bytes */

    vtss_counter_t rx_uc_packets;  /* Received IP unicast packets */
    vtss_counter_t rx_mc_packets;  /* Received IP multicast packets */
    vtss_counter_t rx_rpf_packets; /* Failed RPF packets */

    vtss_counter_t tx_uc_packets;  /* Forwarded IP unicast packets */
} vtss_rl_counters_t;

/******************************************************************************
 * Description: Update Router Leg counters.
 *
 * \param rlid (input): Router Leg ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_rl_counters_update(const vtss_rlid_t rlid);


/******************************************************************************
 * Description: Clear Router Leg counters.
 *
 * \param rlid (input): Router Leg ID.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_rl_counters_clear(const vtss_rlid_t rlid);


/******************************************************************************
 * Description: Get Router Leg counters.
 *
 * \param rlid (input)     : Router Leg ID.
 * \param counters (output): Router Leg counters structure.
 *
 * \return : Return code.
 ******************************************************************************/
vtss_rc vtss_rl_counters_get(const vtss_rlid_t rlid,
                             vtss_rl_counters_t * const counters);

#endif /* VTSS_FEATURE_LAYER3 */

#endif /* _VTSS_AL_H_ */

