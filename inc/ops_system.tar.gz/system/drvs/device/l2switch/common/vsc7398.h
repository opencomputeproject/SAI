#ifndef _VSC7398_H
#define _VSC7398_H

uint vtss7398_sizeof_al(void);
uint vtss7398_learn_mode_set(vtss_learn_mode_t* vtss_learn_mode);
void vtss7398_enable_port(uint8_t port);
void vtss7398_disable_port(uint8_t port);
void vtss7398_port_get_stats(uint8_t port, port_stats_t *stats);
int vtss7398_en_phy_loopback(uint8_t port);
int vtss7398_en_phy_far_end_loopback(uint8_t port);
int vtss7398_dis_phy_loopback(uint8_t port);
int vtss7398_dis_phy_far_end_loopback(uint8_t port);
vtss_rc vtss7398_phy_read (const vtss_port_no_t port_no, const uint reg, ushort *const value);
vtss_rc vtss7398_phy_write(const vtss_port_no_t port_no, const uint reg, const ushort value);
vtss_rc vtss7398_register_read(const ulong reg, ulong *value);
vtss_rc vtss7398_register_write(const ulong reg, ulong value);
vtss_rc vtss7398_select_chip(vtss_state_t * const state);
vtss_rc vtss7398_vlan_port_members_set(const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE]);
vtss_rc vtss7398_vlan_port_mode_set(const vtss_port_no_t port_no, const vtss_vlan_port_mode_t * const vlan_mode);
vtss_rc vtss7398_poag_counters_clear(const vtss_poag_no_t poag_no);
vtss_rc ht7398_wr_xx(uint blk, uint sub, uint reg, ulong value);
vtss_rc ht7398_rd_xx(uint blk, uint sub, uint reg, ulong *value);
vtss_rc vtss7398_init(const vtss_init_setup_t * const setup);
vtss_rc vtss7398_port_map_set(const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE]);
vtss_rc vtss7398_phy_reset(const vtss_port_no_t port_no, const vtss_phy_reset_setup_t * const setup);
vtss_rc vtss7398_phy_setup(const vtss_port_no_t port_no, const vtss_phy_setup_t * const setup);
vtss_rc vtss7398_port_stp_state_set(const vtss_port_no_t port_no, const vtss_stp_state_t stp_state);
vtss_rc vtss7398_port_setup(const vtss_port_no_t port_no, const vtss_port_setup_t * const setup);
vtss_rc vtss7398_port_enable(const vtss_port_no_t port_no, const BOOL enable);
vtss_rc vtss7398_mac_table_learn(const vtss_mac_table_entry_t * const entry);
uint vtss7398_sizeof_al(void); 
uint vtss7398_phy_sizeof_al( const uint ports );
vtss_rc vtss7398_chipid_get(vtss_chipid_t * const chipid);
vtss_rc vtss7398_port_status_get(const vtss_port_no_t port_no, vtss_port_status_t * const status);
vtss_rc vtss7398_vlan_port_mode_get(const vtss_port_no_t port_no, vtss_vlan_port_mode_t * const vlan_mode);
vtss_rc vtss7398_poag_counters_get(const vtss_poag_no_t poag_no, vtss_poag_counters_t *const big_counters);

#endif
