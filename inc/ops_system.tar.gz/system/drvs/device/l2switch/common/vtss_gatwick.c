/*

 Vitesse Switch software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_gatwick.c,v 1.82 2007/05/15 12:52:36 cpj Exp $
 $Revision: 1.82 $

*/

#define VTSS_TRACE_LAYER 2
#define VTSS_TRACE_FILE "ll"

/* Standard headers */
#include <string.h>

/* API public headers */
#include "vtss_switch_api.h"

/* API private headers */
#include "vtss_state.h"
#include "vtss_gatwick_reg.h"
#include "gatwick_qs.h"
#include "vtss_cil.h"

#ifdef VTSS_CHIPS
#define GW_LEARN_QUEUE VTSS_CPU_RX_QUEUE_END
#endif /* VTSS_CHIPS */

/* Unused port on chip */
#define PORT_ON_CHIP_RESV 1

#define GW_RD(tgt,reg,port_on_chip,value) \
{ \
    vtss_rc rc; \
    if ((rc=gw_rd(T_##tgt,R_##tgt##_##reg,port_on_chip,value))<0) \
        return rc; \
}

#define GW_WR(tgt,reg,port_on_chip,value) \
{ \
    vtss_rc rc; \
    if ((rc=gw_wr(T_##tgt,R_##tgt##_##reg,port_on_chip,value))<0) \
        return rc; \
}

#define GW_WR_MASKED(tgt,reg,port_on_chip,value,mask) \
{ \
    vtss_rc rc; \
    if ((rc=gw_wr_masked(T_##tgt,R_##tgt##_##reg,port_on_chip,value,mask))<0) \
        return rc; \
}

#define GW_RDF(tgt,reg,fld,port_on_chip,value) \
{ \
    vtss_rc rc; \
    if ((rc=gw_rdf(T_##tgt,R_##tgt##_##reg,O_##tgt##_##reg##_##fld,M_##tgt##_##reg##_##fld,port_on_chip,value))<0) \
        return rc; \
}

#define GW_WRF(tgt,reg,fld,port_on_chip,value) \
{ \
    vtss_rc rc; \
    if ((rc=gw_wrf(T_##tgt,R_##tgt##_##reg,O_##tgt##_##reg##_##fld,M_##tgt##_##reg##_##fld,port_on_chip,value))<0) \
        return rc; \
}

#define GW_PI_RD(tgt,reg,value) \
{ \
    vtss_rc rc; \
    if ((rc=vtss_io_pi_rd(T_##tgt,R_##tgt##_##reg,value))<0) \
        return rc; \
}

#define GW_PI_WR(tgt,reg,value) \
{ \
    vtss_rc rc; \
    if ((rc=vtss_io_pi_wr(T_##tgt,R_##tgt##_##reg,value))<0) \
        return rc; \
}

#define GW_PI_RDF(tgt,reg,fld,value) \
{ \
    vtss_rc rc; \
    if ((rc=vtss_io_pi_rd(T_##tgt,R_##tgt##_##reg,value))<0) \
        return rc; \
    *value = ((*value >> O_##tgt##_##reg##_##fld) & M_##tgt##_##reg##_##fld); \
}

#define GW_PI_WRF(tgt,reg,fld,value) \
{ \
    vtss_rc rc; \
    ulong   val,mask; \
    if ((rc=vtss_io_pi_rd(T_##tgt,R_##tgt##_##reg,&val))<0) \
        return rc; \
    mask = (M_##tgt##_##reg##_##fld << O_##tgt##_##reg##_##fld); \
    val = ((val & ~mask) | ((value << O_##tgt##_##reg##_##fld) & mask)); \
    if ((rc=vtss_io_pi_wr(T_##tgt,R_##tgt##_##reg,val))<0) \
        return rc; \
}

/****************************************************************************
 *** Target read/write functions ********************************************
 ****************************************************************************/
#if defined(VTSS_CHIPS)
static vtss_rc gw_port_setup_internal(BOOL init);
#endif /* VTSS_CHIPS */

static vtss_rc gw_mstp_table_write(uint port_on_chip, uint msti, BOOL learn, BOOL forward);

#if defined(VTSS_FEATURE_LAYER3)
static vtss_rc gw_rl_vlan_update(vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE]);
#endif /* VTSS_FEATURE_LAYER3 */

/* Remap target and register for port and read/write */
static vtss_rc gw_rd_wr(uint target, uint address, uint port_on_chip, ulong *value, BOOL write)
{
    vtss_rc rc;
    uint    offset,index;
    const   char *str,*oper;
    
    oper=(write ? "gw_wr" : "gw_rd");
    if (port_on_chip>VTSS_CHIP_PORTS || (port_on_chip<8 && (port_on_chip % 4))) {
        VTSS_E(("%s: illegal port_on_chip: %d, target: %d, address: %d",
                oper,port_on_chip,target,address));
        return VTSS_INVALID_PARAMETER;
    }

    offset=0;
    index=(port_on_chip/4);
    switch (target) {
    case T_CPU_CCA:
        str="cpu_cca";
        break;
    case T_CPU_GM:
        str="cpu_gm";
        break;
    case T_CPU_MWR:
        str="cpu_mwr";
        break;
    case T_AR:
        str="ar";
        break;
    case T_AN_RL_L3:
        str="an_rl_l3";
        break;
    case T_AN_L2_PS:
        str="an_l2_ps";
        break;
    case T_RXP:
        str="rxp";
        offset=0x20;
        break;
    case T_TXP:
        str="txp";
        offset=0x20;
        break;
    case T_D10_MAC:
        if (port_on_chip!=0 && port_on_chip!=4) {
            VTSS_E(("%s: d10_mac, illegal port_on_chip: %d",oper,port_on_chip));
            return VTSS_INVALID_PARAMETER;
        }
        str="mac";
        offset=0x10; /* Offset not used, but indicates that it is a port target */
        break;
    case T_SE:
        str="se";
        offset=0x40;
        break;
    case T_D4_MAC:
        if (port_on_chip<8) {
            VTSS_E(("%s: d4_mac, illegal port_on_chip: %d",oper,port_on_chip));
            return VTSS_INVALID_PARAMETER;
        }
        str="mac";
        offset=0x10;
        index=((port_on_chip-8)/4);
        break;
    default:
        VTSS_E(("%s: unknown base target: %d",oper,target));
        return VTSS_INVALID_PARAMETER;
    }
    
    if (offset==0) {
        /* Non-port target */
        if (port_on_chip!=0) {
            VTSS_E(("%s, target 0x%02x (%s): illegal port_on_chip: %d",oper,target,str,port_on_chip));
            return VTSS_INVALID_PARAMETER;
        }
        VTSS_N(("%s, target: 0x%02x (%s), address: 0x%02x, value: 0x%08lx (%s)",
                oper,target,str,address,*value,write ? "writing" : "reading"));
    } else {
        /* Port target */
        target+=(4*index);
        address+=((port_on_chip%4)*offset);
        VTSS_N(("%s, target: 0x%02x (%s_%s_%d), address: 0x%02x, value: 0x%08lx (%s)",
                oper,target, 
                port_on_chip<8 ? "d10" : "d4",str,port_on_chip<8 ? index : (port_on_chip-8)/4,
                address,*value,write ? "writing" : "reading"));
    }
    
    if (write) {
        if (vtss_api_state->init_setup.use_cpu_si)
            rc = vtss_io_si_wr(target,address,*value);
        else
            rc = vtss_io_pi_tgt_wr(target,address,*value);
    } else {
        if (vtss_api_state->init_setup.use_cpu_si)
            rc = vtss_io_si_rd(target,address,value);
        else
            rc = vtss_io_pi_tgt_rd(target,address,value);
    }

    if (offset==0) {
        /* Non-port target */
        VTSS_N(("%s, target: 0x%02x (%s), address: 0x%02x, value: 0x%08lx (%s)",
                oper,target,str,address,*value,write ? "wrote" : "read"));
    } else {
        /* Port target */
        VTSS_N(("%s, target: 0x%02x (%s_%s_%d), address: 0x%02x, value: 0x%08lx (%s)",
                oper,target,
                port_on_chip<8 ? "d10" : "d4",str,port_on_chip<8 ? index : (port_on_chip-8)/4,
                address,*value,write ? "wrote" : "read"));
    }

    return rc;
}

/* Read target register using current CPU interface */
static vtss_rc gw_rd(uint target, uint address, uint port_on_chip, ulong *value)
{
    return gw_rd_wr(target,address,port_on_chip,value,0);
}

/* Write target register using current CPU interface */
static vtss_rc gw_wr(uint target, uint address, uint port_on_chip, ulong value)
{
    return gw_rd_wr(target,address,port_on_chip,&value,1);
}

/* Read-modify-write target register using current CPU interface */
static vtss_rc gw_wr_masked(uint target, uint address, uint port_on_chip, 
                            ulong value, ulong mask)
{
    vtss_rc rc;
    ulong   val;

    if (value & ~mask) {
        VTSS_E(("illegal value: 0x%08lx, mask: 0x%08lx, target: 0x%02x, address: 0x%02x",
           value,mask,target,address));
        rc = VTSS_INVALID_PARAMETER;
    } else if ((rc = gw_rd(target,address,port_on_chip,&val))>=0) {
        rc = gw_wr(target,address,port_on_chip,(val & ~mask) | value);
    }
    return rc;
}

/* Read target register field using current CPU interface */
static vtss_rc gw_rdf(uint target, uint address, uint offset, ulong mask, 
                      uint port_on_chip, ulong *value)
{
    vtss_rc rc;
    
    rc = gw_rd(target,address,port_on_chip,value);
    *value = ((*value >> offset) & mask);

    return rc;
}

/* Read-modify-write target register field using current CPU interface */
static vtss_rc gw_wrf(uint target, uint address, uint offset, ulong mask, 
                      uint port_on_chip, ulong value)
{
    vtss_rc rc;
    ulong   val,msk;
    
    msk=(mask << offset);
    if ((rc = gw_rd(target,address,port_on_chip,&val))>=0) {
        rc = gw_wr(target,address,port_on_chip,(val & ~msk) | ((value << offset) & msk));
    }
    
    return rc;
}

/****************************************************************************
 *** Various utilities ******************************************************
 ****************************************************************************/

/* Convert port list to chip port mask */
#if defined(VTSS_CHIPS)
static ulong gw_list2mask(vtss_chip_no_t chip_no, const BOOL member[VTSS_PORT_ARRAY_SIZE])
#else
static ulong gw_list2mask(const BOOL member[VTSS_PORT_ARRAY_SIZE])
#endif /* VTSS_CHIPS */
{
    vtss_port_no_t port_no;
    int            port_on_chip;
    ulong          mask;
    BOOL           port_member;

    mask=0;
    for (port_no=VTSS_PORT_NO_START; port_no<VTSS_PORT_NO_END; port_no++) {
#if defined(VTSS_CHIPS)
        port_member=(member[port_no] && vtss_api_state->port_map.chip_no[port_no]==chip_no);
#else
        port_member=member[port_no];
#endif /* VTSS_CHIPS */
        if (port_member) {
            port_on_chip=vtss_api_state->port_map.chip_port[port_no];
            if (port_on_chip>=0) {
                mask|=(1<<port_on_chip);
            }
        }
    }
    return mask;
}
    
/* Convert high level PGID number to PGID number on chip */
static uint gw_pgid_on_chip(vtss_pgid_no_t pgid_no) 
{
    uint pgid_on_chip;
    
#if defined(VTSS_CHIPS)
    if (vtss_api_state->gw1e) {
        if (pgid_no<VTSS_PGID_UNICAST_END) {
            pgid_on_chip=(pgid_no-VTSS_PGID_START+VTSS_PGID_GLAG_START);
        } else {
            if (pgid_no<(VTSS_PGID_START+VTSS_PORTS+VTSS_PGID_GLAG_START)) {
                pgid_on_chip=(pgid_no-VTSS_PGID_START-VTSS_PORTS);
            } else {
                pgid_on_chip=(pgid_no-VTSS_PGID_START);
            }
        }
        return pgid_on_chip;
    }
#endif /* VTSS_CHIPS */
    if (pgid_no<VTSS_PGID_UNICAST_END) {
        pgid_on_chip=vtss_api_state->port_map.chip_port[pgid_no];
    } else {
        pgid_on_chip=(pgid_no+VTSS_CHIP_PORTS-VTSS_PORTS-VTSS_PGID_START);
    }
    return pgid_on_chip;
}

/* Convert PGID number on chip to high level PGID number */
#if defined(VTSS_CHIPS)
static vtss_pgid_no_t gw_pgid_on_hl(vtss_chip_no_t chip_no, uint pgid_on_chip) 
#else
static vtss_pgid_no_t gw_pgid_on_hl(uint pgid_on_chip) 
#endif /* VTSS_CHIPS */
{
    vtss_pgid_no_t pgid_no;
#if defined(VTSS_CHIPS)
    if (vtss_api_state->gw1e) {
        if (pgid_on_chip<VTSS_PGID_GLAG_START) {
            pgid_no=(pgid_on_chip+VTSS_PGID_START+VTSS_PORTS);
        } else if (pgid_on_chip<(VTSS_PGID_GLAG_START+VTSS_PORTS)) {
            pgid_no=(pgid_on_chip-VTSS_PGID_GLAG_START+VTSS_PGID_START);
        } else {
            pgid_no=(pgid_on_chip+VTSS_PGID_START);
        }
        return pgid_no;
    }
#endif /* VTSS_CHIPS */
    if (pgid_on_chip<VTSS_CHIP_PORTS) {
#if defined(VTSS_CHIPS)
        pgid_no=vtss_api_state->port_map.vtss_port[chip_no][pgid_on_chip];
#else
        pgid_no=vtss_api_state->port_map.vtss_port[pgid_on_chip];
#endif /* VTSS_CHIPS */
    } else {
        pgid_no=(pgid_on_chip+VTSS_PORTS+VTSS_PGID_START-VTSS_CHIP_PORTS);
    }
    return pgid_no;
}

/****************************************************************************
 *** Port Control ***********************************************************
 ****************************************************************************/

/* Handle PHY commands, assuming the register layout is the same for the MII busses */
static vtss_rc gw_mii_cmd(uint phy_cmd, uint sof, uint miim_controller, 
                          uint phy_addr, uint phy_reg, ushort *data)
{
    uint    offset;
    ulong   value;

    switch (miim_controller) {
    case VTSS_MIIM_CONTROLLER_0:
        offset = R_CPU_GM_MII_STATUS_1G;
        break;
    case VTSS_MIIM_CONTROLLER_1:
        offset = R_CPU_GM_MII_STATUS_10G_0;
        break;
    case VTSS_MIIM_CONTROLLER_2:
        offset = R_CPU_GM_MII_STATUS_10G_1;
        break;
    default:
        VTSS_E(("illegal miim_controller: %d",miim_controller));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Read command is different for Clause 22 */
    if (sof==1 && phy_cmd==PHY_CMD_READ) {
        phy_cmd=PHY_CMD_READ_INC;
    }

    /* Set Start of frame field */
    GW_WR_MASKED(CPU_GM,MII_CFG_1G+offset,0,
                 sof<<O_CPU_GM_MII_CFG_1G_START_OF_FRAME_CFG_1G,
                 M_CPU_GM_MII_CFG_1G_START_OF_FRAME_CFG_1G<<O_CPU_GM_MII_CFG_1G_START_OF_FRAME_CFG_1G);

    /* Issue command */
    GW_WR(CPU_GM,MII_COMMAND_1G+offset,0,
          (phy_cmd<<O_CPU_GM_MII_COMMAND_1G_ACCESS_TYPE_1G) |
          (phy_addr<<O_CPU_GM_MII_COMMAND_1G_PHY_ADDR_1G) | 
          (phy_reg<<O_CPU_GM_MII_COMMAND_1G_REG_ADDR_1G) | 
          (*data<<O_CPU_GM_MII_COMMAND_1G_WRITE_DATA_1G) |
          (0<<O_CPU_GM_MII_COMMAND_1G_SCAN_ENA_1G));
    
    /* Wait for access to complete */
    while (1) {
        GW_RD(CPU_GM,MII_STATUS_1G+offset,0,&value);
        
        if ((value & 
             ((M_CPU_GM_MII_STATUS_1G_WRITE_IN_PROGRESS_1G<<
               O_CPU_GM_MII_STATUS_1G_WRITE_IN_PROGRESS_1G) | 
              (M_CPU_GM_MII_STATUS_1G_READ_IN_PROGRESS_1G<<
               O_CPU_GM_MII_STATUS_1G_READ_IN_PROGRESS_1G)))==0)
            break;
    }

    /* Read data if it is a read command */
    if (phy_cmd == PHY_CMD_READ || phy_cmd == PHY_CMD_READ_INC) {
        GW_RD(CPU_GM,MII_DATA_1G+offset,0,&value);
        if (TRF(value,CPU_GM,MII_DATA_1G,READ_ERR_1G))
            return VTSS_PHY_READ_ERROR;
        *data = TRF(value,CPU_GM,MII_DATA_1G,READ_DATA_1G);
    }

    return VTSS_OK;
}

vtss_rc vtss_ll_phy_read(uint miim_controller, uint phy_addr, uint phy_reg, ushort *value)
{
    VTSS_N(("miim_controller: %d, phy_addr: 0x%02x, phy_reg: 0x%02x",
            miim_controller,phy_addr,phy_reg));

    return gw_mii_cmd(PHY_CMD_READ,1,miim_controller,phy_addr,phy_reg,value);
}

vtss_rc vtss_ll_phy_write(uint miim_controller, uint phy_addr, uint phy_reg, ushort value)
{
    VTSS_N(("miim_controller: %d, phy_addr: 0x%02x, phy_reg: 0x%02x, value: 0x%04x",
            miim_controller,phy_addr,phy_reg,value));
    
    return gw_mii_cmd(PHY_CMD_WRITE,1,miim_controller,phy_addr,phy_reg, &value);
}

vtss_rc vtss_ll_mmd_read(uint miim_controller, uint phy_addr, uint mmd, uint address, ushort *value)
{
    ushort addr = address;

    VTSS_N(("mii_controller: %d, phy_addr: 0x%02x, mmd: 0x%02x",
            miim_controller,phy_addr,mmd));
    
    VTSS_RC(gw_mii_cmd(PHY_CMD_ADDRESS,0,miim_controller,phy_addr,mmd,&addr));
    return gw_mii_cmd(PHY_CMD_READ,0,miim_controller,phy_addr,mmd,value);
}

vtss_rc vtss_ll_mmd_write(uint miim_controller, uint phy_addr, uint mmd, uint address, ushort data)
{
    ushort addr = address;

    VTSS_N(("mii_controller: %d, phy_addr: 0x%02x, mmd: 0x%02x, data: 0x%04x",
            miim_controller,phy_addr,mmd,data));

    VTSS_RC(gw_mii_cmd(PHY_CMD_ADDRESS,0,miim_controller,phy_addr,mmd,&addr));
    return gw_mii_cmd(PHY_CMD_WRITE,0,miim_controller,phy_addr,mmd,&data);
}

#if defined(BOARD_JETWAY48)
static vtss_rc gw_mmd_write_masked(uint miim_controller, uint phy_addr, uint mmd, uint address, ushort value, ushort mask)
{
    ushort data;

    VTSS_RC(vtss_ll_mmd_read(miim_controller, phy_addr, mmd, address, &data));

    return vtss_ll_mmd_write(miim_controller, phy_addr, mmd, address, 
                             (data & ~mask) | (value & mask));
}
#endif /* BOARD_JETWAY48 */

vtss_rc vtss_ll_port_tbi_enabled(uint port_no, BOOL *enabled)
{
    uint  port_on_chip = vtss_api_state->port_map.chip_port[port_no];
    ulong value;
    
    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
    
    GW_RDF(D4_MAC,MODE_CFG,TBI_MODE,port_on_chip,&value);
    *enabled = MAKEBOOL01(value);
    return VTSS_OK;
}    

vtss_rc vtss_ll_port_tbi_autoneg_enabled(uint port_no, BOOL *enabled)
{
    uint  port_on_chip = vtss_api_state->port_map.chip_port[port_no];
    ulong value;

    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
    
    GW_RDF(D4_MAC,TBI_CFG,AN_ENA,port_on_chip,&value);
    *enabled = MAKEBOOL01(value);
    return VTSS_OK;
}

vtss_rc vtss_ll_port_tbi_get_aneg_advertisement(uint port_no,
                                                vtss_autoneg_1000base_x_advertisement_t * advertisement )
{
    uint port_on_chip = vtss_api_state->port_map.chip_port[port_no];
    ulong value;

    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    GW_RDF(D4_MAC,TBI_STATUS,LPA,port_on_chip,&value);

    advertisement->fdx      = MAKEBOOL01(value &   (1<< 5));
    advertisement->hdx      = MAKEBOOL01(value &   (1<< 6));
    advertisement->symmetric_pause  = MAKEBOOL01(value &   (1<< 7));
    advertisement->asymmetric_pause = MAKEBOOL01(value &   (1<< 8));
    advertisement->remote_fault     =           (value & (0x3<<12)) >> 12;
    advertisement->acknowledge      = MAKEBOOL01(value &   (1<<14));
    advertisement->next_page        = MAKEBOOL01(value &   (1<<15));

    return VTSS_OK;
}

vtss_rc vtss_ll_port_tbi_aneg_enable(uint port_no,
                                     const vtss_autoneg_1000base_x_advertisement_t *adv)
{
    BOOL enabled;
    uint port_on_chip = vtss_api_state->port_map.chip_port[port_no];

    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    
    /* Restart if autoneg enabled */
    VTSS_RC(vtss_ll_port_tbi_autoneg_enabled(port_no,&enabled));
    if (!enabled) { 
        GW_WRF(D4_MAC,TBI_CFG,AN_ENA,port_on_chip,1);
        GW_WRF(D4_MAC,TBI_CFG,AN_RESTART,port_on_chip,1);
    }
    
    GW_WRF(D4_MAC,TBI_CFG,DAR,port_on_chip,
           (adv->fdx ? (1<<5) : 0) |
           (adv->hdx ? (1<<6) : 0) |
           (adv->symmetric_pause ? (1<<7) : 0) |
           (adv->asymmetric_pause ? (1<<8) : 0) |
           (adv->remote_fault ? (1<<12) : 0) |
           (adv->acknowledge ? (1<<14) : 0) |
           (adv->next_page ? (1<<15) : 0));
    return VTSS_OK;
}

vtss_rc vtss_ll_port_tbi_aneg_restart(uint port_no)
{
    uint port_on_chip = vtss_api_state->port_map.chip_port[port_no];

    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    return gw_wrf(TROM(D4_MAC,TBI_CFG,AN_RESTART),port_on_chip,1);
}

vtss_rc vtss_ll_port_tbi_status_get(uint port_no, vtss_tbi_status_t *status)
{
    uint  port_on_chip = vtss_api_state->port_map.chip_port[port_no];
    ulong value;

    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    GW_RD(D4_MAC,TBI_STATUS,port_on_chip,&value);
    
    status->link_status = TRF(value, D4_MAC,TBI_STATUS, LINK_STATUS);
    status->link_down_counter = TRF(value, D4_MAC, TBI_STATUS, LINK_DOWN_CNT); 
    switch (TRF(value, D4_MAC, TBI_STATUS, XMIT_MODE)) {
    case 0:
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_IDLE;
        break;
    case 1:
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_CONFIG;
        break;
    case 3:
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_DATA;
        break;
    default:
        VTSS_E(("Illegal TBI PCS state"));
        break;
    }
    status->autoneg.priority_resolution = TRF(value, D4_MAC,TBI_STATUS, PR);
    status->autoneg.complete = TRF(value, D4_MAC,TBI_STATUS, ANC);
    status->autoneg.partner_advertisement.fdx = MAKEBOOL01(value & (1<<5));
    status->autoneg.partner_advertisement.hdx = MAKEBOOL01(value & (1<<6));
    status->autoneg.partner_advertisement.symmetric_pause = MAKEBOOL01(value & (1<<7));
    status->autoneg.partner_advertisement.asymmetric_pause = MAKEBOOL01(value & (1<<8));
    status->autoneg.partner_advertisement.remote_fault = ((value & (0x3<<12))>>12);
    status->autoneg.partner_advertisement.acknowledge = MAKEBOOL01(value & (1<<14));
    status->autoneg.partner_advertisement.next_page = MAKEBOOL01(value & (1<<15));
    return VTSS_OK;
}

static vtss_rc gw_port_queue_setup(uint port_on_chip, BOOL fc_rx, BOOL fc_tx) 
{
    uint prios;
    uint wm_high,wm_low,queue_lvl_3,queue_lvl_2,queue_lvl_1,queue_lvl_0,port_lvl;
    BOOL jumbo;

    jumbo = vtss_api_state->jumbo;
    prios = vtss_api_state->prios;
    
    VTSS_D(("port_on_chip: %d, fc_rx: %d, fc_tx: %d, jumbo: %d, prios: %d",
            port_on_chip,fc_rx,fc_tx,jumbo,prios));
    
    /* Select ingress queue system setup */
    if (fc_tx) {
        /* Tx flow control (pause frames generated): Avoid ingress frame drop */
        if (VTSS_PORT_IS_10G(port_on_chip)) {
            /* Ingress flow control mode, 10G port */
            if (jumbo) {
#if defined(VTSS_CHIPS) && !defined(BOARD_JETWAY48)
                /* Internal link settings for XGMII-XGMII connection */
                wm_high     = 31;
                wm_low      = 31;
#else
                wm_high     = GW_IN_WM_HIGH_FC_10G_JUMBO;
                wm_low      = GW_IN_WM_LOW_FC_10G_JUMBO;
#endif
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_FC_10G_JUMBO;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_FC_10G_JUMBO;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_FC_10G_JUMBO;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_FC_10G_JUMBO;
                port_lvl    = GW_IN_PORT_LVL_FC_10G_JUMBO;
            } else {
#if defined(VTSS_CHIPS) && !defined(BOARD_JETWAY48)
                /* Internal link settings for XGMII-XGMII connection */
                wm_high     = 55;
                wm_low      = 55;
#else
                wm_high     = GW_IN_WM_HIGH_FC_10G;
                wm_low      = GW_IN_WM_LOW_FC_10G;
#endif
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_FC_10G;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_FC_10G;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_FC_10G;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_FC_10G;
                port_lvl    = GW_IN_PORT_LVL_FC_10G;
            }
        } else {
            /* Ingress flow control mode, 1G port */
            if (jumbo) {
                wm_high     = GW_IN_WM_HIGH_FC_1G_JUMBO;
                wm_low      = GW_IN_WM_LOW_FC_1G_JUMBO;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_FC_1G_JUMBO;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_FC_1G_JUMBO;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_FC_1G_JUMBO;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_FC_1G_JUMBO;
                port_lvl    = GW_IN_PORT_LVL_FC_1G_JUMBO;
            } else {
                wm_high     = GW_IN_WM_HIGH_FC_1G;
                wm_low      = GW_IN_WM_LOW_FC_1G;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_FC_1G;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_FC_1G;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_FC_1G;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_FC_1G;
                port_lvl    = GW_IN_PORT_LVL_FC_1G;
            }
        }
    } else {
        /* No Tx flow control (pause frames not generated): Allow ingress frame drop */
        if (VTSS_PORT_IS_10G(port_on_chip)) {
            /* Ingress drop mode, 10G port */
            if (jumbo) {
                wm_high     = GW_IN_WM_HIGH_DROP_10G_JUMBO;
                wm_low      = GW_IN_WM_LOW_DROP_10G_JUMBO;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_10G_JUMBO;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_10G_JUMBO;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_10G_JUMBO;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_10G_JUMBO;
                port_lvl    = GW_IN_PORT_LVL_DROP_10G_JUMBO;
            } else if (prios == 4) {
                wm_high     = GW_IN_WM_HIGH_DROP_10G_PRIO_4;
                wm_low      = GW_IN_WM_LOW_DROP_10G_PRIO_4;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_10G_PRIO_4;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_10G_PRIO_4;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_10G_PRIO_4;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_10G_PRIO_4;
                port_lvl    = GW_IN_PORT_LVL_DROP_10G_PRIO_4;
            } else if (prios == 2) {
                wm_high     = GW_IN_WM_HIGH_DROP_10G_PRIO_2;
                wm_low      = GW_IN_WM_LOW_DROP_10G_PRIO_2;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_10G_PRIO_2;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_10G_PRIO_2;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_10G_PRIO_2;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_10G_PRIO_2;
                port_lvl    = GW_IN_PORT_LVL_DROP_10G_PRIO_2;
            } else {
                wm_high     = GW_IN_WM_HIGH_DROP_10G_PRIO_1;
                wm_low      = GW_IN_WM_LOW_DROP_10G_PRIO_1;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_10G_PRIO_1;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_10G_PRIO_1;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_10G_PRIO_1;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_10G_PRIO_1;
                port_lvl    = GW_IN_PORT_LVL_DROP_10G_PRIO_1;
            }
        } else {
            /* Ingress drop mode, 1G port */
            if (jumbo) {
                wm_high     = GW_IN_WM_HIGH_DROP_1G_JUMBO;
                wm_low      = GW_IN_WM_LOW_DROP_1G_JUMBO;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_1G_JUMBO;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_1G_JUMBO;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_1G_JUMBO;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_1G_JUMBO;
                port_lvl    = GW_IN_PORT_LVL_DROP_1G_JUMBO;
            } else if (prios == 4) {
                wm_high     = GW_IN_WM_HIGH_DROP_1G_PRIO_4;
                wm_low      = GW_IN_WM_LOW_DROP_1G_PRIO_4;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_1G_PRIO_4;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_1G_PRIO_4;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_1G_PRIO_4;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_1G_PRIO_4;
                port_lvl    = GW_IN_PORT_LVL_DROP_1G_PRIO_4;
            } else if (prios == 2) {
                wm_high     = GW_IN_WM_HIGH_DROP_1G_PRIO_2;
                wm_low      = GW_IN_WM_LOW_DROP_1G_PRIO_2;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_1G_PRIO_2;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_1G_PRIO_2;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_1G_PRIO_2;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_1G_PRIO_2;
                port_lvl    = GW_IN_PORT_LVL_DROP_1G_PRIO_2;
            } else {
                wm_high     = GW_IN_WM_HIGH_DROP_1G_PRIO_1;
                wm_low      = GW_IN_WM_LOW_DROP_1G_PRIO_1;
                queue_lvl_3 = GW_IN_QUEUE_LVL_3_DROP_1G_PRIO_1;
                queue_lvl_2 = GW_IN_QUEUE_LVL_2_DROP_1G_PRIO_1;
                queue_lvl_1 = GW_IN_QUEUE_LVL_1_DROP_1G_PRIO_1;
                queue_lvl_0 = GW_IN_QUEUE_LVL_0_DROP_1G_PRIO_1;
                port_lvl    = GW_IN_PORT_LVL_DROP_1G_PRIO_1;
            }
        }
    }
    
    /* Write to ingress queue system registers */
    GW_WR(RXP,IN_QUEUE_DROP_CFG_0,port_on_chip,
          (queue_lvl_0<<O_RXP_IN_QUEUE_DROP_CFG_0_QUEUE_DROP_0) |
          (queue_lvl_1<<O_RXP_IN_QUEUE_DROP_CFG_0_QUEUE_DROP_1));
    GW_WR(RXP,IN_QUEUE_DROP_CFG_1,port_on_chip,
          (queue_lvl_2<<O_RXP_IN_QUEUE_DROP_CFG_1_QUEUE_DROP_2) |
          (queue_lvl_3<<O_RXP_IN_QUEUE_DROP_CFG_1_QUEUE_DROP_3));
    GW_WR(RXP,IN_QUEUE_WMARK_CFG,port_on_chip,
          (wm_low<<O_RXP_IN_QUEUE_WMARK_CFG_PORT_WM_LOW) |
          (wm_high<<O_RXP_IN_QUEUE_WMARK_CFG_PORT_WM_HIGH) |
          (port_lvl<<O_RXP_IN_QUEUE_WMARK_CFG_PORT_DROP_LEVEL));
    
    /* Select egress queue system setup */
    if (fc_rx) {
        /* Rx flow control (pause frames obeyed): Avoid egress frame drop */
        if (VTSS_PORT_IS_10G(port_on_chip)) {
            /* Ingress flow control mode, 10G port */
            if (jumbo) {
                wm_high     = GW_EG_WM_HIGH_FC_10G_JUMBO;
                wm_low      = GW_EG_WM_LOW_FC_10G_JUMBO;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_FC_10G_JUMBO;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_FC_10G_JUMBO;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_FC_10G_JUMBO;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_FC_10G_JUMBO;
                port_lvl    = GW_EG_PORT_LVL_FC_10G_JUMBO;
            } else {
                wm_high     = GW_EG_WM_HIGH_FC_10G;
                wm_low      = GW_EG_WM_LOW_FC_10G;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_FC_10G;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_FC_10G;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_FC_10G;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_FC_10G;
                port_lvl    = GW_EG_PORT_LVL_FC_10G;
            }
        } else {
            /* Ingress flow control mode, 1G port */
            if (jumbo) {
                wm_high     = GW_EG_WM_HIGH_FC_1G_JUMBO;
                wm_low      = GW_EG_WM_LOW_FC_1G_JUMBO;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_FC_1G_JUMBO;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_FC_1G_JUMBO;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_FC_1G_JUMBO;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_FC_1G_JUMBO;
                port_lvl    = GW_EG_PORT_LVL_FC_1G_JUMBO;
            } else {
                wm_high     = GW_EG_WM_HIGH_FC_1G;
                wm_low      = GW_EG_WM_LOW_FC_1G;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_FC_1G;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_FC_1G;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_FC_1G;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_FC_1G;
                port_lvl    = GW_EG_PORT_LVL_FC_1G;
            }
        }
    } else {
        /* No Rx flow control (pause frames not obeyed): Allow egress frame drop */
        if (VTSS_PORT_IS_10G(port_on_chip)) {
            /* Egress drop mode, 10G port */
            if (jumbo) {
                wm_high     = GW_EG_WM_HIGH_DROP_10G_JUMBO;
                wm_low      = GW_EG_WM_LOW_DROP_10G_JUMBO;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_10G_JUMBO;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_10G_JUMBO;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_10G_JUMBO;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_10G_JUMBO;
                port_lvl    = GW_EG_PORT_LVL_DROP_10G_JUMBO;
            } else if (prios == 4) {
                wm_high     = GW_EG_WM_HIGH_DROP_10G_PRIO_4;
                wm_low      = GW_EG_WM_LOW_DROP_10G_PRIO_4;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_10G_PRIO_4;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_10G_PRIO_4;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_10G_PRIO_4;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_10G_PRIO_4;
                port_lvl    = GW_EG_PORT_LVL_DROP_10G_PRIO_4;
            } else if (prios == 2) {
                wm_high     = GW_EG_WM_HIGH_DROP_10G_PRIO_2;
                wm_low      = GW_EG_WM_LOW_DROP_10G_PRIO_2;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_10G_PRIO_2;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_10G_PRIO_2;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_10G_PRIO_2;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_10G_PRIO_2;
                port_lvl    = GW_EG_PORT_LVL_DROP_10G_PRIO_2;
            } else {
                wm_high     = GW_EG_WM_HIGH_DROP_10G_PRIO_1;
                wm_low      = GW_EG_WM_LOW_DROP_10G_PRIO_1;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_10G_PRIO_1;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_10G_PRIO_1;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_10G_PRIO_1;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_10G_PRIO_1;
                port_lvl    = GW_EG_PORT_LVL_DROP_10G_PRIO_1;
            }
        } else {
            /* Egress drop mode, 1G port */
            if (jumbo) {
                wm_high     = GW_EG_WM_HIGH_DROP_1G_JUMBO;
                wm_low      = GW_EG_WM_LOW_DROP_1G_JUMBO;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_1G_JUMBO;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_1G_JUMBO;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_1G_JUMBO;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_1G_JUMBO;
                port_lvl    = GW_EG_PORT_LVL_DROP_1G_JUMBO;
            } else if (prios == 4) {
                wm_high     = GW_EG_WM_HIGH_DROP_1G_PRIO_4;
                wm_low      = GW_EG_WM_LOW_DROP_1G_PRIO_4;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_1G_PRIO_4;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_1G_PRIO_4;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_1G_PRIO_4;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_1G_PRIO_4;
                port_lvl    = GW_EG_PORT_LVL_DROP_1G_PRIO_4;
            } else if (prios == 2) {
                wm_high     = GW_EG_WM_HIGH_DROP_1G_PRIO_2;
                wm_low      = GW_EG_WM_LOW_DROP_1G_PRIO_2;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_1G_PRIO_2;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_1G_PRIO_2;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_1G_PRIO_2;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_1G_PRIO_2;
                port_lvl    = GW_EG_PORT_LVL_DROP_1G_PRIO_2;
            } else {
                wm_high     = GW_EG_WM_HIGH_DROP_1G_PRIO_1;
                wm_low      = GW_EG_WM_LOW_DROP_1G_PRIO_1;
                queue_lvl_3 = GW_EG_QUEUE_LVL_3_DROP_1G_PRIO_1;
                queue_lvl_2 = GW_EG_QUEUE_LVL_2_DROP_1G_PRIO_1;
                queue_lvl_1 = GW_EG_QUEUE_LVL_1_DROP_1G_PRIO_1;
                queue_lvl_0 = GW_EG_QUEUE_LVL_0_DROP_1G_PRIO_1;
                port_lvl    = GW_EG_PORT_LVL_DROP_1G_PRIO_1;
            }
        }
    }
    
    /* Write to egress queue system registers */
    GW_WR(TXP,QS_DROP_CFG,port_on_chip,
          (queue_lvl_0<<O_TXP_QS_DROP_CFG_LEVEL0) |
          (queue_lvl_1<<O_TXP_QS_DROP_CFG_LEVEL1) |
          (queue_lvl_2<<O_TXP_QS_DROP_CFG_LEVEL2) |
          (queue_lvl_3<<O_TXP_QS_DROP_CFG_LEVEL3));
    GW_WR(TXP,QS_PORT_WM,port_on_chip,
          (wm_low<<O_TXP_QS_PORT_WM_PORT_WM_LOW) |
          (wm_high<<O_TXP_QS_PORT_WM_PORT_WM_HIGH));
    GW_WR(TXP,QS_PORT_DROP_CFG,port_on_chip,
          port_lvl<<O_TXP_QS_PORT_DROP_CFG_PORT_LEVEL);

    return VTSS_OK;
}

/* Setup water marks and drop levels for port */
vtss_rc vtss_ll_port_queue_setup(vtss_port_no_t port_no)
{
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    return gw_port_queue_setup(vtss_api_state->port_map.chip_port[port_no],
                               vtss_api_state->port_fc_rx[port_no],
                               vtss_api_state->port_fc_tx[port_no]);
}

static vtss_rc gw_port_queue_enable(uint port_on_chip, BOOL enable, BOOL port_up)
{
    uint  i,prios;
    ulong in_value,eg_value,mask,count,pending;
    
    prios=vtss_api_state->prios;
    
    VTSS_D(("port_on_chip: %d, enable: %d, port_up: %d",port_on_chip,enable,port_up));

    if (enable) {
        /* Enable ingress queues if port is up. */
        in_value=0;
        for (i=0; i<VTSS_QUEUES && port_up; i++) {
            in_value|=((1<<(O_RXP_IN_QUEUE_CTRL_RD_ENA_0+i)) |
                       (1<<(O_RXP_IN_QUEUE_CTRL_WR_ENA_0+i)));
        }
        GW_WR(RXP,IN_QUEUE_CTRL,port_on_chip,in_value);
        
        /* Enable egress queues if port is up. */
        eg_value=0;
        for (i=0; i<VTSS_QUEUES && port_up; i++) {
            eg_value|=((1<<(O_TXP_QS_CFG_WR_ENA+i)) | 
                       (1<<(O_TXP_QS_CFG_RD_ENA+i)) |
                       (1<<(O_TXP_QS_CFG_AGE_ENA+i)));
        }
        GW_WR(TXP,QS_CFG,port_on_chip,eg_value);
    } else {
        /* Disable ingress queue system for reading */
        GW_RD(RXP,IN_QUEUE_CTRL,port_on_chip,&in_value);
        mask=0;
        for (i=0; i<VTSS_QUEUES; i++) {
            mask|=(1<<(O_RXP_IN_QUEUE_CTRL_RD_ENA_0+i));
        }
        in_value &= ~mask;
        GW_WR(RXP,IN_QUEUE_CTRL,port_on_chip,in_value);
        
        /* Disable and flush egress queue system */
        eg_value=0;
        for (i=0; i<VTSS_QUEUES; i++) {
            eg_value|=((0<<(O_TXP_QS_CFG_WR_ENA+i)) | 
                       (0<<(O_TXP_QS_CFG_RD_ENA+i)) |
                       (1<<(O_TXP_QS_CFG_AGE_ENA+i)) |
                       (1<<(O_TXP_QS_CFG_FLUSH+i)));
        }
        GW_WR(TXP,QS_CFG,port_on_chip,eg_value);

        /* Wait until all frames have been received from the MAC (10 usec) */
        VTSS_NSLEEP(10000);

        /* Flush ingress queue system */
        GW_WR(RXP,IN_QUEUE_CTRL,port_on_chip,
              in_value | (1<<O_RXP_IN_QUEUE_CTRL_INGR_PORT_FLUSH));
        
        /* Ignore congestion on port */
        GW_WR(AR,CONG_IGNORE_CFG,0,1<<port_on_chip);

        /* Wait until the last frame in the ingress queue system has been sent */
        count=1000;
        while (count) {
            GW_RDF(RXP,IN_QUEUE_CTRL,INGR_ARB_PENDING,port_on_chip,&pending);
            if (!pending)
                break;
            count--;
        }
        
        if (count==0) {
            ulong queue_ctrl[VTSS_CHIP_PORTS];
            uint  port;
            
            VTSS_E(("Arbiter still pending for port_on_chip: %d",port_on_chip));
            
            for (port=0; port<VTSS_CHIP_PORTS; port++) {
                /* Skip current and unused ports */
                if (port==port_on_chip || (VTSS_PORT_IS_10G(port) && (port % 4)!=0))
                    continue;
                
                /* Disable ingress queue system for reading */
                GW_RD(RXP,IN_QUEUE_CTRL,port,&queue_ctrl[port]);
                
                /* Clear flush flag (this is set if the first port in D4_RXP is being flushed) */
                mask=(1<<O_RXP_IN_QUEUE_CTRL_INGR_PORT_FLUSH);
                queue_ctrl[port] &= ~mask;

                mask=0;
                for (i=0; i<VTSS_QUEUES; i++) {
                    mask|=(1<<(O_RXP_IN_QUEUE_CTRL_RD_ENA_0+i));
                }
                GW_WR(RXP,IN_QUEUE_CTRL,port,queue_ctrl[port] & ~mask);
            }

            /* Wait until the last frame in the ingress queue system has been sent */
            count=10000;
            while (count) {
                GW_RDF(RXP,IN_QUEUE_CTRL,INGR_ARB_PENDING,port_on_chip,&pending);
                if (!pending)
                    break;
                count--;
            }
            if (count==0) {
                VTSS_E(("ALERT: Arbiter still pending for port_on_chip: %d",port_on_chip));
            }

            for (port=0; port<VTSS_CHIP_PORTS; port++) {
                /* Skip current and unused ports */
                if (port==port_on_chip || (VTSS_PORT_IS_10G(port) && (port % 4)!=0))
                    continue;
                
                /* Restore ingress queue system settings */
                GW_WR(RXP,IN_QUEUE_CTRL,port,queue_ctrl[port]);
            }
        }
        
        /* Respect congestion again */
        GW_WR(AR,CONG_IGNORE_CFG,0,0);

        /* Stop flush and disable ingress queue system for writing */
        GW_WR(RXP,IN_QUEUE_CTRL,port_on_chip,0);
    }
    
    return VTSS_OK;
}

/* Enable or disable and flush port queue systems */
vtss_rc vtss_ll_port_queue_enable(vtss_port_no_t port_no, BOOL enable)
{
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    return gw_port_queue_enable(vtss_api_state->port_map.chip_port[port_no], 
                                enable, 
                                VTSS_STP_UP(vtss_api_state->stp_state[port_no]));
}

vtss_rc vtss_ll_port_speed_mode_tbi_gmii(vtss_port_no_t port_no,
                                         const vtss_port_setup_t * setup)
{
    uint         port_on_chip, clock;
    vtss_speed_t speed;    
    BOOL         tbi, giga, fdx;
    ulong        mode_cfg;

    VTSS_D(("port_no: %d",port_no));

    port_on_chip = vtss_api_state->port_map.chip_port[port_no];

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    /* Check interface type and determine TBI mode and speed */
    switch (setup->interface_mode.interface_type)  {
    case VTSS_PORT_INTERFACE_RTBI:
        tbi = 1;
        speed = VTSS_SPEED_1G;
        break;
    case VTSS_PORT_INTERFACE_MII:
    case VTSS_PORT_INTERFACE_GMII:
    case VTSS_PORT_INTERFACE_RGMII:
        tbi = 0;
        speed = setup->interface_mode.speed;
        break;
    default:
        VTSS_E(("unknown interface type: %d",setup->interface_mode.interface_type));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Check speed and determine giga mode and clock */
    switch (speed)  {
    case VTSS_SPEED_1G:
        giga = 1;
        clock = 1;
        break;
    case VTSS_SPEED_100M:
        giga = 0;
        clock = 2;
        break;
    case VTSS_SPEED_10M:
        giga = 0;
        clock = 3;
        break;
    default:
        VTSS_E(("unknown speed: %d",speed));
        return VTSS_INVALID_PARAMETER;
    }
    fdx = ((setup->fdx || giga) ? 1 : 0);

    /* Disable MAC on Rx */
    GW_WRF(D4_MAC,MODE_CFG,RX_ENA,port_on_chip,0);
    
    /* Disable and flush queue systems */
    VTSS_RC(vtss_ll_port_queue_enable(port_no,0));
    
    /* Disable MAC on Tx */
    GW_WRF(D4_MAC,MODE_CFG,TX_ENA,port_on_chip,0);

    /* Reset MAC */
    GW_WR_MASKED(D4_MAC,RESET_CTRL,port_on_chip,
                 /* value */
                 (1<<O_D4_MAC_RESET_CTRL_RX_RESET) | 
                 (1<<O_D4_MAC_RESET_CTRL_TX_RESET),
                 /* mask */
                 (M_D4_MAC_RESET_CTRL_RX_RESET<<O_D4_MAC_RESET_CTRL_RX_RESET) |
                 (M_D4_MAC_RESET_CTRL_TX_RESET<<O_D4_MAC_RESET_CTRL_TX_RESET));

    mode_cfg = ((0<<O_D4_MAC_MODE_CFG_TX_ENA) |
                (0<<O_D4_MAC_MODE_CFG_RX_ENA) |
                (1<<O_D4_MAC_MODE_CFG_VLAN_AWARE_ENA) |
                (fdx<<O_D4_MAC_MODE_CFG_FDX) | 
                (giga<<O_D4_MAC_MODE_CFG_GIGA_MODE) | 
#if defined(VTSS_MAC_LEN_CHECK)
                (1<<O_D4_MAC_MODE_CFG_LEN_DROP) |
#else
                (0<<O_D4_MAC_MODE_CFG_LEN_DROP) |
#endif /* VTSS_MAC_LEN_CHECK */
                (1<<O_D4_MAC_MODE_CFG_RMODE_XOR) |
                ((fdx ? 0 : 1)<<O_D4_MAC_MODE_CFG_SEED_LOAD) |
                ((fdx ? 0 : setup->flowcontrol.smac.addr[5])<<O_D4_MAC_MODE_CFG_SEED) |
                (tbi<<O_D4_MAC_MODE_CFG_TBI_MODE) |
                (0<<O_D4_MAC_MODE_CFG_OB_ENA) |
                (0<<O_D4_MAC_MODE_CFG_ASS_DIS));
    /* Setup mode, always enable VLAN awareness */
    GW_WR(D4_MAC,MODE_CFG,port_on_chip,mode_cfg);
    
    if (!fdx) {
        /* For HDX, deassert the SEED_LOAD field */
        mode_cfg &= ~(1<<O_D4_MAC_MODE_CFG_SEED_LOAD);
        GW_WR(D4_MAC,MODE_CFG,port_on_chip,mode_cfg);
    }

    /* Select clock */
    GW_WR(D4_MAC,RESET_CTRL,port_on_chip,
          (1<<O_D4_MAC_RESET_CTRL_RX_RESET) | 
          (1<<O_D4_MAC_RESET_CTRL_TX_RESET) |
          (clock<<O_D4_MAC_RESET_CTRL_TX_CLOCK_SEL));

    if (tbi) {
        /* Setup TBI */
        GW_WR(D4_MAC,TBI_CFG,port_on_chip, 
              (0<<O_D4_MAC_TBI_CFG_DAR) |
              (0<<O_D4_MAC_TBI_CFG_AN_RESTART) |
              (0<<O_D4_MAC_TBI_CFG_AN_ENA) |
              (0<<O_D4_MAC_TBI_CFG_TBI_LOOPBACK) |
              (0<<O_D4_MAC_TBI_CFG_UDLT) |
              (0<<O_D4_MAC_TBI_CFG_JTP_SEL) |
              ((setup->tbi_use_signaldetect ? 1 : 0)<<O_D4_MAC_TBI_CFG_SD_ENA) |
              ((setup->tbi_signaldetect_activehigh ? 1 : 0)<<O_D4_MAC_TBI_CFG_SD_POL) |
              (0<<O_D4_MAC_TBI_CFG_SW_RESOLVE));
    }
    
    {
        /* Setup inter frame gaps */
        const vtss_frame_gaps_t *gaps;
        uint                    rx_ifg1, rx_ifg2, tx_ifg;

        gaps = &setup->frame_gaps;

        rx_ifg1 = (gaps->hdx_gap_1==VTSS_FRAME_GAP_DEFAULT ? 6 : gaps->hdx_gap_1);

        rx_ifg2 = gaps->hdx_gap_2;
        if (rx_ifg2 == VTSS_FRAME_GAP_DEFAULT) {
            if (vtss_api_state->gw1e)
                rx_ifg2 = 8;
            else
                rx_ifg2 = 9;
        }
        
        tx_ifg = gaps->fdx_gap;
        if (tx_ifg == VTSS_FRAME_GAP_DEFAULT) {
            if (vtss_api_state->gw1e)
                tx_ifg = (giga ? 6 : 17);
            else
                tx_ifg = (giga ? 7 : 19);
        }

        GW_WR(D4_MAC,IFG_CFG,port_on_chip,
              (rx_ifg1<<O_D4_MAC_IFG_CFG_RX_IFG1) |
              (rx_ifg2<<O_D4_MAC_IFG_CFG_RX_IFG2) | 
              (tx_ifg<<O_D4_MAC_IFG_CFG_TX_IFG));
    }

    /* Setup flow-control */
    GW_WR(D4_MAC,PAUSE_CFG,port_on_chip,
          (GW_PAUSE_VAL_FC_1G<<O_D4_MAC_PAUSE_CFG_TX_PAUSE_VAL) |
          ((setup->flowcontrol.generate ? 1 : 0)<<O_D4_MAC_PAUSE_CFG_TX_FLOW_CTRL_ENA) | 
          ((setup->flowcontrol.obey ? 1 : 0)<<O_D4_MAC_PAUSE_CFG_RX_PAUSE_ENA) | 
          (1<<O_D4_MAC_PAUSE_CFG_TX_PAUSE_XONOFF));
    
    /* Ignore Rx congestion in Tx flow control mode */
    GW_WR_MASKED(AR,RX_CONG_IGNORE_CFG,0,
                 (setup->flowcontrol.generate ? 1 : 0)<<port_on_chip, (1<<port_on_chip));

    /* Setup port MAC address in flow control mode */
    if (setup->fdx && (setup->flowcontrol.generate || setup->flowcontrol.obey)) {
        GW_WR(D4_MAC,MAC_ADDR_HIGH_CFG,port_on_chip, 
              (setup->flowcontrol.smac.addr[0]<<16) |
              (setup->flowcontrol.smac.addr[1]<<8) | 
              (setup->flowcontrol.smac.addr[2]));
        GW_WR(D4_MAC,MAC_ADDR_LOW_CFG,port_on_chip, 
              (setup->flowcontrol.smac.addr[3]<<16) |
              (setup->flowcontrol.smac.addr[4]<<8) | 
              (setup->flowcontrol.smac.addr[5]));
    }   
   
    /* Setup max frame length */
    GW_WR(D4_MAC,MAXLEN_CFG,port_on_chip,(setup->maxframelength));
    
    /* Release MAC */
    GW_WR(D4_MAC,RESET_CTRL,port_on_chip,
          (0<<O_D4_MAC_RESET_CTRL_RX_RESET) | 
          (0<<O_D4_MAC_RESET_CTRL_TX_RESET) |
          (clock<<O_D4_MAC_RESET_CTRL_TX_CLOCK_SEL));
    
    /* Setup queue systems */
    VTSS_RC(vtss_ll_port_queue_setup(port_no));

    /* Enable queue systems */
    VTSS_RC(vtss_ll_port_queue_enable(port_no,1));
    
    /* Enable MAC */
    mode_cfg |= ((1<<O_D4_MAC_MODE_CFG_TX_ENA) | (1<<O_D4_MAC_MODE_CFG_RX_ENA));
    GW_WR(D4_MAC,MODE_CFG,port_on_chip,mode_cfg);	
    
#if defined(VTSS_CHIPS)
    /* Setup 10G ports if flow control mode changed */
    return gw_port_setup_internal(0);
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

static vtss_rc gw_port_speed_mode_xgmii(uint port_on_chip,
                                        BOOL port_up,
                                        const vtss_port_setup_t *setup)
{
    ulong   mode_cfg;

    VTSS_D(("port_on_chip: %d",port_on_chip));
    
    /* Disable MAC on Rx */
    GW_WRF(D10_MAC,MODE_CFG,RX_ENA,port_on_chip,0);

    /* Disable and flush queue systems */
    VTSS_RC(gw_port_queue_enable(port_on_chip,0,port_up));
    
    /* Disable MAC on Tx */
    GW_WRF(D10_MAC,MODE_CFG,TX_ENA,port_on_chip,0);

    /* Reset MAC */
    GW_WR(D10_MAC,RESET_CTRL,port_on_chip, 
          (1<<O_D10_MAC_RESET_CTRL_RX_RESET) | 
          (1<<O_D10_MAC_RESET_CTRL_TX_RESET));
    
    /* Setup mode, always enable VLAN awareness */
    mode_cfg = ((0<<O_D10_MAC_MODE_CFG_TX_ENA) |
                (0<<O_D10_MAC_MODE_CFG_RX_ENA) |
                (1<<O_D10_MAC_MODE_CFG_VLAN_AWARE_ENA) |
#if defined(VTSS_MAC_LEN_CHECK)
                (1<<O_D10_MAC_MODE_CFG_INR_ERR) |
#else
                (0<<O_D10_MAC_MODE_CFG_INR_ERR) |
#endif /* VTSS_MAC_LEN_CHECK */
                (0<<O_D10_MAC_MODE_CFG_OOR_ERR) |
                (1<<O_D10_MAC_MODE_CFG_SFD_CHK) |
                (1<<O_D10_MAC_MODE_CFG_LFS_MODE) |
                (0<<O_D10_MAC_MODE_CFG_LFS_DIS_TX) |
                (0<<O_D10_MAC_MODE_CFG_LFS_INH_TX) |
                (0<<O_D10_MAC_MODE_CFG_XGMII_GEN_MODE) |
                (1<<O_D10_MAC_MODE_CFG_EXT_SOP_CHK) |
                (0<<O_D10_MAC_MODE_CFG_EXT_EOP_CHK));
#if defined(VTSS_CHIPS)
    if (vtss_api_state->gw1e) /* Accept stacking tag */
        mode_cfg |= ((1<<O_D10_MAC_MODE_CFG_PRM_SHK_CHK_DIS) | 
                     (0<<O_D10_MAC_MODE_CFG_PRM_CHK));
    else
#endif /* VTSS_CHIPS */
        mode_cfg |= (1<<O_D10_MAC_MODE_CFG_PRM_CHK);
    GW_WR(D10_MAC,MODE_CFG,port_on_chip,mode_cfg);

    /* Setup flow-control */
    GW_WR(D10_MAC,PAUSE_CFG,port_on_chip, 
          (GW_PAUSE_VAL_FC_10G<<O_D10_MAC_PAUSE_CFG_TX_PAUSE_VAL) |
          ((setup->flowcontrol.generate ? 1: 0)<<O_D10_MAC_PAUSE_CFG_TX_PAUSE_ENA) |
          ((setup->flowcontrol.obey ? 1 : 0)<<O_D10_MAC_PAUSE_CFG_RX_PAUSE_ENA) | 
          (1<<O_D10_MAC_PAUSE_CFG_TX_PAUSE_XONOFF));
  
    /* Ignore Rx congestion in Tx flow control mode */
    GW_WR_MASKED(AR,RX_CONG_IGNORE_CFG,0,
                 (setup->flowcontrol.generate ? 1 : 0)<<port_on_chip, (1<<port_on_chip));

    /* Setup port MAC address in flow control mode */
    if (setup->flowcontrol.generate || setup->flowcontrol.obey) {
        GW_WR(D10_MAC,MAC_ADDR_HIGH_CFG,port_on_chip, 
              (setup->flowcontrol.smac.addr[0]<<16) |
              (setup->flowcontrol.smac.addr[1]<<8) | 
              (setup->flowcontrol.smac.addr[2]));
        GW_WR(D10_MAC,MAC_ADDR_LOW_CFG,port_on_chip, 
              (setup->flowcontrol.smac.addr[3]<<16) |
              (setup->flowcontrol.smac.addr[4]<<8) | 
              (setup->flowcontrol.smac.addr[5]));
    }   

    /* Setup max frame length */
    GW_WR(D10_MAC,MAXLEN_CFG,port_on_chip,setup->maxframelength);
 
    /* Setup pin swapping */
    GW_WR(D10_MAC,MISC_CFG,port_on_chip, 
          (setup->xgmii_swap_rx_pins<<O_D10_MAC_MISC_CFG_SWAP_RX_PINS_ENA) |
          (setup->xgmii_swap_tx_pins<<O_D10_MAC_MISC_CFG_SWAP_TX_PINS_ENA));

    /* Release MAC */
    GW_WR(D10_MAC,RESET_CTRL,port_on_chip, 
          (0<<O_D10_MAC_RESET_CTRL_RX_RESET) | 
          (0<<O_D10_MAC_RESET_CTRL_TX_RESET));

    /* Setup queue systems */
    VTSS_RC(gw_port_queue_setup(port_on_chip,setup->flowcontrol.obey,setup->flowcontrol.generate));
    /* Enable queue systems */
    VTSS_RC(gw_port_queue_enable(port_on_chip,1,port_up));
   
    /* Enable MAC */
    mode_cfg |= (((setup->powerdown ? 0 : 1)<<O_D10_MAC_MODE_CFG_TX_ENA) | 
                 ((setup->powerdown ? 0 : 1)<<O_D10_MAC_MODE_CFG_RX_ENA));
    GW_WR(D10_MAC,MODE_CFG,port_on_chip,mode_cfg);
    
    /* Clear sticky bits used for link detection */
    GW_WR(D10_MAC,TX_MONITOR_STICKY,port_on_chip,
          (1<<O_D10_MAC_TX_MONITOR_STICKY_DIS_STATE) |
          (1<<O_D10_MAC_TX_MONITOR_STICKY_REMOTE_ERR_STATE) |
          (1<<O_D10_MAC_TX_MONITOR_STICKY_LOCAL_ERR_STATE));
    
    return VTSS_OK;
}

vtss_rc vtss_ll_port_speed_mode_xgmii(vtss_port_no_t port_no,
                                      const vtss_port_setup_t * setup)
{
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    return gw_port_speed_mode_xgmii(vtss_api_state->port_map.chip_port[port_no],
                                    VTSS_STP_UP(vtss_api_state->stp_state[port_no]),
                                    setup);
}

static vtss_rc gw_port_up(uint port_on_chip, BOOL *port_up)
{
    ulong value;

    /* Read and clear sticky bits */
    GW_RD(D10_MAC,TX_MONITOR_STICKY,port_on_chip,&value);

    *port_up=(!(TRF(value,D10_MAC,TX_MONITOR_STICKY,DIS_STATE) ||
                TRF(value,D10_MAC,TX_MONITOR_STICKY,REMOTE_ERR_STATE) ||
                TRF(value,D10_MAC,TX_MONITOR_STICKY,LOCAL_ERR_STATE)));
    
    /* Clear sticky bits */
    GW_WR(D10_MAC,TX_MONITOR_STICKY,port_on_chip,
          (1<<O_D10_MAC_TX_MONITOR_STICKY_DIS_STATE) |
          (1<<O_D10_MAC_TX_MONITOR_STICKY_REMOTE_ERR_STATE) |
          (1<<O_D10_MAC_TX_MONITOR_STICKY_LOCAL_ERR_STATE));
    
    return VTSS_OK;
}

/* Determine if 10G port is up */
vtss_rc vtss_ll_port_up(vtss_port_no_t port_no, BOOL *port_up)
{
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    return gw_port_up(vtss_api_state->port_map.chip_port[port_no], port_up);
}

/* Conversion from rate [1000 bit/sec] to register value */
static ulong gw_qos_rate2reg(vtss_bitrate_t rate)
{
    ulong val,res;

    if (rate>10000000) {
        /* Rate bigger than 10Gbit/sec */
        val=0xffff;
    } else {
#if VTSS_OPT_12G
        if (vtss_api_state->gw1e)
            /* Policer/shaper rate resolution: 183105 (12 Gbit/sec divided by 65536) */
            res=183105;
        else
#endif /* VTSS_OPT_12G */
            /* Policer/shaper rate resolution: 152588 (10 Gbit/sec divided by 65536) */
            res=152588;
        
        /* Make calculation as accurate as possible */
        if (rate<(0xffffffff/1000)) {
            /* 1000*rate is less than 32 bits */
            val=(rate*1000)/res;
        } else {
            /* 1000*rate is more than 32 bits */
            val=(rate/res)*1000;
        }
    }
    
    return val;
}

/* Policer level in 64 byte units */
#define GW_QOS_POLICER_LEVEL(port_on_chip) ((VTSS_PORT_IS_10G(port_on_chip) ? ((1<<8)-1) : 12*1024/64)-1-(1522/64)) 

/* Shaper level in 64 byte units */
#define GW_QOS_SHAPER_LEVEL ((1<<7)-1-1-1522/64)

/* Determine queue corresponding to priority */
static uint gw_prio2queue(vtss_prio_t prio)
{
    uint queue;

    switch (vtss_api_state->prios) {
    case 4:
        /* One queue for each priority */
        queue = (prio==4 ? 3 : prio==3 ? 2 : prio==2 ? 1 : 0);
        break;
    case 2:
        /* Priority 2,3,4 in queue 3 (queue 1,0 unused) */
        queue = (prio > 1 ? 3 : 2); 
        break;
    case 1:
    default:
        /* All priorities in queue 3 (queue 2,1,0 unused) */
        queue = 3;
        break;
    }
    
    return queue;
}

/* Determine priority corresponding to queue, priority zero means unused */
static uint gw_queue2prio(uint queue)
{
    vtss_prio_t prio;

    switch (vtss_api_state->prios) {
    case 4:
        /* One queue for each priority */
        prio = (queue+1);
        break;
    case 2:
        /* Priority 2,3,4 in queue 3 (queue 1,0 unused) */
        prio = (queue==3 ? 2 : queue==2 ? 1 : 0); 
        break;
    case 1:
    default:
        /* All priorities in queue 3 (queue 2,1,0 unused) */
        prio = (queue==3 ? 1 : 0);
        break;
    }
    
    return prio;
}

static vtss_rc gw_port_qos_setup_set(uint port_on_chip, const vtss_port_qos_setup_t *qos)
{
    uint        i;
    ulong       value,mask;
    vtss_prio_t prio;

    /* Set priority enable fields and default priority */
    value = (
         ((qos->udp_tcp_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_PORT) |
         ((qos->dscp_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_DSCP) |
         ((qos->ip_proto_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_IPPROTO) |
         ((qos->tag_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_VLAN) |
         ((qos->mpls_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_EXP) |
         ((qos->etype_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_ETYPE) |
         (gw_prio2queue(qos->default_prio)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_DEFAULT_PRI));
    if (vtss_api_state->gw1e)
        value |= ((qos->dscp_enable ? 1 : 0)<<O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_IPV6_DSCP);
    GW_WR(RXP,PRIO_ENABLE_CFG,port_on_chip,value);
    
    /* Set DSCP map table */
    for (i=0; i<64; i++) {
        if ((i%16)==0) {
            value=0;
        }
        value|=(gw_prio2queue(qos->dscp_prio[i])<<
                (O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_0+2*(i%16)));
        if (((i+1)%16)==0) {
            GW_WR(RXP,DSCP_PRIO_CFG_0+(i/16),port_on_chip,value);
        }
    }
    
    /* Set Ethernet type and IP protocol mapping */
    GW_WR(RXP,ETYPE_IPPROTO_PRIO_CFG,port_on_chip,
          (gw_prio2queue(qos->default_prio/*ip_proto_prio_def*/)<<
           O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_DEF) |
          (gw_prio2queue(qos->ip_proto_prio)<<
           O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_PRI) |
          (qos->ip_proto_val<<O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_VAL) |
          (gw_prio2queue(qos->default_prio/*etype_prio_def*/)<<
           O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_DEF) |
          (gw_prio2queue(qos->etype_prio)<<
           O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_PRI) |
          (qos->etype_val<<O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_VAL));
    
    /* Set VLAN tag and MPLS EXP mapping */
    value=0;
    for (i=0; i<8; i++) {
        value|=(gw_prio2queue(qos->tag_prio[i])<<(O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_0+2*i));
        value|=(gw_prio2queue(qos->mpls_prio[i])<<(O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_0+2*i));
    }
    GW_WR(RXP,VLAN_MPLS_PRIO_CFG,port_on_chip,value);
    
    /* Set ingress VLAN tag priority mapping */
    value=((qos->tag_map_enable ? 0 : 1)<<O_RXP_PORT_VLAN_CFG_VLAN_KEEP_USER_PRIO);
    mask=(M_RXP_PORT_VLAN_CFG_VLAN_KEEP_USER_PRIO<<O_RXP_PORT_VLAN_CFG_VLAN_KEEP_USER_PRIO);
    for (prio=VTSS_PRIO_START; prio<=vtss_api_state->prios; prio++) {
        i=gw_prio2queue(prio);
        value|=(qos->usr_prio[prio]<<(O_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_0+3*i));
        mask|=(M_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_0<<(O_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_0+3*i));
    }
    GW_WR_MASKED(RXP,PORT_VLAN_CFG,port_on_chip,value,mask);
    
    /* Set egress VLAN tag priority mapping */
    value=0;
    mask=0;
    for (i=0; i<8; i++) {
        value|=(qos->remap_prio[i]<<(O_TXP_REWR_CFG_PRIO_MAP_0+3*i));
        mask|=(M_TXP_REWR_CFG_PRIO_MAP_0<<(O_TXP_REWR_CFG_PRIO_MAP_0+3*i));
    }
    GW_WR_MASKED(TXP,REWR_CFG,port_on_chip,value,mask);
    
    /* Set policer rate */
    if (qos->policer_port==VTSS_BITRATE_FEATURE_DISABLED) {
        GW_WRF(RXP,IN_POLICER_CTRL,INGR_POLICER_ALL_ENA,port_on_chip,0);
    } else {
        GW_WRF(RXP,IN_POLICER_CTRL,INGR_POLICER_ALL_ENA,port_on_chip,1);
        GW_WRF(RXP,IN_POLICER_RATE_CFG,INGR_POLICER_RATE_ALL,port_on_chip,
               gw_qos_rate2reg(qos->policer_port)); /* Convert from 1000 bit/sec */
        GW_WRF(RXP,IN_POLICER_LEVEL_CFG,INGR_POLICER_LEVEL_ALL,port_on_chip,
               GW_QOS_POLICER_LEVEL(port_on_chip));
    }

    /* Set MC policer rate */
    if (qos->mc_policer_port==VTSS_BITRATE_FEATURE_DISABLED) {
        GW_WRF(RXP,IN_POLICER_CTRL,INGR_POLICER_MC_ENA,port_on_chip,0);
    } else {
        /* Count both multicasts and broadcasts */
        value=((1<<O_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_ENA) |
               ((qos->mc_policer_port_bc_only ? 0 : 1)<<O_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_BC));
        mask=((M_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_ENA<<
               O_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_ENA) |
              (M_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_BC<<
               O_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_BC));
        GW_WR_MASKED(RXP,IN_POLICER_CTRL,port_on_chip,value,mask);
        GW_WRF(RXP,IN_POLICER_RATE_CFG,INGR_POLICER_RATE_MC,port_on_chip,
               gw_qos_rate2reg(qos->mc_policer_port)); /* Convert from 1000 bit/sec */
        GW_WRF(RXP,IN_POLICER_LEVEL_CFG,INGR_POLICER_LEVEL_MC,port_on_chip,
               GW_QOS_POLICER_LEVEL(port_on_chip));
    }

    /* Set shaper rates */
    for (i=0; i<VTSS_QUEUES; i++) {
        /* Use shaper corresponding to mapped queue */
        if (qos->shaper_port!=VTSS_BITRATE_FEATURE_DISABLED) {
            /* Port shaper enabled */
            value=(((i==0 ? gw_qos_rate2reg(qos->shaper_port) : 0)<<O_TXP_SHAPER_CFG_0_RATE) |
                   (GW_QOS_SHAPER_LEVEL<<O_TXP_SHAPER_CFG_0_BURSTSIZE) |
                   (1<<O_TXP_SHAPER_CFG_0_LINERATE_ENA) |
                   (1<<O_TXP_SHAPER_CFG_0_EXCESS_ENA) |
                   (1<<O_TXP_SHAPER_CFG_0_SHAPER_ENA));
        } else {
            /* Port shaper disabled, setup queue shapers */
            prio=gw_queue2prio(i);
            if (prio==0 || qos->shaper_queue[prio]==VTSS_BITRATE_FEATURE_DISABLED) {
                /* Queue unused or shaper disabled */
                value=((0<<O_TXP_SHAPER_CFG_0_RATE) |
                       (0<<O_TXP_SHAPER_CFG_0_BURSTSIZE) |
                       (0<<O_TXP_SHAPER_CFG_0_LINERATE_ENA) |
                       (0<<O_TXP_SHAPER_CFG_0_EXCESS_ENA) |
                       (0<<O_TXP_SHAPER_CFG_0_SHAPER_ENA));
            } else {
                /* Shaper enabled */
                value=((gw_qos_rate2reg(qos->shaper_queue[prio])<<O_TXP_SHAPER_CFG_0_RATE) |
                       (GW_QOS_SHAPER_LEVEL<<O_TXP_SHAPER_CFG_0_BURSTSIZE) |
                       (0<<O_TXP_SHAPER_CFG_0_LINERATE_ENA) |
                       ((qos->shaper_queue_excss_enable[prio] ? 1 : 0)<<O_TXP_SHAPER_CFG_0_EXCESS_ENA) |
                       (1<<O_TXP_SHAPER_CFG_0_SHAPER_ENA));
            }
        }
        GW_WR(TXP,SHAPER_CFG_0+i,port_on_chip,value);
    }

    return VTSS_OK;
}

/* Set port QoS setup */
vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos)
{
    VTSS_D(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    return gw_port_qos_setup_set(vtss_api_state->port_map.chip_port[port_no], qos);
}

#if defined(VTSS_CHIPS)
static vtss_rc gw_port_setup_internal(BOOL init)
{
    vtss_rc            rc = VTSS_OK;
    vtss_chip_no_t     chip_no;
    uint               iport,port_on_chip;
    vtss_iport_setup_t *iport_setup;
    vtss_port_setup_t  setup;
    BOOL               fc=0;
    int                i;
#if VTSS_OPT_INT_PORT_FC
    vtss_port_no_t     port_no;
    
    /* Determine if flow control is used on operational ports on the chips */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (vtss_api_state->port_fc_rx[port_no] || vtss_api_state->port_fc_tx[port_no]) {
            fc = 1;
            break;
        }
    }
#endif /* VTSS_OPT_INT_PORT_FC */
    
    VTSS_D(("init: %d",init));

    /* Check if flow control or jumbo mode setup was changed */
    if (fc == vtss_api_state->fc_internal && 
        vtss_api_state->jumbo == vtss_api_state->jumbo_internal && 
        !init) {
        VTSS_D(("flow control/jumbo mode not changed %d/%d",fc,vtss_api_state->jumbo));
        return rc;
    }
    
    VTSS_D(("flow control: %d, jumbo: %d",fc,vtss_api_state->jumbo));
    vtss_api_state->fc_internal = fc;
    vtss_api_state->jumbo_internal = vtss_api_state->jumbo;
    
    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        for (iport=vtss_api_state->iport_first[chip_no]; 
             iport<=vtss_api_state->iport_last[chip_no]; 
             iport++) {
            iport_setup = &vtss_api_state->iport_setup[iport];
            port_on_chip = iport_setup->chip_port;
            
            /* Fill out setup structure */
            setup.interface_mode.interface_type = VTSS_PORT_INTERFACE_XGMII;
            setup.powerdown = 0;
            setup.interface_mode.speed = VTSS_SPEED_10G;
            setup.fdx = 1;
            setup.flowcontrol.obey = fc;
            setup.flowcontrol.generate = fc;
            /* Source MAC address 00-00-00-00-00-0X, where X is (iport+1) */
            for (i=0; i<6; i++) {
                setup.flowcontrol.smac.addr[i] = (i==5 ? (iport+1) : 0);
            }
            setup.maxframelength = VTSS_MAXFRAMELENGTH_MAX;
            setup.xgmii_swap_rx_pins = iport_setup->swap_rx_pins;
            setup.xgmii_swap_tx_pins = iport_setup->swap_tx_pins;
            
            VTSS_D(("chip_no: %d, port_on_chip: %d",chip_no,port_on_chip));
            VTSS_RC(gw_port_speed_mode_xgmii(port_on_chip,1,&setup));
        }
    }
    return rc;
}

/* Setup QoS for internal port */
static vtss_rc gw_port_qos_setup_internal(uint port_on_chip)
{
    vtss_port_qos_setup_t qos;
    vtss_prio_t           prio;
    vtss_queue_t          queue;
    int                   i;
    
    /* Classification mode */
    qos.udp_tcp_enable = 0;
    qos.dscp_enable = 0;
    qos.ip_proto_enable = 0;
    qos.tag_enable = 0;
    qos.mpls_enable = 0;
    qos.etype_enable = 0;

    /* DSCP */
    for (i=0; i<64; i++) {
        qos.dscp_prio[i] = VTSS_PRIO_START;
    }

    /* IP protocol */
    qos.ip_proto_val = 0;
    qos.ip_proto_prio = VTSS_PRIO_START;

    /* Tag and MPLS */
    for (i=0; i<8; i++) {
        qos.tag_prio[i] = VTSS_PRIO_START;
        qos.mpls_prio[i] = VTSS_PRIO_START;
    }

    /* Ethernet type */
    qos.etype_val = 0;
    qos.etype_prio = VTSS_PRIO_START;

    /* Default priority */
    qos.default_prio = VTSS_PRIO_START;

    /* Default tag priority and remapping */
    for (prio=VTSS_PRIO_START; prio<VTSS_PRIO_END; prio++) {
        qos.usr_prio[prio] = 0;
    }
    qos.tag_map_enable = 0;
    for (i=0; i<8; i++) {
        qos.remap_prio[i] = i;
    }

    /* Policers: Disabled */
    qos.policer_port = VTSS_BITRATE_FEATURE_DISABLED;
    qos.mc_policer_port = VTSS_BITRATE_FEATURE_DISABLED;
    
    /* Shapers: Disabled */
    qos.shaper_port = VTSS_BITRATE_FEATURE_DISABLED;
    for (queue=VTSS_QUEUE_START; queue<VTSS_QUEUE_END; queue++) {
        qos.shaper_queue[queue] = VTSS_BITRATE_FEATURE_DISABLED;
        qos.shaper_queue_excss_enable[queue] = 0;
    }
    
    return gw_port_qos_setup_set(port_on_chip, &qos);
}
#endif /* VTSS_CHIPS */

/* Set QoS setup for all ports/modules */
vtss_rc vtss_ll_qos_setup_set(const vtss_qos_setup_t *qos)
{
    uint           i,port_on_chip=0;
    ulong          value=0;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
    VTSS_D(("enter"));
    
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
    
        for (port_on_chip=0; port_on_chip<VTSS_CHIP_PORTS; port_on_chip++) {

            if ((port_on_chip%4)==0) {
                /* Setup per module */
                /* Set mapped priorities and default priority */
                value=(gw_prio2queue(qos->udp_tcp_prio_def)<<
                       O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_DEF_PRI);
                for (i=0; i<10; i++) {
                    value|=(gw_prio2queue(qos->udp_tcp_prio[i])<<
                            (O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_0+2*i));
                }
                GW_WR(RXP,UDP_TCP_PRIO_CFG,port_on_chip,value);
                
                /* Set UDP/TCP port numbers */
                for (i=0; i<10; i++) {
                    if ((i%2)==0) {
                        value=0;
                    }
                    value|=(qos->udp_tcp_val[i]<<(O_RXP_UDP_TCP_PORT_CFG_0_PRI_MAP_PORT_VAL_1*(i%2)));
                    if ((i+1)%2==0) {
                        GW_WR(RXP,UDP_TCP_PORT_CFG_0+(i/2),port_on_chip,value);
                    }
                }
            }
            
#if defined(VTSS_CHIPS)
            /* For internal ports, setup and enable queues (vtss_api_state->prios changed) */
            if (port_on_chip==vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port ||
                port_on_chip==vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port) {
                VTSS_RC(gw_port_qos_setup_internal(port_on_chip));
                VTSS_RC(gw_port_queue_setup(port_on_chip,
                                            vtss_api_state->fc_internal,
                                            vtss_api_state->fc_internal));
                VTSS_RC(gw_port_queue_enable(port_on_chip,1,1));
            }
#endif /* VTSS_CHIPS */
        }
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Set aggregation mode */
vtss_rc vtss_ll_aggr_mode_set(const vtss_aggr_mode_t *mode)
{
    uint           port_on_chip;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        
        for (port_on_chip=0; port_on_chip<VTSS_CHIP_PORTS; port_on_chip++) {
            if ((port_on_chip%4)!=0 && VTSS_PORT_IS_10G(port_on_chip))
                continue;

            GW_WR(RXP,AGGR_ENABLE_CFG,port_on_chip,
                  ((mode->smac_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_LOW_SMAC_ENA) |
                  ((mode->smac_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_HIGH_SMAC_ENA) |
                  ((mode->dmac_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_LOW_DMAC_ENA) |
                  ((mode->dmac_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_HIGH_DMAC_ENA) |
                  ((mode->etype_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_ETYPE_ENA) |
                  ((mode->vlan_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_VID_ENA) |
                  ((mode->mpls_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_LABEL_ENA) |
                  ((mode->ip_proto_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_IP_PROTO_ENA) |
                  ((mode->sip_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_SIP_ENA) |
                  ((mode->dip_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_DIP_ENA) |
                  ((mode->sport_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_SPORT_ENA) |
                  ((mode->dport_enable ? 1 : 0)<<O_RXP_AGGR_ENABLE_CFG_AGGRE_DPORT_ENA));
        }
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

/* ================================================================= *
 *  Statistics and Counters
 * ================================================================= */
vtss_rc vtss_ll_port_counters_get(uint port_no, vtss_chip_counters_t * counters)
{
    uint port_on_chip=vtss_api_state->port_map.chip_port[port_no];
    
    VTSS_N(("port_no: %d",port_no));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    GW_RD(SE,RX_IN_BYTES_CNT,port_on_chip,&counters->rx_in_bytes);
    GW_RD(SE,RX_SYMBOL_CARRIER_ERR_CNT,port_on_chip,&counters->rx_symbol_carrier_err);
    GW_RD(RXP,DROP_CNT,port_on_chip,&counters->rx_drops);
    GW_RD(SE,RX_PAUSE_CNT,port_on_chip,&counters->rx_pause);
    GW_RD(SE,RX_UNSUP_OPCODE_CNT,port_on_chip,&counters->rx_unsup_opcode);
    GW_RD(SE,RX_OK_BYTES_CNT,port_on_chip,&counters->rx_ok_bytes);
    GW_RD(SE,RX_BAD_BYTES_CNT,port_on_chip,&counters->rx_bad_bytes);
    GW_RD(SE,RX_UNICAST_CNT,port_on_chip,&counters->rx_unicast);
    GW_RD(SE,RX_MULTICAST_CNT,port_on_chip,&counters->rx_multicast);
    GW_RD(SE,RX_BROADCAST_CNT,port_on_chip,&counters->rx_broadcast);
    GW_RD(SE,RX_CRC_ERR_CNT,port_on_chip,&counters->rx_crc_err);
    GW_RD(SE,RX_UNDERSIZE_CNT,port_on_chip,&counters->rx_undersize);
    GW_RD(SE,RX_FRAGMENTS_CNT,port_on_chip,&counters->rx_fragments);
#if defined(VTSS_MAC_LEN_CHECK)
    GW_RD(SE,RX_IN_RANGE_LENGTH_ERR_CNT,port_on_chip,&counters->rx_in_range_length_err);
    GW_RD(SE,RX_OUT_OF_RANGE_LENGTH_ERR_CNT,port_on_chip,&counters->rx_out_of_range_length_err);
#else
    /* Length range errors are ignored if these are not discarded */
    counters->rx_in_range_length_err = 0;
    counters->rx_out_of_range_length_err = 0;
#endif /* VTSS_MAC_LEN_CHECK */
    GW_RD(SE,RX_OVERSIZE_CNT,port_on_chip,&counters->rx_oversize);
    GW_RD(SE,RX_JABBERS_CNT,port_on_chip,&counters->rx_jabbers);
    GW_RD(SE,RX_SIZE64_CNT,port_on_chip,&counters->rx_size64);
    GW_RD(SE,RX_SIZE65TO127_CNT,port_on_chip,&counters->rx_size65_127);
    GW_RD(SE,RX_SIZE128TO255_CNT,port_on_chip,&counters->rx_size128_255);
    GW_RD(SE,RX_SIZE256TO511_CNT,port_on_chip,&counters->rx_size256_511);
    GW_RD(SE,RX_SIZE512TO1023_CNT,port_on_chip,&counters->rx_size512_1023);
    GW_RD(SE,RX_SIZE1024TO1518_CNT,port_on_chip,&counters->rx_size1024_1518);
    GW_RD(SE,RX_SIZE1519TOMAX_CNT,port_on_chip,&counters->rx_size1519_max);
    GW_RD(SE,TX_OUT_BYTES_CNT,port_on_chip,&counters->tx_out_bytes);
    GW_RD(SE,TX_PAUSE_CNT,port_on_chip,&counters->tx_pause);
    GW_RD(SE,TX_OK_BYTES_CNT,port_on_chip,&counters->tx_ok_bytes);
    GW_RD(SE,TX_UNICAST_CNT,port_on_chip,&counters->tx_unicast);
    GW_RD(SE,TX_MULTICAST_CNT,port_on_chip,&counters->tx_multicast);
    GW_RD(SE,TX_BROADCAST_CNT,port_on_chip,&counters->tx_broadcast);
    GW_RD(SE,TX_SIZE64_CNT,port_on_chip,&counters->tx_size64);
    GW_RD(SE,TX_SIZE65TO127_CNT,port_on_chip,&counters->tx_size65_127);
    GW_RD(SE,TX_SIZE128TO255_CNT,port_on_chip,&counters->tx_size128_255);
    GW_RD(SE,TX_SIZE256TO511_CNT,port_on_chip,&counters->tx_size256_511);
    GW_RD(SE,TX_SIZE512TO1023_CNT,port_on_chip,&counters->tx_size512_1023);
    GW_RD(SE,TX_SIZE1024TO1518_CNT,port_on_chip,&counters->tx_size1024_1518);
    GW_RD(SE,TX_SIZE1519TOMAX_CNT,port_on_chip,&counters->tx_size1519_max);
    GW_RD(SE,TX_UNDERRUN_CNT,port_on_chip,&counters->tx_underrun);
    GW_RD(SE,RX_IPG_SHRINK_CNT,port_on_chip,&counters->rx_ipg_shrink);
    if (vtss_api_state->gw1e) {
        GW_RD(TXP,PORT_DROP_CNT,port_on_chip,&counters->tx_queue_system_drops);  
    } else
        /* Only one counter per D4 device in chip rev. 1 */
        GW_RD(TXP,QS_DROP_CNT,port_on_chip - (port_on_chip%4),&counters->tx_queue_system_drops);  
    if (VTSS_PORT_IS_10G(port_on_chip)) {
        counters->rx_alignment_err = 0;
        counters->tx_multi_coll    = 0;
        counters->tx_late_coll     = 0;
        counters->tx_xcoll         = 0;
        counters->tx_defer         = 0;
        counters->tx_csense        = 0;
        counters->tx_backoff1      = 0;
        counters->tx_backoff2      = 0;
        counters->tx_backoff3      = 0;
        counters->tx_backoff4      = 0;
        counters->tx_backoff5      = 0;
        counters->tx_backoff6      = 0;
        counters->tx_backoff7      = 0;
        counters->tx_backoff8      = 0;
        counters->tx_backoff9      = 0;
        counters->tx_backoff10     = 0;
        counters->tx_backoff11     = 0;
        counters->tx_backoff12     = 0;
        counters->tx_backoff13     = 0;
        counters->tx_backoff14     = 0;
        counters->tx_backoff15     = 0;
        GW_RD(D10_MAC,DROP_CNT,port_on_chip,&counters->tx_mac_drop);
    } else {
        GW_RD(SE,RX_ALIGNMENT_ERR_CNT,port_on_chip,&counters->rx_alignment_err);
        GW_RD(SE,TX_MULTI_COLL_CNT,port_on_chip,&counters->tx_multi_coll);
        GW_RD(SE,TX_LATE_COLL_CNT,port_on_chip,&counters->tx_late_coll);
        GW_RD(SE,TX_XCOLL_CNT,port_on_chip,&counters->tx_xcoll);
        GW_RD(SE,TX_DEFER_CNT,port_on_chip,&counters->tx_defer);
        GW_RD(SE,TX_CSENSE_CNT,port_on_chip,&counters->tx_csense);
        GW_RD(SE,TX_BACKOFF1_CNT,port_on_chip,&counters->tx_backoff1);
        GW_RD(SE,TX_BACKOFF2_CNT,port_on_chip,&counters->tx_backoff2);
        GW_RD(SE,TX_BACKOFF3_CNT,port_on_chip,&counters->tx_backoff3);
        GW_RD(SE,TX_BACKOFF4_CNT,port_on_chip,&counters->tx_backoff4);
        GW_RD(SE,TX_BACKOFF5_CNT,port_on_chip,&counters->tx_backoff5);
        GW_RD(SE,TX_BACKOFF6_CNT,port_on_chip,&counters->tx_backoff6);
        GW_RD(SE,TX_BACKOFF7_CNT,port_on_chip,&counters->tx_backoff7);
        GW_RD(SE,TX_BACKOFF8_CNT,port_on_chip,&counters->tx_backoff8);
        GW_RD(SE,TX_BACKOFF9_CNT,port_on_chip,&counters->tx_backoff9);
        GW_RD(SE,TX_BACKOFF10_CNT,port_on_chip,&counters->tx_backoff10);
        GW_RD(SE,TX_BACKOFF11_CNT,port_on_chip,&counters->tx_backoff11);
        GW_RD(SE,TX_BACKOFF12_CNT,port_on_chip,&counters->tx_backoff12);
        GW_RD(SE,TX_BACKOFF13_CNT,port_on_chip,&counters->tx_backoff13);
        GW_RD(SE,TX_BACKOFF14_CNT,port_on_chip,&counters->tx_backoff14);
        GW_RD(SE,TX_BACKOFF15_CNT,port_on_chip,&counters->tx_backoff15);
        GW_RD(D4_MAC,DROP_CNT,port_on_chip,&counters->tx_mac_drop);
    }

    return VTSS_OK;
}
 
/****************************************************************************
 *** Packet Control *********************************************************
 ****************************************************************************/

static vtss_rc gw_frame_rx_init(void)
{
    vtss_rc             rc = VTSS_OK;
    vtss_cpu_rx_queue_t queue_no;
    ulong               mask=0,sem;

    VTSS_D(("enter"));

    for (queue_no=VTSS_CPU_RX_QUEUE_START; queue_no<VTSS_CPU_RX_QUEUE_END; queue_no++) {
        mask|=(1<<(queue_no-VTSS_CPU_RX_QUEUE_START));
    }
    
    /* Enable reception of frames in CCA */
    GW_WR(CPU_CCA,QS_TXQS_CFG0,0,mask<<O_CPU_CCA_QS_TXQS_CFG0_CPUQS_WR_ENA);
    
    /* Get queue semaphore */
    GW_RDF(CPU_CCA,QS_SEMAPHORE,SEMA,0,&sem);
    if (sem!=1) {
        VTSS_E(("could not get CCA semaphore"));
        rc = VTSS_UNSPECIFIED_ERROR;
    }
    return rc;
}

/* Enable/disable frame ready interrupt */
vtss_rc vtss_ll_frame_rx_ready_int(vtss_cpu_rx_queue_t queue_no, BOOL enable)
{
    ulong          ims,mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("queue_no: %d, enable: %d",queue_no,enable));
    queue_no -= VTSS_CPU_RX_QUEUE_START;
    
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
    
        /* Enable/disable interrupts in PQS */
        GW_PI_RDF(CPU_PQS,INT_MASK_SET,FPN_IMS,&ims);
        mask = (1<<queue_no);
        if (enable)
            ims |= mask;
        else
            ims &= ~mask;
        GW_PI_WR(CPU_PQS,INT_MASK_SET,
                 (ims<<O_CPU_PQS_INT_MASK_SET_FPN_IMS)+
                 ((ims ? 1 : 0)<<O_CPU_PQS_INT_MASK_SET_DR_IMS));
        
        /* Enable/disable interrupts in PMB */
        GW_PI_WRF(CPU_PMB,INT_MASK_SET,PQS_IMS,ims ? 1 : 0);
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    
    return VTSS_OK;
}

/* Setup Rx queue map */
vtss_rc vtss_ll_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map)
{
    ulong          value, mask;
    uint           learn_queue;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
    learn_queue = map->learn_queue;
    vtss_api_state->learn_queue = learn_queue;

#if defined(VTSS_CHIPS)
    if (vtss_api_state->learn_auto)
        learn_queue = GW_LEARN_QUEUE;
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        value = (((map->bpdu_garp_queue-VTSS_CPU_RX_QUEUE_START)<<
                  O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_BPDU) |
                 ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<
                  O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_MC_CTRL) |
                 ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<
                  O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IGMP_REDIR));
#if defined(VTSS_FEATURE_LAYER3)
        value |= (((map->ip_opt_queue-VTSS_CPU_RX_QUEUE_START)<<
                   O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_OPT_REDIR) |
                  ((map->ip_error_queue-VTSS_CPU_RX_QUEUE_START)<<
                   O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_HDR_FAIL) |
                  ((map->rl_match_queue-VTSS_CPU_RX_QUEUE_START)<<
                   O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_RL));
#endif /* VTSS_FEATURE_LAYER3 */
        mask = ((M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_BPDU<<
                 O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_BPDU) |
                (M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_MC_CTRL<<
                 O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_MC_CTRL) |
                (M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IGMP_REDIR<<
                 O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IGMP_REDIR) |
                (M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_OPT_REDIR<<
                 O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_OPT_REDIR) |
                (M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_HDR_FAIL<<
                 O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_HDR_FAIL) |
                (M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_RL<<
                 O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_RL));
        GW_WR_MASKED(AN_RL_L3,RL_PROTO_CTRL,0,value,mask);

        if (vtss_api_state->gw1e) {
            value = (map->arp_bc_queue<<O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_CPU_QUEUE_SELECTED_BC);
            mask = (M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_CPU_QUEUE_SELECTED_BC<<
                    O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_CPU_QUEUE_SELECTED_BC);
            GW_WR_MASKED(AN_RL_L3,RL_CUSTOM_REDIR_CTRL,0,value,mask);
        }

#if defined(VTSS_FEATURE_LAYER3)
        GW_WR(AN_RL_L3,L3_CPU_QUEUE_CFG,0,
              ((map->ipuc_ttl_queue-VTSS_CPU_RX_QUEUE_START)<<
               O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_IP_TTL_FAIL) |
              ((map->ipuc_fail_queue-VTSS_CPU_RX_QUEUE_START)<<
               O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC_FAIL) |
              ((map->ipmc_fail_queue-VTSS_CPU_RX_QUEUE_START)<<
               O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_MC_FAIL) |
              ((map->ipuc_sec_queue-VTSS_CPU_RX_QUEUE_START)<<
               O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC_SECUR_FAIL) |
              ((map->ipuc_dmac_queue-VTSS_CPU_RX_QUEUE_START)<<
               O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC));
#endif /* VTSS_FEATURE_LAYER3 */

        GW_WR_MASKED(AN_L2_PS,L2_MAIN_CFG,0,
                     ((map->mac_vid_queue-VTSS_CPU_RX_QUEUE_START)<<
                      O_AN_L2_PS_L2_MAIN_CFG_FORW_CPU_COPY_QUEUE) | 
                     ((learn_queue-VTSS_CPU_RX_QUEUE_START)<<
                      O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE),
                     (M_AN_L2_PS_L2_MAIN_CFG_FORW_CPU_COPY_QUEUE<<
                      O_AN_L2_PS_L2_MAIN_CFG_FORW_CPU_COPY_QUEUE) | 
                     (M_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE<<
                      O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE));
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Set Rx queue size */
vtss_rc vtss_ll_cpu_rx_queue_size_set(const vtss_cpu_rx_queue_t queue_no, 
                                      const vtss_cpu_rx_queue_size_t size)
{
    uint           slices;
    ulong          mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    /* Calculate number of slices, max 63 */
    slices = (size/768);
    if (slices>63)
        slices = 63;
    
    mask = (1<<(O_CPU_CCA_QS_TXQS_CFG0_CPUQS_WR_ENA+queue_no-VTSS_CPU_RX_QUEUE_START));
                
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        /* Enable/disable reception of frames in CCA */
        GW_WR_MASKED(CPU_CCA,QS_TXQS_CFG0,0,slices ? mask : 0,mask);

        /* Setup queue size */
        GW_WR(CPU_CCA,QS_TXQS_DROP_CFG0+queue_no-VTSS_CPU_RX_QUEUE_START,0,slices);
        
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

/* Set frame registration */
vtss_rc vtss_ll_frame_reg_set(const vtss_cpu_rx_registration_t * const reg)
{
    int            i;
    ulong          value,mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        
        VTSS_D(("enter"));

        /* Set BPDU, IP MC and IGMP registrations */
        value = (
            ((reg->ipmc_ctrl_cpu_copy ? 1 : 0)<<
             O_AN_RL_L3_RL_PROTO_CTRL_IP_MC_CTRL_COPY_ENA) |
            ((reg->mcast_igmp_cpu_only ? 1 : 0)<<
             O_AN_RL_L3_RL_PROTO_CTRL_IGMP_REDIR_ENA) |
            (1<<O_AN_RL_L3_RL_PROTO_CTRL_IP_OPT_REDIR_ENA));
        if (!vtss_api_state->gw1e)
            value |= ((reg->bpdu_cpu_only[0] ? 1 : 0)<< 
                      O_AN_RL_L3_RL_PROTO_CTRL_BPDU_REDIR_ENA);
        mask = (
            (M_AN_RL_L3_RL_PROTO_CTRL_BPDU_REDIR_ENA<<
             O_AN_RL_L3_RL_PROTO_CTRL_BPDU_REDIR_ENA) |
            (M_AN_RL_L3_RL_PROTO_CTRL_IP_MC_CTRL_COPY_ENA<<
             O_AN_RL_L3_RL_PROTO_CTRL_IP_MC_CTRL_COPY_ENA) |
            (M_AN_RL_L3_RL_PROTO_CTRL_IGMP_REDIR_ENA<<
             O_AN_RL_L3_RL_PROTO_CTRL_IGMP_REDIR_ENA) |
            (M_AN_RL_L3_RL_PROTO_CTRL_IP_OPT_REDIR_ENA<<
             O_AN_RL_L3_RL_PROTO_CTRL_IP_OPT_REDIR_ENA));
        GW_WR_MASKED(AN_RL_L3,RL_PROTO_CTRL,0,value,mask);

        if (vtss_api_state->gw1e) {
            value = 0;
            for (i=0; i<16; i++) {
                value |= ((reg->bpdu_cpu_only[i] ? 1 : 0)<<
                          (O_AN_RL_L3_BPDU_REDIR_CTRL_BPDU_REDIR_ENA+i));
            }
            mask = (M_AN_RL_L3_BPDU_REDIR_CTRL_BPDU_REDIR_ENA<<
                    O_AN_RL_L3_BPDU_REDIR_CTRL_BPDU_REDIR_ENA);
            GW_WR_MASKED(AN_RL_L3,BPDU_REDIR_CTRL,0,value,mask);
        }
        
        /* Set GARP registrations */
        value = 0;
        for (i=0; i<16; i++) {
            value |= ((reg->garp_cpu_only[i] ? 1 : 0)<<
                      (O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_GXRP_REDIR_ENA+i));
        }
        mask = (M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_GXRP_REDIR_ENA<<
                O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_GXRP_REDIR_ENA);

        if (vtss_api_state->gw1e) {
            value |= (
#if defined(VTSS_FEATURE_LAYER3)
                ((reg->bcast_rl_match_all ? 1 : 0)<<
                 O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_ALL_BC_COPY_ENA) |
                ((reg->bcast_rl_match_sel ? 1 : 0)<<
                 O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_SELECTED_BC_COPY_ENA) |
#endif /* VTSS_FEATURE_LAYER3 */
                (1<<O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_SELECTED_BC_COPY_ENA));
            mask |= (
#if defined(VTSS_FEATURE_LAYER3)
                (M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_ALL_BC_COPY_ENA<<
                 O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_ALL_BC_COPY_ENA) |
                (M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_SELECTED_BC_COPY_ENA<<
                 O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_SELECTED_BC_COPY_ENA) |
#endif /* VTSS_FEATURE_LAYER3 */
                (M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_SELECTED_BC_COPY_ENA<<
                 O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_SELECTED_BC_COPY_ENA));
        }
        GW_WR_MASKED(AN_RL_L3,RL_CUSTOM_REDIR_CTRL,0,value,mask);

        if (vtss_api_state->gw1e) {
            uint port_on_chip;

            /* Setup ARP filtering for each Rx port module */
            value = (((reg->bcast_arp_cpu_copy_all ? 1 : 0)<<
                      O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_ALL_ENA) |
                     ((reg->bcast_arp_cpu_copy_sel ? 1 : 0)<<
                      O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_TAR_ENA));
            mask = ((M_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_ALL_ENA<<
                     O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_ALL_ENA) |
                    (M_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_TAR_ENA<<
                     O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_TAR_ENA));
            
            for (port_on_chip=0; port_on_chip<VTSS_CHIP_PORTS; port_on_chip++) {
                if ((port_on_chip%4)==0) {
                    GW_WR_MASKED(RXP,DP_AND_CPU_BC_COPY_CFG,port_on_chip,value,mask);
                    GW_WR(RXP,ARP_BC_TAR_CFG,port_on_chip,reg->arp_ip);
                }
            }
        }

#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
} 

static vtss_rc gw1e_learn_check(vtss_system_frame_header_t *sys_header, uchar *frame)
{
    vtss_port_no_t         port_no;
    vtss_vid_t             vid;
    vtss_stp_state_t       stp_state;
    vtss_mstp_state_t      mstp_state;
    vtss_mac_table_entry_t entry;
    vtss_pgid_no_t         pgid_no;
    uint                   i;
    
    port_no = sys_header->source_port_no;
    vid = sys_header->tag.vid;
    stp_state = vtss_api_state->stp_state[port_no];
    mstp_state = vtss_api_state->mstp_table[
        vtss_api_state->vlan_table[vid].msti].state[port_no];
    if (vtss_api_state->learn_auto &&
        stp_state!=VTSS_STP_STATE_BLOCKING &&
        stp_state!=VTSS_STP_STATE_LISTENING &&
        mstp_state!=VTSS_MSTP_STATE_DISCARDING) {
        /* Learn (VID, SMAC) if learning allowed */
        entry.vid_mac.vid = vid;
        for (i=0; i<6; i++)
            entry.vid_mac.mac.addr[i] = frame[6+i];
        entry.copy_to_cpu = 0;
        entry.locked = 0;
        entry.aged = 0;
        pgid_no = vtss_api_state->logical_port_no[port_no];
        VTSS_RC(vtss_ll_mac_table_learn(&entry, pgid_no));
    }
    return VTSS_OK;
}

#if VTSS_OPT_DMA

/* Frame word padding */
#define VTSS_FRAME_PAD(len) (3 - ((len + 3) % 4))

vtss_rc vtss_ll_frame_dma_rx_ready(void)
{
    vtss_packet_rx_t *rx_packet;
    ulong            ifh[2];
    int              length;
    uint             port_on_chip;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t   chip_no;
    int              i;
#endif /* VTSS_CHIPS */
    rx_packet=&vtss_api_state->rx_packet;
    if (rx_packet->used) {
        VTSS_N(("packet already used"));
        return 1;
    }
#if defined(VTSS_CHIPS)
    for (i = 0; i < VTSS_CHIPS; i++) {
        /* Select next chip */
        chip_no = (rx_packet->chip_no + 1) % VTSS_CHIPS;
        rx_packet->chip_no = chip_no;
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        if (vtss_io_dma_read(sizeof(ifh), (uchar *)&ifh[0], 8) == VTSS_OK) {
            /* Calculate frame length excluding preamble and IFH */
            length=((((ifh[0]>>O_IFH0_LENGTH) & M_IFH0_LENGTH)-1)*96+
                    ((ifh[0]>>O_IFH0_BYTES) & M_IFH0_BYTES)-16);
            if (length < 0) {
                VTSS_E(("frame too small: %d", length));
                return 0;
            }
            port_on_chip=((ifh[1]>>O_IFH1_PORTNO) & M_IFH1_PORTNO);
            
            VTSS_N(("ifh0: 0x%08lx, ifh1: 0x%08lx, length: %d, port_on_chip: %d",
                    ifh[0],ifh[1],length,port_on_chip));
#ifdef VTSS_CHIPS
            /* Check if it is an internal port */
            if (port_on_chip==vtss_api_state->iport_setup[
                    vtss_api_state->iport_first[chip_no]].chip_port ||
                port_on_chip==vtss_api_state->iport_setup[
                    vtss_api_state->iport_last[chip_no]].chip_port) {
                VTSS_N(("discarded packet on internal port_on_chip: %d",port_on_chip));
                vtss_io_dma_read(0, NULL, length + VTSS_FRAME_PAD(length));
                return 0;
            }
#endif /* VTSS_CHIPS */
    
            /* Fill out system header */
#if VTSS_OPT_INCLUDE_FCS
            rx_packet->sys_header.length=length;
#else
            rx_packet->sys_header.length=(length-VTSS_FCS_SIZE);
#endif /* VTSS_OPT_INCLUDE_FCS */
#if defined(VTSS_CHIPS)
            rx_packet->sys_header.source_port_no=vtss_api_state->port_map.vtss_port[chip_no][port_on_chip];
#else
            rx_packet->sys_header.source_port_no=vtss_api_state->port_map.vtss_port[port_on_chip];
#endif /* VTSS_CHIPS */
            rx_packet->sys_header.arrived_tagged=((ifh[1]>>O_IFH1_WASTAG) & M_IFH1_WASTAG);
            rx_packet->sys_header.tag.vid=((ifh[1]>>O_IFH1_VID) & M_IFH1_VID);
            rx_packet->sys_header.tag.cfi=((ifh[0]>>O_IFH0_CFI) & M_IFH0_CFI);
            rx_packet->sys_header.tag.tagprio=((ifh[0]>>O_IFH0_UPRIO) & M_IFH0_UPRIO);
            rx_packet->used=1;
            rx_packet->length=0;
            return 1;
        }
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return 0;
}

vtss_rc vtss_ll_frame_dma_rx(vtss_system_frame_header_t *sys_header,
                             uchar *frame, 
                             uint maxlength)
{
    uint             i,length,skip;
    vtss_packet_rx_t *rx_packet;

    /* Check that the packet header has been extracted */
    rx_packet=&vtss_api_state->rx_packet;
    if (!rx_packet->used) {
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Copy frame header */
    *sys_header=rx_packet->sys_header;

    /* Check if the application is just requesting the header */
    if (frame==NULL) {
        return VTSS_PACKET_BUF_SMALL;
    }
    
    /* Check buffer size, if the application has previously done a preview */
    length=rx_packet->length;
    if (length && maxlength<sys_header->length) {
        VTSS_E(("buffer still too small: %d, frame length: %d",
                maxlength,sys_header->length));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* If the application has previously done a preview, copy preview from API buffer */
    for (i=0; i<length; i++)
        frame[i]=rx_packet->buf[i];

    /* Read frame from DMA */
    if (maxlength < sys_header->length) {
        length = maxlength;
        skip = 0;
    } else {
        length = sys_header->length;
#if VTSS_OPT_INCLUDE_FCS
        skip = VTSS_FRAME_PAD(length);
#else
        skip = (VTSS_FCS_SIZE + VTSS_FRAME_PAD(length));
#endif /* VTSS_OPT_INCLUDE_FCS */
    }
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[rx_packet->chip_no]);
#endif /* VTSS_CHIPS */
    VTSS_RC(vtss_io_dma_read(length-i, &frame[i], skip));
    
    /* Copy preview or release frame */
    if (sys_header->length>maxlength) {
        /* Frame preview was done, copy preview to API buffer */
        for (i=0; i<maxlength; i++)
            rx_packet->buf[i]=frame[i];
        rx_packet->length=maxlength;
        return VTSS_PACKET_BUF_SMALL;
    } else {
        rx_packet->used=0;
        rx_packet->length=0;
        return gw1e_learn_check(sys_header, frame);
    }
}

vtss_rc vtss_ll_frame_dma_rx_discard(void)
{
    vtss_packet_rx_t *rx_packet;
    int              length;

    rx_packet=&vtss_api_state->rx_packet;

    /* Discard frame if the header has been extracted */
    if (rx_packet->used) {
#if defined(VTSS_CHIPS)
        vtss_io_select_chip(&vtss_state->io[rx_packet->chip_no]);
#endif /* VTSS_CHIPS */
        length = (rx_packet->sys_header.length - rx_packet->length + VTSS_FCS_SIZE);
        vtss_io_dma_read(0, NULL, length + VTSS_FRAME_PAD(length));
        rx_packet->used = 0;
        rx_packet->length = 0;
    }
    return VTSS_OK;
}
#endif /* VTSS_OPT_DMA */
        
/* Determine if a frame is ready in the CPU Rx queue */
vtss_rc vtss_ll_frame_rx_ready(vtss_cpu_rx_queue_t queue_no)
{
    BOOL             use_cpu_si;
    vtss_packet_rx_t *rx_packet;
    ulong            fpn,ready,dummy;
    ulong            ifh0,ifh1;
    int              i,length;
    uint             port_on_chip;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t   chip_no;
#endif /* VTSS_CHIPS */
    
    VTSS_N(("queue_no: %d",queue_no));
    queue_no -= VTSS_CPU_RX_QUEUE_START;
    use_cpu_si=vtss_api_state->init_setup.use_cpu_si;
    
    rx_packet=&vtss_api_state->rx_packet;
    if (rx_packet->used) {
        VTSS_N(("packet already used"));
        return 1;
    }

    /* No packet in current buffer, try to extract one */
#if defined(VTSS_CHIPS)
    for (i=0; i<VTSS_CHIPS; i++) {
        
        /* Select next chip */
        chip_no=rx_packet->chip_no;
        chip_no=(chip_no==VTSS_CHIP_NO_START ? (chip_no+1) : VTSS_CHIP_NO_START);
        rx_packet->chip_no=chip_no;
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        
        if (use_cpu_si) {
            GW_RDF(CPU_CCA,QS_STATUS,CPUQS_FPN,0,&fpn);
        } else {
            GW_PI_RDF(CPU_PQS,INT_STATUS,FPN_IS,&fpn);
        }

        /* If packet ready, exit loop */
        if (fpn & (1<<queue_no)) {
            break;
        }

        /* If packet not ready and it is the second try, return */
        if (i!=0) {
            VTSS_N(("no packet ready yet"));
            return 0;
        }
    }
#else
    if (use_cpu_si) {
        GW_RDF(CPU_CCA,QS_STATUS,CPUQS_FPN,0,&fpn);
    } else {
        GW_PI_RDF(CPU_PQS,INT_STATUS,FPN_IS,&fpn);
    }
    if (!(fpn & (1<<queue_no))) {
        VTSS_N(("no packet ready yet"));
        return 0;
    }
#endif /* VTSS_CHIPS */
    
    /* Packet ready, extract to buffer */
    if (use_cpu_si) {
        GW_WR(CPU_CCA,QS_QUEUE_SEL,0,1<<queue_no);
    } else {
        GW_PI_WR(CPU_PQS,QUEUE_SEL,1<<queue_no);
    }
    
    /* Wait until frame ready */
    for (i=0;; i++) {
        if (use_cpu_si) {
            GW_RDF(CPU_CCA,QS_STATUS,CPUQS_DR,0,&ready);
        } else {
            GW_PI_RDF(CPU_PQS,INT_STATUS,DR_IS,&ready);
        }
        if (ready)
            break;
        
        if (i==100) {
            VTSS_E(("frame not ready on queue %d after %d retries",queue_no,i));
            return 0;
        }
    }
            
    if (use_cpu_si) {
        /* Read IFH and preamble */
        GW_RD(CPU_CCA,QS_DATA,0,&ifh0);
        GW_RD(CPU_CCA,QS_DATA,0,&ifh1);
        GW_RD(CPU_CCA,QS_DATA,0,&dummy);
        GW_RD(CPU_CCA,QS_DATA,0,&dummy);
    } else {
        /* Read IFH and preamble */
        GW_PI_RD(CPU_PQS,DATA,&ifh0);
        GW_PI_RD(CPU_PQS,DATA,&ifh1);
        GW_PI_RD(CPU_PQS,DATA,&dummy);
        GW_PI_RD(CPU_PQS,DATA,&dummy);
    }

    /* Calculate frame length excluding preamble and IFH */
    length=((((ifh0>>O_IFH0_LENGTH) & M_IFH0_LENGTH)-1)*96+
            ((ifh0>>O_IFH0_BYTES) & M_IFH0_BYTES)-16);
    port_on_chip=((ifh1>>O_IFH1_PORTNO) & M_IFH1_PORTNO);
    
    VTSS_N(("ifh0: 0x%08lx, ifh1: 0x%08lx, length: %d, port_on_chip: %d",
            ifh0,ifh1,length,port_on_chip));

#ifdef VTSS_CHIPS
    /* Check if it is an internal port */
    if (port_on_chip==vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port ||
        port_on_chip==vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port) {
        VTSS_N(("discarded packet on internal port_on_chip: %d",port_on_chip));
        GW_WR(CPU_CCA,QS_CTRL,0,1<<O_CPU_CCA_QS_CTRL_CPUQS_FLUSH);
        return 0;
    }
#endif /* VTSS_CHIPS */
    
    /* Length check */
    if (length<0) {
        VTSS_E(("frame too small on queue %d",queue_no));
        GW_WR(CPU_CCA,QS_CTRL,0,1<<O_CPU_CCA_QS_CTRL_CPUQS_FLUSH);
        return 0;
    }
    
    /* Fill out system header */
#if VTSS_OPT_INCLUDE_FCS
    rx_packet->sys_header.length=length;
#else
    rx_packet->sys_header.length=(length-VTSS_FCS_SIZE);
#endif /* VTSS_OPT_INCLUDE_FCS */
#if defined(VTSS_CHIPS)
    rx_packet->sys_header.source_port_no=vtss_api_state->port_map.vtss_port[chip_no][port_on_chip];
#else
    rx_packet->sys_header.source_port_no=vtss_api_state->port_map.vtss_port[port_on_chip];
#endif /* VTSS_CHIPS */
    rx_packet->sys_header.arrived_tagged=((ifh1>>O_IFH1_WASTAG) & M_IFH1_WASTAG);
    rx_packet->sys_header.tag.vid=((ifh1>>O_IFH1_VID) & M_IFH1_VID);
    rx_packet->sys_header.tag.cfi=((ifh0>>O_IFH0_CFI) & M_IFH0_CFI);
    rx_packet->sys_header.tag.tagprio=((ifh0>>O_IFH0_UPRIO) & M_IFH0_UPRIO);
    
    rx_packet->queue_no=queue_no;
    rx_packet->used=1;
    rx_packet->length=0;
    
    return 1;
}

/* Get frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx(vtss_cpu_rx_queue_t queue_no, 
                         vtss_system_frame_header_t *sys_header,
                         uchar *frame, 
                         uint maxlength)
{
    uint             i,length;
    vtss_packet_rx_t *rx_packet;
    BOOL             use_cpu_si;
    ulong            data;

    VTSS_D(("queue_no: %d",queue_no));
    queue_no -= VTSS_CPU_RX_QUEUE_START;

    /* Check that the packet header has been extracted */
    rx_packet=&vtss_api_state->rx_packet;
    if (!rx_packet->used) {
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Check that the current frame is from the right queue */
    if (rx_packet->queue_no!=queue_no) {
        VTSS_E(("used queue: %d, queue_no: %d",rx_packet->queue_no,queue_no));
        return VTSS_UNSPECIFIED_ERROR;
    }
    
    /* Copy frame header */
    *sys_header=rx_packet->sys_header;

    /* Check if the application is just requesting the header */
    if (frame==NULL) {
        return VTSS_PACKET_BUF_SMALL;
    }
    
    /* Check buffer size, if the application has previously done a preview */
    length=rx_packet->length;
    if (length && maxlength<sys_header->length) {
        VTSS_E(("buffer still too small: %d, frame length: %d",
                maxlength,sys_header->length));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* If the application has previously done a preview, copy preview from API buffer */
    for (i=0; i<length; i++)
        frame[i]=rx_packet->buf[i];

    /* Read frame from chip */
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[rx_packet->chip_no]);
#endif /* VTSS_CHIPS */
    use_cpu_si=vtss_api_state->init_setup.use_cpu_si;
    length=sys_header->length;
    if (maxlength<length)
        length=maxlength;
    for (; i<length; i+=4) {
        if (use_cpu_si) {
            GW_RD(CPU_CCA,QS_DATA,0,&data);
        } else {
            GW_PI_RD(CPU_PQS,DATA,&data);
        }
        frame[i+0]=((data>>24) & 0xff);
        frame[i+1]=((data>>16) & 0xff);
        frame[i+2]=((data>>8) & 0xff);
        frame[i+3]=(data & 0xff);
    }
    
    /* Copy preview or release frame */
    if (sys_header->length>maxlength) {
        /* Frame preview was done, copy preview to API buffer */
        for (i=0; i<maxlength; i++)
            rx_packet->buf[i]=frame[i];
        rx_packet->length=maxlength;
        return VTSS_PACKET_BUF_SMALL;
    } else {
#if !VTSS_OPT_INCLUDE_FCS
        /* Read FCS */
        if (use_cpu_si) {
            GW_RD(CPU_CCA,QS_DATA,0,&data);
        } else {
            GW_PI_RD(CPU_PQS,DATA,&data);
        }
#endif /* VTSS_OPT_INCLUDE_FCS */
        rx_packet->used=0;
        rx_packet->length=0;
        if (vtss_api_state->gw1e)
            return gw1e_learn_check(sys_header, frame);
        return VTSS_OK;
    }
}

/* Discard frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx_discard(vtss_cpu_rx_queue_t queue_no)
{
    vtss_packet_rx_t *rx_packet;

    VTSS_N(("queue_no: %d",queue_no));
    queue_no -= VTSS_CPU_RX_QUEUE_START;

    rx_packet=&vtss_api_state->rx_packet;

    /* Discard frame if the header has been extracted for this queue */
    if (rx_packet->used && rx_packet->queue_no==queue_no) {
#if defined(VTSS_CHIPS)
        vtss_io_select_chip(&vtss_state->io[rx_packet->chip_no]);
#endif /* VTSS_CHIPS */
       GW_WR(CPU_CCA,QS_CTRL,0,1<<O_CPU_CCA_QS_CTRL_CPUQS_FLUSH);
       rx_packet->used=0;
       rx_packet->length=0;
    }

    return VTSS_OK;
}

#define VTSS_CPUTX_BUSY_MAXRETRIES 10000

/* Transmit frame on port, optionally with tag */
vtss_rc vtss_ll_frame_tx(vtss_port_no_t port_no, const uchar *frame, uint length, vtss_vid_t vid)
{
    uint    port_on_chip,base_port,len,i;
    ulong   busy,ifh0,ifh1,data;
    BOOL    use_cpu_si;
    uint    retry_count;

    VTSS_D(("port_no: %d",port_no));

    port_on_chip=vtss_api_state->port_map.chip_port[port_no];
    base_port=4*(port_on_chip/4);

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    /* Check that the port is not busy */
    retry_count = 0;
    do {
        GW_RDF(TXP,QS_CPU_CTRL,BUSY,base_port,&busy);
    } while (busy && retry_count++<VTSS_CPUTX_BUSY_MAXRETRIES);
    if (busy) {
        VTSS_E(("device with port_no %d is busy",port_no));
        return VTSS_TIMEOUT_RETRYLATER;
    }
    
    /* Calculate data length including tag, padding and FCS */
#if VTSS_OPT_INCLUDE_FCS
    len=length;
#else
    len=(length+VTSS_FCS_SIZE);
#endif /* VTSS_OPT_INCLUDE_FCS */
    if (vid!=VTSS_VID_NULL)
        len+=4;
    if (len<64)
        len=64;

    /* Write the CPU header */
    len+=16;
    GW_WR(TXP,QS_CPU_DATA,base_port,((port_on_chip%4)<<14)+len);
    
    ifh0 = ((((len-1)/96+1)<<O_IFH0_LENGTH)+(((len-1)%96+1)<<O_IFH0_BYTES));
    ifh1 = ((PORT_ON_CHIP_RESV<<O_IFH1_PORTNO)+(1<<O_IFH1_UPDFCS)+(1<<O_IFH1_DONTTCH));
    len-=16;
    use_cpu_si=vtss_api_state->init_setup.use_cpu_si;
    if (use_cpu_si) {
        /* Write IFH */
        GW_WR(TXP,QS_CPU_DATA,base_port,ifh0);
        GW_WR(TXP,QS_CPU_DATA,base_port,ifh1);
        
        /* Write preamble */
        GW_WR(TXP,QS_CPU_DATA,base_port,0x55555555);
        GW_WR(TXP,QS_CPU_DATA,base_port,0x555555d5);
    } else {
        /* Write IFH */
        GW_PI_WR(CPU_PIA,DATA_REQ,ifh0);
        GW_PI_WR(CPU_PIA,DATA_REQ,ifh1);
        
        /* Write preamble */
        GW_PI_WR(CPU_PIA,DATA_REQ,0x55555555);
        GW_PI_WR(CPU_PIA,DATA_REQ,0x555555d5);
    }
    /* Write the data */
    if (vid!=VTSS_VID_NULL)
        len-=4;
    for (i=0; i<len; i+=4) {
        if ((i+3)<length) {
            /* Pure data */
            data=((frame[i]<<24)+(frame[i+1]<<16)+(frame[i+2]<<8)+frame[i+3]);
        } else {
            /* Padding and data */
            data=0;
            if (i<length)
                data+=(frame[i]<<24);
            if ((i+1)<length)
                data+=(frame[i+1]<<16);
            if ((i+2)<length)
                data+=(frame[i+2]<<8);
        }

        if (use_cpu_si) {
            GW_WR(TXP,QS_CPU_DATA,base_port,data);
        } else {
            GW_PI_WR(CPU_PIA,DATA_REQ,data);
        }
        
        if (i==8 && vid!=VTSS_VID_NULL) {
            /* Insert tag */
            data = ((0x8100<<16)+vid);
            if (use_cpu_si) {
                GW_WR(TXP,QS_CPU_DATA,base_port,data);
            } else {
                GW_PI_WR(CPU_PIA,DATA_REQ,data);
            }
        }
    }
    
    return VTSS_OK;
}

/****************************************************************************
 *** Layer 2 ****************************************************************
 ****************************************************************************/

static vtss_rc gw_pmap_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,RL_PORT_MAP_CTRL,PORT_TABLE_CMD,0,&cmd);
        if (cmd==PORT_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize logical port map table */
static vtss_rc gw_pmap_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    GW_WR(AN_RL_L3,RL_PORT_MAP_CTRL,0,
          PORT_CMD_CLEAR<<O_AN_RL_L3_RL_PORT_MAP_CTRL_PORT_TABLE_CMD);

    /* Wait until idle again */
    return gw_pmap_table_idle();
}

static vtss_rc gw_pmap_table_write(uint physical_port_on_chip, 
                                   uint logical_port_on_chip, 
                                   uint glag)
{
    ulong value;

    VTSS_D(("physical_port_on_chip: %d, logical_port_on_chip: %d, glag: %d",
            physical_port_on_chip,logical_port_on_chip,glag));

    /* Set logical port number */
    value = (logical_port_on_chip<<O_AN_RL_L3_RL_PORT_MAP_CFG_LOGICAL_PORT_NUM);
    if (vtss_api_state->gw1e)
        value |= (glag<<O_AN_RL_L3_RL_PORT_MAP_CFG_GLAG_NUM);
    GW_WR(AN_RL_L3,RL_PORT_MAP_CFG,0,value);
    
    /* Set physical port number and issue write command */
    GW_WR(AN_RL_L3,RL_PORT_MAP_CTRL,0,
          (physical_port_on_chip<<O_AN_RL_L3_RL_PORT_MAP_CTRL_PHYS_PORT_INDEX) |
          (PORT_CMD_WRITE<<O_AN_RL_L3_RL_PORT_MAP_CTRL_PORT_TABLE_CMD));

    /* Wait until idle again */
    return gw_pmap_table_idle();
}

/* Set logical port mapping */
vtss_rc vtss_ll_pmap_table_write(vtss_port_no_t physical_port_no, 
                                 vtss_port_no_t logical_port_no)
{
    uint lport, glag;

    VTSS_D(("physical_port_no: %d, logical_port_no: %d",
            physical_port_no,logical_port_no));

    /* By default, the GLAG is zero and the logical port is used */
    glag = 0;
    lport = vtss_api_state->port_map.chip_port[logical_port_no];

    if (vtss_api_state->gw1e) {
        vtss_api_state->logical_port_no[physical_port_no] = logical_port_no;
#if defined(VTSS_CHIPS)
        /* The logical port is used as GLAG, the physical port maps to itself */
        glag = logical_port_no;
        lport = vtss_api_state->port_map.chip_port[physical_port_no];
#endif /* VTSS_CHIPS */
    }
    
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[physical_port_no]]);
#endif /* VTSS_CHIPS */

    return gw_pmap_table_write(vtss_api_state->port_map.chip_port[physical_port_no],
                               lport,glag);
}

/* Set learn mode */
vtss_rc vtss_ll_learn_mode_set(vtss_learn_mode_t * const learn_mode)
{
    uint           learn_queue;
    BOOL           cpu,discard;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    vtss_msti_t    msti;
#endif /* VTSS_CHIPS */
    
    learn_queue = (vtss_api_state->learn_queue - VTSS_CPU_RX_QUEUE_START);
    cpu = MAKEBOOL01(learn_mode->cpu);
    discard = MAKEBOOL01(learn_mode->discard);
    
#if defined(VTSS_CHIPS)
    vtss_api_state->learn_auto = learn_mode->automatic;
    if (learn_mode->automatic) {
        /* For 48-port solutions, automatic learning always means that CPU learning 
           to the reserved queue is done and learn frames are forwarded */
        learn_queue = (GW_LEARN_QUEUE - VTSS_CPU_RX_QUEUE_START);
        cpu = 1;
        discard = 0;
    }
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        
        /* Update learn state for internal ports */
        for (msti = VTSS_MSTI_START; msti < vtss_api_state->msti_end; msti++) {
            uint iport;

            for (iport=vtss_api_state->iport_first[chip_no]; 
                 iport<=vtss_api_state->iport_last[chip_no]; 
                 iport++) {
                VTSS_RC(gw_mstp_table_write(vtss_api_state->iport_setup[iport].chip_port,
                                            msti-VTSS_MSTI_START,
                                            learn_mode->automatic,
                                            1));
            }
        }
#endif /* VTSS_CHIPS */

        GW_WR_MASKED(AN_L2_PS,L2_MAIN_CFG,0,
                     (MAKEBOOL01(learn_mode->automatic)<<O_AN_L2_PS_L2_MAIN_CFG_L2_LEARN_ENA) |
                     (cpu<<O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_ENA) | 
                     (learn_queue<<O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE) |
                     (discard<<O_AN_L2_PS_L2_MAIN_CFG_LEARN_DROP),
                     (M_AN_L2_PS_L2_MAIN_CFG_L2_LEARN_ENA<<
                      O_AN_L2_PS_L2_MAIN_CFG_L2_LEARN_ENA) |
                     (M_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_ENA<<
                      O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_ENA) |
                     (M_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE<<
                      O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE) |
                     (M_AN_L2_PS_L2_MAIN_CFG_LEARN_DROP<<
                      O_AN_L2_PS_L2_MAIN_CFG_LEARN_DROP));
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

static vtss_rc gw_vlan_port_mode_set(uint port_on_chip, const vtss_vlan_port_mode_t *vlan_mode)
{
    vtss_rc rc;

    VTSS_D(("port_on_chip:%d, aware:%d, pvid:%d, uvid:%d, frame_type:%s, ingress_filter:%d",
            port_on_chip,
            vlan_mode->aware,
            vlan_mode->pvid,
            vlan_mode->untagged_vid,
            vlan_mode->frame_type==VTSS_VLAN_FRAME_TAGGED ? "tagged" : "all",
            vlan_mode->ingress_filter));

    /* Set VLAN awareness, PVID and accepted frames in Rx path */
    GW_WR_MASKED(RXP,PORT_VLAN_CFG,port_on_chip,
                 /* value */
                 (vlan_mode->pvid<<O_RXP_PORT_VLAN_CFG_VLAN_DEF) |
                 ((vlan_mode->frame_type==VTSS_VLAN_FRAME_TAGGED ? 0 : 1)<<O_RXP_PORT_VLAN_CFG_VLAN_UNTAGGED_ENA) |
                 ((vlan_mode->aware ? 1 : 0)<<O_RXP_PORT_VLAN_CFG_VLAN_AWARE_ENA),
                 /* mask */
                 (M_RXP_PORT_VLAN_CFG_VLAN_DEF<<O_RXP_PORT_VLAN_CFG_VLAN_DEF) |
                 (M_RXP_PORT_VLAN_CFG_VLAN_UNTAGGED_ENA<<O_RXP_PORT_VLAN_CFG_VLAN_UNTAGGED_ENA) |
                 (M_RXP_PORT_VLAN_CFG_VLAN_AWARE_ENA<<O_RXP_PORT_VLAN_CFG_VLAN_AWARE_ENA));
    
    /* Set tag mode in Tx path */
    GW_WRF(TXP,REWR_CFG,TAG_1Q,port_on_chip, vlan_mode->untagged_vid!=VTSS_VID_ALL ? 1 : 0);
    
    /* Set untagged VID in Tx path */
    GW_WRF(TXP,REWR_UNTAGGED_VLAN,UNTAGGED_VLAN,port_on_chip,
           vlan_mode->untagged_vid & 0xfff);
    
    /* Set ingress filtering in Analyzer */
    rc = gw_wrf(TR(AN_RL_L3,L3_VLAN_FILT_CTRL),port_on_chip,0x1,0,vlan_mode->ingress_filter ? 1 : 0);
    
    return rc;
}

/* Set VLAN port mode */
vtss_rc vtss_ll_vlan_port_mode_set(vtss_port_no_t port_no, const vtss_vlan_port_mode_t *vlan_mode)
{
    uint port_on_chip;

    VTSS_D(("port_no: %d, aware: %d, pvid: %d, uvid: %d, frame_type: %s, ingress_filter: %d",
            port_no,vlan_mode->aware,vlan_mode->pvid,vlan_mode->untagged_vid,
            vlan_mode->frame_type==VTSS_VLAN_FRAME_TAGGED ? "tagged" : "all",
            vlan_mode->ingress_filter));

#if defined(VTSS_CHIPS)
    {
        BOOL           vlan_aware;
        vtss_vid_t     pvid;
        vtss_port_no_t port_no;

        /* Determine if the internal ports must run VLAN aware */ 
        vlan_aware = 0;
        pvid = vtss_api_state->vlan_port_table[VTSS_PORT_NO_START].pvid;
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (vtss_api_state->vlan_port_table[port_no].aware ||
                vtss_api_state->vlan_port_table[port_no].pvid!=pvid) {
                vlan_aware = 1;
                break;
            }
        }

        /* Setup internal ports if VLAN awareness has changed */
        if (vlan_aware!=vtss_api_state->vlan_aware) {
            vtss_vlan_port_mode_t mode;
            vtss_chip_no_t        chip_no;
            uint                  iport;

            vtss_api_state->vlan_aware = vlan_aware;

            VTSS_D(("changing internal ports to VLAN %s",vlan_aware ? "aware" : "unaware"));
            mode.aware = vlan_aware;
            mode.pvid = (vlan_aware ? VTSS_VID_NULL : pvid);
            mode.untagged_vid = mode.pvid;
            mode.frame_type = VTSS_VLAN_FRAME_ALL;
            mode.ingress_filter = 0;

            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
                for (iport=vtss_api_state->iport_first[chip_no]; 
                     iport<=vtss_api_state->iport_last[chip_no]; 
                     iport++) {
                    port_on_chip = vtss_api_state->iport_setup[iport].chip_port;
                    VTSS_RC(gw_vlan_port_mode_set(port_on_chip, &mode));
                }
            }
        }
    }
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    port_on_chip = vtss_api_state->port_map.chip_port[port_no];
    return gw_vlan_port_mode_set(port_on_chip, vlan_mode);
}

static vtss_rc gw_vlan_table_idle(void) 
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_VLAN_CTRL,VLAN_CMD,0,&cmd);
        if (cmd==VLAN_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize VLAN table */
static vtss_rc gw_vlan_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command and enable VLAN table */
    GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
          (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) |
          (VLAN_CMD_CLEAR<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
    
    /* Wait until idle again */
    return gw_vlan_table_idle();
}

/* Set VLAN port members */
vtss_rc vtss_ll_vlan_table_write(vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    ulong          mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
#if defined(VTSS_FEATURE_LAYER3) 
    if (gw_rl_vlan_update(vid, member) < 0) {
        VTSS_E(("router leg update failed"));
        return VTSS_UNSPECIFIED_ERROR;
    } 
#endif /* VTSS_FEATURE_LAYER3 */ 

#if defined(VTSS_CHIPS)
    /* Get membership mask(s) */
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        
        mask = gw_list2mask(chip_no,member);
        
        /* Include internal ports if any port on the other chip is included */
        if (gw_list2mask(chip_no==VTSS_CHIP_NO_START ? (chip_no+1) : (chip_no-1),member)!=0) { 
            mask |= ((1<<vtss_api_state->iport_setup[
                          vtss_api_state->iport_first[chip_no]].chip_port) |
                     (1<<vtss_api_state->iport_setup[
                         vtss_api_state->iport_last[chip_no]].chip_port));
        }
        VTSS_D(("chip_no: %d, vid: %d, mask: %08lx",chip_no,vid,mask));
#else
        mask=gw_list2mask(member);
        VTSS_D(("vid: %d, mask: %08lx",vid,mask));
#endif /* VTSS_CHIPS */
    
        /* Issue read command */
        GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
              (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) | 
              (vid<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX) | 
              (VLAN_CMD_READ<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
        
        /* Wait until idle again */
        VTSS_RC(gw_vlan_table_idle());
        
        /* Set valid flag */
        GW_WRF(AN_RL_L3,L3_VLAN_CFG_1,VALID,0,1);
        
        /* Set port mask */
        GW_WR(AN_RL_L3,L3_VLAN_CFG_2,0,mask);
        
        /* Issue write command */
        GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
              (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) | 
              (vid<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX) | 
              (VLAN_CMD_WRITE<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
        
        /* Wait until idle again */
        VTSS_RC(gw_vlan_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Set VLAN MSTP instance */
vtss_rc vtss_ll_vlan_table_mstp_set(vtss_vid_t vid, uint msti)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    msti -= VTSS_MSTI_START;

#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        VTSS_D(("chip_no: %d, vid: %d, msti: %d",chip_no,vid,msti));
#else
        VTSS_D(("vid: %d, msti: %d",vid,msti));
#endif /* VTSS_CHIPS */
    
        /* Issue read command */
        GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
              (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) | 
              (vid<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX) | 
              (VLAN_CMD_READ<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
    
        /* Wait until idle again */
        VTSS_RC(gw_vlan_table_idle());
        
        /* Set MSTP index */
        if (vtss_api_state->gw1e) {
            GW_WRF(AN_RL_L3,L3_VLAN_CFG_1,MSTP_PTR_GW1E,0,msti);
        } else
            GW_WRF(AN_RL_L3,L3_VLAN_CFG_1,MSTP_PTR_GW1,0,msti);
        
        /* Issue write command */
        GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
              (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) | 
              (vid<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX) | 
              (VLAN_CMD_WRITE<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
        
        /* Wait until idle again */
        VTSS_RC(gw_vlan_table_idle());

#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
        
    return VTSS_OK;
}

static vtss_rc gw_mstp_table_idle(void) 
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        if (vtss_api_state->gw1e) {
            GW_RDF(AN_RL_L3,L3_MSTP_CTRL,MSTP_TABLE_CMD_GW1E,0,&cmd);
        } else
            GW_RDF(AN_RL_L3,L3_MSTP_CTRL,MSTP_TABLE_CMD_GW1,0,&cmd);
        if (cmd==MSTP_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize MSTP table */
static vtss_rc gw_mstp_table_init(void)
{
    VTSS_D(("enter"));
    
    /* Issue clear command */
    if (vtss_api_state->gw1e) {
        GW_WR(AN_RL_L3,L3_MSTP_CTRL,0,
              MSTP_CMD_CLEAR<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1E);
    } else
        GW_WR(AN_RL_L3,L3_MSTP_CTRL,0,
              MSTP_CMD_CLEAR<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1);

    /* Wait until idle again */
    return gw_mstp_table_idle();
}

static vtss_rc gw_mstp_table_write(uint port_on_chip, uint msti, BOOL learn, BOOL forward) 
{
    /* Issue read command */
    if (vtss_api_state->gw1e) {
        GW_WR(AN_RL_L3,L3_MSTP_CTRL,0,
              (msti<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1E) | 
              (MSTP_CMD_READ<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1E));
    } else
        GW_WR(AN_RL_L3,L3_MSTP_CTRL,0,
              (msti<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1) | 
              (MSTP_CMD_READ<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1));
    
    /* Wait until idle again */
    VTSS_RC(gw_mstp_table_idle());

    /* Read and modify learn mask */
    VTSS_RC(gw_wrf(TR(AN_RL_L3,L3_MSTP_CFG_1),port_on_chip,0x1,0,learn ? 1 : 0));
    
    /* Read and modify forward mask */
    VTSS_RC(gw_wrf(TR(AN_RL_L3,L3_MSTP_CFG_2),port_on_chip,0x1,0,forward ? 1 : 0));
    
    /* Issue write command */
    if (vtss_api_state->gw1e) {
        GW_WR(AN_RL_L3,L3_MSTP_CTRL,0,
              (msti<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1E) | 
              (MSTP_CMD_WRITE<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1E));
    } else
        GW_WR(AN_RL_L3,L3_MSTP_CTRL,0,
              (msti<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1) | 
              (MSTP_CMD_WRITE<<O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1));

    /* Wait until idle again */
    return gw_mstp_table_idle();
} 

/* Set MSTP state for port and mstp instance */
vtss_rc vtss_ll_mstp_table_write(vtss_port_no_t port_no, vtss_msti_t msti, vtss_mstp_state_t state)
{
    VTSS_D(("port_no: %d, msti: %d",port_no,msti));
    
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
    
    return gw_mstp_table_write(vtss_api_state->port_map.chip_port[port_no], 
                               msti-VTSS_MSTI_START,
                               state!=VTSS_MSTP_STATE_DISCARDING,
                               state==VTSS_MSTP_STATE_FORWARDING);
}

static vtss_rc gw_mac_table_idle(void) 
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_L2_PS,L2_MAC_CTRL,MAC_TABLE_CMD,0,&cmd);
        if (cmd==MAC_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize MAC address table */
static vtss_rc gw_mac_table_init(void)
{
    uint    i;
    
    VTSS_D(("enter"));

    if (vtss_api_state->gw1e) {
        /* Issue clear command */
        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_CLEAR<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
        
        /* Wait until idle again */
        return gw_mac_table_idle();
    }

    /* Set VID/MACH to zero */
    GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,
          (0<<O_AN_L2_PS_L2_MAC_CFG_0_MACH) |
          (0<<O_AN_L2_PS_L2_MAC_CFG_0_VID));

    /* Set MACL to non-zero value - must be done to make lookup/read work properly */
    GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,0x00000001);

    for (i=0; i<vtss_api_state->mac_addrs; i++) {
        
        /* Set index, then set VALID and other fields to zero */
        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_MIRROR) | 
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_LOCKED) |
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_VALID) |
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_AGE_FLAG) |
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_VLAN_IGNORE) |
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_CPU_COPY) |
              (0<<O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1) |
              ((i%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
              ((i/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
        
        /* Issue write command */
        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_WRITE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);

        /* Wait until idle again */
        VTSS_RC(gw_mac_table_idle());
    }
    return VTSS_OK;
}

/* Do one age scan on current chip */
static vtss_rc gw_mac_table_age(BOOL port_age, vtss_port_no_t port_no, 
                                BOOL vid_age, vtss_vid_t vid)
{
    uint  pgid;
    ulong value;

    VTSS_D(("port_age: %d, port_no: %d, vid_age: %d, vid: %d",port_age,port_no,vid_age,vid));

    pgid = gw_pgid_on_chip(port_no);
    
    /* Set age filter */
    value = ((port_age ? 1 : 0)<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_ENA);
    if (vtss_api_state->gw1e)
        value |= ((pgid<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1E) |
                  ((vid_age ? 1 : 0)<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1E) |
                  (vid<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1E));
    else
        value |= ((pgid<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1) |
                  ((vid_age ? 1 : 0)<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1) |
                  (vid<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1));
    GW_WR(AN_L2_PS,L2_AGEFILTER_CFG,0,value);

    if (vtss_api_state->gw1e)
        GW_WR(AN_L2_PS,L2_AGEMODE_CFG,0,
              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_UNTIL_FOUND_ENA) |
              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_KEEP_AGE_BIT_ENA) |
              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW_ENA) |
              (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_AGED_ENA) |
              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_LOCKED_ENA) |
              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW) |
              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_STATUS));

    /* Issue age command */
    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_AGE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
    
    /* Wait until idle again */
    return gw_mac_table_idle();
}

/* Flush MAC address table */
vtss_rc vtss_ll_mac_table_flush(BOOL port_age, vtss_port_no_t port_no, 
                                BOOL vid_age, vtss_vid_t vid)
{
    VTSS_D(("port_age: %d, port_no: %d, vid_age: %d, vid: %d",port_age,port_no,vid_age,vid));
#if defined(VTSS_CHIPS)
    if (!vtss_api_state->gw1e && port_age) {
        /* Port specific flush must be done the slow way */
        vtss_chip_no_t chip_no,chip_other;
        ulong          cfg0,cfg1,cfg2;
        uint           mac_start,mac_end,i,j,pgid,del_count=0;
        
        /* Determine which chip includes the port */
        chip_no = vtss_api_state->port_map.chip_no[port_no];
        chip_other = (chip_no==VTSS_CHIP_NO_START ? (chip_no+1) : (chip_no-1));
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        pgid = gw_pgid_on_chip(port_no);

        /* Determine number of entries to scan */
        mac_start=vtss_api_state->mac_flush_index_port[port_no];
        mac_end=mac_start+VTSS_OPT_MAC_FLUSH_PORT_MAX;
        if (mac_end>vtss_api_state->mac_addrs)
            mac_end=vtss_api_state->mac_addrs;
        
        for (i=mac_start; i<mac_end; i++) {
            
            /* Setup index and set other fields to zero */
            GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                  ((i%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                  ((i/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
            
            /* Issue read command */
            GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                  MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
            
            /* Read result register CFG_2 */
            GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&cfg2);

            /* Skip if invalid, locked or learned on other ports */
            if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0 ||
                TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,LOCKED)==1 || 
                TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1)!=pgid)
                continue;

            /* Skip if VID specific flush and the VID does not match */
            GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&cfg0);
            if (vid_age!=0 && TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID)!=vid)
                continue;
            
            GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&cfg1);
            
            VTSS_D(("aging entry, vid: 0x%04lx, mac: %04lx%08lx",
                    TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                    TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                    cfg1));
            del_count++;
            /* Unlearn on other chip, then unlearn on current chip */
            for (j=0; j<VTSS_CHIPS; j++) {
                vtss_io_select_chip(&vtss_state->io[j==0 ? chip_other : chip_no]);
                    
                GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                
                /* Issue unlearn command */
                GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                      MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
            }
        }
        VTSS_D(("deleted %d entries",del_count));
        vtss_api_state->mac_flush_index_port[port_no]=(mac_end==vtss_api_state->mac_addrs ? 0 : mac_end);
        return (mac_end==vtss_api_state->mac_addrs ? VTSS_OK : VTSS_INCOMPLETE);
    }
#endif /* VTSS_CHIPS */   
    {
#if defined(VTSS_CHIPS)
        vtss_chip_no_t chip_no;

        for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

            /* Age MAC table twice */
            VTSS_RC(gw_mac_table_age(port_age, port_no, vid_age, vid));
            VTSS_RC(gw_mac_table_age(port_age, port_no, vid_age, vid));
            
#if defined(VTSS_CHIPS)
        }
#endif /* VTSS_CHIPS */
    }
    return VTSS_OK;
}

/* Age MAC address table */
vtss_rc vtss_ll_mac_table_age(BOOL port_age, vtss_port_no_t port_no, 
                              BOOL vid_age, vtss_vid_t vid)
{
#if defined(VTSS_CHIPS)
    vtss_rc        rc;
    uint           age_count=0;

    if (vtss_api_state->gw1e) {
        vtss_chip_no_t chip_no,chip_other;
        vtss_port_no_t glag;
        ulong          agefilter,col,agemode,cfg0,cfg1;
    
        VTSS_D(("port_age: %d, port_no: %d, vid_age: %d, vid: %d",
                port_age, port_no, vid_age, vid));
    
        /* Run through all ports/glags */
        for (glag = VTSS_PORT_NO_START; glag < VTSS_PORT_NO_END; glag++) {
            
            /* If port specific scan, skip other ports */
            if (port_age && glag != port_no)
                continue;
            
            /* Age filter value */
            agefilter = (
                (1<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_ENA) |
                (gw_pgid_on_chip(glag)<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1E) |
                ((vid_age ? 1 : 0)<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1E) |
                (vid<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1E));
            
            if (!vtss_api_state->port_aggr_multi[glag]) {
                ulong row,status;
                
                /* Port is not first port in multi chip aggregation, 
                   age flags on glag chip used */
                chip_no = vtss_api_state->port_map.chip_no[glag];
                chip_other = (chip_no==VTSS_CHIP_NO_START ? (chip_no+1) : (chip_no-1));
                vtss_io_select_chip(&vtss_state->io[chip_no]);
                
                /* Setup age filter */
                GW_WR(AN_L2_PS,L2_AGEFILTER_CFG,0,agefilter);
                
                /* Scan for aged entries */
                for (row = 0; row < (vtss_api_state->mac_addrs/4); ) {
                    /* Scan for next aged entry and read status */
                    GW_WR(AN_L2_PS,L2_AGEMODE_CFG,0,
                          (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_UNTIL_FOUND_ENA) |
                          (0<<O_AN_L2_PS_L2_AGEMODE_CFG_KEEP_AGE_BIT_ENA) |
                          (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW_ENA) |
                          (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_AGED_ENA) |
                          (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_LOCKED_ENA) |
                          (row<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW) |
                          (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_STATUS));
                    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_AGE<<
                          O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                    VTSS_RC(gw_mac_table_idle());
                    GW_RD(AN_L2_PS,L2_AGEMODE_CFG,0,&agemode);
                    
                    /* Exit loop if no more entries to be aged */
                    if ((status = TRF(agemode,AN_L2_PS,L2_AGEMODE_CFG,SCAN_STATUS))==0)
                        break;
                    row = TRF(agemode,AN_L2_PS,L2_AGEMODE_CFG,SCAN_ROW);
                    
                    /* Look at age candidates in each column */
                    for (col = 0; col < 4; col++) {
                        if (!(status & (1<<col)))
                            continue;
                        
                        /* Read entry from current chip */
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                              (col<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                              (row<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&cfg0);
                        GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&cfg1);
                        
                        VTSS_D(("aging entry, vid: 0x%04lx, mac: %04lx%08lx",
                                TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                cfg1));
                        age_count++;
                        
                        /* Unlearn on other chip  */
                        vtss_io_select_chip(&vtss_state->io[chip_other]);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        
                        /* Unlearn on current chip */
                        vtss_io_select_chip(&vtss_state->io[chip_no]);
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                    } /* Column loop */
                } /* Row/age loop */
            } else {
                /* Port is first port in multi chip aggregation, age flags on both chips used */
                ulong          row[VTSS_CHIPS],status[VTSS_CHIPS],ageflag;
                vtss_chip_no_t chip_first,chip_last;
                
                /* Setup age filter for both chips */
                for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
                    vtss_io_select_chip(&vtss_state->io[chip_no]);
                    GW_WR(AN_L2_PS,L2_AGEFILTER_CFG,0,agefilter);
                }            
                
                row[VTSS_CHIP_NO_START]=0;
                row[VTSS_CHIP_NO_START+1]=0;
                while (1) {
                    /* Start age scan on one or both chips and read status */
                    chip_first = (row[VTSS_CHIP_NO_START]>row[VTSS_CHIP_NO_START+1] ? 
                                  (VTSS_CHIP_NO_START+1) : VTSS_CHIP_NO_START);
                    chip_last = (row[VTSS_CHIP_NO_START+1]>row[VTSS_CHIP_NO_START] ? 
                                 VTSS_CHIP_NO_START : (VTSS_CHIP_NO_START+1));
                    for (chip_no=chip_first; chip_no<=chip_last; chip_no++) {
                        vtss_io_select_chip(&vtss_state->io[chip_no]);
                        GW_WR(AN_L2_PS,L2_AGEMODE_CFG,0,
                              (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_UNTIL_FOUND_ENA) |
                              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_KEEP_AGE_BIT_ENA) |
                              (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW_ENA) |
                              (1<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_AGED_ENA) |
                              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_LOCKED_ENA) |
                              (row[chip_no]<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW) |
                              (0<<O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_STATUS));
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_AGE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        GW_RD(AN_L2_PS,L2_AGEMODE_CFG,0,&agemode);
                        if ((status[chip_no] = TRF(agemode,
                                                   AN_L2_PS,L2_AGEMODE_CFG,SCAN_STATUS))==0)
                            row[chip_no] = (vtss_api_state->mac_addrs/4);
                        else
                            row[chip_no] = TRF(agemode,AN_L2_PS,L2_AGEMODE_CFG,SCAN_ROW);
                    } /* Chip loop */
                    
                    /* If both rows are at the end point we are done */
                    if (row[VTSS_CHIP_NO_START] == (vtss_api_state->mac_addrs/4) && 
                        row[VTSS_CHIP_NO_START+1] == (vtss_api_state->mac_addrs/4))
                        break;
                    
                    /* Inspect columns on chip with smallest row */
                    chip_no = (row[VTSS_CHIP_NO_START] <= row[VTSS_CHIP_NO_START+1] ?
                               VTSS_CHIP_NO_START : (VTSS_CHIP_NO_START+1));
                    for (col = 0; col < 4; col++) {
                        if (!(status[chip_no] & (1<<col)))
                            continue;
                        
                        /* Read aged entry */
                        vtss_io_select_chip(&vtss_state->io[chip_no]);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                              (col<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                              (row[chip_no]<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        
                        if (row[VTSS_CHIP_NO_START] == row[VTSS_CHIP_NO_START+1]) {
                            /* If the rows are the same, check age flag in other chip */
                            GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&cfg0);
                            GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&cfg1);
                            vtss_io_select_chip(&vtss_state->io[VTSS_CHIP_NO_START+1]);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                            GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                  MAC_CMD_LOOKUP<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                            VTSS_RC(gw_mac_table_idle());
                            GW_RDF(AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG,0,&ageflag);
                            if (ageflag) {
                                /* Unlearn on both chips */
                                VTSS_D(("aging entry (aggr), vid: 0x%04lx, mac: %04lx%08lx",
                                        TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                        TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                        cfg1));
                                age_count++;
                                GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                      MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                                VTSS_RC(gw_mac_table_idle());
                                vtss_io_select_chip(&vtss_state->io[VTSS_CHIP_NO_START]);
                                GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                      MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                                VTSS_RC(gw_mac_table_idle());
                                continue;
                            } else
                                vtss_io_select_chip(&vtss_state->io[VTSS_CHIP_NO_START]);
                        }
                        /* Clear age flag on chip */
                        GW_WRF(AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG,0,0);
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_WRITE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                    } /* Column loop */
                } /* While loop */
            } /* Port is first port in multi chip aggregation */
        } /* Glag loop */
        
        VTSS_D(("aged %d entries",age_count));
        rc = VTSS_OK;
    } else { 
        /* Not Gatwick-Ie */
        vtss_chip_no_t chip_no, chip_first, chip_last;
        uint           i,j,port_on_chip,pgid_internal;
        ulong          cfg0,cfg1,cfg2,mac_start,mac_end;
        vtss_port_no_t port;
        
        VTSS_D(("port_age: %d, port_no: %d, vid_age: %d, vid: %d",
                port_age, port_no, vid_age, vid));
    
        /* For port specific aging, only operate on the chip the port belongs to */
        if (port_age) {
            chip_first=vtss_api_state->port_map.chip_no[port_no];
            chip_last=chip_first;
            port_on_chip=vtss_api_state->port_map.chip_port[port_no];
        } else {
            chip_first=VTSS_CHIP_NO_START;
            chip_last=chip_first+1;
            port_on_chip=0;
        }
        
        /* For normal age scan, reduce number of entries */
        if (port_age || vid_age) {
            mac_start=0;
            mac_end=vtss_api_state->mac_addrs;
        } else {
            mac_start=vtss_api_state->mac_age_index;
            mac_end=mac_start+VTSS_OPT_MAC_AGE_MAX;
            if (mac_end>vtss_api_state->mac_addrs)
                mac_end=vtss_api_state->mac_addrs;
        }
        
        for (chip_no=chip_first; chip_no<=chip_last; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
            
            pgid_internal=vtss_api_state->iport_setup[
                vtss_api_state->iport_first[chip_no]].chip_port;
        
            for (i=mac_start; i<mac_end; i++) {
                
                /* Setup index and set other fields to zero */
                GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                      ((i%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                      ((i/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
                
                /* Issue read command */
                GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                      MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                
                /* Read result register CFG_2 */
                GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&cfg2);
                
                /* If the entry is invalid, refreshed or locked, aging is not done */
                if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0 ||
                    TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG)==0 ||
                    TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,LOCKED)==1)
                    continue;
                
                /* If it is not port specific scan and the entry is learned on internal port, 
                   aging is not done */
                if (port_age==0 && TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1)==pgid_internal)
                    continue;
                
                /* If it is a port specific scan and the port does not match, 
                   aging is not done */
                if (port_age!=0 && TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1)!=port_on_chip)
                    continue;

                /* If it is a VID specific scan and the VID does not match, aging is not done */
                GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&cfg0);
                if (vid_age!=0 && TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID)!=vid)
                    continue;
                
                GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&cfg1);
                
                VTSS_D(("aging entry, vid: 0x%04lx, mac: %04lx%08lx",
                        TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                        TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                        cfg1));
                age_count++;
                
                /* Unlearn on other chip, then unlearn on current chip */
                for (j=0; j<VTSS_CHIPS; j++) {
                    vtss_io_select_chip(&vtss_state->io[j==0 ? (chip_no==VTSS_CHIP_NO_START ? (chip_no+1) : (chip_no-1)) : chip_no]);
                    
                    GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                    GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                    
                    /* Issue unlearn command */
                    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                          MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                }
            } /* MAC table loop */
            
            /* If more addresses, skip the following scan for setting age flag */
            if (mac_end!=vtss_api_state->mac_addrs)
                continue;
            
            /* Do age scan on specified port or all external ports */
            for (port=VTSS_PORT_NO_START; port<VTSS_PORT_NO_END; port++) {
                if (vtss_api_state->port_map.chip_no[port]==chip_no &&
                    (port_age==0 || port==port_no)) {
                    
                    port_on_chip=vtss_api_state->port_map.chip_port[port];
                    
                    /* Set age filter */
                    GW_WR(AN_L2_PS,L2_AGEFILTER_CFG,0,
                          (1<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_ENA) |
                          (port_on_chip<<O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1) |
                          ((vid_age ? 1 : 0)<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1) |
                          (vid<<O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1));
                    
                    /* Issue age command */
                    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                          MAC_CMD_AGE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                    
                    /* Wait until idle again */
                    VTSS_RC(gw_mac_table_idle());
                }
            } /* Port loop */
        } /* Chip loop */
        VTSS_D(("aged %d entries",age_count));
        
        if (port_age || vid_age) {
            rc = VTSS_OK;
        } else {
            vtss_api_state->mac_age_index=(mac_end==vtss_api_state->mac_addrs ? 0 : mac_end);
            rc = (mac_end==vtss_api_state->mac_addrs ? VTSS_OK : VTSS_INCOMPLETE);
        }
    }
    if (age_count) {
        vtss_api_state->mac_status_appl.aged = 1;
        vtss_api_state->mac_status_next.aged = 1;
        vtss_api_state->mac_status_sync.aged = 1;
    }
    return rc;
#else
    return gw_mac_table_age(port_age, port_no, vid_age, vid);
#endif /* VTSS_CHIPS */
}

/* Learn (VID, MAC) */
vtss_rc vtss_ll_mac_table_learn(const vtss_mac_table_entry_t *entry, vtss_pgid_no_t pgid_no)
{
    uchar          *mac=entry->vid_mac.mac.addr;
    ulong          value;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("vid: %d, mac: %02x-%02x-%02x-%02x-%02x-%02x",
            entry->vid_mac.vid,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]));

#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        /* Set VID/MACH */
        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,
              (((mac[0]<<8) | mac[1])<<O_AN_L2_PS_L2_MAC_CFG_0_MACH) |
              (entry->vid_mac.vid<<O_AN_L2_PS_L2_MAC_CFG_0_VID));

        /* Set MACL */
        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,
              (mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
        
        /* Set PGID, CPU_COPY, LOCK and other fields */
        value = ((0<<O_AN_L2_PS_L2_MAC_CFG_2_MIRROR) | 
                 (entry->locked<<O_AN_L2_PS_L2_MAC_CFG_2_LOCKED) |
                 (1<<O_AN_L2_PS_L2_MAC_CFG_2_VALID) |
                 (0<<O_AN_L2_PS_L2_MAC_CFG_2_AGE_FLAG) |
                 (0<<O_AN_L2_PS_L2_MAC_CFG_2_VLAN_IGNORE) |
                 (entry->copy_to_cpu<<O_AN_L2_PS_L2_MAC_CFG_2_CPU_COPY));
        if (vtss_api_state->gw1e)
            value |= ((gw_pgid_on_chip(pgid_no)<<O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1E) |
                      (0<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                      (0<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
        else
            value |= ((gw_pgid_on_chip(pgid_no)<<O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1) |
                      (0<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                      (0<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,value);
        
        /* Issue learn command */
        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_LEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
        
        /* Wait until idle again */
        VTSS_RC(gw_mac_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Unlearn (VID, MAC) */
vtss_rc vtss_ll_mac_table_unlearn(const vtss_vid_mac_t * vid_mac)
{
    ulong          cfg0,cfg1;
    uchar          *mac=vid_mac->mac.addr;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("vid: %d, mac: %02x-%02x-%02x-%02x-%02x-%02x",
            vid_mac->vid,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]));
        
    cfg0=((((mac[0]<<8) | mac[1])<<O_AN_L2_PS_L2_MAC_CFG_0_MACH) |
          (vid_mac->vid<<O_AN_L2_PS_L2_MAC_CFG_0_VID));
    cfg1=((mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);

#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        /* Set VID/MACH */
        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
        
        /* Set MACL */
        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
        
        /* Issue unlearn command */
        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
        
        /* Wait until idle again */
        VTSS_RC(gw_mac_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    
    return VTSS_OK;
}

/* Lookup (VID, MAC) */
vtss_rc vtss_ll_mac_table_lookup(vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no)
{
    ulong          cfg0,cfg1,cfg2;
    uint           vid=entry->vid_mac.vid;
    uchar          *mac=entry->vid_mac.mac.addr;
    uint           pgid_on_chip;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    BOOL           retry;
#endif /* VTSS_CHIPS */

    VTSS_D(("vid: %d, mac: %02x-%02x-%02x-%02x-%02x-%02x",
            vid,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]));
    
    cfg0=((((mac[0]<<8) | mac[1])<<O_AN_L2_PS_L2_MAC_CFG_0_MACH) |
          (vid<<O_AN_L2_PS_L2_MAC_CFG_0_VID));
    cfg1=((mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
    
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
        
        /* Issue lookup command */
        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_LOOKUP<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
        
        /* Wait until idle again */
        VTSS_RC(gw_mac_table_idle());
        
        GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&cfg2);
        if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0) {
            VTSS_D(("lookup failure"));
            return VTSS_ENTRY_NOT_FOUND;
        }
        
        /* Extract PGID, CPU_COPY and LOCK fields */
        if (vtss_api_state->gw1e)
            pgid_on_chip=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1E);
        else
            pgid_on_chip=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1);
#if defined(VTSS_CHIPS)
        if (vtss_api_state->gw1e) {
            /* For unicast entries, lookup on the second chip is done to get age bit in 
               these cases:
               1. Glag is on second chip
               2. Glag is multi chip aggregation and age flag is set */
            *pgid_no=gw_pgid_on_hl(chip_no, pgid_on_chip);
            retry=(*pgid_no<VTSS_PORT_NO_END && 
                   (vtss_api_state->port_map.chip_no[*pgid_no]!=chip_no || 
                    (vtss_api_state->port_aggr_multi[*pgid_no] && 
                     TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG))));
        } else
            /* If address learned on internal port, 
               lookup on second chip to get pgid and age bit */
            retry=(pgid_on_chip==vtss_api_state->iport_setup[
                   vtss_api_state->iport_first[VTSS_CHIP_NO_START]].chip_port);
        if (retry) {
            if (chip_no!=VTSS_CHIP_NO_START) {
                VTSS_D(("lookup failure"));
                return VTSS_ENTRY_NOT_FOUND;
            }
            continue;
        }
        break;
    }
    *pgid_no=gw_pgid_on_hl(chip_no, pgid_on_chip);
#else
    *pgid_no=gw_pgid_on_hl(pgid_on_chip);
#endif /* VTSS_CHIPS */
    entry->copy_to_cpu=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,CPU_COPY);
    entry->locked=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,LOCKED);
    entry->aged=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG);
    VTSS_D(("lookup success, pgid_on_chip: %d, pgid: %d",pgid_on_chip,*pgid_no));

    return VTSS_OK;
}

/* Direct MAC read */
vtss_rc vtss_ll_mac_table_read(uint index, vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no)
{
    ulong          cfg0,cfg1,cfg2;
    uchar          *mac=entry->vid_mac.mac.addr;
    uint           pgid_on_chip;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    BOOL           retry;

    /* Select first chip */
    chip_no=VTSS_CHIP_NO_START;
    vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

    index-=VTSS_MAC_ADDR_START;

    /* Write column and row */
    if (vtss_api_state->gw1e)
        cfg2 = (((index%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
    else
        cfg2 = (((index%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
    GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,cfg2);
        
    /* Issue read command */
    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
    
    /* Wait until idle again */
    VTSS_RC(gw_mac_table_idle());
    
    /* Get result register */
    GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&cfg2);
    
    /* Check if valid flag set */
    if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0)
        return VTSS_ENTRY_NOT_FOUND;
    
    /* Read CFG_0 and CFG_1 */ 
    GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&cfg0);
    GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&cfg1);

    /* Extract PGID, CPU_COPY and LOCK fields */
    if (vtss_api_state->gw1e)
        pgid_on_chip=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1E);
    else
        pgid_on_chip=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1);
#if defined(VTSS_CHIPS)
    if (vtss_api_state->gw1e) {
        /* For unicast entries, a lookup on the second chip is done to get age flag 
           in these cases:
           1. Glag is on second chip
           2. Glag is multi chip aggregation and age flag is set */
        *pgid_no=gw_pgid_on_hl(chip_no, pgid_on_chip);
        retry=(*pgid_no<VTSS_PORT_NO_END && 
               (vtss_api_state->port_map.chip_no[*pgid_no]!=chip_no || 
                (vtss_api_state->port_aggr_multi[*pgid_no] && 
                 TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG))));
    } else
        /* If address learned on internal port, 
           do lookup on second chip to get pgid and age flag */
        retry=(pgid_on_chip==vtss_api_state->iport_setup[
                   vtss_api_state->iport_first[chip_no]].chip_port);
    if (retry) {
        chip_no++;
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        
        /* Setup (VID, MAC) */
        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
        
        /* Issue lookup command */
        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,MAC_CMD_LOOKUP<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
        
        /* Wait until idle again */
        VTSS_RC(gw_mac_table_idle());
        
        GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&cfg2);

        /* Check if valid flag set */
        if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0)
            return VTSS_ENTRY_NOT_FOUND;

        /* Check if learned on internal port on both chips */
        if (vtss_api_state->gw1e)
            pgid_on_chip=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1E);
        else
            pgid_on_chip=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1);
        if (pgid_on_chip==vtss_api_state->iport_setup[
                vtss_api_state->iport_first[chip_no]].chip_port)
            return VTSS_ENTRY_NOT_FOUND;
    }
    *pgid_no=gw_pgid_on_hl(chip_no, pgid_on_chip);
#else
    *pgid_no=gw_pgid_on_hl(pgid_on_chip);
#endif /* VTSS_CHIPS */
    entry->copy_to_cpu=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,CPU_COPY);
    entry->locked=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,LOCKED);
    entry->aged=TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG);
            
    /* Extract VID, and MACL fields */
    entry->vid_mac.vid=TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID);  
    cfg0=TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH);
    mac[0]=((cfg0>>8) & 0xff);
    mac[1]=(cfg0 & 0xff);
    
    /* Extract MACL field */
    mac[2]=((cfg1>>24) & 0xff);
    mac[3]=((cfg1>>16) & 0xff);
    mac[4]=((cfg1>>8) & 0xff);  
    mac[5]=(cfg1 & 0xff);  

    return VTSS_OK;
}

/* Get MAC table status */
vtss_rc vtss_ll_mac_table_status_get(vtss_mac_table_status_t *status) 
{
    ulong          value,mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    status->learned = 0;
    status->replaced = 0;
    status->moved = 0;
    status->aged = 0;

#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        if (!vtss_api_state->gw1e) {
            /* Detect port move events */
            GW_RD(AN_L2_PS,L2_MOVELOG_STICKY,0,&value);
            GW_WR(AN_L2_PS,L2_MOVELOG_STICKY,0,value);
            if (value)
                status->moved = 1;
        }
        
        GW_RD(AN_L2_PS,L2_EVENTS_STICKY,0,&value);

        /* Detect learn events */
        if (TRF(value,AN_L2_PS,L2_EVENTS_STICKY,LEARN_INSERT))
            status->learned = 1;

        /* Detect replace events */
        if (TRF(value,AN_L2_PS,L2_EVENTS_STICKY,LEARN_REPLACE))
            status->replaced = 1;

        /* Detect age events */
        if (TRF(value,AN_L2_PS,L2_EVENTS_STICKY,AGED_ENTRY_REMOVED))
            status->aged = 1;
        
        mask = ((1<<O_AN_L2_PS_L2_EVENTS_STICKY_LEARN_INSERT) |
                (1<<O_AN_L2_PS_L2_EVENTS_STICKY_LEARN_REPLACE) |
                (1<<O_AN_L2_PS_L2_EVENTS_STICKY_AGED_ENTRY_REMOVED));

        if (vtss_api_state->gw1e) {
#if defined(VTSS_CHIPS)
            if (TRF(value,AN_L2_PS,L2_EVENTS_STICKY,GLOBAL_TO_GLOBAL_PORT_MOVE))
                status->moved = 1; 
            mask |= (1<<O_AN_L2_PS_L2_EVENTS_STICKY_GLOBAL_TO_GLOBAL_PORT_MOVE);
#else
            if (TRF(value,AN_L2_PS,L2_EVENTS_STICKY,LOCAL_TO_LOCAL_PORT_MOVE))
                status->moved = 1;
            mask |= (1<<O_AN_L2_PS_L2_EVENTS_STICKY_LOCAL_TO_LOCAL_PORT_MOVE);
#endif /* VTSS_CHIPS */        
        }
        
        GW_WR(AN_L2_PS,L2_EVENTS_STICKY,0,value & mask)

#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

static vtss_rc gw_cpid_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_L2_PS,PS_CPID_CTRL,CPID_TABLE_CMD,0,&cmd);
        if (cmd==CPID_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize CPID table */
static vtss_rc gw_cpid_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    GW_WR(AN_L2_PS,PS_CPID_CTRL,0,
          CPID_CMD_CLEAR<<O_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_CMD);

    /* Wait until idle again */
    return gw_cpid_table_idle();
}

#ifdef VTSS_CHIPS
static vtss_rc gw_cpid_table_write(uint cpid_on_chip, ulong mask)
{
    VTSS_D(("cpid_on_chip: %d, mask: 0x%08lx",cpid_on_chip,mask));

    /* Set port mask */
    GW_WR(AN_L2_PS,PS_CPID_CFG,0,mask);
    
    /* Issue write command */
    GW_WR(AN_L2_PS,PS_CPID_CTRL,0,
          (cpid_on_chip<<O_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_INDEX) |
          (CPID_CMD_WRITE<<O_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_CMD));
    
    /* Wait until idle again */
    return gw_cpid_table_idle();
}
#endif /* VTSS_CHIPS */

#if defined(VTSS_CHIPS)
static vtss_rc gw_glag_table_idle(void)
{
    ulong cmd;
    
    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_L2_PS,PS_GLAG_CTRL,GLAG_TABLE_CMD,0,&cmd);
        if (cmd==GLAG_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

static vtss_rc gw_glag_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    GW_WR(AN_L2_PS,PS_GLAG_CTRL,0,
          GLAG_CMD_CLEAR<<O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_CMD);
    
    /* Wait until idle again */
    return gw_glag_table_idle();
}

static vtss_rc gw_glag_table_write(uint glag, ulong mask)
{
    VTSS_D(("glag: %d, mask: 0x%08lx",glag,mask));

    /* Set port mask */
    GW_WR(AN_L2_PS,PS_GLAG_CFG,0,mask);
    
    /* Issue write command */
    GW_WR(AN_L2_PS,PS_GLAG_CTRL,0,
          (GLAG_CMD_WRITE<<O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_CMD) |
          (0<<O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_MIRROR) |
          (glag<<O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_INDEX));
    
    /* Wait until idle again */
    return gw_glag_table_idle();
}
#endif /* VTSS_CHIPS */

static vtss_rc gw_src_table_idle(void)
{
    ulong cmd;
    
    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_L2_PS,PS_SRC_CTRL,SRC_TABLE_CMD,0,&cmd);
        if (cmd==SRC_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize source table */
static int gw_src_table_init(void)
{
    ulong value;

    VTSS_D(("enter"));

    /* Enable PGID, AGGR and SRC tables */
    value = (
        (1<<O_AN_L2_PS_PS_CFG_PGID_ENA) |
        (1<<O_AN_L2_PS_PS_CFG_AGGR_ENA) |
        (1<<O_AN_L2_PS_PS_CFG_SRC_MASK_ENA) |
        (1<<O_AN_L2_PS_PS_CFG_CPID_MASK_ENA));
#if defined(VTSS_CHIPS)
    if (vtss_api_state->gw1e)
        value |= ((1<<O_AN_L2_PS_PS_CFG_GLAG_MASK_ENA) |
                  (1<<O_AN_L2_PS_PS_CFG_L3_STACKING_SRC_AGGR_MODE_ENA));
#endif /* VTSS_CHIPS */
    GW_WR(AN_L2_PS,PS_CFG,0,value);

    /* Issue clear command */
    GW_WR(AN_L2_PS,PS_SRC_CTRL,0,
          SRC_CMD_CLEAR<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_CMD);
    
    /* Wait until idle again */
    return gw_src_table_idle();
}

static vtss_rc gw_src_table_write(uint port_on_chip, ulong mask)
{
    VTSS_D(("port_on_chip: %d, mask: 0x%08lx",port_on_chip,mask));

    /* Issue read command to get the mirror flag */
    GW_WR(AN_L2_PS,PS_SRC_CTRL,0,
          (port_on_chip<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_INDEX) |
          (SRC_CMD_READ<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_CMD));

    /* Wait until idle again */
    VTSS_RC(gw_src_table_idle());
    
    /* Set port mask */
    GW_WR(AN_L2_PS,PS_SRC_CFG,0,mask);
    
    /* Issue write command */
    GW_WRF(AN_L2_PS,PS_SRC_CTRL,SRC_TABLE_CMD,0,SRC_CMD_WRITE);
    
    /* Wait until idle again */
    return gw_src_table_idle();
}

/* Add source port entry */
vtss_rc vtss_ll_src_table_write(vtss_port_no_t port_no, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    uint           port_on_chip;
    ulong          mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    ulong          mask1;
#endif /* VTSS_CHIPS */

    port_on_chip=vtss_api_state->port_map.chip_port[port_no];

#if defined(VTSS_CHIPS)
    chip_no = vtss_api_state->port_map.chip_no[port_no];
    vtss_io_select_chip(&vtss_state->io[chip_no]);
    mask = gw_list2mask(chip_no,member);
    if (vtss_api_state->pvlan_isolate) {
        /* No PVLAN includes ports on both chips => exclude internal ports */
        mask1 = 0;
    } else if (port_on_chip<20) {
        /* Port 8-19 send to the first internal port */
        mask |= (1<<vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port);
        mask1 = (1<<vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port);
    } else {
        /* Port 20-31 send to the last internal port */
        mask |= (1<<vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port);
        mask1 = (1<<vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port);
    }
    /* If port is aggregated, allow sending to both internal ports */
    if (vtss_api_state->port_poag_no[port_no] != port_no)
        mask |= mask1;
#else
    mask = gw_list2mask(member);
#endif /* VTSS_CHIPS */
    VTSS_D(("port_no: %d, mask: 0x%08lx",port_no,mask));
    
    /* Update analyzer source mask entry */
    VTSS_RC(gw_src_table_write(port_on_chip,mask));

    /* Update source mask in Tx path */
#if defined(VTSS_CHIPS)
    /* In the Tx path mask, allow packets from both internal ports */
    mask |= mask1;
#endif /* VTSS_CHIPS */
    GW_WR(TXP,QS_LINKAGGR_CFG,port_on_chip,mask | (1<<PORT_ON_CHIP_RESV));

#if defined(VTSS_CHIPS)
    /* Setup GLAG masks */
    if (vtss_api_state->gw1e) {
        for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
            mask = gw_list2mask(chip_no,member);
            mask |= (1<<vtss_api_state->iport_setup[
                         vtss_api_state->iport_first[chip_no]].chip_port);
            mask |= (1<<vtss_api_state->iport_setup[
                         vtss_api_state->iport_last[chip_no]].chip_port);
            VTSS_RC(gw_glag_table_write(port_no, mask));
        }
    }
#endif /* VTSS_CHIPS */
    
    return VTSS_OK;
}

/* Enable/disable ingress mirroring of port */
vtss_rc vtss_ll_src_mirror_set(vtss_port_no_t port_no, BOOL enable)
{
    uint    port_on_chip;
    ulong   mask;
    
    VTSS_D(("port_no: %d",port_no));
    
    port_on_chip=vtss_api_state->port_map.chip_port[port_no];
    
#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

    /* Issue read command to get the port mask */
    GW_WR(AN_L2_PS,PS_SRC_CTRL,0,
          (port_on_chip<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_INDEX) |
          (SRC_CMD_READ<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_CMD));
    
    /* Wait until idle again */
    VTSS_RC(gw_src_table_idle());

    /* To fully update the mask in the chip, it must be written again */
    GW_RD(AN_L2_PS,PS_SRC_CFG,0,&mask);
    GW_WR(AN_L2_PS,PS_SRC_CFG,0,mask);

    /* Issue write command updating the mirror flag */
    GW_WR(AN_L2_PS,PS_SRC_CTRL,0,
          (port_on_chip<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_INDEX) |
          (SRC_CMD_WRITE<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_CMD) |
          ((enable ? 1 : 0)<<O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_MIRROR));

    /* Wait until idle again */
    return gw_src_table_idle();
}

/* Enable/disable egress mirroring of port */
vtss_rc vtss_ll_dst_mirror_set(vtss_port_no_t port_no, BOOL enable)
{
    uint  port_on_chip;
    
    VTSS_D(("port_no: %d",port_no));
    
    port_on_chip=vtss_api_state->port_map.chip_port[port_no];

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
 
    return gw_wrf(TR(AN_L2_PS,PS_EGRESS_MIRROR_MASK_CFG),port_on_chip,0x1,0,enable ? 1 : 0);
}

/* Enable/disable mirroring */
vtss_rc vtss_ll_mirror_port_set(vtss_port_no_t port_no)
{
    uint           port_on_chip;
    ulong          value;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
    BOOL           local;
#endif /* VTSS_CHIPS */

    port_on_chip=vtss_api_state->port_map.chip_port[port_no];
    
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        
        /* Allow setting up one mirror port on each chip */
        local = (vtss_api_state->port_map.chip_no[port_no] == chip_no);
#if VTSS_OPT_DUAL_MIRROR_PORTS
        /* Only change mirror setup for chip with mirror port */
        if (!local)
            continue;
#endif /* VTSS_OPT_DUAL_MIRROR_PORTS */

        value = (0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_MIRROR_ENA);
        if (vtss_api_state->gw1e)
            value |= 
                (((local ? 1 : 0)<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_LOCAL_PORT_MIRROR_ENA) |
                 ((local ? 0 : 1)<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_0_MIRROR_ENA) |
                 ((local ? 0 : 1)<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_1_MIRROR_ENA) |
                 (0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1E) |
                 ((local ? port_on_chip : 0)<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1E));
        else
            value |= 
                ((0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1) |
                 ((local ? port_on_chip : 0)<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1));
        GW_WR(AN_L2_PS,PS_CPU_MIRROR_CFG,0,value);
    }
#else
    value = (0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_MIRROR_ENA);
    if (vtss_api_state->gw1e)
        value |= 
            ((1<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_LOCAL_PORT_MIRROR_ENA) |
             (0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_0_MIRROR_ENA) |
             (0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_1_MIRROR_ENA) |
             (0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1E) |
             (port_on_chip<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1E));
    else
        value |= 
            ((0<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1) |
             (port_on_chip<<O_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1));
    GW_WR(AN_L2_PS,PS_CPU_MIRROR_CFG,0,value);
#endif /* VTSS_CHIPS */
    return VTSS_OK;    
}

static vtss_rc gw_pgid_table_idle(void) 
{
    ulong cmd;
    
    /* Wait until idle again */
    while (1) {
        if (vtss_api_state->gw1e) {
            GW_RDF(AN_L2_PS,PS_PGID_CTRL,PGID_TABLE_CMD_GW1E,0,&cmd);
        } else
            GW_RDF(AN_L2_PS,PS_PGID_CTRL,PGID_TABLE_CMD_GW1,0,&cmd);
        if (cmd==PGID_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize PGID table */
static vtss_rc gw_pgid_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    if (vtss_api_state->gw1e) {
        GW_WR(AN_L2_PS,PS_PGID_CTRL,0,
              PGID_CMD_CLEAR<<O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1E);
    } else
        GW_WR(AN_L2_PS,PS_PGID_CTRL,0,
              PGID_CMD_CLEAR<<O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1);
    
    return gw_pgid_table_idle();
}

static vtss_rc gw_pgid_table_write(uint pgid_on_chip, ulong mask, BOOL cpu_fwd)
{
    VTSS_D(("pgid_on_chip: %d, mask: 0x%08lx",pgid_on_chip,mask));

    /* Set port mask */
    GW_WR(AN_L2_PS,PS_PGID_CFG,0,mask);
    
    /* Set PGID and CPU fwd flag and issue write command */
    if (vtss_api_state->gw1e) {
        GW_WR(AN_L2_PS,PS_PGID_CTRL,0,
              (pgid_on_chip<<O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_INDEX_GW1E) |
              (PGID_CMD_WRITE<<O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1E) |
              ((cpu_fwd ? 1 : 0)<<O_AN_L2_PS_PS_PGID_CTRL_PGID_CPU_MASK_GW1E) |
              (0<<O_AN_L2_PS_PS_PGID_CTRL_CPU_QUEUE_PGID_FWD_GW1E));
    } else
        GW_WR(AN_L2_PS,PS_PGID_CTRL,0,
              (pgid_on_chip<<O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_INDEX_GW1) |
              (PGID_CMD_WRITE<<O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1) |
              ((cpu_fwd ? 1 : 0)<<O_AN_L2_PS_PS_PGID_CTRL_PGID_CPU_MASK_GW1) |
              (0<<O_AN_L2_PS_PS_PGID_CTRL_CPU_QUEUE_PGID_FWD_GW1));
    
    /* Wait until idle again */
    return gw_pgid_table_idle();
}

/* PGID table write */
vtss_rc vtss_ll_pgid_table_write(vtss_pgid_no_t pgid_no, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    ulong          mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no, chip_first, chip_last;
    ulong          masks[VTSS_CHIP_NO_END];
    
    /* By default, setup both chips */
    chip_first=VTSS_CHIP_NO_START;
    chip_last=(chip_first+1);
    if (!vtss_api_state->gw1e && pgid_no<VTSS_PGID_UNICAST_END) {
        /* Unicast entry, just setup one chip */
        chip_first=vtss_api_state->port_map.chip_no[pgid_no];
        chip_last=chip_first;
    }
    
    /* Get membership mask(s) */
    for (chip_no=chip_first; chip_no<=chip_last; chip_no++) {
        masks[chip_no] = gw_list2mask(chip_no,member);
    }
    for (chip_no=chip_first; chip_no<=chip_last; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        
        /* The internal ports are included if any port on the other chip is included */
        mask=masks[chip_no];
        if (chip_first!=chip_last &&
            ((chip_no==chip_first && masks[chip_last]!=0) ||
             (chip_no==chip_last && masks[chip_first]!=0))) {
            mask|=(1<<vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port);
            mask|=(1<<vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port);
        }
#else
        mask = gw_list2mask(member);
#endif /* VTSS_CHIPS */
    
        VTSS_D(("pgid_no: %d, mask: 0x%08lx",pgid_no,mask));
        
        VTSS_RC(gw_pgid_table_write(gw_pgid_on_chip(pgid_no),mask,0));
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

static vtss_rc gw_aggr_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        if (vtss_api_state->gw1e) {
            GW_RDF(AN_L2_PS,PS_AGGR_CTRL_GW1E,AGGR_TABLE_CMD,0,&cmd);
        } else
            GW_RDF(AN_L2_PS,PS_AGGR_CTRL_GW1,AGGR_TABLE_CMD,0,&cmd);
        if (cmd==AGGR_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize aggregation table */
static vtss_rc gw_aggr_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    if (vtss_api_state->gw1e) {
        GW_WR(AN_L2_PS,PS_AGGR_CTRL_GW1E,0,
              AGGR_CMD_CLEAR<<O_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_CMD);
    } else
        GW_WR(AN_L2_PS,PS_AGGR_CTRL_GW1,0,
              AGGR_CMD_CLEAR<<O_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_CMD);

    /* Wait until idle again */
    return gw_aggr_table_idle();
}

/* Write aggregation entry */
vtss_rc vtss_ll_aggr_table_write(vtss_ac_no_t ac, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    ulong          mask;
    BOOL           debug;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
    debug = (ac==VTSS_AC_START || ac==VTSS_ACS);
    ac-=VTSS_AC_START;
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        /* Include internal ports */
        mask = (gw_list2mask(chip_no,member) |
                (1<<vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port) |
                (1<<vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port));
        if (debug) {
            VTSS_D(("chip_no: %d, ac: %d, mask: 0x%08lx",chip_no,ac,mask));
        } else {
            VTSS_N(("chip_no: %d, ac: %d, mask: 0x%08lx",chip_no,ac,mask));
        }
#else
        mask = gw_list2mask(member);
        if (debug) {
            VTSS_D(("ac: %d, mask: 0x%08lx",ac,mask));
        } else {
            VTSS_N(("ac: %d, mask: 0x%08lx",ac,mask));
        }
#endif /* VTSS_CHIPS */
        
        /* Set port mask and issue write command */
        if (vtss_api_state->gw1e) {
            GW_WR(AN_L2_PS,PS_AGGR_CFG_0,0,mask);
            GW_WR(AN_L2_PS,PS_AGGR_CTRL_GW1E,0,
                  (ac<<O_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_INDEX) |
                  (AGGR_CMD_WRITE<<O_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_CMD));
        } else
        {
            GW_WR(AN_L2_PS,PS_AGGR_CFG_GW1,0,mask);
            GW_WR(AN_L2_PS,PS_AGGR_CTRL_GW1,0,
                  (ac<<O_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_INDEX) |
                  (AGGR_CMD_WRITE<<O_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_CMD));
        }
        /* Wait until idle again */
        VTSS_RC(gw_aggr_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

vtss_rc vtss_ll_ipmc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    ulong          mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;

    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
        /* Include first and last internal ports */
        mask = (gw_list2mask(chip_no,member) |
                vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port |
                vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port);
        VTSS_D(("chip_no: %d, mask: 0x%08lx",chip_no,mask));
#else
        mask = gw_list2mask(member);
        VTSS_D(("mask: 0x%08lx",mask));
#endif /* VTSS_CHIPS */
    
        GW_WR(AN_L2_PS,PS_L3_MC_FLOOD_MASK_CFG,0,mask);
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/***************************************************************************
 *** Layer 3 ***************************************************************
 ***************************************************************************/

static vtss_rc gw_irlid_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,RL_CTRL,RL_CMD,0,&cmd);
        if (cmd==RL_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize IRLID table */
static vtss_rc gw_irlid_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    gw_wr(TR(AN_RL_L3,RL_CTRL),0,
          RL_CMD_CLEAR<<O_AN_RL_L3_RL_CTRL_RL_CMD);
    
    /* Wait until idle again */
    return gw_irlid_table_idle();
}

#if defined(VTSS_FEATURE_LAYER3)
/* Write IRLID entry */
static vtss_rc gw1e_irlid_table_write(vtss_rlid_t rlid, const vtss_mac_t *mac, 
                                      vtss_vrid_t vrid0, vtss_vrid_t vrid1, BOOL mc_ena)
{
    const uchar *dmac;

    VTSS_D(("rlid: %d",rlid));
    dmac = mac->addr;
    rlid -= VTSS_RLID_START;

    /* Setup CFG_1 */
    GW_WR(AN_RL_L3,RL_CFG_1,0,
          (mc_ena<<O_AN_RL_L3_RL_CFG_1_L3MC_ENA_GW1E) |
          ((vrid0 || vrid1 ? 1 : 0)<<O_AN_RL_L3_RL_CFG_1_VRRP_ENA) |
          (vrid0<<O_AN_RL_L3_RL_CFG_1_VRID0) |
          (vrid1<<O_AN_RL_L3_RL_CFG_1_VRID1));
    
    /* Setup CFG_2 */
    GW_WR(AN_RL_L3,RL_CFG_2,0,(dmac[2]<<24) | (dmac[3]<<16) | (dmac[4]<<8) | dmac[5]);
    
    /* Setup CFG_3 */
    GW_WR(AN_RL_L3,RL_CFG_3,0,(dmac[0]<<8) | dmac[1]);
    
    /* Issue write command */
    GW_WR(AN_RL_L3,RL_CTRL,0,
          (rlid<<O_AN_RL_L3_RL_CTRL_RL_INDEX_GW1E) |
          (RL_CMD_WRITE<<O_AN_RL_L3_RL_CTRL_RL_CMD));
    
    /* Wait until idle again */
    return gw_irlid_table_idle();
}

/* Write RLID for VLAN, zero means disabled */
static vtss_rc gw_vlan_table_rlid_set(vtss_rlid_t rlid, vtss_vid_t vid)
{
    ulong          value,mask;
    
    VTSS_D(("rlid: %d, vid: %d",rlid,vid));

    /* Issue read command */
    GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
          (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) | 
          (vid<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX) | 
          (VLAN_CMD_READ<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
    
    /* Wait until idle again */
    VTSS_RC(gw_vlan_table_idle());
    
    value = (((rlid ? 1 : 0)<<O_AN_RL_L3_L3_VLAN_CFG_1_RL_ENA) |
             ((rlid ? (rlid-VTSS_RLID_START) : 0)<<O_AN_RL_L3_L3_VLAN_CFG_1_RLID));
    mask = ((M_AN_RL_L3_L3_VLAN_CFG_1_RL_ENA<<O_AN_RL_L3_L3_VLAN_CFG_1_RL_ENA) |
            (M_AN_RL_L3_L3_VLAN_CFG_1_RLID<<O_AN_RL_L3_L3_VLAN_CFG_1_RLID));
    /* Set RLID index */
    GW_WR_MASKED(AN_RL_L3,L3_VLAN_CFG_1,0,value,mask);
        
    /* Issue write command */
    GW_WR(AN_RL_L3,L3_VLAN_CTRL,0,
          (1<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA) | 
          (vid<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX) | 
          (VLAN_CMD_WRITE<<O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD));
    
    /* Wait until idle again */
    return gw_vlan_table_idle();
}

/* Write IRLID entry */
static vtss_rc gw1_irlid_table_write(uint port_on_chip, vtss_prlid_t prlid, vtss_rlid_t rlid,
                                     const vtss_vid_mac_t *vid_mac, BOOL mc_ena)
{
    const uchar *mac;
    
    VTSS_D(("port_on_chip: %d, prlid: %d, rlid: %d",port_on_chip,prlid,rlid));

    mac=vid_mac->mac.addr;
    prlid-=VTSS_PRLID_START;
    rlid-=VTSS_RLID_START;

    /* Set VALID, VID, IRLID and MC_ENA fields */
    GW_WR(AN_RL_L3,RL_CFG_1,0,
          (1<<O_AN_RL_L3_RL_CFG_1_RL_VALID) | 
          (vid_mac->vid<<O_AN_RL_L3_RL_CFG_1_VID) |
          (rlid<<O_AN_RL_L3_RL_CFG_1_IRLID) |
          ((mc_ena ? 1 : 0)<<O_AN_RL_L3_RL_CFG_1_L3MC_ENA_GW1));
    
    /* Set MACL */
    GW_WR(AN_RL_L3,RL_CFG_2,0,(mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
    
    /* Set MACH */
    GW_WR(AN_RL_L3,RL_CFG_3,0,(mac[0]<<8) | mac[1]);
    
    /* Issue write command */
    GW_WR(AN_RL_L3,RL_CTRL,0,
          (((port_on_chip<<2) | prlid)<<O_AN_RL_L3_RL_CTRL_RL_INDEX_GW1) |
          (RL_CMD_WRITE<<O_AN_RL_L3_RL_CTRL_RL_CMD));

    /* Wait until idle again */
    return gw_irlid_table_idle();
}

/* Delete IRLID entry */
static vtss_rc gw1_irlid_table_del(uint port_on_chip, vtss_prlid_t prlid)
{
    VTSS_D(("port_on_chip: %d, prlid: %d",port_on_chip,prlid));
    
    prlid-=VTSS_PRLID_START;

    /* Clear valid field */
    GW_WR(AN_RL_L3,RL_CFG_1,0,0<<O_AN_RL_L3_RL_CFG_1_RL_VALID);

    /* Issue write command */
    GW_WR(AN_RL_L3,RL_CTRL,0,
          (((port_on_chip<<2) | prlid)<<O_AN_RL_L3_RL_CTRL_RL_INDEX_GW1) |
          (RL_CMD_WRITE<<O_AN_RL_L3_RL_CTRL_RL_CMD));
    
    /* Wait until idle again */
    return gw_irlid_table_idle();
}

static vtss_rc gw_erlid_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_ERLID_CTRL,ERLID_TABLE_CMD,0,&cmd);
        if (cmd==ERLID_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize ERLID table */
static vtss_rc gw_erlid_table_init(void)
{
    VTSS_D(("enter"));
    
    /* Issue clear command */
    gw_wr(TR(AN_RL_L3,L3_ERLID_CTRL),0,
          ERLID_CMD_CLEAR<<O_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_CMD);
    
    /* Wait until idle again */
    return gw_erlid_table_idle();
}

/* Write ERLID entry */
static int gw_erlid_table_write(vtss_rlid_t erlid, vtss_vid_t vid)
{
    VTSS_D(("erlid: %d, vid: %d",erlid,vid));

    erlid-=VTSS_RLID_START;

    /* Set VID */
    GW_WR(AN_RL_L3,L3_ERLID_CFG,0,vid);
    
    /* Issue write command */
    GW_WR(AN_RL_L3,L3_ERLID_CTRL,0,
          (erlid<<O_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_INDEX) |
          (ERLID_CMD_WRITE<<O_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_CMD));
    
    /* Wait until idle again */
    return gw_erlid_table_idle();
}

/* Write port router leg in Tx path */
static vtss_rc gw_prlid_table_write(uint port_on_chip, vtss_prlid_t prlid, 
                                    const vtss_vid_mac_t *vid_mac, uchar ttl) 
{
    const uchar *mac;
    
    VTSS_D(("port_on_chip: %d, prlid: %d",port_on_chip,prlid));

    mac=vid_mac->mac.addr;
    prlid-=VTSS_PRLID_START;

    /* Set MACL */
    GW_WR(TXP,REWR_L3_SMAC_LO_0+prlid*2,port_on_chip,
          (mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
    
    /* Set VID/MACH */
    GW_WR(TXP,REWR_L3_SMAC_HI_0+prlid*2,port_on_chip,
          (((mac[0]<<8) | mac[1])<<O_TXP_REWR_L3_SMAC_HI_0_SMAC_HI_0) |
          (vid_mac->vid<<O_TXP_REWR_L3_SMAC_HI_0_VID_0));

    /* Set TTL */
    GW_WR_MASKED(TXP,REWR_L3_TTL,port_on_chip,ttl<<(prlid*8),
                 M_TXP_REWR_L3_TTL_TTL_0 << (prlid*8));
    
    return VTSS_OK;
}

/* Write ERLGID in Tx path */
static vtss_rc gw_erlgid_table_write(uint port_on_chip, vtss_erlgid_t erlgid, uchar emask)
{
    ulong value,mask;
    
    VTSS_D(("port_on_chip: %d, erlgid: %d, emask: 0x%02x",port_on_chip,erlgid,emask));

    /* Set PRLID L2 and L3 fields */
    value=((((emask & 1) ? 1 : 0)<<O_TXP_QS_PRLID_0_PRLID0_L2) | 
           ((emask>>1)<<O_TXP_QS_PRLID_0_PRLID0_L3));
    mask=(M_TXP_QS_PRLID_0_PRLID0_L2<<O_TXP_QS_PRLID_0_PRLID0_L2) |
         (M_TXP_QS_PRLID_0_PRLID0_L3<<O_TXP_QS_PRLID_0_PRLID0_L3);

    GW_WR_MASKED(TXP,QS_PRLID_0+erlgid/4,port_on_chip,
                 value<<((erlgid%4)*8),mask<<((erlgid%4)*8));

    return VTSS_OK;
}

/* Set ICMP redirect */
static vtss_rc gw_icmp_set(vtss_rlid_t rlid, BOOL enable)
{
    VTSS_D(("rlid: %d, enable: %d",rlid,enable));

    /* Set ICMP redirect */
    return gw_wrf(TR(AN_RL_L3,L3_ICMP_CTRL),rlid-VTSS_RLID_START,0x01,0,enable ? 1 : 0);
}

static vtss_rc gw_uc_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_CAM_CTRL,CAM_CMD,0,&cmd);
        if (cmd==CAM_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize unicast forwarding table */
static vtss_rc gw_uc_table_init(void)
{
    VTSS_D(("enter"));
    
    /* Issue clear command */
    GW_WR(AN_RL_L3,L3_CAM_CTRL,0,CAM_CMD_CLEAR<<O_AN_RL_L3_L3_CAM_CTRL_CAM_CMD);

    /* Enable L3 */
    GW_WR(AN_RL_L3,L3_COMMON_CFG,0,1<<O_AN_RL_L3_L3_COMMON_CFG_L3_ENA);

    /* Wait until idle again */
    return gw_uc_table_idle();
}

/* Write unicast forwarding entry */
static vtss_rc gw_uc_table_write(vtss_ucid_t ucid, vtss_ip_t net, uint plen, uint slen, 
                                 vtss_arpid_t arpid, BOOL valid)
{
    VTSS_D(("ucid: %d, net/mask: 0x%08lx/%d, arpid: %d",ucid,net,plen,arpid));

    ucid-=VTSS_UCID_START;
    arpid-=VTSS_ARPID_START;

    /* Set valid, prefix length, subnet length and base pointer fields */
    GW_WR(AN_RL_L3,L3_CAM_CFG_1,0,
          ((valid ? 1 : 0)<<O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_VALID) |
          (plen<<O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_PREFIX_LEN) |
          (slen<<O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_SUB_LEN) |
          (arpid<<O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_BASE_PTR));

    if (valid) {
        /* Set DIP field */
        GW_WR(AN_RL_L3,L3_CAM_CFG_2,0,net);
    }
    
    /* Issue write command */
    GW_WR(AN_RL_L3,L3_CAM_CTRL,0,
          (ucid<<O_AN_RL_L3_L3_CAM_CTRL_CAM_INDEX) |
          (CAM_CMD_WRITE<<O_AN_RL_L3_L3_CAM_CTRL_CAM_CMD));
    
    /* Wait until idle again */
    return gw_uc_table_idle();
}

static vtss_rc gw_arp_table_idle(void)
{
    ulong cmd;

    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_IP_CTRL,IP_TABLE_CMD,0,&cmd);
        if (cmd==IP_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize ARP/MC table */
static vtss_rc gw_arp_table_init(void)
{
    VTSS_D(("enter"));
    
    /* Issue clear command */
    GW_WR(AN_RL_L3,L3_IP_CTRL,0,
          (IP_CMD_CLEAR<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
          (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));

    return gw_arp_table_idle();
}

/* Write ARP entry */
static vtss_rc gw_arp_table_write(vtss_arpid_t arpid, const vtss_mac_t *dmac, vtss_rlid_t erlid,
                                  vtss_erlgid_t erlgid, BOOL valid)
{
    ulong value;
    
    VTSS_D(("arpid: %d, valid: %d",arpid,valid ? 1 : 0));

    arpid-=VTSS_ARPID_START;
    erlid-=VTSS_RLID_START;

    /* Set valid, erlid and erlgid fields */
    value = ((valid ? 1 : 0)<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_VALID);
    if (vtss_api_state->gw1e)
        value |= (erlid<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1E);
    else
        value |= ((erlgid<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLGID_GW1) |
                  (erlid<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1));
    GW_WR(AN_RL_L3,L3_UC_CFG_1,0,value);
    
    if (valid) {
        uchar *mac=dmac->addr;
    
        /* Set MACH */
        GW_WR(AN_RL_L3,L3_UC_CFG_2,0,(mac[0]<<8) | mac[1]);
        
        /* Set MACL */
        GW_WR(AN_RL_L3,L3_UC_CFG_3,0,(mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
    }

    /* Issue unicast write command */
    GW_WR(AN_RL_L3,L3_IP_CTRL,0,
          ((arpid/4)<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW) |
          ((arpid%4)<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL) |
          (IP_CMD_WRITE_UC<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
          (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));
    
    /* Wait until idle again */
    return gw_arp_table_idle();
}

/* Update ARP entry */
static vtss_rc gw1_arp_table_update(vtss_arpid_t arpid, vtss_rlid_t erlid, vtss_erlgid_t erlgid)
{
    VTSS_D(("arpid: %d, erlid: %d, erlgid: %d",arpid,erlid,erlgid));

    arpid-=VTSS_ARPID_START;
    erlid-=VTSS_RLID_START;

    /* Write row */
    GW_WRF(AN_RL_L3,L3_IP_CTRL,IP_TABLE_ROW,0,arpid/4);

    /* Write column */
    GW_WRF(AN_RL_L3,L3_IP_CTRL,IP_TABLE_COL,0,arpid%4);

    /* Issue unicast read command */
    GW_WR(AN_RL_L3,L3_IP_CTRL,0,
          ((arpid/4)<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW) |
          ((arpid%4)<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL) |
          (IP_CMD_READ_UC<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
          (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));
          
    /* Wait until idle again */
    VTSS_RC(gw_arp_table_idle());

    /* Set valid, erlid and erlgid fields */
    GW_WR(AN_RL_L3,L3_UC_CFG_1,0,
          (1<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_VALID) |
          (erlgid<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLGID_GW1) |
          (erlid<<O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1));

    /* Issue unicast write command */
    GW_WR(AN_RL_L3,L3_IP_CTRL,0,
          ((arpid/4)<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW) |
          ((arpid%4)<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL) |
          (IP_CMD_WRITE_UC<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
          (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));

    /* Wait until idle again */
    return gw_arp_table_idle();
}

static vtss_rc gw_sec_table_idle(void)
{
    ulong cmd;
    
    /* Wait until idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_SECUR_CTRL,UC_SECUR_TABLE_CMD,0,&cmd);
        if (cmd==SEC_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Initialize security table */
static vtss_rc gw_sec_table_init(void)
{
    VTSS_D(("enter"));

    /* Issue clear command */
    GW_WRF(AN_RL_L3,L3_SECUR_CTRL,UC_SECUR_TABLE_CMD,0,SEC_CMD_CLEAR);
    
    return gw_sec_table_idle();
}

/* Enable/disable security table */
vtss_rc vtss_ll_sec_set(BOOL enable)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("enable: %d",enable));
    
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        
        GW_WRF(AN_RL_L3,L3_SECUR_CTRL,UC_SECUR_ENA,0,enable ? 1 : 0);
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

/* Write security entry */
vtss_rc vtss_ll_sec_table_write(vtss_rlid_t irlid, vtss_rlid_t erlid, BOOL enable)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("irlid: %d, erlid: %d, enable: %d",irlid,erlid,enable));

    irlid-=VTSS_RLID_START;
    erlid-=VTSS_RLID_START;

#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        /* Set index field */
        GW_WRF(AN_RL_L3,L3_SECUR_CTRL,UC_SECUR_TABLE_INDEX,0,irlid);
        
        /* Issue read command */
        GW_WRF(AN_RL_L3,L3_SECUR_CTRL,UC_SECUR_TABLE_CMD,0,SEC_CMD_READ);
        
        /* Wait until idle again */
        VTSS_RC(gw_sec_table_idle());

        /* Set ERLID bit */
        VTSS_RC(gw_wrf(TR(AN_RL_L3,L3_SECUR_CFG),erlid,0x1,0,enable ? 1 : 0));
        
        /* Issue write command */
        GW_WRF(AN_RL_L3,L3_SECUR_CTRL,UC_SECUR_TABLE_CMD,0,SEC_CMD_WRITE);
        
        /* Wait until idle again */
        VTSS_RC(gw_sec_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

/* Write multicast entry */
static vtss_rc gw_mc_table_write(vtss_ip_t sip, vtss_ip_t dip, vtss_rlid_t irlid, 
                                 BOOL rpf_enable, vtss_pgid_no_t pgid_no, vtss_erlgid_t erlgid)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
    VTSS_D(("sip: 0x%08lx, dip: 0x%08lx",sip,dip));
    irlid-=VTSS_RLID_START;

#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        
        /* Set VALID, RPF, ERLGID, IRLID and PGID fields */
        GW_WR(AN_RL_L3,L3_MC_CFG_1,0,
              (1<<O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_VALID) | 
              ((rpf_enable ? 1 : 0)<<O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_RPF_CHK) |
              (erlgid<<O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_ERLGID) |
              (irlid<<O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_IRLID) |
              (gw_pgid_on_chip(pgid_no)<<O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_PGID));
        
        /* Set DIP */
        GW_WR(AN_RL_L3,L3_MC_CFG_2,0,dip);
        
        /* Set SIP */
        GW_WR(AN_RL_L3,L3_MC_CFG_3,0,sip);
        
        /* Issue multicast learn command */
        GW_WR(AN_RL_L3,L3_IP_CTRL,0,
              (0<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW) |
              (0<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL) |
              (IP_CMD_LEARN_MC<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
              (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));
        
        /* Wait until idle again */
        VTSS_RC(gw_arp_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Delete multicast entry */
static vtss_rc gw_mc_table_del(vtss_ip_t sip, vtss_ip_t dip)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
    VTSS_D(("sip: 0x%08lx, dip: 0x%08lx",sip,dip));
#if defined(VTSS_CHIPS)
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */

        /* Set DIP */
        GW_WR(AN_RL_L3,L3_MC_CFG_2,0,dip);
        
        /* Set SIP */
        GW_WR(AN_RL_L3,L3_MC_CFG_3,0,sip);
        
        /* Issue multicast unlearn command */
        GW_WR(AN_RL_L3,L3_IP_CTRL,0,
              (0<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW) |
              (0<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL) |
              (IP_CMD_UNLEARN_MC<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
              (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));
        
        /* Wait until idle again */
        VTSS_RC(gw_arp_table_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Lookup (SIP, DIP) pair, return ERLGID if found */
static vtss_rc gw_mc_table_lookup(vtss_ip_t sip, vtss_ip_t dip, vtss_erlgid_t *erlgid)
{
    ulong hash,row,col,mc_mask,cfg1,cfg2,cfg3;

    /* Calculate 11 bit hash value */
    hash = (sip ^ (sip>>11) ^ ((sip>>22) | (dip<<10)) ^ 
            (dip>>1) ^ (dip>>12) ^ ((dip>>23) & 0x1f));
    mc_mask = ((1<<vtss_api_state->mc_size)-1);
    row = (2047-mc_mask+(hash & mc_mask));
    
    for (col=0; col<3; col++) {
        /* Issue multicast read command */
        GW_WR(AN_RL_L3,L3_IP_CTRL,0,
              (row<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW) |
              (col<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL) |
              (IP_CMD_READ_MC<<O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD) |
              (vtss_api_state->mc_size<<O_AN_RL_L3_L3_IP_CTRL_MC_SIZE));
        
        /* Wait until idle again */
        VTSS_RC(gw_arp_table_idle());

        /* Read CFG1 register */
        GW_RD(AN_RL_L3,L3_MC_CFG_1,0,&cfg1);

        /* If invalid, continue */
        if (!TRF(cfg1,AN_RL_L3,L3_MC_CFG_1,MC_DATA_VALID))
            continue;
        
        /* Read SIP and DIP */
        GW_RD(AN_RL_L3,L3_MC_CFG_2,0,&cfg2);
        GW_RD(AN_RL_L3,L3_MC_CFG_3,0,&cfg3);
        
        /* If (SIP, DIP) match, return ERLGID */
        if ((dip & M_AN_RL_L3_L3_MC_CFG_2_MC_DATA_DIP) == cfg2 &&
            sip == cfg3) {
            *erlgid = TRF(cfg1,AN_RL_L3,L3_MC_CFG_1,MC_DATA_ERLGID);
            VTSS_D(("sip: 0x%08lx, dip: 0x%08lx, row: %ld, col: %ld",sip,dip,row,col));
            return VTSS_OK;
        }
    }
    return VTSS_ENTRY_NOT_FOUND;
}

/* Allocate Port Router Leg ID, returns VTSS_PRLID_END on failure */
static vtss_prlid_t gw_prlid_alloc(vtss_port_no_t port_no, uint count)
{
    vtss_rlid_t     rlid;
    vtss_rl_entry_t *rl_entry;
    BOOL            prlid_used[VTSS_PRLID_ARRAY_SIZE];
    vtss_prlid_t    prlid, prlid_free;
    uint            free_count;
    uint            vr;
    
    memset(prlid_used, 0, sizeof(prlid_used));
    for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
        rl_entry = &vtss_api_state->rl_table[rlid];
        if (rl_entry->enabled) {
            /* Mark port Router Legs as used */
            prlid_used[rl_entry->prlid[port_no]] = 1;

            if (vtss_api_state->gw1e)
                continue;

            /* Mark VR port Router Legs as used */
            for (vr = 0; vr <VTSS_VRIDS; vr++) {
                prlid_used[rl_entry->vr_prlid[vr][port_no]] = 1;
            }
        }
    }
    free_count = 0;
    prlid_free = VTSS_PRLID_END;
    for (prlid = VTSS_PRLID_START; prlid < VTSS_PRLID_END; prlid++) {
        if (!prlid_used[prlid]) {
            /* PRLID unused */
            free_count++;
            if (prlid_free == VTSS_PRLID_END)
                prlid_free = prlid;
        }
    }
    
    if (count > free_count) {
        /* Not enough PRLIDs left */
        prlid_free = VTSS_PRLID_END;
    }
    return prlid_free;
}

static uchar gw_erlgid_mask(vtss_port_no_t port_no,
                            vtss_rlid_t    irlid,
                            BOOL           erlid[VTSS_RLID_ARRAY_SIZE])
{
    uchar           emask;
    vtss_rl_entry_t *rl_entry;
    vtss_rlid_t     rlid;
    BOOL            member;

    emask = 0;
    
    /* Include IRLID and ERLID contribution */
    for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
        rl_entry = &vtss_api_state->rl_table[rlid];
        member = vtss_api_state->vlan_table[rl_entry->rl.vid_mac.vid].member[port_no];
        
        /* L2 forwarding on IRLID */
        if (irlid == rlid && member) {
            emask |= (1 << VTSS_PRLID_L2);
        } 
        
        /* L3 forwarding on ERLID */
        if (erlid[rlid] && member) {
            emask |= (1 << rl_entry->prlid[port_no]);
        }
    }
    return emask;
}

/* Allocate Egress Router Leg ID, returns VTSS_ERLGID_END on failure */
static vtss_rc gw_erlgid_alloc(vtss_erlgid_t erlgid_start,
                               vtss_erlgid_t erlgid_end,
                               vtss_rlid_t   irlid,
                               BOOL          erlid[VTSS_RLID_ARRAY_SIZE],
                               vtss_erlgid_t *new)
{
    vtss_rc             rc;
    vtss_erlgid_t       erlgid,erlgid_free;
    vtss_erlgid_entry_t *erlgid_entry;
    vtss_port_no_t      port_no;
    BOOL                member[VTSS_PORT_ARRAY_SIZE];
    uchar               emask[VTSS_PORT_ARRAY_SIZE],emask_old;
    vtss_rlid_t         rlid;
    
    /* Calculate ERLID masks */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        emask[port_no] = gw_erlgid_mask(port_no, irlid, erlid);
    }
    
    /* Find an available ERLGID */
    erlgid_free = erlgid_end;
    for (erlgid = erlgid_start; erlgid < erlgid_end; erlgid++) {
        erlgid_entry = &vtss_api_state->erlgid_table[erlgid];
        
        /* Remember first free entry */
        if (erlgid_entry->ref_count == 0) {
            if (erlgid_free == erlgid_end)
                erlgid_free = erlgid;
            continue;
        }
        
        /* If IRLID differs, continue with next entry */
        if (irlid != erlgid_entry->irlid) {
            continue;
        }

        if (irlid == 0) {
            /* Try to reuse unicast entry */
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                emask_old = gw_erlgid_mask(port_no, irlid, erlgid_entry->erlid);
                if (emask_old != 0 && emask[port_no] != 0 && emask_old != emask[port_no])
                    break;
            }
            if (port_no == VTSS_PORT_NO_END) {
                /* No mismatch found */
                for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
                    if (erlid[rlid])
                        erlgid_entry->erlid[rlid] = 1;
                }
                break;
            }
        } else {
            /* Try to reuse multicast entry */
            for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
                if (erlgid_entry->erlid[rlid] != erlid[rlid])
                    break;
            }
            if (rlid == vtss_api_state->rlid_end) {
                /* Found matching ERLIDs */
                break;
            }
        }
    } /* ERLGID loop */

    /* Use first free entry if no matching entry found */
    if (erlgid == erlgid_end)
        erlgid = erlgid_free;
    
    /* No matching or free entry found */
    if (erlgid == erlgid_end) {
        *new = VTSS_ERLGID_END;
        return VTSS_OK;
    }

    erlgid_entry = &vtss_api_state->erlgid_table[erlgid];

    if (erlgid_entry->ref_count == 0) {
        /* If new entry, fill out IRLID and ERLID fields */
        erlgid_entry->irlid = irlid;
        for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
            erlgid_entry->erlid[rlid] = erlid[rlid];
        }

        /* If new multicast entry, allocate PGID */
        if (irlid != 0) {
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                member[port_no] = MAKEBOOL01(emask[port_no]);
            }
            if ((rc = vtss_pgid_alloc(&erlgid_entry->pgid_no, 1, member)) < 0) {
                VTSS_E(("no more pgids"));
                return rc;
            }
        }
    }

    /* Write changed ERLGID masks to chip */
    if (erlgid_entry->ref_count == 0 || irlid == 0) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (emask[port_no] == 0)
                continue;
            
#if defined(VTSS_CHIPS)
            vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

            /* Write ERLGID mask */
            VTSS_RC(gw_erlgid_table_write(vtss_api_state->port_map.chip_port[port_no], 
                                          erlgid, emask[port_no]));
        } /* Port loop */
#if defined(VTSS_CHIPS)
        /* Setup internal ports */
        {
            vtss_chip_no_t  chip_no;
            uchar           emask_first,emask_last,emask_iport;
            vtss_prlid_t    prlid = 0;
            uint            iport,port_on_chip;
            vtss_rl_t       *rl = NULL;
            
            /* L2 forwarding on IRLID */
            emask_first = (irlid == 0 ? 0 : (1 << VTSS_PRLID_L2));
            emask_last = emask_first;

            /* L3 forwarding on ERLIDs */
            for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
                if (erlid[rlid]) {
                    rl = &vtss_api_state->rl_table[rlid].rl;
                    
                    if (vtss_api_state->gw1e)
                        continue;

                    prlid = ((rlid+VTSS_PRLID_START)/2);
                    if (rlid & 1) {
                        /* Odd RLIDs on first port (1,3,5,7) */
                        emask_first |= (1 << prlid);
                    } else {
                        /* Even RLIDs on last port (2,4,6,8) */
                        emask_last |= (1 << prlid);
                    }
                }
            }
            
            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);

                for (iport=vtss_api_state->iport_first[chip_no]; 
                     iport<=vtss_api_state->iport_last[chip_no]; 
                     iport++) {
                    port_on_chip = vtss_api_state->iport_setup[iport].chip_port;

                    if (iport == vtss_api_state->iport_first[chip_no])
                        emask_iport = emask_first;
                    else
                        emask_iport = emask_last;
                    
                    /* Write ERLGID mask */
                    VTSS_RC(gw_erlgid_table_write(port_on_chip, erlgid, emask_iport));
                    
                    /* If unicast, update PRLID for internal port enabled for RLID */
                    if (irlid == 0 && emask_iport != 0) {
                        VTSS_RC(gw_prlid_table_write(port_on_chip, prlid, 
                                                     &rl->vid_mac, rl->ipmc_ttl));
                    }
                }
            }
        }
#endif /* VTSS_CHIPS */
    }

    erlgid_entry->ref_count++;
    *new = erlgid;
    return VTSS_OK;
}

/* Free ERLGID previously allocated */
static vtss_rc gw_erlgid_free(vtss_erlgid_t erlgid, vtss_rlid_t rlid)
{
    vtss_erlgid_entry_t *erlgid_entry;

    VTSS_D(("erlgid: %d, rlid: %d", erlgid, rlid));
    erlgid_entry = &vtss_api_state->erlgid_table[erlgid];
    if (erlgid_entry->ref_count == 0) {
        VTSS_E(("erlgid: %d already free, rlid: %d", erlgid, rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    if (rlid == 0) {
        /* Multicast entry, free PGID if last entry */
        if (erlgid_entry->ref_count == 1)
            VTSS_RC(vtss_pgid_free(erlgid_entry->pgid_no));
    } else {
        /* Unicast entrym free ERLID */
        erlgid_entry->erlid[rlid] = 0; 
    }
    erlgid_entry->ref_count--;
    return VTSS_OK;
}

/* Check that VLAN port change can be done */
static vtss_rc gw_rl_vlan_update(vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_rlid_t         rlid;
    vtss_rl_entry_t     *rl_entry = NULL;
    vtss_port_no_t      port_no;
    vtss_prlid_t        prlid[VTSS_PORT_ARRAY_SIZE],prlid_old;
    BOOL                add_ports[VTSS_PORT_ARRAY_SIZE],del_ports[VTSS_PORT_ARRAY_SIZE];
    BOOL                ports_added;
    vtss_erlgid_t       erlgid;
    vtss_erlgid_entry_t *erlgid_entry;
    uint                count=1;
    BOOL                erlid[VTSS_RLID_ARRAY_SIZE];
    vtss_arpid_t        arpid;
    vtss_arp_entry_t    *arp_entry;
    uint                vr;

    VTSS_D(("vid: %d", vid));

    /* Look for Router Leg on VID */
    for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
        rl_entry = &vtss_api_state->rl_table[rlid];
        if (rl_entry->enabled && rl_entry->rl.vid_mac.vid == vid)
            break;
    }

    /* No problem if no Router Leg found */
    if (rlid == vtss_api_state->rlid_end)
        return VTSS_OK;

    /* No problem if IP multicast disabled */
    if (vtss_api_state->gw1e) {
        if (!rl_entry->rl.ipmc_enable)
            return VTSS_OK;
    } else {
        /* Calculate number of PRLIDs required */
        for (vr = 0; vr < VTSS_VRIDS; vr++) {
            if (rl_entry->vrids[vr] != 0)
                count++;
        }
    }
    
    /* Allocate PRLID for added ports */
    ports_added = 0;
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        
        add_ports[port_no] = 0;
        del_ports[port_no] = 0;
        if (member[port_no] && rl_entry->prlid[port_no] == VTSS_PRLID_L2) {
            /* Port has been added */
            prlid[port_no] = gw_prlid_alloc(port_no, count);
            if (prlid[port_no] == VTSS_PRLID_END) {
                VTSS_E(("no more prlids on port_no: %d, count: %d", port_no, count));
                return VTSS_UNSPECIFIED_ERROR;
            }
            ports_added = 1;
            add_ports[port_no] = 1;
        } else {
            prlid[port_no] = (member[port_no] ? rl_entry->prlid[port_no] : VTSS_PRLID_L2);
        }
        if (!member[port_no] && rl_entry->prlid[port_no] != VTSS_PRLID_L2) {
            /* Port has been deleted */
            del_ports[port_no] = 1;
        }
    }
    
    /* Update API state, needed for ERLGID allocation */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        prlid_old = rl_entry->prlid[port_no];
        rl_entry->prlid[port_no] = prlid[port_no];
        prlid[port_no] = prlid_old;
        if (add_ports[port_no])
            vtss_api_state->vlan_table[vid].member[port_no] = 1;
        if (del_ports[port_no])
            vtss_api_state->vlan_table[vid].member[port_no] = 0;
    }

    if (!vtss_api_state->gw1e) {
        /* If ports have been added, try to allocate the same ERLGID */
        if (ports_added) {
        
            /* Free ERLGID and allocate again */
            VTSS_RC(gw_erlgid_free(rl_entry->erlgid, rlid));
            memset(erlid, 0, sizeof(erlid));
            erlid[rlid] = 1;
            VTSS_RC(gw_erlgid_alloc(rl_entry->erlgid, rl_entry->erlgid+1, 0, erlid, &erlgid));
            
            /* If failed, try to allocate new ERLGID */
            if (erlgid == VTSS_ERLGID_END) {
                VTSS_RC(gw_erlgid_alloc(VTSS_ERLGID_START, VTSS_ERLGID_END, 0, erlid, &erlgid));
            } else {
                VTSS_D(("erlgid %d reused for rlid %d",erlgid,rlid));
            }
            
            /* If this also fails, restore API state, reallocate ERLGID and return */
            if (erlgid == VTSS_ERLGID_END) {
                for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                    rl_entry->prlid[port_no] = prlid[port_no];
                    if (add_ports[port_no])
                        vtss_api_state->vlan_table[vid].member[port_no] = 0;
                    if (del_ports[port_no])
                        vtss_api_state->vlan_table[vid].member[port_no] = 1;
                }
                VTSS_RC(gw_erlgid_alloc(rl_entry->erlgid, rl_entry->erlgid+1, 
                                        0, erlid, &erlgid));
                VTSS_E(("no more erlgids"));
                return VTSS_UNSPECIFIED_ERROR;
            } 
            
            /* If ERLGID changed, update ARP entries with the new ERLGID */
            if (erlgid != rl_entry->erlgid) {
                VTSS_D(("new erlgid %d used for rlid %d",erlgid,rlid));
                rl_entry->erlgid = erlgid;
                
                for (arpid = VTSS_ARPID_FIRST; arpid < VTSS_ARPID_END; arpid++) {
                    arp_entry = &vtss_api_state->arp_table[arpid];
                    if (arp_entry->enabled && arp_entry->rlid == rlid) {
                        VTSS_RC(gw1_arp_table_update(arpid, rlid, erlgid));
                    }
                }
            }
        } /* Ports added */
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        uint port_on_chip;

        port_on_chip = vtss_api_state->port_map.chip_port[port_no];
        
        if (!vtss_api_state->gw1e) {
            /* Update deleted ports */
            if (del_ports[port_no]) {
            
#if defined(VTSS_CHIPS)
                vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

                /* Delete IRLID entry for port Router Leg */
                VTSS_RC(gw1_irlid_table_del(port_on_chip, prlid[port_no]));
                
                /* Delete IRLID entries for Virtual Routers */
                for (vr = 0; vr < VTSS_VRIDS; vr++) {
                    prlid_old = rl_entry->vr_prlid[vr][port_no];
                    if (prlid_old != VTSS_PRLID_L2) {
                        VTSS_RC(gw1_irlid_table_del(port_on_chip, prlid_old));
                        rl_entry->vr_prlid[vr][port_no] = VTSS_PRLID_L2;
                    }
                }
            }
        }

        /* Update added ports */
        if (add_ports[port_no]) {

#if defined(VTSS_CHIPS)
            vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
            
            /* Add PRLID entry */
            VTSS_RC(gw_prlid_table_write(port_on_chip, rl_entry->prlid[port_no], 
                                         &rl_entry->rl.vid_mac, rl_entry->rl.ipmc_ttl));

            if (!vtss_api_state->gw1e) {
                /* Add IRLID entry */
                VTSS_RC(gw1_irlid_table_write(port_on_chip, rl_entry->prlid[port_no], rlid, 
                                              &rl_entry->rl.vid_mac, rl_entry->rl.ipmc_enable));

                /* Add IRLID entries for Virtual Routers */
                for (vr = 0; vr < VTSS_VRIDS; vr++) {
                    vtss_vid_mac_t vid_mac;
                    
                    if (rl_entry->vrids[vr] != 0) {
                        rl_entry->vr_prlid[vr][port_no] = gw_prlid_alloc(port_no, 1);
                        vid_mac.vid = vid;
                        vid_mac.mac = vtss_api_state->vrrp_base;
                        vid_mac.mac.addr[5] = rl_entry->vrids[vr];
                        VTSS_RC(gw1_irlid_table_write(port_on_chip, 
                                                      rl_entry->vr_prlid[vr][port_no], 
                                                      rlid, &vid_mac, 0));
                    }
                }
            }
        }
    }

    /* Handle MC entry changes */
    for (erlgid = VTSS_ERLGID_START; erlgid < VTSS_ERLGID_END; erlgid++) {
        vtss_pgid_entry_t *pgid_entry;
        uchar             emask;

        erlgid_entry = &vtss_api_state->erlgid_table[erlgid];
        
        /* Skip unused and unicast entries */
        if (erlgid_entry->ref_count == 0 || erlgid_entry->irlid == 0)
            continue;

        /* Skip multicast entries not including the RLID */
        if (erlgid_entry->irlid != rlid && erlgid_entry->erlid[rlid] == 0)
            continue;

        VTSS_D(("erlgid %d multicast entry changed, rlid %d",erlgid,rlid));

        /* Update changed ports */
        pgid_entry = &vtss_api_state->pgid_table[erlgid_entry->pgid_no];
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {

            if (add_ports[port_no] || del_ports[port_no]) {
                
                /* Calculate new ERLGID mask for port */
                emask = gw_erlgid_mask(port_no, erlgid_entry->irlid, erlgid_entry->erlid);

#if defined(VTSS_CHIPS)
                vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

                /* Write ERLGID mask */
                VTSS_RC(gw_erlgid_table_write(vtss_api_state->port_map.chip_port[port_no], 
                                              erlgid, emask));
                
                /* Update PGID entry state */
                pgid_entry->member[port_no] = MAKEBOOL01(emask);
            }
        }
        
        /* Write changed PGID entry */
        VTSS_RC(vtss_pgid_table_write(erlgid_entry->pgid_no));
    }

    return VTSS_OK;
}

/* Set IP forwarding mode */
vtss_rc vtss_ll_ip_forwarding_set(BOOL enable)
{
    vtss_port_no_t port_no;
    uint           port_on_chip;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {

        port_on_chip = vtss_api_state->port_map.chip_port[port_no];

#if defined(VTSS_CHIPS)
        vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
        
        /* Setup classifier */
        GW_WRF(RXP,SWITCH_MODE_CFG,ANAREQ_IPVALID_SEL,port_on_chip,enable ? 1 : 0);
    }    
    return VTSS_OK;
}

vtss_rc vtss_ll_rl_add(vtss_rlid_t new_rlid, const vtss_rl_t *rl)
{
    vtss_rlid_t     rlid;
    vtss_rl_entry_t *rl_entry;
    vtss_vid_t      vid;
    vtss_port_no_t  port_no;
    BOOL            erlid[VTSS_PORT_ARRAY_SIZE];
    vtss_prlid_t    prlid;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */
    
    vid = rl->vid_mac.vid;
    VTSS_D(("new_rlid: %d, vid: %d", new_rlid, vid));

    rl_entry = &vtss_api_state->rl_table[new_rlid];
    if (rl_entry->enabled) {
        /* Router Leg exists, check that the VLAN is unchanged */
        if (rl_entry->rl.vid_mac.vid != vid) {
            VTSS_E(("old vid %d differs from new vid: %d",
                    rl_entry->rl.vid_mac.vid, vid));
            return VTSS_UNSPECIFIED_ERROR;
        }
        if (vtss_api_state->gw1e) {
            for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
                if (rl_entry->rl.ipmc_enable && !rl->ipmc_enable) {
                    /* IP multicast disabled, free PRLID */
                    rl_entry->prlid[port_no] = VTSS_PRLID_L2;
                }
                if (!rl_entry->rl.ipmc_enable && rl->ipmc_enable &&
                    vtss_api_state->vlan_table[vid].member[port_no]) {
                    /* IP multicast enabled, allocate PRLID */
                    rl_entry->prlid[port_no] = gw_prlid_alloc(port_no, 1);
                    if (rl_entry->prlid[port_no] == VTSS_PRLID_END) {
                        VTSS_E(("no more prlids on port_no: %d", port_no));
                        for (port_no = VTSS_PORT_NO_START; 
                             port_no < VTSS_PORT_NO_END; port_no++) {
                            rl_entry->prlid[port_no] = VTSS_PRLID_L2;
                        }
                        return VTSS_UNSPECIFIED_ERROR;
                    }
                }
            }
        }
        rl_entry->rl = *rl;
    } else {
        /* Router Leg does not exist, create new entry */
        
        /* Check if VLAN already exists */
        for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
            rl_entry = &vtss_api_state->rl_table[rlid];
            if (rl_entry->enabled && rl_entry->rl.vid_mac.vid == vid) {
                VTSS_E(("rlid: %d already uses vid: %d", rlid, vid));
                return VTSS_UNSPECIFIED_ERROR;
            }
        }
        
        /* Find available Port Router Leg ID for all ports in the VLAN */
        rl_entry = &vtss_api_state->rl_table[new_rlid];
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if ((!vtss_api_state->gw1e || rl->ipmc_enable) &&
                vtss_api_state->vlan_table[vid].member[port_no]) {
                rl_entry->prlid[port_no] = gw_prlid_alloc(port_no, 1);
                if (rl_entry->prlid[port_no] == VTSS_PRLID_END) {
                    VTSS_E(("no more prlids on port_no: %d", port_no));
                    return VTSS_UNSPECIFIED_ERROR;
                }
            } else {
                rl_entry->prlid[port_no] = VTSS_PRLID_L2; /* L2 means unused here */
            }
        }

        rl_entry->rl = *rl;
        if (!vtss_api_state->gw1e) {
            memset(erlid, 0, sizeof(erlid));
            erlid[new_rlid] = 1;
#if defined(VTSS_CHIPS)
            /* Allocate unique ERLGID for each Router Leg */
            VTSS_RC(gw_erlgid_alloc(new_rlid, new_rlid+1, 0, erlid, &rl_entry->erlgid));
#else
            VTSS_RC(gw_erlgid_alloc(VTSS_ERLGID_START, VTSS_ERLGID_END, 0,
                                    erlid, &rl_entry->erlgid));
#endif /* VTSS_CHIPS */
            if (rl_entry->erlgid == VTSS_ERLGID_END) {
                VTSS_E(("no more erlgids"));
                return VTSS_UNSPECIFIED_ERROR;
            }
            VTSS_D(("erlgid %d allocated for new_rlid %d",rl_entry->erlgid,new_rlid));
        }

        /* Enable Router Leg */
        rl_entry->enabled = 1;
    }

    /* Add/update ERLID map and ICMP redirect */
#if defined(VTSS_CHIPS)
    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        
        if (vtss_api_state->gw1e) {
            VTSS_RC(gw1e_irlid_table_write(new_rlid, &rl->vid_mac.mac, rl_entry->vrids[0], 
                                           rl_entry->vrids[1], rl->ipmc_enable));
            VTSS_RC(gw_vlan_table_rlid_set(new_rlid, vid));
        }

        /* Add ERLID map entry */
        VTSS_RC(gw_erlid_table_write(new_rlid, vid));
        
        /* Set ICMP redirection */
        VTSS_RC(gw_icmp_set(new_rlid, rl->icmp_redir));
        
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    /* Add/update PRLID and IRLID */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        uint port_on_chip;
        
        if ((prlid = rl_entry->prlid[port_no]) == VTSS_PRLID_L2)
            continue;
        
#if defined(VTSS_CHIPS)
        vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */
            
        port_on_chip = vtss_api_state->port_map.chip_port[port_no];

        /* Add PRLID entry */
        VTSS_RC(gw_prlid_table_write(port_on_chip, prlid, &rl->vid_mac, rl->ipmc_ttl));

        if (!vtss_api_state->gw1e)
            /* Add IRLID entry */
            VTSS_RC(gw1_irlid_table_write(port_on_chip, prlid, new_rlid, 
                                          &rl->vid_mac, rl->ipmc_enable));
    }

    return VTSS_OK;
}

vtss_rc vtss_ll_rl_del(vtss_rlid_t rlid)
{
    vtss_rl_entry_t *rl_entry;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */
    vtss_port_no_t  port_no;

    VTSS_D(("rlid: %d", rlid));

    /* Check if Router Leg already exists */
    rl_entry = &vtss_api_state->rl_table[rlid];
    if (!rl_entry->enabled) {
        VTSS_E(("rlid: %d does not exist", rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    if (vtss_api_state->gw1e) {
#if defined(VTSS_CHIPS)
        for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
            VTSS_RC(gw_vlan_table_rlid_set(0, rl_entry->rl.vid_mac.vid));
#if defined(VTSS_CHIPS)
        }
#endif /* VTSS_CHIPS */
    } else {
        /* Free ERLGID */
        VTSS_RC(gw_erlgid_free(rl_entry->erlgid, rlid));

        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (rl_entry->prlid[port_no] != VTSS_PRLID_L2) {

#if defined(VTSS_CHIPS)
                vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

                /* Delete IRLID entry */
                VTSS_RC(gw1_irlid_table_del(vtss_api_state->port_map.chip_port[port_no], 
                                            rl_entry->prlid[port_no]));
            }
        }
    }

    /* Delete Router Leg state */
    memset(rl_entry, 0, sizeof(*rl_entry));

    return VTSS_OK;
}

/* Set VRRP base address */
vtss_rc vtss_ll_vrrp_addr_set(vtss_mac_t mac)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;

    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        if (vtss_api_state->gw1e) {
            GW_WR(AN_RL_L3,RL_VRRP_CFG_0,0,(mac.addr[0]<<8) | mac.addr[1]); 
            GW_WR(AN_RL_L3,RL_VRRP_CFG_1,0,
                  (mac.addr[2]<<24) | (mac.addr[3]<<16) | (mac.addr[4]<<8)); 
        }
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */
    return VTSS_OK;
}

/* Add Virtual Router */
vtss_rc vtss_ll_vrrp_vrid_add(vtss_vrid_t vrid, vtss_rlid_t rlid)
{
    vtss_rl_entry_t *rl_entry;
    uint            vr, vr_free;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */
    vtss_port_no_t  port_no;
    vtss_prlid_t    prlid[VTSS_PORT_ARRAY_SIZE];
    uint            port_on_chip;
    vtss_vid_mac_t  vid_mac;

    /* Check that the RLID is enabled */
    rl_entry = &vtss_api_state->rl_table[rlid];
    if (!rl_entry->enabled) {
        VTSS_E(("rlid %d not enabled", rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }
    
    /* Check that the VRID does not already exist */
    vr_free = VTSS_VRIDS;
    for (vr = 0; vr < VTSS_VRIDS; vr++) {
        if (rl_entry->vrids[vr] == vrid) {
            VTSS_E(("vrid %d already exists on rlid %d", vrid, rlid));
            return VTSS_UNSPECIFIED_ERROR;
        }
        if (rl_entry->vrids[vr] == 0 && vr_free == VTSS_VRIDS) {
            vr_free = vr;
        }
    }

    /* Check that a free VRID was found */
    if (vr_free == VTSS_VRIDS) {
        VTSS_E(("No free vrid for %d on rlid %d", vrid, rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    if (vtss_api_state->gw1e) {
        rl_entry->vrids[vr_free] = vrid;
#if defined(VTSS_CHIPS)
        for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
            VTSS_RC(gw1e_irlid_table_write(rlid, &rl_entry->rl.vid_mac.mac, rl_entry->vrids[0], 
                                           rl_entry->vrids[1], rl_entry->rl.ipmc_enable));
#if defined(VTSS_CHIPS)
        }
#endif /* VTSS_CHIPS */
        return VTSS_OK;
    }

    /* Check that a PRLID can be allocated */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {

        /* Skip ports not included in VLAN */
        if (rl_entry->prlid[port_no] == VTSS_PRLID_L2)
            continue;
        
        prlid[port_no] = gw_prlid_alloc(port_no, 1);
        if (prlid[port_no] == VTSS_PRLID_END) {
            VTSS_E(("no more prlids on port_no: %d", port_no));
            return VTSS_UNSPECIFIED_ERROR;
        }
    }

    /* Write IRLID entry for all ports */
    rl_entry->vrids[vr_free] = vrid;
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        
        /* Skip ports not included in VLAN */
        if (rl_entry->prlid[port_no] == VTSS_PRLID_L2)
            continue;
        
        rl_entry->vr_prlid[vr_free][port_no] = prlid[port_no];
        vid_mac.vid = rl_entry->rl.vid_mac.vid;
        vid_mac.mac = vtss_api_state->vrrp_base;
        vid_mac.mac.addr[5] = vrid;

        port_on_chip = vtss_api_state->port_map.chip_port[port_no];
        
#if defined(VTSS_CHIPS)
        vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

        VTSS_RC(gw1_irlid_table_write(port_on_chip, prlid[port_no], rlid, &vid_mac, 0));
    }    

    return VTSS_OK;
}

/* Delete Virtual Router */
vtss_rc vtss_ll_vrrp_vrid_del(vtss_vrid_t vrid, vtss_rlid_t rlid)
{
    vtss_rl_entry_t *rl_entry;
    uint            vr;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */
    vtss_port_no_t  port_no;
    uint            port_on_chip;
    vtss_prlid_t    prlid;

    /* Check that the RLID is enabled */
    rl_entry = &vtss_api_state->rl_table[rlid];
    if (!rl_entry->enabled) {
        VTSS_E(("rlid %d not enabled", rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }
    
    /* Check that the VRID exists */
    for (vr = 0; vr < VTSS_VRIDS; vr++) {
        if (rl_entry->vrids[vr] == vrid) {
            break;
        }
    }

    /* Check that a VRID was found */
    if (vr == VTSS_VRIDS) {
        VTSS_E(("vrid %d not found on rlid %d", vrid, rlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Delete IRLID entry for ports */
    rl_entry->vrids[vr] = 0;
    if (vtss_api_state->gw1e) {
#if defined(VTSS_CHIPS)
        for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
            VTSS_RC(gw1e_irlid_table_write(rlid, &rl_entry->rl.vid_mac.mac, rl_entry->vrids[0], 
                                           rl_entry->vrids[1], rl_entry->rl.ipmc_enable));
#if defined(VTSS_CHIPS)
        }
#endif /* VTSS_CHIPS */
        return VTSS_OK;
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {

        /* Skip ports not included in VLAN */
        if ((prlid = rl_entry->vr_prlid[vr][port_no]) == VTSS_PRLID_L2)
            continue;

        port_on_chip = vtss_api_state->port_map.chip_port[port_no];

#if defined(VTSS_CHIPS)
        vtss_io_select_chip(&vtss_state->io[vtss_api_state->port_map.chip_no[port_no]]);
#endif /* VTSS_CHIPS */

        /* Delete IRLID entry for port Router Leg */
        VTSS_RC(gw1_irlid_table_del(port_on_chip, prlid));
        
        rl_entry->vr_prlid[vr][port_no] = VTSS_PRLID_L2;
    }
    return VTSS_OK;
}

static vtss_rc gatwick_ipuc_add(vtss_ip_t net, vtss_ip_t mask, vtss_ip_t router, 
                                vtss_ip_t parent_net, vtss_ip_t parent_mask)
{
    vtss_ucid_t     ucid_i, ucid_j, ucid_new;
    vtss_uc_entry_t *uc_entry_i, *uc_entry_j;
    vtss_arpid_t    arpid_new, arpid_next, arpid_min;
    uint            i, plen;
    BOOL            zero_found;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("net/mask: 0x%08lx/0x%08lx, router: 0x%08lx", net, mask, router));

    /* Calculate prefix length and check mask */ 
    for (i = 0, plen = 0, zero_found = 0; i < 32; i++) {
        if (mask & (1 << (31 - i))) {
            if (zero_found) {
                VTSS_E(("mask: 0x%08lx illegal", mask));
                return VTSS_UNSPECIFIED_ERROR;
            }
            plen++;
        } else {
            zero_found = 1;
        }
    }

    /* First ARP entry is reserved for CPU redirect and is used for discard routes
       and direct routes exceeding the maximum ARP block size */
    arpid_new = (router==VTSS_ROUTER_DISCARD ||
                 (router==VTSS_ROUTER_NONE && (1 << (32 - plen)) > VTSS_OPT_ARP_MAX) ?
                 VTSS_ARPID_START : 0);
    arpid_min = vtss_api_state->arp_size + VTSS_ARPID_START;
    ucid_new = 0;
    for (ucid_i = VTSS_UCID_START; ucid_i < VTSS_UCID_END; ucid_i++) {
        uc_entry_i = &vtss_api_state->uc_table[ucid_i];
        if (!uc_entry_i->enabled)
            break;

        /* Remember smallest ARP block index */
        if (uc_entry_i->router == VTSS_ROUTER_NONE && 
            uc_entry_i->arpid != VTSS_ARPID_START &&
            uc_entry_i->arpid < arpid_min) {
            arpid_min = uc_entry_i->arpid;
        }

        /* Check if route already exists */
        if (plen == uc_entry_i->plen && net == uc_entry_i->net) {
            if (uc_entry_i->router == router) {
                /* Route unchanged */
                return VTSS_OK;
            }
            if (uc_entry_i->router == VTSS_ROUTER_NONE) {
                /* Changing direct to indirect net not allowed */
                VTSS_E(("Direct net/mask 0x%08lx/0x%08lx already exists", net, mask));
                return VTSS_UNSPECIFIED_ERROR;
            }
            if (router == VTSS_ROUTER_NONE) {
                /* Changing indirect to direct net not allowed */
                VTSS_E(("Indirect net/mask 0x%08lx/0x%08lx already exists", net, mask));
                return VTSS_UNSPECIFIED_ERROR;
            }
        }

        /* Find insertion index for the new entry */
        if (ucid_new == 0 && (plen > uc_entry_i->plen || 
                              (plen == uc_entry_i->plen && net < uc_entry_i->net))) {
            ucid_new = ucid_i;
        }

        /* Look for free ARP block/index */
        if (arpid_new == 0) {
            if (router == VTSS_ROUTER_NONE) {
                /* Direct route */

                if (uc_entry_i->router == VTSS_ROUTER_NONE &&
                    uc_entry_i->arpid != VTSS_ARPID_START) {
                    /* Look for direct route with the next ARP index */
                    arpid_next = vtss_api_state->arp_size + VTSS_ARPID_START;
                    for (ucid_j = VTSS_UCID_START; ucid_j < VTSS_UCID_END; ucid_j++) {
                        uc_entry_j = &vtss_api_state->uc_table[ucid_j];
                        if (!uc_entry_j->enabled)
                            break;
                        
                        if (uc_entry_j->router == VTSS_ROUTER_NONE && 
                            uc_entry_j->arpid != VTSS_ARPID_START && 
                            uc_entry_j->arpid > uc_entry_i->arpid && 
                            uc_entry_j->arpid < arpid_next) {
                            arpid_next = uc_entry_j->arpid;
                        }
                    }
                    
                    /* Check if the block is large enough */
                    arpid_new = (uc_entry_i->arpid + (1 << (32 - uc_entry_i->plen)));
                    if ((arpid_new + (1 << (32 - plen))) > arpid_next) {
                        /* The block was too small */
                        arpid_new = 0;
                    }
                }
            } else {
                /* Indirect route */
                if (uc_entry_i->router == VTSS_ROUTER_NONE && 
                    uc_entry_i->arpid != VTSS_ARPID_START &&
                    (router & uc_entry_i->mask) == uc_entry_i->net) {
                    /* Found direct route containing the next hop router */
                    arpid_new = (uc_entry_i->arpid + (router & ~uc_entry_i->mask));
                }
            }
        }
    }

    if (ucid_i == VTSS_UCID_END) {
        VTSS_E(("no room for net/mask 0x%08lx/0x%08lx", net, mask));
        return VTSS_UNSPECIFIED_ERROR;
    }

    if (arpid_new == 0) {
        if (router == VTSS_ROUTER_NONE) {
            if ((arpid_min - VTSS_ARPID_FIRST) > (1 << (32 - plen))) {
                /* The first ARP block is available */
                arpid_new = VTSS_ARPID_FIRST;
            } else {
                VTSS_E(("no ARP block for net/mask 0x%08lx/0x%08lx", net, mask));
                return VTSS_UNSPECIFIED_ERROR;
            }
        } else {
            VTSS_D(("no direct route for router 0x%08lx, net/mask 0x%08lx/0x%08lx", 
                    router, net, mask));
            arpid_new = VTSS_ARPID_START;
        }
    }

    /* Insert entry */
    if (ucid_new == 0)
        ucid_new = ucid_i;
    
    /* Add new entry */
    VTSS_D(("adding at index %d, arpid: %d, net/mask: 0x%08lx/0x%08lx", 
            ucid_new, arpid_new, net, mask));
    for (; ucid_i >= ucid_new; ucid_i--) {
        uc_entry_i = &vtss_api_state->uc_table[ucid_i];
        if (ucid_i == ucid_new) {
            uc_entry_i->net = net;
            uc_entry_i->mask = mask;
            uc_entry_i->router = router;
            uc_entry_i->parent_net = parent_net;
            uc_entry_i->parent_mask = parent_mask;
            uc_entry_i->enabled = 1;
            uc_entry_i->arpid = arpid_new;
            uc_entry_i->arp_count = 0;
            uc_entry_i->plen = plen;
        } else {
            *uc_entry_i = vtss_api_state->uc_table[ucid_i - 1];
        }

#if defined(VTSS_CHIPS)
        for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
            /* Update unicast entry in Gatwick */
            VTSS_RC(gw_uc_table_write(ucid_i, uc_entry_i->net, uc_entry_i->plen,
                                      uc_entry_i->router == VTSS_ROUTER_NONE ? (32 - uc_entry_i->plen) : 0,
                                      uc_entry_i->arpid, uc_entry_i->enabled));
#if defined(VTSS_CHIPS)
        }
#endif /* VTSS_CHIPS */
    }
    return VTSS_OK;
}

vtss_rc vtss_ll_ipuc_add(vtss_ip_t net, vtss_ip_t mask, vtss_ip_t router)
{
    return gatwick_ipuc_add(net, mask, router, 0, 0);
}

vtss_rc vtss_ll_ipuc_del(vtss_ip_t net, vtss_ip_t mask)
{
    vtss_ucid_t     ucid;
    vtss_uc_entry_t *uc_entry;
    vtss_arpid_t    arpid, arpid_end;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */
    uint            del_count = 0;

    VTSS_D(("net/mask: 0x%08lx/0x%08lx", net, mask));

    /* Delete and contract table */
    for (ucid = VTSS_UCID_START; ucid < VTSS_UCID_END; ucid++) {
        uc_entry = &vtss_api_state->uc_table[ucid];
        if (!uc_entry->enabled)
            break;
        
        /* Delete matching parent/child routes */
        if ((uc_entry->net == net && uc_entry->mask == mask) ||
            (net != 0 && mask != 0 && 
             uc_entry->parent_net == net && uc_entry->parent_mask == mask)) {

            del_count++;
            uc_entry->enabled = 0;
            
            /* Delete unicast entry in chip */
#if defined(VTSS_CHIPS)
            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                VTSS_RC(gw_uc_table_write(ucid, 0, 0, 0, 0, 0));
#if defined(VTSS_CHIPS)
            }
#endif /* VTSS_CHIPS */

            /* Delete ARP entries if direct child route */
            if (uc_entry->router == VTSS_ROUTER_NONE && uc_entry->arpid != VTSS_ARPID_START) {
                arpid_end = (uc_entry->arpid + (1 << (32 - uc_entry->plen)));
                VTSS_D(("deleting ARP entries %d-%d", uc_entry->arpid,arpid_end - 1));
                for (arpid = uc_entry->arpid; arpid < arpid_end; arpid++) {
                    if (vtss_api_state->arp_table[arpid].enabled) {
#if defined(VTSS_CHIPS)
                        for (chip_no = VTSS_CHIP_NO_START; 
                             chip_no < VTSS_CHIP_NO_END; chip_no++) {
                            vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                            VTSS_RC(gw_arp_table_write(arpid, NULL, 0, 0, 0));
#if defined(VTSS_CHIPS)
                        }
#endif /* VTSS_CHIPS */
                        vtss_api_state->arp_table[arpid].enabled = 0;
                    }
                }
            }
        } else if (del_count != 0) {
            /* Move entry up if one or more previous entries have been deleted */
#if defined(VTSS_CHIPS)
            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                /* Move entry up */
                VTSS_RC(gw_uc_table_write(ucid - del_count, uc_entry->net, uc_entry->plen,
                                          uc_entry->router == VTSS_ROUTER_NONE ? 
                                          (32 - uc_entry->plen) : 0,
                                          uc_entry->arpid, uc_entry->enabled));
                /* Delete current entry */
                VTSS_RC(gw_uc_table_write(ucid, 0, 0, 0, 0, 0));
#if defined(VTSS_CHIPS)
            }
#endif /* VTSS_CHIPS */
            vtss_api_state->uc_table[ucid - del_count] = *uc_entry;
            uc_entry->enabled = 0;
        }
    }
    
    if (del_count == 0) {
        VTSS_E(("net/mask 0x%08lx/0x%08lx not found", net, mask));
        return VTSS_UNSPECIFIED_ERROR;
    }

    return VTSS_OK;
}

vtss_rc vtss_ll_arp_add(vtss_ip_t dip, const vtss_arp_t *arp)
{
    vtss_ucid_t     ucid, ucid_parent;
    vtss_uc_entry_t *uc_entry;
    vtss_rl_entry_t *rl_entry;
    vtss_arpid_t    arpid;
    vtss_ip_t       child_mask;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("dip: 0x%08lx", dip));
    
    /* Look for direct network including DIP */
    rl_entry = &vtss_api_state->rl_table[arp->rlid];
    ucid_parent = 0;
    for (ucid = VTSS_UCID_START; ucid < VTSS_UCID_END; ucid++) {
        uc_entry = &vtss_api_state->uc_table[ucid];
        if (!uc_entry->enabled)
            break;

        if (uc_entry->router == VTSS_ROUTER_NONE && (dip & uc_entry->mask) == uc_entry->net) {
            
            /* Remember matching parent network */
            if (ucid_parent == 0 && uc_entry->arpid == VTSS_ARPID_START) {
                ucid_parent = ucid;
                continue;
            }
            
            arpid = (uc_entry->arpid + (dip & ~uc_entry->mask));
#if defined(VTSS_CHIPS)
            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                VTSS_RC(gw_arp_table_write(arpid, &arp->dmac, arp->rlid, rl_entry->erlgid, 1));
#if defined(VTSS_CHIPS)
            }
#endif /* VTSS_CHIPS */
            uc_entry->arp_count++;
            vtss_api_state->arp_table[arpid].enabled = 1;
            vtss_api_state->arp_table[arpid].rlid = arp->rlid;
            
            /* Update routes with this DIP as router */
            for (ucid = VTSS_UCID_START; ucid < VTSS_UCID_END; ucid++) {
                uc_entry = &vtss_api_state->uc_table[ucid];
                if (!uc_entry->enabled)
                    break;
                
                if (uc_entry->router == dip) {
                    uc_entry->arpid = arpid;
#if defined(VTSS_CHIPS)
                    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                        VTSS_RC(gw_uc_table_write(ucid, uc_entry->net, uc_entry->plen,
                                                  0, uc_entry->arpid, uc_entry->enabled));
#if defined(VTSS_CHIPS)
                    }
#endif /* VTSS_CHIPS */
                }
            }
            return VTSS_OK;
        }
    }

    /* Add child network if matching parent network was found */
    if (ucid_parent != 0) {
        child_mask = (0xffffffff - (VTSS_OPT_ARP_MAX - 1));
        uc_entry = &vtss_api_state->uc_table[ucid_parent];
        VTSS_RC(gatwick_ipuc_add(dip & child_mask, child_mask, VTSS_ROUTER_NONE, 
                                 uc_entry->net, uc_entry->mask));
        return vtss_ll_arp_add(dip, arp);
    }

    VTSS_E(("direct net including dip 0x%08lx not found", dip));
    return VTSS_UNSPECIFIED_ERROR;
}

vtss_rc vtss_ll_arp_del(vtss_ip_t dip)
{
    vtss_ucid_t     ucid;
    vtss_uc_entry_t *uc_entry;
    vtss_arpid_t    arpid;
    vtss_ip_t       child_net = 0, child_mask = 0;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t  chip_no;
#endif /* VTSS_CHIPS */
    BOOL            found = 0;

    VTSS_D(("dip: 0x%08lx", dip));

    /* Look for direct network including DIP */
    for (ucid = VTSS_UCID_START; ucid < VTSS_UCID_END; ucid++) {
        uc_entry = &vtss_api_state->uc_table[ucid];
        if (!uc_entry->enabled)
            break;
        
        if (uc_entry->router == VTSS_ROUTER_NONE && uc_entry->arpid != VTSS_ARPID_START &&
            (dip & uc_entry->mask) == uc_entry->net) {
            arpid = (uc_entry->arpid + (dip & ~uc_entry->mask));
#if defined(VTSS_CHIPS)
            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                VTSS_RC(gw_arp_table_write(arpid, NULL, 0, 0, 0));
#if defined(VTSS_CHIPS)
            }
#endif /* VTSS_CHIPS */
            vtss_api_state->arp_table[arpid].enabled = 0;

            /* Count down ARP reference count */
            uc_entry->arp_count--;
            if (uc_entry->arp_count == 0 && uc_entry->parent_net != 0) {
                child_net = uc_entry->net;
                child_mask = uc_entry->mask;
            }
            found = 1;
        }
        
        /* Routes using the DIP are changed to the first ARP entry (CPU redirect) */
        if (uc_entry->router == dip) {
            uc_entry->arpid = VTSS_ARPID_START;
#if defined(VTSS_CHIPS)
            for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
                VTSS_RC(gw_uc_table_write(ucid, uc_entry->net, uc_entry->plen,
                                          0, uc_entry->arpid, uc_entry->enabled));
#if defined(VTSS_CHIPS)
            }
#endif /* VTSS_CHIPS */
        }
    }

    /* Delete child network */
    if (child_net != 0) {
        VTSS_D(("deleting child net 0x%08lx/0x%08lx", child_net, child_mask));
        VTSS_RC(vtss_ll_ipuc_del(child_net, child_mask));
    }

    if (!found) {
        /* This is not treated as an error, since the ARP entry may have been
           deleted when deleting the direct route it was based on. */
        VTSS_D(("direct net including dip 0x%08lx not found", dip));
    }
    return VTSS_OK;
}

vtss_rc vtss_ll_ipmc_add(vtss_ip_t sip, vtss_ip_t dip, const vtss_ipmc_t *ipmc)
{
    vtss_rl_entry_t *rl_entry;
    vtss_rlid_t     rlid;
    vtss_erlgid_t   erlgid;
    vtss_pgid_no_t  pgid_no;
    BOOL            erlid[VTSS_RLID_ARRAY_SIZE];

    VTSS_D(("sip: 0x%08lx, dip: 0x%08lx",sip,dip));
    
    /* Check that the IRLID is enabled */
    rl_entry = &vtss_api_state->rl_table[ipmc->irlid];
    if (!rl_entry->enabled) {
        VTSS_E(("irlid %d not enabled", ipmc->irlid));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Check that the ERLIDs are enabled */
    for (rlid = VTSS_RLID_START; rlid < vtss_api_state->rlid_end; rlid++) {
        rl_entry = &vtss_api_state->rl_table[rlid];
        erlid[rlid] = MAKEBOOL01(ipmc->erlid[rlid]);
        if (erlid[rlid] && !rl_entry->enabled) {
            VTSS_E(("erlid %d not enabled", rlid));
            return VTSS_UNSPECIFIED_ERROR;
        }
    }

    /* Check that the (SIP, DIP) pair does not already exist */
    if (gw_mc_table_lookup(sip, dip, &erlgid)==VTSS_OK) {
        VTSS_E(("sip: 0x%08lx, dip: 0x%08lx already exists", sip, dip));
        return VTSS_UNSPECIFIED_ERROR;
    }


    if (vtss_api_state->gw1e) {
        /* Allocate PGID and ERLGID in range 1-31 */
        VTSS_RC(gw_erlgid_alloc(VTSS_ERLGID_START, VTSS_ERLGID_END, 
                                ipmc->irlid, erlid, &erlgid));
    } else
        /* Allocate PGID and ERLGID in range 9-31 */
        VTSS_RC(gw_erlgid_alloc(VTSS_ERLGID_START + 8, VTSS_ERLGID_END, 
                                ipmc->irlid, erlid, &erlgid));
    if (erlgid == VTSS_ERLGID_END) {
        VTSS_E(("no more erlgids"));
        return VTSS_UNSPECIFIED_ERROR;
    }

    pgid_no = vtss_api_state->erlgid_table[erlgid].pgid_no;

    /* Add multicast entry */
    return gw_mc_table_write(sip, dip, ipmc->irlid, ipmc->rpf_enable, pgid_no, erlgid);
}

vtss_rc vtss_ll_ipmc_del(vtss_ip_t sip, vtss_ip_t dip)
{
    vtss_erlgid_t erlgid;
    
    VTSS_D(("sip: 0x%08lx, dip: 0x%08lx",sip,dip));

    /* Lookup (SIP, DIP) pair */
    VTSS_RC(gw_mc_table_lookup(sip, dip, &erlgid));

    /* Free ERLGID and PGID */
    VTSS_RC(gw_erlgid_free(erlgid, 0));

    /* Delete multicast entry */
    return gw_mc_table_del(sip, dip);
}

/* Get IP counters */
vtss_rc vtss_ll_ip_counters_get(vtss_ip_counters_t *counters)
{
    ulong cnt;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */
    
    VTSS_N(("enter"));

    /* Clear counter fields */
    counters->rx_packets=0;
    counters->tx_uc_packets=0;
    counters->tx_mc_packets=0;
    counters->secur_fail_packets=0;

#if defined(VTSS_CHIPS)
    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        GW_RD(AN_RL_L3,L3_IP_PKT_RECEIVED_CNT,0,&cnt);
        counters->rx_packets += cnt;

        GW_RD(AN_RL_L3,L3_IP_UC_FWD_CNT,0,&cnt);
        counters->tx_uc_packets += cnt;
        
        GW_RD(AN_RL_L3,L3_IP_NON_UC_FWD_CNT,0,&cnt);
        counters->tx_mc_packets += cnt;

        GW_RD(AN_RL_L3,L3_SECUR_FAIL_PKT_CNT,0,&cnt);
        counters->secur_fail_packets += cnt;
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

static vtss_rc gw_irlid_counters_idle(void)
{
    ulong cmd;

    /* Wait until IRLID counters are idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_IRLID_CNT_CTRL,IRLID_CNT_CMD,0,&cmd);
        if (cmd==IRLID_CNT_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

static vtss_rc gw_erlid_counters_idle(void)
{
    ulong cmd;

    /* Wait until ERLID counters are idle again */
    while (1) {
        GW_RDF(AN_RL_L3,L3_ERLID_CNT_CTRL,ERLID_CNT_CMD,0,&cmd);
        if (cmd==ERLID_CNT_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Get Router Leg counters */
vtss_rc vtss_ll_rl_counters_get(vtss_rlid_t rlid, vtss_rl_counters_t *counters)
{
    ulong              cnt;
    vtss_counter_t     octets,msb;
#if defined(VTSS_CHIPS)
    vtss_chip_no_t     chip_no;
#endif /* VTSS_CHIPS */

    VTSS_N(("rlid: %d",rlid));

    rlid-=VTSS_RLID_START;

    /* Clear counter fields */
    counters->rx_uc_packets=0;
    counters->rx_mc_packets=0;
    counters->rx_rpf_packets=0;
    counters->rx_octets=0;
    counters->tx_uc_packets=0;
    counters->tx_uc_octets=0;

#if defined(VTSS_CHIPS)
    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        /* Issue read and clear command for IRLID counters */
        GW_WR(AN_RL_L3,L3_IRLID_CNT_CTRL,0,
              (rlid<<O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_INDEX) |
              (M_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_SELECTION<<
               O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_SELECTION) |
              (IRLID_CNT_CMD_READ_CLEAR<<O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_CMD));

        /* Issue read and clear command for ERLID counters */
        GW_WR(AN_RL_L3,L3_ERLID_CNT_CTRL,0,
              (rlid<<O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_INDEX) |
              (M_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_SELECTION<<
               O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_SELECTION) |
              (ERLID_CNT_CMD_READ_CLEAR<<O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_CMD));
    
        /* Wait until IRLID counters are idle again */
        VTSS_RC(gw_irlid_counters_idle());

        /* Read IRLID counters */
        GW_RD(AN_RL_L3,L3_IRLID_UC_PKT_CNT,0,&cnt);
        counters->rx_uc_packets += cnt;

        GW_RD(AN_RL_L3,L3_IRLID_NON_UC_PKT_CNT,0,&cnt);
        counters->rx_mc_packets += cnt;

        GW_RD(AN_RL_L3,L3_IRLID_MC_RPF_FAIL_PKT_CNT,0,&cnt);
        counters->rx_rpf_packets += cnt;
        
        GW_RD(AN_RL_L3,L3_IRLID_OCTETS_LSB_CNT,0,&cnt);
        octets = cnt;
        if (sizeof(vtss_counter_t)==8) {
            /* Include MSB octets */
            GW_RD(AN_RL_L3,L3_IRLID_OCTETS_MSB_CNT,0,&cnt);
            msb = cnt;
            octets += (msb<<sizeof(vtss_counter_t)*4);
        }
        counters->rx_octets += octets;
        
        /* Wait until ERLID counters are idle again */
        VTSS_RC(gw_erlid_counters_idle());
        
        /* Read ERLID counters */
        GW_RD(AN_RL_L3,L3_ERLID_UC_PKT_CNT,0,&cnt);
        counters->tx_uc_packets += cnt;
        
        GW_RD(AN_RL_L3,L3_ERLID_UC_OCTETS_LSB_CNT,0,&cnt);
        octets = cnt;
        if (sizeof(vtss_counter_t)==8) {
            /* Include MSB octets */
            GW_RD(AN_RL_L3,L3_ERLID_UC_OCTETS_MSB_CNT,0,&cnt);
            msb = cnt;
            octets+=(msb<<sizeof(vtss_counter_t)*4);
        }
        counters->tx_uc_octets += octets;
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}

/* Clear Router Leg counters */
vtss_rc vtss_ll_rl_counters_clear(vtss_rlid_t rlid)
{
#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
#endif /* VTSS_CHIPS */

    VTSS_D(("rlid: %d",rlid));

    rlid-=VTSS_RLID_START;

#if defined(VTSS_CHIPS)
    for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
        /* Issue clear command for IRLID counters */
        GW_WR(AN_RL_L3,L3_IRLID_CNT_CTRL,0,
              (rlid<<O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_INDEX) |
              (M_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_SELECTION<<
               O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_SELECTION) |
              (IRLID_CNT_CMD_CLEAR_ONE<<O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_CMD));

        /* Issue clear command for ERLID counters */
        GW_WR(AN_RL_L3,L3_ERLID_CNT_CTRL,0,
              (rlid<<O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_INDEX) |
              (M_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_SELECTION<<
               O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_SELECTION) |
              (ERLID_CNT_CMD_CLEAR_ONE<<O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_CMD));
        
        /* Wait until IRLID counters are idle again */
        VTSS_RC(gw_irlid_counters_idle());
        
        /* Wait until ERLID counters are idle again */
        VTSS_RC(gw_erlid_counters_idle());
#if defined(VTSS_CHIPS)
    }
#endif /* VTSS_CHIPS */

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_LAYER3 */

/***************************************************************************
 *** Supplementary *********************************************************
 ***************************************************************************/

/* Target register read */
vtss_rc vtss_ll_register_read(ulong reg, ulong *value)
{
    vtss_rc rc;
    uint    target,address;

    target=((reg>>8) & 0xff);
    address=(reg & 0xff);

    VTSS_D(("target: 0x%02x, address: 0x%02x",target,address));

    if (vtss_api_state->init_setup.use_cpu_si)
        rc=vtss_io_si_rd(target,address,value);
    else
        rc=vtss_io_pi_tgt_rd(target,address,value);

    return rc;
}

/* Target register write */
vtss_rc vtss_ll_register_write(ulong reg, ulong value)
{
    vtss_rc rc;
    uint    target,address;

    target=((reg>>8) & 0xff);
    address=(reg & 0xff);
    
    VTSS_D(("target: 0x%02x, address: 0x%02x, value: 0x%08lx",target,address,value));

    if (vtss_api_state->init_setup.use_cpu_si)
        rc=vtss_io_si_wr(target,address,value);
    else
        rc=vtss_io_pi_tgt_wr(target,address,value);
    
    return rc;
}

/* Get chip ID and revision */
/* Note: Use chipid=NULL for checking CPU access to the switch chip. */
vtss_rc vtss_ll_chipid_get(vtss_chipid_t *chipid)
{
    ulong value;

    VTSS_D(("enter"));

#if defined(VTSS_CHIPS)
    vtss_io_select_chip(&vtss_state->io[VTSS_CHIP_NO_START]);
#endif /* VTSS_CHIPS */
        
    GW_RD(CPU_CCA,CHIP_JTAG_ID,0,&value);
    if (chipid) {
        chipid->part_number = TRF(value,CPU_CCA,CHIP_JTAG_ID,PART_NUMBER);
        chipid->revision = (TRF(value,CPU_CCA,CHIP_JTAG_ID,REVISION_ID)+1);

        /* Detect second revision */
        if (chipid->revision == 1 && vtss_api_state->gw1e)
            chipid->revision = 2;

        VTSS_D(("part_number: 0x%04x, revision: 0x%04x",chipid->part_number,chipid->revision));
    }

    if (value==0x00000000 || value==0xFFFFFFFF) {
        return VTSS_DATA_NOT_READY;
    }
    return VTSS_OK;
}

vtss_rc vtss_ll_optimize_1sec(void)
{
    uint           port_on_chip,i,hdx_count=0;
    vtss_port_no_t port_no,port;
    BOOL           drops=0;
    ulong          value, val;
    ulong          schedstate;

#if defined(VTSS_CHIPS)
    vtss_chip_no_t chip_no;
        
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#endif /* VTSS_CHIPS */
    
        for (port_on_chip=8; port_on_chip<VTSS_CHIP_PORTS; port_on_chip++) {
            
#if defined(VTSS_CHIPS)
            port_no = vtss_api_state->port_map.vtss_port[chip_no][port_on_chip];
#else
            port_no = vtss_api_state->port_map.vtss_port[port_on_chip];
#endif /* VTSS_CHIPS */
                
            GW_RDF(TXP, SCHED_STATUS, STATE, port_on_chip, &schedstate);
            if (schedstate == 4) {
                GW_RDF(TXP, QS_CPU_CTRL, BUSY, 4*(port_on_chip/4), &value);
                if (value) {
                    VTSS_D(("port_no %d busy, optimizing", port_no));
                    GW_WRF(D4_MAC, MODE_CFG, FDX, port_on_chip, 1);
                    GW_WRF(D4_MAC, MODE_CFG, FDX, port_on_chip, 0);
                }
            }
            
            if (!vtss_api_state->gw1e) {
                /* If first port in D4 module, do calculations */
                if ((port_on_chip%4)==0) {
                    /* Read QS egress drop counter */
                    GW_RD(TXP,QS_DROP_CNT,port_on_chip,&value);
                    drops = (value != vtss_api_state->tx_drops[port_no]);
                    vtss_api_state->tx_drops[port_no] = value;
                    
                    /* Calculate number of half duplex ports in device */
                    for (hdx_count=0,i=0; i<3; i++) {
#if defined(VTSS_CHIPS)
                        port = vtss_api_state->port_map.vtss_port[chip_no][port_on_chip+i];
#else
                        port = vtss_api_state->port_map.vtss_port[port_on_chip+i];
#endif /* VTSS_CHIPS */
                        if (VTSS_STP_UP(vtss_api_state->stp_state[port]) &&
                            !vtss_api_state->setup[port].fdx) {
                            hdx_count++;
                        }
                    }                
                }
                
                /* Read SE egress byte counter */
                GW_RD(SE,TX_OUT_BYTES_CNT,port_on_chip,&value);
                if (VTSS_STP_UP(vtss_api_state->stp_state[port_no]) && 
                    hdx_count &&
                    value == vtss_api_state->tx_bytes[port_no] &&
                    ((vtss_api_state->port_fc_rx[port_no] || 
                      vtss_api_state->port_fc_tx[port_no]) ||
                     drops)) {
                    
                    VTSS_D(("optimizing port_no %d",port_no));
                    
                    /* Disable and flush egress queue system */
                    GW_RD(TXP,QS_CFG,port_on_chip,&value);
                    val = 0;
                    for (i=0; i<VTSS_QUEUES; i++) {
                        val|=((0<<(O_TXP_QS_CFG_WR_ENA+i)) | 
                              (0<<(O_TXP_QS_CFG_RD_ENA+i)) |
                              (1<<(O_TXP_QS_CFG_AGE_ENA+i)) |
                              (1<<(O_TXP_QS_CFG_FLUSH+i)));
                    }
                    GW_WR(TXP,QS_CFG,port_on_chip,val);
                    
                    /* Briefly switch to FDX mode to reactivate the scheduler */
                    GW_RDF(TXP,SCHED_STATUS,STATE,port_on_chip,&schedstate);
                    if (schedstate==0x4) {
                        /* State 4 can only occur for HDX ports, so setting HDX is safe */
                        GW_WRF(D4_MAC,MODE_CFG,FDX,port_on_chip,1);
                        GW_WRF(D4_MAC,MODE_CFG,FDX,port_on_chip,0);
                    }
                    
                    /* Enable egress queues again */
                    GW_WR(TXP,QS_CFG,port_on_chip,value);
                } else
                    vtss_api_state->tx_bytes[port_no] = value;
            }
#if defined(VTSS_CHIPS)
        }
#endif /* VTSS_CHIPS */
    }

#ifdef BOARD_JETWAY48    
    {
        vtss_chip_no_t     chip_no;
        uint               port_on_chip,iport,iport_first,mii,phy,mmd;
        vtss_iport_setup_t *iport_setup;
        ulong              counter;
        ushort             value, mask=(0xf<<8);
        BOOL               port_up;
        
        /* Control Jetway LEDs on internal ports */
        mmd = VTSS_MMD_DTE_XS;
        for (chip_no = VTSS_CHIP_NO_START; chip_no < VTSS_CHIP_NO_END; chip_no++) {
            vtss_io_select_chip(&vtss_state->io[chip_no]);

            /* Control LEDs for both ports even though only one is operational */
            iport_first = vtss_api_state->iport_first[chip_no];
            if (iport_first == vtss_api_state->iport_last[chip_no])
                iport_first--;

            for (iport=iport_first; 
                 iport<=vtss_api_state->iport_last[chip_no]; 
                 iport++) {
                
                iport_setup = &vtss_api_state->iport_setup[iport];
                port_on_chip = iport_setup->chip_port;

                /* 10G LEDs are swapped on the board */
                phy = (iport_setup->phy_addr == 1 ? 0 : 1);
                mii = iport_setup->miim_controller;
                
                VTSS_RC(gw_port_up(port_on_chip, &port_up));;

                VTSS_D(("chip_no: %d, port_on_chip: %d, phy_addr: %d, up: %d",
                        chip_no,port_on_chip,phy,port_up));

                /* Link: LED 5 control */
                value = ((port_up ? 1 : 0)<<8);
                gw_mmd_write_masked(mii, phy, mmd, 0x8006, value, mask);
                
                /* Rx activity: LED 3 control */
                GW_RD(SE,RX_OK_BYTES_CNT,port_on_chip,&counter);
                value = ((counter!=vtss_api_state->rx_ok_bytes[iport] ? 2 : 0)<<8); 
                vtss_api_state->rx_ok_bytes[iport] = counter;
                gw_mmd_write_masked(mii, phy, mmd, 0x8005, value, mask);
                
                /* Tx activity: LED 1 control */
                GW_RD(SE,TX_OK_BYTES_CNT,port_on_chip,&counter);
                value = ((counter!=vtss_api_state->tx_ok_bytes[iport] ? 2 : 0)<<8); 
                vtss_api_state->tx_ok_bytes[iport] = counter;
                gw_mmd_write_masked(mii, phy, mmd, 0x8004, value, mask);
            }
        }    
    }
#endif /* BOARD_JETWAY48 */
#if defined(VTSS_CHIPS) && (VTSS_OPT_MAC_SYNC_MAX != 0)
    /* MAC address table synchronization */
    {
        vtss_chip_no_t chip_no,chip_other;
        ulong          count,index,cfg0,cfg1,cfg2,valid,c0,c1,c2;
        ulong          col,col_inv,col_ext,col_int;
        uint           pgid_int_cur,pgid_int_other,done,do_sync;
        vtss_pgid_no_t pgid_no;
        
        /* Check replace event */
        if (vtss_api_state->mac_index_sync == 0) {
            VTSS_RC(vtss_mac_table_status_read());
            do_sync = vtss_api_state->mac_status_sync.replaced;
            vtss_api_state->mac_status_sync.replaced = 0;
        } else {
            do_sync = 1;
        }
        
        if (do_sync) {
            VTSS_D(("synchronization start, index: %d",vtss_api_state->mac_index_sync));
            chip_no = VTSS_CHIP_NO_START;
            chip_other = (VTSS_CHIP_NO_START+1);
            pgid_int_cur = vtss_api_state->iport_setup[
                vtss_api_state->iport_first[chip_no]].chip_port;
            pgid_int_other = vtss_api_state->iport_setup[
                vtss_api_state->iport_first[chip_other]].chip_port;
            count = 0;
            for (index=vtss_api_state->mac_index_sync; index<vtss_api_state->mac_addrs; index++) {
                vtss_io_select_chip(&vtss_state->io[chip_no]);
                
                /* Read entry */
                if (vtss_api_state->gw1e)
                    cfg2 = (((index%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                            ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
                else
                    cfg2 = (((index%4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                            ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
                GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,cfg2);
                GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                      MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                VTSS_RC(gw_mac_table_idle());
                
                /* If the entry is invalid or locked, continue */
                GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&cfg2);
                if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0 ||
                    TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,LOCKED)==1)
                    continue;
                
                /* Lookup in other chip */
                GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&cfg0);
                GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&cfg1);
                vtss_io_select_chip(&vtss_state->io[chip_other]);
                GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                      MAC_CMD_LOOKUP<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                VTSS_RC(gw_mac_table_idle());
                
                /* If the entry is found, continue */
                GW_RDF(AN_L2_PS,L2_MAC_CFG_2,VALID,0,&valid);
                if (valid)
                    continue;
                
                /* Indicate that replace has taken place */
                vtss_api_state->mac_status_appl.replaced = 1;
                vtss_api_state->mac_status_next.replaced = 1;

                /* Upper limit for number of entries synchronized */
                count++;
                if (count == VTSS_OPT_MAC_SYNC_MAX)
                    break;
                
                VTSS_D(("unsync entry on chip %d at [%ld,%ld], vid: 0x%04lx, mac: %04lx%08lx",
                        chip_no,index/4,index%4,
                        TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                        TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                        cfg1));

                /* The entry was only found on one chip, examine hash row on other chip */
                col_ext = 4;
                col_int = 4;
                col_inv = 4;
                for (col = 0; col < 4; col++) {
                    /* Read entry */
                    vtss_io_select_chip(&vtss_state->io[chip_other]);
                    if (vtss_api_state->gw1e) {
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                              (col<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                              ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
                    } else
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                              (col<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                              ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
                    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                          MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                    VTSS_RC(gw_mac_table_idle());
                    GW_RD(AN_L2_PS,L2_MAC_CFG_2,0,&c2);
                    
                    /* If the entry is invalid, remember column and continue */
                    if (TRF(c2,AN_L2_PS,L2_MAC_CFG_2,VALID)==0) {
                        VTSS_D(("chip %d, invalid at [%ld,%ld]",chip_other,index/4,col));
                        col_inv = col;
                        continue;
                    }

                    /* If the entry is locked, continue */
                    if (TRF(c2,AN_L2_PS,L2_MAC_CFG_2,LOCKED)==1) {
                        VTSS_D(("chip %d, locked at [%ld,%ld]",chip_other,index/4,col));
                        continue;
                    }                    
                    /* Check if the entry exists on current chip */
                    GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&c0);
                    GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&c1);
                    VTSS_D(("chip %d at [%ld,%ld], vid: 0x%04lx, mac: %04lx%08lx",
                            chip_other,index/4,col,
                            TRF(c0,AN_L2_PS,L2_MAC_CFG_0,VID),
                            TRF(c0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                            c1));
                    vtss_io_select_chip(&vtss_state->io[chip_no]);
                    GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,c0);
                    GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,c1);
                    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                          MAC_CMD_LOOKUP<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                    VTSS_RC(gw_mac_table_idle());
                    
                    /* If the entry is found, continue */
                    GW_RDF(AN_L2_PS,L2_MAC_CFG_2,VALID,0,&valid);
                    if (valid) {
                        continue;
                    }
                    
                    if (vtss_api_state->gw1e) {
                        pgid_no = gw_pgid_on_hl(chip_no, 
                                                TRF(c2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1E));
                        if (vtss_api_state->port_map.chip_no[pgid_no] == chip_other) {
                            /* Entry learned on external port */
                            if (TRF(c2,AN_L2_PS,L2_MAC_CFG_2,AGE_FLAG))
                                col_int = col; /* Aged entry treated like internal entry */
                            else
                                col_ext = col;
                        } else {
                            /* Entry learned on internal port */
                            col_int = col;
                        }
                    } else {
                        if (TRF(c2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1)==pgid_int_other) {
                            /* Entry learned on internal port, delete */
                            VTSS_D(("deleting unsync entry on chip %d, vid: 0x%04lx, mac: %04lx%08lx",
                                    chip_other,
                                    TRF(c0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                    TRF(c0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                    c1));
                            vtss_io_select_chip(&vtss_state->io[chip_other]);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,c0);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,c1);
                            GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                  MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                            VTSS_RC(gw_mac_table_idle());
                            col_inv = col;
                        } else {
                            /* Entry learned on external port, remember column */
                            col_ext = col;
                        }
                    }
                } /* Column loop */
                
                done = 0;
                if (vtss_api_state->gw1e) {
                    col = (col_inv == 4 ? col_int : col_inv);
                    if (col != 4) {
                        /* Overwrite invalid/internal/external port entry on other chip */
                        VTSS_D(("writing entry on chip %d at [%ld,%ld], vid: 0x%04lx, mac: %04lx%08lx",
                                chip_other,index/4,col,
                                TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                cfg1));
                        vtss_io_select_chip(&vtss_state->io[chip_other]);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                        c2 = ((0<<O_AN_L2_PS_L2_MAC_CFG_2_MIRROR) | 
                              (0<<O_AN_L2_PS_L2_MAC_CFG_2_LOCKED) |
                              (1<<O_AN_L2_PS_L2_MAC_CFG_2_VALID) |
                              (0<<O_AN_L2_PS_L2_MAC_CFG_2_AGE_FLAG) |
                              (0<<O_AN_L2_PS_L2_MAC_CFG_2_VLAN_IGNORE) |
                              (0<<O_AN_L2_PS_L2_MAC_CFG_2_CPU_COPY) |
                              (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1E)<<
                               O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1E) |
                              (col<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                              ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,c2);
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_WRITE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        done = 1;
                    } else if (col_ext != 4) {
                        /* Entry on external port found on other chip, overwrite current */
                        vtss_io_select_chip(&vtss_state->io[chip_other]);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                              (col_ext<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E) |
                              ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E));
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&c0);
                        GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&c1);
                        GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&c2);
                        VTSS_D(("writing entry on chip %d at [%ld,%ld], vid: 0x%04lx, mac: %04lx%08lx",
                                chip_no,index/4,index%4,
                                TRF(c0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                TRF(c0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                c1));
                        vtss_io_select_chip(&vtss_state->io[chip_no]);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,c0);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,c1);
                        GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                              (c2 & (M_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E<<
                                     O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E)) |
                              ((index % 4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E));
                        GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                              MAC_CMD_WRITE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                        VTSS_RC(gw_mac_table_idle());
                        done = 1;
                    }
                } else {
                    if (TRF(cfg2,AN_L2_PS,L2_MAC_CFG_2,PGID_GW1)==pgid_int_cur) {
                        /* Entry in current chip was learned on internal port */
                        if (col_ext != 4) {
                            /* Entry on external port found on other chip, overwrite current */
                            vtss_io_select_chip(&vtss_state->io[chip_other]);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                                  (col_ext<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                                  ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
                            GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                  MAC_CMD_READ<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                            VTSS_RC(gw_mac_table_idle());
                            GW_RD(AN_L2_PS,L2_MAC_CFG_0,0,&c0);
                            GW_RD(AN_L2_PS,L2_MAC_CFG_1,0,&c1);
                            VTSS_D(("writing entry on chip %d at [%ld,%ld], vid: 0x%04lx, mac: %04lx%08lx",
                                    chip_no,index/4,index%4,
                                    TRF(c0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                    TRF(c0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                    c1));
                            vtss_io_select_chip(&vtss_state->io[chip_no]);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,c0);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,c1);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,cfg2);
                            GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                  MAC_CMD_WRITE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                            VTSS_RC(gw_mac_table_idle());
                            done = 1;
                        } 
                    } else {
                        /* Entry in current chip was learned on external port */
                        col = (col_inv == 4 ? col_ext : col_inv);
                        if (col != 4) {
                            /* Overwrite invalid/internal/external port entry on other chip */
                            VTSS_D(("writing entry on chip %d at [%ld,%ld], vid: 0x%04lx, mac: %04lx%08lx",
                                    chip_other,index/4,col,
                                    TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                                    TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                                    cfg1));
                            vtss_io_select_chip(&vtss_state->io[chip_other]);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                            GW_WR(AN_L2_PS,L2_MAC_CFG_2,0,
                                  (0<<O_AN_L2_PS_L2_MAC_CFG_2_MIRROR) | 
                                  (0<<O_AN_L2_PS_L2_MAC_CFG_2_LOCKED) |
                                  (1<<O_AN_L2_PS_L2_MAC_CFG_2_VALID) |
                                  (0<<O_AN_L2_PS_L2_MAC_CFG_2_AGE_FLAG) |
                                  (0<<O_AN_L2_PS_L2_MAC_CFG_2_VLAN_IGNORE) |
                                  (0<<O_AN_L2_PS_L2_MAC_CFG_2_CPU_COPY) |
                                  (pgid_int_other<<O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1) |
                                  (col<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1) |
                                  ((index/4)<<O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1));
                            GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                                  MAC_CMD_WRITE<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                            VTSS_RC(gw_mac_table_idle());
                            done = 1;
                        }
                    }
                }
                if (!done) {
                    /* Current entry must be deleted */
                    VTSS_D(("removing entry on chip %d, vid: 0x%04lx, mac: %04lx%08lx",
                            chip_no,
                            TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,VID),
                            TRF(cfg0,AN_L2_PS,L2_MAC_CFG_0,MACH),
                            cfg1));
                    vtss_io_select_chip(&vtss_state->io[chip_no]);
                    GW_WR(AN_L2_PS,L2_MAC_CFG_0,0,cfg0);
                    GW_WR(AN_L2_PS,L2_MAC_CFG_1,0,cfg1);
                    GW_WR(AN_L2_PS,L2_MAC_CTRL,0,
                          MAC_CMD_UNLEARN<<O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD);
                    VTSS_RC(gw_mac_table_idle());
                }
            } /* MAC address table loop */
            vtss_api_state->mac_index_sync = (index==vtss_api_state->mac_addrs ? 0 : index);
            VTSS_D(("synchronization done, index: %ld",index));
        } /* Synchronization */
    }
#endif /* VTSS_CHIPS && VTSS_OPT_MAC_SYNC_MAX != 0 */
    return VTSS_OK;
}

/* Set GPIO direction */
vtss_rc vtss_ll_gpio_direction_set(vtss_gpio_no_t gpio_no, BOOL output)
{
    VTSS_D(("gpio_no: %d, output: %d",gpio_no,output));
    
    return gw_wrf(TR(CPU_GM,GPIO_DIRECTION),O_CPU_GM_GPIO_DIRECTION_OUT_ENA+gpio_no,
                  0x1,0,output ? 1 : 0);
}

/* Read GPIO input pin */
vtss_rc vtss_ll_gpio_input_read(vtss_gpio_no_t gpio_no, BOOL *value)
{
    vtss_rc rc;
    ulong   val;
    
    VTSS_D(("gpio_no: %d",gpio_no));
    
    rc = gw_rdf(TR(CPU_GM,GPIO_IN),O_CPU_GM_GPIO_IN_GPIO_IN_DATA+gpio_no,0x1,0,&val);
    *value = MAKEBOOL01(val);
    return rc;
}

/* Write GPIO output pin */
vtss_rc vtss_ll_gpio_output_write(vtss_gpio_no_t gpio_no, BOOL value)
{
    VTSS_D(("gpio_no: %d, value: %d",gpio_no,value));

    return gw_wrf(TR(CPU_GM,GPIO_OUT),O_CPU_GM_GPIO_OUT_GPIO_OUT_DATA+gpio_no,
                  0x1,0,value ? 1 : 0);
}

/* Initialize low level layer */
vtss_rc vtss_ll_init(const vtss_init_setup_t *setup)
{
    uint                  port_on_chip;
    ulong                 value;
#if defined(VTSS_CHIPS)
    uint                  iport;
    vtss_chip_no_t        chip_no;
    vtss_iport_setup_t    *iport_setup;
    ulong                 mask;

    /* Initialize both internal chips */
    for (chip_no=VTSS_CHIP_NO_START; chip_no<VTSS_CHIP_NO_END; chip_no++) {
        VTSS_D(("chip_no: %d",chip_no));
        vtss_io_select_chip(&vtss_state->io[chip_no]);
#else
        VTSS_D(("enter"));
#endif /* VTSS_CHIPS */
        
        /* I/O Layer */
        vtss_io_init();

        if (setup->reset_chip) {

            /* Chip reset */
            GW_WR(CPU_CCA,SOFT_RESET_CTRL,0,
                  (1<<O_CPU_CCA_SOFT_RESET_CTRL_GLOBAL_RESET0) |
                  (1<<O_CPU_CCA_SOFT_RESET_CTRL_GLOBAL_RESET1));
            
            /* Soft reset takes 7 clock cycles of 6.4 nsec, 
               so waiting 100 nsec should be sufficient */
            VTSS_NSLEEP(100);

            /* Check CPU interface. */
            GW_RD(CPU_CCA,CHIP_JTAG_ID,0,&value);
            if (value==0x00000000 || value==0xFFFFFFFF) {
                return VTSS_DATA_NOT_READY;
            }

#if defined(VTSS_CHIPS)
            if (chip_no == VTSS_CHIP_NO_START) {
#endif /* VTSS_CHIPS */
                /* Detect chip revision. Gatwick-Ie revision A and Gatwick 
                   returns the same revision, so we use a hack to be able to
                   support Gatwick-Ie revision A:
                   For Gatwick, only to 20 LSB of the register below are valid */
                GW_WR(AN_RL_L3,RL_CUSTOM_REDIR_CTRL,0,0xffffffff); 
                GW_RD(AN_RL_L3,RL_CUSTOM_REDIR_CTRL,0,&value); 
                GW_WR(AN_RL_L3,RL_CUSTOM_REDIR_CTRL,0,0); 
                vtss_api_state->gw1e = (value == 0x000fffff ? 0 : 1); 
                if (!vtss_api_state->gw1e) {
                    vtss_api_state->pgid_end = VTSS_PGID_END_GW;
                    vtss_api_state->mac_addrs = VTSS_MAC_ADDRS_GW;
                    vtss_api_state->msti_end = (VTSS_MSTI_START+VTSS_MSTIS_GW);
#if defined(VTSS_CHIPS) && defined(VTSS_FEATURE_LAYER3)
                    /* Only 8 Router Legs for GATWICK48 */
                    vtss_api_state->rlid_end = (VTSS_RLID_START+VTSS_RLIDS_GW);
#endif /* VTSS_CHIPS && VTSS_FEATURE_LAYER3 */
                }
#if defined(VTSS_CHIPS)
            }
#endif /* VTSS_CHIPS */
            
            /* Arbiter */
            GW_WR(AR,CONG_MODE_CFG,0,0<<O_AR_CONG_MODE_CFG_CONG_SUSPEND);
            if (vtss_api_state->gw1e)
                GW_WR(AR,PATCH_CFG,0,
                      (1<<O_AR_PATCH_CFG_SUB_PORT_ARB_REV_A_ENA) |
                      (0<<O_AR_PATCH_CFG_DROP_ON_RX_CONG) |
                      (1<<O_AR_PATCH_CFG_NO_ZERO_DEST_RATE_INC) |
                      (1<<O_AR_PATCH_CFG_ZERO_DEST_LAST_ENA));
            
            /* Port */
            VTSS_RC(gw_pmap_table_init());

            for (port_on_chip=0; port_on_chip<VTSS_CHIP_PORTS; port_on_chip++) {
                /* Skip unused ports */
                if ((port_on_chip % 4)!=0 && VTSS_PORT_IS_10G(port_on_chip))
                    continue;

                /* Disable RXP counting of drops signalled from MAC and MAC control frames. */
                GW_WR(RXP,DROP_MASK_CFG,port_on_chip,
                      (1<<O_RXP_DROP_MASK_CFG_DROP_MASK_FCS) |
                      (1<<O_RXP_DROP_MASK_CFG_DROP_MASK_MAC_CTRL));

                /* Enable IP and frame ageing in the Rx path */
                value = ((1<<O_RXP_SWITCH_MODE_CFG_AGE_ENA) |
                         (1<<O_RXP_SWITCH_MODE_CFG_ANAREQ_IPVALID_SEL) |
                         (1<<O_RXP_SWITCH_MODE_CFG_IP_ENA) |
                         (0<<O_RXP_SWITCH_MODE_CFG_MAC_CTRL_ENA));
                if (vtss_api_state->gw1e)
                    value |= (1<<O_RXP_SWITCH_MODE_CFG_SMAC_ZERO_ENA);
                GW_WR(RXP,SWITCH_MODE_CFG,port_on_chip,value);
            }

            /* Initialize time stamp to 1718 msec */
            GW_WR(CPU_CCA,TSTAMP_CFG,0,
                  (5<<O_CPU_CCA_TSTAMP_CFG_TSTAMP_MODE) |
                  (1<<O_CPU_CCA_TSTAMP_CFG_SET_LFSR));
            
            /* Packet */
            VTSS_RC(gw_frame_rx_init());
#if VTSS_OPT_DMA
            if (!setup->use_cpu_si) {
                VTSS_D(("Autoselect for chip %d", chip_no));
                GW_PI_WR(CPU_PQS,DMA_CFG,
                         (1 << O_CPU_PQS_DMA_CFG_REQ_ENA) |
                         (1 << O_CPU_PQS_DMA_CFG_ACK_ENA) |
                         (1 << O_CPU_PQS_DMA_CFG_EOT_ENA) |
                         (0 << O_CPU_PQS_DMA_CFG_REQ_POL) |
                         (0 << O_CPU_PQS_DMA_CFG_ACK_POL) |
                         (0 << O_CPU_PQS_DMA_CFG_EOT_POL) |
                         (1 << O_CPU_PQS_DMA_CFG_AUTO_SEL_ENA) |
                         (0 << O_CPU_PQS_DMA_CFG_AUTO_REQ_DIS_ENA) |
                         (0 << O_CPU_PQS_DMA_CFG_REQ_TOGGLE_CC));
                GW_PI_WR(CPU_PQS,DMA_MASK,M_CPU_PQS_DMA_MASK_MASK << O_CPU_PQS_DMA_MASK_MASK);
                VTSS_RC(vtss_io_dma_init());
            }
#endif /* VTSS_OPT_DMA */
            
            /* Layer 2 */
            VTSS_RC(gw_cpid_table_init());
#if defined(VTSS_CHIPS)
            if (vtss_api_state->gw1e)
                VTSS_RC(gw_glag_table_init());
#endif /* VTSS_CHIPS */
            VTSS_RC(gw_src_table_init());
            VTSS_RC(gw_pgid_table_init());
            VTSS_RC(gw_aggr_table_init());
            VTSS_RC(gw_vlan_table_init());
            VTSS_RC(gw_mstp_table_init());
            VTSS_RC(gw_mac_table_init());

            /* Layer 3 */
            VTSS_RC(gw_irlid_table_init());
#ifdef VTSS_FEATURE_LAYER3
            VTSS_RC(gw_erlid_table_init());
            VTSS_RC(gw_uc_table_init());
            VTSS_RC(gw_arp_table_init());
            VTSS_RC(gw_sec_table_init());
#endif /* VTSS_FEATURE_LAYER3 */
        }
#if defined(VTSS_CHIPS)
        /* Build internal port setup */
        for (iport = 2*chip_no; iport < (2*chip_no+2); iport++) {
            
            iport_setup = &vtss_api_state->iport_setup[iport];
            
            iport_setup->chip_port = ((iport & 1) ? 4 : 0);
            
            iport_setup->swap_rx_pins = 0;
            iport_setup->swap_tx_pins = 0;
#if defined(BOARD_JETWAY48)
            /* Tx pins are swapped for the first 10G port */
            iport_setup->swap_tx_pins = (iport_setup->chip_port == 0 ? 1 : 0);
            iport_setup->miim_controller = VTSS_MIIM_CONTROLLER_2;
            iport_setup->phy_addr = (iport_setup->chip_port == 0 ? 0 : 1);
#endif            
        }
        iport = 2*chip_no;

        /* Setup first and last internal port */
#if defined(VSC7280_REV_A)
        vtss_api_state->iport_first[chip_no] = (iport+1);
#else
        vtss_api_state->iport_first[chip_no] = (iport);
#endif
        vtss_api_state->iport_last[chip_no] = (iport+1);

        VTSS_D(("chip_no: %d, first port: %d, last port: %d",
                chip_no,
                vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port,
                vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port));
    
        /* Calculate mask of internal ports */
        mask = ((1<<vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port) |
                (1<<vtss_api_state->iport_setup[vtss_api_state->iport_last[chip_no]].chip_port));

        /* Setup internal ports */
        for (iport = vtss_api_state->iport_first[chip_no]; 
             iport <= vtss_api_state->iport_last[chip_no] && setup->reset_chip; 
             iport++) {
            ulong                 smask;
            vtss_vlan_port_mode_t vlan_mode;
            
            iport_setup = &vtss_api_state->iport_setup[iport];

#if defined(BOARD_JETWAY48)
            {
                long data;
                uint mii, phy, mmd;
                ushort value,mask;

                mii = iport_setup->miim_controller;
                phy = iport_setup->phy_addr;
                mmd = VTSS_MMD_DTE_XS;
                
                /* Reset VSC 7280 */
                gw_mmd_write_masked(mii, phy, mmd, MMD_CTRL_1, MMD_CTRL_1_RESET, MMD_CTRL_1_RESET);
                while ((data = vtss_ll_mmd_read(mii, phy, mmd, MMD_CTRL_1))>=0 &&
                       (data & MMD_CTRL_1_RESET))
                    ;
                
                /* Reset 10G module via VSC7280 vendor specific register 0x8007 */
                vtss_ll_mmd_write(mii, phy, mmd, 0x8007, 1<<8);
                vtss_ll_mmd_write(mii, phy, mmd, 0x8007, 0<<8);

                /* Enable equalization and half swing */
                mask = (1<<15 | 1<<14 | 1<<13 | 1<<12 | 1<<11);
                value = mask;
                gw_mmd_write_masked(mii, phy, mmd, 0xc06b, value, mask);
                gw_mmd_write_masked(mii, phy, mmd, 0xc071, value, mask);
                gw_mmd_write_masked(mii, phy, mmd, 0xc077, value, mask);
                gw_mmd_write_masked(mii, phy, mmd, 0xc07d, value, mask);
            }
#endif /* BOARD_JETWAY48 */
            
            /* Logical port mapping: Map to first internal port */
            VTSS_RC(gw_pmap_table_write(iport_setup->chip_port,vtss_api_state->iport_setup[vtss_api_state->iport_first[chip_no]].chip_port,0));
            
            /* Source masks: Exclude internal ports */
            VTSS_RC(gw_src_table_write(iport_setup->chip_port,~mask));
            
            smask=0;
            if (iport==vtss_api_state->iport_first[chip_no]) {
                /* Port 8-19 send to the first internal port */
                smask|=0x000fff00;
            } 
            if (iport==vtss_api_state->iport_last[chip_no]) {
                /* Port 20-31 send to the last internal port */
                smask|=0xfff00000;
            }
            GW_WR(TXP,QS_LINKAGGR_CFG,iport_setup->chip_port,smask | (1<<PORT_ON_CHIP_RESV));

            /* Destination masks: Include internal ports */
            VTSS_RC(gw_pgid_table_write(iport_setup->chip_port,mask,0));

            /* VLAN mode unaware by default */
            vlan_mode.aware = 0;
            vlan_mode.pvid = VTSS_VID_DEFAULT;
            vlan_mode.frame_type = VTSS_VLAN_FRAME_ALL;
            vlan_mode.untagged_vid = VTSS_VID_DEFAULT;
            vlan_mode.ingress_filter = 0;
            VTSS_RC(gw_vlan_port_mode_set(iport_setup->chip_port,&vlan_mode));
            
            /* QoS mode */
            VTSS_RC(gw_port_qos_setup_internal(iport_setup->chip_port));

            if (vtss_api_state->gw1e) {
                /* Stacking setup */
                GW_WR(RXP,STACKING_TAG_CFG,iport_setup->chip_port,
                      (1<<O_RXP_STACKING_TAG_CFG_STACKING_PORT_ENA) |
                      (1<<O_RXP_STACKING_TAG_CFG_NO_STACKING_TAG) |
                      (1<<O_RXP_STACKING_TAG_CFG_ST_VERSION_UNKNOWN) |
                      (1<<O_RXP_STACKING_TAG_CFG_CONF_ST_REDIR_ENA) |
                      (0<<O_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_0) |
                      (1<<O_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_1));
                GW_WR(RXP,ST_PRIO_REMAP_CFG,iport_setup->chip_port,
                      (0<<O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_0) |
                      (1<<O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_1) |
                      (2<<O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_2) |
                      (3<<O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_3));
                GW_WR(TXP,STACKING_TAG_CFG,iport_setup->chip_port,
                      (1<<O_TXP_STACKING_TAG_CFG_STACKING_PORT_ENA) |
                      (0<<O_TXP_STACKING_TAG_CFG_ST_DP_REMAP_0) |
                      (1<<O_TXP_STACKING_TAG_CFG_ST_DP_REMAP_1) |
                      (0<<O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_0) |
                      (1<<O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_1) |
                      (2<<O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_2) |
                      (3<<O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_3));
            }
        } /* Internal port loop */

        /* CPID mask: Include internal ports for learn queue */
        VTSS_RC(gw_cpid_table_write(GW_LEARN_QUEUE-VTSS_CPU_RX_QUEUE_START,mask));

        /* Enable CPU learning */
        GW_WR(AN_L2_PS,L2_MAIN_CFG,0,
              (1<<O_AN_L2_PS_L2_MAIN_CFG_L2_FORW_ENA) | 
              (0<<O_AN_L2_PS_L2_MAIN_CFG_FORW_CPU_COPY_QUEUE) |
              (1<<O_AN_L2_PS_L2_MAIN_CFG_L2_LEARN_ENA) |
              (1<<O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_ENA) |
              ((GW_LEARN_QUEUE-VTSS_CPU_RX_QUEUE_START)<<O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE) |
              (0<<O_AN_L2_PS_L2_MAIN_CFG_LEARN_DROP));
    } /* Chip loop */

    /* Setup 10G ports */
    VTSS_RC(gw_port_setup_internal(1));
                
#endif /* VTSS_CHIPS */
    
    /* Setup learn state */
    vtss_api_state->learn_auto = 1;
    vtss_api_state->learn_queue = VTSS_CPU_RX_QUEUE_START;

    return VTSS_OK;
}
