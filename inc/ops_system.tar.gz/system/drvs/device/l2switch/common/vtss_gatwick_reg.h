/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_gatwick_reg.h,v 1.30 2007/05/15 12:52:36 cpj Exp $
 $Revision: 1.30 $

*/

/* Port map table commands */
#define PORT_CMD_IDLE  0
#define PORT_CMD_CLEAR 1
#define PORT_CMD_READ  2
#define PORT_CMD_WRITE 3

/* IRLID table commands */
#define RL_CMD_IDLE  0
#define RL_CMD_CLEAR 1
#define RL_CMD_READ  2
#define RL_CMD_WRITE 3

/* ERLID table commands */
#define ERLID_CMD_IDLE  0
#define ERLID_CMD_CLEAR 1
#define ERLID_CMD_READ  2
#define ERLID_CMD_WRITE 3

/* MSTP table commands */
#define MSTP_CMD_IDLE  0
#define MSTP_CMD_CLEAR 1
#define MSTP_CMD_READ  2
#define MSTP_CMD_WRITE 3

/* VLAN table commands */
#define VLAN_CMD_IDLE  0
#define VLAN_CMD_CLEAR 1
#define VLAN_CMD_READ  2
#define VLAN_CMD_WRITE 3

/* PGID table commands */
#define PGID_CMD_IDLE  0
#define PGID_CMD_CLEAR 1
#define PGID_CMD_READ  2
#define PGID_CMD_WRITE 3

/* CAM table commands */
#define CAM_CMD_IDLE  0
#define CAM_CMD_CLEAR 1
#define CAM_CMD_READ  2
#define CAM_CMD_WRITE 3

/* IP table commands */
#define IP_CMD_IDLE       0
#define IP_CMD_LEARN_MC   1
#define IP_CMD_UNLEARN_MC 2
#define IP_CMD_READ_MC    3
#define IP_CMD_WRITE_MC   4
#define IP_CMD_CLEAR      5
#define IP_CMD_READ_UC    6
#define IP_CMD_WRITE_UC   7

/* Security table commands */
#define SEC_CMD_IDLE  0
#define SEC_CMD_CLEAR 1
#define SEC_CMD_READ  2
#define SEC_CMD_WRITE 3

/* IRLID counter commands */
#define IRLID_CNT_CMD_IDLE       0
#define IRLID_CNT_CMD_CLEAR_ALL  1
#define IRLID_CNT_CMD_READ       2
#define IRLID_CNT_CMD_READ_CLEAR 3
#define IRLID_CNT_CMD_CLEAR_ONE  4

/* ERLID counter commands */
#define ERLID_CNT_CMD_IDLE       0
#define ERLID_CNT_CMD_CLEAR_ALL  1
#define ERLID_CNT_CMD_READ       2
#define ERLID_CNT_CMD_READ_CLEAR 3
#define ERLID_CNT_CMD_CLEAR_ONE  4

/* MAC address table commands */
#define MAC_CMD_IDLE    0
#define MAC_CMD_LEARN   1
#define MAC_CMD_UNLEARN 2
#define MAC_CMD_AGE     3
#define MAC_CMD_LOOKUP  4
#define MAC_CMD_CLEAR   5
#define MAC_CMD_READ    6
#define MAC_CMD_WRITE   7

/* Gatwick-Ie only: GLAG table commands */
#define GLAG_CMD_IDLE  0 
#define GLAG_CMD_CLEAR 1 
#define GLAG_CMD_READ  2 
#define GLAG_CMD_WRITE 3

/* SRC table commands */
#define SRC_CMD_IDLE  0
#define SRC_CMD_CLEAR 1
#define SRC_CMD_READ  2
#define SRC_CMD_WRITE 3

/* AGGR table commands */
#define AGGR_CMD_IDLE  0
#define AGGR_CMD_CLEAR 1
#define AGGR_CMD_READ  2
#define AGGR_CMD_WRITE 3

/* CPID table commands */
#define CPID_CMD_IDLE  0
#define CPID_CMD_CLEAR 1
#define CPID_CMD_READ  2
#define CPID_CMD_WRITE 3

/* PHY commands */
#define PHY_CMD_ADDRESS  0 /* 10G only */
#define PHY_CMD_WRITE    1 
#define PHY_CMD_READ_INC 2 /* NB: READ for 1G */
#define PHY_CMD_READ     3 /* 10G only */

/* Internal frame header words IFH0/IFH1 field offset and mask */
#define O_IFH0_PRIO    30
#define M_IFH0_PRIO    0x3
#define O_IFH0_CPUQ    26
#define M_IFH0_CPUQ    0xf
#define O_IFH0_LENGTH  19
#define M_IFH0_LENGTH  0x7f
#define O_IFH0_BYTES   12     
#define M_IFH0_BYTES   0x7f
#define O_IFH0_AGE     11
#define M_IFH0_AGE     0x1
#define O_IFH0_TIME    4
#define M_IFH0_TIME    0x3f
#define O_IFH0_UPRIO   1
#define M_IFH0_UPRIO   0x7
#define O_IFH0_CFI     0
#define M_IFH0_CFI     0x1

#define O_IFH1_VID     20
#define M_IFH1_VID     0xfff
#define O_IFH1_WASTAG  19
#define M_IFH1_WASTAG  0x1
#define O_IFH1_VIDENA  18
#define M_IFH1_VIDENA  0x1
#define O_IFH1_ERLGID  13
#define M_IFH1_ERLGID  0x1f
#define O_IFH1_PORTNO  8
#define M_IFH1_PORTNO  0x1f
#define O_IFH1_RESV1   7
#define M_IFH1_RESV1   0x1
#define O_IFH1_UPDFCS  6
#define M_IFH1_UPDFCS  0x1
#define O_IFH1_ADDFCS  5
#define M_IFH1_ADDFCS  0x1
#define O_IFH1_DONTTCH 4
#define M_IFH1_DONTTCH 0x1
#define O_IFH1_RESV    0
#define M_IFH1_RESV    0xf

/* Target/register macro */
#define TR(tgt,reg) T_##tgt,R_##tgt##_##reg

/* Target/register/offset/mask macro */
#define TROM(tgt,reg,fld) \
T_##tgt,R_##tgt##_##reg,O_##tgt##_##reg##_##fld,M_##tgt##_##reg##_##fld

/* Target/register/field value macro */
#define TRF(value,tgt,reg,fld) \
((value>>O_##tgt##_##reg##_##fld) & M_##tgt##_##reg##_##fld)

/****************************************************************************
 *** Automatically generated from ERF files, except for regdoc/fielddoc *****
 ****************************************************************************/

/* Gatwick register definitions based on ERF files tagged 'Rel_Gatwick_1_16_JRH' */

/* PI block IDs */
#define T_CPU_PMB 0x00
#define T_CPU_PIA 0x01
#define T_CPU_PQS 0x02

/* PI block T_CPU_PMB registers */
#define R_CPU_PMB_INT_STATUS         0x00
#define R_CPU_PMB_INT_MASK           0x01
#define R_CPU_PMB_INT_MASK_SET       0x02
#define R_CPU_PMB_INT_MASK_CLR       0x03
#define R_CPU_PMB_INT_IDENT          0x04
#define R_CPU_PMB_INT_RETRIGGER_CTRL 0x05
#define R_CPU_PMB_POLARITY_CFG       0x06
#define R_CPU_PMB_CHIP_JTAG_ID       0x07
#define R_CPU_PMB_ILLGL_BLK_ACC_CNT  0x08
#define R_CPU_PMB_TOTAL_READ_CNT     0x09
#define R_CPU_PMB_TOTAL_WRITE_CNT    0x0a

/* PI block T_CPU_PIA registers */
#define R_CPU_PIA_INT_STATUS        0x00
#define R_CPU_PIA_INT_MASK          0x01
#define R_CPU_PIA_INT_MASK_SET      0x02
#define R_CPU_PIA_INT_MASK_CLR      0x03
#define R_CPU_PIA_INT_IDENT         0x04
#define R_CPU_PIA_ADDR_REQ          0x05
#define R_CPU_PIA_DATA_REQ          0x06
#define R_CPU_PIA_ADDR_REPLY        0x07
#define R_CPU_PIA_DATA_REPLY        0x08
#define R_CPU_PIA_STATUS            0x09
#define R_CPU_PIA_CFG               0x0a
#define R_CPU_PIA_CTRL              0x0b
#define R_CPU_PIA_ERR               0x0c
#define R_CPU_PIA_ILLGL_BLK_ACC_CNT 0x0d

/* PI block T_CPU_PQS registers */
#define R_CPU_PQS_INT_STATUS        0x00
#define R_CPU_PQS_INT_MASK          0x01
#define R_CPU_PQS_INT_MASK_SET      0x02
#define R_CPU_PQS_INT_MASK_CLEAR    0x03
#define R_CPU_PQS_INT_IDENT         0x04
#define R_CPU_PQS_FRAME_STATUS      0x07
#define R_CPU_PQS_DATA              0x08
#define R_CPU_PQS_QUEUE_SEL         0x09
#define R_CPU_PQS_ERR               0x0a
#define R_CPU_PQS_STICKY_ERR        0x0b
#define R_CPU_PQS_STICKY_ERR_SHADOW 0x0c
#define R_CPU_PQS_DMA_CFG           0x0d /* Gatwick-Ie only */
#define R_CPU_PQS_DMA_MASK          0x0e /* Gatwick-Ie only */
#define R_CPU_PQS_DMA_CTRL          0x0f /* Gatwick-Ie only */

/* PI register R_CPU_PMB_INT_STATUS fields */
#define O_CPU_PMB_INT_STATUS_PMB_IS 0
#define M_CPU_PMB_INT_STATUS_PMB_IS 0x1
#define O_CPU_PMB_INT_STATUS_PIA_IS 1
#define M_CPU_PMB_INT_STATUS_PIA_IS 0x1
#define O_CPU_PMB_INT_STATUS_PQS_IS 2
#define M_CPU_PMB_INT_STATUS_PQS_IS 0x1

/* PI register R_CPU_PMB_INT_MASK fields */
#define O_CPU_PMB_INT_MASK_PMB_IM 0
#define M_CPU_PMB_INT_MASK_PMB_IM 0x1
#define O_CPU_PMB_INT_MASK_PIA_IM 1
#define M_CPU_PMB_INT_MASK_PIA_IM 0x1
#define O_CPU_PMB_INT_MASK_PQS_IM 2
#define M_CPU_PMB_INT_MASK_PQS_IM 0x1

/* PI register R_CPU_PMB_INT_MASK_SET fields */
#define O_CPU_PMB_INT_MASK_SET_PMB_IMS 0
#define M_CPU_PMB_INT_MASK_SET_PMB_IMS 0x1
#define O_CPU_PMB_INT_MASK_SET_PIA_IMS 1
#define M_CPU_PMB_INT_MASK_SET_PIA_IMS 0x1
#define O_CPU_PMB_INT_MASK_SET_PQS_IMS 2
#define M_CPU_PMB_INT_MASK_SET_PQS_IMS 0x1

/* PI register R_CPU_PMB_INT_MASK_CLR fields */
#define O_CPU_PMB_INT_MASK_CLR_PMB_IMC 0
#define M_CPU_PMB_INT_MASK_CLR_PMB_IMC 0x1
#define O_CPU_PMB_INT_MASK_CLR_PIA_IMC 1
#define M_CPU_PMB_INT_MASK_CLR_PIA_IMC 0x1
#define O_CPU_PMB_INT_MASK_CLR_PQS_IMC 2
#define M_CPU_PMB_INT_MASK_CLR_PQS_IMC 0x1

/* PI register R_CPU_PMB_INT_IDENT fields */
#define O_CPU_PMB_INT_IDENT_PMB_II 0
#define M_CPU_PMB_INT_IDENT_PMB_II 0x1
#define O_CPU_PMB_INT_IDENT_PIA_II 1
#define M_CPU_PMB_INT_IDENT_PIA_II 0x1
#define O_CPU_PMB_INT_IDENT_PQS_II 2
#define M_CPU_PMB_INT_IDENT_PQS_II 0x1

/* PI register R_CPU_PMB_INT_RETRIGGER_CTRL fields */
#define O_CPU_PMB_INT_RETRIGGER_CTRL_TIME_INACTIVE 0
#define M_CPU_PMB_INT_RETRIGGER_CTRL_TIME_INACTIVE 0xf

/* PI register R_CPU_PMB_POLARITY_CFG fields */
#define O_CPU_PMB_POLARITY_CFG_INT_REQ_POL 0
#define M_CPU_PMB_POLARITY_CFG_INT_REQ_POL 0x1

/* PI register R_CPU_PMB_CHIP_JTAG_ID fields */
#define O_CPU_PMB_CHIP_JTAG_ID_ALWAYS_ONE      0
#define M_CPU_PMB_CHIP_JTAG_ID_ALWAYS_ONE      0x1
#define O_CPU_PMB_CHIP_JTAG_ID_MANUFACTURER_ID 1
#define M_CPU_PMB_CHIP_JTAG_ID_MANUFACTURER_ID 0x7ff
#define O_CPU_PMB_CHIP_JTAG_ID_PART_NUMBER     12
#define M_CPU_PMB_CHIP_JTAG_ID_PART_NUMBER     0xffff
#define O_CPU_PMB_CHIP_JTAG_ID_REVISION_ID     28
#define M_CPU_PMB_CHIP_JTAG_ID_REVISION_ID     0xf

/* PI register R_CPU_PMB_ILLGL_BLK_ACC_CNT fields */
#define O_CPU_PMB_ILLGL_BLK_ACC_CNT_ILLGL_ACCESS_COUNT 0
#define M_CPU_PMB_ILLGL_BLK_ACC_CNT_ILLGL_ACCESS_COUNT 0xff

/* PI register R_CPU_PMB_TOTAL_READ_CNT fields */
#define O_CPU_PMB_TOTAL_READ_CNT_RD_COUNT 0
#define M_CPU_PMB_TOTAL_READ_CNT_RD_COUNT 0xffff

/* PI register R_CPU_PMB_TOTAL_WRITE_CNT fields */
#define O_CPU_PMB_TOTAL_WRITE_CNT_WR_COUNT 0
#define M_CPU_PMB_TOTAL_WRITE_CNT_WR_COUNT 0xffff

/* PI register R_CPU_PIA_INT_STATUS fields */
#define O_CPU_PIA_INT_STATUS_REPLY_IS   0
#define M_CPU_PIA_INT_STATUS_REPLY_IS   0x1
#define O_CPU_PIA_INT_STATUS_REQUEST_IS 1
#define M_CPU_PIA_INT_STATUS_REQUEST_IS 0x1

/* PI register R_CPU_PIA_INT_MASK fields */
#define O_CPU_PIA_INT_MASK_REPLY_IM   0
#define M_CPU_PIA_INT_MASK_REPLY_IM   0x1
#define O_CPU_PIA_INT_MASK_REQUEST_IM 1
#define M_CPU_PIA_INT_MASK_REQUEST_IM 0x1

/* PI register R_CPU_PIA_INT_MASK_SET fields */
#define O_CPU_PIA_INT_MASK_SET_REPLY_IMS   0
#define M_CPU_PIA_INT_MASK_SET_REPLY_IMS   0x1
#define O_CPU_PIA_INT_MASK_SET_REQUEST_IMS 1
#define M_CPU_PIA_INT_MASK_SET_REQUEST_IMS 0x1

/* PI register R_CPU_PIA_INT_MASK_CLR fields */
#define O_CPU_PIA_INT_MASK_CLR_REPLY_IMC   0
#define M_CPU_PIA_INT_MASK_CLR_REPLY_IMC   0x1
#define O_CPU_PIA_INT_MASK_CLR_REQUEST_IMC 1
#define M_CPU_PIA_INT_MASK_CLR_REQUEST_IMC 0x1

/* PI register R_CPU_PIA_INT_IDENT fields */
#define O_CPU_PIA_INT_IDENT_REPLY_II   0
#define M_CPU_PIA_INT_IDENT_REPLY_II   0x1
#define O_CPU_PIA_INT_IDENT_REQUEST_II 1
#define M_CPU_PIA_INT_IDENT_REQUEST_II 0x1

/* PI register R_CPU_PIA_ADDR_REQ fields */
#define O_CPU_PIA_ADDR_REQ_REQ_TARGET_ADDRESS 0
#define M_CPU_PIA_ADDR_REQ_REQ_TARGET_ADDRESS 0xff
#define O_CPU_PIA_ADDR_REQ_REQ_TARGET_MODULE  8
#define M_CPU_PIA_ADDR_REQ_REQ_TARGET_MODULE  0xff
#define O_CPU_PIA_ADDR_REQ_REQ_WRITE_REQUEST  16
#define M_CPU_PIA_ADDR_REQ_REQ_WRITE_REQUEST  0x1
#define O_CPU_PIA_ADDR_REQ_REQ_STATUS         17
#define M_CPU_PIA_ADDR_REQ_REQ_STATUS         0x1

/* PI register R_CPU_PIA_DATA_REQ fields */
#define O_CPU_PIA_DATA_REQ_REQ_DATA 0
#define M_CPU_PIA_DATA_REQ_REQ_DATA 0xffffffff

/* PI register R_CPU_PIA_ADDR_REPLY fields */
#define O_CPU_PIA_ADDR_REPLY_REP_TARGET_ADDRESS 0
#define M_CPU_PIA_ADDR_REPLY_REP_TARGET_ADDRESS 0xff
#define O_CPU_PIA_ADDR_REPLY_REP_TARGET_MODULE  8
#define M_CPU_PIA_ADDR_REPLY_REP_TARGET_MODULE  0xff
#define O_CPU_PIA_ADDR_REPLY_REP_WRITE_REPLY    16
#define M_CPU_PIA_ADDR_REPLY_REP_WRITE_REPLY    0x1
#define O_CPU_PIA_ADDR_REPLY_REP_STATUS         17
#define M_CPU_PIA_ADDR_REPLY_REP_STATUS         0x1
#define O_CPU_PIA_ADDR_REPLY_REP_TGT_BUSY       18
#define M_CPU_PIA_ADDR_REPLY_REP_TGT_BUSY       0x1
#define O_CPU_PIA_ADDR_REPLY_REP_TGT_UNKNOWN    19
#define M_CPU_PIA_ADDR_REPLY_REP_TGT_UNKNOWN    0x1
#define O_CPU_PIA_ADDR_REPLY_REP_VALID          31
#define M_CPU_PIA_ADDR_REPLY_REP_VALID          0x1

/* PI register R_CPU_PIA_DATA_REPLY fields */
#define O_CPU_PIA_DATA_REPLY_REP_DATA 0
#define M_CPU_PIA_DATA_REPLY_REP_DATA 0xffffffff

/* PI register R_CPU_PIA_STATUS fields */
#define O_CPU_PIA_STATUS_REPLY_FILL_LEVEL    0
#define M_CPU_PIA_STATUS_REPLY_FILL_LEVEL    0x1f
#define O_CPU_PIA_STATUS_REQUEST_EMPTY_LEVEL 8
#define M_CPU_PIA_STATUS_REQUEST_EMPTY_LEVEL 0xf

/* PI register R_CPU_PIA_CFG fields */
#define O_CPU_PIA_CFG_REPLY_TIMEOUT     0
#define M_CPU_PIA_CFG_REPLY_TIMEOUT     0xff
#define O_CPU_PIA_CFG_REPLY_WATERMARK   8
#define M_CPU_PIA_CFG_REPLY_WATERMARK   0xf
#define O_CPU_PIA_CFG_REQUEST_WATERMARK 16
#define M_CPU_PIA_CFG_REQUEST_WATERMARK 0xf

/* PI register R_CPU_PIA_CTRL fields */
#define O_CPU_PIA_CTRL_REPLY_RESET 0
#define M_CPU_PIA_CTRL_REPLY_RESET 0x1

/* PI register R_CPU_PIA_ERR fields */
#define O_CPU_PIA_ERR_REPLY_EMPTY_ERR  0
#define M_CPU_PIA_ERR_REPLY_EMPTY_ERR  0x1
#define O_CPU_PIA_ERR_REQUEST_FULL_ERR 1
#define M_CPU_PIA_ERR_REQUEST_FULL_ERR 0x1

/* PI register R_CPU_PIA_ILLGL_BLK_ACC_CNT fields */
#define O_CPU_PIA_ILLGL_BLK_ACC_CNT_ILLGL_ACCESS_COUNT 0
#define M_CPU_PIA_ILLGL_BLK_ACC_CNT_ILLGL_ACCESS_COUNT 0xff

/* PI register R_CPU_PQS_INT_STATUS fields */
#define O_CPU_PQS_INT_STATUS_FPN_IS 0
#define M_CPU_PQS_INT_STATUS_FPN_IS 0xffff
#define O_CPU_PQS_INT_STATUS_DR_IS  17
#define M_CPU_PQS_INT_STATUS_DR_IS  0x1

/* PI register R_CPU_PQS_INT_MASK fields */
#define O_CPU_PQS_INT_MASK_FPN_IM 0
#define M_CPU_PQS_INT_MASK_FPN_IM 0xffff
#define O_CPU_PQS_INT_MASK_DR_IM  17
#define M_CPU_PQS_INT_MASK_DR_IM  0x1

/* PI register R_CPU_PQS_INT_MASK_SET fields */
#define O_CPU_PQS_INT_MASK_SET_FPN_IMS 0
#define M_CPU_PQS_INT_MASK_SET_FPN_IMS 0xffff
#define O_CPU_PQS_INT_MASK_SET_DR_IMS  17
#define M_CPU_PQS_INT_MASK_SET_DR_IMS  0x1

/* PI register R_CPU_PQS_INT_MASK_CLEAR fields */
#define O_CPU_PQS_INT_MASK_CLEAR_FPN_IMC 0
#define M_CPU_PQS_INT_MASK_CLEAR_FPN_IMC 0xffff
#define O_CPU_PQS_INT_MASK_CLEAR_DR_IMC  17
#define M_CPU_PQS_INT_MASK_CLEAR_DR_IMC  0x1

/* PI register R_CPU_PQS_INT_IDENT fields */
#define O_CPU_PQS_INT_IDENT_FPN_II 0
#define M_CPU_PQS_INT_IDENT_FPN_II 0xffff
#define O_CPU_PQS_INT_IDENT_DR_II  17
#define M_CPU_PQS_INT_IDENT_DR_II  0x1

/* PI register R_CPU_PQS_FRAME_STATUS fields */
#define O_CPU_PQS_FRAME_STATUS_LAST  23
#define M_CPU_PQS_FRAME_STATUS_LAST  0x7
#define O_CPU_PQS_FRAME_STATUS_FQ    26
#define M_CPU_PQS_FRAME_STATUS_FQ    0xf
#define O_CPU_PQS_FRAME_STATUS_VALID 31
#define M_CPU_PQS_FRAME_STATUS_VALID 0x1

/* PI register R_CPU_PQS_DATA fields */
#define O_CPU_PQS_DATA_FD 0
#define M_CPU_PQS_DATA_FD 0xffffffff

/* PI register R_CPU_PQS_QUEUE_SEL fields */
#define O_CPU_PQS_QUEUE_SEL_FQN 0
#define M_CPU_PQS_QUEUE_SEL_FQN 0xffff

/* PI register R_CPU_PQS_ERR fields */
#define O_CPU_PQS_ERR_NFE 1
#define M_CPU_PQS_ERR_NFE 0x1
#define O_CPU_PQS_ERR_BE  2
#define M_CPU_PQS_ERR_BE  0x1
#define O_CPU_PQS_ERR_FDE 3
#define M_CPU_PQS_ERR_FDE 0x1

/* PI register R_CPU_PQS_STICKY_ERR fields */
#define O_CPU_PQS_STICKY_ERR_NFE_STICKY 1
#define M_CPU_PQS_STICKY_ERR_NFE_STICKY 0x1
#define O_CPU_PQS_STICKY_ERR_BE_STICKY  2
#define M_CPU_PQS_STICKY_ERR_BE_STICKY  0x1
#define O_CPU_PQS_STICKY_ERR_FDE_STICKY 3
#define M_CPU_PQS_STICKY_ERR_FDE_STICKY 0x1

/* PI register R_CPU_PQS_STICKY_ERR_SHADOW fields */
#define O_CPU_PQS_STICKY_ERR_SHADOW_NFE_SHADOW 1
#define M_CPU_PQS_STICKY_ERR_SHADOW_NFE_SHADOW 0x1
#define O_CPU_PQS_STICKY_ERR_SHADOW_BE_SHADOW  2
#define M_CPU_PQS_STICKY_ERR_SHADOW_BE_SHADOW  0x1
#define O_CPU_PQS_STICKY_ERR_SHADOW_FDE_SHADOW 3
#define M_CPU_PQS_STICKY_ERR_SHADOW_FDE_SHADOW 0x1

/* PI register R_CPU_PQS_DMA_CFG fields */
#define O_CPU_PQS_DMA_CFG_REQ_ENA          0   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_REQ_ENA          0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_ACK_ENA          1   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_ACK_ENA          0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_EOT_ENA          2   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_EOT_ENA          0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_REQ_POL          3   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_REQ_POL          0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_ACK_POL          4   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_ACK_POL          0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_EOT_POL          5   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_EOT_POL          0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_AUTO_SEL_ENA     6   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_AUTO_SEL_ENA     0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_AUTO_REQ_DIS_ENA 7   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_AUTO_REQ_DIS_ENA 0x1 /* Gatwick-Ie only */
#define O_CPU_PQS_DMA_CFG_REQ_TOGGLE_CC    8   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CFG_REQ_TOGGLE_CC    0x7 /* Gatwick-Ie only */

/* PI register R_CPU_PQS_DMA_MASK fields */
#define O_CPU_PQS_DMA_MASK_MASK 0      /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_MASK_MASK 0xffff /* Gatwick-Ie only */

/* PI register R_CPU_PQS_DMA_CTRL fields */
#define O_CPU_PQS_DMA_CTRL_REQ_ACTIVATE 1   /* Gatwick-Ie only */
#define M_CPU_PQS_DMA_CTRL_REQ_ACTIVATE 0x1 /* Gatwick-Ie only */

/* Target IDs */
#define T_CPU_CCA  0x01
#define T_CPU_GM   0x02
#define T_CPU_MWR  0x03
#define T_AR       0x08
#define T_AN_RL_L3 0x10
#define T_AN_L2_PS 0x11
#define T_RXP      0x20
#define T_TXP      0x21
#define T_D10_MAC  0x22
#define T_SE       0x23
#define T_D4_MAC   0x2a

/* Target T_CPU_CCA registers */
#define R_CPU_CCA_CHIP_JTAG_ID           0x00
#define R_CPU_CCA_BLADE_ID               0x01
#define R_CPU_CCA_SOFT_RESET_CTRL        0x02
#define R_CPU_CCA_TSTAMP_CFG             0x03
#define R_CPU_CCA_SI_CFG_0               0x0f
#define R_CPU_CCA_SI_CFG_1               0x18
#define R_CPU_CCA_QS_STATUS              0x20
#define R_CPU_CCA_QS_CTRL                0x25
#define R_CPU_CCA_QS_FRAME_STATUS        0x27
#define R_CPU_CCA_QS_DATA                0x28
#define R_CPU_CCA_QS_QUEUE_SEL           0x29
#define R_CPU_CCA_QS_ERR                 0x2a
#define R_CPU_CCA_QS_STICKY_ERR          0x2b
#define R_CPU_CCA_QS_STICKY_ERR_SHADOW   0x2c
#define R_CPU_CCA_QS_SEMAPHORE           0x2d
#define R_CPU_CCA_QS_TXQS_CFG0           0x30
#define R_CPU_CCA_QS_TXQS_CFG1           0x31
#define R_CPU_CCA_QS_DROP_CNT            0x32
#define R_CPU_CCA_QS_DROP_CNT_CFG        0x33
#define R_CPU_CCA_QS_TXQS_DROP_CFG0      0x40
#define R_CPU_CCA_QS_TXQS_DROP_CFG1      0x41
#define R_CPU_CCA_QS_TXQS_DROP_CFG2      0x42
#define R_CPU_CCA_QS_TXQS_DROP_CFG3      0x43
#define R_CPU_CCA_QS_TXQS_DROP_CFG4      0x44
#define R_CPU_CCA_QS_TXQS_DROP_CFG5      0x45
#define R_CPU_CCA_QS_TXQS_DROP_CFG6      0x46
#define R_CPU_CCA_QS_TXQS_DROP_CFG7      0x47
#define R_CPU_CCA_QS_TXQS_DROP_CFG8      0x48
#define R_CPU_CCA_QS_TXQS_DROP_CFG9      0x49
#define R_CPU_CCA_QS_TXQS_DROP_CFG10     0x4a
#define R_CPU_CCA_QS_TXQS_DROP_CFG11     0x4b
#define R_CPU_CCA_QS_TXQS_DROP_CFG12     0x4c
#define R_CPU_CCA_QS_TXQS_DROP_CFG13     0x4d
#define R_CPU_CCA_QS_TXQS_DROP_CFG14     0x4e
#define R_CPU_CCA_QS_TXQS_DROP_CFG15     0x4f
#define R_CPU_CCA_QS_LINK_INDEX          0x52
#define R_CPU_CCA_QS_LINK_DATA           0x53
#define R_CPU_CCA_QS_QUEUE_INDEX         0x54
#define R_CPU_CCA_QS_QUEUE_DATA0         0x55
#define R_CPU_CCA_QS_QUEUE_DATA1         0x56
#define R_CPU_CCA_QS_REPLAY_CFG          0x57
#define R_CPU_CCA_QS_RFS_CFG             0x58

/* Target T_CPU_GM registers */
#define R_CPU_GM_MII_STATUS_1G           0x00
#define R_CPU_GM_MII_COMMAND_1G          0x01
#define R_CPU_GM_MII_DATA_1G             0x02
#define R_CPU_GM_MII_CFG_1G              0x03
#define R_CPU_GM_MII_SCAN1_1G            0x04
#define R_CPU_GM_MII_SCAN2_1G            0x05
#define R_CPU_GM_MII_SCAN_RESULTS_1G     0x06
#define R_CPU_GM_MII_STATUS_10G_0        0x08
#define R_CPU_GM_MII_COMMAND_10G_0       0x09
#define R_CPU_GM_MII_DATA_10G_0          0x0a
#define R_CPU_GM_MII_CFG_10G_0           0x0b
#define R_CPU_GM_MII_SCAN1_10G_0         0x0c
#define R_CPU_GM_MII_SCAN2_10G_0         0x0d
#define R_CPU_GM_MII_SCAN_RESULTS_10G_0  0x0e
#define R_CPU_GM_MII_STATUS_10G_1        0x10
#define R_CPU_GM_MII_COMMAND_10G_1       0x11
#define R_CPU_GM_MII_DATA_10G_1          0x12
#define R_CPU_GM_MII_CFG_10G_1           0x13
#define R_CPU_GM_MII_SCAN1_10G_1         0x14
#define R_CPU_GM_MII_SCAN2_10G_1         0x15
#define R_CPU_GM_MII_SCAN_RESULTS_10G_1  0x16
#define R_CPU_GM_GPIO_DIRECTION          0x80
#define R_CPU_GM_GPIO_OUT                0x81
#define R_CPU_GM_GPIO_STATUS             0x82
#define R_CPU_GM_GPIO_IN                 0x83

/* Target T_CPU_MWR registers */
#define R_CPU_MWR_ACCESS      0x00
#define R_CPU_MWR_READ_RESULT 0x01

/* Target T_AR registers */
#define R_AR_LEAK_RATE_CFG_0    0x00
#define R_AR_LEAK_RATE_CFG_1    0x01
#define R_AR_LEAK_RATE_CFG_2    0x02
#define R_AR_LEAK_RATE_CFG_3    0x03
#define R_AR_LEAK_RATE_CFG_4    0x04
#define R_AR_LEAK_RATE_CFG_5    0x05
#define R_AR_LEAK_RATE_CFG_6    0x06
#define R_AR_LEAK_RATE_CFG_7    0x07
#define R_AR_CONG_MODE_CFG      0x08
#define R_AR_CONG_IGNORE_CFG    0x09
#define R_AR_RX_CONG_IGNORE_CFG 0x0a
#define R_AR_SRC_DISABLE_CFG    0x0b
#define R_AR_DEST_DISABLE_CFG   0x0c
#define R_AR_DEST_ACTIVE_STICKY 0x10
#define R_AR_SRC_ACTIVE_STICKY  0x11
#define R_AR_REQ_OVERFL_STICKY  0x12
#define R_AR_REQ_EMPTY_STICKY   0x13
#define R_AR_TX_CONG_STICKY     0x14 /* Gatwick-Ie only */
#define R_AR_RX_CONG_STICKY     0x15 /* Gatwick-Ie only */
#define R_AR_INTERVAL_CFG       0x16 /* Gatwick-Ie only */
#define R_AR_POLYNOM_CFG_0      0x17 /* Gatwick-Ie only */
#define R_AR_POLYNOM_CFG_1      0x18 /* Gatwick-Ie only */
#define R_AR_POLYNOM_CFG_2      0x19 /* Gatwick-Ie only */
#define R_AR_PATCH_CFG          0x1a /* Gatwick-Ie only */
#define R_AR_ZERO_DEST_CNT      0x20 /* Gatwick-Ie only */

/* Target T_AN_RL_L3 registers */
#define R_AN_RL_L3_RL_CTRL                       0x00
#define R_AN_RL_L3_RL_CFG_1                      0x01
#define R_AN_RL_L3_RL_CFG_2                      0x02
#define R_AN_RL_L3_RL_CFG_3                      0x03
#define R_AN_RL_L3_RL_PORT_MAP_CTRL              0x04
#define R_AN_RL_L3_RL_PORT_MAP_CFG               0x05
#define R_AN_RL_L3_RL_PROTO_CTRL                 0x06
#define R_AN_RL_L3_RL_CUSTOM_REDIR_CTRL          0x07
#define R_AN_RL_L3_RL_DMAC_PAT_LSB_CFG           0x08
#define R_AN_RL_L3_RL_DMAC_PAT_MSB_CFG           0x09
#define R_AN_RL_L3_RL_DMAC_MASK_LSB_CFG          0x0a
#define R_AN_RL_L3_RL_DMAC_MASK_MSB_CFG          0x0b
#define R_AN_RL_L3_RL_STICKY                     0x0c
#define R_AN_RL_L3_L3_COMMON_CFG                 0x0d
#define R_AN_RL_L3_L3_VLAN_CTRL                  0x0e
#define R_AN_RL_L3_L3_VLAN_CFG_1                 0x0f
#define R_AN_RL_L3_L3_VLAN_CFG_2                 0x10
#define R_AN_RL_L3_L3_MSTP_CTRL                  0x11
#define R_AN_RL_L3_L3_MSTP_CFG_1                 0x12
#define R_AN_RL_L3_L3_MSTP_CFG_2                 0x13
#define R_AN_RL_L3_L3_VLAN_FILT_CTRL             0x14
#define R_AN_RL_L3_L3_INGRESS_FILTER_DISCARD_CNT 0x15
#define R_AN_RL_L3_L3_CAM_CTRL                   0x16
#define R_AN_RL_L3_L3_CAM_CFG_1                  0x17
#define R_AN_RL_L3_L3_CAM_CFG_2                  0x18
#define R_AN_RL_L3_L3_IP_CTRL                    0x19
#define R_AN_RL_L3_L3_UC_CFG_1                   0x1a
#define R_AN_RL_L3_L3_UC_CFG_2                   0x1b
#define R_AN_RL_L3_L3_UC_CFG_3                   0x1c
#define R_AN_RL_L3_L3_MC_CFG_1                   0x1d
#define R_AN_RL_L3_L3_MC_CFG_2                   0x1e
#define R_AN_RL_L3_L3_MC_CFG_3                   0x1f
#define R_AN_RL_L3_L3_CPU_QUEUE_CFG              0x20
#define R_AN_RL_L3_L3_SECUR_CTRL                 0x21
#define R_AN_RL_L3_L3_SECUR_CFG                  0x22
#define R_AN_RL_L3_L3_ICMP_CTRL                  0x23
#define R_AN_RL_L3_L3_ERLID_CTRL                 0x24
#define R_AN_RL_L3_L3_ERLID_CFG                  0x25
#define R_AN_RL_L3_L3_STICKY_0                   0x26
#define R_AN_RL_L3_L3_STICKY_1                   0x27
#define R_AN_RL_L3_L3_IP_PKT_RECEIVED_CNT        0x28
#define R_AN_RL_L3_L3_IP_UC_FWD_CNT              0x29
#define R_AN_RL_L3_L3_IP_NON_UC_FWD_CNT          0x2a
#define R_AN_RL_L3_L3_IRLID_CNT_CTRL             0x2b
#define R_AN_RL_L3_L3_IRLID_UC_PKT_CNT           0x2c
#define R_AN_RL_L3_L3_IRLID_NON_UC_PKT_CNT       0x2d
#define R_AN_RL_L3_L3_IRLID_MC_RPF_FAIL_PKT_CNT  0x2e
#define R_AN_RL_L3_L3_IRLID_OCTETS_MSB_CNT       0x2f
#define R_AN_RL_L3_L3_IRLID_OCTETS_LSB_CNT       0x30
#define R_AN_RL_L3_L3_ERLID_CNT_CTRL             0x31
#define R_AN_RL_L3_L3_ERLID_UC_PKT_CNT           0x32
#define R_AN_RL_L3_L3_ERLID_UC_OCTETS_MSB_CNT    0x33
#define R_AN_RL_L3_L3_ERLID_UC_OCTETS_LSB_CNT    0x34
#define R_AN_RL_L3_L3_SECUR_FAIL_PKT_CNT         0x35
#define R_AN_RL_L3_RL_VRRP_CFG_0                 0x36 /* Gatwick-Ie only */
#define R_AN_RL_L3_RL_VRRP_CFG_1                 0x37 /* Gatwick-Ie only */
#define R_AN_RL_L3_BPDU_REDIR_CTRL               0x38 /* Gatwick-Ie only */

/* Target T_AN_L2_PS registers */
#define R_AN_L2_PS_L2_MAIN_CFG               0x00
#define R_AN_L2_PS_L2_AGEFILTER_CFG          0x01
#define R_AN_L2_PS_L2_MAC_CFG_0              0x02
#define R_AN_L2_PS_L2_MAC_CFG_1              0x03
#define R_AN_L2_PS_L2_MAC_CFG_2              0x04
#define R_AN_L2_PS_L2_MAC_CTRL               0x05
#define R_AN_L2_PS_L2_FLOOD_CFG              0x06
#define R_AN_L2_PS_L2_AUTO_CFG               0x07
#define R_AN_L2_PS_L2_EVENTMASK_CFG          0x08
#define R_AN_L2_PS_L2_AGEMODE_CFG            0x09 /* Gatwick-Ie only */
#define R_AN_L2_PS_L2_MOVELOG_STICKY         0x10
#define R_AN_L2_PS_L2_TABLEPOS_STICKY        0x11
#define R_AN_L2_PS_L2_EVENTS_STICKY          0x12
#define R_AN_L2_PS_L2_EVENT_CNT              0x13
#define R_AN_L2_PS_PS_CFG                    0x14
#define R_AN_L2_PS_PS_PGID_CTRL              0x15
#define R_AN_L2_PS_PS_PGID_CFG               0x16
#define R_AN_L2_PS_PS_AGGR_CTRL_GW1          0x17 /* Not Gatwick-Ie */
#define R_AN_L2_PS_PS_AGGR_CFG_GW1           0x18 /* Not Gatwick-Ie */
#define R_AN_L2_PS_PS_SRC_CTRL               0x19
#define R_AN_L2_PS_PS_SRC_CFG                0x1a
#define R_AN_L2_PS_PS_L2_UC_FLOOD_MASK_CFG   0x1b
#define R_AN_L2_PS_PS_L2_MC_FLOOD_MASK_CFG   0x1c
#define R_AN_L2_PS_PS_L3_MC_FLOOD_MASK_CFG   0x1d
#define R_AN_L2_PS_PS_EGRESS_MIRROR_MASK_CFG 0x1f
#define R_AN_L2_PS_PS_CPU_MIRROR_CFG         0x20
#define R_AN_L2_PS_PS_STICKY                 0x21
#define R_AN_L2_PS_PS_CPID_CTRL              0x22
#define R_AN_L2_PS_PS_CPID_CFG               0x23
#define R_AN_L2_PS_PS_DBG_CTRL               0x24
#define R_AN_L2_PS_PS_AGGR_CTRL_GW1E         0x25 /* Gatwick-Ie only */
#define R_AN_L2_PS_PS_AGGR_CFG_0             0x26 /* Gatwick-Ie only */
#define R_AN_L2_PS_PS_AGGR_CFG_1             0x27 /* Gatwick-Ie only */
#define R_AN_L2_PS_PS_AGGR_CFG_2             0x28 /* Gatwick-Ie only */
#define R_AN_L2_PS_PS_AGGR_CFG_3             0x29 /* Gatwick-Ie only */
#define R_AN_L2_PS_PS_GLAG_CTRL              0x2a /* Gatwick-Ie only */
#define R_AN_L2_PS_PS_GLAG_CFG               0x2b /* Gatwick-Ie only */

/* Target T_RXP registers */
#define R_RXP_VLAN_MPLS_PRIO_CFG     0x00
#define R_RXP_DSCP_PRIO_CFG_0        0x01
#define R_RXP_DSCP_PRIO_CFG_1        0x02
#define R_RXP_DSCP_PRIO_CFG_2        0x03
#define R_RXP_DSCP_PRIO_CFG_3        0x04
#define R_RXP_ETYPE_IPPROTO_PRIO_CFG 0x05
#define R_RXP_PRIO_ENABLE_CFG        0x06
#define R_RXP_AGGR_ENABLE_CFG        0x07
#define R_RXP_IN_QUEUE_CTRL          0x08
#define R_RXP_IN_QUEUE_DROP_CFG_0    0x09
#define R_RXP_IN_QUEUE_DROP_CFG_1    0x0a
#define R_RXP_IN_QUEUE_WMARK_CFG     0x0b
#define R_RXP_IN_POLICER_LEVEL_CFG   0x0c
#define R_RXP_IN_POLICER_RATE_CFG    0x0d
#define R_RXP_IN_POLICER_CTRL        0x0e
#define R_RXP_SWITCH_MODE_CFG        0x0f
#define R_RXP_PORT_VLAN_CFG          0x10
#define R_RXP_DROP_MASK_CFG          0x11
#define R_RXP_DROP_CNT               0x12
#define R_RXP_IN_PORT_STICKY         0x13
#define R_RXP_IN_QUEUE_SYSTEM_CFG    0x80
#define R_RXP_UDP_TCP_PRIO_CFG       0x81
#define R_RXP_UDP_TCP_PORT_CFG_0     0x82
#define R_RXP_UDP_TCP_PORT_CFG_1     0x83
#define R_RXP_UDP_TCP_PORT_CFG_2     0x84
#define R_RXP_UDP_TCP_PORT_CFG_3     0x85
#define R_RXP_UDP_TCP_PORT_CFG_4     0x86
#define R_RXP_IN_MODULE_STICKY       0x87
#define R_RXP_IN_MODULE_MPLS_CFG     0x88 /* Gatwick-Ie only */
#define R_RXP_DP_AND_CPU_BC_COPY_CFG 0x89 /* Gatwick-Ie only */
#define R_RXP_ARP_BC_TAR_CFG         0x8a /* Gatwick-Ie only */
#define R_RXP_STACKING_TAG_CFG       0x8b /* Gatwick-Ie only */
#define R_RXP_ST_PRIO_REMAP_CFG      0x8c /* Gatwick-Ie only */

/* Target T_TXP registers */
#define R_TXP_QS_CFG                    0x00
#define R_TXP_QS_LINKAGGR_CFG           0x01
#define R_TXP_IP_MULTICAST_TTL_DROP_CNT 0x02
#define R_TXP_DROP_CFG                  0x03
#define R_TXP_QS_DROP_CFG               0x04
#define R_TXP_QS_PORT_WM                0x05
#define R_TXP_QS_PORT_DROP_CFG          0x06
#define R_TXP_PORT_DROP_CNT             0x07 /* Gatwick-Ie only */
#define R_TXP_QS_PRLID_0                0x08
#define R_TXP_QS_PRLID_1                0x09
#define R_TXP_QS_PRLID_2                0x0a
#define R_TXP_QS_PRLID_3                0x0b
#define R_TXP_QS_PRLID_4                0x0c
#define R_TXP_QS_PRLID_5                0x0d
#define R_TXP_QS_PRLID_6                0x0e
#define R_TXP_QS_PRLID_7                0x0f
#define R_TXP_SHAPER_CFG_0              0x10
#define R_TXP_SHAPER_CFG_1              0x11
#define R_TXP_SHAPER_CFG_2              0x12
#define R_TXP_SHAPER_CFG_3              0x13
#define R_TXP_REWR_CFG                  0x14
#define R_TXP_REWR_UNTAGGED_VLAN        0x15
#define R_TXP_REWR_L3_SMAC_LO_0         0x16
#define R_TXP_REWR_L3_SMAC_HI_0         0x17
#define R_TXP_REWR_L3_SMAC_LO_1         0x18
#define R_TXP_REWR_L3_SMAC_HI_1         0x19
#define R_TXP_REWR_L3_SMAC_LO_2         0x1a
#define R_TXP_REWR_L3_SMAC_HI_2         0x1b
#define R_TXP_REWR_L3_SMAC_LO_3         0x1c
#define R_TXP_REWR_L3_SMAC_HI_3         0x1d
#define R_TXP_REWR_L3_TTL               0x1e
#define R_TXP_SCHED_STATUS              0x1f
#define R_TXP_QS_MODULE_WM              0x80
#define R_TXP_QS_DROP_CNT               0x81 /* Not Gatwick-Ie */
#define R_TXP_QS_CPU_DATA               0x82
#define R_TXP_QS_CPU_CTRL               0x83
#define R_TXP_QS_STICKY                 0x84
#define R_TXP_QS_LINK_INDEX             0x85
#define R_TXP_QS_LINK_DATA              0x86
#define R_TXP_QS_QUEUE_INDEX            0x87
#define R_TXP_QS_QUEUE_DATA0            0x88
#define R_TXP_QS_QUEUE_DATA1            0x89
#define R_TXP_QS_REPLAY_CFG             0x8a
#define R_TXP_QS_RFS_CFG                0x8b
#define R_TXP_STACKING_TAG_CFG          0x8c

/* Target T_D10_MAC registers */
#define R_D10_MAC_MODE_CFG          0x00
#define R_D10_MAC_PAUSE_CFG         0x01
#define R_D10_MAC_MAXLEN_CFG        0x02
#define R_D10_MAC_MAC_ADDR_HIGH_CFG 0x03
#define R_D10_MAC_MAC_ADDR_LOW_CFG  0x04
#define R_D10_MAC_VSC7226_PCS_CFG   0x05 /* Not Gatwick-Ie */
#define R_D10_MAC_MISC_CFG          0x06
#define R_D10_MAC_RESET_CTRL        0x08
#define R_D10_MAC_DROP_CNT          0x09
#define R_D10_MAC_DBG_CFG           0x0a
#define R_D10_MAC_RX_LANE_STICKY_0  0x0b
#define R_D10_MAC_RX_LANE_STICKY_1  0x0c
#define R_D10_MAC_TX_MONITOR_STICKY 0x0d
#define R_D10_MAC_MISC_STICKY       0x0e
#define R_D10_MAC_PB_PORT_CFG       0x0f /* Gatwick-Ie only */
#define R_D10_MAC_PB_MODE_CFG       0x80 /* Gatwick-Ie only */

/* Target T_SE registers */
#define R_SE_RX_IN_BYTES_CNT                0x00
#define R_SE_RX_SYMBOL_CARRIER_ERR_CNT      0x01
#define R_SE_RX_PAUSE_CNT                   0x02
#define R_SE_RX_UNSUP_OPCODE_CNT            0x03
#define R_SE_RX_OK_BYTES_CNT                0x04
#define R_SE_RX_BAD_BYTES_CNT               0x05
#define R_SE_RX_UNICAST_CNT                 0x06
#define R_SE_RX_MULTICAST_CNT               0x07
#define R_SE_RX_BROADCAST_CNT               0x08
#define R_SE_RX_CRC_ERR_CNT                 0x09
#define R_SE_RX_ALIGNMENT_ERR_CNT           0x0a /* D4 only */
#define R_SE_RX_UNDERSIZE_CNT               0x0b
#define R_SE_RX_FRAGMENTS_CNT               0x0c
#define R_SE_RX_IN_RANGE_LENGTH_ERR_CNT     0x0d
#define R_SE_RX_OUT_OF_RANGE_LENGTH_ERR_CNT 0x0e
#define R_SE_RX_OVERSIZE_CNT                0x0f
#define R_SE_RX_JABBERS_CNT                 0x10
#define R_SE_RX_SIZE64_CNT                  0x11
#define R_SE_RX_SIZE65TO127_CNT             0x12
#define R_SE_RX_SIZE128TO255_CNT            0x13
#define R_SE_RX_SIZE256TO511_CNT            0x14
#define R_SE_RX_SIZE512TO1023_CNT           0x15
#define R_SE_RX_SIZE1024TO1518_CNT          0x16
#define R_SE_RX_SIZE1519TOMAX_CNT           0x17
#define R_SE_TX_OUT_BYTES_CNT               0x18
#define R_SE_TX_PAUSE_CNT                   0x19
#define R_SE_TX_OK_BYTES_CNT                0x1a
#define R_SE_TX_UNICAST_CNT                 0x1b
#define R_SE_TX_MULTICAST_CNT               0x1c
#define R_SE_TX_BROADCAST_CNT               0x1d
#define R_SE_TX_MULTI_COLL_CNT              0x1e /* D4 only */
#define R_SE_TX_LATE_COLL_CNT               0x1f /* D4 only */
#define R_SE_TX_XCOLL_CNT                   0x20 /* D4 only */
#define R_SE_TX_DEFER_CNT                   0x21 /* D4 only */
#define R_SE_TX_XDEFER_CNT                  0x22 /* D4 only */
#define R_SE_TX_CSENSE_CNT                  0x23 /* D4 only */
#define R_SE_TX_SIZE64_CNT                  0x24
#define R_SE_TX_SIZE65TO127_CNT             0x25
#define R_SE_TX_SIZE128TO255_CNT            0x26
#define R_SE_TX_SIZE256TO511_CNT            0x27
#define R_SE_TX_SIZE512TO1023_CNT           0x28
#define R_SE_TX_SIZE1024TO1518_CNT          0x29
#define R_SE_TX_SIZE1519TOMAX_CNT           0x2a
#define R_SE_TX_BACKOFF1_CNT                0x2b /* D4 only */
#define R_SE_TX_BACKOFF2_CNT                0x2c /* D4 only */
#define R_SE_TX_BACKOFF3_CNT                0x2d /* D4 only */
#define R_SE_TX_BACKOFF4_CNT                0x2e /* D4 only */
#define R_SE_TX_BACKOFF5_CNT                0x2f /* D4 only */
#define R_SE_TX_BACKOFF6_CNT                0x30 /* D4 only */
#define R_SE_TX_BACKOFF7_CNT                0x31 /* D4 only */
#define R_SE_TX_BACKOFF8_CNT                0x32 /* D4 only */
#define R_SE_TX_BACKOFF9_CNT                0x33 /* D4 only */
#define R_SE_TX_BACKOFF10_CNT               0x34 /* D4 only */
#define R_SE_TX_BACKOFF11_CNT               0x35 /* D4 only */
#define R_SE_TX_BACKOFF12_CNT               0x36 /* D4 only */
#define R_SE_TX_BACKOFF13_CNT               0x37 /* D4 only */
#define R_SE_TX_BACKOFF14_CNT               0x38 /* D4 only */
#define R_SE_TX_BACKOFF15_CNT               0x39 /* D4 only */
#define R_SE_TX_UNDERRUN_CNT                0x3a
#define R_SE_RX_XGMII_PROT_ERR_CNT          0x3b /* D10 only */
#define R_SE_RX_IPG_SHRINK_CNT              0x3c
#define R_SE_STAT_STICKY                    0x3e /* Fields different for D4/D10 */

/* Target T_D4_MAC registers */
#define R_D4_MAC_MODE_CFG          0x00
#define R_D4_MAC_PAUSE_CFG         0x01
#define R_D4_MAC_MAXLEN_CFG        0x02
#define R_D4_MAC_MAC_ADDR_HIGH_CFG 0x03
#define R_D4_MAC_MAC_ADDR_LOW_CFG  0x04
#define R_D4_MAC_IFG_CFG           0x05
#define R_D4_MAC_TBI_CFG           0x06
#define R_D4_MAC_LATE_COL_POS_CFG  0x07
#define R_D4_MAC_RESET_CTRL        0x08
#define R_D4_MAC_TBI_STATUS        0x09
#define R_D4_MAC_TBI_STATUS_DBG    0x0a
#define R_D4_MAC_DROP_CNT          0x0b
#define R_D4_MAC_DBG_CFG           0x0c
#define R_D4_MAC_STICKY            0x0d
#define R_D4_MAC_PB_PORT_CFG       0x0f /* Gatwick-Ie only */
#define R_D4_MAC_PB_MODE_CFG       0x80 /* Gatwick-Ie only */

/* Target register R_CPU_CCA_CHIP_JTAG_ID fields */
#define O_CPU_CCA_CHIP_JTAG_ID_ALWAYS_ONE      0
#define M_CPU_CCA_CHIP_JTAG_ID_ALWAYSONE       0x1
#define O_CPU_CCA_CHIP_JTAG_ID_MANUFACTURER_ID 1
#define M_CPU_CCA_CHIP_JTAG_ID_MANUFACTURER_ID 0x7ff
#define O_CPU_CCA_CHIP_JTAG_ID_PART_NUMBER     12
#define M_CPU_CCA_CHIP_JTAG_ID_PART_NUMBER     0xffff
#define O_CPU_CCA_CHIP_JTAG_ID_REVISION_ID     28
#define M_CPU_CCA_CHIP_JTAG_ID_REVISION_ID     0xf

/* Target register R_CPU_CCA_BLADE_ID fields */
#define O_CPU_CCA_BLADE_ID_BLADE_ID 0
#define M_CPU_CCA_BLADE_ID_BLADE_ID 0xff

/* Target register R_CPU_CCA_SOFT_RESET_CTRL fields */
#define O_CPU_CCA_SOFT_RESET_CTRL_GLOBAL_RESET0 0
#define M_CPU_CCA_SOFT_RESET_CTRL_GLOBAL_RESET0 0x1
#define O_CPU_CCA_SOFT_RESET_CTRL_GLOBAL_RESET1 31
#define M_CPU_CCA_SOFT_RESET_CTRL_GLOBAL_RESET1 0x1

/* Target register R_CPU_CCA_TSTAMP_CFG fields */
#define O_CPU_CCA_TSTAMP_CFG_TSTAMP_MODE 0
#define M_CPU_CCA_TSTAMP_CFG_TSTAMP_MODE 0x7
#define O_CPU_CCA_TSTAMP_CFG_TSTAMP_VAL  3
#define M_CPU_CCA_TSTAMP_CFG_TSTAMP_VAL  0x7f
#define O_CPU_CCA_TSTAMP_CFG_SET_TSTAMP  10
#define M_CPU_CCA_TSTAMP_CFG_SET_TSTAMP  0x1
#define O_CPU_CCA_TSTAMP_CFG_SET_LFSR    11
#define M_CPU_CCA_TSTAMP_CFG_SET_LFSR    0x1

/* Target register R_CPU_CCA_SI_CFG_0 fields */
#define O_CPU_CCA_SI_CFG_0_SI_INSERT_BYTES 0
#define M_CPU_CCA_SI_CFG_0_SI_INSERT_BYTES 0xf

/* Target register R_CPU_CCA_SI_CFG_1 fields */
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_0  0
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_0  0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_0 3
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_0 0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_1 4
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_1 0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_1  7
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_1  0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_2  8
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_2  0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_2 11
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_2 0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_3 12
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_3 0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_3  15
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_3  0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_4  16
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_4  0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_4 19
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_4 0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_5 20
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_5 0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_5  23
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_5  0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_6  24
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_6  0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_6 27
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_6 0x1
#define O_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_7 28
#define M_CPU_CCA_SI_CFG_1_SI_BIG_ENDIAN_7 0x1
#define O_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_7  31
#define M_CPU_CCA_SI_CFG_1_SI_MSB_FIRST_7  0x1

/* Target register R_CPU_CCA_QS_STATUS fields */
#define O_CPU_CCA_QS_STATUS_CPUQS_FPN 0
#define M_CPU_CCA_QS_STATUS_CPUQS_FPN 0xffff
#define O_CPU_CCA_QS_STATUS_CPUQS_DR  17
#define M_CPU_CCA_QS_STATUS_CPUQS_DR  0x1

/* Target register R_CPU_CCA_QS_CTRL fields */
#define O_CPU_CCA_QS_CTRL_CPUQS_FQRN  0
#define M_CPU_CCA_QS_CTRL_CPUQS_FQRN  0xffff
#define O_CPU_CCA_QS_CTRL_CPUQS_FLUSH 16
#define M_CPU_CCA_QS_CTRL_CPUQS_FLUSH 0x1
#define O_CPU_CCA_QS_CTRL_CPUQS_RESET 17
#define M_CPU_CCA_QS_CTRL_CPUQS_RESET 0x1

/* Target register R_CPU_CCA_QS_FRAME_STATUS fields */
#define O_CPU_CCA_QS_FRAME_STATUS_CPUQS_LAST    23
#define M_CPU_CCA_QS_FRAME_STATUS_CPUQS_LAST    0x7
#define O_CPU_CCA_QS_FRAME_STATUS_CPUQS_FQ      26
#define M_CPU_CCA_QS_FRAME_STATUS_CPUQS_FQ      0xf
#define O_CPU_CCA_QS_FRAME_STATUS_CPUQS_FRVALID 31
#define M_CPU_CCA_QS_FRAME_STATUS_CPUQS_FRVALID 0x1

/* Target register R_CPU_CCA_QS_DATA fields */
#define O_CPU_CCA_QS_DATA_CPUQS_FD 0
#define M_CPU_CCA_QS_DATA_CPUQS_FD 0xffffffff

/* Target register R_CPU_CCA_QS_QUEUE_SEL fields */
#define O_CPU_CCA_QS_QUEUE_SEL_CPUQS_FQN 0
#define M_CPU_CCA_QS_QUEUE_SEL_CPUQS_FQN 0xffff

/* Target register R_CPU_CCA_QS_ERR fields */
#define O_CPU_CCA_QS_ERR_CPUQS_NFE 1
#define M_CPU_CCA_QS_ERR_CPUQS_NFE 0x1
#define O_CPU_CCA_QS_ERR_CPUQS_BE  2
#define M_CPU_CCA_QS_ERR_CPUQS_BE  0x1
#define O_CPU_CCA_QS_ERR_CPUQS_FDE 3
#define M_CPU_CCA_QS_ERR_CPUQS_FDE 0x1

/* Target register R_CPU_CCA_QS_STICKY_ERR fields */
#define O_CPU_CCA_QS_STICKY_ERR_CPUQS_NFE_STICKY 1
#define M_CPU_CCA_QS_STICKY_ERR_CPUQS_NFE_STICKY 0x1
#define O_CPU_CCA_QS_STICKY_ERR_CPUQS_BE_STICKY  2
#define M_CPU_CCA_QS_STICKY_ERR_CPUQS_BE_STICKY  0x1
#define O_CPU_CCA_QS_STICKY_ERR_CPUQS_FDE_STICKY 3
#define M_CPU_CCA_QS_STICKY_ERR_CPUQS_FDE_STICKY 0x1

/* Target register R_CPU_CCA_QS_STICKY_ERR_SHADOW fields */
#define O_CPU_CCA_QS_STICKY_ERR_SHADOW_CPUQS_NFE_SHADOW 1
#define M_CPU_CCA_QS_STICKY_ERR_SHADOW_CPUQS_NFE_SHADOW 0x1
#define O_CPU_CCA_QS_STICKY_ERR_SHADOW_CPUQS_BE_SHADOW  2
#define M_CPU_CCA_QS_STICKY_ERR_SHADOW_CPUQS_BE_SHADOW  0x1
#define O_CPU_CCA_QS_STICKY_ERR_SHADOW_CPUQS_FDE_SHADOW 3
#define M_CPU_CCA_QS_STICKY_ERR_SHADOW_CPUQS_FDE_SHADOW 0x1

/* Target register R_CPU_CCA_QS_SEMAPHORE fields */
#define O_CPU_CCA_QS_SEMAPHORE_SEMA 0
#define M_CPU_CCA_QS_SEMAPHORE_SEMA 0x1

/* Target register R_CPU_CCA_QS_TXQS_CFG0 fields */
#define O_CPU_CCA_QS_TXQS_CFG0_CPUQS_WR_ENA 0
#define M_CPU_CCA_QS_TXQS_CFG0_CPUQS_WR_ENA 0xffff

/* Target register R_CPU_CCA_QS_TXQS_CFG1 fields */
#define O_CPU_CCA_QS_TXQS_CFG1_CPUQS_TRUNC 0
#define M_CPU_CCA_QS_TXQS_CFG1_CPUQS_TRUNC 0xffff

/* Target register R_CPU_CCA_QS_DROP_CNT fields */
#define O_CPU_CCA_QS_DROP_CNT_CPUQS_QSDROP 0
#define M_CPU_CCA_QS_DROP_CNT_CPUQS_QSDROP 0xffffffff

/* Target register R_CPU_CCA_QS_DROP_CNT_CFG fields */
#define O_CPU_CCA_QS_DROP_CNT_CFG_CPUQS_QS 0
#define M_CPU_CCA_QS_DROP_CNT_CFG_CPUQS_QS 0x1

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG0 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG0_CPUQS_LEVEL0 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG0_CPUQS_LEVEL0 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG1 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG1_CPUQS_LEVEL1 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG1_CPUQS_LEVEL1 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG2 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG2_CPUQS_LEVEL2 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG2_CPUQS_LEVEL2 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG3 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG3_CPUQS_LEVEL3 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG3_CPUQS_LEVEL3 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG4 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG4_CPUQS_LEVEL4 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG4_CPUQS_LEVEL4 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG5 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG5_CPUQS_LEVEL5 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG5_CPUQS_LEVEL5 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG6 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG6_CPUQS_LEVEL6 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG6_CPUQS_LEVEL6 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG7 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG7_CPUQS_LEVEL7 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG7_CPUQS_LEVEL7 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG8 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG8_CPUQS_LEVEL8 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG8_CPUQS_LEVEL8 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG9 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG9_CPUQS_LEVEL9 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG9_CPUQS_LEVEL9 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG10 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG10_CPUQS_LEVEL10 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG10_CPUQS_LEVEL10 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG11 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG11_CPUQS_LEVEL11 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG11_CPUQS_LEVEL11 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG12 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG12_CPUQS_LEVEL12 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG12_CPUQS_LEVEL12 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG13 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG13_CPUQS_LEVEL13 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG13_CPUQS_LEVEL13 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG14 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG14_CPUQS_LEVEL14 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG14_CPUQS_LEVEL14 0x3f

/* Target register R_CPU_CCA_QS_TXQS_DROP_CFG15 fields */
#define O_CPU_CCA_QS_TXQS_DROP_CFG15_CPUQS_LEVEL15 0
#define M_CPU_CCA_QS_TXQS_DROP_CFG15_CPUQS_LEVEL15 0x3f

/* Target register R_CPU_CCA_QS_LINK_INDEX fields */
#define O_CPU_CCA_QS_LINK_INDEX_CPUQS_LINK_INDEX 0
#define M_CPU_CCA_QS_LINK_INDEX_CPUQS_LINK_INDEX 0x3f

/* Target register R_CPU_CCA_QS_LINK_DATA fields */
#define O_CPU_CCA_QS_LINK_DATA_CPUQS_LINK_PTR   0
#define M_CPU_CCA_QS_LINK_DATA_CPUQS_LINK_PTR   0x3f
#define O_CPU_CCA_QS_LINK_DATA_CPUQS_LINK_INUSE 6
#define M_CPU_CCA_QS_LINK_DATA_CPUQS_LINK_INUSE 0x1

/* Target register R_CPU_CCA_QS_QUEUE_INDEX fields */
#define O_CPU_CCA_QS_QUEUE_INDEX_CPUQS_INDEX 0
#define M_CPU_CCA_QS_QUEUE_INDEX_CPUQS_INDEX 0x1f

/* Target register R_CPU_CCA_QS_QUEUE_DATA0 fields */
#define O_CPU_CCA_QS_QUEUE_DATA0_CPUQS_INUSE   0
#define M_CPU_CCA_QS_QUEUE_DATA0_CPUQS_INUSE   0x1
#define O_CPU_CCA_QS_QUEUE_DATA0_CPUQS_RX      1
#define M_CPU_CCA_QS_QUEUE_DATA0_CPUQS_RX      0x1
#define O_CPU_CCA_QS_QUEUE_DATA0_CPUQS_RXPTR   2
#define M_CPU_CCA_QS_QUEUE_DATA0_CPUQS_RXPTR   0x1ff
#define O_CPU_CCA_QS_QUEUE_DATA0_CPUQS_RETXPTR 11
#define M_CPU_CCA_QS_QUEUE_DATA0_CPUQS_RETXPTR 0x1ff
#define O_CPU_CCA_QS_QUEUE_DATA0_CPUQS_TXPTR   20
#define M_CPU_CCA_QS_QUEUE_DATA0_CPUQS_TXPTR   0xfff

/* Target register R_CPU_CCA_QS_QUEUE_DATA1 fields */
#define O_CPU_CCA_QS_QUEUE_DATA1_CPUQS_TXSET   0
#define M_CPU_CCA_QS_QUEUE_DATA1_CPUQS_TXSET   0x1
#define O_CPU_CCA_QS_QUEUE_DATA1_CPUQS_TXVALID 1
#define M_CPU_CCA_QS_QUEUE_DATA1_CPUQS_TXVALID 0x1
#define O_CPU_CCA_QS_QUEUE_DATA1_CPUQS_SRCFPTR 2
#define M_CPU_CCA_QS_QUEUE_DATA1_CPUQS_SRCFPTR 0x1ff

/* Target register R_CPU_CCA_QS_REPLAY_CFG fields */
#define O_CPU_CCA_QS_REPLAY_CFG_CPUQS_REPLAY_ENA 0
#define M_CPU_CCA_QS_REPLAY_CFG_CPUQS_REPLAY_ENA 0x1

/* Target register R_CPU_CCA_QS_RFS_CFG fields */
#define O_CPU_CCA_QS_RFS_CFG_CPUQS_POINTER   0
#define M_CPU_CCA_QS_RFS_CFG_CPUQS_POINTER   0x3f
#define O_CPU_CCA_QS_RFS_CFG_CPUQS_VALID     6
#define M_CPU_CCA_QS_RFS_CFG_CPUQS_VALID     0x1
#define O_CPU_CCA_QS_RFS_CFG_CPUQS_CPU_QUEUE 7
#define M_CPU_CCA_QS_RFS_CFG_CPUQS_CPU_QUEUE 0x3f
#define O_CPU_CCA_QS_RFS_CFG_CPUQS_CPU_VALID 13
#define M_CPU_CCA_QS_RFS_CFG_CPUQS_CPU_VALID 0x1

/* Target register R_CPU_GM_MII_STATUS_1G fields */
#define O_CPU_GM_MII_STATUS_1G_WRITE_IN_PROGRESS_1G   0
#define M_CPU_GM_MII_STATUS_1G_WRITE_IN_PROGRESS_1G   0x1
#define O_CPU_GM_MII_STATUS_1G_READ_IN_PROGRESS_1G    1
#define M_CPU_GM_MII_STATUS_1G_READ_IN_PROGRESS_1G    0x1
#define O_CPU_GM_MII_STATUS_1G_ACCESS_PENDING_1G      2
#define M_CPU_GM_MII_STATUS_1G_ACCESS_PENDIND_1G      0x1
#define O_CPU_GM_MII_STATUS_1G_BUSY_OR_IN_PROGRESS_1G 3
#define M_CPU_GM_MII_STATUS_1G_BUSY_OR_IN_PROGRESS_1G 0x1

/* Target register R_CPU_GM_MII_COMMAND_1G fields */
#define O_CPU_GM_MII_COMMAND_1G_WRITE_DATA_1G  0
#define M_CPU_GM_MII_COMMAND_1G_WRITE_DATA_1G  0xffff
#define O_CPU_GM_MII_COMMAND_1G_REG_ADDR_1G    16
#define M_CPU_GM_MII_COMMAND_1G_REG_ADDR_1G    0x1f
#define O_CPU_GM_MII_COMMAND_1G_PHY_ADDR_1G    21
#define M_CPU_GM_MII_COMMAND_1G_PHY_ADDR_1G    0x1f
#define O_CPU_GM_MII_COMMAND_1G_ACCESS_TYPE_1G 26
#define M_CPU_GM_MII_COMMAND_1G_ACCESS_TYPE_1G 0x3
#define O_CPU_GM_MII_COMMAND_1G_SCAN_ENA_1G    28
#define M_CPU_GM_MII_COMMAND_1G_SCAN_ENA_1G    0x1

/* Target register R_CPU_GM_MII_DATA_1G fields */
#define O_CPU_GM_MII_DATA_1G_READ_DATA_1G 0
#define M_CPU_GM_MII_DATA_1G_READ_DATA_1G 0xffff
#define O_CPU_GM_MII_DATA_1G_READ_ERR_1G  16
#define M_CPU_GM_MII_DATA_1G_READ_ERR_1G  0x3

/* Target register R_CPU_GM_MII_CFG_1G fields */
#define O_CPU_GM_MII_CFG_1G_CLOCK_PRESCALE_1G          0
#define M_CPU_GM_MII_CFG_1G_CLOCK_PRESCALE_1G          0x3f
#define O_CPU_GM_MII_CFG_1G_BUSY_OR_PROGRESS_SELECT_1G 6
#define M_CPU_GM_MII_CFG_1G_BUSY_OR_PROGESSS_SELECT_1G 0x1
#define O_CPU_GM_MII_CFG_1G_START_OF_FRAME_CFG_1G      7
#define M_CPU_GM_MII_CFG_1G_START_OF_FRAME_CFG_1G      0x3

/* Target register R_CPU_GM_MII_SCAN1_1G fields */
#define O_CPU_GM_MII_SCAN1_1G_PHY_ADDR_LOW_1G  0
#define M_CPU_GM_MII_SCAN1_1G_PHY_ADDR_LOW_1G  0x1f
#define O_CPU_GM_MII_SCAN1_1G_PHY_ADDR_HIGH_1G 5
#define M_CPU_GM_MII_SCAN1_1G_PHY_ADDR_HIGH_1G 0x1f

/* Target register R_CPU_GM_MII_SCAN2_1G fields */
#define O_CPU_GM_MII_SCAN2_1G_SCAN_EXPECT 0
#define M_CPU_GM_MII_SCAN2_1G_SCAN_EXPECT 0xffff
#define O_CPU_GM_MII_SCAN2_1G_SCAN_MASK   16
#define M_CPU_GM_MII_SCAN2_1G_SCAN_MASK   0xffff

/* Target register R_CPU_GM_MII_SCAN_RESULTS_1G fields */
#define O_CPU_GM_MII_SCAN_RESULTS_1G_SCAN_RESULTS 0
#define M_CPU_GM_MII_SCAN_RESULTS_1G_SCAN_RESULTS 0xffffffff

/* Target register R_CPU_GM_MII_STATUS_10G_0 fields */
#define O_CPU_GM_MII_STATUS_10G_0_WRITE_IN_PROGRESS_10G   0
#define M_CPU_GM_MII_STATUS_10G_0_WRITE_IN_PROGRESS_10G   0x1
#define O_CPU_GM_MII_STATUS_10G_0_READ_IN_PROGRESS_10G    1
#define M_CPU_GM_MII_STATUS_10G_0_READ_IN_PROGRESS_10G    0x1
#define O_CPU_GM_MII_STATUS_10G_0_ACCESS_PENDING_10G      2
#define M_CPU_GM_MII_STATUS_10G_0_ACCESS_PENDING_10G      0x1
#define O_CPU_GM_MII_STATUS_10G_0_BUSY_OR_IN_PROGRESS_10G 3
#define M_CPU_GM_MII_STATUS_10G_0_BUSY_OR_IN_PROGRESS_10G 0x1

/* Target register R_CPU_GM_MII_COMMAND_10G_0 fields */
#define O_CPU_GM_MII_COMMAND_10G_0_WRITE_DATA_10G  0
#define M_CPU_GM_MII_COMMAND_10G_0_WRITE_DATA_10G  0xffff
#define O_CPU_GM_MII_COMMAND_10G_0_REG_ADDR_10G    16
#define M_CPU_GM_MII_COMMAND_10G_0_REG_ADDR_10G    0x1f
#define O_CPU_GM_MII_COMMAND_10G_0_PHY_ADDR_10G    21
#define M_CPU_GM_MII_COMMAND_10G_0_PHY_ADDR_10G    0x1f
#define O_CPU_GM_MII_COMMAND_10G_0_ACCESS_TYPE_10G 26
#define M_CPU_GM_MII_COMMAND_10G_0_ACCESS_TYPE_10G 0x3
#define O_CPU_GM_MII_COMMAND_10G_0_SCAN_ENA_10G    28
#define M_CPU_GM_MII_COMMAND_10G_0_SCAN_ENA_10G    0x1

/* Target register R_CPU_GM_MII_DATA_10G_0 fields */
#define O_CPU_GM_MII_DATA_10G_0_READ_DATA_10G 0
#define M_CPU_GM_MII_DATA_10G_0_READ_DATA_10G 0xffff
#define O_CPU_GM_MII_DATA_10G_0_READ_ERR_10G  16
#define M_CPU_GM_MII_DATA_10G_0_READ_ERR_10G  0x3

/* Target register R_CPU_GM_MII_CFG_10G_0 fields */
#define O_CPU_GM_MII_CFG_10G_CLOCK_PRESCALE_10G          0
#define M_CPU_GM_MII_CFG_10G_0_CLOCK_PRESCALE_10G          0x3f
#define O_CPU_GM_MII_CFG_10G_0_BUSY_OR_PROGRESS_SELECT_10G 6
#define M_CPU_GM_MII_CFG_10G_0_BUSY_OR_PROGRESS_SELECT_10G 0x1
#define O_CPU_GM_MII_CFG_10G_0_START_OF_FRAME_CFG_10G      7
#define M_CPU_GM_MII_CFG_10G_0_START_OF_FRAME_CFG_10G      0x3
#define O_CPU_GM_MII_CFG_10G_0_VSC7226_MODE_ENA_10G        9   /* Not Gatwick-Ie */
#define M_CPU_GM_MII_CFG_10G_0_VSC7226_MODE_ENA_10G        0x1 /* Not Gatwick-Ie */

/* Target register R_CPU_GM_MII_SCAN1_10G_0 fields */
#define O_CPU_GM_MII_SCAN1_10G_0_PHY_ADDR_LOW_10G  0
#define M_CPU_GM_MII_SCAN1_10G_0_PHY_ADDR_LOW_10G  0x1f
#define O_CPU_GM_MII_SCAN1_10G_0_PHY_ADDR_HIGH_10G 5
#define M_CPU_GM_MII_SCAN1_10G_0_PHY_ADDR_HIGH_10G 0x1f

/* Target register R_CPU_GM_MII_SCAN2_10G_0 fields */
#define O_CPU_GM_MII_SCAN2_10G_0_SCAN_EXPECT_10G 0
#define M_CPU_GM_MII_SCAN2_10G_0_SCAN_EXPECT_10G 0xffff
#define O_CPU_GM_MII_SCAN2_10G_0_SCAN_MASK_10G   16
#define M_CPU_GM_MII_SCAN2_10G_0_SCAN_MASK_10G   0xffff

/* Target register R_CPU_GM_MII_SCAN_RESULTS_10G_0 fields */
#define O_CPU_GM_MII_SCAN_RESULTS_10G_0_SCAN_RESULTS_10G 0
#define M_CPU_GM_MII_SCAN_RESULTS_10G_0_SCAN_RESULTS_10G 0xffffffff

/* Target register R_CPU_GM_MII_STATUS_10G_1 fields */
#define O_CPU_GM_MII_STATUS_10G_1_WRITE_IN_PROGRESS_10G   0
#define M_CPU_GM_MII_STATUS_10G_1_WRITE_IN_PROGRESS_10G   0x1
#define O_CPU_GM_MII_STATUS_10G_1_READ_IN_PROGRESS_10G    1
#define M_CPU_GM_MII_STATUS_10G_1_READ_IN_PROGRESS_10G    0x1
#define O_CPU_GM_MII_STATUS_10G_1_ACCESS_PENDING_10G      2
#define M_CPU_GM_MII_STATUS_10G_1_ACCESS_PENDING_10G      0x1
#define O_CPU_GM_MII_STATUS_10G_1_BUSY_OR_IN_PROGRESS_10G 3
#define M_CPU_GM_MII_STATUS_10G_1_BUSY_OR_IN_PROGRESS_10G 0x1

/* Target register R_CPU_GM_MII_COMMAND_10G_1 fields */
#define O_CPU_GM_MII_COMMAND_10G_1_WRITE_DATA_10G  0
#define M_CPU_GM_MII_COMMAND_10G_1_WRITE_DATA_10G  0xffff
#define O_CPU_GM_MII_COMMAND_10G_1_REG_ADDR_10G    16
#define M_CPU_GM_MII_COMMAND_10G_1_REG_ADDR_10G    0x1f
#define O_CPU_GM_MII_COMMAND_10G_1_PHY_ADDR_10G    21
#define M_CPU_GM_MII_COMMAND_10G_1_PHY_ADDR_10G    0x1f
#define O_CPU_GM_MII_COMMAND_10G_1_ACCESS_TYPE_10G 26
#define M_CPU_GM_MII_COMMAND_10G_1_ACCESS_TYPE_10G 0x3
#define O_CPU_GM_MII_COMMAND_10G_1_SCAN_ENA_10G    28
#define M_CPU_GM_MII_COMMAND_10G_1_SCAN_ENA_10G    0x1

/* Target register R_CPU_GM_MII_DATA_10G_1 fields */
#define O_CPU_GM_MII_DATA_10G_1_READ_DATA_10G 0
#define M_CPU_GM_MII_DATA_10G_1_READ_DATA_10G 0xffff
#define O_CPU_GM_MII_DATA_10G_1_READ_ERR_10G  16
#define M_CPU_GM_MII_DATA_10G_1_READ_ERR_10G  0x3

/* Target register R_CPU_GM_MII_CFG_10G_1 fields */
#define O_CPU_GM_MII_CFG_10G_CLOCK_PRESCALE_10G          0
#define M_CPU_GM_MII_CFG_10G_1_CLOCK_PRESCALE_10G          0x3f
#define O_CPU_GM_MII_CFG_10G_1_BUSY_OR_PROGRESS_SELECT_10G 6
#define M_CPU_GM_MII_CFG_10G_1_BUSY_OR_PROGRESS_SELECT_10G 0x1
#define O_CPU_GM_MII_CFG_10G_1_START_OF_FRAME_CFG_10G      7
#define M_CPU_GM_MII_CFG_10G_1_START_OF_FRAME_CFG_10G      0x3
#define O_CPU_GM_MII_CFG_10G_1_VSC7226_MODE_ENA_10G        9   /* Not Gatwick-Ie */
#define M_CPU_GM_MII_CFG_10G_1_VSC7226_MODE_ENA_10G        0x1 /* Not Gatwick-Ie */

/* Target register R_CPU_GM_MII_SCAN1_10G_1 fields */
#define O_CPU_GM_MII_SCAN1_10G_1_PHY_ADDR_LOW_10G  0
#define M_CPU_GM_MII_SCAN1_10G_1_PHY_ADDR_LOW_10G  0x1f
#define O_CPU_GM_MII_SCAN1_10G_1_PHY_ADDR_HIGH_10G 5
#define M_CPU_GM_MII_SCAN1_10G_1_PHY_ADDR_HIGH_10G 0x1f

/* Target register R_CPU_GM_MII_SCAN2_10G_1 fields */
#define O_CPU_GM_MII_SCAN2_10G_1_SCAN_EXPECT_10G 0
#define M_CPU_GM_MII_SCAN2_10G_1_SCAN_EXPECT_10G 0xffff
#define O_CPU_GM_MII_SCAN2_10G_1_SCAN_MASK_10G   16
#define M_CPU_GM_MII_SCAN2_10G_1_SCAN_MASK_10G   0xffff

/* Target register R_CPU_GM_MII_SCAN_RESULTS_10G_1 fields */
#define O_CPU_GM_MII_SCAN_RESULTS_10G_1_SCAN_RESULTS_10G 0
#define M_CPU_GM_MII_SCAN_RESULTS_10G_1_SCAN_RESULTS_10G 0xffffffff

/* Target register R_CPU_GM_GPIO_DIRECTION fields */
#define O_CPU_GM_GPIO_DIRECTION_OUT_ENA 0
#define M_CPU_GM_GPIO_DIRECTION_OUT_ENA 0xffff

/* Target register R_CPU_GM_GPIO_OUT fields */
#define O_CPU_GM_GPIO_OUT_GPIO_OUT_DATA 0
#define M_CPU_GM_GPIO_OUT_GPIO_OUT_DATA 0xffff

/* Target register R_CPU_GM_GPIO_STATUS fields */
#define O_CPU_GM_GPIO_STATUS_STATUS 0
#define M_CPU_GM_GPIO_STATUS_STATUS 0xffff

/* Target register R_CPU_GM_GPIO_IN fields */
#define O_CPU_GM_GPIO_IN_GPIO_IN_DATA 0
#define M_CPU_GM_GPIO_IN_GPIO_IN_DATA 0xffff

/* Target register R_CPU_MWR_ACCESS fields */
#define O_CPU_MWR_ACCESS_MODULE_ID     0
#define M_CPU_MWR_ACCESS_MODULE_ID     0xff
#define O_CPU_MWR_ACCESS_REG_WR_DATA   8
#define M_CPU_MWR_ACCESS_REG_WR_DATA   0xff
#define O_CPU_MWR_ACCESS_REG_ADDR      16
#define M_CPU_MWR_ACCESS_REG_ADDR      0xff
#define O_CPU_MWR_ACCESS_ACCESS_TYPE   24
#define M_CPU_MWR_ACCESS_ACCESS_TYPE   0x1
#define O_CPU_MWR_ACCESS_WR_ERR_STICKY 25
#define M_CPU_MWR_ACCESS_WR_ERR_STICKY 0x1
#define O_CPU_MWR_ACCESS_WR_ERR        26
#define M_CPU_MWR_ACCESS_WR_ERR        0x1
#define O_CPU_MWR_ACCESS_WR_BUSY       27
#define M_CPU_MWR_ACCESS_WR_BUSY       0x1

/* Target register R_CPU_MWR_READ_RESULT fields */
#define O_CPU_MWR_READ_RESULT_REG_RD_DATA 0
#define M_CPU_MWR_READ_RESULT_REG_RD_DATA 0xff
#define O_CPU_MWR_READ_RESULT_RD_ERR      8
#define M_CPU_MWR_READ_RESULT_RD_ERR      0x1
#define O_CPU_MWR_READ_RESULT_RD_BUSY     9
#define M_CPU_MWR_READ_RESULT_RD_BUSY     0x1

/* Target register R_AR_LEAK_RATE_CFG_0 fields */
#define O_AR_LEAK_RATE_CFG_0_LB_LEAK_RATE_0 0
#define M_AR_LEAK_RATE_CFG_0_LB_LEAK_RATE_0 0x3f

/* Target register R_AR_LEAK_RATE_CFG_1 fields */
#define O_AR_LEAK_RATE_CFG_1_LB_LEAK_RATE_1 0
#define M_AR_LEAK_RATE_CFG_1_LB_LEAK_RATE_1 0x3f

/* Target register R_AR_LEAK_RATE_CFG_2 fields */
#define O_AR_LEAK_RATE_CFG_2_LB_LEAK_RATE_2 0
#define M_AR_LEAK_RATE_CFG_2_LB_LEAK_RATE_2 0x3f

/* Target register R_AR_LEAK_RATE_CFG_3 fields */
#define O_AR_LEAK_RATE_CFG_3_LB_LEAK_RATE_3 0
#define M_AR_LEAK_RATE_CFG_3_LB_LEAK_RATE_3 0x3f

/* Target register R_AR_LEAK_RATE_CFG_4 fields */
#define O_AR_LEAK_RATE_CFG_4_LB_LEAK_RATE_4 0
#define M_AR_LEAK_RATE_CFG_4_LB_LEAK_RATE_4 0x3f

/* Target register R_AR_LEAK_RATE_CFG_5 fields */
#define O_AR_LEAK_RATE_CFG_5_LB_LEAK_RATE_5 0
#define M_AR_LEAK_RATE_CFG_5_LB_LEAK_RATE_5 0x3f

/* Target register R_AR_LEAK_RATE_CFG_6 fields */
#define O_AR_LEAK_RATE_CFG_6_LB_LEAK_RATE_6 0
#define M_AR_LEAK_RATE_CFG_6_LB_LEAK_RATE_6 0x3f

/* Target register R_AR_LEAK_RATE_CFG_7 fields */
#define O_AR_LEAK_RATE_CFG_7_LB_LEAK_RATE_7 0
#define M_AR_LEAK_RATE_CFG_7_LB_LEAK_RATE_7 0x3f

/* Target register R_AR_CONG_MODE_CFG fields */
#define O_AR_CONG_MODE_CFG_CONG_SUSPEND 0
#define M_AR_CONG_MODE_CFG_CONG_SUSPEND 0x1

/* Target register R_AR_CONG_IGNORE_CFG fields */
#define O_AR_CONG_IGNORE_CFG_CONG_IGNORE 0
#define M_AR_CONG_IGNORE_CFG_CONG_IGNORE 0xffffffff

/* Target register R_AR_RX_CONG_IGNORE_CFG fields */
#define O_AR_RX_CONG_IGNORE_CFG_RX_CONG_IGNORE 0
#define M_AR_RX_CONG_IGNORE_CFG_RX_CONG_IGNORE 0xffffffff

/* Target register R_AR_SRC_DISABLE_CFG fields */
#define O_AR_SRC_DISABLE_CFG_DBG_SRC_DISABLE 0
#define M_AR_SRC_DISABLE_CFG_DBG_SRC_DISABLE 0xff

/* Target register R_AR_DEST_DISABLE_CFG fields */
#define O_AR_DEST_DISABLE_CFG_DBG_DEST_DISABLE 0
#define M_AR_DEST_DISABLE_CFG_DBG_DEST_DISABLE 0x3ffff

/* Target register R_AR_DEST_ACTIVE_STICKY fields */
#define O_AR_DEST_ACTIVE_STICKY_DEST_ACTIVE 0
#define M_AR_DEST_ACTIVE_STICKY_DEST_ACTIVE 0x1ff

/* Target register R_AR_SRC_ACTIVE_STICKY fields */
#define O_AR_SRC_ACTIVE_STICKY_SRC_ACTIVE 0
#define M_AR_SRC_ACTIVE_STICKY_SRC_ACTIVE 0xff

/* Target register R_AR_REQ_OVERFL_STICKY fields */
#define O_AR_REQ_OVERFL_STICKY_DBG_REQ_OVERFL 0
#define M_AR_REQ_OVERFL_STICKY_DBG_REQ_OVERFL 0xffffffff

/* Target register R_AR_REQ_EMPTY_STICKY fields */
#define O_AR_REQ_EMPTY_STICKY_DBG_REQ_EMPTY 0
#define M_AR_REQ_EMPTY_STICKY_DBG_REQ_EMPTY 0xffffffff

/* Target register R_AR_TX_CONG_STICKY fields */
#define O_AR_TX_CONG_STICKY_DBG_TX_CONG 0          /* Gatwick-Ie only */
#define M_AR_TX_CONG_STICKY_DBG_TX_CONG 0xffffffff /* Gatwick-Ie only */

/* Target register R_AR_RX_CONG_STICKY fields */
#define O_AR_RX_CONG_STICKY_DBG_RX_CONG 0          /* Gatwick-Ie only */
#define M_AR_RX_CONG_STICKY_DBG_RX_CONG 0xffffffff /* Gatwick-Ie only */

/* Target register R_AR_INTERVAL_CFG fields */
#define O_AR_INTERVAL_CFG_INTERVAL    0      /* Gatwick-Ie only */
#define M_AR_INTERVAL_CFG_INTERVAL    0xffff /* Gatwick-Ie only */
#define O_AR_INTERVAL_CFG_RANDOM_MODE 30     /* Gatwick-Ie only */
#define M_AR_INTERVAL_CFG_RANDOM_MODE 0x1    /* Gatwick-Ie only */
#define O_AR_INTERVAL_CFG_RANDOM_ENA  31     /* Gatwick-Ie only */
#define M_AR_INTERVAL_CFG_RANDOM_ENA  0x1    /* Gatwick-Ie only */

/* Target register R_AR_POLYNOM_CFG_0 fields */
#define O_AR_POLYNOM_CFG_0_POLYNOM_CFG 0      /* Gatwick-Ie only */
#define M_AR_POLYNOM_CFG_0_POLYNOM_CFG 0xffff /* Gatwick-Ie only */

/* Target register R_AR_POLYNOM_CFG_1 fields */
#define O_AR_POLYNOM_CFG_1_POLYNOM_CFG 0      /* Gatwick-Ie only */
#define M_AR_POLYNOM_CFG_1_POLYNOM_CFG 0xffff /* Gatwick-Ie only */

/* Target register R_AR_POLYNOM_CFG_2 fields */
#define O_AR_POLYNOM_CFG_2_POLYNOM_CFG 0      /* Gatwick-Ie only */
#define M_AR_POLYNOM_CFG_2_POLYNOM_CFG 0xffff /* Gatwick-Ie only */

/* Target register R_AR_PATCH_CFG fields */
#define O_AR_PATCH_CFG_SUB_PORT_ARB_REV_A_ENA 0   /* Gatwick-Ie only */
#define M_AR_PATCH_CFG_SUB_PORT_ARB_REV_A_ENA 0x1 /* Gatwick-Ie only */
#define O_AR_PATCH_CFG_DROP_ON_RX_CONG        1   /* Gatwick-Ie only */
#define M_AR_PATCH_CFG_DROP_ON_RX_CONG        0x1 /* Gatwick-Ie only */
#define O_AR_PATCH_CFG_NO_ZERO_DEST_RATE_INC  2   /* Gatwick-Ie only */
#define M_AR_PATCH_CFG_NO_ZERO_DEST_RATE_INC  0x1 /* Gatwick-Ie only */
#define O_AR_PATCH_CFG_ZERO_DEST_LAST_ENA     3   /* Gatwick-Ie only */
#define M_AR_PATCH_CFG_ZERO_DEST_LAST_ENA     0x1 /* Gatwick-Ie only */

/* Target register R_AR_ZERO_DEST_CNT fields */
#define O_AR_ZERO_DEST_CNT_AR_ZERO_DEST_CNT 0          /* Gatwick-Ie only */
#define M_AR_ZERO_DEST_CNT_AR_ZERO_DEST_CNT 0xffffffff /* Gatwick-Ie only */

/* Target register R_AN_RL_L3_RL_CTRL fields */
#define O_AN_RL_L3_RL_CTRL_RL_INDEX_GW1E 0    /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CTRL_RL_INDEX_GW1E 0x1f
#define O_AN_RL_L3_RL_CTRL_RL_INDEX_GW1  0    /* Not Gatwick-Ie */
#define M_AN_RL_L3_RL_CTRL_RL_INDEX_GW1  0x7f /* Not Gatwick-Ie */
#define O_AN_RL_L3_RL_CTRL_RL_CMD        7
#define M_AN_RL_L3_RL_CTRL_RL_CMD        0x3

/* Target register R_AN_RL_L3_RL_CFG_1 fields */
#define O_AN_RL_L3_RL_CFG_1_L3MC_ENA_GW1E 0     /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CFG_1_L3MC_ENA_GW1E 0x1   /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CFG_1_VRRP_ENA      1     /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CFG_1_VRRP_ENA      0x1   /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CFG_1_VRID0         16    /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CFG_1_VRID0         0xff  /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CFG_1_VRID1         24    /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CFG_1_VRID1         0xff  /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CFG_1_RL_VALID      0     /* Not Gatwick-Ie */
#define M_AN_RL_L3_RL_CFG_1_RL_VALID      0x1   /* Not Gatwick-Ie */
#define O_AN_RL_L3_RL_CFG_1_VID           1     /* Not Gatwick-Ie */
#define M_AN_RL_L3_RL_CFG_1_VID           0xfff /* Not Gatwick-Ie */
#define O_AN_RL_L3_RL_CFG_1_IRLID         13    /* Not Gatwick-Ie */
#define M_AN_RL_L3_RL_CFG_1_IRLID         0x1f  /* Not Gatwick-Ie */
#define O_AN_RL_L3_RL_CFG_1_L3MC_ENA_GW1  18    /* Not Gatwick-Ie */
#define M_AN_RL_L3_RL_CFG_1_L3MC_ENA_GW1  0x1   /* Not Gatwick-Ie */

/* Target register R_AN_RL_L3_RL_CFG_2 fields */
#define O_AN_RL_L3_RL_CFG_2_DMAC_LSB 0
#define M_AN_RL_L3_RL_CFG_2_DMAC_LSB 0xffffffff

/* Target register R_AN_RL_L3_RL_CFG_3 fields */
#define O_AN_RL_L3_RL_CFG_3_DMAC_MSB 0
#define M_AN_RL_L3_RL_CFG_3_DMAC_MSB 0xffff

/* Target register R_AN_RL_L3_RL_PORT_MAP_CTRL fields */
#define O_AN_RL_L3_RL_PORT_MAP_CTRL_PHYS_PORT_INDEX 0
#define M_AN_RL_L3_RL_PORT_MAP_CTRL_PHYS_PORT_INDEX 0x1f
#define O_AN_RL_L3_RL_PORT_MAP_CTRL_PORT_TABLE_CMD  5
#define M_AN_RL_L3_RL_PORT_MAP_CTRL_PORT_TABLE_CMD  0x3

/* Target register R_AN_RL_L3_RL_PORT_MAP_CFG fields */
#define O_AN_RL_L3_RL_PORT_MAP_CFG_LOGICAL_PORT_NUM 0
#define M_AN_RL_L3_RL_PORT_MAP_CFG_LOGICAL_PORT_NUM 0x1f
#define O_AN_RL_L3_RL_PORT_MAP_CFG_GLAG_NUM         8    /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_PORT_MAP_CFG_GLAG_NUM         0xff /* Gatwick-Ie only */

/* Target register R_AN_RL_L3_RL_PROTO_CTRL fields */
#define O_AN_RL_L3_RL_PROTO_CTRL_BPDU_REDIR_ENA         0   /* Not Gatwick-Ie */
#define M_AN_RL_L3_RL_PROTO_CTRL_BPDU_REDIR_ENA         0x1 /* Not Gatwick-Ie */
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_BPDU         1
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_BPDU         0xf
#define O_AN_RL_L3_RL_PROTO_CTRL_IP_MC_CTRL_COPY_ENA    5
#define M_AN_RL_L3_RL_PROTO_CTRL_IP_MC_CTRL_COPY_ENA    0x1
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_MC_CTRL   6
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_MC_CTRL   0xf
#define O_AN_RL_L3_RL_PROTO_CTRL_IGMP_REDIR_ENA         10
#define M_AN_RL_L3_RL_PROTO_CTRL_IGMP_REDIR_ENA         0x1
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IGMP_REDIR   11
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IGMP_REDIR   0xf
#define O_AN_RL_L3_RL_PROTO_CTRL_IP_OPT_REDIR_ENA       15
#define M_AN_RL_L3_RL_PROTO_CTRL_IP_OPT_REDIR_ENA       0x1
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_OPT_REDIR 16
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_OPT_REDIR 0xf
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_HDR_FAIL  20
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_IP_HDR_FAIL  0xf
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_RL           24
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_RL           0xf
#define O_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_MAC_CTRL     28
#define M_AN_RL_L3_RL_PROTO_CTRL_CPU_QUEUE_MAC_CTRL     0xf

/* Target register R_AN_RL_L3_RL_CUSTOM_REDIR_CTRL fields */
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_GXRP_REDIR_ENA          0
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_GXRP_REDIR_ENA          0xffff
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_REQ_DMAC_MOVE_ENA       16
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_REQ_DMAC_MOVE_ENA       0x1
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_MAC_CTRL_REDIR_ENA      17
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_MAC_CTRL_REDIR_ENA      0x1
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_IP_MC_TTL_COPY_ENA      18
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_IP_MC_TTL_COPY_ENA      0x1
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_IP_MC_TTL_L3_ENA        19
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_IP_MC_TTL_L3_ENA        0x1
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_ALL_BC_COPY_ENA      20  /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_ALL_BC_COPY_ENA      0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_SELECTED_BC_COPY_ENA 21  /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_RL_SELECTED_BC_COPY_ENA 0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_SELECTED_BC_COPY_ENA    22  /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_SELECTED_BC_COPY_ENA    0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_CPU_QUEUE_SELECTED_BC   24  /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_CUSTOM_REDIR_CTRL_CPU_QUEUE_SELECTED_BC   0xf /* Gatwick-Ie only */

/* Target register R_AN_RL_L3_RL_DMAC_PAT_LSB_CFG fields */
#define O_AN_RL_L3_RL_DMAC_PAT_LSB_CFG_CPU_REQ_DMAC_ADDR_LSB 0
#define M_AN_RL_L3_RL_DMAC_PAT_LSB_CFG_CPU_REQ_DMAC_ADDR_LSB 0xffffffff

/* Target register R_AN_RL_L3_RL_DMAC_PAT_MSB_CFG fields */
#define O_AN_RL_L3_RL_DMAC_PAT_MSB_CFG_CPU_REQ_DMAC_ADDR_MSB 0
#define M_AN_RL_L3_RL_DMAC_PAT_MSB_CFG_CPU_REQ_DMAC_ADDR_MSB 0xffff

/* Target register R_AN_RL_L3_RL_DMAC_MASK_LSB_CFG fields */
#define O_AN_RL_L3_RL_DMAC_MASK_LSB_CFG_CPU_REQ_DMAC_MASK_LSB 0
#define M_AN_RL_L3_RL_DMAC_MASK_LSB_CFG_CPU_REQ_DMAC_MASK_LSB 0xffffffff

/* Target register R_AN_RL_L3_RL_DMAC_MASK_MSB_CFG fields */
#define O_AN_RL_L3_RL_DMAC_MASK_MSB_CFG_CPU_REQ_DMAC_MASK_MSB 0
#define M_AN_RL_L3_RL_DMAC_MASK_MSB_CFG_CPU_REQ_DMAC_MASK_MSB 0xffff

/* Target register R_AN_RL_L3_RL_STICKY fields */
#define O_AN_RL_L3_RL_STICKY_RL_CMD_PROCESSED            0
#define M_AN_RL_L3_RL_STICKY_RL_CMD_PROCESSED            0x1
#define O_AN_RL_L3_RL_STICKY_PORT_TABLE_CMD_PROCESSED    1
#define M_AN_RL_L3_RL_STICKY_PORT_TABLE_CMD_PROCESSED    0x1
#define O_AN_RL_L3_RL_STICKY_MAC_CTRL_REDIR_EVENT        2
#define M_AN_RL_L3_RL_STICKY_MAC_CTRL_REDIR_EVENT        0x1
#define O_AN_RL_L3_RL_STICKY_BPDU_REDIR_EVENT            3
#define M_AN_RL_L3_RL_STICKY_BPDU_REDIR_EVENT            0x1
#define O_AN_RL_L3_RL_STICKY_GARP_REDIR_EVENT            4
#define M_AN_RL_L3_RL_STICKY_GARP_REDIR_EVENT            0x1
#define O_AN_RL_L3_RL_STICKY_DMAC_REDIR_EVENT            5
#define M_AN_RL_L3_RL_STICKY_DMAC_REDIR_EVENT            0x1
#define O_AN_RL_L3_RL_STICKY_IGMP_REDIR_EVENT            6
#define M_AN_RL_L3_RL_STICKY_IGMP_REDIR_EVENT            0x1
#define O_AN_RL_L3_RL_STICKY_IP_CTRL_MATCH_EVENT         7
#define M_AN_RL_L3_RL_STICKY_IP_CTRL_MATCH_EVENT         0x1
#define O_AN_RL_L3_RL_STICKY_RL_UC_IP_VALID_REDIR_EVENT  8
#define M_AN_RL_L3_RL_STICKY_RL_UC_IP_VALID_REDIR_EVENT  0x1
#define O_AN_RL_L3_RL_STICKY_RL_UC_HDR_ERR_REDIR_EVENT   9
#define M_AN_RL_L3_RL_STICKY_RL_UC_HDR_ERR_REDIR_EVENT   0x1
#define O_AN_RL_L3_RL_STICKY_RL_UC_IP_OPTION_REDIR_EVENT 10
#define M_AN_RL_L3_RL_STICKY_RL_UC_IP_OPTION_REDIR_EVENT 0x1
#define O_AN_RL_L3_RL_STICKY_RL_UC_HIT_EVENT             11
#define M_AN_RL_L3_RL_STICKY_RL_UC_HIT_EVENT             0x1
#define O_AN_RL_L3_RL_STICKY_RL_MC_HDR_ERR_REDIR_EVENT   12
#define M_AN_RL_L3_RL_STICKY_RL_MC_HDR_ERR_REDIR_EVENT   0x1
#define O_AN_RL_L3_RL_STICKY_RL_MC_IP_OPTION_REDIR_EVENT 13
#define M_AN_RL_L3_RL_STICKY_RL_MC_IP_OPTION_REDIR_EVENT 0x1
#define O_AN_RL_L3_RL_STICKY_RL_MC_TTL_EVENT             14
#define M_AN_RL_L3_RL_STICKY_RL_MC_TTL_EVENT             0x1
#define O_AN_RL_L3_RL_STICKY_RL_MC_HIT_EVENT             15
#define M_AN_RL_L3_RL_STICKY_RL_MC_HIT_EVENT             0x1
#define O_AN_RL_L3_RL_STICKY_L2_FWD_EVENT                16
#define M_AN_RL_L3_RL_STICKY_L2_FWD_EVENT                0x1
#define O_AN_RL_L3_RL_STICKY_RL_RAM_INTGR_ERR            17
#define M_AN_RL_L3_RL_STICKY_RL_RAM_INTGR_ERR            0x1
#define O_AN_RL_L3_RL_STICKY_STACKING_MIRROR_RECEIVED    18  /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_STICKY_STACKING_MIRROR_RECEIVED    0x1 /* Gatwick-Ie only */

/* Target register R_AN_RL_L3_L3_COMMON_CFG fields */
#define O_AN_RL_L3_L3_COMMON_CFG_L3_ENA 0
#define M_AN_RL_L3_L3_COMMON_CFG_L3_ENA 0x1

/* Target register R_AN_RL_L3_L3_VLAN_CTRL fields */
#define O_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA   0
#define M_AN_RL_L3_L3_VLAN_CTRL_VLAN_ENA   0x1
#define O_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX 1
#define M_AN_RL_L3_L3_VLAN_CTRL_VLAN_INDEX 0xfff
#define O_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD   13
#define M_AN_RL_L3_L3_VLAN_CTRL_VLAN_CMD   0x3

/* Target register R_AN_RL_L3_L3_VLAN_CFG_1 fields */
#define O_AN_RL_L3_L3_VLAN_CFG_1_VALID         0
#define M_AN_RL_L3_L3_VLAN_CFG_1_VALID         0x1
#define O_AN_RL_L3_L3_VLAN_CFG_1_MIRROR        1
#define M_AN_RL_L3_L3_VLAN_CFG_1_MIRROR        0x1
#define O_AN_RL_L3_L3_VLAN_CFG_1_LRN_DIS       2    /* Gatwick-Ie only */ 
#define M_AN_RL_L3_L3_VLAN_CFG_1_LRN_DIS       0x1  /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_VLAN_CFG_1_RL_ENA        3    /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_VLAN_CFG_1_RL_ENA        0x1  /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_VLAN_CFG_1_MSTP_PTR_GW1E 16   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_VLAN_CFG_1_MSTP_PTR_GW1E 0x7f /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_VLAN_CFG_1_RLID          24   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_VLAN_CFG_1_RLID          0x1f /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_VLAN_CFG_1_MSTP_PTR_GW1  2    /* Not Gatwick-Ie */
#define M_AN_RL_L3_L3_VLAN_CFG_1_MSTP_PTR_GW1  0xf  /* Not Gatwick-Ie */

/* Target register R_AN_RL_L3_L3_VLAN_CFG_2 fields */
#define O_AN_RL_L3_L3_VLAN_CFG_2_PORT_MASK 0
#define M_AN_RL_L3_L3_VLAN_CFG_2_PORT_MASK 0xffffffff

/* Target register R_AN_RL_L3_L3_MSTP_CTRL fields */
#define O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1E 0    /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1E 0x3  /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1E     2    /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1E     0x3f /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1      0    /* Not Gatwick-Ie */
#define M_AN_RL_L3_L3_MSTP_CTRL_MSTP_INDEX_GW1      0xf  /* Not Gatwick-Ie */
#define O_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1  4    /* Not Gatwick-Ie */
#define M_AN_RL_L3_L3_MSTP_CTRL_MSTP_TABLE_CMD_GW1  0x3  /* Not Gatwick-Ie */

/* Target register R_AN_RL_L3_L3_MSTP_CFG_1 fields */
#define O_AN_RL_L3_L3_MSTP_CFG_1_MSTP_DATA_LEARN 0
#define M_AN_RL_L3_L3_MSTP_CFG_1_MSTP_DATA_LEARN 0xffffffff

/* Target register R_AN_RL_L3_L3_MSTP_CFG_2 fields */
#define O_AN_RL_L3_L3_MSTP_CFG_2_MSTP_DATA_FWD 0
#define M_AN_RL_L3_L3_MSTP_CFG_2_MSTP_DATA_FWD 0xffffffff

/* Target register R_AN_RL_L3_L3_VLAN_FILT_CTRL fields */
#define O_AN_RL_L3_L3_VLAN_FILT_CTRL_VLAN_FILT_ENA 0
#define M_AN_RL_L3_L3_VLAN_FILT_CTRL_VLAN_FILT_ENA 0xffffffff

/* Target register R_AN_RL_L3_L3_INGRESS_FILTER_DISCARD_CNT fields */
#define O_AN_RL_L3_L3_INGRESS_FILTER_DISCARD_CNT_INGRESS_PKT_DISCARD 0
#define M_AN_RL_L3_L3_INGRESS_FILTER_DISCARD_CNT_INGRESS_PKT_DISCARD 0xffffffff

/* Target register R_AN_RL_L3_L3_CAM_CTRL fields */
#define O_AN_RL_L3_L3_CAM_CTRL_CAM_INDEX 0
#define M_AN_RL_L3_L3_CAM_CTRL_CAM_INDEX 0x3f
#define O_AN_RL_L3_L3_CAM_CTRL_CAM_CMD   6
#define M_AN_RL_L3_L3_CAM_CTRL_CAM_CMD   0x3

/* Target register R_AN_RL_L3_L3_CAM_CFG_1 fields */
#define O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_VALID      0
#define M_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_VALID      0x1
#define O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_PREFIX_LEN 1
#define M_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_PREFIX_LEN 0x3f
#define O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_SUB_LEN    7
#define M_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_SUB_LEN    0xf
#define O_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_BASE_PTR   11
#define M_AN_RL_L3_L3_CAM_CFG_1_CAM_DATA_BASE_PTR   0x1fff

/* Target register R_AN_RL_L3_L3_CAM_CFG_2 fields */
#define O_AN_RL_L3_L3_CAM_CFG_2_CAM_DATA_DIP 0
#define M_AN_RL_L3_L3_CAM_CFG_2_CAM_DATA_DIP 0xffffffff

/* Target register R_AN_RL_L3_L3_IP_CTRL fields */
#define O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW 0
#define M_AN_RL_L3_L3_IP_CTRL_IP_TABLE_ROW 0x7ff
#define O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL 11
#define M_AN_RL_L3_L3_IP_CTRL_IP_TABLE_COL 0x3
#define O_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD 13
#define M_AN_RL_L3_L3_IP_CTRL_IP_TABLE_CMD 0x7
#define O_AN_RL_L3_L3_IP_CTRL_MC_SIZE      16
#define M_AN_RL_L3_L3_IP_CTRL_MC_SIZE      0x1f

/* Target register R_AN_RL_L3_L3_UC_CFG_1 fields */
#define O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_VALID       0
#define M_AN_RL_L3_L3_UC_CFG_1_UC_DATA_VALID       0x1
#define O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLGID_GW1  1    /* Not Gatwick-Ie */
#define M_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLGID_GW1  0x1f /* Not Gatwick-Ie */
#define O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1E  1    /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1E  0x1f /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1   6    /* Not Gatwick-Ie */
#define M_AN_RL_L3_L3_UC_CFG_1_UC_DATA_ERLID_GW1   0x1f /* Not Gatwick-Ie */

/* Target register R_AN_RL_L3_L3_UC_CFG_2 fields */
#define O_AN_RL_L3_L3_UC_CFG_2_UC_DATA_DMAC_H 0
#define M_AN_RL_L3_L3_UC_CFG_2_UC_DATA_DMAC_H 0xffff

/* Target register R_AN_RL_L3_L3_UC_CFG_3 fields */
#define O_AN_RL_L3_L3_UC_CFG_3_UC_DATA_DMAC_L 0
#define M_AN_RL_L3_L3_UC_CFG_3_UC_DATA_DMAC_L 0xffffffff

/* Target register R_AN_RL_L3_L3_MC_CFG_1 fields */
#define O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_VALID        0
#define M_AN_RL_L3_L3_MC_CFG_1_MC_DATA_VALID        0x1
#define O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_RPF_CHK      1
#define M_AN_RL_L3_L3_MC_CFG_1_MC_DATA_RPF_CHK      0x1
#define O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_ERLGID       2
#define M_AN_RL_L3_L3_MC_CFG_1_MC_DATA_ERLGID       0x1f
#define O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_IRLID        7
#define M_AN_RL_L3_L3_MC_CFG_1_MC_DATA_IRLID        0x1f
#define O_AN_RL_L3_L3_MC_CFG_1_MC_DATA_PGID         12
#define M_AN_RL_L3_L3_MC_CFG_1_MC_DATA_PGID_GW1E    0x1ff /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_MC_CFG_1_MC_DATA_PGID_GW1     0xff  /* Not Gatwick-Ie */

/* Target register R_AN_RL_L3_L3_MC_CFG_2 fields */
#define O_AN_RL_L3_L3_MC_CFG_2_MC_DATA_DIP 0
#define M_AN_RL_L3_L3_MC_CFG_2_MC_DATA_DIP 0xfffffff

/* Target register R_AN_RL_L3_L3_MC_CFG_3 fields */
#define O_AN_RL_L3_L3_MC_CFG_3_MC_DATA_SIP 0
#define M_AN_RL_L3_L3_MC_CFG_3_MC_DATA_SIP 0xffffffff

/* Target register R_AN_RL_L3_L3_CPU_QUEUE_CFG fields */
#define O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_IP_TTL_FAIL   0
#define M_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_IP_TTL_FAIL   0xf
#define O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC_FAIL       4
#define M_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC_FAIL       0xf
#define O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_MC_FAIL       8
#define M_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_MC_FAIL       0xf
#define O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC_SECUR_FAIL 12
#define M_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC_SECUR_FAIL 0xf
#define O_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC            16
#define M_AN_RL_L3_L3_CPU_QUEUE_CFG_CPU_QUEUE_UC            0xf

/* Target register R_AN_RL_L3_L3_SECUR_CTRL fields */
#define O_AN_RL_L3_L3_SECUR_CTRL_UC_SECUR_TABLE_INDEX 0
#define M_AN_RL_L3_L3_SECUR_CTRL_UC_SECUR_TABLE_INDEX 0x1f
#define O_AN_RL_L3_L3_SECUR_CTRL_UC_SECUR_TABLE_CMD   5
#define M_AN_RL_L3_L3_SECUR_CTRL_UC_SECUR_TABLE_CMD   0x3
#define O_AN_RL_L3_L3_SECUR_CTRL_UC_SECUR_ENA         7
#define M_AN_RL_L3_L3_SECUR_CTRL_UC_SECUR_ENA         0x1

/* Target register R_AN_RL_L3_L3_SECUR_CFG fields */
#define O_AN_RL_L3_L3_SECUR_CFG_UC_SECUR_TABLE_ERLID_ALLOW 0
#define M_AN_RL_L3_L3_SECUR_CFG_UC_SECUR_TABLE_ERLID_ALLOW 0xffffffff

/* Target register R_AN_RL_L3_L3_ICMP_CTRL fields */
#define O_AN_RL_L3_L3_ICMP_CTRL_ICMP_REDIR_ENA 0
#define M_AN_RL_L3_L3_ICMP_CTRL_ICMP_REDIR_ENA 0xffffffff

/* Target register R_AN_RL_L3_L3_ERLID_CTRL fields */
#define O_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_INDEX 0
#define M_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_INDEX 0x1f
#define O_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_CMD   5
#define M_AN_RL_L3_L3_ERLID_CTRL_ERLID_TABLE_CMD   0x3

/* Target register R_AN_RL_L3_L3_ERLID_CFG fields */
#define O_AN_RL_L3_L3_ERLID_CFG_ERLID_VID 0
#define M_AN_RL_L3_L3_ERLID_CFG_ERLID_VID 0xfff

/* Target register R_AN_RL_L3_L3_STICKY_0 fields */
#define O_AN_RL_L3_L3_STICKY_0_IP_CPU_CMD_PROCESSED          0
#define M_AN_RL_L3_L3_STICKY_0_IP_CPU_CMD_PROCESSED          0x1
#define O_AN_RL_L3_L3_STICKY_0_VLAN_CMD_PROCESSED            1
#define M_AN_RL_L3_L3_STICKY_0_VLAN_CMD_PROCESSED            0x1
#define O_AN_RL_L3_L3_STICKY_0_MSTP_TABLE_CMD_PROCESSED      2
#define M_AN_RL_L3_L3_STICKY_0_MSTP_TABLE_CMD_PROCESSED      0x1
#define O_AN_RL_L3_L3_STICKY_0_CAM_CMD_PROCESSED             3
#define M_AN_RL_L3_L3_STICKY_0_CAM_CMD_PROCESSED             0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_SECUR_TABLE_CMD_PROCESSED  4
#define M_AN_RL_L3_L3_STICKY_0_UC_SECUR_TABLE_CMD_PROCESSED  0x1
#define O_AN_RL_L3_L3_STICKY_0_VLAN_LOOKUP_INVALID_EVENT     5
#define M_AN_RL_L3_L3_STICKY_0_VLAN_LOOKUP_INVALID_EVENT     0x1
#define O_AN_RL_L3_L3_STICKY_0_VLAN_SRC_FILTER_EVENT         6
#define M_AN_RL_L3_L3_STICKY_0_VLAN_SRC_FILTER_EVENT         0x1
#define O_AN_RL_L3_L3_STICKY_0_VLAN_REPLACED_EVENT           7
#define M_AN_RL_L3_L3_STICKY_0_VLAN_REPLACED_EVENT           0x1
#define O_AN_RL_L3_L3_STICKY_0_MSTP_LEARN_ALLOWED_EVENT      8
#define M_AN_RL_L3_L3_STICKY_0_MSTP_LEARN_ALLOWED_EVENT      0x1
#define O_AN_RL_L3_L3_STICKY_0_MSTP_FWD_FILTER_EVENT         9
#define M_AN_RL_L3_L3_STICKY_0_MSTP_FWD_FILTER_EVENT         0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_LONGEST_PREFIX_FOUND_EVENT 10
#define M_AN_RL_L3_L3_STICKY_0_UC_LONGEST_PREFIX_FOUND_EVENT 0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_ENTRY_FOUND_EVENT          11
#define M_AN_RL_L3_L3_STICKY_0_UC_ENTRY_FOUND_EVENT          0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_ZERO_DMAC_FOUND_EVENT      12
#define M_AN_RL_L3_L3_STICKY_0_UC_ZERO_DMAC_FOUND_EVENT      0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_ICMP_REDIR_EVENT           13
#define M_AN_RL_L3_L3_STICKY_0_UC_ICMP_REDIR_EVENT           0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_SECUR_REDIR_EVENT          14
#define M_AN_RL_L3_L3_STICKY_0_UC_SECUR_REDIR_EVENT          0x1
#define O_AN_RL_L3_L3_STICKY_0_UC_TTL_FILTERING_EVENT        15
#define M_AN_RL_L3_L3_STICKY_0_UC_TTL_FILTERING_EVENT        0x1
#define O_AN_RL_L3_L3_STICKY_0_MC_ENTRY_NOT_FOUND_EVENT      16
#define M_AN_RL_L3_L3_STICKY_0_MC_ENTRY_NOT_FOUND_EVENT      0x1
#define O_AN_RL_L3_L3_STICKY_0_MC_RPF_FILTER_EVENT           17
#define M_AN_RL_L3_L3_STICKY_0_MC_RPF_FILTER_EVENT           0x1
#define O_AN_RL_L3_L3_STICKY_0_MC_FWD_EVENT                  18
#define M_AN_RL_L3_L3_STICKY_0_MC_FWD_EVENT                  0x1
#define O_AN_RL_L3_L3_STICKY_0_CPU_LATEST_MC_ROW_ACC         19
#define M_AN_RL_L3_L3_STICKY_0_CPU_LATEST_MC_ROW_ACC         0x7ff
#define O_AN_RL_L3_L3_STICKY_0_CPU_LATEST_MC_COL_ACC         30
#define M_AN_RL_L3_L3_STICKY_0_CPU_LATEST_MC_COL_ACC         0x3

/* Target register R_AN_RL_L3_L3_STICKY_1 fields */
#define O_AN_RL_L3_L3_STICKY_1_IP_RAM_INTGR_ERR           0
#define M_AN_RL_L3_L3_STICKY_1_IP_RAM_INTGR_ERR           0x1
#define O_AN_RL_L3_L3_STICKY_1_VLAN_RAM_INTGR_ERR         1
#define M_AN_RL_L3_L3_STICKY_1_VLAN_RAM_INTGR_ERR         0x1
#define O_AN_RL_L3_L3_STICKY_1_IRLID_CNT_CMD_PROCESSED    2
#define M_AN_RL_L3_L3_STICKY_1_IRLID_CNT_CMD_PROCESSED    0x1
#define O_AN_RL_L3_L3_STICKY_1_ERLID_CNT_CMD_PROCESSED    3
#define M_AN_RL_L3_L3_STICKY_1_ERLID_CNT_CMD_PROCESSED    0x1
#define O_AN_RL_L3_L3_STICKY_1_VLAN_MASK_VALID            4   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_STICKY_1_VLAN_MASK_VALID            0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_STICKY_1_SECOND_VLAN_LOOKUP_INVALID 5   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_STICKY_1_SECOND_VLAN_LOOKUP_INVALID 0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_STICKY_1_NON_ZERO_GLAG_SET          6   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_STICKY_1_NON_ZERO_GLAG_SET          0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_STICKY_1_NON_ZERO_GLAG_RECEIVED     7   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_STICKY_1_NON_ZERO_GLAG_RECEIVED     0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_STICKY_1_MSTP_RAM_INTGR_ERR         8   /* Gatwick-Ie only */
#define M_AN_RL_L3_L3_STICKY_1_MSTP_RAM_INTGR_ERR         0x1 /* Gatwick-Ie only */
#define O_AN_RL_L3_L3_STICKY_1_ERLID_TABLE_CMD_PROCESSED  4   /* Not Gatwick-Ie */
#define M_AN_RL_L3_L3_STICKY_1_ERLID_TABLE_CMD_PROCESSED  0x1 /* Not Gatwick-Ie */

/* Target register R_AN_RL_L3_L3_IP_PKT_RECEIVED_CNT fields */
#define O_AN_RL_L3_L3_IP_PKT_RECEIVED_CNT_IP_PKT_RECEIVED 0
#define M_AN_RL_L3_L3_IP_PKT_RECEIVED_CNT_IP_PKT_RECEIVED 0xffffffff

/* Target register R_AN_RL_L3_L3_IP_UC_FWD_CNT fields */
#define O_AN_RL_L3_L3_IP_UC_FWD_CNT_IP_UC_PKT_FWD 0
#define M_AN_RL_L3_L3_IP_UC_FWD_CNT_IP_UC_PKT_FWD 0xffffffff

/* Target register R_AN_RL_L3_L3_IP_NON_UC_FWD_CNT fields */
#define O_AN_RL_L3_L3_IP_NON_UC_FWD_CNT_IP_NON_UC_PKT_FWD 0
#define M_AN_RL_L3_L3_IP_NON_UC_FWD_CNT_IP_NON_UC_PKT_FWD 0xffffffff

/* Target register R_AN_RL_L3_L3_IRLID_CNT_CTRL fields */
#define O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_INDEX     0
#define M_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_INDEX     0x1f
#define O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_SELECTION 5
#define M_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_SELECTION 0xf
#define O_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_CMD       9
#define M_AN_RL_L3_L3_IRLID_CNT_CTRL_IRLID_CNT_CMD       0x7

/* Target register R_AN_RL_L3_L3_IRLID_UC_PKT_CNT fields */
#define O_AN_RL_L3_L3_IRLID_UC_PKT_CNT_IRLID_UC_PKT 0
#define M_AN_RL_L3_L3_IRLID_UC_PKT_CNT_IRLID_UC_PKT 0xffffffff

/* Target register R_AN_RL_L3_L3_IRLID_NON_UC_PKT_CNT fields */
#define O_AN_RL_L3_L3_IRLID_NON_UC_PKT_CNT_IRLID_NON_UC_PKT 0
#define M_AN_RL_L3_L3_IRLID_NON_UC_PKT_CNT_IRLID_NON_UC_PKT 0xffffffff

/* Target register R_AN_RL_L3_L3_IRLID_MC_RPF_FAIL_PKT_CNT fields */
#define O_AN_RL_L3_L3_IRLID_MC_RPF_FAIL_PKT_CNT_IRLID_MC_RPF_FAIL_PKT 0
#define M_AN_RL_L3_L3_IRLID_MC_RPF_FAIL_PKT_CNT_IRLID_MC_RPF_FAIL_PKT 0xffffffff

/* Target register R_AN_RL_L3_L3_IRLID_OCTETS_MSB_CNT fields */
#define O_AN_RL_L3_L3_IRLID_OCTETS_MSB_CNT_IRLID_OCTETS_MSB 0
#define M_AN_RL_L3_L3_IRLID_OCTETS_MSB_CNT_IRLID_OCTETS_MSB 0xffffffff

/* Target register R_AN_RL_L3_L3_IRLID_OCTETS_LSB_CNT fields */
#define O_AN_RL_L3_L3_IRLID_OCTETS_LSB_CNT_IRLID_OCTETS_LSB 0
#define M_AN_RL_L3_L3_IRLID_OCTETS_LSB_CNT_IRLID_OCTETS_LSB 0xffffffff

/* Target register R_AN_RL_L3_L3_ERLID_CNT_CTRL fields */
#define O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_INDEX     0
#define M_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_INDEX     0x1f
#define O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_SELECTION 5
#define M_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_SELECTION 0x3
#define O_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_CMD       7
#define M_AN_RL_L3_L3_ERLID_CNT_CTRL_ERLID_CNT_CMD       0x7

/* Target register R_AN_RL_L3_L3_ERLID_UC_PKT_CNT fields */
#define O_AN_RL_L3_L3_ERLID_UC_PKT_CNT_ERLID_UC_PKT 0
#define M_AN_RL_L3_L3_ERLID_UC_PKT_CNT_ERLID_UC_PKT 0xffffffff

/* Target register R_AN_RL_L3_L3_ERLID_UC_OCTETS_MSB_CNT fields */
#define O_AN_RL_L3_L3_ERLID_UC_OCTETS_MSB_CNT_ERLID_UC_OCTETS_MSB 0
#define M_AN_RL_L3_L3_ERLID_UC_OCTETS_MSB_CNT_ERLID_UC_OCTETS_MSB 0xffffffff

/* Target register R_AN_RL_L3_L3_ERLID_UC_OCTETS_LSB_CNT fields */
#define O_AN_RL_L3_L3_ERLID_UC_OCTETS_LSB_CNT_ERLID_UC_OCTETS_LSB 0
#define M_AN_RL_L3_L3_ERLID_UC_OCTETS_LSB_CNT_ERLID_UC_OCTETS_LSB 0xffffffff

/* Target register R_AN_RL_L3_L3_SECUR_FAIL_PKT_CNT fields */
#define O_AN_RL_L3_L3_SECUR_FAIL_PKT_CNT_UC_SECUR_FAIL_PKT 0
#define M_AN_RL_L3_L3_SECUR_FAIL_PKT_CNT_UC_SECUR_FAIL_PKT 0xffffffff

/* Target register R_AN_RL_L3_RL_VRRP_CFG_0 fields */
#define O_AN_RL_L3_RL_VRRP_CFG_0_VRRP_MAC_MSB 0      /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_VRRP_CFG_0_VRRP_MAC_MSB 0xffff /* Gatwick-Ie only */

/* Target register R_AN_RL_L3_RL_VRRP_CFG_1 fields */
#define O_AN_RL_L3_RL_VRRP_CFG_1_VRRP_MAC_LSB 8        /* Gatwick-Ie only */
#define M_AN_RL_L3_RL_VRRP_CFG_1_VRRP_MAC_LSB 0xffffff /* Gatwick-Ie only */

/* Target register R_AN_RL_L3_BPDU_REDIR_CTRL fields */
#define O_AN_RL_L3_BPDU_REDIR_CTRL_BPDU_REDIR_ENA 0      /* Gatwick-Ie only */
#define M_AN_RL_L3_BPDU_REDIR_CTRL_BPDU_REDIR_ENA 0xffff /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_L2_MAIN_CFG fields */
#define O_AN_L2_PS_L2_MAIN_CFG_L2_FORW_ENA         0
#define M_AN_L2_PS_L2_MAIN_CFG_L2_FORW_ENA         0x1
#define O_AN_L2_PS_L2_MAIN_CFG_FORW_CPU_COPY_QUEUE 1
#define M_AN_L2_PS_L2_MAIN_CFG_FORW_CPU_COPY_QUEUE 0xf
#define O_AN_L2_PS_L2_MAIN_CFG_L2_LEARN_ENA        5
#define M_AN_L2_PS_L2_MAIN_CFG_L2_LEARN_ENA        0x1
#define O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_ENA       6
#define M_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_ENA       0x1
#define O_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE     7
#define M_AN_L2_PS_L2_MAIN_CFG_LEARN_CPU_QUEUE     0xf
#define O_AN_L2_PS_L2_MAIN_CFG_LEARN_DROP          11
#define M_AN_L2_PS_L2_MAIN_CFG_LEARN_DROP          0x1
#define O_AN_L2_PS_L2_MAIN_CFG_FID_MASK            16    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_MAIN_CFG_FID_MASK            0xfff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_MAIN_CFG_FILTER_MODE_SEL     28    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_MAIN_CFG_FILTER_MODE_SEL     0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_MAIN_CFG_MAC_MIRROR_MODE_SEL 29    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_MAIN_CFG_MAC_MIRROR_MODE_SEL 0x1   /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_L2_AGEFILTER_CFG fields */
#define O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_ENA       0
#define M_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_ENA       0x1
#define O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1E 1     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1E 0x1ff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1E  10    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1E  0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1E  11    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1E  0xfff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1  1     /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_AGEFILTER_CFG_PORT_AGE_PGID_GW1  0xff  /* Not Gatwick-Ie */
#define O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1   9     /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_ENA_GW1   0x1   /* Not Gatwick-Ie */
#define O_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1   10    /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_AGEFILTER_CFG_VLAN_AGE_VID_GW1   0xfff /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_L2_MAC_CFG_0 fields */
#define O_AN_L2_PS_L2_MAC_CFG_0_MACH 0
#define M_AN_L2_PS_L2_MAC_CFG_0_MACH 0xffff
#define O_AN_L2_PS_L2_MAC_CFG_0_VID  16
#define M_AN_L2_PS_L2_MAC_CFG_0_VID  0xfff

/* Target register R_AN_L2_PS_L2_MAC_CFG_1 fields */
#define O_AN_L2_PS_L2_MAC_CFG_1_MACL 0
#define M_AN_L2_PS_L2_MAC_CFG_1_MACL 0xffffffff

/* Target register R_AN_L2_PS_L2_MAC_CFG_2 fields */
#define O_AN_L2_PS_L2_MAC_CFG_2_MIRROR           0
#define M_AN_L2_PS_L2_MAC_CFG_2_MIRROR           0x1
#define O_AN_L2_PS_L2_MAC_CFG_2_LOCKED           1
#define M_AN_L2_PS_L2_MAC_CFG_2_LOCKED           0x1
#define O_AN_L2_PS_L2_MAC_CFG_2_VALID            2
#define M_AN_L2_PS_L2_MAC_CFG_2_VALID            0x1
#define O_AN_L2_PS_L2_MAC_CFG_2_AGE_FLAG         3
#define M_AN_L2_PS_L2_MAC_CFG_2_AGE_FLAG         0x1
#define O_AN_L2_PS_L2_MAC_CFG_2_VLAN_IGNORE      4
#define M_AN_L2_PS_L2_MAC_CFG_2_VLAN_IGNORE      0x1
#define O_AN_L2_PS_L2_MAC_CFG_2_CPU_COPY         5
#define M_AN_L2_PS_L2_MAC_CFG_2_CPU_COPY         0x1
#define O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1E        6     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1E        0x1ff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E  15    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1E  0x3   /* Gatwick-Ie only */ 
#define O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E  17    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1E  0xfff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1         6     /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_MAC_CFG_2_PGID_GW1         0xff  /* Not Gatwick-Ie */
#define O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1   14    /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_MAC_CFG_2_DIRECT_COL_GW1   0x3   /* Not Gatwick-Ie */
#define O_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1   16    /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_MAC_CFG_2_DIRECT_ROW_GW1   0x7ff /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_L2_MAC_CTRL fields */
#define O_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD 0
#define M_AN_L2_PS_L2_MAC_CTRL_MAC_TABLE_CMD 0x7

/* Target register R_AN_L2_PS_L2_FLOOD_CFG fields */
#define O_AN_L2_PS_L2_FLOOD_CFG_FLOOD_IGNORE_VLAN 0
#define M_AN_L2_PS_L2_FLOOD_CFG_FLOOD_IGNORE_VLAN 0x1
#define O_AN_L2_PS_L2_FLOOD_CFG_FLOOD_MIRROR      1
#define M_AN_L2_PS_L2_FLOOD_CFG_FLOOD_MIRROR      0x1
#define O_AN_L2_PS_L2_FLOOD_CFG_FLOOD_CPU_COPY    2
#define M_AN_L2_PS_L2_FLOOD_CFG_FLOOD_CPU_COPY    0x1

/* Target register R_AN_L2_PS_L2_AUTO_CFG fields */
#define O_AN_L2_PS_L2_AUTO_CFG_AUTO_IGNORE_VLAN 0
#define M_AN_L2_PS_L2_AUTO_CFG_AUTO_IGNORE_VLAN 0x1
#define O_AN_L2_PS_L2_AUTO_CFG_AUTO_MIRROR      1
#define M_AN_L2_PS_L2_AUTO_CFG_AUTO_MIRROR      0x1
#define O_AN_L2_PS_L2_AUTO_CFG_AUTO_CPU_COPY    2
#define M_AN_L2_PS_L2_AUTO_CFG_AUTO_CPU_COPY    0x1

/* Target register R_AN_L2_PS_L2_EVENTMASK_CFG fields */
#define O_AN_L2_PS_L2_EVENTMASK_CFG_STICKY_MASK_GW1E 0
#define M_AN_L2_PS_L2_EVENTMASK_CFG_STICKY_MASK_GW1E 0xffffff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_EVENTMASK_CFG_STICKY_MASK_GW   0
#define M_AN_L2_PS_L2_EVENTMASK_CFG_STICKY_MASK_GW   0x7ffff  /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_L2_AGEMODE_CFG fields */
#define O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_UNTIL_FOUND_ENA 0     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_SCAN_UNTIL_FOUND_ENA 0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEMODE_CFG_KEEP_AGE_BIT_ENA     1     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_KEEP_AGE_BIT_ENA     0x1   /* Gatwick-Ie only */ 
#define O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW_ENA         2     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW_ENA         0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_AGED_ENA   3     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_AGED_ENA   0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_LOCKED_ENA 4     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_SCAN_FIND_LOCKED_ENA 0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW             8     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_SCAN_ROW             0xfff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_AGEMODE_CFG_SCAN_STATUS          20    /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_AGEMODE_CFG_SCAN_STATUS          0xf   /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_L2_MOVELOG_STICKY fields */
#define O_AN_L2_PS_L2_MOVELOG_STICKY_MOVELOG 0
#define M_AN_L2_PS_L2_MOVELOG_STICKY_MOVELOG 0xffffffff

/* Target register R_AN_L2_PS_L2_TABLEPOS_STICKY fields */
#define O_AN_L2_PS_L2_TABLEPOS_STICKY_LATEST_CPU_COL      0
#define M_AN_L2_PS_L2_TABLEPOS_STICKY_LATEST_CPU_COL      0x3
#define O_AN_L2_PS_L2_TABLEPOS_STICKY_LATEST_CPU_ROW_GW1E 2     /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_TABLEPOS_STICKY_LATEST_CPU_ROW_GW1E 0xfff /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_TABLEPOS_STICKY_LATEST_CPU_ROW_GW1  2     /* Not Gatwick-Ie */
#define M_AN_L2_PS_L2_TABLEPOS_STICKY_LATEST_CPU_ROW_GW1  0x7ff /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_L2_EVENTS_STICKY fields */
#define O_AN_L2_PS_L2_EVENTS_STICKY_SMAC_LOOKUP                0
#define M_AN_L2_PS_L2_EVENTS_STICKY_SMAC_LOOKUP                0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_DMAC_LOOKUP                1
#define M_AN_L2_PS_L2_EVENTS_STICKY_DMAC_LOOKUP                0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_CPU_CMD_COMPLETED          2
#define M_AN_L2_PS_L2_EVENTS_STICKY_CPU_CMD_COMPLETED          0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_COL3_MATCH                 3
#define M_AN_L2_PS_L2_EVENTS_STICKY_COL3_MATCH                 0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_COL2_MATCH                 4
#define M_AN_L2_PS_L2_EVENTS_STICKY_COL2_MATCH                 0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_COL1_MATCH                 5
#define M_AN_L2_PS_L2_EVENTS_STICKY_COL1_MATCH                 0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_COL0_MATCH                 6
#define M_AN_L2_PS_L2_EVENTS_STICKY_COL0_MATCH                 0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_L2_FORWARD                 7
#define M_AN_L2_PS_L2_EVENTS_STICKY_L2_FORWARD                 0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_DROPPED                    8
#define M_AN_L2_PS_L2_EVENTS_STICKY_DROPPED                    0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_LEARN_INSERT               9
#define M_AN_L2_PS_L2_EVENTS_STICKY_LEARN_INSERT               0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_LEARN_REPLACE              10
#define M_AN_L2_PS_L2_EVENTS_STICKY_LEARN_REPLACE              0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_LEARN_REFRESH              11
#define M_AN_L2_PS_L2_EVENTS_STICKY_LEARN_REFRESH              0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_AGED_ENTRY_REMOVED         12
#define M_AN_L2_PS_L2_EVENTS_STICKY_AGED_ENTRY_REMOVED         0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_AUTO_LEARN_FAILED          13
#define M_AN_L2_PS_L2_EVENTS_STICKY_AUTO_LEARN_FAILED          0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_CPU_LEARN_FAILED           14
#define M_AN_L2_PS_L2_EVENTS_STICKY_CPU_LEARN_FAILED           0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_SC_FLOOD                   15
#define M_AN_L2_PS_L2_EVENTS_STICKY_SC_FLOOD                   0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_MC_FLOOD                   16
#define M_AN_L2_PS_L2_EVENTS_STICKY_MC_FLOOD                   0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_IP_MC_FLOOD                17
#define M_AN_L2_PS_L2_EVENTS_STICKY_IP_MC_FLOOD                0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_MAC_RAM_INTGR_ERR          18
#define M_AN_L2_PS_L2_EVENTS_STICKY_MAC_RAM_INTGR_ERR          0x1
#define O_AN_L2_PS_L2_EVENTS_STICKY_LOCAL_TO_LOCAL_PORT_MOVE   19  /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_EVENTS_STICKY_LOCAL_TO_LOCAL_PORT_MOVE   0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_EVENTS_STICKY_GLOBAL_TO_LOCAL_PORT_MOVE  20  /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_EVENTS_STICKY_GLOBAL_TO_LOCAL_PORT_MOVE  0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_EVENTS_STICKY_LOCAL_TO_GLOBAL_PORT_MOVE  21  /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_EVENTS_STICKY_LOCAL_TO_GLOBAL_PORT_MOVE  0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_EVENTS_STICKY_GLOBAL_TO_GLOBAL_PORT_MOVE 22  /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_EVENTS_STICKY_GLOBAL_TO_GLOBAL_PORT_MOVE 0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_L2_EVENTS_STICKY_ROW_WITH_AGED_ENTRY_FOUND  23  /* Gatwick-Ie only */
#define M_AN_L2_PS_L2_EVENTS_STICKY_ROW_WITH_AGED_ENTRY_FOUND  0x1 /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_L2_EVENT_CNT fields */
#define O_AN_L2_PS_L2_EVENT_CNT_STICKY_CNT 0
#define M_AN_L2_PS_L2_EVENT_CNT_STICKY_CNT 0xffffffff

/* Target register R_AN_L2_PS_PS_CFG fields */
#define O_AN_L2_PS_PS_CFG_PGID_ENA                        0
#define M_AN_L2_PS_PS_CFG_PGID_ENA                        0x1
#define O_AN_L2_PS_PS_CFG_AGGR_ENA                        1
#define M_AN_L2_PS_PS_CFG_AGGR_ENA                        0x1
#define O_AN_L2_PS_PS_CFG_SRC_MASK_ENA                    2
#define M_AN_L2_PS_PS_CFG_SRC_MASK_ENA                    0x1
#define O_AN_L2_PS_PS_CFG_CPID_MASK_ENA                   3
#define M_AN_L2_PS_PS_CFG_CPID_MASK_ENA                   0x1
#define O_AN_L2_PS_PS_CFG_GLAG_MASK_ENA                   4   /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CFG_GLAG_MASK_ENA                   0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CFG_L2_LOOP_ENA                     5   /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CFG_L2_LOOP_ENA                     0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CFG_L3_STACKING_SRC_AGGR_MODE_ENA   6   /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CFG_L3_STACKING_SRC_AGGR_MODE_ENA   0x1 /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_PGID_CTRL fields */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_INDEX_GW1E   0     /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_INDEX_GW1E   0x1ff /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1E     9     /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1E     0x3   /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_CPU_MASK_GW1E      11    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_CPU_MASK_GW1E      0x1   /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_AGGR_IDX_GW1E      12    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_AGGR_IDX_GW1E      0x3   /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_PGID_CTRL_CPU_QUEUE_PGID_FWD_GW1E 16    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_PGID_CTRL_CPU_QUEUE_PGID_FWD_GW1E 0xf   /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_INDEX_GW1    0     /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_INDEX_GW1    0xff  /* Not Gatwick-Ie */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1      8     /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_TABLE_CMD_GW1      0x3   /* Not Gatwick-Ie */
#define O_AN_L2_PS_PS_PGID_CTRL_PGID_CPU_MASK_GW1       10    /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_PGID_CTRL_PGID_CPU_MASK_GW1       0x1   /* Not Gatwick-Ie */
#define O_AN_L2_PS_PS_PGID_CTRL_CPU_QUEUE_PGID_FWD_GW1  11    /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_PGID_CTRL_CPU_QUEUE_PGID_FWD_GW1  0xf   /* Not Gatwick-Ie */ 

/* Target register R_AN_L2_PS_PS_PGID_CFG fields */
#define O_AN_L2_PS_PS_PGID_CFG_PGID_PORT_MASK 0
#define M_AN_L2_PS_PS_PGID_CFG_PGID_PORT_MASK 0xffffffff

/* Target register R_AN_L2_PS_PS_AGGR_CTRL_GW1 fields */
#define O_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_INDEX 0    /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_INDEX 0x3f /* Not Gatwick-Ie */
#define O_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_CMD   6    /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_AGGR_CTRL_GW1_AGGR_TABLE_CMD   0x3  /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_PS_AGGR_CFG_GW1 fields */
#define O_AN_L2_PS_PS_AGGR_CFG_GW1_AGGR_TABLE_MASK 0          /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_AGGR_CFG_GW1_AGGR_TABLE_MASK 0xffffffff /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_PS_SRC_CTRL fields */
#define O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_INDEX  0
#define M_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_INDEX  0x1f
#define O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_CMD    5
#define M_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_CMD    0x3
#define O_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_MIRROR 7
#define M_AN_L2_PS_PS_SRC_CTRL_SRC_TABLE_MIRROR 0x1

/* Target register R_AN_L2_PS_PS_SRC_CFG fields */
#define O_AN_L2_PS_PS_SRC_CFG_SRC_TABLE_MASK 0
#define M_AN_L2_PS_PS_SRC_CFG_SRC_TABLE_MASK 0xffffffff

/* Target register R_AN_L2_PS_PS_L2_UC_FLOOD_MASK_CFG fields */
#define O_AN_L2_PS_PS_L2_UC_FLOOD_MASK_CFG_L2_SC_FLOOD_PORT 0
#define M_AN_L2_PS_PS_L2_UC_FLOOD_MASK_CFG_L2_SC_FLOOD_PORT 0xffffffff

/* Target register R_AN_L2_PS_PS_L2_MC_FLOOD_MASK_CFG fields */
#define O_AN_L2_PS_PS_L2_MC_FLOOD_MASK_CFG_L2_MC_FLOOD_PORT 0
#define M_AN_L2_PS_PS_L2_MC_FLOOD_MASK_CFG_L2_MC_FLOOD_PORT 0xffffffff

/* Target register R_AN_L2_PS_PS_L3_MC_FLOOD_MASK_CFG fields */
#define O_AN_L2_PS_PS_L3_MC_FLOOD_MASK_CFG_L3_MC_FLOOD_PORT 0
#define M_AN_L2_PS_PS_L3_MC_FLOOD_MASK_CFG_L3_MC_FLOOD_PORT 0xffffffff

/* Target register R_AN_L2_PS_PS_EGRESS_MIRROR_MASK_CFG fields */
#define O_AN_L2_PS_PS_EGRESS_MIRROR_MASK_CFG_EGRESS_MIRROR_MASK 0
#define M_AN_L2_PS_PS_EGRESS_MIRROR_MASK_CFG_EGRESS_MIRROR_MASK 0xffffffff

/* Target register R_AN_L2_PS_PS_CPU_MIRROR_CFG fields */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_MIRROR_ENA             0
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_MIRROR_ENA             0x1
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_LOCAL_PORT_MIRROR_ENA      1    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_LOCAL_PORT_MIRROR_ENA      0x1  /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_0_MIRROR_ENA 2    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_0_MIRROR_ENA 0x1  /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_1_MIRROR_ENA 3    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_STACKING_PORT_1_MIRROR_ENA 0x1  /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1E      4    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1E      0xf  /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1E           8    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1E           0x1f /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1            1    /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_MIRROR_PORT_GW1            0x1f /* Not Gatwick-Ie */
#define O_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1       6    /* Not Gatwick-Ie */
#define M_AN_L2_PS_PS_CPU_MIRROR_CFG_CPU_QUEUE_MIRROR_GW1       0xf  /* Not Gatwick-Ie */

/* Target register R_AN_L2_PS_PS_STICKY fields */
#define O_AN_L2_PS_PS_STICKY_PGID_CMD_PROCESSED       0
#define M_AN_L2_PS_PS_STICKY_PGID_CMD_PROCESSED       0x1
#define O_AN_L2_PS_PS_STICKY_AGGR_CMD_PROCESSED       1
#define M_AN_L2_PS_PS_STICKY_AGGR_CMD_PROCESSED       0x1
#define O_AN_L2_PS_PS_STICKY_SRC_CMD_PROCESSED        2
#define M_AN_L2_PS_PS_STICKY_SRC_CMD_PROCESSED        0x1
#define O_AN_L2_PS_PS_STICKY_UC_FLOOD_EVENT           3
#define M_AN_L2_PS_PS_STICKY_UC_FLOOD_EVENT           0x1
#define O_AN_L2_PS_PS_STICKY_MC_FLOOD_EVENT           4
#define M_AN_L2_PS_PS_STICKY_MC_FLOOD_EVENT           0x1
#define O_AN_L2_PS_PS_STICKY_IP_MC_FLOOD_EVENT        5
#define M_AN_L2_PS_PS_STICKY_IP_MC_FLOOD_EVENT        0x1
#define O_AN_L2_PS_PS_STICKY_PGID_USAGE_EVENT         6
#define M_AN_L2_PS_PS_STICKY_PGID_USAGE_EVENT         0x1
#define O_AN_L2_PS_PS_STICKY_NO_L2_L3_FWD_EVENT       7
#define M_AN_L2_PS_PS_STICKY_NO_L2_L3_FWD_EVENT       0x1
#define O_AN_L2_PS_PS_STICKY_PGID_CPU_MASK_EVENT      8
#define M_AN_L2_PS_PS_STICKY_PGID_CPU_MASK_EVENT      0x1
#define O_AN_L2_PS_PS_STICKY_SRC_CONTRIBUTION_EVENT   9
#define M_AN_L2_PS_PS_STICKY_SRC_CONTRIBUTION_EVENT   0x1
#define O_AN_L2_PS_PS_STICKY_VLAN_CONTRIBUTION_EVENT  10
#define M_AN_L2_PS_PS_STICKY_VLAN_CONTRIBUTION_EVENT  0x1
#define O_AN_L2_PS_PS_STICKY_CPID_ADDITION_EVENT      11
#define M_AN_L2_PS_PS_STICKY_CPID_ADDITION_EVENT      0x1
#define O_AN_L2_PS_PS_STICKY_AGGR_CONTRIBUTION_EVENT  12
#define M_AN_L2_PS_PS_STICKY_AGGR_CONTRIBUTION_EVENT  0x1
#define O_AN_L2_PS_PS_STICKY_L2_MIRROR_EVENT          13
#define M_AN_L2_PS_PS_STICKY_L2_MIRROR_EVENT          0x1
#define O_AN_L2_PS_PS_STICKY_SRC_MIRROR_EVENT         14
#define M_AN_L2_PS_PS_STICKY_SRC_MIRROR_EVENT         0x1
#define O_AN_L2_PS_PS_STICKY_EGRESS_PORT_MIRROR_EVENT 15
#define M_AN_L2_PS_PS_STICKY_EGRESS_PORT_MIRROR_EVENT 0x1
#define O_AN_L2_PS_PS_STICKY_ZERO_DEST_EVENT          16
#define M_AN_L2_PS_PS_STICKY_ZERO_DEST_EVENT          0x1
#define O_AN_L2_PS_PS_STICKY_PGID_RAM_INTGR_ERR       17
#define M_AN_L2_PS_PS_STICKY_PGID_RAM_INTGR_ERR       0x1
#define O_AN_L2_PS_PS_STICKY_SRC_RAM_INTGR_ERR        18
#define M_AN_L2_PS_PS_STICKY_SRC_RAM_INTGR_ERR        0x1
#define O_AN_L2_PS_PS_STICKY_AGGR_RAM_INTGR_ERR       19
#define M_AN_L2_PS_PS_STICKY_AGGR_RAM_INTGR_ERR       0x1
#define O_AN_L2_PS_PS_STICKY_GLAG_RAM_INTGR_ERR       20  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_GLAG_RAM_INTGR_ERR       0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_GLAG_MIRROR_EVENT        21  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_GLAG_MIRROR_EVENT        0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_GLAG_CONTRIBUTION_EVENT  22  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_GLAG_CONTRIBUTION_EVENT  0x1 /* Gatwick-Ie only */ 
#define O_AN_L2_PS_PS_STICKY_AGGR_TABLE0_EVENT        23  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_AGGR_TABLE0_EVENT        0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_AGGR_TABLE1_EVENT        24  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_AGGR_TABLE1_EVENT        0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_AGGR_TABLE2_EVENT        25  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_AGGR_TABLE2_EVENT        0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_AGGR_TABLE3_EVENT        26  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_AGGR_TABLE3_EVENT        0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_GLAG_CMD_PROCESSED       27  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_GLAG_CMD_PROCESSED       0x1 /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_STICKY_MIRROR_TO_STACK_EVENT    28  /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_STICKY_MIRROR_TO_STACK_EVENT    0x1 /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_CPID_CTRL fields */
#define O_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_INDEX 0
#define M_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_INDEX 0xf
#define O_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_CMD   4
#define M_AN_L2_PS_PS_CPID_CTRL_CPID_TABLE_CMD   0x3

/* Target register R_AN_L2_PS_PS_CPID_CFG fields */
#define O_AN_L2_PS_PS_CPID_CFG_CPID_MASK 0
#define M_AN_L2_PS_PS_CPID_CFG_CPID_MASK 0xffffffff

/* Target register R_AN_L2_PS_PS_DBG_CTRL fields */
#define O_AN_L2_PS_PS_DBG_CTRL_QUEUE_ZERO_DEST_SET     0
#define M_AN_L2_PS_PS_DBG_CTRL_QUEUE_ZERO_DEST_SET     0xf
#define O_AN_L2_PS_PS_DBG_CTRL_REDIR_ZERO_DEST_SET_ENA 4
#define M_AN_L2_PS_PS_DBG_CTRL_REDIR_ZERO_DEST_SET_ENA 0x1

/* Target register R_AN_L2_PS_PS_AGGR_CTRL_GW1E fields */
#define O_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_INDEX 0    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_INDEX 0x3f /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_CMD   6    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_AGGR_CTRL_GW1E_AGGR_TABLE_CMD   0x3  /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_AGGR_CFG_0 fields */
#define O_AN_L2_PS_PS_AGGR_CFG_0_AGGR_TABLE_MASK 0          /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_AGGR_CFG_0_AGGR_TABLE_MASK 0xffffffff /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_AGGR_CFG_1 fields */
#define O_AN_L2_PS_PS_AGGR_CFG_1_AGGR_TABLE_MASK 0          /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_AGGR_CFG_1_AGGR_TABLE_MASK 0xffffffff /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_AGGR_CFG_2 fields */
#define O_AN_L2_PS_PS_AGGR_CFG_2_AGGR_TABLE_MASK 0          /* Gatwick-Ie only */ 
#define M_AN_L2_PS_PS_AGGR_CFG_2_AGGR_TABLE_MASK 0xffffffff /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_AGGR_CFG_3 fields */
#define O_AN_L2_PS_PS_AGGR_CFG_3_AGGR_TABLE_MASK 0          /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_AGGR_CFG_3_AGGR_TABLE_MASK 0xffffffff /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_GLAG_CTRL fields */
#define O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_CMD    0    /* Gatwick-Ie only */    
#define M_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_CMD    0x3  /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_MIRROR 2    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_MIRROR 0x1  /* Gatwick-Ie only */
#define O_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_INDEX  8    /* Gatwick-Ie only */
#define M_AN_L2_PS_PS_GLAG_CTRL_GLAG_TABLE_INDEX  0xff /* Gatwick-Ie only */

/* Target register R_AN_L2_PS_PS_GLAG_CFG fields */
#define O_AN_L2_PS_PS_GLAG_CFG_GLAG_TABLE_MASK 0          /* Gatwick-Ie only */   
#define M_AN_L2_PS_PS_GLAG_CFG_GLAG_TABLE_MASK 0xffffffff /* Gatwick-Ie only */ 

/* Target register R_RXP_VLAN_MPLS_PRIO_CFG fields */
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_0 0
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_0 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_1 2
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_1 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_2 4
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_2 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_3 6
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_3 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_4 8
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_4 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_5 10
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_5 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_6 12
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_6 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_7 14
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_VLAN_7 0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_0  16
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_0  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_1  18
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_1  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_2  20
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_2  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_3  22
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_3  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_4  24
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_4  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_5  26
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_5  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_6  28
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_6  0x3
#define O_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_7  30
#define M_RXP_VLAN_MPLS_PRIO_CFG_PRI_MAP_EXP_7  0x3

/* Target register R_RXP_DSCP_PRIO_CFG_0 fields */
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_0  0
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_0  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_1  2
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_1  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_2  4
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_2  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_3  6
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_3  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_4  8
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_4  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_5  10
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_5  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_6  12
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_6  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_7  14
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_7  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_8  16
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_8  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_9  18
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_9  0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_10 20
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_10 0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_11 22
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_11 0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_12 24
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_12 0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_13 26
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_13 0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_14 28
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_14 0x3
#define O_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_15 30
#define M_RXP_DSCP_PRIO_CFG_0_PRI_MAP_DSCP_15 0x3

/* Target register R_RXP_DSCP_PRIO_CFG_1 fields */
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_16 0
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_16 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_17 2
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_17 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_18 4
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_18 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_19 6
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_19 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_20 8
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_20 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_21 10
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_21 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_22 12
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_22 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_23 14
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_23 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_24 16
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_24 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_25 18
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_25 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_26 20
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_26 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_27 22
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_27 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_28 24
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_28 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_29 26
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_29 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_30 28
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_30 0x3
#define O_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_31 30
#define M_RXP_DSCP_PRIO_CFG_1_PRI_MAP_DSCP_31 0x3

/* Target register R_RXP_DSCP_PRIO_CFG_2 fields */
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_32 0
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_32 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_33 2
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_33 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_34 4
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_34 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_35 6
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_35 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_36 8
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_36 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_37 10
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_37 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_38 12
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_38 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_39 14
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_39 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_40 16
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_40 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_41 18
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_41 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_42 20
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_42 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_43 22
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_43 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_44 24
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_44 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_45 26
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_45 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_46 28
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_46 0x3
#define O_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_47 30
#define M_RXP_DSCP_PRIO_CFG_2_PRI_MAP_DSCP_47 0x3

/* Target register R_RXP_DSCP_PRIO_CFG_3 fields */
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_48 0
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_48 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_49 2
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_49 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_50 4
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_50 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_51 6
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_51 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_52 8
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_52 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_53 10
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_53 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_54 12
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_54 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_55 14
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_55 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_56 16
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_56 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_57 18
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_57 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_58 20
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_58 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_59 22
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_59 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_60 24
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_60 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_61 26
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_61 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_62 28
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_62 0x3
#define O_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_63 30
#define M_RXP_DSCP_PRIO_CFG_3_PRI_MAP_DSCP_63 0x3

/* Target register R_RXP_ETYPE_IPPROTO_PRIO_CFG fields */
#define O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_DEF 0
#define M_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_DEF 0x3
#define O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_PRI 2
#define M_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_PRI 0x3
#define O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_VAL 4
#define M_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_IPPROTO_VAL 0xff
#define O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_DEF   12
#define M_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_DEF   0x3
#define O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_PRI   14
#define M_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_PRI   0x3
#define O_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_VAL   16
#define M_RXP_ETYPE_IPPROTO_PRIO_CFG_PRI_MAP_ETYPE_VAL   0xffff

/* Target register R_RXP_PRIO_ENABLE_CFG fields */
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_DEFAULT_PRI   0
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_DEFAULT_PRI   0x3
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_ETYPE     2
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_ETYPE     0x1
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_EXP       3
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_EXP       0x1
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_VLAN      4
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_VLAN      0x1
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_IPPROTO   5
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_IPPROTO   0x1
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_DSCP      6
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_DSCP      0x1
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_PORT      7
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_PORT      0x1
#define O_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_IPV6_DSCP 8   /* Gatwick-Ie only */
#define M_RXP_PRIO_ENABLE_CFG_PRI_MAP_ENA_IPV6_DSCP 0x1 /* Gatwick-Ie only */

/* Target register R_RXP_AGGR_ENABLE_CFG fields */
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_SPORT_ENA     0
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_SPORT_ENA     0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_DPORT_ENA     1
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_DPORT_ENA     0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_SIP_ENA       2
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_SIP_ENA       0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_DIP_ENA       3
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_DIP_ENA       0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_IP_PROTO_ENA  4
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_IP_PROTO_ENA  0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_LABEL_ENA     5
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_LABEL_ENA     0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_VID_ENA       6
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_VID_ENA       0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_ETYPE_ENA     7
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_ETYPE_ENA     0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_LOW_SMAC_ENA  8
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_LOW_SMAC_ENA  0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_HIGH_SMAC_ENA 9
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_HIGH_SMAC_ENA 0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_LOW_DMAC_ENA  10
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_LOW_DMAC_ENA  0x1
#define O_RXP_AGGR_ENABLE_CFG_AGGRE_HIGH_DMAC_ENA 11
#define M_RXP_AGGR_ENABLE_CFG_AGGRE_HIGH_DMAC_ENA 0x1

/* Target register R_RXP_IN_QUEUE_CTRL fields */
#define O_RXP_IN_QUEUE_CTRL_RD_ENA_0         0
#define M_RXP_IN_QUEUE_CTRL_RD_ENA_0         0x1
#define O_RXP_IN_QUEUE_CTRL_RD_ENA_1         1
#define M_RXP_IN_QUEUE_CTRL_RD_ENA_1         0x1
#define O_RXP_IN_QUEUE_CTRL_RD_ENA_2         2
#define M_RXP_IN_QUEUE_CTRL_RD_ENA_2         0x1
#define O_RXP_IN_QUEUE_CTRL_RD_ENA_3         3
#define M_RXP_IN_QUEUE_CTRL_RD_ENA_3         0x1
#define O_RXP_IN_QUEUE_CTRL_WR_ENA_0         4
#define M_RXP_IN_QUEUE_CTRL_WR_ENA_0         0x1
#define O_RXP_IN_QUEUE_CTRL_WR_ENA_1         5
#define M_RXP_IN_QUEUE_CTRL_WR_ENA_1         0x1
#define O_RXP_IN_QUEUE_CTRL_WR_ENA_2         6
#define M_RXP_IN_QUEUE_CTRL_WR_ENA_2         0x1
#define O_RXP_IN_QUEUE_CTRL_WR_ENA_3         7
#define M_RXP_IN_QUEUE_CTRL_WR_ENA_3         0x1
#define O_RXP_IN_QUEUE_CTRL_INGR_ARB_PENDING 8
#define M_RXP_IN_QUEUE_CTRL_INGR_ARB_PENDING 0x1
#define O_RXP_IN_QUEUE_CTRL_INGR_PORT_FLUSH  9
#define M_RXP_IN_QUEUE_CTRL_INGR_PORT_FLUSH  0x1

/* Target register R_RXP_IN_QUEUE_DROP_CFG_0 fields */
#define O_RXP_IN_QUEUE_DROP_CFG_0_QUEUE_DROP_0 0
#define M_RXP_IN_QUEUE_DROP_CFG_0_QUEUE_DROP_0 0x1ff
#define O_RXP_IN_QUEUE_DROP_CFG_0_QUEUE_DROP_1 9
#define M_RXP_IN_QUEUE_DROP_CFG_0_QUEUE_DROP_1 0x1ff

/* Target register R_RXP_IN_QUEUE_DROP_CFG_1 fields */
#define O_RXP_IN_QUEUE_DROP_CFG_1_QUEUE_DROP_2 0
#define M_RXP_IN_QUEUE_DROP_CFG_1_QUEUE_DROP_2 0x1ff
#define O_RXP_IN_QUEUE_DROP_CFG_1_QUEUE_DROP_3 9
#define M_RXP_IN_QUEUE_DROP_CFG_1_QUEUE_DROP_3 0x1ff

/* Target register R_RXP_IN_QUEUE_WMARK_CFG fields */
#define O_RXP_IN_QUEUE_WMARK_CFG_PORT_WM_LOW     0
#define M_RXP_IN_QUEUE_WMARK_CFG_PORT_WM_LOW     0x3f
#define O_RXP_IN_QUEUE_WMARK_CFG_PORT_WM_HIGH    6
#define M_RXP_IN_QUEUE_WMARK_CFG_PORT_WM_HIGH    0x3f
#define O_RXP_IN_QUEUE_WMARK_CFG_PORT_DROP_LEVEL 12
#define M_RXP_IN_QUEUE_WMARK_CFG_PORT_DROP_LEVEL 0x3f

/* Target register R_RXP_IN_POLICER_LEVEL_CFG fields */
#define O_RXP_IN_POLICER_LEVEL_CFG_INGR_POLICER_LEVEL_MC  0
#define M_RXP_IN_POLICER_LEVEL_CFG_INGR_POLICER_LEVEL_MC  0xff
#define O_RXP_IN_POLICER_LEVEL_CFG_INGR_POLICER_LEVEL_ALL 16
#define M_RXP_IN_POLICER_LEVEL_CFG_INGR_POLICER_LEVEL_ALL 0xff

/* Target register R_RXP_IN_POLICER_RATE_CFG fields */
#define O_RXP_IN_POLICER_RATE_CFG_INGR_POLICER_RATE_MC  0
#define M_RXP_IN_POLICER_RATE_CFG_INGR_POLICER_RATE_MC  0xffff
#define O_RXP_IN_POLICER_RATE_CFG_INGR_POLICER_RATE_ALL 16
#define M_RXP_IN_POLICER_RATE_CFG_INGR_POLICER_RATE_ALL 0xffff

/* Target register R_RXP_IN_POLICER_CTRL fields */
#define O_RXP_IN_POLICER_CTRL_INGR_POLICER_ALL_ENA 0
#define M_RXP_IN_POLICER_CTRL_INGR_POLICER_ALL_ENA 0x1
#define O_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_ENA  1
#define M_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_ENA  0x1
#define O_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_BC   2
#define M_RXP_IN_POLICER_CTRL_INGR_POLICER_MC_BC   0x1

/* Target register R_RXP_SWITCH_MODE_CFG fields */
#define O_RXP_SWITCH_MODE_CFG_AGE_ENA            0
#define M_RXP_SWITCH_MODE_CFG_AGE_ENA            0x1
#define O_RXP_SWITCH_MODE_CFG_ANAREQ_IPVALID_SEL 1
#define M_RXP_SWITCH_MODE_CFG_ANAREQ_IPVALID_SEL 0x1
#define O_RXP_SWITCH_MODE_CFG_IP_ENA             2
#define M_RXP_SWITCH_MODE_CFG_IP_ENA             0x1
#define O_RXP_SWITCH_MODE_CFG_MAC_CTRL_ENA       3
#define M_RXP_SWITCH_MODE_CFG_MAC_CTRL_ENA       0x1
#define O_RXP_SWITCH_MODE_CFG_SMAC_ZERO_ENA      4   /* Gatwick-Ie only */
#define M_RXP_SWITCH_MODE_CFG_SMAC_ZERO_ENA      0x1 /* Gatwick-Ie only */
#define O_RXP_SWITCH_MODE_CFG_SMAC_MC_ENA        5   /* Gatwick-Ie only */
#define M_RXP_SWITCH_MODE_CFG_SMAC_MC_ENA        0x1 /* Gatwick-Ie only */
#define O_RXP_SWITCH_MODE_CFG_LABEL_SWITCH_ENA   6   /* Gatwick-Ie only */
#define M_RXP_SWITCH_MODE_CFG_LABEL_SWITCH_ENA   0x3 /* Gatwick-Ie only */

/* Target register R_RXP_PORT_VLAN_CFG fields */
#define O_RXP_PORT_VLAN_CFG_VLAN_DEF            0
#define M_RXP_PORT_VLAN_CFG_VLAN_DEF            0xfff
#define O_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_0    12
#define M_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_0    0x7
#define O_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_1    15
#define M_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_1    0x7
#define O_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_2    18
#define M_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_2    0x7
#define O_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_3    21
#define M_RXP_PORT_VLAN_CFG_VLAN_USER_PRIO_3    0x7
#define O_RXP_PORT_VLAN_CFG_VLAN_KEEP_USER_PRIO 24
#define M_RXP_PORT_VLAN_CFG_VLAN_KEEP_USER_PRIO 0x1
#define O_RXP_PORT_VLAN_CFG_VLAN_CFI            25
#define M_RXP_PORT_VLAN_CFG_VLAN_CFI            0x1
#define O_RXP_PORT_VLAN_CFG_VLAN_UNTAGGED_ENA   26
#define M_RXP_PORT_VLAN_CFG_VLAN_UNTAGGED_ENA   0x1
#define O_RXP_PORT_VLAN_CFG_VLAN_TAGGED_ENA     27
#define M_RXP_PORT_VLAN_CFG_VLAN_TAGGED_ENA     0x1
#define O_RXP_PORT_VLAN_CFG_VLAN_AWARE_ENA      28
#define M_RXP_PORT_VLAN_CFG_VLAN_AWARE_ENA      0x1

/* Target register R_RXP_DROP_MASK_CFG fields */
#define O_RXP_DROP_MASK_CFG_DROP_MASK_POLICER_MC  0
#define M_RXP_DROP_MASK_CFG_DROP_MASK_POLICER_MC  0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_POLICER_ALL 1
#define M_RXP_DROP_MASK_CFG_DROP_MASK_POLICER_ALL 0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_MODULE_FULL 2
#define M_RXP_DROP_MASK_CFG_DROP_MASK_MODULE_FULL 0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_QUEUE_FULL  3
#define M_RXP_DROP_MASK_CFG_DROP_MASK_QUEUE_FULL  0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_PORT_FULL   4
#define M_RXP_DROP_MASK_CFG_DROP_MASK_PORT_FULL   0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_FCS         5
#define M_RXP_DROP_MASK_CFG_DROP_MASK_FCS         0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_BAD_MACS    6
#define M_RXP_DROP_MASK_CFG_DROP_MASK_BAD_MACS    0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_MAC_CTRL    7
#define M_RXP_DROP_MASK_CFG_DROP_MASK_MAC_CTRL    0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_TAGGED      8
#define M_RXP_DROP_MASK_CFG_DROP_MASK_TAGGED      0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_UNTAGGED    9
#define M_RXP_DROP_MASK_CFG_DROP_MASK_UNTAGGED    0x1
#define O_RXP_DROP_MASK_CFG_DBG_TALLY             10
#define M_RXP_DROP_MASK_CFG_DBG_TALLY             0x1
#define O_RXP_DROP_MASK_CFG_DBG_IFH_RESV          11
#define M_RXP_DROP_MASK_CFG_DBG_IFH_RESV          0xf
#define O_RXP_DROP_MASK_CFG_DBG_DONT_TOUCH        15
#define M_RXP_DROP_MASK_CFG_DBG_DONT_TOUCH        0x1
#define O_RXP_DROP_MASK_CFG_DBG_FORCE_FCS_UPD     16
#define M_RXP_DROP_MASK_CFG_DBG_FORCE_FCS_UPD     0x1
#define O_RXP_DROP_MASK_CFG_DBG_NEVER_DROP        17
#define M_RXP_DROP_MASK_CFG_DBG_NEVER_DROP        0x1
#define O_RXP_DROP_MASK_CFG_DBG_FORCE_FCS_ADD     18
#define M_RXP_DROP_MASK_CFG_DBG_FORCE_FCS_ADD     0x1
#define O_RXP_DROP_MASK_CFG_DBG_CHECK_SEQ         19
#define M_RXP_DROP_MASK_CFG_DBG_CHECK_SEQ         0x1
#define O_RXP_DROP_MASK_CFG_DBG_MAC_ABORT         20
#define M_RXP_DROP_MASK_CFG_DBG_MAC_ABORT         0x1
#define O_RXP_DROP_MASK_CFG_DROP_MASK_WR_ENA      21  /* Gatwick-Ie only */
#define M_RXP_DROP_MASK_CFG_DROP_MASK_WR_ENA      0x1 /* Gatwick-Ie only */
#define O_RXP_DROP_MASK_CFG_DROP_MASK_ZERO_DEST   22  /* Gatwick-Ie only */
#define M_RXP_DROP_MASK_CFG_DROP_MASK_ZERO_DEST   0x1 /* Gatwick-Ie only */
#define O_RXP_DROP_MASK_CFG_DROP_MASK_SMAC_ZERO   23  /* Gatwick-Ie only */
#define M_RXP_DROP_MASK_CFG_DROP_MASK_SMAC_ZERO   0x1 /* Gatwick-Ie only */
#define O_RXP_DROP_MASK_CFG_DROP_MASK_SMAC_MC     24  /* Gatwick-Ie only */
#define M_RXP_DROP_MASK_CFG_DROP_MASK_SMAC_MC     0x1 /* Gatwick-Ie only */ 
#define O_RXP_DROP_MASK_CFG_DROP_MASK_ST_CRC      25  /* Gatwick-Ie only */
#define M_RXP_DROP_MASK_CFG_DROP_MASK_ST_CRC      0x1 /* Gatwick-Ie only */
#define O_RXP_DROP_MASK_CFG_DROP_MASK_ST_FIELD    26  /* Gatwick-Ie only */
#define M_RXP_DROP_MASK_CFG_DROP_MASK_ST_FIELD    0x1 /* Gatwick-Ie only */

/* Target register R_RXP_DROP_CNT fields */
#define O_RXP_DROP_CNT_DROP_CNT 0
#define M_RXP_DROP_CNT_DROP_CNT 0xffffffff

/* Target register R_RXP_IN_PORT_STICKY fields */
#define O_RXP_IN_PORT_STICKY_STICKY_IP_NORMAL     0
#define M_RXP_IN_PORT_STICKY_STICKY_IP_NORMAL     0x1
#define O_RXP_IN_PORT_STICKY_STICKY_IP_OPTIONS    1
#define M_RXP_IN_PORT_STICKY_STICKY_IP_OPTIONS    0x1
#define O_RXP_IN_PORT_STICKY_STICKY_IP_TTL        2
#define M_RXP_IN_PORT_STICKY_STICKY_IP_TTL        0x1
#define O_RXP_IN_PORT_STICKY_STICKY_IP_CSUM       3
#define M_RXP_IN_PORT_STICKY_STICKY_IP_CSUM       0x1
#define O_RXP_IN_PORT_STICKY_STICKY_IP_LEN        4
#define M_RXP_IN_PORT_STICKY_STICKY_IP_LEN        0x1
#define O_RXP_IN_PORT_STICKY_STICKY_IP_VER        5
#define M_RXP_IN_PORT_STICKY_STICKY_IP_VER        0x1
#define O_RXP_IN_PORT_STICKY_STICKY_POLICER_MC    6
#define M_RXP_IN_PORT_STICKY_STICKY_POLICER_MC    0x1
#define O_RXP_IN_PORT_STICKY_STICKY_POLICER_ALL   7
#define M_RXP_IN_PORT_STICKY_STICKY_POLICER_ALL   0x1
#define O_RXP_IN_PORT_STICKY_STICKY_MODULE_FULL   8
#define M_RXP_IN_PORT_STICKY_STICKY_MODULE_FULL   0x1
#define O_RXP_IN_PORT_STICKY_STICKY_QUEUE_FULL    9
#define M_RXP_IN_PORT_STICKY_STICKY_QUEUE_FULL    0x1
#define O_RXP_IN_PORT_STICKY_STICKY_PORT_FULL     10
#define M_RXP_IN_PORT_STICKY_STICKY_PORT_FULL     0x1
#define O_RXP_IN_PORT_STICKY_STICKY_FCS           11
#define M_RXP_IN_PORT_STICKY_STICKY_FCS           0x1
#define O_RXP_IN_PORT_STICKY_STICKY_BAD_MACS      12
#define M_RXP_IN_PORT_STICKY_STICKY_BAD_MACS      0x1
#define O_RXP_IN_PORT_STICKY_STICKY_MAC_CTRL      13
#define M_RXP_IN_PORT_STICKY_STICKY_MAC_CTRL      0x1
#define O_RXP_IN_PORT_STICKY_STICKY_TAGGED        14
#define M_RXP_IN_PORT_STICKY_STICKY_TAGGED        0x1
#define O_RXP_IN_PORT_STICKY_STICKY_UNTAGGED      15
#define M_RXP_IN_PORT_STICKY_STICKY_UNTAGGED      0x1
#define O_RXP_IN_PORT_STICKY_STICKY_CLASS_FIFO_FF 16
#define M_RXP_IN_PORT_STICKY_STICKY_CLASS_FIFO_FF 0x1
#define O_RXP_IN_PORT_STICKY_STICKY_WR_ENA        17  /* Gatwick-Ie only */
#define M_RXP_IN_PORT_STICKY_STICKY_WR_ENA        0x1 /* Gatwick-Ie only */
#define O_RXP_IN_PORT_STICKY_STICKY_ZERO_DEST     18  /* Gatwick-Ie only */
#define M_RXP_IN_PORT_STICKY_STICKY_ZERO_DEST     0x1 /* Gatwick-Ie only */
#define O_RXP_IN_PORT_STICKY_STICKY_SMAC_ZERO     19  /* Gatwick-Ie only */
#define M_RXP_IN_PORT_STICKY_STICKY_SMAC_ZERO     0x1 /* Gatwick-Ie only */
#define O_RXP_IN_PORT_STICKY_STICKY_SMAC_MC       20  /* Gatwick-Ie only */
#define M_RXP_IN_PORT_STICKY_STICKY_SMAC_MC       0x1 /* Gatwick-Ie only */
#define O_RXP_IN_PORT_STICKY_STICKY_ST_CRC        21  /* Gatwick-Ie only */
#define M_RXP_IN_PORT_STICKY_STICKY_ST_CRC        0x1 /* Gatwick-Ie only */
#define O_RXP_IN_PORT_STICKY_STICKY_ST_FIELD      22  /* Gatwick-Ie only */
#define M_RXP_IN_PORT_STICKY_STICKY_ST_FIELD      0x1 /* Gatwick-Ie only */

/* Target register R_RXP_IN_QUEUE_SYSTEM_CFG fields */
#define O_RXP_IN_QUEUE_SYSTEM_CFG_MODULE_WM_LOW  0
#define M_RXP_IN_QUEUE_SYSTEM_CFG_MODULE_WM_LOW  0x3f
#define O_RXP_IN_QUEUE_SYSTEM_CFG_MODULE_WM_HIGH 6
#define M_RXP_IN_QUEUE_SYSTEM_CFG_MODULE_WM_HIGH 0x3f
#define O_RXP_IN_QUEUE_SYSTEM_CFG_PB_TAG_VAL     12     /* Gatwick-Ie only */
#define M_RXP_IN_QUEUE_SYSTEM_CFG_PB_TAG_VAL     0xffff /* Gatwick-Ie only */
#define O_RXP_IN_QUEUE_SYSTEM_CFG_PB_ENA         28     /* Gatwick-Ie only */
#define M_RXP_IN_QUEUE_SYSTEM_CFG_PB_ENA         0x1    /* Gatwick-Ie only */

/* Target register R_RXP_UDP_TCP_PRIO_CFG fields */
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_DEF_PRI 0
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_DEF_PRI 0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_0   2
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_0   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_1   4
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_1   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_2   6
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_2   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_3   8
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_3   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_4   10
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_4   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_5   12
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_5   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_6   14
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_6   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_7   16
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_7   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_8   18
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_8   0x3
#define O_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_9   20
#define M_RXP_UDP_TCP_PRIO_CFG_PRI_MAP_PORT_PRI_9   0x3

/* Target register R_RXP_UDP_TCP_PORT_CFG_0 fields */
#define O_RXP_UDP_TCP_PORT_CFG_0_PRI_MAP_PORT_VAL_0 0
#define M_RXP_UDP_TCP_PORT_CFG_0_PRI_MAP_PORT_VAL_0 0xffff
#define O_RXP_UDP_TCP_PORT_CFG_0_PRI_MAP_PORT_VAL_1 16
#define M_RXP_UDP_TCP_PORT_CFG_0_PRI_MAP_PORT_VAL_1 0xffff

/* Target register R_RXP_UDP_TCP_PORT_CFG_1 fields */
#define O_RXP_UDP_TCP_PORT_CFG_1_PRI_MAP_PORT_VAL_2 0
#define M_RXP_UDP_TCP_PORT_CFG_1_PRI_MAP_PORT_VAL_2 0xffff
#define O_RXP_UDP_TCP_PORT_CFG_1_PRI_MAP_PORT_VAL_3 16
#define M_RXP_UDP_TCP_PORT_CFG_1_PRI_MAP_PORT_VAL_3 0xffff

/* Target register R_RXP_UDP_TCP_PORT_CFG_2 fields */
#define O_RXP_UDP_TCP_PORT_CFG_2_PRI_MAP_PORT_VAL_4 0
#define M_RXP_UDP_TCP_PORT_CFG_2_PRI_MAP_PORT_VAL_4 0xffff
#define O_RXP_UDP_TCP_PORT_CFG_2_PRI_MAP_PORT_VAL_5 16
#define M_RXP_UDP_TCP_PORT_CFG_2_PRI_MAP_PORT_VAL_5 0xffff

/* Target register R_RXP_UDP_TCP_PORT_CFG_3 fields */
#define O_RXP_UDP_TCP_PORT_CFG_3_PRI_MAP_PORT_VAL_6 0
#define M_RXP_UDP_TCP_PORT_CFG_3_PRI_MAP_PORT_VAL_6 0xffff
#define O_RXP_UDP_TCP_PORT_CFG_3_PRI_MAP_PORT_VAL_7 16
#define M_RXP_UDP_TCP_PORT_CFG_3_PRI_MAP_PORT_VAL_7 0xffff

/* Target register R_RXP_UDP_TCP_PORT_CFG_4 fields */
#define O_RXP_UDP_TCP_PORT_CFG_4_PRI_MAP_PORT_VAL_8 0
#define M_RXP_UDP_TCP_PORT_CFG_4_PRI_MAP_PORT_VAL_8 0xffff
#define O_RXP_UDP_TCP_PORT_CFG_4_PRI_MAP_PORT_VAL_9 16
#define M_RXP_UDP_TCP_PORT_CFG_4_PRI_MAP_PORT_VAL_9 0xffff

/* Target register R_RXP_IN_MODULE_STICKY fields */
#define O_RXP_IN_MODULE_STICKY_STICKY_RDF_FIFO_FF      0
#define M_RXP_IN_MODULE_STICKY_STICKY_RDF_FIFO_FF      0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_RDF_SYNC_ERR     1
#define M_RXP_IN_MODULE_STICKY_STICKY_RDF_SYNC_ERR     0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_RDF_SUBP_ERR     2
#define M_RXP_IN_MODULE_STICKY_STICKY_RDF_SUBP_ERR     0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_RDF_REQ_ERR      3
#define M_RXP_IN_MODULE_STICKY_STICKY_RDF_REQ_ERR      0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_0_FF    4
#define M_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_0_FF    0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_1_FF    5
#define M_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_1_FF    0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_2_FF    6
#define M_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_2_FF    0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_3_FF    7
#define M_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_3_FF    0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_4_FF    8
#define M_RXP_IN_MODULE_STICKY_STICKY_WRF_FIFO_4_FF    0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_REM_RAM_INT_ERR  9
#define M_RXP_IN_MODULE_STICKY_STICKY_REM_RAM_INT_ERR  0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_REQ_RAM_INT_ERR  10
#define M_RXP_IN_MODULE_STICKY_STICKY_REQ_RAM_INT_ERR  0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_REM_RAM_RDY_ERR  11
#define M_RXP_IN_MODULE_STICKY_STICKY_REM_RAM_RDY_ERR  0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_REQ_RAM_RDY_ERR  12
#define M_RXP_IN_MODULE_STICKY_STICKY_REQ_RAM_RDY_ERR  0x1
#define O_RXP_IN_MODULE_STICKY_STICKY_MAIN_RAM_RDY_ERR 13
#define M_RXP_IN_MODULE_STICKY_STICKY_MAIN_RAM_RDY_ERR 0x1

/* Target register R_RXP_IN_MODULE_MPLS_CFG fields */
#define O_RXP_IN_MODULE_MPLS_CFG_VENDOR_ID_CFG 0        /* Gatwick-Ie only */
#define M_RXP_IN_MODULE_MPLS_CFG_VENDOR_ID_CFG 0xffffff /* Gatwick-Ie only */

/* Target register R_RXP_DP_AND_CPU_BC_COPY_CFG fields */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_ALL_ENA 0   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_ALL_ENA 0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_TAR_ENA 1   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_ARP_BC_TAR_ENA 0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_BOOTP_ENA      2   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_BOOTP_ENA      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_RIPV1_ENA      3   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_COPY_RIPV1_ENA      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_0      4   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_0      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_1      5   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_1      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_2      6   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_2      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_3      7   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_3      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_4      8   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_4      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_5      9   /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_5      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_6      10  /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_6      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_7      11  /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_USER_PRIO_DP_7      0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_DP_ENA              12  /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_DP_ENA              0x1 /* Gatwick-Ie only */
#define O_RXP_DP_AND_CPU_BC_COPY_CFG_DP_CFG              13  /* Gatwick-Ie only */
#define M_RXP_DP_AND_CPU_BC_COPY_CFG_DP_CFG              0x1 /* Gatwick-Ie only */

/* Target register R_RXP_ARP_BC_TAR_CFG fields */ 
#define O_RXP_ARP_BC_TAR_CFG_ARP_BC_TAR_VAL 0          /* Gatwick-Ie only */
#define M_RXP_ARP_BC_TAR_CFG_ARP_BC_TAR_VAL 0xffffffff /* Gatwick-Ie only */

/* Target register R_RXP_STACKING_TAG_CFG fields */
#define O_RXP_STACKING_TAG_CFG_STACKING_PORT_ENA  0   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_STACKING_PORT_ENA  0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_NO_STACKING_TAG    1   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_NO_STACKING_TAG    0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_ST_VERSION_UNKNOWN 2   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_ST_VERSION_UNKNOWN 0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_CONF_ST_REDIR_ENA  3   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_CONF_ST_REDIR_ENA  0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_0 4   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_0 0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_1 5   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_1 0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_2 6   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_2 0x1 /* Gatwick-Ie only */
#define O_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_3 7   /* Gatwick-Ie only */
#define M_RXP_STACKING_TAG_CFG_CONF_ST_DP_REMAP_3 0x1 /* Gatwick-Ie only */

/* Target register R_RXP_ST_PRIO_REMAP_CFG fields */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_0  0   /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_0  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_1  2   /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_1  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_2  4   /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_2  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_3  6   /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_3  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_4  8   /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_4  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_5  10  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_5  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_6  12  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_6  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_7  14  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_7  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_8  16  /* Gatwick-Ie only */ 
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_8  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_9  18  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_9  0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_10 20  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_10 0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_11 22  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_11 0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_12 24  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_12 0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_13 26  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_13 0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_14 28  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_14 0x3 /* Gatwick-Ie only */
#define O_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_15 30  /* Gatwick-Ie only */
#define M_RXP_ST_PRIO_REMAP_CFG_PRI_MAP_ST_PRIO_15 0x3 /* Gatwick-Ie only */

/* Target register R_TXP_QS_CFG fields */
#define O_TXP_QS_CFG_WR_ENA  0
#define M_TXP_QS_CFG_WR_ENA  0xf
#define O_TXP_QS_CFG_RD_ENA  4
#define M_TXP_QS_CFG_RD_ENA  0xf
#define O_TXP_QS_CFG_AGE_ENA 8
#define M_TXP_QS_CFG_AGE_ENA 0xf
#define O_TXP_QS_CFG_TRUNC   12
#define M_TXP_QS_CFG_TRUNC   0xf
#define O_TXP_QS_CFG_FLUSH   16
#define M_TXP_QS_CFG_FLUSH   0xf

/* Target register R_TXP_QS_LINKAGGR_CFG fields */
#define O_TXP_QS_LINKAGGR_CFG_AGGR_ENA 0
#define M_TXP_QS_LINKAGGR_CFG_AGGR_ENA 0xffffffff

/* Target register R_TXP_IP_MULTICAST_TTL_DROP_CNT fields */
#define O_TXP_IP_MULTICAST_TTL_DROP_CNT_DROP_CNT 0
#define M_TXP_IP_MULTICAST_TTL_DROP_CNT_DROP_CNT 0xffffffff

/* Target register R_TXP_DROP_CFG fields */
#define O_TXP_DROP_CFG_IP_MULTICAST_TTL_DROP_DISABLE 0
#define M_TXP_DROP_CFG_IP_MULTICAST_TTL_DROP_DISABLE 0x1
#define O_TXP_DROP_CFG_DBG_SET_SEQ                   1
#define M_TXP_DROP_CFG_DBG_SET_SEQ                   0x1

/* Target register R_TXP_QS_DROP_CFG fields */
#define O_TXP_QS_DROP_CFG_LEVEL0 0
#define M_TXP_QS_DROP_CFG_LEVEL0 0x3f
#define O_TXP_QS_DROP_CFG_LEVEL1 8
#define M_TXP_QS_DROP_CFG_LEVEL1 0x3f
#define O_TXP_QS_DROP_CFG_LEVEL2 16
#define M_TXP_QS_DROP_CFG_LEVEL2 0x3f
#define O_TXP_QS_DROP_CFG_LEVEL3 24
#define M_TXP_QS_DROP_CFG_LEVEL3 0x3f

/* Target register R_TXP_QS_PORT_WM fields */
#define O_TXP_QS_PORT_WM_PORT_WM_LOW  0
#define M_TXP_QS_PORT_WM_PORT_WM_LOW  0x3f
#define O_TXP_QS_PORT_WM_PORT_WM_HIGH 8
#define M_TXP_QS_PORT_WM_PORT_WM_HIGH 0x3f

/* Target register R_TXP_QS_PORT_DROP_CFG fields */
#define O_TXP_QS_PORT_DROP_CFG_PORT_LEVEL 0
#define M_TXP_QS_PORT_DROP_CFG_PORT_LEVEL 0x3f

/* Target register R_TXP_PORT_DROP_CNT fields */
#define O_TXP_PORT_DROP_CNT_PORT_DROP_CNT 0          /* Gatwick-Ie only */
#define M_TXP_PORT_DROP_CNT_PORT_DROP_CNT 0xffffffff /* Gatwick-Ie only */

/* Target register R_TXP_QS_PRLID_0 fields */
#define O_TXP_QS_PRLID_0_PRLID0_L2 0
#define M_TXP_QS_PRLID_0_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_0_PRLID0_L3 1
#define M_TXP_QS_PRLID_0_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_0_PRLID1_L2 8
#define M_TXP_QS_PRLID_0_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_0_PRLID1_L3 9
#define M_TXP_QS_PRLID_0_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_0_PRLID2_L2 16
#define M_TXP_QS_PRLID_0_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_0_PRLID2_L3 17
#define M_TXP_QS_PRLID_0_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_0_PRLID3_L2 24
#define M_TXP_QS_PRLID_0_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_0_PRLID3_L3 25
#define M_TXP_QS_PRLID_0_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_1 fields */
#define O_TXP_QS_PRLID_1_PRLID0_L2 0
#define M_TXP_QS_PRLID_1_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_1_PRLID0_L3 1
#define M_TXP_QS_PRLID_1_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_1_PRLID1_L2 8
#define M_TXP_QS_PRLID_1_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_1_PRLID1_L3 9
#define M_TXP_QS_PRLID_1_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_1_PRLID2_L2 16
#define M_TXP_QS_PRLID_1_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_1_PRLID2_L3 17
#define M_TXP_QS_PRLID_1_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_1_PRLID3_L2 24
#define M_TXP_QS_PRLID_1_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_1_PRLID3_L3 25
#define M_TXP_QS_PRLID_1_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_2 fields */
#define O_TXP_QS_PRLID_2_PRLID0_L2 0
#define M_TXP_QS_PRLID_2_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_2_PRLID0_L3 1
#define M_TXP_QS_PRLID_2_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_2_PRLID1_L2 8
#define M_TXP_QS_PRLID_2_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_2_PRLID1_L3 9
#define M_TXP_QS_PRLID_2_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_2_PRLID2_L2 16
#define M_TXP_QS_PRLID_2_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_2_PRLID2_L3 17
#define M_TXP_QS_PRLID_2_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_2_PRLID3_L2 24
#define M_TXP_QS_PRLID_2_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_2_PRLID3_L3 25
#define M_TXP_QS_PRLID_2_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_3 fields */
#define O_TXP_QS_PRLID_3_PRLID0_L2 0
#define M_TXP_QS_PRLID_3_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_3_PRLID0_L3 1
#define M_TXP_QS_PRLID_3_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_3_PRLID1_L2 8
#define M_TXP_QS_PRLID_3_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_3_PRLID1_L3 9
#define M_TXP_QS_PRLID_3_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_3_PRLID2_L2 16
#define M_TXP_QS_PRLID_3_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_3_PRLID2_L3 17
#define M_TXP_QS_PRLID_3_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_3_PRLID3_L2 24
#define M_TXP_QS_PRLID_3_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_3_PRLID3_L3 25
#define M_TXP_QS_PRLID_3_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_4 fields */
#define O_TXP_QS_PRLID_4_PRLID0_L2 0
#define M_TXP_QS_PRLID_4_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_4_PRLID0_L3 1
#define M_TXP_QS_PRLID_4_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_4_PRLID1_L2 8
#define M_TXP_QS_PRLID_4_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_4_PRLID1_L3 9
#define M_TXP_QS_PRLID_4_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_4_PRLID2_L2 16
#define M_TXP_QS_PRLID_4_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_4_PRLID2_L3 17
#define M_TXP_QS_PRLID_4_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_4_PRLID3_L2 24
#define M_TXP_QS_PRLID_4_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_4_PRLID3_L3 25
#define M_TXP_QS_PRLID_4_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_5 fields */
#define O_TXP_QS_PRLID_5_PRLID0_L2 0
#define M_TXP_QS_PRLID_5_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_5_PRLID0_L3 1
#define M_TXP_QS_PRLID_5_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_5_PRLID1_L2 8
#define M_TXP_QS_PRLID_5_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_5_PRLID1_L3 9
#define M_TXP_QS_PRLID_5_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_5_PRLID2_L2 16
#define M_TXP_QS_PRLID_5_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_5_PRLID2_L3 17
#define M_TXP_QS_PRLID_5_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_5_PRLID3_L2 24
#define M_TXP_QS_PRLID_5_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_5_PRLID3_L3 25
#define M_TXP_QS_PRLID_5_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_6 fields */
#define O_TXP_QS_PRLID_6_PRLID0_L2 0
#define M_TXP_QS_PRLID_6_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_6_PRLID0_L3 1
#define M_TXP_QS_PRLID_6_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_6_PRLID1_L2 8
#define M_TXP_QS_PRLID_6_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_6_PRLID1_L3 9
#define M_TXP_QS_PRLID_6_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_6_PRLID2_L2 16
#define M_TXP_QS_PRLID_6_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_6_PRLID2_L3 17
#define M_TXP_QS_PRLID_6_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_6_PRLID3_L2 24
#define M_TXP_QS_PRLID_6_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_6_PRLID3_L3 25
#define M_TXP_QS_PRLID_6_PRLID3_L3 0xf

/* Target register R_TXP_QS_PRLID_7 fields */
#define O_TXP_QS_PRLID_7_PRLID0_L2 0
#define M_TXP_QS_PRLID_7_PRLID0_L2 0x1
#define O_TXP_QS_PRLID_7_PRLID0_L3 1
#define M_TXP_QS_PRLID_7_PRLID0_L3 0xf
#define O_TXP_QS_PRLID_7_PRLID1_L2 8
#define M_TXP_QS_PRLID_7_PRLID1_L2 0x1
#define O_TXP_QS_PRLID_7_PRLID1_L3 9
#define M_TXP_QS_PRLID_7_PRLID1_L3 0xf
#define O_TXP_QS_PRLID_7_PRLID2_L2 16
#define M_TXP_QS_PRLID_7_PRLID2_L2 0x1
#define O_TXP_QS_PRLID_7_PRLID2_L3 17
#define M_TXP_QS_PRLID_7_PRLID2_L3 0xf
#define O_TXP_QS_PRLID_7_PRLID3_L2 24
#define M_TXP_QS_PRLID_7_PRLID3_L2 0x1
#define O_TXP_QS_PRLID_7_PRLID3_L3 25
#define M_TXP_QS_PRLID_7_PRLID3_L3 0xf

/* Target register R_TXP_SHAPER_CFG_0 fields */
#define O_TXP_SHAPER_CFG_0_RATE         0
#define M_TXP_SHAPER_CFG_0_RATE         0xffff
#define O_TXP_SHAPER_CFG_0_BURSTSIZE    16
#define M_TXP_SHAPER_CFG_0_BURSTSIZE    0x7f
#define O_TXP_SHAPER_CFG_0_LINERATE_ENA 29
#define M_TXP_SHAPER_CFG_0_LINERATE_ENA 0x1
#define O_TXP_SHAPER_CFG_0_EXCESS_ENA   30
#define M_TXP_SHAPER_CFG_0_EXCESS_ENA   0x1
#define O_TXP_SHAPER_CFG_0_SHAPER_ENA   31
#define M_TXP_SHAPER_CFG_0_SHAPER_ENA   0x1

/* Target register R_TXP_SHAPER_CFG_1 fields */
#define O_TXP_SHAPER_CFG_1_RATE         0
#define M_TXP_SHAPER_CFG_1_RATE         0xffff
#define O_TXP_SHAPER_CFG_1_BURSTSIZE    16
#define M_TXP_SHAPER_CFG_1_BURSTSIZE    0x7f
#define O_TXP_SHAPER_CFG_1_LINERATE_ENA 29
#define M_TXP_SHAPER_CFG_1_LINERATE_ENA 0x1
#define O_TXP_SHAPER_CFG_1_EXCESS_ENA   30
#define M_TXP_SHAPER_CFG_1_EXCESS_ENA   0x1
#define O_TXP_SHAPER_CFG_1_SHAPER_ENA   31
#define M_TXP_SHAPER_CFG_1_SHAPER_ENA   0x1

/* Target register R_TXP_SHAPER_CFG_2 fields */
#define O_TXP_SHAPER_CFG_2_RATE         0
#define M_TXP_SHAPER_CFG_2_RATE         0xffff
#define O_TXP_SHAPER_CFG_2_BURSTSIZE    16
#define M_TXP_SHAPER_CFG_2_BURSTSIZE    0x7f
#define O_TXP_SHAPER_CFG_2_LINERATE_ENA 29
#define M_TXP_SHAPER_CFG_2_LINERATE_ENA 0x1
#define O_TXP_SHAPER_CFG_2_EXCESS_ENA   30
#define M_TXP_SHAPER_CFG_2_EXCESS_ENA   0x1
#define O_TXP_SHAPER_CFG_2_SHAPER_ENA   31
#define M_TXP_SHAPER_CFG_2_SHAPER_ENA   0x1

/* Target register R_TXP_SHAPER_CFG_3 fields */
#define O_TXP_SHAPER_CFG_3_RATE         0
#define M_TXP_SHAPER_CFG_3_RATE         0xffff
#define O_TXP_SHAPER_CFG_3_BURSTSIZE    16
#define M_TXP_SHAPER_CFG_3_BURSTSIZE    0x7f
#define O_TXP_SHAPER_CFG_3_LINERATE_ENA 29
#define M_TXP_SHAPER_CFG_3_LINERATE_ENA 0x1
#define O_TXP_SHAPER_CFG_3_EXCESS_ENA   30
#define M_TXP_SHAPER_CFG_3_EXCESS_ENA   0x1
#define O_TXP_SHAPER_CFG_3_SHAPER_ENA   31
#define M_TXP_SHAPER_CFG_3_SHAPER_ENA   0x1

/* Target register R_TXP_REWR_CFG fields */
#define O_TXP_REWR_CFG_PRIO_MAP_0 0
#define M_TXP_REWR_CFG_PRIO_MAP_0 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_1 3
#define M_TXP_REWR_CFG_PRIO_MAP_1 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_2 6
#define M_TXP_REWR_CFG_PRIO_MAP_2 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_3 9
#define M_TXP_REWR_CFG_PRIO_MAP_3 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_4 12
#define M_TXP_REWR_CFG_PRIO_MAP_4 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_5 15
#define M_TXP_REWR_CFG_PRIO_MAP_5 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_6 18
#define M_TXP_REWR_CFG_PRIO_MAP_6 0x7
#define O_TXP_REWR_CFG_PRIO_MAP_7 21
#define M_TXP_REWR_CFG_PRIO_MAP_7 0x7
#define O_TXP_REWR_CFG_TAG_1Q     24
#define M_TXP_REWR_CFG_TAG_1Q     0x1
#define O_TXP_REWR_CFG_TAG_1P     25
#define M_TXP_REWR_CFG_TAG_1P     0x1

/* Target register R_TXP_REWR_UNTAGGED_VLAN fields */
#define O_TXP_REWR_UNTAGGED_VLAN_UNTAGGED_VLAN 0
#define M_TXP_REWR_UNTAGGED_VLAN_UNTAGGED_VLAN 0xfff

/* Target register R_TXP_REWR_L3_SMAC_LO_0 fields */
#define O_TXP_REWR_L3_SMAC_LO_0_SMAC_LO_0 0
#define M_TXP_REWR_L3_SMAC_LO_0_SMAC_LO_0 0xffffffff

/* Target register R_TXP_REWR_L3_SMAC_HI_0 fields */
#define O_TXP_REWR_L3_SMAC_HI_0_SMAC_HI_0 0
#define M_TXP_REWR_L3_SMAC_HI_0_SMAC_HI_0 0xffff
#define O_TXP_REWR_L3_SMAC_HI_0_VID_0     16
#define M_TXP_REWR_L3_SMAC_HI_0_VID_0     0xfff

/* Target register R_TXP_REWR_L3_SMAC_LO_1 fields */
#define O_TXP_REWR_L3_SMAC_LO_1_SMAC_LO_1 0
#define M_TXP_REWR_L3_SMAC_LO_1_SMAC_LO_1 0xffffffff

/* Target register R_TXP_REWR_L3_SMAC_HI_1 fields */
#define O_TXP_REWR_L3_SMAC_HI_1_SMAC_HI_1 0
#define M_TXP_REWR_L3_SMAC_HI_1_SMAC_HI_1 0xffff
#define O_TXP_REWR_L3_SMAC_HI_1_VID_1     16
#define M_TXP_REWR_L3_SMAC_HI_1_VID_1     0xfff

/* Target register R_TXP_REWR_L3_SMAC_LO_2 fields */
#define O_TXP_REWR_L3_SMAC_LO_2_SMAC_LO_2 0
#define M_TXP_REWR_L3_SMAC_LO_2_SMAC_LO_2 0xffffffff

/* Target register R_TXP_REWR_L3_SMAC_HI_2 fields */
#define O_TXP_REWR_L3_SMAC_HI_2_SMAC_HI_2 0
#define M_TXP_REWR_L3_SMAC_HI_2_SMAC_HI_2 0xffff
#define O_TXP_REWR_L3_SMAC_HI_2_VID_2     16
#define M_TXP_REWR_L3_SMAC_HI_2_VID_2     0xfff

/* Target register R_TXP_REWR_L3_SMAC_LO_3 fields */
#define O_TXP_REWR_L3_SMAC_LO_3_SMAC_LO_3 0
#define M_TXP_REWR_L3_SMAC_LO_3_SMAC_LO_3 0xffffffff

/* Target register R_TXP_REWR_L3_SMAC_HI_3 fields */
#define O_TXP_REWR_L3_SMAC_HI_3_SMAC_HI_3 0
#define M_TXP_REWR_L3_SMAC_HI_3_SMAC_HI_3 0xffff
#define O_TXP_REWR_L3_SMAC_HI_3_VID_3     16
#define M_TXP_REWR_L3_SMAC_HI_3_VID_3     0xfff

/* Target register R_TXP_REWR_L3_TTL fields */
#define O_TXP_REWR_L3_TTL_TTL_0 0
#define M_TXP_REWR_L3_TTL_TTL_0 0xff
#define O_TXP_REWR_L3_TTL_TTL_1 8
#define M_TXP_REWR_L3_TTL_TTL_1 0xff
#define O_TXP_REWR_L3_TTL_TTL_2 16
#define M_TXP_REWR_L3_TTL_TTL_2 0xff
#define O_TXP_REWR_L3_TTL_TTL_3 24
#define M_TXP_REWR_L3_TTL_TTL_3 0xff

/* Target register R_TXP_SCHED_STATUS fields */
#define O_TXP_SCHED_STATUS_STATE  0
#define M_TXP_SCHED_STATUS_STATE  0xf
#define O_TXP_SCHED_STATUS_TOKENS 4
#define M_TXP_SCHED_STATUS_TOKENS 0x1f

/* Target register R_TXP_QS_MODULE_WM fields */
#define O_TXP_QS_MODULE_WM_MODULE_WM_LOW  0
#define M_TXP_QS_MODULE_WM_MODULE_WM_LOW  0x3f
#define O_TXP_QS_MODULE_WM_MODULE_WM_HIGH 6
#define M_TXP_QS_MODULE_WM_MODULE_WM_HIGH 0x3f
#define O_TXP_QS_MODULE_WM_DP_ENA         12   /* Gatwick-Ie only */
#define M_TXP_QS_MODULE_WM_DP_ENA         0x1  /* Gatwick-Ie only */

/* Target register R_TXP_QS_DROP_CNT fields */
#define O_TXP_QS_DROP_CNT_QS_DROP_CNT 0          /* Not Gatwick-Ie */
#define M_TXP_QS_DROP_CNT_QS_DROP_CNT 0xffffffff /* Not Gatwick-Ie */

/* Target register R_TXP_QS_CPU_DATA fields */
#define O_TXP_QS_CPU_DATA_DATA 0
#define M_TXP_QS_CPU_DATA_DATA 0xffffffff

/* Target register R_TXP_QS_CPU_CTRL fields */
#define O_TXP_QS_CPU_CTRL_CLEAR 0
#define M_TXP_QS_CPU_CTRL_CLEAR 0x1
#define O_TXP_QS_CPU_CTRL_BUSY  1
#define M_TXP_QS_CPU_CTRL_BUSY  0x1

/* Target register R_TXP_QS_STICKY fields */
#define O_TXP_QS_STICKY_ZERO_LENGTH    0
#define M_TXP_QS_STICKY_ZERO_LENGTH    0x1
#define O_TXP_QS_STICKY_CELL_START_ERR 1
#define M_TXP_QS_STICKY_CELL_START_ERR 0x1
#define O_TXP_QS_STICKY_CELL_VALID_ERR 2
#define M_TXP_QS_STICKY_CELL_VALID_ERR 0x1
#define O_TXP_QS_STICKY_CELL_FIRST     3
#define M_TXP_QS_STICKY_CELL_FIRST     0x1
#define O_TXP_QS_STICKY_CELL_NON_FIRST 4
#define M_TXP_QS_STICKY_CELL_NON_FIRST 0x1
#define O_TXP_QS_STICKY_VALID_ERR      5
#define M_TXP_QS_STICKY_VALID_ERR      0x1
#define O_TXP_QS_STICKY_REQ_DROP       6
#define M_TXP_QS_STICKY_REQ_DROP       0x1
#define O_TXP_QS_STICKY_CPU_NON_FIRST  7
#define M_TXP_QS_STICKY_CPU_NON_FIRST  0x1
#define O_TXP_QS_STICKY_REQ_FAILURE    8
#define M_TXP_QS_STICKY_REQ_FAILURE    0x1
#define O_TXP_QS_STICKY_RAM_EVEN_ERR   9
#define M_TXP_QS_STICKY_RAM_EVEN_ERR   0x1
#define O_TXP_QS_STICKY_RAM_ODD_ERR    10
#define M_TXP_QS_STICKY_RAM_ODD_ERR    0x1

/* Target register R_TXP_QS_LINK_INDEX fields */
#define O_TXP_QS_LINK_INDEX_LINK_INDEX 0
#define M_TXP_QS_LINK_INDEX_LINK_INDEX 0x3f

/* Target register R_TXP_QS_LINK_DATA fields */
#define O_TXP_QS_LINK_DATA_LINK_PTR   0
#define M_TXP_QS_LINK_DATA_LINK_PTR   0x3f
#define O_TXP_QS_LINK_DATA_LINK_INUSE 6
#define M_TXP_QS_LINK_DATA_LINK_INUSE 0x1

/* Target register R_TXP_QS_QUEUE_INDEX fields */
#define O_TXP_QS_QUEUE_INDEX_QHS_INDEX 0
#define M_TXP_QS_QUEUE_INDEX_QHS_INDEX 0x1f

/* Target register R_TXP_QS_QUEUE_DATA0 fields */
#define O_TXP_QS_QUEUE_DATA0_QHS_INUSE   0
#define M_TXP_QS_QUEUE_DATA0_QHS_INUSE   0x1
#define O_TXP_QS_QUEUE_DATA0_QHS_RX      1
#define M_TXP_QS_QUEUE_DATA0_QHS_RX      0x1
#define O_TXP_QS_QUEUE_DATA0_QHS_RXPTR   2
#define M_TXP_QS_QUEUE_DATA0_QHS_RXPTR   0x1ff
#define O_TXP_QS_QUEUE_DATA0_QHS_RETXPTR 11
#define M_TXP_QS_QUEUE_DATA0_QHS_RETXPTR 0x1ff
#define O_TXP_QS_QUEUE_DATA0_QHS_TXPTR   20
#define M_TXP_QS_QUEUE_DATA0_QHS_TXPTR   0xfff

/* Target register R_TXP_QS_QUEUE_DATA1 fields */
#define O_TXP_QS_QUEUE_DATA1_QHS_TXSET   0
#define M_TXP_QS_QUEUE_DATA1_QHS_TXSET   0x1
#define O_TXP_QS_QUEUE_DATA1_QHS_TXVALID 1
#define M_TXP_QS_QUEUE_DATA1_QHS_TXVALID 0x1
#define O_TXP_QS_QUEUE_DATA1_QHS_SRCFPTR 2
#define M_TXP_QS_QUEUE_DATA1_QHS_SRCFPTR 0x1ff

/* Target register R_TXP_QS_REPLAY_CFG fields */
#define O_TXP_QS_REPLAY_CFG_REPLAY_ENA 0
#define M_TXP_QS_REPLAY_CFG_REPLAY_ENA 0x1

/* Target register R_TXP_QS_RFS_CFG fields */
#define O_TXP_QS_RFS_CFG_POINTER   0
#define M_TXP_QS_RFS_CFG_POINTER   0x3f
#define O_TXP_QS_RFS_CFG_VALID     6
#define M_TXP_QS_RFS_CFG_VALID     0x1
#define O_TXP_QS_RFS_CFG_CPU_QUEUE 7
#define M_TXP_QS_RFS_CFG_CPU_QUEUE 0x3f
#define O_TXP_QS_RFS_CFG_CPU_VALID 13
#define M_TXP_QS_RFS_CFG_CPU_VALID 0x1

/* Target register R_TXP_STACKING_TAG_CFG fields */
#define O_TXP_STACKING_TAG_CFG_STACKING_PORT_ENA 0   /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_STACKING_PORT_ENA 0x1 /* Gatwick-Ie only */
#define O_TXP_STACKING_TAG_CFG_ST_DP_REMAP_0     4   /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_ST_DP_REMAP_0     0x3 /* Gatwick-Ie only */
#define O_TXP_STACKING_TAG_CFG_ST_DP_REMAP_1     6   /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_ST_DP_REMAP_1     0x3 /* Gatwick-Ie only */
#define O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_0 8   /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_0 0xf /* Gatwick-Ie only */
#define O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_1 12  /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_1 0xf /* Gatwick-Ie only */
#define O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_2 16  /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_2 0xf /* Gatwick-Ie only */
#define O_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_3 20  /* Gatwick-Ie only */
#define M_TXP_STACKING_TAG_CFG_PRI_MAP_ST_PRIO_3 0xf /* Gatwick-Ie only */

/* Target register R_D10_MAC_MODE_CFG fields */
#define O_D10_MAC_MODE_CFG_TX_ENA          0
#define M_D10_MAC_MODE_CFG_TX_ENA          0x1
#define O_D10_MAC_MODE_CFG_RX_ENA          1
#define M_D10_MAC_MODE_CFG_RX_ENA          0x1
#define O_D10_MAC_MODE_CFG_VLAN_AWARE_ENA  2
#define M_D10_MAC_MODE_CFG_VLAN_AWARE_ENA  0x1
#define O_D10_MAC_MODE_CFG_PRM_CHK         3
#define M_D10_MAC_MODE_CFG_PRM_CHK         0x1
#define O_D10_MAC_MODE_CFG_STRETCH_MODE    4
#define M_D10_MAC_MODE_CFG_STRETCH_MODE    0x1
#define O_D10_MAC_MODE_CFG_INR_ERR         5
#define M_D10_MAC_MODE_CFG_INR_ERR         0x1
#define O_D10_MAC_MODE_CFG_OOR_ERR         6
#define M_D10_MAC_MODE_CFG_OOR_ERR         0x1
#define O_D10_MAC_MODE_CFG_SFD_CHK         7
#define M_D10_MAC_MODE_CFG_SFD_CHK         0x1
#define O_D10_MAC_MODE_CFG_LFS_MODE        8
#define M_D10_MAC_MODE_CFG_LFS_MODE        0x1
#define O_D10_MAC_MODE_CFG_LFS_DIS_TX      9
#define M_D10_MAC_MODE_CFG_LFS_DIS_TX      0x1
#define O_D10_MAC_MODE_CFG_LFS_INH_TX      10
#define M_D10_MAC_MODE_CFG_LFS_INH_TX      0x1
#define O_D10_MAC_MODE_CFG_XGMII_GEN_MODE  11
#define M_D10_MAC_MODE_CFG_XGMII_GEN_MODE  0x1
#define O_D10_MAC_MODE_CFG_EXT_SOP_CHK     12
#define M_D10_MAC_MODE_CFG_EXT_SOP_CHK     0x1
#define O_D10_MAC_MODE_CFG_EXT_EOP_CHK     13
#define M_D10_MAC_MODE_CFG_EXT_EOP_CHK     0x1
#define O_D10_MAC_MODE_CFG_PRM_SHK_CHK_DIS 15  /* Gatwick-Ie only */
#define M_D10_MAC_MODE_CFG_PRM_SHK_CHK_DIS 0x1 /* Gatwick-Ie only */

/* Target register R_D10_MAC_PAUSE_CFG fields */
#define O_D10_MAC_PAUSE_CFG_TX_PAUSE_VAL    0
#define M_D10_MAC_PAUSE_CFG_TX_PAUSE_VAL    0xffff
#define O_D10_MAC_PAUSE_CFG_TX_PAUSE_ENA    16
#define M_D10_MAC_PAUSE_CFG_TX_PAUSE_ENA    0x1
#define O_D10_MAC_PAUSE_CFG_RX_PAUSE_ENA    17
#define M_D10_MAC_PAUSE_CFG_RX_PAUSE_ENA    0x1
#define O_D10_MAC_PAUSE_CFG_TX_PAUSE_XONOFF 18
#define M_D10_MAC_PAUSE_CFG_TX_PAUSE_XONOFF 0x1

/* Target register R_D10_MAC_MAXLEN_CFG fields */
#define O_D10_MAC_MAXLEN_CFG_MAX_LEN 0
#define M_D10_MAC_MAXLEN_CFG_MAX_LEN 0xffff

/* Target register R_D10_MAC_MAC_ADDR_HIGH_CFG fields */
#define O_D10_MAC_MAC_ADDR_HIGH_CFG_MAC_ADDR_HIGH 0
#define M_D10_MAC_MAC_ADDR_HIGH_CFG_MAC_ADDR_HIGH 0xffffff

/* Target register R_D10_MAC_MAC_ADDR_LOW_CFG fields */
#define O_D10_MAC_MAC_ADDR_LOW_CFG_MAC_ADDR_LOW 0
#define M_D10_MAC_MAC_ADDR_LOW_CFG_MAC_ADDR_LOW 0xffffff

/* Target register R_D10_MAC_VSC7226_PCS_CFG fields */
#define O_D10_MAC_VSC7226_PCS_CFG_VSC7226_RX_ENA 0   /* Not Gatwick-Ie */
#define M_D10_MAC_VSC7226_PCS_CFG_VSC7226_RX_ENA 0x1 /* Not Gatwick-Ie */
#define O_D10_MAC_VSC7226_PCS_CFG_VSC7226_TX_ENA 1   /* Not Gatwick-Ie */
#define M_D10_MAC_VSC7226_PCS_CFG_VSC7226_TX_ENA 0x1 /* Not Gatwick-Ie */

/* Target register R_D10_MAC_MISC_CFG fields */
#define O_D10_MAC_MISC_CFG_SWAP_RX_PINS_ENA 0
#define M_D10_MAC_MISC_CFG_SWAP_RX_PINS_ENA 0x1
#define O_D10_MAC_MISC_CFG_SWAP_TX_PINS_ENA 1
#define M_D10_MAC_MISC_CFG_SWAP_TX_PINS_ENA 0x1

/* Target register R_D10_MAC_RESET_CTRL fields */
#define O_D10_MAC_RESET_CTRL_RX_RESET 0
#define M_D10_MAC_RESET_CTRL_RX_RESET 0x1
#define O_D10_MAC_RESET_CTRL_TX_RESET 1
#define M_D10_MAC_RESET_CTRL_TX_RESET 0x1

/* Target register R_D10_MAC_DROP_CNT fields */
#define O_D10_MAC_DROP_CNT_DROP_CNT 0
#define M_D10_MAC_DROP_CNT_DROP_CNT 0xffffffff

/* Target register R_D10_MAC_DBG_CFG fields */
#define O_D10_MAC_DBG_CFG_HOST_LOOPBACK 0
#define M_D10_MAC_DBG_CFG_HOST_LOOPBACK 0x1
#define O_D10_MAC_DBG_CFG_PHY_LOOPBACK  1
#define M_D10_MAC_DBG_CFG_PHY_LOOPBACK  0x1
#define O_D10_MAC_DBG_CFG_INV_RX_CLOCK  2
#define M_D10_MAC_DBG_CFG_INV_RX_CLOCK  0x1

/* Target register R_D10_MAC_RX_LANE_STICKY_0 fields */
#define O_D10_MAC_RX_LANE_STICKY_0_DATA0 0
#define M_D10_MAC_RX_LANE_STICKY_0_DATA0 0x1
#define O_D10_MAC_RX_LANE_STICKY_0_CTRL0 1
#define M_D10_MAC_RX_LANE_STICKY_0_CTRL0 0x1
#define O_D10_MAC_RX_LANE_STICKY_0_IDLE0 2
#define M_D10_MAC_RX_LANE_STICKY_0_IDLE0 0x1
#define O_D10_MAC_RX_LANE_STICKY_0_PULS0 3
#define M_D10_MAC_RX_LANE_STICKY_0_PULS0 0x1
#define O_D10_MAC_RX_LANE_STICKY_0_SOP0  4
#define M_D10_MAC_RX_LANE_STICKY_0_SOP0  0x1
#define O_D10_MAC_RX_LANE_STICKY_0_EOP0  5
#define M_D10_MAC_RX_LANE_STICKY_0_EOP0  0x1
#define O_D10_MAC_RX_LANE_STICKY_0_ERR0  6
#define M_D10_MAC_RX_LANE_STICKY_0_ERR0  0x1
#define O_D10_MAC_RX_LANE_STICKY_0_LANE1 8
#define M_D10_MAC_RX_LANE_STICKY_0_LANE1 0x7f
#define O_D10_MAC_RX_LANE_STICKY_0_LANE2 16
#define M_D10_MAC_RX_LANE_STICKY_0_LANE2 0x7f
#define O_D10_MAC_RX_LANE_STICKY_0_LANE3 24
#define M_D10_MAC_RX_LANE_STICKY_0_LANE3 0x7f

/* Target register R_D10_MAC_RX_LANE_STICKY_1 fields */
#define O_D10_MAC_RX_LANE_STICKY_1_LANE4 0
#define M_D10_MAC_RX_LANE_STICKY_1_LANE4 0x7f
#define O_D10_MAC_RX_LANE_STICKY_1_LANE5 8
#define M_D10_MAC_RX_LANE_STICKY_1_LANE5 0x7f
#define O_D10_MAC_RX_LANE_STICKY_1_LANE6 16
#define M_D10_MAC_RX_LANE_STICKY_1_LANE6 0x7f
#define O_D10_MAC_RX_LANE_STICKY_1_LANE7 24
#define M_D10_MAC_RX_LANE_STICKY_1_LANE7 0x7f

/* Target register R_D10_MAC_TX_MONITOR_STICKY fields */
#define O_D10_MAC_TX_MONITOR_STICKY_DIS_STATE        0
#define M_D10_MAC_TX_MONITOR_STICKY_DIS_STATE        0x1
#define O_D10_MAC_TX_MONITOR_STICKY_IDLE_STATE       1
#define M_D10_MAC_TX_MONITOR_STICKY_IDLE_STATE       0x1
#define O_D10_MAC_TX_MONITOR_STICKY_PAUSE_STATE      2
#define M_D10_MAC_TX_MONITOR_STICKY_PAUSE_STATE      0x1
#define O_D10_MAC_TX_MONITOR_STICKY_REMOTE_ERR_STATE 3
#define M_D10_MAC_TX_MONITOR_STICKY_REMOTE_ERR_STATE 0x1
#define O_D10_MAC_TX_MONITOR_STICKY_LOCAL_ERR_STATE  4
#define M_D10_MAC_TX_MONITOR_STICKY_LOCAL_ERR_STATE  0x1

/* Target register R_D10_MAC_MISC_STICKY fields */
#define O_D10_MAC_MISC_STICKY_RX_RESYNC_FIFO_OVF 0
#define M_D10_MAC_MISC_STICKY_RX_RESYNC_FIFO_OVF 0x1
#define O_D10_MAC_MISC_STICKY_TX_SOF_ERR         1
#define M_D10_MAC_MISC_STICKY_TX_SOF_ERR         0x1
#define O_D10_MAC_MISC_STICKY_TX_EOF_ERR         2
#define M_D10_MAC_MISC_STICKY_TX_EOF_ERR         0x1
#define O_D10_MAC_MISC_STICKY_TX_BUFF_UNF        3
#define M_D10_MAC_MISC_STICKY_TX_BUFF_UNF        0x1
#define O_D10_MAC_MISC_STICKY_TX_BUFF_OVF        4
#define M_D10_MAC_MISC_STICKY_TX_BUFF_OVF        0x1
#define O_D10_MAC_MISC_STICKY_PARTIAL_FAIL       5
#define M_D10_MAC_MISC_STICKY_PARTIAL_FAIL       0x1
#define O_D10_MAC_MISC_STICKY_BUFF_SM_FAIL       6
#define M_D10_MAC_MISC_STICKY_BUFF_SM_FAIL       0x1
#define O_D10_MAC_MISC_STICKY_RX_SOF_ERR         7
#define M_D10_MAC_MISC_STICKY_RX_SOF_ERR         0x1
#define O_D10_MAC_MISC_STICKY_RX_EOF_ERR         8
#define M_D10_MAC_MISC_STICKY_RX_EOF_ERR         0x1

/* Target register R_D10_MAC_PB_PORT_CFG fields */
#define O_D10_MAC_PB_PORT_CFG_PB_ENA 0   /* Gatwick-Ie only */
#define M_D10_MAC_PB_PORT_CFG_PB_ENA 0x1 /* Gatwick-Ie only */

/* Target register R_D10_MAC_PB_MODE_CFG fields */
#define O_D10_MAC_PB_MODE_CFG_PB_TAG_VAL 0      /* Gatwick-Ie only */
#define M_D10_MAC_PB_MODE_CFG_PB_TAG_VAL 0xffff /* Gatwick-Ie only */

/* Target register R_SE_RX_IN_BYTES_CNT fields */
#define O_SE_RX_IN_BYTES_CNT_RX_IN_BYTES_CNT 0
#define M_SE_RX_IN_BYTES_CNT_RX_IN_BYTES_CNT 0xffffffff

/* Target register R_SE_RX_SYMBOL_CARRIER_ERR_CNT fields */
#define O_SE_RX_SYMBOL_CARRIER_ERR_CNT_RX_SYMBOL_CARRIER_CNT 0
#define M_SE_RX_SYMBOL_CARRIER_ERR_CNT_RX_SYMBOL_CARRIER_CNT 0xffffffff

/* Target register R_SE_RX_PAUSE_CNT fields */
#define O_SE_RX_PAUSE_CNT_RX_PAUS_CNTE 0
#define M_SE_RX_PAUSE_CNT_RX_PAUS_CNTE 0xffffffff

/* Target register R_SE_RX_UNSUP_OPCODE_CNT fields */
#define O_SE_RX_UNSUP_OPCODE_CNT_RX_UNSUP_OPCODE_CNT 0
#define M_SE_RX_UNSUP_OPCODE_CNT_RX_UNSUP_OPCODE_CNT 0xffffffff

/* Target register R_SE_RX_OK_BYTES_CNT fields */
#define O_SE_RX_OK_BYTES_CNT_RX_OK_BYTES_CNT 0
#define M_SE_RX_OK_BYTES_CNT_RX_OK_BYTES_CNT 0xffffffff

/* Target register R_SE_RX_BAD_BYTES_CNT fields */
#define O_SE_RX_BAD_BYTES_CNT_RX_BAD_BYTES_CNT 0
#define M_SE_RX_BAD_BYTES_CNT_RX_BAD_BYTES_CNT 0xffffffff

/* Target register R_SE_RX_UNICAST_CNT fields */
#define O_SE_RX_UNICAST_CNT_RX_UNICAST_CNT 0
#define M_SE_RX_UNICAST_CNT_RX_UNICAST_CNT 0xffffffff

/* Target register R_SE_RX_MULTICAST_CNT fields */
#define O_SE_RX_MULTICAST_CNT_RX_MULTICAST_CNT 0
#define M_SE_RX_MULTICAST_CNT_RX_MULTICAST_CNT 0xffffffff

/* Target register R_SE_RX_BROADCAST_CNT fields */
#define O_SE_RX_BROADCAST_CNT_RX_BROADCAST_CNT 0
#define M_SE_RX_BROADCAST_CNT_RX_BROADCAST_CNT 0xffffffff

/* Target register R_SE_RX_CRC_ERR_CNT fields */
#define O_SE_RX_CRC_ERR_CNT_RX_CRC_ERR_CNT 0
#define M_SE_RX_CRC_ERR_CNT_RX_CRC_ERR_CNT 0xffffffff

/* Target register R_SE_RX_ALIGNMENT_ERR_CNT fields */
#define O_SE_RX_ALIGNMENT_ERR_CNT_RX_ALIGNMENT_ERR_CNT 0
#define M_SE_RX_ALIGNMENT_ERR_CNT_RX_ALIGNMENT_ERR_CNT 0xffffffff

/* Target register R_SE_RX_UNDERSIZE_CNT fields */
#define O_SE_RX_UNDERSIZE_CNT_RX_UNDERSIZE_CNT 0
#define M_SE_RX_UNDERSIZE_CNT_RX_UNDERSIZE_CNT 0xffffffff

/* Target register R_SE_RX_FRAGMENTS_CNT fields */
#define O_SE_RX_FRAGMENTS_CNT_RX_FRAGMENTS_CNT 0
#define M_SE_RX_FRAGMENTS_CNT_RX_FRAGMENTS_CNT 0xffffffff

/* Target register R_SE_RX_IN_RANGE_LENGTH_ERR_CNT fields */
#define O_SE_RX_IN_RANGE_LENGTH_ERR_CNT_RX_IN_RANGE_LENGTH_ERR_CNT 0
#define M_SE_RX_IN_RANGE_LENGTH_ERR_CNT_RX_IN_RANGE_LENGTH_ERR_CNT 0xffffffff

/* Target register R_SE_RX_OUT_OF_RANGE_LENGTH_ERR_CNT fields */
#define O_SE_RX_OUT_OF_RANGE_LENGTH_ERR_CNT_RX_OUT_OF_RANGE_LENGTH_ERR_CNT 0
#define M_SE_RX_OUT_OF_RANGE_LENGTH_ERR_CNT_RX_OUT_OF_RANGE_LENGTH_ERR_CNT 0xffffffff

/* Target register R_SE_RX_OVERSIZE_CNT fields */
#define O_SE_RX_OVERSIZE_CNT_RX_OVERSIZE_CNT 0
#define M_SE_RX_OVERSIZE_CNT_RX_OVERSIZE_CNT 0xffffffff

/* Target register R_SE_RX_JABBERS_CNT fields */
#define O_SE_RX_JABBERS_CNT_RX_JABBERS_CNT 0
#define M_SE_RX_JABBERS_CNT_RX_JABBERS_CNT 0xffffffff

/* Target register R_SE_RX_SIZE64_CNT fields */
#define O_SE_RX_SIZE64_CNT_RX_SIZE64_CNT 0
#define M_SE_RX_SIZE64_CNT_RX_SIZE64_CNT 0xffffffff

/* Target register R_SE_RX_SIZE65TO127_CNT fields */
#define O_SE_RX_SIZE65TO127_CNT_RX_SIZE65TO127_CNT 0
#define M_SE_RX_SIZE65TO127_CNT_RX_SIZE65TO127_CNT 0xffffffff

/* Target register R_SE_RX_SIZE128TO255_CNT fields */
#define O_SE_RX_SIZE128TO255_CNT_RX_SIZE128TO255_CNT 0
#define M_SE_RX_SIZE128TO255_CNT_RX_SIZE128TO255_CNT 0xffffffff

/* Target register R_SE_RX_SIZE256TO511_CNT fields */
#define O_SE_RX_SIZE256TO511_CNT_RX_SIZE256TO511_CNT 0
#define M_SE_RX_SIZE256TO511_CNT_RX_SIZE256TO511_CNT 0xffffffff

/* Target register R_SE_RX_SIZE512TO1023_CNT fields */
#define O_SE_RX_SIZE512TO1023_CNT_RX_SIZE512TO1023_CNT 0
#define M_SE_RX_SIZE512TO1023_CNT_RX_SIZE512TO1023_CNT 0xffffffff

/* Target register R_SE_RX_SIZE1024TO1518_CNT fields */
#define O_SE_RX_SIZE1024TO1518_CNT_RX_SIZE1024TO1518_CNT 0
#define M_SE_RX_SIZE1024TO1518_CNT_RX_SIZE1024TO1518_CNT 0xffffffff

/* Target register R_SE_RX_SIZE1519TOMAX_CNT fields */
#define O_SE_RX_SIZE1519TOMAX_CNT_RX_SIZE1519TOMAX_CNT 0
#define M_SE_RX_SIZE1519TOMAX_CNT_RX_SIZE1519TOMAX_CNT 0xffffffff

/* Target register R_SE_TX_OUT_BYTES_CNT fields */
#define O_SE_TX_OUT_BYTES_CNT_TX_OUT_BYTES_CNT 0
#define M_SE_TX_OUT_BYTES_CNT_TX_OUT_BYTES_CNT 0xffffffff

/* Target register R_SE_TX_PAUSE_CNT fields */
#define O_SE_TX_PAUSE_CNT_TX_PAUSE_CNT 0
#define M_SE_TX_PAUSE_CNT_TX_PAUSE_CNT 0xffffffff

/* Target register R_SE_TX_OK_BYTES_CNT fields */
#define O_SE_TX_OK_BYTES_CNT_TX_OK_BYTES_CNT 0
#define M_SE_TX_OK_BYTES_CNT_TX_OK_BYTES_CNT 0xffffffff

/* Target register R_SE_TX_UNICAST_CNT fields */
#define O_SE_TX_UNICAST_CNT_TX_UNICAST_CNT 0
#define M_SE_TX_UNICAST_CNT_TX_UNICAST_CNT 0xffffffff

/* Target register R_SE_TX_MULTICAST_CNT fields */
#define O_SE_TX_MULTICAST_CNT_TX_MULTICAST_CNT 0
#define M_SE_TX_MULTICAST_CNT_TX_MULTICAST_CNT 0xffffffff

/* Target register R_SE_TX_BROADCAST_CNT fields */
#define O_SE_TX_BROADCAST_CNT_TX_BROADCAST_CNT 0
#define M_SE_TX_BROADCAST_CNT_TX_BROADCAST_CNT 0xffffffff

/* Target register R_SE_TX_MULTI_COLL_CNT fields */
#define O_SE_TX_MULTI_COLL_CNT_TX_MULTI_COLL_CNT 0
#define M_SE_TX_MULTI_COLL_CNT_TX_MULTI_COLL_CNT 0xffffffff

/* Target register R_SE_TX_LATE_COLL_CNT fields */
#define O_SE_TX_LATE_COLL_CNT_TX_LATE_COLL_CNT 0
#define M_SE_TX_LATE_COLL_CNT_TX_LATE_COLL_CNT 0xffffffff

/* Target register R_SE_TX_XCOLL_CNT fields */
#define O_SE_TX_XCOLL_CNT_TX_XCOLL_CNT 0
#define M_SE_TX_XCOLL_CNT_TX_XCOLL_CNT 0xffffffff

/* Target register R_SE_TX_DEFER_CNT fields */
#define O_SE_TX_DEFER_CNT_TX_DEFER_CNT 0
#define M_SE_TX_DEFER_CNT_TX_DEFER_CNT 0xffffffff

/* Target register R_SE_TX_XDEFER_CNT fields */
#define O_SE_TX_XDEFER_CNT_TX_XDEFER_CNT 0
#define M_SE_TX_XDEFER_CNT_TX_XDEFER_CNT 0xffffffff

/* Target register R_SE_TX_CSENSE_CNT fields */
#define O_SE_TX_CSENSE_CNT_TX_CSENSE_CNT 0
#define M_SE_TX_CSENSE_CNT_TX_CSENSE_CNT 0xffffffff

/* Target register R_SE_TX_SIZE64_CNT fields */
#define O_SE_TX_SIZE64_CNT_TX_SIZE64_CNT 0
#define M_SE_TX_SIZE64_CNT_TX_SIZE64_CNT 0xffffffff

/* Target register R_SE_TX_SIZE65TO127_CNT fields */
#define O_SE_TX_SIZE65TO127_CNT_TX_SIZE65TO127_CNT 0
#define M_SE_TX_SIZE65TO127_CNT_TX_SIZE65TO127_CNT 0xffffffff

/* Target register R_SE_TX_SIZE128TO255_CNT fields */
#define O_SE_TX_SIZE128TO255_CNT_TX_SIZE128TO255_CNT 0
#define M_SE_TX_SIZE128TO255_CNT_TX_SIZE128TO255_CNT 0xffffffff

/* Target register R_SE_TX_SIZE256TO511_CNT fields */
#define O_SE_TX_SIZE256TO511_CNT_TX_SIZE256TO511_CNT 0
#define M_SE_TX_SIZE256TO511_CNT_TX_SIZE256TO511_CNT 0xffffffff

/* Target register R_SE_TX_SIZE512TO1023_CNT fields */
#define O_SE_TX_SIZE512TO1023_CNT_TX_SIZE512TO1023_CNT 0
#define M_SE_TX_SIZE512TO1023_CNT_TX_SIZE512TO1023_CNT 0xffffffff

/* Target register R_SE_TX_SIZE1024TO1518_CNT fields */
#define O_SE_TX_SIZE1024TO1518_CNT_TX_SIZE1024TO1518_CNT 0
#define M_SE_TX_SIZE1024TO1518_CNT_TX_SIZE1024TO1518_CNT 0xffffffff

/* Target register R_SE_TX_SIZE1519TOMAX_CNT fields */
#define O_SE_TX_SIZE1519TOMAX_CNT_TX_SIZE1519TOMAX_CNT 0
#define M_SE_TX_SIZE1519TOMAX_CNT_TX_SIZE1519TOMAX_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF1_CNT fields */
#define O_SE_TX_BACKOFF1_CNT_TX_BACKOFF1_CNT 0
#define M_SE_TX_BACKOFF1_CNT_TX_BACKOFF1_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF2_CNT fields */
#define O_SE_TX_BACKOFF2_CNT_TX_BACKOFF2_CNT 0
#define M_SE_TX_BACKOFF2_CNT_TX_BACKOFF2_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF3_CNT fields */
#define O_SE_TX_BACKOFF3_CNT_TX_BACKOFF3_CNT 0
#define M_SE_TX_BACKOFF3_CNT_TX_BACKOFF3_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF4_CNT fields */
#define O_SE_TX_BACKOFF4_CNT_TX_BACKOFF4_CNT 0
#define M_SE_TX_BACKOFF4_CNT_TX_BACKOFF4_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF5_CNT fields */
#define O_SE_TX_BACKOFF5_CNT_TX_BACKOFF5_CNT 0
#define M_SE_TX_BACKOFF5_CNT_TX_BACKOFF5_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF6_CNT fields */
#define O_SE_TX_BACKOFF6_CNT_TX_BACKOFF6_CNT 0
#define M_SE_TX_BACKOFF6_CNT_TX_BACKOFF6_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF7_CNT fields */
#define O_SE_TX_BACKOFF7_CNT_TX_BACKOFF7_CNT 0
#define M_SE_TX_BACKOFF7_CNT_TX_BACKOFF7_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF8_CNT fields */
#define O_SE_TX_BACKOFF8_CNT_TX_BACKOFF8_CNT 0
#define M_SE_TX_BACKOFF8_CNT_TX_BACKOFF8_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF9_CNT fields */
#define O_SE_TX_BACKOFF9_CNT_TX_BACKOFF9_CNT 0
#define M_SE_TX_BACKOFF9_CNT_TX_BACKOFF9_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF10_CNT fields */
#define O_SE_TX_BACKOFF10_CNT_TX_BACKOFF10_CNT 0
#define M_SE_TX_BACKOFF10_CNT_TX_BACKOFF10_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF11_CNT fields */
#define O_SE_TX_BACKOFF11_CNT_TX_BACKOFF11_CNT 0
#define M_SE_TX_BACKOFF11_CNT_TX_BACKOFF11_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF12_CNT fields */
#define O_SE_TX_BACKOFF12_CNT_TX_BACKOFF12_CNT 0
#define M_SE_TX_BACKOFF12_CNT_TX_BACKOFF12_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF13_CNT fields */
#define O_SE_TX_BACKOFF13_CNT_TX_BACKOFF13_CNT 0
#define M_SE_TX_BACKOFF13_CNT_TX_BACKOFF13_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF14_CNT fields */
#define O_SE_TX_BACKOFF14_CNT_TX_BACKOFF14_CNT 0
#define M_SE_TX_BACKOFF14_CNT_TX_BACKOFF14_CNT 0xffffffff

/* Target register R_SE_TX_BACKOFF15_CNT fields */
#define O_SE_TX_BACKOFF15_CNT_TX_BACKOFF15_CNT 0
#define M_SE_TX_BACKOFF15_CNT_TX_BACKOFF15_CNT 0xffffffff

/* Target register R_SE_TX_UNDERRUN_CNT fields */
#define O_SE_TX_UNDERRUN_CNT_TX_UNDERRUN_CNT 0
#define M_SE_TX_UNDERRUN_CNT_TX_UNDERRUN_CNT 0xffffffff

/* Target register R_SE_RX_XGMII_PROT_ERR_CNT fields */
#define O_SE_RX_XGMII_PROT_ERR_CNT_RX_XGMII_PROT_ERR_CNT 0
#define M_SE_RX_XGMII_PROT_ERR_CNT_RX_XGMII_PROT_ERR_CNT 0xffffffff

/* Target register R_SE_RX_IPG_SHRINK_CNT fields */
#define O_SE_RX_IPG_SHRINK_CNT_RX_IPG_SHRINK_CNT 0
#define M_SE_RX_IPG_SHRINK_CNT_RX_IPG_SHRINK_CNT 0xffffffff

/* Target register R_SE_STAT_STICKY fields */
#define O_SE_STAT_STICKY_TX_FRAME_LEN_OVR     0   /* D4 only */
#define M_SE_STAT_STICKY_TX_FRAME_LEN_OVR     0x1 /* D4 only */
#define O_SE_STAT_STICKY_TX_FIFO_OVR          1   /* D4 only */
#define M_SE_STAT_STICKY_TX_FIFO_OVR          0x1 /* D4 only */
#define O_SE_STAT_STICKY_TX_ABORT             2
#define M_SE_STAT_STICKY_TX_ABORT             0x1
#define O_SE_STAT_STICKY_TX_JAM               3   /* D4 only */
#define M_SE_STAT_STICKY_TX_JAM               0x1 /* D4 only */
#define O_SE_STAT_STICKY_TX_RETRANSMIT        4   /* D4 only */
#define M_SE_STAT_STICKY_TX_RETRANSMIT        0x1 /* D4 only */
#define O_SE_STAT_STICKY_RX_TAG               5   /* D10 only */
#define M_SE_STAT_STICKY_RX_TAG               0x1 /* D10 only */
#define O_SE_STAT_STICKY_RX_NON_STD_PREAMBLE  6   /* D10 only */
#define M_SE_STAT_STICKY_RX_NON_STD_PREAMBLE  0x1 /* D10 only */
#define O_SE_STAT_STICKY_RX_PREABMLE_SHRINK   7
#define M_SE_STAT_STICKY_RX_PREABMLE_SHRINK   0x1
#define O_SE_STAT_STICKY_RX_IPG_SHRINK        8
#define M_SE_STAT_STICKY_RX_IPG_SHRINK        0x1
#define O_SE_STAT_STICKY_RX_JUNK              9   /* D4 only */
#define M_SE_STAT_STICKY_RX_JUNK              0x1 /* D4 only */
#define O_SE_STAT_STICKY_RX_CARRIER_EXT_ERR   10  /* D4 only */
#define M_SE_STAT_STICKY_RX_CARRIER_EXT_ERR   0x1 /* D4 only */
#define O_SE_STAT_STICKY_RX_CARRIER_EXT       11  /* D4 only */
#define M_SE_STAT_STICKY_RX_CARRIER_EXT       0x1 /* D4 only */
#define O_SE_STAT_STICKY_RX_MPLS_MC           12  /* D10 only */
#define M_SE_STAT_STICKY_RX_MPLS_MC           0x1 /* D10 only */
#define O_SE_STAT_STICKY_RX_MPLS_UC           13  /* D10 only */
#define M_SE_STAT_STICKY_RX_MPLS_UC           0x1 /* D10 only */
#define O_SE_STAT_STICKY_RX_PREAMBLE_ERR      14  /* D10 only */
#define M_SE_STAT_STICKY_RX_PREAMBLE_ERR      0x1 /* D10 only */
#define O_SE_STAT_STICKY_RX_PREAMBLE_MISMATCH 15  /* D10 only */
#define M_SE_STAT_STICKY_RX_PREAMBLE_MISMATCH 0x1 /* D10 only */

/* Target register R_D4_MAC_MODE_CFG fields */
#define O_D4_MAC_MODE_CFG_TX_ENA         0
#define M_D4_MAC_MODE_CFG_TX_ENA         0x1
#define O_D4_MAC_MODE_CFG_RX_ENA         1
#define M_D4_MAC_MODE_CFG_RX_ENA         0x1
#define O_D4_MAC_MODE_CFG_VLAN_AWARE_ENA 2
#define M_D4_MAC_MODE_CFG_VLAN_AWARE_ENA 0x1
#define O_D4_MAC_MODE_CFG_FDX            3
#define M_D4_MAC_MODE_CFG_FDX            0x1
#define O_D4_MAC_MODE_CFG_GIGA_MODE      4
#define M_D4_MAC_MODE_CFG_GIGA_MODE      0x1
#define O_D4_MAC_MODE_CFG_LEN_DROP       5
#define M_D4_MAC_MODE_CFG_LEN_DROP       0x1
#define O_D4_MAC_MODE_CFG_RMODE_XOR      6
#define M_D4_MAC_MODE_CFG_RMODE_XOR      0x1
#define O_D4_MAC_MODE_CFG_SEED_LOAD      7
#define M_D4_MAC_MODE_CFG_SEED_LOAD      0x1
#define O_D4_MAC_MODE_CFG_SEED           8
#define M_D4_MAC_MODE_CFG_SEED           0xff
#define O_D4_MAC_MODE_CFG_TBI_MODE       16
#define M_D4_MAC_MODE_CFG_TBI_MODE       0x1
#define O_D4_MAC_MODE_CFG_OB_ENA         17
#define M_D4_MAC_MODE_CFG_OB_ENA         0x1
#define O_D4_MAC_MODE_CFG_ASS_DIS        18
#define M_D4_MAC_MODE_CFG_ASS_DIS        0x1

/* Target register R_D4_MAC_PAUSE_CFG fields */
#define O_D4_MAC_PAUSE_CFG_TX_PAUSE_VAL     0
#define M_D4_MAC_PAUSE_CFG_TX_PAUSE_VAL     0xffff
#define O_D4_MAC_PAUSE_CFG_TX_FLOW_CTRL_ENA 16
#define M_D4_MAC_PAUSE_CFG_TX_FLOW_CTRL_ENA 0x1
#define O_D4_MAC_PAUSE_CFG_RX_PAUSE_ENA     17
#define M_D4_MAC_PAUSE_CFG_RX_PAUSE_ENA     0x1
#define O_D4_MAC_PAUSE_CFG_TX_PAUSE_XONOFF  18
#define M_D4_MAC_PAUSE_CFG_TX_PAUSE_XONOFF  0x1

/* Target register R_D4_MAC_MAXLEN_CFG fields */
#define O_D4_MAC_MAXLEN_CFG_MAX_LEN 0
#define M_D4_MAC_MAXLEN_CFG_MAX_LEN 0xffff

/* Target register R_D4_MAC_MAC_ADDR_HIGH_CFG fields */
#define O_D4_MAC_MAC_ADDR_HIGH_CFG_MAC_ADDR_HIGH 0
#define M_D4_MAC_MAC_ADDR_HIGH_CFG_MAC_ADDR_HIGH 0xffffff

/* Target register R_D4_MAC_MAC_ADDR_LOW_CFG fields */
#define O_D4_MAC_MAC_ADDR_LOW_CFG_MAC_ADDR_LOW 0
#define M_D4_MAC_MAC_ADDR_LOW_CFG_MAC_ADDR_LOW 0xffffff

/* Target register R_D4_MAC_IFG_CFG fields */
#define O_D4_MAC_IFG_CFG_RX_IFG1 0
#define M_D4_MAC_IFG_CFG_RX_IFG1 0xf
#define O_D4_MAC_IFG_CFG_RX_IFG2 4
#define M_D4_MAC_IFG_CFG_RX_IFG2 0xf
#define O_D4_MAC_IFG_CFG_TX_IFG  8
#define M_D4_MAC_IFG_CFG_TX_IFG  0x1f

/* Target register R_D4_MAC_TBI_CFG fields */
#define O_D4_MAC_TBI_CFG_DAR          0
#define M_D4_MAC_TBI_CFG_DAR          0xffff
#define O_D4_MAC_TBI_CFG_AN_RESTART   16
#define M_D4_MAC_TBI_CFG_AN_RESTART   0x1
#define O_D4_MAC_TBI_CFG_AN_ENA       17
#define M_D4_MAC_TBI_CFG_AN_ENA       0x1
#define O_D4_MAC_TBI_CFG_TBI_LOOPBACK 18
#define M_D4_MAC_TBI_CFG_TBI_LOOPBACK 0x1
#define O_D4_MAC_TBI_CFG_UDLT         19
#define M_D4_MAC_TBI_CFG_UDLT         0x1
#define O_D4_MAC_TBI_CFG_JTP_SEL      20
#define M_D4_MAC_TBI_CFG_JTP_SEL      0x3
#define O_D4_MAC_TBI_CFG_SD_ENA       22
#define M_D4_MAC_TBI_CFG_SD_ENA       0x1
#define O_D4_MAC_TBI_CFG_SD_POL       23
#define M_D4_MAC_TBI_CFG_SD_POL       0x1
#define O_D4_MAC_TBI_CFG_SW_RESOLVE   24
#define M_D4_MAC_TBI_CFG_SW_RESOLVE   0x1

/* Target register R_D4_MAC_LATE_COL_POS_CFG fields */
#define O_D4_MAC_LATE_COL_POS_CFG_LATE_COL_POS 0
#define M_D4_MAC_LATE_COL_POS_CFG_LATE_COL_POS 0x7f

/* Target register R_D4_MAC_RESET_CTRL fields */
#define O_D4_MAC_RESET_CTRL_RX_RESET     0
#define M_D4_MAC_RESET_CTRL_RX_RESET     0x1
#define O_D4_MAC_RESET_CTRL_TX_RESET     1
#define M_D4_MAC_RESET_CTRL_TX_RESET     0x1
#define O_D4_MAC_RESET_CTRL_TX_CLOCK_SEL 3
#define M_D4_MAC_RESET_CTRL_TX_CLOCK_SEL 0x7

/* Target register R_D4_MAC_TBI_STATUS fields */
#define O_D4_MAC_TBI_STATUS_LPA           0
#define M_D4_MAC_TBI_STATUS_LPA           0xffff
#define O_D4_MAC_TBI_STATUS_ANC           16
#define M_D4_MAC_TBI_STATUS_ANC           0x1
#define O_D4_MAC_TBI_STATUS_PR            17
#define M_D4_MAC_TBI_STATUS_PR            0x1
#define O_D4_MAC_TBI_STATUS_XMIT_MODE     18
#define M_D4_MAC_TBI_STATUS_XMIT_MODE     0x3
#define O_D4_MAC_TBI_STATUS_LINK_STATUS   20
#define M_D4_MAC_TBI_STATUS_LINK_STATUS   0x1
#define O_D4_MAC_TBI_STATUS_JTP_ERR       21
#define M_D4_MAC_TBI_STATUS_JTP_ERR       0x1
#define O_D4_MAC_TBI_STATUS_JTP_LOCK      22
#define M_D4_MAC_TBI_STATUS_JTP_LOCK      0x1
#define O_D4_MAC_TBI_STATUS_SIGNAL_DETECT 23
#define M_D4_MAC_TBI_STATUS_SIGNAL_DETECT 0x1
#define O_D4_MAC_TBI_STATUS_LINK_DOWN_CNT 24
#define M_D4_MAC_TBI_STATUS_LINK_DOWN_CNT 0xff

/* Target register R_D4_MAC_TBI_STATUS_DBG fields */
#define O_D4_MAC_TBI_STATUS_DBG_TBI_DBG 0
#define M_D4_MAC_TBI_STATUS_DBG_TBI_DBG 0xffffffff

/* Target register R_D4_MAC_DROP_CNT fields */
#define O_D4_MAC_DROP_CNT_DROP_CNT 0
#define M_D4_MAC_DROP_CNT_DROP_CNT 0xffffffff

/* Target register R_D4_MAC_DBG_CFG fields */
#define O_D4_MAC_DBG_CFG_HOST_LOOPBACK       0
#define M_D4_MAC_DBG_CFG_HOST_LOOPBACK       0x1
#define O_D4_MAC_DBG_CFG_PHY_LOOPBACK        1
#define M_D4_MAC_DBG_CFG_PHY_LOOPBACK        0x1
#define O_D4_MAC_DBG_CFG_INV_RX_CLOCK        2
#define M_D4_MAC_DBG_CFG_INV_RX_CLOCK        0x1
#define O_D4_MAC_DBG_CFG_INV_GTX_CLOCK       3
#define M_D4_MAC_DBG_CFG_INV_GTX_CLOCK       0x1
#define O_D4_MAC_DBG_CFG_IFG_CRS_EXT_CHK_ENA 4
#define M_D4_MAC_DBG_CFG_IFG_CRS_EXT_CHK_ENA 0x1

/* Target register R_D4_MAC_STICKY fields */
#define O_D4_MAC_STICKY_RX_RESYNC_FIFO_OVF 0
#define M_D4_MAC_STICKY_RX_RESYNC_FIFO_OVF 0x1
#define O_D4_MAC_STICKY_TX_SOF_ERR         1
#define M_D4_MAC_STICKY_TX_SOF_ERR         0x1
#define O_D4_MAC_STICKY_TX_EOF_ERR         2
#define M_D4_MAC_STICKY_TX_EOF_ERR         0x1
#define O_D4_MAC_STICKY_TX_UNF_ERR         3
#define M_D4_MAC_STICKY_TX_UNF_ERR         0x1
#define O_D4_MAC_STICKY_TX_OVF_ERR         4
#define M_D4_MAC_STICKY_TX_OVF_ERR         0x1

/* Target register R_D4_MAC_PB_PORT_CFG fields */
#define O_D4_MAC_PB_PORT_CFG_PB_ENA 0   /* Gatwick-Ie only */
#define M_D4_MAC_PB_PORT_CFG_PB_ENA 0x1 /* Gatwick-Ie only */

/* Target register R_D4_MAC_PB_MODE_CFG fields */
#define O_D4_MAC_PB_MODE_CFG_PB_TAG_VAL 0      /* Gatwick-Ie only */
#define M_D4_MAC_PB_MODE_CFG_PB_TAG_VAL 0xffff /* Gatwick-Ie only */
