/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_basic_trace.c,v 1.5 2007/05/15 12:52:36 cpj Exp $
 $Revision: 1.5 $

*/

#define VTSS_TRACE_LAYER 3
#define VTSS_TRACE_FILE "hl"

/* Standard headers */
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "vtss_basic_trace.h"

#if defined(SWITCH_APP_TRACE) || defined(VTSS_BASIC_TRACE_USE_ADVANCED)
const char *vtss_trace_func;
int vtss_trace_line;
int vtss_trace_module;
int vtss_trace_level;
#endif /* SWITCH_APP_TRACE/VTSS_BASIC_TRACE_USE_ADVANCED */

#if defined(VTSS_BASIC_TRACE_USE_ADVANCED)
#include <vtss_trace_lvl_api.h>
#include <vtss_trace_api.h>

#if (VTSS_TRACE_ENABLED)
vtss_trace_reg_t vtss_trace_reg_api[3] =
{
    [0] = {
        .module_id = VTSS_MODULE_ID_API_IO,
        .name      = "api_io",
        .descr     = "API I/O Layer",
    },
    [1] = {
        .module_id = VTSS_MODULE_ID_API_CI,
        .name      = "api_ci",
        .descr     = "API Chip Interface Layer",
    },
    [2] = {
        .module_id = VTSS_MODULE_ID_API_AI,
        .name      = "api_ai",
        .descr     = "API Application Interface Layer",
    }
};
    
vtss_trace_grp_t vtss_trace_grps_api[3][1] =
{
    [0] = {
        [VTSS_TRACE_GRP_DEFAULT] = { 
            .name      = "default",
            .descr     = "Default",
            .lvl       = VTSS_TRACE_LVL_ERROR,
            .timestamp = 0,
        },
    },
    [1] = {
        [VTSS_TRACE_GRP_DEFAULT] = { 
            .name      = "default",
            .descr     = "Default",
            .lvl       = VTSS_TRACE_LVL_ERROR,
            .timestamp = 0,
        },
    },
    [2] = {
        [VTSS_TRACE_GRP_DEFAULT] = { 
            .name      = "default",
            .descr     = "Default",
            .lvl       = VTSS_TRACE_LVL_ERROR,
            .timestamp = 0,
        },
    },
};
#endif /* VTSS_TRACE_ENABLED */
#endif /* VTSS_BASIC_TRACE_USE_ADVANCED */


#if defined(SWITCH_APP_TRACE) || defined(VTSS_BASIC_TRACE_USE_ADVANCED)
void vtss_basic_trace(const char *fmt, ...)
{
    char    msg[200];
    va_list arg;

    va_start(arg,fmt);
    vsprintf(msg,fmt,arg);
#if defined(VTSS_BASIC_TRACE_USE_ADVANCED)
    T_EXPLICIT_NO_VA(vtss_trace_module, VTSS_TRACE_GRP_DEFAULT, vtss_trace_level, vtss_trace_func, vtss_trace_line, msg);
#else
    trace(vtss_trace_module,vtss_trace_func,NULL,vtss_trace_line,0,VTSS_OK,vtss_trace_level,msg);
#endif
}
#endif /* SWITCH_APP_TRACE/VTSS_BASIC_TRACE_USE_ADVANCED */


#if defined(VTSS_BASIC_TRACE_USE_ADVANCED)
void vtss_basic_trace_register(void)
{
#if (VTSS_TRACE_ENABLED)    
    static int done = 0;

    /* Initialize trace ressources */
    int i;
    if (!done) {
        done = 1;
        for (i = 0; i < 3; i++) {
            VTSS_TRACE_REG_INIT(&vtss_trace_reg_api[i], vtss_trace_grps_api[i], 1);
            VTSS_TRACE_REGISTER(&vtss_trace_reg_api[i]);
        }
    }
#endif /* VTSS_TRACE_ENABLED */    
} /* vtss_basic_trace_init */
#endif /* VTSS_BASIC_TRACE_USE_ADVANCED */    


/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
