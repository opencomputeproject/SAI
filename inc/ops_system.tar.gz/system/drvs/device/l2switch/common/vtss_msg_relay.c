/*

 Vitesse Switch Software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_msg_relay.c,v 1.5 2007/09/05 13:47:57 cpj Exp $
 $Revision: 1.5 $

*/

#include "vtss_switch_api.h"

/* Only include this C-file if VTSS_OPT_MSG_RELAY is non-zero */
#if VTSS_OPT_MSG_RELAY

#include "vtss_msg_relay_api.h"

#define HTL_OFFSET 21

/****************************************************************************/
/****************************************************************************/
static vtss_msg_relay_init_t msg_relay_setup;

/* The VStaX2 Header is the same for all frames, so we can as well define it and fill it in once and for all. */
static vtss_vstax_tx_header_t vs2_hdr;

/****************************************************************************
 * vtss_msg_relay_init()
 ****************************************************************************/
vtss_rc vtss_msg_relay_init(vtss_msg_relay_init_t *setup)
{
    memcpy(&msg_relay_setup, setup, sizeof(msg_relay_setup));

    /* Since the VStaX2 header is invariant in the message protocol, initialize
       it once and for all. */
    vs2_hdr.fwd_mode    = VTSS_VSTAX_FWD_MODE_CPU_ALL; /* Frame goes to the CPU... */
    vs2_hdr.ttl         = 1; /* ...on the neighboring switch... */
    vs2_hdr.prio        = VTSS_PRIO_SUPER; /* using this switch's super priority Tx queue and the neighboring switch SP Rx queue. */
    vs2_hdr.uid         = 1; /* Hmm! */
    vs2_hdr.tci.vid     = 1; /* Hmm! */
    vs2_hdr.tci.cfi     = 0; /* Hmm! */
    vs2_hdr.tci.tagprio = 0; /* Hmm! */
    vs2_hdr.glag_no     = 0; /* Hmm! */
    vs2_hdr.port_no     = 1; /* Not used when fwd_mode is VTSS_VSTAX_FWD_MODE_CPU_ALL, but most be a valid logical port number to avoid assertion failure. */
    vs2_hdr.queue_no    = msg_relay_setup.cpu_qu;
    return VTSS_OK;
}

/****************************************************************************
 * vtss_msg_relay_rx_pkt()
 * Decrements the frames Hops-To-Live (HTL) field, and if then non-zero,
 * forwards the frame on the opposite stack port. Otherwise discards it.
 ****************************************************************************/
vtss_rc vtss_msg_relay_rx_pkt(vtss_port_no_t port_no, uchar *frm, uint len)
{
    if(port_no != msg_relay_setup.stack_port_a && port_no != msg_relay_setup.stack_port_b)
        return VTSS_UNSPECIFIED_ERROR;

    if(--frm[HTL_OFFSET] == 0)
      return VTSS_OK; /* Don't relay when HTL reaches zero. It's not a particular error. */
   
    return vtss_tx_vstax_frame(port_no == msg_relay_setup.stack_port_a ? msg_relay_setup.stack_port_b : msg_relay_setup.stack_port_a, &vs2_hdr, frm, len);
}

#endif /* VTSS_OPT_MSG_RELAY */

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
