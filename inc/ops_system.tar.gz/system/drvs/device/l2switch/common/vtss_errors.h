/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2004 Vitesse Semiconductor Corporation. All Rights Reserved.
 Unpublished rights reserved under the copyright laws of the United States of 
 America, other countries and international treaties. The software is provided
 without fee. Permission to use, copy, store, modify, disclose, transmit or 
 distribute the software is granted, provided that this copyright notice must 
 appear in any copy, modification, disclosure, transmission or distribution of 
 the software. Vitesse Semiconductor Corporation retains all ownership, 
 copyright, trade secret and proprietary rights in the software. THIS SOFTWARE
 HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY INCLUDING, 
 WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_errors.h,v 1.7 2006/09/18 08:17:06 cpj Exp $
 $Revision: 1.7 $

*/

#ifndef _VTSS_ERRORS_H_
#define _VTSS_ERRORS_H_

/* ================================================================= *
 *  Return Codes
 * ================================================================= */

/* - Return Code type ---------------------------------------------- */

typedef int vtss_rc;

/* - Return Code values -------------------------------------------- */

#define VTSS_OK                  0     /* rc>=0 means OK */

/* General warnings */
#define VTSS_WARNING            -0x01  /* Error, but fixed by API. */
#define VTSS_INCOMPLETE         -0x02  /* Operation incomplete */

/* General errors */
#define VTSS_UNSPECIFIED_ERROR  -0x03
#define VTSS_NOT_IMPLEMENTED    -0x04
#define VTSS_INVALID_PARAMETER  -0x05
#define VTSS_DATA_NOT_READY     -0x06
#define VTSS_ENTRY_NOT_FOUND    -0x07
#define VTSS_TIMEOUT_RETRYLATER -0x08  /* Timeout, retry later. */
#define VTSS_FATAL_ERROR        -0x09  /* Fatal error. Chip reset required. */

/* PHY errors */
#define VTSS_PHY_NOT_MAPPED     -0x10
#define VTSS_PHY_READ_ERROR     -0x11  /* No PHY read reply. */
#define VTSS_PHY_TIMEOUT        -0x12  /* The PHY did not react within spec'ed time */

/* Port errors */
#define VTSS_TBI_DISABLED       -0x20

/* Packet errors */
#define VTSS_PACKET_BUF_SMALL    -0x30 
#define VTSS_PACKET_PROTOCOL_ERROR -0x31
 
/* Layer 2 errors */
#define VTSS_AGGR_INVALID       -0x40

/* I/O errors for Vitesse implementation */
#define VTSS_IO_READ_ERROR      -0x60  /* I/O Layer read error */
#define VTSS_IO_WRITE_ERROR     -0x61  /* I/O Layer write error */
#define VTSS_IO_DMA             -0x62  /* I/O Layer DMA error */

#define VTSS_IO_NIC_READ_ERROR  -0x63  /* I/O NIC Layer read error */
#define VTSS_IO_NIC_WRITE_ERROR -0x64  /* I/O NIC Layer write error */
#define VTSS_IO_NIC_ERROR       -0x65  /* I/O NIC Layer error */

/* Customer specific errors, use range: -0x1000 to -0x1FFF */


#endif /* _VTSS_ERRORS_H_ */

