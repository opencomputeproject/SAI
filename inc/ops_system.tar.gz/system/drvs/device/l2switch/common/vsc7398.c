#include "vtss_switch_api.h"
#include "vtss_state.h"
#include "vtss_phy_veriphy.h"
#include "l2-switch-g5.h"
#include "vtss_errors.h"
#include "vtss_types.h"
#include "vtss_switch_api.h"
#include "vtss_os.h"
#include "vtss_phy.h"

uint vtss7398_learn_mode_set(vtss_learn_mode_t* vtss_learn_mode)
{
    return vtss_learn_mode_set(vtss_learn_mode);
}
void vtss7398_enable_port(uint8_t port)
{
    vtss_enable_port(port);
}

void vtss7398_disable_port(uint8_t port)
{
    vtss_disable_port(port);
}

void vtss7398_port_get_stats(uint8_t port, port_stats_t *stats)
{
    vtss_port_get_stats(port, stats);
}

int vtss7398_en_phy_loopback(uint8_t port)
{
    return vtss_en_phy_loopback(port);
}

int vtss7398_en_phy_far_end_loopback(uint8_t port)
{
    return vtss_en_phy_far_end_loopback(port);
}

int vtss7398_dis_phy_loopback(uint8_t port)
{
    return vtss_dis_phy_loopback(port);
}

int vtss7398_dis_phy_far_end_loopback(uint8_t port)
{
    return vtss_dis_phy_far_end_loopback(port);
}

vtss_rc vtss7398_phy_read(const vtss_port_no_t port_no,const uint reg, ushort *const value)
{
    return vtss_phy_read(port_no, reg, value);
}

vtss_rc vtss7398_phy_write(const vtss_port_no_t port_no, const uint reg, const ushort value)
{
    return  vtss_phy_write(port_no, reg, value);
}

vtss_rc vtss7398_register_read(const ulong reg, ulong *value)
{
    return vtss_register_read(reg, value);
}

vtss_rc vtss7398_register_write(const ulong reg, ulong value)
{
    return vtss_register_write(reg, value);
}

vtss_rc vtss7398_select_chip(vtss_state_t * const state)
{
    return vtss_select_chip(state);
}

vtss_rc vtss7398_vlan_port_members_set(const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    return vtss_vlan_port_members_set(vid, member);
}

vtss_rc vtss7398_vlan_port_mode_set(const vtss_port_no_t port_no, const vtss_vlan_port_mode_t * const vlan_mode)
{
    return vtss_vlan_port_mode_set(port_no, vlan_mode);
}

vtss_rc vtss7398_poag_counters_clear(const vtss_poag_no_t poag_no)
{
    return vtss_poag_counters_clear(poag_no);
}

extern vtss_rc ht_wr_xx(uint blk, uint sub, uint neg, ulong value);
extern vtss_rc ht_rd_xx(uint blk, uint sub, uint reg, ulong *value);
vtss_rc ht7398_wr_xx(uint blk, uint sub, uint reg, ulong value)
{
    return ht_wr_xx(blk, sub, reg, value);
}
vtss_rc ht7398_rd_xx(uint blk, uint sub, uint reg, ulong *value)
{
    return ht_rd_xx(blk, sub, reg, value);
}

vtss_rc vtss7398_init(const vtss_init_setup_t * const setup)
{
    return vtss_init(setup);
}

vtss_rc vtss7398_port_map_set(const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE])
{
    return vtss_port_map_set(mapped_ports);
}


vtss_rc vtss7398_phy_reset(const vtss_port_no_t port_no, const vtss_phy_reset_setup_t * const setup)
{
    return vtss_phy_reset(port_no, setup);
}

vtss_rc vtss7398_phy_setup(const vtss_port_no_t port_no, const vtss_phy_setup_t * const setup)
{
    return vtss_phy_setup(port_no, setup);
}

vtss_rc vtss7398_port_stp_state_set(const vtss_port_no_t port_no, const vtss_stp_state_t stp_state)
{
    return vtss_port_stp_state_set(port_no, stp_state);
}

vtss_rc vtss7398_port_setup(const vtss_port_no_t port_no, const vtss_port_setup_t * const setup)
{
    return vtss_port_setup(port_no, setup);
}

vtss_rc vtss7398_port_enable(const vtss_port_no_t port_no, const BOOL enable)
{
    return vtss_port_enable(port_no, enable);
}

vtss_rc vtss7398_mac_table_learn(const vtss_mac_table_entry_t * const entry)
{
    return vtss_mac_table_learn(entry);
}

uint vtss7398_sizeof_al(void) 
{
   return vtss_sizeof_al();
}

uint vtss7398_phy_sizeof_al( const uint ports )
{
   return vtss_phy_sizeof_al(ports);
}

vtss_rc vtss7398_chipid_get(vtss_chipid_t * const chipid)
{
    return vtss_chipid_get(chipid);
}

vtss_rc vtss7398_port_status_get(const vtss_port_no_t port_no, vtss_port_status_t * const status)
{
    return vtss_port_status_get(port_no, status);
}

vtss_rc vtss7398_vlan_port_mode_get(const vtss_port_no_t port_no, vtss_vlan_port_mode_t * const vlan_mode)
{
    return vtss_vlan_port_mode_get(port_no, vlan_mode);
}

vtss_rc vtss7398_poag_counters_get(const vtss_poag_no_t poag_no, vtss_poag_counters_t *const big_counters)
{
    return vtss_poag_counters_get(poag_no, big_counters);
}

