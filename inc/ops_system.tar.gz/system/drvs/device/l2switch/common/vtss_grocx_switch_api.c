/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.

*/

#include <net/if.h>
#include <sys/ioctl.h>

#include <string.h>
#include <stdio.h>

#include "vtss_grocx_switch_api.h"

/* - Star switch specific ------------------------------------------ */
/* device name to do ioctl */
static char vtss_ioctl_dev[] = "eth0";

/* socket file descriptor to do ioctl */
static int vtss_grx_ioctl_fd;

vtss_rc vtss_grocx_router_packet_counter_clear(vtss_grx_port_counter_t * ctl)
{
	struct ifreq ifr;
	int err;
	
	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, vtss_ioctl_dev);
	
	ifr.ifr_data = (caddr_t)ctl;
	err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
	if (err < 0) {
		perror("ioctl failed\n");
		return VTSS_FATAL_ERROR;
	}
	return VTSS_OK;
}

vtss_rc vtss_grocx_router_packet_counter_get(vtss_grx_port_counter_t * ctl)
{
    struct ifreq ifr;
    int err;

    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);

    ifr.ifr_data = (caddr_t)ctl;
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("octl failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_grocx_router_vlan_control(vtss_grx_vlan_ctl_t *vlan_ctl)
{
    struct ifreq ifr;
    int err;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    
    ifr.ifr_data = (caddr_t)vlan_ctl;
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("octl failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_grocx_router_arl_table_control(vtss_grx_arl_table_t *arl_table)
{
    struct ifreq ifr;
    int err;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    ifr.ifr_data = (caddr_t)arl_table;
    
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("vtss_arl_table_control failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_grocx_router_mac1_control(vtss_grx_mac1_control_t * mac1_control)
{
    struct ifreq ifr;
    int err;
    
    //printf("[use mode]: vtss_mac1_control\n");
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    
    ifr.ifr_data = (caddr_t)mac1_control;
    
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("ioctl failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_grocx_router_qos_control(vtss_grx_qos_ctl_t * qos_ctl)
{
    struct ifreq ifr;
    int err;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    ifr.ifr_data = (caddr_t)qos_ctl;
    
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("vtss_qos_control failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_grocx_router_egress_rate_limit_control(vtss_grx_egress_rate_limit_ctl_t *egress_rate_limit_ctl)
{
    struct ifreq ifr;
    int err;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    ifr.ifr_data = (caddr_t)egress_rate_limit_ctl;
    
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("vtss_grx_egress_rate_limit_control failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

vtss_rc vtss_grocx_router_storm_control(vtss_grx_storm_ctl_t * storm_ctl)
{
    struct ifreq ifr;
    int err;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    ifr.ifr_data = (caddr_t)storm_ctl;
    
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("vtss_grx_storm_control failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

/*  Enable/Disable unknown VLAN trap to CPU port */
vtss_rc vtss_grocx_router_vlan_trap(const BOOL enable)
{
    struct ifreq ifr;
    vtss_grx_vlan_trap_ctl_t trap_ctl;
    int err;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    
    trap_ctl.cmd = VTSS_GRX_IOCTL_VLAN_TRAP;
    //trap_ctl.port = port;
    trap_ctl.enable = enable;
    
    ifr.ifr_data = (caddr_t)&trap_ctl;
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("vtss_grx_vlan_trap failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

/* - wrapper for vtss_grocx_* ------------------------------------------ */

/* create a socket for ioctl */
vtss_rc vtss_grocx_router_ioctl_init(void)
{
    vtss_grx_ioctl_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (vtss_grx_ioctl_fd < 0) {
        perror("socket failed\n");
        return VTSS_FATAL_ERROR;
    }
    
    return VTSS_OK;
}

#if 0
static vtss_rc vtss_grocx_router_ioctl_close(void)
{
    fclose(vtss_grx_ioctl_fd);
    
    return VTSS_OK;
}
#endif

static vtss_rc vtss_grocx_router_init(void)
{
    struct ifreq ifr;
    int err;
    vtss_grx_mac1_control_t mac1_control;
    
    vtss_grocx_router_ioctl_init();
    
    mac1_control.cmd = VTSS_GRX_INIT;
    
    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, vtss_ioctl_dev);
    
    ifr.ifr_data = (caddr_t)&mac1_control;
    
    printf("vtss_gsw_init\n");
    err = ioctl(vtss_grx_ioctl_fd, SIOCDEVPRIVATE, &ifr);
    if (err < 0) {
        perror("ioctl failed\n");
        return VTSS_FATAL_ERROR;
    }
    return VTSS_OK;
}

#if 0
static vtss_rc vtss_grocx_router_port_setup(const vtss_grocx_port_conf_t * const setup)
{
    vtss_grx_mac1_control_t ctl;
    
    ctl.an = setup->autoneg;
    switch (setup->speed)
    {
        case VTSS_SPEED_10M:
    	{
            ctl.force_speed = FORCE_10;
            ctl.giga_mode = MODE_10_100;
    	    break;
    	}
    	case VTSS_SPEED_100M:
    	{
            ctl.force_speed = FORCE_100;
            ctl.giga_mode = MODE_10_100;
    	    break;
    	}
    	case VTSS_SPEED_1G:
    	{
            ctl.force_speed = FORCE_1000;
            ctl.giga_mode = MODE_10_100_1000;
    	    break;
    	}
    	default:
    	    break;
    }
    
    ctl.force_fc_tx = setup->flow_control;
    ctl.force_fc_rx = setup->flow_control;
    
    
    ctl.cmd = VTSS_GRX_IOCTL_MAC1_CONTROL;
    
    if (setup->fdx==1) {
        ctl.force_duplex = FULL_DUPLEX;
    } else {
        ctl.force_duplex = HALF_DUPLEX;
    }
    
    vtss_grocx_router_mac1_control(&ctl);
    return VTSS_OK;
}
#endif


static vtss_rc vtss_grocx_router_vlan_port_members_set( const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_grx_vlan_ctl_t ctl;
    uint lan = 0;
    vtss_port_no_t         port_no;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if(port_no != VTSS_OPT_ROUTER_PORT_WAN)
            lan |= member[port_no];
    }
    
    if(lan) {
        ctl.cmd = VTSS_GRX_IOCTL_MODIFY_VLAN;
        ctl.vlan_port_map = VTSS_GRX_MAC0_PMAP | VTSS_GRX_CPU_PMAP;
        ctl.vlan_tag_port_map = VTSS_GRX_MAC0_PMAP | VTSS_GRX_CPU_PMAP;
        //ctl.gid
        ctl.vid = vid;
    
        vtss_grocx_router_vlan_control(&ctl);
    }
    
    return VTSS_OK;
}

#if 0
static vtss_rc vtss_grocx_router_vlan_port_members_get( const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_grx_vlan_ctl_t ctl;
    ctl.cmd = VTSS_GRX_IOCTL_GET_VLAN;

    ctl.vid = vid;
    vtss_grocx_router_vlan_control(&ctl);
    member[0] = ctl.vlan_port_map;
    return VTSS_OK;
}
#endif

#if 0
static vtss_rc vtss_grocx_router_poag_counters_get(vtss_poag_counters_t * const counters)
{
    vtss_grx_port_counter_t ctl;

    ctl.cmd = VTSS_GRX_IOCTL_COUNTER_GET;
    ctl.port = VTSS_GRX_PORT_MAC1;
    vtss_grocx_router_packet_counter_get(&ctl);
    // count all drop packet
    counters->rmon.rx_etherStatsDropEvents = ctl.rx_no_buffer_drop_pkt + ctl.rx_arl_drop_pkt + ctl.rx_vlan_ingress_drop_pkt;
    counters->rmon.rx_etherStatsOctets = ctl.rx_ok_byte;
    counters->rmon.rx_etherStatsPkts = ctl.rx_ok_pkt + ctl.rx_runt_pkt + ctl.rx_over_size_pkt + ctl.rx_crc_err_pkt + ctl.rx_csum_err_pkt; // + ctl.rx_pause_frame_pkt; need the pause frame
    counters->rmon.rx_etherStatsCRCAlignErrors = ctl.rx_crc_err_pkt;
    counters->rmon.rx_etherStatsFragments = ctl.rx_runt_pkt;
    //counters->rmon.tx_etherStatsDropEvents =
    counters->rmon.tx_etherStatsOctets = ctl.tx_ok_byte;
    counters->rmon.tx_etherStatsPkts = ctl.tx_ok_pkt;
    
    return VTSS_OK;
}
#endif

#if 0
static vtss_rc vtss_grocx_router_poag_counters_clear(void)
{
	vtss_grx_port_counter_t ctl;

	ctl.cmd = VTSS_GRX_IOCTL_COUNTER_CLEAR;
	ctl.port = VTSS_GRX_PORT_MAC1;
	vtss_grocx_router_packet_counter_clear(&ctl);

	return VTSS_OK;
}
#endif

/* - vitesse grocx API ------------------------------------------ */
vtss_rc vtss_grocx_init(void)
{
#if !defined(VTSS_OPT_ROUTER_PORT_WAN) /* config C or config D*/
    return vtss_grocx_router_init();
#else /* config A or config B */
    return vtss_grocx_router_init();
#endif
}

vtss_rc vtss_grocx_port_setup(const vtss_port_no_t            port_no,
                        const vtss_grocx_port_conf_t * const setup)
{
    vtss_port_setup_t port_setup, *ps;
    
#if !defined(VTSS_OPT_ROUTER_PORT_WAN) /* config C or config D */
    if(port_no == 1)
        return vtss_grocx_router_port_setup(setup);
#else /* config A or config B */

#endif

    ps = &port_setup;
    memset(ps, 0, sizeof(*ps));
    ps->interface_mode.interface_type = VTSS_PORT_INTERFACE_INTERNAL;
    ps->powerdown = (setup->enable ? 0 : 1);
    ps->maxframelength = setup->maxframelength;
    ps->frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
    ps->frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
    ps->frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
    ps->interface_mode.speed = setup->speed;
    ps->fdx = setup->fdx;
    ps->flowcontrol.obey = setup->flow_control;
    ps->flowcontrol.generate = setup->flow_control; 

    return vtss_port_setup(port_no, ps);
}

vtss_rc vtss_grocx_poag_counters_clear(const vtss_poag_no_t poag_no)
{
#if !defined(VTSS_OPT_ROUTER_PORT_WAN) /* config C or config D */
    return ((port_no == 1) ? vtss_grocx_router_poag_counters_clear() : vtss_poag_counters_clear(poag_no));
#else /* config A or config B */
    return vtss_poag_counters_clear(poag_no);
#endif
}

vtss_rc vtss_grocx_poag_counters_get(const vtss_poag_no_t         poag_no,
                               vtss_poag_counters_t * const counters)
{
#if !defined(VTSS_OPT_ROUTER_PORT_WAN) /* config C or config D */
    return ((port_no == 1) ? vtss_grocx_router_poag_counters_get(counters) : vtss_poag_counters_get(poag_no, counters));
#else /* config A or config B */
    vtss_poag_counters_get(poag_no, counters);
#endif
    return VTSS_OK;
}

vtss_rc vtss_grocx_vlan_port_members_get(
    const vtss_vid_t vid,
    BOOL             member[VTSS_PORT_ARRAY_SIZE])
{
    //vtss_grocx_router_vlan_port_members_get(vid, member);
    vtss_vlan_port_members_get(vid, member);
    return VTSS_OK;
}

vtss_rc vtss_grocx_vlan_port_members_set(
    const vtss_vid_t vid,
    BOOL             member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_grocx_router_vlan_port_members_set(vid, member);
    vtss_vlan_port_members_set(vid, member);
    return VTSS_OK;
}
