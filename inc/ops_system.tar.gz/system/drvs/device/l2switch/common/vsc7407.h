#ifndef _VSC7407_H
#define _VSC7407_H

vtss_rc vtss7407_register_read(const ulong reg, ulong *value);
vtss_rc vtss7407_register_write(const ulong reg, ulong value);
vtss_rc vtss7407_select_chip(vtss_state_t * const state);
vtss_rc vtss7407_vlan_port_members_set(const vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE]);
vtss_rc vtss7407_vlan_port_mode_set(const vtss_port_no_t port_no, const vtss_vlan_port_mode_t * const vlan_mode);
vtss_rc vtss7407_poag_counters_clear(const vtss_poag_no_t poag_no);
vtss_rc vtss7407_init(const vtss_init_setup_t * const setup);
vtss_rc vtss7407_port_map_set(const vtss_mapped_port_t mapped_ports[VTSS_PORT_ARRAY_SIZE]);
vtss_rc vtss7407_phy_reset(const vtss_port_no_t port_no, const vtss_phy_reset_setup_t * const setup);
vtss_rc vtss7407_phy_setup(const vtss_port_no_t port_no, const vtss_phy_setup_t * const setup);
vtss_rc vtss7407_port_stp_state_set(const vtss_port_no_t port_no, const vtss_stp_state_t stp_state);
vtss_rc vtss7407_port_setup(const vtss_port_no_t port_no, const vtss_port_setup_t * const setup);
vtss_rc vtss7407_learn_port_mode_set(const vtss_port_no_t port_no, vtss_learn_mode_t * const learn_mode);
vtss_rc vtss7407_mac_table_learn(const vtss_mac_table_entry_t * const entry);
uint vtss7407_sizeof_al(void);
uint vtss7407_phy_sizeof_al(const uint ports);
vtss_rc vtss7407_chipid_get(vtss_chipid_t * const chipid);
vtss_rc vtss7407_port_status_get(const vtss_port_no_t port_no, vtss_port_status_t * const status);
vtss_rc vtss7407_vlan_port_mode_get(const vtss_port_no_t port_no, vtss_vlan_port_mode_t * const vlan_mode);
vtss_rc vtss7407_poag_counters_get(const vtss_poag_no_t poag_no, vtss_poag_counters_t *const big_counters);
vtss_rc ht7407_wr_xx(uint blk, uint sub, uint reg, ulong value);
vtss_rc ht7407_rd_xx(uint blk, uint sub, uint reg, ulong *value);

#endif
