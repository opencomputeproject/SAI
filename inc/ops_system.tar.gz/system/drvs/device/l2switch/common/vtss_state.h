/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_state.h,v 1.91 2007/10/10 09:07:04 cpj Exp $
 $Revision: 1.91 $

*/

#ifndef _VTSS_STATE_H_
#define _VTSS_STATE_H_

/* Number of ports on chip */
#if defined(VTSS_ARCH_GATWICK)
#define VTSS_CHIP_PORTS 32
#endif /* VTSS_ARCH_GATWICK */

#if defined(VTSS_ARCH_HEATHROW)

#if defined(HEATHROW3)
#define VTSS_CHIP_PORTS 24
#define VTSS_CHIP_PORTMASK ((1<<VTSS_PORTS)-1)<<4
#endif /* HEATHROW3 */

#if defined(SPARX_G5)
#define VTSS_CHIP_PORTS    7
#define VTSS_CHIP_PORTMASK 0x5f /* Chip port 0-4 and 6 */
#endif /* SPARX_G5 */

#if defined(VTSS_ARCH_SPARX_28)
#if defined(G_ROCX)
#define VTSS_CHIP_PORTS    VTSS_PORT_COUNT
#else
#define VTSS_CHIP_PORTS    28
#endif /* G_ROCX */
#define VTSS_CHIP_PORT_CPU VTSS_CHIP_PORTS
#define VTSS_CHIP_PORTMASK ((1<<VTSS_CHIP_PORTS)-1)
#endif /* VTSS_ARCH_SPARX_28 */

#if defined(ELSTREE)
#define VTSS_CHIP_PORTS 12
#endif

#if defined(VTSS_ARCH_HAWX)
#define VTSS_CHIP_PORTS 26
#endif /* VTSS_ARCH_HAWX */

#if !defined(VTSS_CHIP_PORTS)
#define VTSS_CHIP_PORTS VTSS_PORT_COUNT
#endif

#if !defined(VTSS_CHIP_PORTMASK)
#define VTSS_CHIP_PORTMASK ((1<<VTSS_PORT_COUNT)-1)
#endif
#endif /* VTSS_ARCH_HEATHROW */

#define VTSS_CHIP_PORT_AGGR_0 24 /* Chip port 24 and 25 are paired */
#define VTSS_CHIP_PORT_AGGR_1 26 /* Chip port 26 and 27 are paired */
#define VTSS_PORT_NO_AGGR_0   (VTSS_PORTS+1) /* Pseudo port mapping to chip port 25 */
#define VTSS_PORT_NO_AGGR_1   (VTSS_PORTS+2) /* Pseudo port mapping to chip port 27 */

#if defined(VTSS_ARCH_SPARX_28)
#define VTSS_CHIP_PORT_VAUI_START 24
#endif /* VTSS_ARCH_SPARX_28 */

/* Number of internally aggregated ports */
#if VTSS_OPT_INT_AGGR
#define VTSS_PORTS_INT_AGGR 2
#else
#define VTSS_PORTS_INT_AGGR 0
#endif /* VTSS_OPT_INT_AGGR */

/* Port array including internally aggregated ports */
#define VTSS_PORT_EXT_ARRAY_SIZE (VTSS_PORT_ARRAY_SIZE+VTSS_PORTS_INT_AGGR)

/* Bit field macros */
#define VTSS_BF_SIZE(n)      ((n+7)/8)
#define VTSS_BF_GET(a, n)    ((a[(n)/8] & (1<<((n)%8))) ? 1 : 0)
#define VTSS_BF_SET(a, n, v) { if (v) { a[(n)/8] |= (1<<((n)%8)); } else { a[(n)/8] &= ~(1<<((n)%8)); }}
#define VTSS_BF_CLR(a, n)    (memset(a, 0, VTSS_BF_SIZE(n)))

/* Port member bit field macros */
#define VTSS_PORT_BF_SIZE                VTSS_BF_SIZE(VTSS_PORTS)
#define VTSS_PORT_BF_GET(a, port_no)     VTSS_BF_GET(a, port_no - VTSS_PORT_NO_START)
#define VTSS_PORT_BF_SET(a, port_no, v)  VTSS_BF_SET(a, port_no - VTSS_PORT_NO_START, v)
#define VTSS_PORT_BF_CLR(a)              VTSS_BF_CLR(a, VTSS_PORTS)

/* - Port state definitions ---------------------------------------- */

/* Port map entry */
typedef struct {
#ifdef VTSS_CHIPS
    vtss_chip_no_t chip_no[VTSS_PORT_ARRAY_SIZE];          /* Internal chip number */
    vtss_port_no_t vtss_port[VTSS_CHIPS][VTSS_CHIP_PORTS]; /* Map from (chip_no, chip_port) to vtss_port */
#else
    vtss_port_no_t vtss_port[VTSS_CHIP_PORTS]; /* Map from chip_port to vtss_port */
#endif /* VTSS_CHIPS */
    int            chip_port[VTSS_PORT_EXT_ARRAY_SIZE];  /* Map from vtss_port to chip_port */
    uint           phy_addr[VTSS_PORT_ARRAY_SIZE];       /* Map from vtss_port_no_t to phy add */
    uint           miim_controller[VTSS_PORT_ARRAY_SIZE];/* Map vtss_port to miim controller */
    int            chip_ports_all[VTSS_PORT_ARRAY_SIZE]; /* Array of all chip ports */
    BOOL           vtss_port_unused[VTSS_PORT_ARRAY_SIZE]; /* Port is unused */
} vtss_port_map_t;

#if defined(VTSS_CHIPS)
/* Internal 10G port setup */
typedef struct {
    int            chip_port;    /* Chip port number */
    BOOL           swap_rx_pins; /* Swapping of XGMII Rx pins */
    BOOL           swap_tx_pins; /* Swapping of XGMII Tx pins */

#if defined(BOARD_JETWAY48)
    /* Remaining fields are for Jetway only */
    int            miim_controller; 
    int            phy_addr;        
#endif /* BOARD_JETWAY48 */
} vtss_iport_setup_t;

#define VTSS_IPORTS 4 /* Number of internal ports */
#endif /* VTSS_CHIPS */

typedef ulong vtss_chip_counter_t;

typedef struct _vtss_chip_counters_t {
#if defined(VTSS_ARCH_HEATHROW)
    vtss_chip_counter_t rx_octets;
    vtss_chip_counter_t tx_octets;

    vtss_chip_counter_t rx_drops;
    vtss_chip_counter_t rx_packets;
    vtss_chip_counter_t rx_broadcasts;
    vtss_chip_counter_t rx_multicasts;
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    vtss_chip_counter_t rx_errors;
#else
    vtss_chip_counter_t rx_crc_align_errors;
    vtss_chip_counter_t rx_shorts;
    vtss_chip_counter_t rx_longs;
    vtss_chip_counter_t rx_fragments;
    vtss_chip_counter_t rx_jabbers;
    vtss_chip_counter_t rx_64;
    vtss_chip_counter_t rx_65_127;
    vtss_chip_counter_t rx_128_255;
    vtss_chip_counter_t rx_256_511;
    vtss_chip_counter_t rx_512_1023;
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_chip_counter_t rx_1024_max;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_chip_counter_t rx_1024_1526;
    vtss_chip_counter_t rx_1527_max;
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    vtss_chip_counter_t tx_drops;
    vtss_chip_counter_t tx_packets;
    vtss_chip_counter_t tx_broadcasts;
    vtss_chip_counter_t tx_multicasts;
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    vtss_chip_counter_t tx_errors;
#else
    vtss_chip_counter_t tx_collisions;
    vtss_chip_counter_t tx_64;
    vtss_chip_counter_t tx_65_127;
    vtss_chip_counter_t tx_128_255;
    vtss_chip_counter_t tx_256_511;
    vtss_chip_counter_t tx_512_1023;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_chip_counter_t tx_1024_max;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_chip_counter_t tx_1024_1526;
    vtss_chip_counter_t tx_1527_max;
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    vtss_chip_counter_t tx_fifo_drops;
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_chip_counter_t rx_low_priority;
    vtss_chip_counter_t rx_high_priority;
    vtss_chip_counter_t tx_low_priority;
    vtss_chip_counter_t tx_high_priority;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_chip_counter_t rx_pauses;
    vtss_chip_counter_t tx_pauses;
    vtss_chip_counter_t rx_classified_drops;
#endif /* VTSS_ARCH_STANSTED/HAWX/SPARX_28 */
#if defined(VTSS_ARCH_HAWX)
    vtss_chip_counter_t rx_backward_drops;
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_chip_counter_t rx_class[VTSS_PRIOS]; /* Always use direct chip values, regardless of current prios. */
    vtss_chip_counter_t tx_class[VTSS_PRIOS]; /* Always use direct chip values, regardless of current prios. */
#endif /* VTSS_ARCH_HAWX/SPARX_G28 */
#if defined(VTSS_ARCH_SPARX_28)
    vtss_chip_counter_t rx_local_drops;
    vtss_chip_counter_t rx_unicast;
    vtss_chip_counter_t tx_unicast;
    vtss_chip_counter_t tx_aging;
#endif /* VTSS_ARCH_SPARX_28 */
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_ARCH_GATWICK)
    vtss_chip_counter_t rx_in_bytes;
    vtss_chip_counter_t rx_symbol_carrier_err;
    vtss_chip_counter_t rx_drops;
    vtss_chip_counter_t rx_pause;
    vtss_chip_counter_t rx_unsup_opcode;
    vtss_chip_counter_t rx_ok_bytes;
    vtss_chip_counter_t rx_bad_bytes;
    vtss_chip_counter_t rx_unicast;
    vtss_chip_counter_t rx_multicast;
    vtss_chip_counter_t rx_broadcast;
    vtss_chip_counter_t rx_crc_err;
    vtss_chip_counter_t rx_undersize;
    vtss_chip_counter_t rx_fragments;
    vtss_chip_counter_t rx_in_range_length_err;
    vtss_chip_counter_t rx_out_of_range_length_err;
    vtss_chip_counter_t rx_oversize;
    vtss_chip_counter_t rx_jabbers;
    vtss_chip_counter_t rx_size64;
    vtss_chip_counter_t rx_size65_127;
    vtss_chip_counter_t rx_size128_255;
    vtss_chip_counter_t rx_size256_511;
    vtss_chip_counter_t rx_size512_1023;
    vtss_chip_counter_t rx_size1024_1518;
    vtss_chip_counter_t rx_size1519_max;
    vtss_chip_counter_t tx_out_bytes;
    vtss_chip_counter_t tx_pause;
    vtss_chip_counter_t tx_ok_bytes;
    vtss_chip_counter_t tx_unicast;
    vtss_chip_counter_t tx_multicast;
    vtss_chip_counter_t tx_broadcast;
    vtss_chip_counter_t tx_size64;
    vtss_chip_counter_t tx_size65_127;
    vtss_chip_counter_t tx_size128_255;
    vtss_chip_counter_t tx_size256_511;
    vtss_chip_counter_t tx_size512_1023;
    vtss_chip_counter_t tx_size1024_1518;
    vtss_chip_counter_t tx_size1519_max;
    vtss_chip_counter_t tx_underrun;
    vtss_chip_counter_t rx_ipg_shrink;
    vtss_chip_counter_t tx_queue_system_drops;
    vtss_chip_counter_t tx_mac_drop;

    /* These fields are only relevant fo D4, for D10 these fields remain 0 */
    vtss_chip_counter_t rx_alignment_err;
    vtss_chip_counter_t tx_multi_coll;
    vtss_chip_counter_t tx_late_coll;
    vtss_chip_counter_t tx_xcoll;
    vtss_chip_counter_t tx_defer;
    vtss_chip_counter_t tx_xdefer;
    vtss_chip_counter_t tx_csense;
    vtss_chip_counter_t tx_backoff1;
    vtss_chip_counter_t tx_backoff2;
    vtss_chip_counter_t tx_backoff3;
    vtss_chip_counter_t tx_backoff4;
    vtss_chip_counter_t tx_backoff5;
    vtss_chip_counter_t tx_backoff6;
    vtss_chip_counter_t tx_backoff7;
    vtss_chip_counter_t tx_backoff8;
    vtss_chip_counter_t tx_backoff9;
    vtss_chip_counter_t tx_backoff10;
    vtss_chip_counter_t tx_backoff11;
    vtss_chip_counter_t tx_backoff12;
    vtss_chip_counter_t tx_backoff13;
    vtss_chip_counter_t tx_backoff14;
    vtss_chip_counter_t tx_backoff15;
#endif /* VTSS_ARCH_GATWICK */

} vtss_chip_counters_t;

/* Structure for accumulated chip specific counters */
typedef struct {
#if defined(VTSS_ARCH_HEATHROW)
    vtss_counter_t  rx_octets;
    vtss_counter_t  tx_octets;

    vtss_counter_t  rx_drops;
    vtss_counter_t  rx_packets;
    vtss_counter_t  rx_broadcasts;
    vtss_counter_t  rx_multicasts;
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    vtss_counter_t  rx_errors;
#else
    vtss_counter_t  rx_crc_align_errors;
    vtss_counter_t  rx_shorts;
    vtss_counter_t  rx_longs;
    vtss_counter_t  rx_fragments;
    vtss_counter_t  rx_jabbers;
    vtss_counter_t  rx_64;
    vtss_counter_t  rx_65_127;
    vtss_counter_t  rx_128_255;
    vtss_counter_t  rx_256_511;
    vtss_counter_t  rx_512_1023;
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_counter_t  rx_1024_max;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_counter_t  rx_1024_1526;
    vtss_counter_t  rx_1527_max;
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    vtss_counter_t  tx_drops;
    vtss_counter_t  tx_packets;
    vtss_counter_t  tx_broadcasts;
    vtss_counter_t  tx_multicasts;
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    vtss_counter_t  tx_errors;
#else
    vtss_counter_t  tx_collisions;
    vtss_counter_t  tx_64;
    vtss_counter_t  tx_65_127;
    vtss_counter_t  tx_128_255;
    vtss_counter_t  tx_256_511;
    vtss_counter_t  tx_512_1023;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_counter_t  tx_1024_max;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_counter_t  tx_1024_1526;
    vtss_counter_t  tx_1527_max;
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    vtss_counter_t  tx_fifo_drops;
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_counter_t  rx_low_priority;
    vtss_counter_t  rx_high_priority;
    vtss_counter_t  tx_low_priority;
    vtss_counter_t  tx_high_priority;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_counter_t  rx_pauses;
    vtss_counter_t  tx_pauses;
    vtss_counter_t  rx_classified_drops;
#endif /* VTSS_ARCH_STANSTED/VTSS_ARCH_HAWX/SPARX_28 */
#if defined(VTSS_ARCH_HAWX)
    vtss_counter_t  rx_backward_drops;
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    vtss_counter_t  rx_class[VTSS_PRIOS];
    vtss_counter_t  tx_class[VTSS_PRIOS];
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#if defined(VTSS_ARCH_SPARX_28)
    vtss_counter_t  rx_local_drops;
    vtss_counter_t  rx_unicast;
    vtss_counter_t  tx_unicast;
    vtss_counter_t  tx_aging;
#endif /* VTSS_ARCH_SPARX_28 */
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_ARCH_GATWICK)
    vtss_counter_t  rx_in_bytes;
    vtss_counter_t  rx_symbol_carrier_err;
    vtss_counter_t  rx_drops;
    vtss_counter_t  rx_pause;
    vtss_counter_t  rx_unsup_opcode;
    vtss_counter_t  rx_ok_bytes;
    vtss_counter_t  rx_bad_bytes;
    vtss_counter_t  rx_unicast;
    vtss_counter_t  rx_multicast;
    vtss_counter_t  rx_broadcast;
    vtss_counter_t  rx_crc_err;
    vtss_counter_t  rx_undersize;
    vtss_counter_t  rx_fragments;
    vtss_counter_t  rx_in_range_length_err;
    vtss_counter_t  rx_out_of_range_length_err;
    vtss_counter_t  rx_oversize;
    vtss_counter_t  rx_jabbers;
    vtss_counter_t  rx_size64;
    vtss_counter_t  rx_size65_127;
    vtss_counter_t  rx_size128_255;
    vtss_counter_t  rx_size256_511;
    vtss_counter_t  rx_size512_1023;
    vtss_counter_t  rx_size1024_1518;
    vtss_counter_t  rx_size1519_max;
    vtss_counter_t  tx_out_bytes;
    vtss_counter_t  tx_pause;
    vtss_counter_t  tx_ok_bytes;
    vtss_counter_t  tx_unicast;
    vtss_counter_t  tx_multicast;
    vtss_counter_t  tx_broadcast;
    vtss_counter_t  tx_size64;
    vtss_counter_t  tx_size65_127;
    vtss_counter_t  tx_size128_255;
    vtss_counter_t  tx_size256_511;
    vtss_counter_t  tx_size512_1023;
    vtss_counter_t  tx_size1024_1518;
    vtss_counter_t  tx_size1519_max;
    vtss_counter_t  tx_underrun;
    vtss_counter_t  rx_ipg_shrink;
    vtss_counter_t  tx_queue_system_drops;
    vtss_counter_t  tx_mac_drop;

    /* These fields are only relevant for 1G ports, for 10G ports these fields remain 0 */
    vtss_counter_t  rx_alignment_err;
    vtss_counter_t  tx_multi_coll;
    vtss_counter_t  tx_late_coll;
    vtss_counter_t  tx_xcoll;
    vtss_counter_t  tx_defer;
    vtss_counter_t  tx_xdefer;
    vtss_counter_t  tx_csense;
    vtss_counter_t  tx_backoff1;
    vtss_counter_t  tx_backoff2;
    vtss_counter_t  tx_backoff3;
    vtss_counter_t  tx_backoff4;
    vtss_counter_t  tx_backoff5;
    vtss_counter_t  tx_backoff6;
    vtss_counter_t  tx_backoff7;
    vtss_counter_t  tx_backoff8;
    vtss_counter_t  tx_backoff9;
    vtss_counter_t  tx_backoff10;
    vtss_counter_t  tx_backoff11;
    vtss_counter_t  tx_backoff12;
    vtss_counter_t  tx_backoff13;
    vtss_counter_t  tx_backoff14;
    vtss_counter_t  tx_backoff15;
#endif /* VTSS_ARCH_GATWICK */

} vtss_port_big_counters_t;

/* - Packet state definitions -------------------------------------- */

#define VTSS_FCS_SIZE 4 /* MAC frame CRC size */

#if defined(VTSS_ARCH_GATWICK)
/* Rx packet state required for Gatwick */
typedef struct {
    BOOL                       used;         /* Packet used flag */
#ifdef VTSS_CHIPS
    vtss_chip_no_t             chip_no;      /* Next internal chip to read frame from */
#endif /* VTSS_CHIPS */
    vtss_system_frame_header_t sys_header;   /* Rx frame header */ 
    vtss_cpu_rx_queue_t        queue_no;     /* Current queue number */
    uchar                      buf[16*1024]; /* Buffer for preview */
    uint                       length;       /* Current preview length */ 
} vtss_packet_rx_t;
#endif /* VTSS_ARCH_GATWICK */

#if defined(VTSS_ARCH_SPARX_28)
typedef struct {
    BOOL                       used;         /* Packet used flag */
    uint                       words_read;   /* Number of words read */
    vtss_system_frame_header_t sys_header;   /* Rx frame header */ 
} vtss_packet_rx_t;
#endif /* VTSS_ARCH_SPARX_28 */

/* - L2 state definitions ------------------------------------------ */

/* Port Group ID */
typedef uint vtss_pgid_no_t;

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_CHIP_PGIDS_GW   256 /* Gatwick PGIDs */
#define VTSS_CHIP_PGIDS      512
#define VTSS_PGID_END_GW     (VTSS_PGID_START+VTSS_CHIP_PGIDS_GW-(VTSS_CHIP_PORTS-VTSS_PORTS))
#endif /* VTSS_ARCH_GATWICK */

#if defined(VTSS_ARCH_HEATHROW)
#define VTSS_CHIP_PGIDS      64
#endif /* VTSS_ARCH_HEATHROW */

#define VTSS_PGID_NONE            (0)
#define VTSS_PGID_START           (1)
#if defined(VTSS_ARCH_GATWICK) && defined(VTSS_CHIPS)
#define VTSS_PGID_SIZE            (VTSS_CHIP_PGIDS)
#define VTSS_PGID_GLAG_START      257
#else
#define VTSS_PGID_SIZE            (VTSS_CHIP_PGIDS-(VTSS_CHIP_PORTS-VTSS_PORTS))
#endif /* VTSS_ARCH_GATWICK && VTSS_CHIPS */
#define VTSS_PGID_END             (VTSS_PGID_START+VTSS_PGID_SIZE)
#define VTSS_PGID_UNICAST_START   (VTSS_PGID_START)
#define VTSS_PGID_UNICAST_END     (VTSS_PGID_START+VTSS_PORTS)
#define VTSS_PGID_KILL            (VTSS_PGID_UNICAST_END)
#define VTSS_PGID_BC              (VTSS_PGID_KILL+1)
#define VTSS_PGID_MULTICAST_START (VTSS_PGID_BC+1)
#define VTSS_PGID_MULTICAST_END   (VTSS_PGID_END)
#define VTSS_PGID_ARRAY_SIZE      VTSS_PGID_END

/* Masks reserved for GLAG support */
#if defined(VTSS_FEATURE_AGGR_GLAG)
#define VTSS_PGID_GLAG_START      (VTSS_PGID_START+30+VTSS_PORTS-VTSS_CHIP_PORTS)
#define VTSS_PGID_GLAGS           8
#define VTSS_PGID_GLAG_END        (VTSS_PGID_GLAG_START+VTSS_PGID_GLAGS)
#define VTSS_PGID_GLAG_DEST       (VTSS_PGID_GLAG_START+0) /* 30-31: Dest. masks */
#define VTSS_PGID_GLAG_SRC        (VTSS_PGID_GLAG_START+2) /* 32-33: Src. masks */
#define VTSS_PGID_GLAG_AGGR_0     (VTSS_PGID_GLAG_START+4) /* 34-35: Aggr. A masks */
#define VTSS_PGID_GLAG_AGGR_1     (VTSS_PGID_GLAG_START+6) /* 36-37: Aggr. B masks */
#endif /* VTSS_FEATURE_AGGR_GLAG */

/* Mapping between high level PGID and chip PGID is done in the low level layer */

/* PGID entry */
typedef struct {
    BOOL member[VTSS_PORT_ARRAY_SIZE]; /* Egress ports/aggregations */
    BOOL resv;                         /* Fixed reservation */
    uint references;                   /* Number references to entry */
} vtss_pgid_entry_t;

/* Aggregation table */
typedef uint vtss_ac_no_t;

#if defined(VTSS_ARCH_HEATHROW)
#if defined(HEATHROW2)
#define VTSS_ACS      ((vtss_ac_no_t)8)
#else
#define VTSS_ACS      ((vtss_ac_no_t)16)
#endif /* HEATHROW2 */
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_ACS      ((vtss_ac_no_t)64)
#endif /* VTSS_ARCH_GATWICK */

#define VTSS_AC_START ((vtss_ac_no_t)1)
#define VTSS_AC_END   (VTSS_AC_START+VTSS_ACS)

/* VLAN entry */
typedef struct {
    BOOL        enabled;                      /* One or more ports enabled */
    BOOL        member[VTSS_PORT_ARRAY_SIZE]; /* Egress ports */
    vtss_msti_t msti;                         /* MSTP intstance */
#if defined(VTSS_FEATURE_ISOLATED_PORT)
    BOOL        isolated;
#endif /* VTSS_FEATURE_ISOLATED_PORT */
} vtss_vlan_entry_t;

/* MSTP entry */
typedef struct {
    vtss_mstp_state_t state[VTSS_PORT_ARRAY_SIZE];       /* MSTP state */
} vtss_mstp_entry_t;

#define VTSS_STP_FORWARDING(stp_state) (stp_state==VTSS_STP_STATE_FORWARDING || stp_state==VTSS_STP_STATE_ENABLED)
#define VTSS_STP_UP(stp_state)         (stp_state!=VTSS_STP_STATE_DISABLED)

/* PVLAN entry */
typedef struct {
    BOOL member[VTSS_PORT_ARRAY_SIZE]; /* Member ports */
} vtss_pvlan_entry_t;

/* Size of lookup page and pointer array */
#define VTSS_MAC_PAGE_SIZE 128 
#define VTSS_MAC_PTR_SIZE  (VTSS_MAC_ADDRS/VTSS_MAC_PAGE_SIZE)

/* MAC address table for get next operations */
typedef struct vtss_mac_entry_t {
    struct vtss_mac_entry_t *next;  /* Next in list */
    ulong                   mach;  /* VID and 16 MSB of MAC */
    ulong                   macl;  /* 32 LSB of MAC */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    uchar                   member[VTSS_PORT_BF_SIZE];
#else
    ulong                   block; /* Table block index */
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
} vtss_mac_entry_t;

#if defined(VTSS_FEATURE_ACL)

/* Number of ACEs */
#if defined(G_ROCX)
#define VTSS_ACES 64 
#else
#define VTSS_ACES 128
#endif /* G_ROCX */

typedef struct vtss_acl_entry_t {
    struct vtss_acl_entry_t *next;   /* Next in list */
    vtss_ace_t              ace;     /* ACE data */
    ulong                   counter; /* Hit counter */
} vtss_acl_entry_t;

/* UDP/TCP range checkers */
#define VTSS_ACL_RANGES 8
typedef struct {
    vtss_ace_udp_tcp_t port;  /* UDP/TCP range information */
    BOOL               sport; /* Source or destination port */
    uint               count; /* Reference count */
} vtss_acl_range_t;

#endif /* VTSS_FEATURE_ACL */

/* IPv4 and IPv6 multicast address */
#define VTSS_MAC_IPV4_MC(mac) (mac[0] == 0x01 && mac[1] == 0x00 && mac[2] == 0x5e && (mac[3] & 0x80) == 0x00)
#define VTSS_MAC_IPV6_MC(mac) (mac[0] == 0x33 && mac[1] == 0x33)

/* - L3 state definitions ------------------------------------------ */

#if defined(VTSS_FEATURE_LAYER3)

/* Port Router Leg ID: VTSS_PRLID_START..(VTSS_PRLID_END-1) */
typedef uchar vtss_prlid_t;
#define VTSS_PRLIDS           ((vtss_prlid_t)4)
#define VTSS_PRLID_L2         ((vtss_prlid_t)0) /* Pseudo PRLID for L2 */
#define VTSS_PRLID_START      ((vtss_prlid_t)1)
#define VTSS_PRLID_END        (VTSS_PRLID_START+VTSS_PRLIDS)
#define VTSS_PRLID_ARRAY_SIZE VTSS_PRLID_END

/* Egress Router Leg ID */
typedef uint vtss_erlgid_t;
#define VTSS_ERLGIDS           ((vtss_erlgid_t)31) /* ERLGID zero reserved for L2 */
#define VTSS_ERLGID_START      ((vtss_erlgid_t)1)
#define VTSS_ERLGID_END        (VTSS_ERLGID_START+VTSS_ERLGIDS)
#define VTSS_ERLGID_ARRAY_SIZE VTSS_ERLGID_END

/* Router Leg entry */
typedef struct {
    vtss_rl_t     rl;                          /* Router Leg info */
    BOOL          enabled;                     /* Router Leg enabled */
    vtss_prlid_t  prlid[VTSS_PORT_ARRAY_SIZE]; /* Port Router Leg, zero if not used */
    vtss_vrid_t   vrids[VTSS_VRIDS];           /* Virtual Routers, if non-zero */
    vtss_prlid_t  vr_prlid[VTSS_VRIDS][VTSS_PORT_ARRAY_SIZE]; /* VR Port Router Legs */
    vtss_erlgid_t erlgid;                      /* ERLGID allocated for Router Leg */
} vtss_rl_entry_t;

/* Egress Router Leg Group ID entry */
typedef struct {
    vtss_rlid_t    irlid;                       /* Ingress Router Leg, zero for unicast */
    BOOL           erlid[VTSS_RLID_ARRAY_SIZE]; /* Egress Router Leg list */
    vtss_pgid_no_t pgid_no;                     /* PGID number, multicast only */
    uint           ref_count;                   /* Reference count */
} vtss_erlgid_entry_t;

/* Unicast forwarding table index */
typedef uint vtss_ucid_t;
#define VTSS_UCIDS           ((vtss_ucid_t)64)
#define VTSS_UCID_START      ((vtss_ucid_t)1)
#define VTSS_UCID_END        (VTSS_UCID_START+VTSS_UCIDS)
#define VTSS_UCID_ARRAY_SIZE VTSS_UCID_END

/* ARP table index */
typedef uint vtss_arpid_t;
#define VTSS_ARPIDS           ((vtss_arpid_t)8192)
#define VTSS_ARPID_START      ((vtss_arpid_t)1)  /* First entry */
#define VTSS_ARPID_FIRST      ((vtss_arpid_t)2)  /* First entry available for allocation */
#define VTSS_ARPID_END        (VTSS_ARPID_START+VTSS_ARPIDS)
#define VTSS_ARPID_ARRAY_SIZE VTSS_ARPID_END

/* Unicast forwarding entry */
typedef struct {
    vtss_ip_t    net;         /* Network address */
    vtss_ip_t    mask;        /* Network mask */
    vtss_ip_t    router;      /* Next hop router, zero for local networks */
    vtss_ip_t    parent_net;  /* Parent network */
    vtss_ip_t    parent_mask; /* Parent mask */
    BOOL         enabled;     /* Entry enabled */ 
    vtss_arpid_t arpid;       /* ARP base index */
    uint         arp_count;   /* ARP reference count */
    uint         plen;        /* Prefix length */
} vtss_uc_entry_t; 

/* ARP entry */
typedef struct {
    BOOL        enabled; /* Entry enabled */
    vtss_rlid_t rlid;    /* Egress Router Leg ID */
} vtss_arp_entry_t;

#endif /* VTSS_FEATURE_LAYER3 */

#if defined(VTSS_ARCH_SPARX_G8)
typedef enum _vtss_luton_version_t {
    VTSS_LUTON_TYPE_BASIC,      /* SparX-G5 or SparX-G8 */
    VTSS_LUTON_TYPE_EXT,        /* SparX-G5e or SparX-G8e */
    VTSS_LUTON_TYPE_R2          /* SparX-G5m */
} vtss_luton_version_t;
#endif /* VTSS_ARCH_SPARX_G8 */

#if defined(VTSS_FEATURE_QCL_PORT)
#define VTSS_QCL_LIST_SIZE 24

typedef struct vtss_qcl_entry_t {
    struct vtss_qcl_entry_t *next;  /* Next in list */
    vtss_qce_t               qce;   /* This entry */
} vtss_qcl_entry_t;

typedef struct {
    vtss_qcl_entry_t         *qcl_list_used;               /* Free entries for QCL usage */
    vtss_qcl_entry_t         *qcl_list_free;               /* Entries in QCL List */
    vtss_qcl_entry_t         qcl_list[VTSS_QCL_LIST_SIZE]; /* Actual storage for list members */
} vtss_qcl_t;
#endif /* VTSS_FEATURE_QCL_PORT */

/* - Supplementary state definitions ------------------------------- */

/* Structure holding all the state information */
typedef struct {
    /* --- Supplementary state --- */
    vtss_init_setup_t        init_setup;       /* Init setup */
    BOOL                     debug_read_write; /* Enable VTSS_D trace for read/write */

    /* --- Port state --- */
#if defined(VTSS_CHIPS)
    /* Internal ports */
    uint                     iport_first[VTSS_CHIPS];  /* Index to first internal port */
    uint                     iport_last[VTSS_CHIPS];   /* Index to last internal port */
    vtss_iport_setup_t       iport_setup[VTSS_IPORTS]; /* Internal port setup */
    BOOL                     fc_internal;              /* Flow control on internal ports */
    BOOL                     jumbo_internal;           /* Jumbo mode on internal ports */
    BOOL                     pvlan_isolate;            /* Isolation of chips due to PVLANs */
#ifdef BOARD_JETWAY48
    ulong                    rx_ok_bytes[VTSS_IPORTS]; /* Rx counter for LED control */
    ulong                    tx_ok_bytes[VTSS_IPORTS]; /* Tx counter for LED control */
#endif /* BOARD_JETWAY48 */
#endif /* VTSS_CHIPS */

    vtss_port_map_t          port_map;
    vtss_prio_t              prios;                            /* Number of priorities used */
    vtss_port_setup_t        setup[VTSS_PORT_EXT_ARRAY_SIZE];   /* Written by vtss_port_setup() only. */
    BOOL                     port_fc_rx[VTSS_PORT_ARRAY_SIZE]; /* Rx flow control (obey pause) */
    BOOL                     port_fc_tx[VTSS_PORT_ARRAY_SIZE]; /* Tx flow control (gen. pause) */
    BOOL                     jumbo;
#if defined(VTSS_FEATURE_QOS_WFQ_PORT)
    BOOL                     wfq;
#endif /* VTSS_FEATURE_QOS_WFQ_PORT */
    vtss_chip_counters_t     port_last_counters[VTSS_PORT_EXT_ARRAY_SIZE];/* Last chip counters */
    vtss_port_big_counters_t poag_big_counters[VTSS_POAG_ARRAY_SIZE]; /* Accumulated counters */
    vtss_port_qos_setup_t    qos[VTSS_PORT_EXT_ARRAY_SIZE];
    vtss_qos_setup_t         qos_setup;
#if defined(VTSS_FEATURE_VSTAX)
    vtss_vstax_setup_t       vstax_setup;                              /* VStaX switch setup */
    vtss_vstax_port_setup_t  vstax_port_setup[VTSS_PORT_EXT_ARRAY_SIZE]; /* VStaX port setup */
#endif /* VTSS_FEATURE_VSTAX */    
#if defined(VTSS_FEATURE_QCL_PORT)
    vtss_qcl_t               qcl[VTSS_QCL_ARRAY_SIZE];     /* QCL setup */
#endif /* VTSS_FEATURE_QCL_PORT */

    /* --- Packet state --- */
#if defined(VTSS_ARCH_GATWICK)
    vtss_packet_rx_t         rx_packet;
    vtss_cpu_rx_queue_t      learn_queue; /* Learn queue (48-port solutions) */
    BOOL                     learn_auto;  /* Learn automatic */
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_ARCH_SPARX_28)
    vtss_packet_rx_t         rx_packet[VTSS_CPU_RX_QUEUES];
#endif /* VTSS_ARCH_SPARX_28 */
#if defined(VTSS_ARCH_HAWX)
    uint                     rx_queue_size[VTSS_CPU_RX_QUEUES]; /* Size in kB */
#endif /* VTSS_ARCH_HAWX */
    vtss_cpu_rx_registration_t rx_registration;

    /* --- L2 state --- */

    vtss_poag_no_t           port_poag_no[VTSS_PORT_ARRAY_SIZE]; /* Aggregation setup */
#if defined(VTSS_FEATURE_AGGR_GLAG)
    vtss_glag_no_t           port_glag_no[VTSS_PORT_ARRAY_SIZE];    /* GLAG setup */
    vtss_port_no_t           port_glag_index[VTSS_PORT_ARRAY_SIZE];
    uint                     glag_port_count[VTSS_GLAGS];           /* Number of ports */
    vtss_port_no_t           glag_members[VTSS_GLAGS][VTSS_GLAG_PORT_ARRAY_SIZE];
#endif /* VTSS_FEATURE_AGGR_GLAG */
#if defined(VTSS_ARCH_GATWICK)
    vtss_port_no_t           logical_port_no[VTSS_PORT_ARRAY_SIZE];
#if defined(VTSS_CHIPS)
    BOOL                     port_aggr_multi[VTSS_PORT_ARRAY_SIZE]; /* Port is first port 
                                                                       in multi chip aggr. */
#endif /* VTSS_CHIPS */
#endif /* VTSS_ARCH_GATWICK */
    BOOL                     aggr_member[VTSS_PORT_ARRAY_SIZE];  /* Aggregation mask 0 */
#if VTSS_OPT_INT_AGGR
    uint                     aggr_chip_port_next[VTSS_PORTS_INT_AGGR]; /* Next port to exclude from aggregation mask */
#endif /* VTSS_OPT_INT_AGGR */
    vtss_vlan_entry_t        vlan_table[VTSS_VIDS];
    vtss_vlan_port_mode_t    vlan_port_table[VTSS_PORT_ARRAY_SIZE];
#if defined(VTSS_CHIPS)
    BOOL                     vlan_aware; /* VLAN awareness on internal ports */
    uint                     mac_age_index; /* Index for MAC table aging */
    uint                     mac_flush_index_port[VTSS_PORT_ARRAY_SIZE]; /* Index per port */
#endif /* VTSS_CHIPS */
    vtss_mac_table_status_t  mac_status_appl; /* Application status */
    vtss_mac_table_status_t  mac_status_next; /* Get next optimization status */
    vtss_mac_table_status_t  mac_status_sync; /* Synchronization status */
    uint                     mac_index_sync;  /* Index for MAC table optimization */
#if (VTSS_OPT_MAC_NEXT_MAX!=0)
    uint                     mac_index_next;  /* Index for MAC table get next */
    uint                     mac_table_count; /* Number of entries in mac_table */
    vtss_mac_entry_t         *mac_list_used;  /* Sorted list of entries */
    vtss_mac_entry_t         *mac_list_free;  /* Free list */
    vtss_mac_entry_t         mac_table[VTSS_MAC_ADDRS]; /* Sorted MAC address table */
    uint                     mac_ptr_count;   /* Number of valid pointers */
    vtss_mac_entry_t         *mac_list_ptr[VTSS_MAC_PTR_SIZE]; /* Pointer array */
#endif /* VTSS_OPT_MAC_NEXT_MAX */
    vtss_pgid_entry_t        pgid_table[VTSS_PGID_ARRAY_SIZE];
    vtss_stp_state_t         stp_state[VTSS_PORT_ARRAY_SIZE];
    vtss_mstp_entry_t        mstp_table[VTSS_MSTI_ARRAY_SIZE];
    vtss_auth_state_t        auth_state[VTSS_PORT_ARRAY_SIZE];
    vtss_pvlan_entry_t       pvlan_table[VTSS_PVLAN_ARRAY_SIZE];
    vtss_port_no_t           mirror_port;
    BOOL                     mirror_ingress[VTSS_PORT_ARRAY_SIZE];
    BOOL                     mirror_egress[VTSS_PORT_ARRAY_SIZE];
#if defined(VTSS_FEATURE_ACL)
    vtss_acl_entry_t         *acl_list; /* List of active ACEs */
    vtss_acl_entry_t         *acl_free; /* List of free ACEs */
    vtss_acl_entry_t         acl[VTSS_ACES];
    vtss_acl_range_t         acl_range[VTSS_ACL_RANGES];
#endif /* VTSS_FEATURE_ACL */

#if defined(VTSS_FEATURE_LAYER3)
    /* --- L3 state --- */
    vtss_rl_entry_t          rl_table[VTSS_RLID_ARRAY_SIZE];
    vtss_erlgid_entry_t      erlgid_table[VTSS_ERLGID_ARRAY_SIZE];
    vtss_uc_entry_t          uc_table[VTSS_UCID_ARRAY_SIZE];
    uint                     mc_size;  /* Number of bits in hash function */
    uint                     arp_size; /* Number of ARP entries */
    vtss_arp_entry_t         arp_table[VTSS_ARPID_ARRAY_SIZE];
    vtss_ip_counters_t       ip_counters_last;
    vtss_ip_counters_t       ip_counters;
    vtss_rl_counters_t       rl_counters[VTSS_RLID_ARRAY_SIZE];
    vtss_mac_t               vrrp_base;
#endif /* VTSS_FEATURE_LAYER3 */

    /* --- Other state --- */
#if defined(VTSS_ARCH_HEATHROW)
#if defined(VTSS_ARCH_STAPLEFORD)
    ulong                    dbqhprx_prev[VTSS_PORT_ARRAY_SIZE],
                             dbqlprx_prev[VTSS_PORT_ARRAY_SIZE],
                             dbqhptx_prev[VTSS_PORT_ARRAY_SIZE],
                             dbqlptx_prev[VTSS_PORT_ARRAY_SIZE];
    int                      congested_count[VTSS_PORT_ARRAY_SIZE];
#if VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1 /*Auto/Fixed*/
    /* Shaper configuration from vtss_ll_port_qos_setup_set(). 0=DISABLED. Index is port_no. */
    int                      shapeconf_bucket_rate_wanted[VTSS_PORT_ARRAY_SIZE];
#endif /* VTSS_OPT_FC_SHAPING_BUCKET_RATE is Auto/Fixed */
#if VTSS_OPT_FC_SHAPING_BUCKET_RATE==1 /*Auto*/
    ulong                    dropcnt_prev[VTSS_PORT_ARRAY_SIZE];
    int                      shapeconf_bucket_rate_prev[VTSS_PORT_ARRAY_SIZE];
    BOOL                     limit_reached[VTSS_PORT_ARRAY_SIZE];
    uint                     shaping_disable_count[VTSS_PORT_ARRAY_SIZE];
#endif
#endif /* VTSS_ARCH_STAPLEFORD */
#endif
#if defined(HEATHROW2)
    /* Errata #5 (601). */
    /* The counter is 16 bits wide. Index is port_no. */
    ulong    rx_drops_when_cleared[VTSS_PORT_ARRAY_SIZE];
    /* Errata #6 (631). */
    /* The counter is 16 bits wide. Index is port_no. */
    ulong    tx_fifo_drops_when_cleared[VTSS_PORT_ARRAY_SIZE];
#endif /* HEATHROW2 */
#if defined(VTSS_ARCH_SPARX_28)
    ulong                    tx_packets[VTSS_PORT_ARRAY_SIZE];
#endif /* VTSS_ARCH_SPARX_28 */


#if defined(VTSS_ARCH_GATWICK)
    ulong                    tx_drops[VTSS_PORT_ARRAY_SIZE];
    ulong                    tx_bytes[VTSS_PORT_ARRAY_SIZE];
#endif /* VTSS_ARCH_GATWICK */

#if defined(VTSS_ARCH_GATWICK)
    BOOL                     gw1e; /* Gatwick-Ie chip found */
#endif /* VTSS_ARCH_GATWICK */
#if defined(VTSS_ARCH_HAWX)
    BOOL                     hawx_b; /* HawX revision B chip found */
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_G8)
    vtss_luton_version_t     g58_type; /* Sparx-G5/8e/5m chip found */
#endif /* VTSS_ARCH_SPARX_G8 */
    vtss_pgid_no_t           pgid_end;  /* End of PGID table */
    uint                     mac_addrs; /* Number of MAC addresses */
    vtss_msti_t              msti_end;  /* End of MSTP table */
#if defined(VTSS_FEATURE_LAYER3)
    vtss_rlid_t              rlid_end;  /* End of Router Leg table */
#endif /* VTSS_FEATURE_LAYER3 */
} vtss_state_info_t;

extern vtss_state_info_t *vtss_api_state; /* API high level state */
extern vtss_state_t *vtss_state;          /* Full API state */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_PORT_IS_10G(chip_port) (chip_port<8)
#endif /* VTSS_ARCH_GATWICH */

#if defined(VTSS_ARCH_HEATHROW)
#define VTSS_PORT_IS_10G(chip_port) 0
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_FEATURE_10G) || defined(BOARD_JETWAY48)

/* Register addresses common for most MMDs */
#define MMD_CTRL_1           0
#define MMD_STAT_1           1
#define MMD_DEV_ID_1         2
#define MMD_DEV_ID_2         3
#define MMD_SPEED_AB         4
#define MMD_DEV_1            5
#define MMD_DEV_2            6
#define MMD_CTRL_2           7
#define MMD_STAT_2           8

/* Masks for MMD_CTRL_1 */
#define MMD_CTRL_1_RESET     (1<<15)
#define MMD_CTRL_1_LOWPOWER  (1<<11)
#define MMD_CTRL_1_LOOPBACK  (1<<0 | 1<<14) /* Either bit 0 or bit 14 enables loopback */

/* Masks for MMD_STAT_1 */
#define MMD_STAT_1_FAULT     (1<<7)
#define MMD_STAT_1_LINK_UP   (1<<2)
#define MMD_STAT_1_LOWPOW_AB (1<<1)

/* Masks for MMD_DEV_1 */
#define MMD_DEV_1_DTE_XS     (1<<5)
#define MMD_DEV_1_PHY_XS     (1<<4)
#define MMD_DEV_1_PCS        (1<<3)
#define MMD_DEV_1_WIS        (1<<2)
#define MMD_DEV_1_PMD_PMA    (1<<1)
#define MMD_DEV_1_CL_22      (1<<0)

/* Masks for MMD_SPEED_AB */
#define MMD_SPEED_AB_10G     (1<<0)

#endif /* VTSS_FEATURE_10G || BOARD_JETWAY48 */

/* Read MAC address table status bits */
vtss_rc vtss_mac_table_status_read(void);

/* Write PGID member to chip */
vtss_rc vtss_pgid_table_write(const vtss_pgid_no_t pgid_no);

/* Allocate PGID */
vtss_rc vtss_pgid_alloc(vtss_pgid_no_t *pgid_no, BOOL resv, 
                        const BOOL member[VTSS_POAG_ARRAY_SIZE]);

/* Free PGID */
vtss_rc vtss_pgid_free(const vtss_pgid_no_t pgid_no);

#endif /* _VTSS_STATE_H_ */
/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
