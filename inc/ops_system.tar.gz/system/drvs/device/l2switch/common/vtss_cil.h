/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_cil.h,v 1.38 2007/09/05 13:48:22 cpj Exp $
 $Revision: 1.38 $

*/

#include "vtss_os.h"
#include "vtss_basic_trace.h"

#ifndef _VTSS_LL_H_
#define _VTSS_LL_H_

/* Read from the phy register */
vtss_rc vtss_ll_phy_read(uint miim_controller, uint phy_addr, uint phy_reg, ushort *value);

/* Write to the phy register */
vtss_rc vtss_ll_phy_write(uint miim_controller, uint phy_addr, uint phy_reg, ushort value);

/* Read from MMD */
vtss_rc vtss_ll_mmd_read(uint miim_controller, uint phy_addr, uint mmd, uint address, ushort *value);

/* Write to MMD  */
vtss_rc vtss_ll_mmd_write(uint miim_controller, uint phy_addr, uint phy_reg, uint address, ushort value);

#ifdef VTSS_FEATURE_TBI

/* Check if TBI is enabled */
vtss_rc vtss_ll_port_tbi_enabled(uint port_no, BOOL *enabled);

/* Check if TBI autoneg is enabled */
vtss_rc vtss_ll_port_tbi_autoneg_enabled(uint port_no, BOOL *enabled);

/* Get word used in TBI autoneg */
vtss_rc vtss_ll_port_tbi_get_aneg_advertisement(uint port_no, 
                                                vtss_autoneg_1000base_x_advertisement_t * advertisement);

/* Enable/Disable TBI autoneg */
vtss_rc vtss_ll_port_tbi_aneg_control( const vtss_port_no_t port_no,
                                       const vtss_tbi_autoneg_control_t * const control );

/* Enable TBI autoneg */
vtss_rc vtss_ll_port_tbi_aneg_enable(uint port_no,
                                     const vtss_autoneg_1000base_x_advertisement_t *adv);

/* Restart TBI autoneg */
vtss_rc vtss_ll_port_tbi_aneg_restart(uint port_no);

/* Get TBI status */
vtss_rc vtss_ll_port_tbi_status_get(uint port_no, vtss_tbi_status_t *status);

#endif /* VTSS_FEATURE_TBI */

/* Configure port into one of the gmii modes or tbi mode */
vtss_rc vtss_ll_port_speed_mode_tbi_gmii(vtss_port_no_t port_no,
                                         const vtss_port_setup_t * setup);

/* Configure port into one of the xgmii mode */
vtss_rc vtss_ll_port_speed_mode_xgmii(vtss_port_no_t port_no,
                                      const vtss_port_setup_t * setup);

/* Enable or disable and flush port queue systems */
vtss_rc vtss_ll_port_queue_enable(vtss_port_no_t port_no, BOOL enable);

/* Setup water marks, drop levels, etc for port */
vtss_rc vtss_ll_port_queue_setup(vtss_port_no_t port_no);

/* Get VAUI port status */
vtss_rc vtss_ll_vaui_status_get(vtss_port_no_t port_no, vtss_port_status_t * const status);

/* Determine if 10G port is up */
vtss_rc vtss_ll_port_up(vtss_port_no_t port_no, BOOL *port_up);

/* Set port QoS setup */
vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos);

/* Set switch QoS setup */
vtss_rc vtss_ll_qos_setup_set(const vtss_qos_setup_t *qos);

/* Set SIP filter */
vtss_rc vtss_ll_filter_sip_set(const vtss_port_no_t port_no,
                               const vtss_ip_t      sip,
                               const vtss_ip_t      mask);

#if defined(VTSS_FEATURE_FILTER_UDP_TCP)
/* Set UDP/TCP filter */
vtss_rc vtss_ll_filter_udp_tcp_set(const vtss_filter_action_t * const action,
                                   const vtss_udp_tcp_t               port_1,
                                   const vtss_udp_tcp_t               port_2);
#endif /* VTSS_FEATURE_FILTER_UDP_TCP */

/* Read port counters */
vtss_rc vtss_ll_port_counters_get(uint port_no, vtss_chip_counters_t * counters);

#if defined(VTSS_FEATURE_VSTAX)
/* Setup VStaX for switch */
vtss_rc vtss_ll_vstax_setup_set(const vtss_vstax_setup_t * const setup);

/* Setup VStaX for port */
vtss_rc vtss_ll_vstax_port_setup_set(const vtss_port_no_t                  port_no,
                                     const vtss_vstax_port_setup_t * const setup);
#endif /* VTSS_FEATURE_VSTAX */

#if defined(VTSS_FEATURE_QCL_PORT)
/* Add QCE */
vtss_rc vtss_ll_qce_add(vtss_qcl_id_t    qcl_id,
                        vtss_qce_id_t    qce_id,
                        const vtss_qce_t *qce);

/* Delete QCE */
vtss_rc vtss_ll_qce_del(vtss_qcl_id_t  qcl_id,
                        vtss_qce_id_t  qce_id);
#endif /* VTSS_FEATURE_QCL_PORT */

/* Set aggregation mode */
vtss_rc vtss_ll_aggr_mode_set(const vtss_aggr_mode_t *mode);

/* Enable/disable frame ready interrupt */
vtss_rc vtss_ll_frame_rx_ready_int(vtss_cpu_rx_queue_t queue_no, BOOL enable);

#if (VTSS_CPU_RX_QUEUES>1)
/* Setup Rx queue map */
vtss_rc vtss_ll_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map);
#endif /* VTSS_CPU_RX_QUEUES>1 */

#if defined(VTSS_ARCH_GATWICK) || defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
/* Set Rx queue size */
vtss_rc vtss_ll_cpu_rx_queue_size_set(const vtss_cpu_rx_queue_t queue_no, 
                                      const vtss_cpu_rx_queue_size_t size);
#endif /* VTSS_ARCH_GATWICK/HAWX/SPARX_28 */    

/* Set frame registration */
vtss_rc vtss_ll_frame_reg_set(const vtss_cpu_rx_registration_t *reg);

/* Determine if a frame is ready in the CPU Rx queue */
/* Returns: 0: no frame ready, <0: error, >0: frame ready */
vtss_rc vtss_ll_frame_rx_ready(vtss_cpu_rx_queue_t queue_no);

/* Get frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx(vtss_cpu_rx_queue_t queue_no, vtss_system_frame_header_t *sys_header,
                         uchar *frame, uint maxlength);

/* Discard frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx_discard(vtss_cpu_rx_queue_t queue_no);

/* Transmit frame on port, optionally with tag */
vtss_rc vtss_ll_frame_tx(vtss_port_no_t port_no, const uchar *frame, uint length, 
                         vtss_vid_t vid
#if defined(VTSS_FEATURE_VSTAX)
                         , const vtss_vstax_tx_header_t *vstax
#endif /* VTSS_FEATURE_VSTAX */    
    );

#if defined(VTSS_FEATURE_VSTAX)
vtss_rc vtss_ll_vstax_header_get(const vtss_port_no_t                 port_no,
                                 const vtss_vstax_tx_header_t * const vstax,
                                 uchar * const                        frame);

vtss_rc vtss_ll_vstax_header_put(const uchar * const            frame,
                                 vtss_vstax_rx_header_t * const vstax_header);
#endif /* VTSS_FEATURE_VSTAX */    

/* Set logical port mapping */
vtss_rc vtss_ll_pmap_table_write(vtss_port_no_t physical_port, vtss_port_no_t logical_port);

/* Set learn port mode */
#if defined(VTSS_FEATURE_LEARN_PORT)
vtss_rc vtss_ll_learn_port_mode_set(const vtss_port_no_t      port_no,
                                    vtss_learn_mode_t * const learn_mode);
#endif /* VTSS_FEATURE_LEARN_PORT */ 

#if defined(VTSS_FEATURE_LEARN_SWITCH)
/* Set learn mode */
vtss_rc vtss_ll_learn_mode_set(vtss_learn_mode_t * const learn_mode);
#endif /* VTSS_FEATURE_LEARN_SWITCH */ 

/* Set logical port mapping */
vtss_rc vtss_ll_pmap_table_write(vtss_port_no_t physical_port, vtss_port_no_t logical_port);

/* Set VLAN port mode */
vtss_rc vtss_ll_vlan_port_mode_set(vtss_port_no_t port_no, const vtss_vlan_port_mode_t *vlan_mode);

/* Set VLAN port members */
vtss_rc vtss_ll_vlan_table_write(vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* Set isolated ports */
vtss_rc vtss_ll_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* Set VLAN MSTP instance */
vtss_rc vtss_ll_vlan_table_mstp_set(vtss_vid_t vid, uint msti);

/* Set MSTP state for port and mstp instance */
vtss_rc vtss_ll_mstp_table_write(vtss_port_no_t port_no, vtss_msti_t msti, vtss_mstp_state_t state);

#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
/* Set MAC address age time */
vtss_rc vtss_ll_mac_table_age_time_set(vtss_mac_age_time_t age_time);
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */

/* Age MAC address table */
vtss_rc vtss_ll_mac_table_age(BOOL pgid_age, vtss_pgid_no_t pgid_no, BOOL vid_age, vtss_vid_t vid);

/* Flush MAC address table */
vtss_rc vtss_ll_mac_table_flush(BOOL pgid_age, vtss_pgid_no_t pgid_no, 
                                BOOL vid_age, vtss_vid_t vid);

/* Learn (VID, MAC) */
vtss_rc vtss_ll_mac_table_learn(const vtss_mac_table_entry_t *entry, vtss_pgid_no_t pgid_no);

/* Unlearn (VID, MAC) */
vtss_rc vtss_ll_mac_table_unlearn(const vtss_vid_mac_t *vid_mac);

/* Lookup (VID, MAC) */
vtss_rc vtss_ll_mac_table_lookup(vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no);

/* Direct MAC read */
vtss_rc vtss_ll_mac_table_read(uint index, vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no);

/* Get next */
vtss_rc vtss_ll_mac_table_get_next(const vtss_vid_mac_t *vid_mac, vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no);

/* Get MAC table status */
vtss_rc vtss_ll_mac_table_status_get(vtss_mac_table_status_t *status);

/* Write PGID entry */
vtss_rc vtss_ll_pgid_table_write(vtss_pgid_no_t pgid_no, BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* Write source port entry */
vtss_rc vtss_ll_src_table_write(vtss_port_no_t port_no, BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* Set monitor port for mirroring */
vtss_rc vtss_ll_mirror_port_set(vtss_port_no_t port_no);

/* Enable/disable egress mirroring of port */
vtss_rc vtss_ll_dst_mirror_set(vtss_port_no_t port_no, BOOL enable);

/* Enable/disable ingress mirroring of port */
vtss_rc vtss_ll_src_mirror_set(vtss_port_no_t port_no, BOOL enable);

/* Write aggregation entry */
vtss_rc vtss_ll_aggr_table_write(vtss_ac_no_t ac, BOOL member[VTSS_PORT_ARRAY_SIZE]);

/* Set IP Multicast flooding ports */
vtss_rc vtss_ll_ipmc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

#if defined(VTSS_FEATURE_CPU_RX_REG_MLD_ADV)
vtss_rc vtss_ll_ipv6_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE]);

vtss_rc vtss_ll_ipv6_mc_ctrl_flood_set(const BOOL scope);
#endif /* VTSS_FEATURE_CPU_RX_REG_MLD_ADV */

#if defined(VTSS_FEATURE_ACL)
/* Set policer rate */
vtss_rc vtss_ll_acl_policer_rate_set(vtss_acl_policer_no_t policer_no,
                                     vtss_packet_rate_t    rate);
/* Set default action for port */
vtss_rc vtss_ll_acl_port_action_set(vtss_port_no_t            port_no,
                                    const vtss_acl_action_t * action);

/* Get default action counter for port */
vtss_rc vtss_ll_acl_port_counter_get(const vtss_port_no_t            port_no,
                                     vtss_acl_port_counter_t * const counter);

/* Clear default action counter for port */
vtss_rc vtss_ll_acl_port_counter_clear(const vtss_port_no_t port_no);

/* Set policy number for port */
vtss_rc vtss_ll_acl_policy_no_set(vtss_port_no_t       port_no,
                                  vtss_acl_policy_no_t policy_no);

/* Add ACE */
vtss_rc vtss_ll_ace_add(vtss_ace_id_t      ace_id,
                        const vtss_ace_t * ace);

/* Delete ACE */
vtss_rc vtss_ll_ace_del(vtss_ace_id_t ace_id);

/* Get ACE counter */
vtss_rc vtss_ll_ace_counter_get(vtss_ace_id_t        ace_id,
                                vtss_ace_counter_t * counter);

/* Clear ACE counter */
vtss_rc vtss_ll_ace_counter_clear(vtss_ace_id_t ace_id);
#endif /* VTSS_FEATURE_ACL */

#if defined(VTSS_FEATURE_LAYER3)

/* Set IP forwarding mode */
vtss_rc vtss_ll_ip_forwarding_set(BOOL enable);

/* Add router leg */
vtss_rc vtss_ll_rl_add(vtss_rlid_t new_rlid, const vtss_rl_t *rl);

/* Delete router leg */
vtss_rc vtss_ll_rl_del(vtss_rlid_t rlid);

/* Set VRRP base address */
vtss_rc vtss_ll_vrrp_addr_set(vtss_mac_t mac);

/* Add Virtual Router */
vtss_rc vtss_ll_vrrp_vrid_add(vtss_vrid_t vrid, vtss_rlid_t rlid);

/* Delete Virtual Router */
vtss_rc vtss_ll_vrrp_vrid_del(vtss_vrid_t vrid, vtss_rlid_t rlid);

/* Add IP unicast entry */
vtss_rc vtss_ll_ipuc_add(vtss_ip_t net, vtss_ip_t mask, vtss_ip_t router);

/* Delete IP unicast entry */
vtss_rc vtss_ll_ipuc_del(vtss_ip_t net, vtss_ip_t mask);

/* Add ARP entry */
vtss_rc vtss_ll_arp_add(vtss_ip_t dip, const vtss_arp_t *arp);

/* Delete ARP entry */
vtss_rc vtss_ll_arp_del(vtss_ip_t dip);

/* Add IP multicast entry */
vtss_rc vtss_ll_ipmc_add(vtss_ip_t sip, vtss_ip_t dip, const vtss_ipmc_t *ipmc);

/* Delete IP multicast entry */
vtss_rc vtss_ll_ipmc_del(vtss_ip_t sip, vtss_ip_t dip);

/* Enable/disable security table */
vtss_rc vtss_ll_sec_set(BOOL enable);

/* Write security entry */
vtss_rc vtss_ll_sec_table_write(vtss_rlid_t irlid, vtss_rlid_t erlid, BOOL enable);

/* Get IP counters */
vtss_rc vtss_ll_ip_counters_get(vtss_ip_counters_t *counters);

/* Get Router Leg counters */
vtss_rc vtss_ll_rl_counters_get(vtss_rlid_t rlid, vtss_rl_counters_t *counters);

/* Clear Router Leg counters */
vtss_rc vtss_ll_rl_counters_clear(vtss_rlid_t rlid);

#endif /* VTSS_FEATURE_LAYER3 */

/* PI/SI register read */
vtss_rc vtss_ll_register_read(ulong reg, ulong *value);
vtss_rc ht_rd_xx(uint blk, uint sub, uint reg, ulong *value);
vtss_rc ht_rd_xx(uint blk, uint sub, uint reg, ulong *value);

/* PI/SI register write */
vtss_rc vtss_ll_register_write(ulong reg, ulong value);

/* Get chip ID and revision */
vtss_rc vtss_ll_chipid_get(vtss_chipid_t *chipid);

/* Optimization function called every second */
vtss_rc vtss_ll_optimize_1sec(void);

/* Optimization function called every 100th millisecond */
vtss_rc vtss_ll_optimize_100msec(void);

/* Set GPIO direction */
vtss_rc vtss_ll_gpio_direction_set(vtss_gpio_no_t gpio_no, BOOL output);

/* Read GPIO input pin */
vtss_rc vtss_ll_gpio_input_read(vtss_gpio_no_t gpio_no, BOOL *value);

/* Write GPIO output pin */
vtss_rc vtss_ll_gpio_output_write(vtss_gpio_no_t gpio_no, BOOL value);

#if defined(VTSS_FEATURE_SERIAL_LED)
/* Setup serial LED mode */
vtss_rc vtss_ll_serial_led_set(const vtss_led_port_t port, 
                               const vtss_led_mode_t mode[3]);
#endif /* VTSS_FEATURE_SERIAL_LED */

/* Initialize low level layer */
vtss_rc vtss_ll_init(const vtss_init_setup_t *setup);

#endif /* _VTSS_LL_H_ */
