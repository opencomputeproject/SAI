/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_sparx.c,v 1.225 2007/10/29 13:41:30 cpj Exp $
 $Revision: 1.225 $

*/

#define VTSS_TRACE_LAYER 2
#define VTSS_TRACE_FILE "ll"

/* Standard headers */
#include <string.h>

/* API public headers */
#include "vtss_switch_api.h"

/* API private headers */
#include "vtss_state.h"
#include "vtss_cil.h"
#include "vtss_sparx_reg.h"
#include "heathrow_qs.h"
#if defined(VTSS_ARCH_SPARX_G8)
#include "vtss_sparx_g5_g8_qs.h"
#endif /* VTSS_ARCH_SPARX_G8 */

/* ================================================================= *
 *  Port MAC constants and types
 * ================================================================= */

typedef enum _ht_tx_clock_select_t {
    HT_TX_CLOCK_OFF      = 0,
    HT_TX_CLOCK_GIGA     = 1,
    HT_TX_CLOCK_100M     = 2,
    HT_TX_CLOCK_10M      = 3,
    HT_TX_CLOCK_MISC     = 4 
} ht_tx_clock_select_t;

/* SparX-G16/G24 revision B tail drop in MISCFIFO bit 2 */
#if defined(VTSS_ARCH_SPARX_G24)
#define MISCFIFO_TAILDROP (1<<2)
#else
#define MISCFIFO_TAILDROP (0<<2)
#endif /* VTSS_ARCH_SPARX_G24 */

/* Frame ageing timer */
#if defined(VTSS_ARCH_SPARX_28)
#define HT_TIMECMP_DEFAULT 0x3ffffff
#else
#define HT_TIMECMP_DEFAULT 0x3b9aca0
#endif /* VTSS_ARCH_SPARX_28 */

/* ================================================================= *
 * ================================================================= *
 * = Helpers ======================================================= *
 * ================================================================= *
 * ================================================================= */

#if VTSS_OPT_NICIO
#define HT_MII_PORT_NO                  (VTSS_PORTS + 1)
#define HT_IS_NOT_MII_PORT(port_no)     (port_no != HT_MII_PORT_NO)
#define HT_CHIP_PORT(port_no)           (HT_IS_NOT_MII_PORT(port_no) ? vtss_api_state->port_map.chip_port[port_no] : VTSS_MII_PORT_NO)
static const vtss_port_setup_t ht_mii_port_setup = {
    {
        VTSS_PORT_INTERFACE_SGMII,
        VTSS_SPEED_100M
    },
    0,                          /* powerdown */
    1,                          /* fdx */
    {                           /* Flowcontrol */
        0,                      /* Obey pause frames */
        0,                      /* Generate pause frames */
        VTSS_MAC_NULL           /* SMAC in pause frames */
    },
    VTSS_MAXFRAMELENGTH_STANDARD,/* Max frame length */
    {                           /* Frame gaps */
        VTSS_FRAME_GAP_DEFAULT, /* Hdx gap 1 */
        VTSS_FRAME_GAP_DEFAULT, /* Hdx gap 2 */
        VTSS_FRAME_GAP_DEFAULT, /* Fdx gap */
    }
};
#else
#define HT_IS_NOT_MII_PORT(port_no)     (1)
#define HT_CHIP_PORT(port_no)           (vtss_api_state->port_map.chip_port[port_no])
#endif /* VTSS_OPT_NICIO */

#if VTSS_OPT_INT_AGGR
/* Determine pseudo port number corresponding to internally aggregated
   chip port */
static vtss_port_no_t vtss_int_aggr_port_no(uint port_on_chip)
{
    if (port_on_chip == VTSS_CHIP_PORT_AGGR_0)
        return VTSS_PORT_NO_AGGR_0;
    if (port_on_chip == VTSS_CHIP_PORT_AGGR_1)
        return VTSS_PORT_NO_AGGR_1;

    /* Chip port not internally aggregated */
    return 0;
}
#endif /* VTSS_OPT_INT_AGGR */

/* Convert from chip port bitfield to vtss_port_no bitfield. */
static ulong vtss_port_bitfield(const ulong chip_port_bitfield)
{
    vtss_port_no_t      port_no;
    ulong               bitfield=0;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (chip_port_bitfield & (1<<HT_CHIP_PORT(port_no))) {
            bitfield |= 1<<port_no;
        }
    }
    return bitfield;
}

/* Convert from vtss_port_no list to chip port bitfield, */
static ulong vtss_chip_port_bitfield(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t      port_no;
    uint                port_on_chip;
    ulong               bitfield=0;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (member[port_no]) {
            if (vtss_api_state->port_map.vtss_port_unused[port_no]) {
                VTSS_E(("Unmapped port enabled: %d",port_no));
            } else {
                port_on_chip = HT_CHIP_PORT(port_no);
                bitfield |= (1 << port_on_chip);
#if VTSS_OPT_INT_AGGR
                /* Enable internally aggregated port */
                if (vtss_int_aggr_port_no(port_on_chip) != 0)
                    bitfield |= (1 << (port_on_chip+1));
#endif /* VTSS_OPT_INT_AGGR */
            }
        }
    }
    return bitfield;
}

/* Convert from vtss_pgid_no to destination index on chip */
static uint vtss_chip_pgid(const vtss_pgid_no_t pgid_no)
{
    if (pgid_no<VTSS_PGID_UNICAST_END) {
        return HT_CHIP_PORT(pgid_no);
    } else {
        return pgid_no-VTSS_PGID_UNICAST_END+VTSS_CHIP_PORTS;
    }
}

/* Convert from destination index on chip to vtss_pgid_no */
static vtss_pgid_no_t vtss_pgid(const uint chip_pgid)
{
    if (chip_pgid<VTSS_CHIP_PORTS) {
        return vtss_api_state->port_map.vtss_port[chip_pgid];
    } else {
        return VTSS_PGID_UNICAST_END+chip_pgid-VTSS_CHIP_PORTS;
    }
}

/* ================================================================= *
 * ================================================================= *
 * = Register Access =============================================== *
 * ================================================================= *
 * ================================================================= */

#define HT_RD(blk, sub, reg, value) \
{ \
    vtss_rc rc; \
    if ((rc = ht_rd_wr(B_##blk, sub, R_##blk##_##reg, value, 0)) < 0) \
        return rc; \
}

#define HT_WR(blk, sub, reg, value) \
{ \
    vtss_rc rc; \
    ulong   val = value; \
    if ((rc = ht_rd_wr(B_##blk, sub, R_##blk##_##reg, &val, 1)) < 0) \
        return rc; \
}

#define HT_WRM(blk, sub, reg, value, mask) \
{ \
    vtss_rc rc; \
    if ((rc = ht_wrm(B_##blk, sub, R_##blk##_##reg, value, mask)) < 0) \
        return rc; \
}

#define HT_RDF(blk, sub, reg, offset, mask, value) \
{ \
    vtss_rc rc; \
    if ((rc = ht_rdf(B_##blk, sub, R_##blk##_##reg, offset, mask, value)) < 0) \
        return rc; \
}

#define HT_WRF(blk, sub, reg, offset, mask, value) \
{ \
    vtss_rc rc; \
    if ((rc = ht_wrf(B_##blk, sub, R_##blk##_##reg, offset, mask, value)) < 0) \
        return rc; \
}

/* Read target register using current CPU interface */
static vtss_rc ht_rd_wr(uint blk, uint sub, uint reg, ulong *value, BOOL write)
{
    vtss_rc rc;
    BOOL    error;

    switch (blk) {
    case B_PORT:
        /* By default, it is an error if the sub block is not included in chip port mask */
        error = ((sub > VTSS_CHIP_PORTS) ||
                 (VTSS_CHIP_PORTMASK & (1<<sub)) == 0);
#if defined(VTSS_ARCH_SPARX_G24)
        /* SparX-G16/G24: MII port 24 is allowed */
        if (sub == VTSS_MII_PORT_NO)
            error = 0; 
#endif /* VTSS_ARCH_SPARX_G24 */        
#if defined(VTSS_ARCH_SPARX_28)
        if (sub == VTSS_CHIP_PORT_CPU)
            error = 0;
#endif /* VTSS_ARCH_SPARX_28 */        
        if (error) {
            break;
        }
        if (sub >= 16) {
            blk = B_PORT_HI;
            sub -= 16;
        }
        break;
    case B_MIIM: /* B_MEMINIT/B_ACL/B_VAUI */
#if defined(VTSS_ARCH_SPARX_28)
#if defined(VTSS_FEATURE_VAUI)
        error = (sub > S_VAUI);
#else
        error = (sub > S_ACL);
#endif /* VTSS_FEATURE_VAUI */
#else
        error = (sub > S_MEMINIT);
#endif /* VTSS_ARCH_SPARX_28 */
        break;
    case B_CAPTURE:
        error = 0;
        break;
    case B_ANALYZER:
    case B_ARBITER:
    case B_SYSTEM:
        error = (sub != 0);
        break;
    case B_PORT_HI: /* vtss_ll_register_read/write may access this directly */
        error = 0;
        break;
    default:
        error = 1;
        break;
    }

    if (error) {
        VTSS_E(("illegal access, blk: 0x%02x, sub: 0x%02x, reg: 0x%02x", blk, sub, reg));
        return VTSS_INVALID_PARAMETER;
    }

    if (vtss_api_state->init_setup.use_cpu_si)
        rc = (write ? vtss_io_si_wr(blk, sub, reg, *value) : 
              vtss_io_si_rd(blk, sub, reg, value));
    else 
        rc = (write ? vtss_io_pi_wr(blk, sub, reg, *value) : 
              vtss_io_pi_rd(blk, sub, reg, value));

    if (vtss_api_state->debug_read_write) {
       VTSS_D(("%s blk: %d, sub: %2d, reg: 0x%02x, value: 0x%08lx", 
                write ? "write" : "read ", blk, sub, reg, *value));
    }

    return rc;
}

vtss_rc ht_rd_xx(uint blk, uint sub, uint reg, ulong *value)
{
    return ht_rd_wr(blk, sub, reg, value, 0);
}

/* Read target register using current CPU interface */
static vtss_rc ht_rd(uint blk, uint sub, uint reg, ulong *value)
{
    return ht_rd_wr(blk, sub, reg, value, 0);
}

vtss_rc ht_wr_xx(uint blk, uint sub, uint reg, ulong value)
{
	return ht_rd_wr(blk, sub, reg, &value, 1);
}

/* Write target register using current CPU interface */
static vtss_rc ht_wr(uint blk, uint sub, uint reg, ulong value)
{
    return ht_rd_wr(blk, sub, reg, &value, 1);
}

/* Read-modify-write target register using current CPU interface */
static vtss_rc ht_wrm(uint blk, uint sub, uint reg, ulong value, ulong mask)
{
    vtss_rc rc;
    ulong   val;

    if ((rc = ht_rd_wr(blk, sub, reg, &val, 0))>=0) {
        val = ((val & ~mask) | (value & mask));
        rc = ht_rd_wr(blk, sub, reg, &val, 1);
    }
    return rc;
}

/* Read target register field using current CPU interface */
static vtss_rc ht_rdf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong *value)
{
    vtss_rc rc;
    
    rc = ht_rd_wr(blk, sub, reg, value, 0);
    *value = ((*value >> offset) & mask);
    return rc;
}

/* Read-modify-write target register field using current CPU interface */
static vtss_rc ht_wrf(uint blk, uint sub, uint reg, uint offset, ulong mask, ulong value)
{
    return ht_wrm(blk, sub, reg, value<<offset, mask<<offset);
}

/* ================================================================= *
 * ================================================================= *
 * = MII Management ================================================ *
 * ================================================================= *
 * ================================================================= */

/* returns (ushort) result or (long) <0 */
static vtss_rc ht_phy_readwrite(BOOL do_write, uint miim_controller, 
                                uint phy_addr, uint phy_reg, ushort *value)
{
    ulong data;

    /* Enqueue MIIM operation to be executed */
    HT_WR(MIIM, miim_controller, MIIMCMD,
          ((do_write ? 0 : 1)<<26) | (phy_addr<<21) | (phy_reg<<16) | *value);

    /* Wait for MIIM operation to finish */
    while (1) {
        HT_RD(MIIM, miim_controller, MIIMSTAT, &data);
        if (!(data & 0xF)) /* Include undocumented "pending" bit */
            break;
    }
    if (!do_write) {
        HT_RD(MIIM, miim_controller, MIIMDATA, &data);
        if (data & (1<<16))
            return VTSS_PHY_READ_ERROR;
        *value = (data & 0xFFFF);
    }
    return VTSS_OK;
}

/* Read from the phy register */
vtss_rc vtss_ll_phy_read(uint miim_controller, uint phy_addr, uint phy_reg, ushort *value)
{
    return ht_phy_readwrite(0, miim_controller, phy_addr, phy_reg, value);
}

/* Write to the phy register */
vtss_rc vtss_ll_phy_write(uint miim_controller, uint phy_addr, uint phy_reg, ushort value)
{
    return ht_phy_readwrite(1, miim_controller, phy_addr, phy_reg, &value);
}

#if defined(VTSS_ARCH_SPARX_G24) 
static vtss_rc use_rxclk_as_txclk(uint port_on_chip, const BOOL enable)
{
    ulong dev;

    if (port_on_chip < 8 || port_on_chip > 15) { /* External ports */
        dev = (port_on_chip < 8 ? port_on_chip : (port_on_chip - 8));
        dev <<= 19;
        if (enable) {
            HT_WR(SYSTEM, 0, SGMII_TR_DBG, 0x6A8000EF | dev);
            VTSS_NSLEEP(VTSS_T_RESET);
            HT_WR(SYSTEM, 0, SGMII_TR_DBG, 0x6A820010 | dev);
        }
        else
            HT_WR(SYSTEM, 0, SGMII_TR_DBG, 0x6A820000 | dev);
    }
    return VTSS_OK;
}

static vtss_rc adjust_sgmii_sample_ctrl(uint port_on_chip)
{
    ulong dev;
    ulong val;
    uint  wait_attempt;
    
    if (port_on_chip < 8 || port_on_chip > 15) { /* External ports */
        dev = (port_on_chip < 8 ? port_on_chip : (port_on_chip - 8));
        dev <<= 19;
        HT_WRM(SYSTEM, 0, SGMII_TR_DBG, 0x0283003D | dev, ~0xfc000000);
        /* Wait until completed */
        for (wait_attempt=0; wait_attempt<1000; wait_attempt++) {
            HT_RD(SYSTEM, 0, SGMII_TR_DBG, &val);
            if ((val & 0x02000000) == 0)
                break;
        }
        if(wait_attempt >= 1000)
            VTSS_D(("SGMII sample_ctrl setting error for port: %d",port_on_chip));
    }
    return VTSS_OK;
}
#endif /* VTSS_ARCH_SPARX_G24 */

/* ================================================================= *
 * ================================================================= *
 * = TBI =========================================================== *
 * ================================================================= *
 * ================================================================= */

#ifdef VTSS_FEATURE_TBI

static vtss_rc ht_tbictrl_wrm(uint port_on_chip, ulong value, ulong mask)
{
#if defined(VTSS_ARCH_STAPLEFORD)
    ulong val;

    HT_RD(PORT, port_on_chip, TBICTRL, &val);
    val = ((val & ~mask) | (value & mask));
    HT_WR(PORT, port_on_chip, TBICTRL, val & ~(1<<31));
    HT_WR(PORT, port_on_chip, TBICTRL, val |  (1<<31));
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    HT_WRM(PORT, port_on_chip, PCSCTRL, value, mask);
#endif /* VTSS_ARCH_HAWX/SPARX */

    if (value & mask & (1<<16)) {
        /* Disable ANEG restart bit again */
        VTSS_RC(ht_tbictrl_wrm(port_on_chip, 0, 1<<16));
    }

    return VTSS_OK;
}

/* Check if TBI is enabled */
vtss_rc vtss_ll_port_tbi_enabled(uint port_no, BOOL *enabled)
{
    vtss_port_interface_t type = vtss_api_state->setup[port_no].interface_mode.interface_type;

#if defined(VTSS_ARCH_STAPLEFORD)
    *enabled = (type == VTSS_PORT_INTERFACE_TBI || type == VTSS_PORT_INTERFACE_RTBI);
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    *enabled = (type == VTSS_PORT_INTERFACE_SERDES || type == VTSS_PORT_INTERFACE_LOOPBACK);
#endif /* VTSS_ARCH_HAWX/SPARX */
    return VTSS_OK;
}

/* Check if TBI autoneg is enabled */
vtss_rc vtss_ll_port_tbi_autoneg_enabled(uint port_no, BOOL *enabled)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong value;

#if defined(VTSS_ARCH_STAPLEFORD)
    HT_RDF(PORT, port_on_chip, TBICTRL, 17, 0x1, &value);
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    HT_RDF(PORT, port_on_chip, PCSCTRL, 17, 0x1, &value);
#endif /* VTSS_ARCH_HAWX/SPARX */

    *enabled = MAKEBOOL01(value);
    return VTSS_OK;
}

/* Get word used in TBI autoneg */
vtss_rc vtss_ll_port_tbi_get_aneg_advertisement(uint port_no, 
                                                vtss_autoneg_1000base_x_advertisement_t * adv)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong value;

#if defined(VTSS_ARCH_STAPLEFORD)
    HT_RD(PORT, port_on_chip, TBICTRL, &value);
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    HT_RD(PORT, port_on_chip, PCSCTRL, &value);
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    adv->fdx              = MAKEBOOL01(value & (1<< 5));
    adv->hdx              = MAKEBOOL01(value & (1<< 6));
    adv->symmetric_pause  = MAKEBOOL01(value & (1<< 7));
    adv->asymmetric_pause = MAKEBOOL01(value & (1<< 8));
    adv->remote_fault     = (value & (0x3<<12)) >> 12;
    adv->next_page        = MAKEBOOL01(value & (1<<15));
    adv->acknowledge      = MAKEBOOL01(value & (1<<14));

    return VTSS_OK;
}

/* Enable/Disable TBI autoneg */
vtss_rc vtss_ll_port_tbi_aneg_control(const vtss_port_no_t port_no,
                                      const vtss_tbi_autoneg_control_t * const control)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong value;
    const vtss_autoneg_1000base_x_advertisement_t *adv = &control->advertisement;
    
    value = ((1<<16) | /* Always restart autonegotiation */
             ((adv->next_page ? 1 : 0)<<15) |
             ((adv->acknowledge ? 1 : 0)<<14) |
             (adv->remote_fault<<12) |
             ((adv->asymmetric_pause ? 1 : 0)<<8) |
             ((adv->symmetric_pause ? 1 : 0)<<7) |
             ((adv->hdx ? 1 : 0)<<6) |
             ((adv->fdx ? 1 : 0)<<5));
    
    if (!control->enable) {
        /* Restart aneg before disabling it */
        VTSS_RC(ht_tbictrl_wrm(port_on_chip, (1<<17) | value, 0x3FFFF));
    }
    
    VTSS_RC(ht_tbictrl_wrm(port_on_chip, ((control->enable ? 1 : 0)<<17) | value, 0x3FFFF));
    
    return VTSS_OK;
}

/* Restart TBI autoneg */
vtss_rc vtss_ll_port_tbi_aneg_restart(uint port_no)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong mask = (1<<16);

    VTSS_RC(ht_tbictrl_wrm(port_on_chip, mask, mask));
    
    return VTSS_OK;
}

/* Get TBI status */
vtss_rc vtss_ll_port_tbi_status_get(uint port_no, vtss_tbi_status_t *status)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong value;

    if (vtss_api_state->setup[port_no].powerdown) {
        memset(status,0,sizeof(vtss_tbi_status_t));
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_IDLE;
        return VTSS_OK;
    }

#if defined(VTSS_ARCH_STAPLEFORD)
    HT_RD(PORT, port_on_chip, TBISTAT, &value);
#endif /* VTSS_ARCH_STAPLEFORD */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    HT_RD(PORT, port_on_chip, PCSSTAT, &value);
#endif /* VTSS_ARCH_HAWX/SPARX_28 */

    status->link_status = MAKEBOOL01(value & (1<<20));
    status->link_down_counter = (value>>24) & 0xFF;
    switch ((value>>18) & 0x3) {
    case 0x0: 
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_IDLE;  
        break;
    case 0x1: 
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_CONFIG;
        break;
    case 0x3: 
    default:  
        status->autoneg.pcs_state = VTSS_TBI_PCS_STATE_DATA;  
        break;
    }
    status->autoneg.priority_resolution =                   MAKEBOOL01(value & (1<<17));
    status->autoneg.complete =                              MAKEBOOL01(value & (1<<16));
    status->autoneg.partner_advertisement.fdx =             MAKEBOOL01(value & (1<<5));
    status->autoneg.partner_advertisement.hdx =             MAKEBOOL01(value & (1<<6));
    status->autoneg.partner_advertisement.symmetric_pause = MAKEBOOL01(value & (1<<7));
    status->autoneg.partner_advertisement.asymmetric_pause =MAKEBOOL01(value & (1<<8));
    status->autoneg.partner_advertisement.remote_fault =    (value>>12)&0x3;
    status->autoneg.partner_advertisement.acknowledge =     MAKEBOOL01(value & (1<<14));
    status->autoneg.partner_advertisement.next_page =       MAKEBOOL01(value & (1<<15));

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_TBI */

/* ================================================================= *
 *  Function Headers
 * ================================================================= */

#if defined(VTSS_ARCH_STAPLEFORD)
static vtss_rc ht_opt_post_fc_port_setup(vtss_port_no_t port_no);
#if (VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1)
static vtss_rc ht_opt_port_shaper_adjust(vtss_port_no_t port_no);
#endif
#endif /* VTSS_ARCH_STAPLEFORD */

/* ================================================================= *
 * ================================================================= *
 * = Frame Arbiter ================================================= *
 * ================================================================= *
 * ================================================================= */

static vtss_rc ht_arbiter_empty_allports(BOOL *empty)
{
    ulong value;

    HT_RD(ARBITER, 0, ARBEMPTY, &value);
    *empty = (vtss_port_bitfield(value) == ((1<<VTSS_PORTS)-1)<<1);
    return VTSS_OK; 
}

/* ================================================================= *
 * ================================================================= *
 * = Port Queues =================================================== *
 * ================================================================= *
 * ================================================================= */

static vtss_rc ht_port_queue_enable(vtss_port_no_t port_no, BOOL enable) 
{
    uint port_on_chip = HT_CHIP_PORT(port_no);

    VTSS_D(("port_on_chip: %d, enable: %d", port_on_chip, enable));

    /* Enable/disable Arbiter discard */
    HT_WRF(ARBITER, 0, ARBDISC, port_on_chip, 0x1, enable ? 0 : 1);

    /* Enable/disable MAC Rx */
    HT_WRF(PORT, port_on_chip, MAC_CFG, 16, 0x1, enable ? 1 : 0);

#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    if (!enable) {
        /* Drop everything in the FIFOs */
        HT_WR(PORT, port_on_chip, DROPCFG, (0<<30) | (0<<24) | (0<<16) | (0<<8) | (0<<0));
        HT_WR(PORT, port_on_chip, POOLCFG, (0<<31) | (0<<30) | (0<<24) | (0<<16) | (0<<14) | (0<<8) | (0<<0));
    }
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */

    /* Enable/disable MAC Tx */
    HT_WRF(PORT, port_on_chip, MAC_CFG, 28, 0x1, enable ? 1 : 0);

    return VTSS_OK;
}

/* Set STP learn mode */
static vtss_rc ht_port_learn_set(vtss_port_no_t port_no)
{
    uint             port_on_chip = HT_CHIP_PORT(port_no);
    vtss_stp_state_t stp_state = vtss_api_state->stp_state[port_no];
    BOOL             learn;

    /* Setup STP learning state */
    learn = (stp_state == VTSS_STP_STATE_LEARNING ||
             stp_state == VTSS_STP_STATE_FORWARDING ||
             stp_state == VTSS_STP_STATE_ENABLED);

    HT_WRF(ANALYZER, 0, LERNMASK, port_on_chip, 0x1, learn ? 1 : 0);

#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(port_on_chip)) != 0) {
        /* Setup STP learning state for aggregated port */
        HT_WRF(ANALYZER, 0, LERNMASK, HT_CHIP_PORT(port_no), 0x1, learn ? 1 : 0);
    }
#endif /* VTSS_OPT_INT_AGGR */

    return VTSS_OK;
}

/* Enable or disable and flush port queue systems */
vtss_rc vtss_ll_port_queue_enable(vtss_port_no_t port_no, BOOL enable)
{
    /* Enable/disable queues */
    VTSS_RC(ht_port_queue_enable(port_no, enable));

    return ht_port_learn_set(port_no);
}

/* Setup water marks, drop levels, etc for port */
vtss_rc vtss_ll_port_queue_setup(vtss_port_no_t port_no)
{
    vtss_port_setup_t *setup = &vtss_api_state->setup[port_no];
    uint              port_on_chip = HT_CHIP_PORT(port_no);
    uchar             *mac;
#if defined(VTSS_ARCH_STAPLEFORD)
    /* Currently only one size of jumbo frames is supported */
    BOOL              jumbo9216 = (setup->maxframelength > 1522);
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED)
    BOOL              jumbo9600 = (setup->maxframelength > 9216);
    BOOL              jumbo9216 = (!jumbo9600 && setup->maxframelength > 1522);
#endif /* VTSS_ARCH_STANSTED */
    BOOL              zero_pause_enable;
    ushort            pause_value;
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    BOOL              wfq = 0;
    enum {
        VTSS_NORM_SQ_DROP,
        VTSS_NORM_WFQ_DROP,
        VTSS_JUMBO_SQ_DROP,
        VTSS_JUMBO_WFQ_DROP,
        VTSS_NORM_SQ_FC,
        /* not used: VTSS_NORM_WFQ_FC, */
        VTSS_JUMBO_SQ_FC
        /* not used: VTSS_JUMBO_WFQ_FC */
    } mode;

#if defined(VTSS_FEATURE_QOS_WFQ_SWITCH)
    wfq = vtss_api_state->qos_setup.weighted_fairness_queueing;
#endif /* VTSS_FEATURE_QOS_WFQ_SWITCH */

#if defined(VTSS_FEATURE_QOS_WFQ_PORT)
    wfq = vtss_api_state->wfq;
#endif /* VTSS_FEATURE_QOS_WFQ_PORT */

    if (setup->flowcontrol.generate) {
        /* Flow control mode */
        if (setup->maxframelength<=VTSS_MAXFRAMELENGTH_TAGGED) {
            mode = VTSS_NORM_SQ_FC;
        } else {
            mode = VTSS_JUMBO_SQ_FC;
        }
    } else {
        /* Drop mode */
        if (setup->maxframelength<=VTSS_MAXFRAMELENGTH_TAGGED) {
            mode = (wfq ? VTSS_NORM_WFQ_DROP : VTSS_NORM_SQ_DROP);
        } else {
            mode = (wfq ? VTSS_JUMBO_WFQ_DROP : VTSS_JUMBO_SQ_DROP);
        }
    }
#endif /* VTSS_ARCH_HAWX/SPARX */

#if defined(VTSS_ARCH_STAPLEFORD)
    zero_pause_enable = 0;
    pause_value = ((setup->flowcontrol.generate && setup->fdx) ? 
                   (jumbo9216 ? 0xFF : 
                    (setup->interface_mode.speed == VTSS_SPEED_1G ? 0x60 : 0x45)) : 
                   0);
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED)
    zero_pause_enable = (setup->flowcontrol.generate ? 1 : 0);
    pause_value = (setup->flowcontrol.generate ? 0x32 : 0);
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_HAWX)
    zero_pause_enable = 0;
    pause_value = 0;
    switch (mode) {
        case VTSS_NORM_SQ_DROP: 
            zero_pause_enable = VTSS_NORM_8S_DROP_ZEROPAUSE; 
            pause_value = VTSS_NORM_8S_DROP_PAUSEVALUE; 
            break;
        case VTSS_NORM_WFQ_DROP: 
            zero_pause_enable = VTSS_NORM_8W_DROP_ZEROPAUSE; 
            pause_value = VTSS_NORM_8W_DROP_PAUSEVALUE; 
            break;
        case VTSS_JUMBO_SQ_DROP: 
            zero_pause_enable = VTSS_9600_8S_DROP_ZEROPAUSE; 
            pause_value = VTSS_9600_8S_DROP_PAUSEVALUE; 
            break;
        case VTSS_JUMBO_WFQ_DROP: 
            zero_pause_enable = VTSS_9600_8W_DROP_ZEROPAUSE; 
            pause_value = VTSS_9600_8W_DROP_PAUSEVALUE; 
            break;
        case VTSS_NORM_SQ_FC:   
            zero_pause_enable = VTSS_NORM_8S_FC_ZEROPAUSE;   
            pause_value = VTSS_NORM_8S_FC_PAUSEVALUE;   
            break;
        case VTSS_JUMBO_SQ_FC:   
            zero_pause_enable = VTSS_9600_8S_FC_ZEROPAUSE;   
            pause_value = VTSS_9600_8S_FC_PAUSEVALUE;   
            break;
    }
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    switch (mode) {
    case VTSS_NORM_SQ_DROP: 
        zero_pause_enable = VTSS_NORM_4S_DROP_ZEROPAUSE; 
        pause_value = VTSS_NORM_4S_DROP_PAUSEVALUE; 
        break;
    case VTSS_NORM_WFQ_DROP: 
        zero_pause_enable = VTSS_NORM_4W_DROP_ZEROPAUSE; 
        pause_value = VTSS_NORM_4W_DROP_PAUSEVALUE; 
        break;
    case VTSS_JUMBO_SQ_DROP: 
        zero_pause_enable = VTSS_9600_4S_DROP_ZEROPAUSE; 
        pause_value = VTSS_9600_4S_DROP_PAUSEVALUE; 
        break;
    case VTSS_JUMBO_WFQ_DROP: 
        zero_pause_enable = VTSS_9600_4W_DROP_ZEROPAUSE; 
        pause_value = VTSS_9600_4W_DROP_PAUSEVALUE; 
        break;
    case VTSS_NORM_SQ_FC:   
        zero_pause_enable = VTSS_NORM_4S_FC_ZEROPAUSE;   
        pause_value = VTSS_NORM_4S_FC_PAUSEVALUE;   
        break;
    case VTSS_JUMBO_SQ_FC:   
        zero_pause_enable = VTSS_9600_4S_FC_ZEROPAUSE;   
        pause_value = VTSS_9600_4S_FC_PAUSEVALUE;   
        break;
    default:
        VTSS_E(("Unknown mode: %d",mode));
        zero_pause_enable = 0;
        pause_value = 0;
        break;
    }
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_SPARX_28)
    switch (mode) {
    case VTSS_NORM_SQ_DROP: 
    case VTSS_JUMBO_SQ_DROP: 
        zero_pause_enable = VTSS_NORM_4S_DROP_ZEROPAUSE; 
        pause_value = VTSS_NORM_4S_DROP_PAUSEVALUE; 
        break;
    case VTSS_NORM_WFQ_DROP: 
    case VTSS_JUMBO_WFQ_DROP: 
        zero_pause_enable = VTSS_NORM_4W_DROP_ZEROPAUSE; 
        pause_value = VTSS_NORM_4W_DROP_PAUSEVALUE; 
        break;
    case VTSS_NORM_SQ_FC:   
    case VTSS_JUMBO_SQ_FC:   
        zero_pause_enable = VTSS_NORM_4S_FC_ZEROPAUSE;   
        pause_value = VTSS_NORM_4S_FC_PAUSEVALUE;   
        break;
    default:
        VTSS_E(("Unknown mode: %d",mode));
        zero_pause_enable = 0;
        pause_value = 0;
        break;
    }
#endif /* VTSS_ARCH_SPARX_28 */

    /* Setup flow control registers */
    mac = &setup->flowcontrol.smac.addr[0];
    HT_WR(PORT, port_on_chip, FCMACHI, (mac[0]<<16) | (mac[1]<<8) | mac[2]);
    HT_WR(PORT, port_on_chip, FCMACLO, (mac[3]<<16) | (mac[4]<<8) | mac[5]);
    HT_WR(PORT, port_on_chip, FCCONF,
          ((zero_pause_enable ? 1 : 0)<<17) | 
          ((setup->flowcontrol.obey ? 1 : 0)<<16) | 
          (pause_value<<0));
    
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    {
        uint early_tx_lvl, eg_drop_low, eg_drop_all, in_drop_low, in_drop_all; /* DROPCFG */
        uint eg_low, eg_high, in_fc, in_low, in_high;                          /* POOLCFG */
#if defined(VTSS_ARCH_STANSTED)
        uint sb_adjust;
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_STAPLEFORD)
        BOOL fe = (setup->interface_mode.speed != VTSS_SPEED_1G);
        if (!setup->flowcontrol.generate) {
            if (!jumbo9216) {
                /* Drop mode, normal frame size */
                early_tx_lvl = 0;
                eg_drop_low  = (vtss_api_state->prios==1 ?  0 : 42);
                eg_drop_all  = 47;
                in_drop_low  = (vtss_api_state->prios==1 ?  0 : 45);
                in_drop_all  = 50;
                eg_low       = 32;
                eg_high      = 32;
                in_fc        = 0;
                in_low       = 40;
                in_high      = 40;
            } else {
                /* Drop mode, jumbo frame size */
                early_tx_lvl = (fe ? 0 : 2);
                eg_drop_low  = 10;
                eg_drop_all  = 41;
                in_drop_low  = 10;
                in_drop_all  = 41;
                eg_low       = 40;
                eg_high      = 40;
                in_fc        = 0;
                in_low       = 12;
                in_high      = 12;
            }
        } else {
            if (!jumbo9216) {
                /* Flow control mode, normal frame size */
                early_tx_lvl = 0;
                eg_drop_low  = (fe ? 22 : 24);
                eg_drop_all  = (fe ? 22 : 24);
                in_drop_low  = (fe ? 38 : 32);
                in_drop_all  = (fe ? 38 : 32);
                eg_low       = (fe ? 20 : 22);
                eg_high      = (fe ? 20 : 22);
                in_fc        = 1;
                in_low       = 0;
                in_high      = (fe ? 20 : 12);
            } else {
                /* Flow control mode, jumbo frame size */
                early_tx_lvl = 0;
                eg_drop_low  = 63;
                eg_drop_all  = 63;
                in_drop_low  = 40;
                in_drop_all  = 40;
                eg_low       = 41;
                eg_high      = 41;
                in_fc        = 1;
                in_low       = 0;
                in_high      = 12;
            }
            VTSS_RC(ht_opt_post_fc_port_setup(port_no));
        }   
#if (VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1)
        /* Design Consideration #1 */
        VTSS_RC(ht_opt_port_shaper_adjust(port_no));
#endif
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED)
        if (!setup->flowcontrol.generate) {
            /* Drop mode */
            early_tx_lvl = 0;
            eg_drop_low  = (jumbo9216 || jumbo9600 || vtss_api_state->prios==1 ? 0 : 23);
            eg_drop_all  = 43;
            in_drop_low  = (jumbo9216 || jumbo9600 || vtss_api_state->prios==1 ? 0 : 30);
            in_drop_all  = 50;
            eg_low       = 15;
            eg_high      = 15;
            in_fc        = 0;
            in_low       = (jumbo9216 || jumbo9600 ? 20 : 40);
            in_high      = (jumbo9216 || jumbo9600 ? 20 : 40);
            sb_adjust    = (jumbo9216 || jumbo9600 || vtss_api_state->prios!=4 ? 0 : 5);
        } else {
            /* Flow control mode */
            early_tx_lvl = 0;
            eg_drop_low  = ((jumbo9216 || jumbo9600) ? 63 : 24);
            eg_drop_all  = ((jumbo9216 || jumbo9600) ? 63 : 24);
            in_drop_low  = (jumbo9600 ? 41 : (jumbo9216 ? 39 : 32));
            in_drop_all  = (jumbo9600 ? 41 : (jumbo9216 ? 39 : 32));
            eg_low       = (jumbo9600 ? 13 : (jumbo9216 ? 15 : 22));
            eg_high      = (jumbo9600 ? 13 : (jumbo9216 ? 15 : 22));
            in_fc        = 1;
            in_low       = 14;
            in_high      = 16;
            sb_adjust    = 0;
        }
        HT_WRM(PORT, port_on_chip, MISCFIFO, sb_adjust<<16, 0x3F<<16);
#endif /* VTSS_ARCH_STANSTED */
        HT_WR(PORT, port_on_chip, DROPCFG,
              (early_tx_lvl<<30) | 
              (eg_drop_low<<24) | 
              (eg_drop_all<<16) | 
              (in_drop_low<<8) |
              (in_drop_all<<0));
        HT_WR(PORT, port_on_chip, POOLCFG,
              (0<<31) |
              (1<<30) |
              (eg_low<<24) |
              (eg_high<<16) |
              (in_fc<<14) |
              (in_low<<8) |
              (in_high<<0));
    }
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */

#if defined(VTSS_ARCH_HAWX)
    {
        ulong mcnf, fwm, wm[8];
        uint  i;

#define MCNF(mode, port_on_chip) \
(((port_on_chip<24 ? VTSS_##mode##_EARLY_TX : VTSS_##mode##_U_EARLY_TX)<<1) | \
 (setup->flowcontrol.generate ? 1 : 0)<<0)

#define FWM(mode, port_on_chip) \
(((port_on_chip<24 ? VTSS_##mode##_FWDP_START : VTSS_##mode##_U_FWDP_START)<<8) | \
 ((port_on_chip<24 ? VTSS_##mode##_FWDP_STOP : VTSS_##mode##_U_FWDP_STOP)<<0))

#define WM(mode, port_on_chip, i) \
(port_on_chip<24 ? \
 (VTSS_##mode##_EMIN##i<<24 | VTSS_##mode##_EMAX##i<<16 | \
  VTSS_##mode##_IMIN##i<<8 | VTSS_##mode##_IMAX##i<<0) : \
 (VTSS_##mode##_U_EMIN##i<<24 | VTSS_##mode##_U_EMAX##i<<16 | \
  VTSS_##mode##_U_IMIN##i<<8 | VTSS_##mode##_U_IMAX##i<<0))
            
        switch (mode) {
        case VTSS_NORM_SQ_DROP:
            mcnf  = MCNF(NORM_8S_DROP, port_on_chip);
            fwm   = FWM(NORM_8S_DROP, port_on_chip);
            wm[0] = WM(NORM_8S_DROP, port_on_chip, 0);
            wm[1] = WM(NORM_8S_DROP, port_on_chip, 1);
            wm[2] = WM(NORM_8S_DROP, port_on_chip, 2);
            wm[3] = WM(NORM_8S_DROP, port_on_chip, 3);
            wm[4] = WM(NORM_8S_DROP, port_on_chip, 4);
            wm[5] = WM(NORM_8S_DROP, port_on_chip, 5);
            wm[6] = WM(NORM_8S_DROP, port_on_chip, 6);
            wm[7] = WM(NORM_8S_DROP, port_on_chip, 7);
            break;
        case VTSS_NORM_WFQ_DROP:
            mcnf  = MCNF(NORM_8W_DROP, port_on_chip);
            fwm   = FWM(NORM_8W_DROP, port_on_chip);
            wm[0] = WM(NORM_8W_DROP, port_on_chip, 0);
            wm[1] = WM(NORM_8W_DROP, port_on_chip, 1);
            wm[2] = WM(NORM_8W_DROP, port_on_chip, 2);
            wm[3] = WM(NORM_8W_DROP, port_on_chip, 3);
            wm[4] = WM(NORM_8W_DROP, port_on_chip, 4);
            wm[5] = WM(NORM_8W_DROP, port_on_chip, 5);
            wm[6] = WM(NORM_8W_DROP, port_on_chip, 6);
            wm[7] = WM(NORM_8W_DROP, port_on_chip, 7);
            break;
        case VTSS_JUMBO_SQ_DROP:
            mcnf  = MCNF(9600_8S_DROP, port_on_chip);
            fwm   = FWM(9600_8S_DROP, port_on_chip);
            wm[0] = WM(9600_8S_DROP, port_on_chip, 0);
            wm[1] = WM(9600_8S_DROP, port_on_chip, 1);
            wm[2] = WM(9600_8S_DROP, port_on_chip, 2);
            wm[3] = WM(9600_8S_DROP, port_on_chip, 3);
            wm[4] = WM(9600_8S_DROP, port_on_chip, 4);
            wm[5] = WM(9600_8S_DROP, port_on_chip, 5);
            wm[6] = WM(9600_8S_DROP, port_on_chip, 6);
            wm[7] = WM(9600_8S_DROP, port_on_chip, 7);
            break;
        case VTSS_JUMBO_WFQ_DROP:
            mcnf  = MCNF(9600_8W_DROP, port_on_chip);
            fwm   = FWM(9600_8W_DROP, port_on_chip);
            wm[0] = WM(9600_8W_DROP, port_on_chip, 0);
            wm[1] = WM(9600_8W_DROP, port_on_chip, 1);
            wm[2] = WM(9600_8W_DROP, port_on_chip, 2);
            wm[3] = WM(9600_8W_DROP, port_on_chip, 3);
            wm[4] = WM(9600_8W_DROP, port_on_chip, 4);
            wm[5] = WM(9600_8W_DROP, port_on_chip, 5);
            wm[6] = WM(9600_8W_DROP, port_on_chip, 6);
            wm[7] = WM(9600_8W_DROP, port_on_chip, 7);
            break;
        case VTSS_NORM_SQ_FC:
            mcnf  = MCNF(NORM_8S_FC, port_on_chip);
            fwm   = FWM(NORM_8S_FC, port_on_chip);
            wm[0] = WM(NORM_8S_FC, port_on_chip, 0);
            wm[1] = WM(NORM_8S_FC, port_on_chip, 1);
            wm[2] = WM(NORM_8S_FC, port_on_chip, 2);
            wm[3] = WM(NORM_8S_FC, port_on_chip, 3);
            wm[4] = WM(NORM_8S_FC, port_on_chip, 4);
            wm[5] = WM(NORM_8S_FC, port_on_chip, 5);
            wm[6] = WM(NORM_8S_FC, port_on_chip, 6);
            wm[7] = WM(NORM_8S_FC, port_on_chip, 7);
            break;
        case VTSS_JUMBO_SQ_FC:
            mcnf  = MCNF(9600_8S_FC, port_on_chip);
            fwm   = FWM(9600_8S_FC, port_on_chip);
            wm[0] = WM(9600_8S_FC, port_on_chip, 0);
            wm[1] = WM(9600_8S_FC, port_on_chip, 1);
            wm[2] = WM(9600_8S_FC, port_on_chip, 2);
            wm[3] = WM(9600_8S_FC, port_on_chip, 3);
            wm[4] = WM(9600_8S_FC, port_on_chip, 4);
            wm[5] = WM(9600_8S_FC, port_on_chip, 5);
            wm[6] = WM(9600_8S_FC, port_on_chip, 6);
            wm[7] = WM(9600_8S_FC, port_on_chip, 7);
            break;
        default:
            VTSS_E(("Unknown mode: %d",mode));
            return VTSS_UNSPECIFIED_ERROR;
        }
        
        HT_WR(PORT, port_on_chip, Q_MISC_CONF, mcnf);
        HT_WR(PORT, port_on_chip, Q_FLOWC_WM, fwm);
        for (i = 0; i < 8; i++) {
            HT_WR(PORT, port_on_chip, Q_DROP_WM+i, wm[i]);
        }
    }
    HT_WRF(ARBITER, 0, SBACKWDROP, port_on_chip, 0x1, MAKEBOOL01(!setup->flowcontrol.generate));
    HT_WRF(ARBITER, 0, DBACKWDROP, port_on_chip, 0x1, MAKEBOOL01(!setup->flowcontrol.obey));
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_SPARX_G8)
    {
        const vtss_sparx_g5_g8_qs_t *qp;
        const vtss_sparx_g5_g8_qs_units_t *qup;
        uint i, early_tx;

        qp = (vtss_api_state->g58_type >= VTSS_LUTON_TYPE_EXT) ? &vtss_sparx_g5e_g8e_qs : &vtss_sparx_g5_g8_qs;
        switch (mode) {
        case VTSS_NORM_SQ_DROP:
            qup = &qp->norm_4s_drop;
            break;
        case VTSS_NORM_WFQ_DROP:
            qup = &qp->norm_4w_drop;
            break;
        case VTSS_JUMBO_SQ_DROP:
            qup = &qp->jumbo_4s_drop;
            break;
        case VTSS_JUMBO_WFQ_DROP:
            qup = &qp->jumbo_4w_drop;
            break;
        case VTSS_NORM_SQ_FC:
            qup = &qp->norm_4s_fc;
            break;
        case VTSS_JUMBO_SQ_FC:
            qup = &qp->jumbo_4s_fc;
            break;
        default:
            VTSS_E(("Unknown mode: %d",mode));
            qup = &qp->norm_4s_drop;
            break;
        }

        /* Disable Early transmit for 10/100 */
        early_tx = (setup->interface_mode.speed == VTSS_SPEED_1G ? qup->early_tx : 0);
        
        HT_WRF(PORT, port_on_chip, Q_MISC_CONF, 0, 0x1f,
               (early_tx<<1) | (MAKEBOOL01(setup->flowcontrol.generate)<<0));
        HT_WR(PORT, port_on_chip, Q_FLOWC_WM, (qup->fwdp_start<<8) | (qup->fwdp_stop<<0));
        for (i = 0; i < VTSS_SPARX_WM_COUNT; i++)
            HT_WR(PORT, port_on_chip, Q_DROP_WM_0 + i, 
                  (qup->emin[i]<<24) | (qup->emax[i]<<16) | (qup->imin[i]<<8) | (qup->imax[i]<<0));
    }
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24)
    {
        ulong mcnf, fwm, wm;

#define MCNF(mode) \
((VTSS_##mode##_IDISC<<24) | \
 (VTSS_##mode##_IMIN<<16) | \
 (VTSS_##mode##_EMIN<<8) | \
 (VTSS_##mode##_EARLY_TX<<1) | \
 (setup->flowcontrol.generate ? 1 : 0)<<0)

#define FWM(mode) \
((VTSS_##mode##_FWDP_START<<8) | \
 (VTSS_##mode##_FWDP_STOP<<0))

#define WM(mode) \
((VTSS_##mode##_EMAX3<<24) | \
 (VTSS_##mode##_EMAX2<<16) | \
 (VTSS_##mode##_EMAX1<<8) | \
 (VTSS_##mode##_EMAX0<<0))

        switch (mode) {
        case VTSS_NORM_SQ_DROP: 
            mcnf = MCNF(NORM_4S_DROP);
            fwm  = FWM(NORM_4S_DROP);
            wm   = WM(NORM_4S_DROP);
            break;
        case VTSS_NORM_WFQ_DROP: 
            mcnf = MCNF(NORM_4W_DROP);
            fwm  = FWM(NORM_4W_DROP);
            wm   = WM(NORM_4W_DROP);
            break;
        case VTSS_JUMBO_SQ_DROP: 
            mcnf = MCNF(9600_4S_DROP);
            fwm  = FWM(9600_4S_DROP);
            wm   = WM(9600_4S_DROP);
#if VTSS_OPT_EARLY_TX
            /* Different FWDP_START value for 10/100 */
            if (setup->interface_mode.speed != VTSS_SPEED_1G)
                fwm = ((fwm & 0xff) | (39<<8));
#endif /* VTSS_OPT_EARLY_TX */                
            break;
        case VTSS_JUMBO_WFQ_DROP: 
            mcnf = MCNF(9600_4W_DROP);
            fwm  = FWM(9600_4W_DROP);
            wm   = WM(9600_4W_DROP);
            break;
        case VTSS_NORM_SQ_FC:   
            mcnf = MCNF(NORM_4S_FC);
            fwm  = FWM(NORM_4S_FC);
            wm   = WM(NORM_4S_FC);
            break;
        case VTSS_JUMBO_SQ_FC:   
            mcnf = MCNF(9600_4S_FC);
            fwm  = FWM(9600_4S_FC);
            wm   = WM(9600_4S_FC);
            break;
        default:
            VTSS_E(("Unknown mode: %d",mode));
            return VTSS_UNSPECIFIED_ERROR;
        }

        /* Disable Early transmit for 10/100 */
        if (setup->interface_mode.speed != VTSS_SPEED_1G)
            mcnf &= 0xffffffe1;

        /* Setup queue system drop levels and water marks */
        HT_WR(PORT, port_on_chip, Q_MISC_CONF, mcnf);
        HT_WR(PORT, port_on_chip, Q_FLOWC_WM, fwm);
        HT_WR(PORT, port_on_chip, Q_EGRESS_WM, wm);
        
        /* Enable tail drop */
        HT_WR(PORT, port_on_chip, MISCFIFO, MISCFIFO_TAILDROP);
    }
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
    {
        ulong mcnf = 0, ewm = 0, iwm[6];
        uint  i;

#define MCNF(mode) \
((VTSS_NORM_##mode##_IMIN<<16) | \
 (VTSS_NORM_##mode##_EMIN<<8) | \
 (VTSS_NORM_##mode##_EARLY_TX<<1))

#define EWM(mode) \
((VTSS_NORM_##mode##_EMAX3<<24) | \
 (VTSS_NORM_##mode##_EMAX2<<16) | \
 (VTSS_NORM_##mode##_EMAX1<<8) | \
 (VTSS_NORM_##mode##_EMAX0<<0))

#define IWM(mode, i) \
((VTSS_NORM_##mode##_LOWONLY_##i<<18) | \
 (VTSS_NORM_##mode##_QMASK_##i<<13) | \
 (VTSS_NORM_##mode##_ACTION_##i<<11) | \
 (VTSS_NORM_##mode##_CHKMIN_##i<<10) | \
 (VTSS_NORM_##mode##_CMPWITH_##i<<8) | \
 (VTSS_NORM_##mode##_LEVEL_##i<<0))

        switch (mode) {
        case VTSS_NORM_SQ_DROP: 
        case VTSS_JUMBO_SQ_DROP: 
            mcnf = MCNF(4S_DROP);
            ewm = EWM(4S_DROP);
            iwm[0] = IWM(4S_DROP, 0);
            iwm[1] = IWM(4S_DROP, 1);
            iwm[2] = IWM(4S_DROP, 2);
            iwm[3] = IWM(4S_DROP, 3);
            iwm[4] = IWM(4S_DROP, 4);
            iwm[5] = IWM(4S_DROP, 5);
            if (vtss_api_state->qos[port_no].policer_port != VTSS_BITRATE_FEATURE_DISABLED) {
                /* Special settings if policer enabled */
                iwm[0] = ((iwm[0] & 0xffffffe0) | (VTSS_NORM_4S_POLICER_LEVEL_0<<0));
                iwm[5] = ((iwm[5] & 0xffffffe0) | (VTSS_NORM_4S_POLICER_LEVEL_5<<0));  
            }
            break;
        case VTSS_NORM_WFQ_DROP: 
        case VTSS_JUMBO_WFQ_DROP: 
            mcnf = MCNF(4W_DROP);
            ewm = EWM(4W_DROP);
            iwm[0] = IWM(4W_DROP, 0);
            iwm[1] = IWM(4W_DROP, 1);
            iwm[2] = IWM(4W_DROP, 2);
            iwm[3] = IWM(4W_DROP, 3);
            iwm[4] = IWM(4W_DROP, 4);
            iwm[5] = IWM(4W_DROP, 5);
            if (vtss_api_state->qos[port_no].policer_port != VTSS_BITRATE_FEATURE_DISABLED) {
                /* Special settings if policer enabled */
                iwm[0] = ((iwm[0] & 0xffffffe0) | (VTSS_NORM_4W_POLICER_LEVEL_0<<0));
                iwm[5] = ((iwm[5] & 0xffffffe0) | (VTSS_NORM_4W_POLICER_LEVEL_5<<0));  
            }
            break;
        case VTSS_NORM_SQ_FC:   
        case VTSS_JUMBO_SQ_FC:   
            mcnf = MCNF(4S_FC);
            ewm = EWM(4S_FC);
            iwm[0] = IWM(4S_FC, 0);
            iwm[1] = IWM(4S_FC, 1);
            iwm[2] = IWM(4S_FC, 2);
            iwm[3] = IWM(4S_FC, 3);
            iwm[4] = IWM(4S_FC, 4);
            iwm[5] = IWM(4S_FC, 5);
            break;
        default:
            VTSS_E(("Unknown mode: %d",mode));
            return VTSS_UNSPECIFIED_ERROR;
        }
        
#if !defined(G_ROCX)
        if (setup->interface_mode.speed == VTSS_SPEED_10M && setup->fdx == 0) {
            /* Special settings for 10 Mbps half duplex operation */
            mcnf = ((mcnf & ((0x1f<<16) | (0xf<<1))) | (VTSS_NORM_10_HDX_EMIN<<8));
            ewm = EWM(10_HDX);
        }
#endif /* G_ROCX */

        /* Setup queue system drop levels and water marks */
        HT_WR(PORT, port_on_chip, Q_MISC_CONF, mcnf);
        HT_WR(PORT, port_on_chip, Q_EGRESS_WM, ewm);
        
        /* Ingress watermarks */
        for (i = 0; i < 6; i++) {
            HT_WR(PORT, port_on_chip, Q_INGRESS_WM + i, iwm[i]);
        }
    }
#endif /* VTSS_ARCH_SPARX_28 */
    return VTSS_OK;
}

/* ================================================================= *
 * ================================================================= *
 * = Port MAC ====================================================== *
 * ================================================================= *
 * ================================================================= */

#define VTSS_ARBITER_WAIT_MAXRETRIES 1000000

/* Reset the MAC and setup the port, watermarks etc. */
static vtss_rc ht_port_setup(vtss_port_no_t port_no, const vtss_port_setup_t * setup)
{
    uint    port_on_chip = HT_CHIP_PORT(port_no);
    ulong   macconf, value;
    ulong   macconf_speedbits;
    ht_tx_clock_select_t tx_clock_select;
    vtss_port_interface_t if_type = setup->interface_mode.interface_type;
    BOOL    if_loopback = (if_type == VTSS_PORT_INTERFACE_LOOPBACK);
#if defined(VTSS_ARCH_STAPLEFORD)
    BOOL    if_gmii_rgmii = (if_type == VTSS_PORT_INTERFACE_GMII || 
                             if_type == VTSS_PORT_INTERFACE_RGMII);
    BOOL    if_tbi_rtbi = (if_type == VTSS_PORT_INTERFACE_TBI || 
                           if_type == VTSS_PORT_INTERFACE_RTBI);
#endif /* VTSS_ARCH_STAPLEFORD */
    vtss_frame_gaps_t gaps;
    uint              hdx_late_col_pos;
    BOOL              powerdown = MAKEBOOL01(setup->powerdown);
    vtss_speed_t      speed = setup->interface_mode.speed;
    ulong             aggr_masks[VTSS_ACS];
    vtss_ac_no_t      ac;
    BOOL              fifo_not_empty = 1;
    uint              fifo_empty_retries = 0;
    
    /* Determine interframe gaps and default clock selection based on speed only */
    gaps.hdx_gap_1   = 0;
    gaps.hdx_gap_2   = 0;
    gaps.fdx_gap     = 0;
    hdx_late_col_pos = 0;

    switch (speed) {
    case VTSS_SPEED_10M:
    case VTSS_SPEED_100M:
        tx_clock_select = (speed == VTSS_SPEED_10M ? HT_TX_CLOCK_10M : HT_TX_CLOCK_100M);
#if defined(VTSS_ARCH_STANSTED)
        gaps.hdx_gap_1   = 6;
        gaps.hdx_gap_2   = 8;
        gaps.fdx_gap     = 17;
        hdx_late_col_pos = 2;
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_STAPLEFORD)
        gaps.hdx_gap_1   = 7;
        gaps.hdx_gap_2   = 8;
        gaps.fdx_gap     = 19;
        hdx_late_col_pos = 1;
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        gaps.hdx_gap_1   = 6;
        gaps.hdx_gap_2   = 8;
        gaps.fdx_gap     = 17;
        hdx_late_col_pos = 2;
#endif /* VTSS_ARCH_HAWX/SPARX */
        break;
    case VTSS_SPEED_1G:
        tx_clock_select = HT_TX_CLOCK_GIGA;
#if defined(VTSS_ARCH_STANSTED)
        gaps.fdx_gap     = 5;
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_STAPLEFORD)
        gaps.fdx_gap     = 7;
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        gaps.fdx_gap     = 6;
#endif /* VTSS_ARCH_HAWX/SPARX */
        break;
#if defined(VTSS_FEATURE_VAUI)
    case VTSS_SPEED_2500M:
    case VTSS_SPEED_5G:
        gaps.fdx_gap = 2; /* VAUI IFG of 8 bytes */
        tx_clock_select = HT_TX_CLOCK_OFF;
        break;
#endif /* VTSS_FEATURE_VAUI */
    default:
        VTSS_E(("illegal speed, port_no %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check interface type and determine clock selection */
    switch (if_type) {
    case VTSS_PORT_INTERFACE_NO_CONNECTION:
        tx_clock_select = HT_TX_CLOCK_OFF;
        break;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD) || defined(G_ROCX)
    case VTSS_PORT_INTERFACE_MII:
        if (speed == VTSS_SPEED_1G) {
            VTSS_E(("illegal speed, port_no %d", port_no));
            return VTSS_INVALID_PARAMETER;
        }
#if defined(G_ROCX)
        if (port_on_chip != 5) /* MII on port 5 only */
            return VTSS_INVALID_PARAMETER;
#endif /* G_ROCX */
        tx_clock_select = HT_TX_CLOCK_MISC;
        break;
    case VTSS_PORT_INTERFACE_GMII:
#if defined(G_ROCX)
        if (port_on_chip != 5) /* GMII on port 5 only */
            return VTSS_INVALID_PARAMETER;
        if (speed != VTSS_SPEED_1G)
            tx_clock_select = HT_TX_CLOCK_MISC;
        break;
#else
    case VTSS_PORT_INTERFACE_TBI:
    case VTSS_PORT_INTERFACE_RTBI:
        if (speed != VTSS_SPEED_1G) {
            VTSS_E(("illegal speed, port_no %d", port_no));
            return VTSS_INVALID_PARAMETER;
        }
        break;
#endif /* G_ROCX */
    case VTSS_PORT_INTERFACE_RGMII:
#if defined(G_ROCX)
        if (port_on_chip < 5) /* RGMII on port 5 and 6 only */
            return VTSS_INVALID_PARAMETER;
#else
    case VTSS_PORT_INTERFACE_LOOPBACK:
#endif /* G_ROCX */
        break;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD/G_ROCX */
#if defined(VTSS_ARCH_SPARX)
    case VTSS_PORT_INTERFACE_INTERNAL:
#if defined(SPARX_G5)
        if (port_on_chip == 6) /* Chip port 6 can only have an external PHY */
            return VTSS_INVALID_PARAMETER;
#endif /* SPARX_G5 */
#if defined(VTSS_ARCH_SPARX_G24)
        if (port_on_chip < 8 || port_on_chip > 15) /* Chip port 8-15 use internal PHY */
            return VTSS_INVALID_PARAMETER;
#endif /* VTSS_ARCH_SPARX_G24 */
        //jqiu modified for this sdk bug. clock select only have 2 bits.
        //tx_clock_select = HT_TX_CLOCK_MISC;
          tx_clock_select = HT_TX_CLOCK_OFF;
#if defined(VTSS_ARCH_SPARX_28)
#if defined(G_ROCX)
        if (port_on_chip == 4 || port_on_chip == 6)
            tx_clock_select = HT_TX_CLOCK_GIGA;
#else
        return VTSS_INVALID_PARAMETER;
#endif /* G_ROCX */
#endif /* VTSS_ARCH_SPARX_28 */
        break;
#if defined(VTSS_ARCH_SPARX_G8)
    case VTSS_PORT_INTERFACE_GMII:
    case VTSS_PORT_INTERFACE_RGMII:
        if (port_on_chip < 6) /* Only chip port 6 (and 7 for SparX-G8) can have external PHY */
            return VTSS_INVALID_PARAMETER;
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24) || (defined(VTSS_ARCH_SPARX_28) && !defined(G_ROCX))
    case VTSS_PORT_INTERFACE_SGMII:
#if defined(VTSS_ARCH_SPARX_G24)
        if (port_on_chip >= 8 && port_on_chip <= 15) /* Chip port 8-15 use internal PHY */
            return VTSS_INVALID_PARAMETER;
#endif /* VTSS_ARCH_SPARX_G24 */
#endif /* VTSS_ARCH_SPARX_G24/SPARX_28 && !G_ROCX */
    case VTSS_PORT_INTERFACE_LOOPBACK:
        if (tx_clock_select == HT_TX_CLOCK_OFF) { /* Not 10/100/1000 */
            VTSS_E(("illegal speed, port_no %d", port_no));
            return VTSS_INVALID_PARAMETER;
        }
        break;
#endif /* VTSS_ARCH_SPARX */
#if defined(VTSS_FEATURE_VAUI)
    case VTSS_PORT_INTERFACE_VAUI:
        if (speed != VTSS_SPEED_1G && speed != VTSS_SPEED_2500M && speed != VTSS_SPEED_5G) {
            VTSS_E(("illegal speed, port_no %d", port_no));
            return VTSS_INVALID_PARAMETER;
        }
        tx_clock_select = HT_TX_CLOCK_GIGA;
        break;
#endif /* VTSS_FEATURE_VAUI */
#if defined(VTSS_ARCH_HAWX)
    case VTSS_PORT_INTERFACE_LOOPBACK:
    case VTSS_PORT_INTERFACE_SGMII:
        if (tx_clock_select == HT_TX_CLOCK_OFF) { /* Not 10/100/1000 */
            VTSS_E(("illegal speed, port_no %d", port_no));
            return VTSS_INVALID_PARAMETER;
        }
        break;
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_FEATURE_SERDES)
    case VTSS_PORT_INTERFACE_SERDES:
        if (speed != VTSS_SPEED_1G) {
            VTSS_E(("illegal speed, port_no %d", port_no));
            return VTSS_INVALID_PARAMETER;
        }
        break;
#endif /* VTSS_FEATURE_SERDES */
    default:
        VTSS_E(("illegal speed, port_no %d", port_no));
        return VTSS_INVALID_PARAMETER;
    }

    /* Read and remove port from aggregation masks to avoid forwarding to port */
    for (ac = VTSS_AC_START; ac < VTSS_AC_END; ac++) {
        HT_RD(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, &value);
        aggr_masks[ac - VTSS_AC_START] = value;
        HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, value & ~(1<<port_on_chip));
    }

    /* Setup half duplex gaps */
    if (setup->frame_gaps.hdx_gap_1 != VTSS_FRAME_GAP_DEFAULT)
        gaps.hdx_gap_1 = setup->frame_gaps.hdx_gap_1;
    if (setup->frame_gaps.hdx_gap_2 != VTSS_FRAME_GAP_DEFAULT)
        gaps.hdx_gap_2 = setup->frame_gaps.hdx_gap_2;
    if (setup->frame_gaps.fdx_gap != VTSS_FRAME_GAP_DEFAULT)
        gaps.fdx_gap = setup->frame_gaps.fdx_gap;
    HT_WR(PORT, port_on_chip, MACHDXGAP,
          (7<<16) |
          (8<<12) | 
          (hdx_late_col_pos<<8) |
          (gaps.hdx_gap_2<<4) |
          (gaps.hdx_gap_1<<0));

    macconf = (((setup->fdx ? 1 : 0)<<18) |
               (gaps.fdx_gap<<6));

#if defined(VTSS_ARCH_STANSTED)
    macconf |= (2<<30);
#endif /* VTSS_ARCH_STANSTED */

    macconf |= ((setup->flowcontrol.smac.addr[5]<<19) |
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
                (0<<15) | /* Never Double VLAN Aware */
#endif /* VTSS_ARCH_HAWX/SPARX */
                ((HT_IS_NOT_MII_PORT(port_no) ? 1 : 0)<<14));
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    /* local_rx_clock is needed in internal_loopback mode */
    macconf |= ((if_loopback ? 1 : 0)<<3);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */

    macconf_speedbits = (((speed == VTSS_SPEED_10M || speed == VTSS_SPEED_100M ? 0 : 1)<<17) |
                         (tx_clock_select<<0));

#if !defined(VTSS_ARCH_SPARX)
    /* The following MAC reset will clear the C_RXDROP and C_TXOVFL counters
       so we clear the counter state to avoid fake increments */
    vtss_api_state->port_last_counters[port_no].rx_drops = 0;
    vtss_api_state->port_last_counters[port_no].tx_fifo_drops = 0;
#endif /* VTSS_ARCH_SPARX */

    /* We need to make sure that the FIFO is not receiving frames
       (from the bus) when it's coming out of reset  */

    while(fifo_not_empty) {
        /* Hold MAC Reset */
        value = (macconf | (1<<29) | (1<<27) | (1<<5) | (1<<4));
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        /* Don't reset PCS, because that would mess up autonegotiation, 
           if this function is called because autoneg completed */
        value |= ((0<<3) | (0<<2));
#endif /* VTSS_ARCH_HAWX/SPARX */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD) || defined(VTSS_ARCH_SPARX)
        value |= macconf_speedbits;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD/SPARX */
#if defined(VTSS_ARCH_HAWX)
        value |= (HT_TX_CLOCK_GIGA<<0);
#endif /* VTSS_ARCH_HAWX */
        HT_WR(PORT, port_on_chip, MAC_CFG, value);
        
        /* Set Arbiter to not discard frames from the port */
        HT_WRF(ARBITER, 0, ARBDISC, port_on_chip, 0x1, 0);
        
#if defined(VTSS_ARCH_SPARX_G8)
        /* Enable extra memory if extended version */
        HT_WRF(PORT, port_on_chip, Q_MISC_CONF, 31, 0x1, 
               vtss_api_state->g58_type >= VTSS_LUTON_TYPE_EXT ? 1 : 0);
#endif /* VTSS_ARCH_SPARX_G8 */                
        
        /* Release MAC from Reset and set Seed_Load */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        /* (MAC here meaning both MAC and PCS) */
#endif
        value = (macconf | (0<<29) | (1<<27) | (0<<5) | (0<<4) | macconf_speedbits);
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        value |= ((0<<3) | (0<<2));
#endif        
        
        HT_WR(PORT, port_on_chip, MAC_CFG, value);
        
        VTSS_NSLEEP(1000);
        /* Clear Seed_Load bit */
        HT_WR(PORT, port_on_chip, MAC_CFG, value & ~(1<<27));
        
        HT_RD(PORT, port_on_chip, FREEPOOL, &value);
        fifo_not_empty = 0;
        if ((value & 0xffff) != 0) {
            /*       VTSS_E(("Freepool is not empty after reset:0x%x.",value));  */
            fifo_not_empty = 1;
            fifo_empty_retries++;
            if (fifo_empty_retries > 10)
                break;            
            VTSS_MSLEEP(100);
        } 
    }
    
    /* Restore aggregation masks */
    for (ac = VTSS_AC_START; ac < VTSS_AC_END; ac++) {
        HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, aggr_masks[ac - VTSS_AC_START]);
    }

#if defined(VTSS_ARCH_SPARX_G24) 
	/*Just for VSC7390 send error packet*/
    use_rxclk_as_txclk(port_on_chip, 0);
    adjust_sgmii_sample_ctrl(port_on_chip);
#endif /* VTSS_ARCH_SPARX_G24 */

    /* Set Advanced Port Mode */
#if defined(VTSS_ARCH_STAPLEFORD)
    value = (((if_loopback ? 1 : 0)<<6) |
             (0<<5) |
             (0<<4) |
             (((if_gmii_rgmii || if_tbi_rtbi) ? 0 : 1)<<3) |
             (if_tbi_rtbi ? 1 : 0)<<0);
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED)
    value = (((setup->flowcontrol.generate && speed == VTSS_SPEED_1G ? 1 : 0)<<9) |
             ((setup->flowcontrol.generate && speed == VTSS_SPEED_1G ? 1 : 0)<<8) |
             (0<<7) |
             ((if_loopback ? 1 : 0)<<6) |
             (0<<4) |
             (0<<3));
#endif /* VTSS_ARCH_STANSTAD */
#if defined(VTSS_ARCH_SPARX_G24) || (defined(VTSS_ARCH_SPARX_28) && !defined(G_ROCX))
    value = (((setup->exc_col_cont ? 1 : 0)<<6) | /* EXC_COL_CONT */
             (0<<5) | /* REVERSE_MII */
             (0<<4) | /* INVERT_GTX */
             (0<<3) | /* ENABLE_GTX */
             (0<<1)); /* IO_LOOPBACK */
#if VTSS_OPT_NICIO
    value |= (((port_on_chip == VTSS_MII_PORT_NO ? 1 : 0)<<11) | /* USE_CPUQ */
              ((port_on_chip == VTSS_MII_PORT_NO ? 1 : 0)<<7) |  /* INSERT_IFH */
              ((port_on_chip == VTSS_MII_PORT_NO ? 0 : 1)<<2));  /* CPUPORT_AWARE */
#endif /* VTSS_OPT_NICIO */
#endif /* VTSS_ARCH_SPARX_G24/SPARX_28 */
#if defined(VTSS_ARCH_SPARX_G8)
    value = (((if_type == VTSS_PORT_INTERFACE_INTERNAL ? 0 : 1)<<5) | /* EXTERNAL_PORT */
             (0<<4) | /* INVERT_GTX */
             ((if_type == VTSS_PORT_INTERFACE_RGMII ? 1 : 0)<<3) | /* ENABLE_GTX */
             ((if_type == VTSS_PORT_INTERFACE_RGMII ? 1 : 0)<<2) | /* DDR_MODE */
             (0<<1) | /* IO_LOOPBACK */
             ((if_loopback ? 1 : 0)<<0)); /* HOST_LOOPBACK */
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_HAWX)
    value = ((0<<7) | /* IFG_PPM */
             ((setup->exc_col_cont ? 1 : 0)<<5)); /* EXC_COL_CNT */
#endif /* VTSS_ARCH_HAWX */
#if defined(G_ROCX)
    value = (((setup->exc_col_cont ? 1 : 0)<<6) | /* EXC_COL_CONT */
             ((port_on_chip == 4 || if_type == VTSS_PORT_INTERFACE_GMII ? 1 : 0)<<4) | /* INVERT_GTX */
             ((port_on_chip > 3 ? 1 : 0)<<3) |    /* ENABLE_GTX */
             ((if_type == VTSS_PORT_INTERFACE_RGMII ? 1 : 0)<<2) |    /* DDR_MODE */
             ((port_on_chip > 3 ? 1 : 0)<<1) |    /* INV_RXCLK */
             ((if_loopback ? 1 : 0)<<0));         /* HOST_LOOPBACK */
#endif /* G_ROCX */
    HT_WR(PORT, port_on_chip, ADVPORTM, value);
    
#if defined(VTSS_ARCH_STAPLEFORD)
    /* Setup TBI signal detect pin */
    VTSS_RC(ht_tbictrl_wrm(port_on_chip,
                           ((setup->tbi_signaldetect_activehigh ? 1 : 0)<<23) |
                           ((setup->tbi_use_signaldetect ? 1 : 0)<<22), 
                           (1<<23) | (1<<22)));
    
#if VTSS_OPT_FC_SHAPING_BUCKET_RATE>1 /*Fixed*/
    /* Design Consideration #1. */
    VTSS_RC(ht_opt_port_shaper_adjust(port_no));
#endif
#endif /* VTSS_ARCH_STAPLEFORD */

    /* Setup PCSCTRL register */
#if defined(VTSS_ARCH_SPARX_G24) 
    HT_WRM(PORT, port_on_chip, PCSCTRL,
           ((if_type == VTSS_PORT_INTERFACE_SGMII ? 1 : 0)<<24),
           (1<<24));
#endif /* VTSS_ARCH_SPARX_G24 */

#if (defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)) && defined(VTSS_FEATURE_TBI)
    VTSS_RC(ht_tbictrl_wrm(port_on_chip,
                           ((if_type == VTSS_PORT_INTERFACE_SGMII ? 1 : 0)<<25) |
                           ((if_type == VTSS_PORT_INTERFACE_SGMII ? 1 : 0)<<24) |
                           ((if_type != VTSS_PORT_INTERFACE_SGMII && 
                             setup->tbi_signaldetect_activehigh ? 1 : 0)<<23) |
                           ((if_type != VTSS_PORT_INTERFACE_SGMII && 
                             setup->tbi_use_signaldetect ? 1 : 0)<<22),
                           (1<<25) | (1<<24) | (1<<23) | (1<<22)));
#endif /* VTSS_ARCH_HAWX/SPARX_28 && TBI */
    
    /* Setup SGMII_CFG register */
#if defined(VTSS_ARCH_SPARX_G24)
    /*HT_WR(PORT, port_on_chip, SGMII_CFG,
          (4<<6) | (4<<3) | (if_loopback ? 3 : 0)<<0);*/
      HT_WR(PORT, port_on_chip, SGMII_CFG,
          (4<<6) | (2<<3) | (if_loopback ? 3 : 0)<<0);    
#endif /* VTSS_ARCH_SPARX_G24 */
    
#if defined(VTSS_FEATURE_SERDES)
    /* Output level */
    value = (if_type == VTSS_PORT_INTERFACE_SERDES ? (setup->serdes_low_drive ? 1 : 0) : 1);
#if defined(VTSS_ARCH_HAWX)
    if (!vtss_api_state->hawx_b)
        value = 0;
#endif /* VTSS_ARCH_HAWX */    
    HT_WRM(PORT, port_on_chip, SGMII_CFG,
           (1<<28) |
           ((if_loopback ? 1 : 0)<<27) |
           (value<<26) | 
           (1<<25) |
           ((if_type == VTSS_PORT_INTERFACE_SGMII ? 0 : 1)<<23) |
           (0<<22) |
           (if_loopback ? (1<<9):0) |
           (1<<8) |
           (1<<0),
           (1<<28) | (1<<27) | (1<<26) | (1<<25) | (1<<23) | 
           (1<<22) | (1<<9) | (1<<8) | (1<<0));
#endif /* VTSS_FEATURE_SERDES */

#if defined(VTSS_FEATURE_VAUI)
    /* Setup VAUI lane */
    if (port_on_chip >= VTSS_CHIP_PORT_VAUI_START) {
        HT_WR(VAUI, S_VAUI, LANE_CFG + (port_on_chip - VTSS_CHIP_PORT_VAUI_START)*4,
              (2<<18) | (2<<10) |
              ((speed == VTSS_SPEED_2500M || speed == VTSS_SPEED_5G ? 0 : 1)<<2) |
              ((speed == VTSS_SPEED_2500M || speed == VTSS_SPEED_5G ? 0 : 1)<<1) |
              ((powerdown ? 0 : 1)<<0));
        HT_WR(VAUI, S_VAUI, IB_CFG + (port_on_chip - VTSS_CHIP_PORT_VAUI_START)*4,
              (1<<7) | (0<<6) | (1<<4) | (VTSS_OPT_VAUI_EQ_CTRL<<0));
    }
#endif /* VTSS_FEATURE_VAUI */

#if defined(VTSS_ARCH_HAWX)
    /* Setup SGMII common mode */
    HT_WRF(PORT, port_on_chip & ~1, SGMII_CMSEL, (port_on_chip & 1) ? 9 : 0, 0x1,
           if_type == VTSS_PORT_INTERFACE_SGMII && setup->sgmii_dc_coupled ? 0 : 1);
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_SPARX_G8)
    if (port_on_chip == 6 || port_on_chip == 7) {
        ulong rx_offs = (port_on_chip == 6 ? 0 : 2);
        ulong tx_offs = (port_on_chip == 6 ? 4 : 6);

        HT_WRM(SYSTEM, 0, GMIIDELAY, 
               ((if_type == VTSS_PORT_INTERFACE_RGMII ? 1 : 0)<<rx_offs) |
               ((if_type == VTSS_PORT_INTERFACE_RGMII ? 1 : 0)<<tx_offs),
               (0x3<<rx_offs) | (0x3<<tx_offs));
    }
#endif /* VTSS_ARCH_SPARX_G8 */

    if (powerdown) {

#ifdef VTSS_FEATURE_TBI
        BOOL tbi;

#if defined(VTSS_ARCH_STAPLEFORD)
        tbi = if_tbi_rtbi;
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
        tbi = (if_type==VTSS_PORT_INTERFACE_SERDES || if_loopback);
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
        if (tbi) {
            /* Send Link Break signal */
            vtss_tbi_autoneg_control_t control;
            memset(&control, 0, sizeof(vtss_tbi_autoneg_control_t));
            /* Enable (and restart) autonegotiation.
               This will send a Link Break signal before autonegotiation restarts. */
            control.enable = 1;
            VTSS_RC(vtss_ll_port_tbi_aneg_control(port_no, &control));
            /* Abort the autonegotiation before it completes */
            control.enable = 0;
            VTSS_RC(vtss_ll_port_tbi_aneg_control(port_no, &control));
        }
#endif /* VTSS_FEATURE_TBI */
            
        /* Power down MAC */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        /* (MAC here meaning both MAC and PCS) */
#endif /* VTSS_ARCH_HAWX/SPARX */
        value = ((1<<5) | (1<<4));
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G24) || defined(VTSS_ARCH_SPARX_28)
        value |= ((1<<3) | (1<<2));
#endif /* VTSS_ARCH_HAWX/SPARX_G24/SPARX_28 */
        HT_WRM(PORT, port_on_chip, MAC_CFG, value, value);
        
#if defined(VTSS_FEATURE_SGMII)
        /* Power down SGMII SerDes */
        HT_WRM(PORT, port_on_chip, SGMII_CFG,
               (0<<28) | (0<<25) | (0<<8) | (0<<0),
               (1<<28) | (1<<25) | (1<<8) | (1<<0));
#endif /* VTSS_FEATURE_SGMII */
#if defined(VTSS_ARCH_SPARX_G24) 
        use_rxclk_as_txclk(port_on_chip, 0);
#endif /* VTSS_ARCH_SPARX_G24 */
    }

    {
        uint maxlen = setup->maxframelength;
#if defined(VTSS_FEATURE_VSTAX)
        /* Allow jumbo frames with VStaX header on stack ports */
        if (vtss_api_state->vstax_port_setup[port_no].enable)
            maxlen = (VTSS_MAXFRAMELENGTH_MAX + VTSS_VSTAX_HDR_SIZE);
#endif /* VTSS_FEATURE_VSTAX */     
        HT_WR(PORT, port_on_chip, MAXLEN, maxlen);
    }
#if defined(VTSS_ARCH_STAPLEFORD) && (VTSS_OPT_FC_SHAPING_BUCKET_RATE>1)
    /* Design Consideration #1. */
    VTSS_RC(ht_opt_port_shaper_adjust(port_no));
#endif 

    return vtss_ll_port_queue_setup(port_no);
}

#if defined(VTSS_FEATURE_VAUI)
/* Get VAUI port status */
vtss_rc vtss_ll_vaui_status_get(vtss_port_no_t port_no, vtss_port_status_t * const status)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong value;

    if (port_on_chip < VTSS_CHIP_PORT_VAUI_START) {
        return VTSS_UNSPECIFIED_ERROR;
    }
    
    /* Read link status */
    HT_RDF(PORT, port_on_chip, PCSSTAT, 20, 0x1, &value);
    status->link_down = (value ? 0 : 1);
    if (status->link_down) {
        HT_RDF(PORT, port_on_chip, PCSSTAT, 20, 0x1, &value);
        status->link = (value ? 1 : 0);
    } else {
        status->link = 1;
    }
#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(port_on_chip)) != 0) {
        /* Read aggregated port status */
        port_on_chip = HT_CHIP_PORT(port_no);
        HT_RDF(PORT, port_on_chip, PCSSTAT, 20, 0x1, &value);
        if (!value) {
            status->link_down = 1;
            HT_RDF(PORT, port_on_chip, PCSSTAT, 20, 0x1, &value);
            if (!value)
                status->link = 0;
        } 
    }
#endif /* VTSS_OPT_INT_AGGR */
    
    /* Read configured speed */
    HT_RDF(VAUI, S_VAUI, LANE_CFG + (port_on_chip - VTSS_CHIP_PORT_VAUI_START)*4, 
           2, 0x1, &value);
#if VTSS_OPT_INT_AGGR
    status->speed = VTSS_SPEED_5G;
#else
    status->speed = (value ? VTSS_SPEED_1G : VTSS_SPEED_2500M);
#endif /* VTSS_OPT_INT_AGGR */
    /* Always report full duplex */
    status->fdx = 1;

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_VAUI */

/* Configure port into one of the gmii modes or tbi modes */
vtss_rc vtss_ll_port_speed_mode_tbi_gmii(vtss_port_no_t port_no,
                                         const vtss_port_setup_t * setup)
{
    uint  wait_attempt;
    ulong value;
    BOOL  empty;

    VTSS_D(("port_no: %d",port_no));

#if defined(VTSS_FEATURE_EXC_COL_CONT)
    {
        vtss_port_no_t    port;
        ulong             value = HT_TIMECMP_DEFAULT;
        vtss_port_setup_t *ps;

        /* Count number of half duplex ports with excessive collision continuation enabled
           and setup frame aging accordingly */
        for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
            ps = &vtss_api_state->setup[port];
            if (ps->exc_col_cont && !ps->fdx) {
                value = 0; /* Frame aging disabled */
                break; 
            }
        }
        HT_WR(SYSTEM, 0, TIMECMP, value);
    }
#endif /* VTSS_FEATURE_EXC_COL_CONT */

    /* Discard frames from the port, Disable RX and Drop everything in the FIFOs */
    VTSS_RC(ht_port_queue_enable(port_no, 0));

    /* Wait until Arbiter port empty */
    for (wait_attempt=0; wait_attempt<VTSS_ARBITER_WAIT_MAXRETRIES; wait_attempt++) {
        HT_RD(ARBITER, 0, ARBEMPTY, &value);
        if (value & (1<<HT_CHIP_PORT(port_no)))
            break;
    }
    if (wait_attempt>=VTSS_ARBITER_WAIT_MAXRETRIES) {
        /* Timeout */
        vtss_port_no_t port; /* Other ports */

        VTSS_D(("Timeout: Arbiter does not empty port %d, reset and setup all ports", port_no));

        /* Discard frames from all ports, Disable RX and Drop everything in the FIFOs */
        for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
            if (port == port_no) continue;
            VTSS_RC(ht_port_queue_enable(port, 0));
        }
#if VTSS_OPT_NICIO
        VTSS_RC(ht_port_queue_enable(HT_MII_PORT_NO, 0));
#endif /* VTSS_OPT_NICIO */

        /* Wait until Arbiter empty for all ports */
        for (wait_attempt=0; wait_attempt<VTSS_ARBITER_WAIT_MAXRETRIES; wait_attempt++) {
            VTSS_RC(ht_arbiter_empty_allports(&empty));
            if (empty)
                break;
        }
        if (wait_attempt>=VTSS_ARBITER_WAIT_MAXRETRIES) {
            /* Timeout */
            VTSS_E(("Timeout: Arbiter does not empty all ports."));
            return VTSS_FATAL_ERROR;
        }

        /* Reset and setup all ports, watermarks etc. */
        for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
            if (port == port_no) continue;
            VTSS_RC(ht_port_setup(port, &vtss_api_state->setup[port]));
            VTSS_RC(ht_port_queue_enable(port, 1));
        }
#if VTSS_OPT_NICIO
        VTSS_RC(ht_port_setup(HT_MII_PORT_NO, &ht_mii_port_setup));
        VTSS_RC(ht_port_queue_enable(HT_MII_PORT_NO, 1));
#endif /* VTSS_OPT_NICIO */
    }

    /* Reset and setup the port, watermarks etc. */
    VTSS_RC(ht_port_setup(port_no, setup));
    
#if !defined(VTSS_ARCH_SPARX)
    /* Setup QoS as policer/shaper rate granularity depend on port speed */
    VTSS_RC(vtss_ll_port_qos_setup_set(port_no, &vtss_api_state->qos[port_no]));
#endif /* VTSS_ARCH_SPARX */

    VTSS_RC(ht_port_queue_enable(port_no, setup->port_enable));

#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(HT_CHIP_PORT(port_no))) != 0) {
        /* Setup aggregated port */
        vtss_api_state->setup[port_no] = *setup;
        VTSS_RC(vtss_ll_port_speed_mode_tbi_gmii(port_no, setup));
    }
#endif /* VTSS_OPT_INT_AGGR */
    
#if defined(VTSS_ARCH_SPARX_28)    
    /* Count number of ports in flow control and setup HOLB */
    value = 0;
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (vtss_api_state->setup[port_no].flowcontrol.obey ||
            vtss_api_state->setup[port_no].flowcontrol.generate)
            value++;
    }
    HT_WR(ARBITER, 0, ARBHOLBPENAB, value ? 0 : VTSS_CHIP_PORTMASK);
#endif /* VTSS_ARCH_SPARX_28 */

    return VTSS_OK;
}

/* ================================================================= *
 * ================================================================= *
 * = Port QoS (Categorizer/Policer/Shaper) ========================= *
 * ================================================================= *
 * ================================================================= */

static int chip_prio(const vtss_prio_t prio) __VTSS_ATTRIB_CONST_FUNCTION__;
static int chip_prio(const vtss_prio_t prio)
{
#if (VTSS_PRIOS==2)
    switch (vtss_api_state->prios) {
        case 1: return 1;
        case 2: return (prio-VTSS_PRIO_START);
    }
#endif /* (VTSS_PRIOS==2) */
#if (VTSS_PRIOS==4)
    switch (vtss_api_state->prios) {
        case 1: return 3;
        case 2: return (prio==1 ? 1 : 3);
        case 4: return (prio-VTSS_PRIO_START);
    }
#endif /* (VTSS_PRIOS==4) */
#if (VTSS_PRIOS==8)
    switch (vtss_api_state->prios) {
        case 1: return 7;
        case 2: return (prio==1 ? 5 : 7);
        case 4: return (prio==1 ? 1 : prio==2 ? 3 : prio==3 ? 5 : 7);
        case 8: return (prio-VTSS_PRIO_START);
    }
#endif /* (VTSS_PRIOS==8) */
    return 0; /* Never comes here, but avoid the compiler warning. */
}

#if !defined(VTSS_ARCH_SPARX)
#if defined(VTSS_FEATURE_QOS_POLICER_PORT) || defined(VTSS_FEATURE_QOS_SHAPER_PORT) || defined(VTSS_ARCH_HAWX)
static vtss_bitrate_t sane_bitrate(const vtss_speed_t speed, const vtss_bitrate_t bitrate) __VTSS_ATTRIB_CONST_FUNCTION__;
static vtss_bitrate_t sane_bitrate(const vtss_speed_t speed, const vtss_bitrate_t bitrate)
{
    if (bitrate==VTSS_BITRATE_FEATURE_DISABLED) return VTSS_BITRATE_FEATURE_DISABLED;
    switch (speed) {
        case VTSS_SPEED_1G:   
            return bitrate<=1000000 ? bitrate : VTSS_BITRATE_FEATURE_DISABLED;
        case VTSS_SPEED_100M: 
            return bitrate<=100000 ? bitrate : VTSS_BITRATE_FEATURE_DISABLED;
        case VTSS_SPEED_10M:  
            return bitrate<=10000 ? bitrate : VTSS_BITRATE_FEATURE_DISABLED;
        default: 
            return bitrate;
    }
}
#endif /* VTSS_FEATURE_QOS_POLICER_PORT || VTSS_FEATURE_QOS_SHAPER_PORT || VTSS_ARCH_HAWX */
#endif /* VTSS_ARCH_SPARX */

#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)

#if (VTSS_PRIOS==2)
#define CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chipprio,bitfield) \
    prio_bitfield    |= ((chipprio) > 0 ? (bitfield) : 0);
#endif /* (VTSS_PRIOS==2) */
#if (VTSS_PRIOS==4)
#define CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chipprio,bitfield) \
    prio_bitfield    |= ((chipprio) & 0x2 ? (bitfield) : 0); \
    subprio_bitfield |= ((chipprio) & 0x1 ? (bitfield) : 0);
#endif /* (VTSS_PRIOS==4) */

static vtss_rc ht_set_shaper_internal(vtss_port_no_t port_no, int bucket_rate)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);

    if (bucket_rate == 0) {
        /* Shaper disabled */
        HT_WR(PORT, port_on_chip, SHAPECONF, 0 );
    } else {
        /* watermark=min(allports:ingress_high_threshold) = 12 */
        /* shaper.threshold=round_up(watermark*0.5) = 6 */
        HT_WR(PORT, port_on_chip, SHAPECONF,
              (0<<31) |      /* bit  31:    'Drop mode' */
              (1<<30) |      /* bit  30:    'Flow control mode' */
                             /* bit  29:    'reset' - Not modified by this function */
              (6<<16) |      /* bits 24..16:'bucket_threshold' */
                             /* bits 15..12: not defined for the POLICECONF register */
              (bucket_rate<<0));   /* bits 11..00:'bucket_rate' */
    }
    return VTSS_OK;
}

#if defined(VTSS_ARCH_STAPLEFORD) && (VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1)

/* This must be called when one of the following port parameters changes: 
   Speed, Duplex, FIFO Ingress Flow Control, Max Frame Size. */

static vtss_rc ht_opt_port_shaper_adjust(vtss_port_no_t port_no)
{
#if VTSS_OPT_FC_SHAPING_BUCKET_RATE==1 /*Auto*/
    /* ht_set_shaper_internal() will be taken care of by ht_opt_fc_shaping(). */
#endif
#if VTSS_OPT_FC_SHAPING_BUCKET_RATE>1 /*Fixed*/
    int bucket_rate = vtss_api_state->shapeconf_bucket_rate_wanted[port_no];
    if ((vtss_api_state->setup[port_no].interface_mode.speed == VTSS_SPEED_10M || 
         vtss_api_state->setup[port_no].interface_mode.speed == VTSS_SPEED_100M) &&
        vtss_api_state->setup[port_no].fdx &&
        (vtss_api_state->setup[port_no].flowcontrol.obey || 
         vtss_api_state->setup[port_no].flowcontrol.generate) &&
        !setup->maxframelength > VTSS_MAXFRAMELENGTH_TAGGED &&
        /* 10/100 FDX with Flow Control enabled, no jumbo frame support */
        (bucket_rate == 0 || bucket_rate >= VTSS_OPT_FC_SHAPING_BUCKET_RATE)) {
        bucket_rate = VTSS_OPT_FC_SHAPING_BUCKET_RATE;
    }
    VTSS_RC(ht_set_shaper_internal(port_no, bucket_rate));
#endif
    return VTSS_OK;
}
#endif /* VTSS_ARCH_STAPLEFORD && VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1 */

static vtss_rc ht_set_shaper(vtss_port_no_t port_no, int bucket_rate)
{
#if defined(VTSS_ARCH_STAPLEFORD) && (VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1)
    vtss_api_state->shapeconf_bucket_rate_wanted[port_no] = bucket_rate;
    return ht_opt_port_shaper_adjust(port_no);
#else
    return ht_set_shaper_internal(port_no, bucket_rate);
#endif /* VTSS_ARCH_STAPLEFORD && VTSS_OPT_FC_SHAPING_BUCKET_RATE>=1 */
}

/* Calculate policer/shaper rate */
static ulong calc_rate(vtss_port_no_t port_no, vtss_bitrate_t bitrate, BOOL round_up)
{
    vtss_speed_t speed;
    ulong        rate;

    speed = vtss_api_state->setup[port_no].interface_mode.speed;
    if (sane_bitrate(speed, bitrate) == VTSS_BITRATE_FEATURE_DISABLED) {
        rate = 0;
    } else {
        switch (speed) {
        case VTSS_SPEED_1G:   
            rate = (bitrate*1000/244144); /* = /(244144/1000) */ 
            break;
        case VTSS_SPEED_100M: 
            rate = (bitrate*5000/244144); /* = *5/(244144/1000) */ 
            break;
        case VTSS_SPEED_10M:  
            rate = (bitrate*50000/244144); /* = *50/(244144/1000) */ 
            break;
        default: 
            rate = 0; 
            break;
        };
        if (round_up) {
            rate = ((rate*2+1)/2);
        }
    }
    return rate;
}

/* Calculate policer register */
static ulong calc_policer_reg(vtss_port_no_t port_no, vtss_bitrate_t bitrate, BOOL mc) 
{
    ulong        rate, reg;

    if ((rate = calc_rate(port_no, bitrate, 1)) == 0) {
        reg = 0;
    } else {
        reg = (((vtss_api_state->port_fc_tx[port_no] ? 0 : 1)<<31) | /* 31: 'Drop mode' */
               ((vtss_api_state->port_fc_tx[port_no] ? 1 : 0)<<30) | /* 30: 'FC mode' */
               ((mc ? 6 : 8)<<16) |  /* 24:16: 'bucket_threshold' */
               (rate<<0));           /* 11:00: 'bucket_rate' */
    }
    return reg;
}

/* Set port QoS setup */
vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);
    uint i;
    ulong prio_bitfield;
    ulong subprio_bitfield;

    if (qos->tag_enable) {
        if (qos->dscp_enable || qos->ip_proto_enable || qos->dsap_enable || qos->etype_enable) {
            VTSS_E(("With tag_enable, any of dscp_enable, ip_proto_enable, dsap_enable or etype_enable classification modes can not be used."));
            return VTSS_INVALID_PARAMETER;
        }
    } else if (qos->dscp_enable && (qos->udp_tcp_enable || qos->ip_proto_enable)) {
        VTSS_E(("With !tag_enable and dscp_enable, the udp_tcp_enable and ip_proto_enable classification modes can not be used."));
        return VTSS_INVALID_PARAMETER;
    }

    /* Categorizer mode */
    HT_WRM(PORT, port_on_chip, CATCONF,
           ((qos->tag_enable ? 1 : 0)<<31) |
           ((qos->dscp_enable ? 1 : 0)<<26) |
           (0<<18),
           (1<<31) | (1<<26) | (1<<18));

    /* Classify based on VLAN tag prio */
    prio_bitfield = 0;
    subprio_bitfield = 0;
    for (i=0;i<=7;i++) {
        CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->tag_prio[i]),1<<i)
    }
    HT_WR(PORT, port_on_chip, CATTAG, prio_bitfield);
#if (VTSS_PRIOS==4)
    HT_WR(PORT, port_on_chip, CATSUBTAG, subprio_bitfield);
#endif /* (VTSS_PRIOS==4) */

    /* Ethernet type value */
    HT_WR(PORT, port_on_chip, CATETHT, qos->etype_enable ? qos->etype_val: 0xFFFF);

    /* DSAP value */
    HT_WR(PORT, port_on_chip, CATDSAP, qos->dsap_enable ? qos->dsap_val : 0x00);

    /* IP protocol value */
    HT_WR(PORT, port_on_chip, CATIPPRT, qos->ip_proto_enable ? qos->ip_proto_val : 255);

    /* End state priorities */
    prio_bitfield = 0;
    subprio_bitfield = 0;
    CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->default_prio),(1<<(1-1))|(1<<(2-1))/*FS1,FS2*/)
    /* Note: there is no FS3 in the chip. */
    CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->dsap_enable?qos->dsap_prio:qos->default_prio),1<<(4-1)/*FS4*/);
    CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->default_prio/*dsap_prio_def*/),1<<(5-1)/*FS5*/)
    CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->etype_enable?qos->etype_prio:qos->default_prio),1<<(6-1)/*FS6*/)
    CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->default_prio/*ip_proto_prio_def*/),1<<(7-1)/*FS7*/)
    CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->default_prio/*etype_prio_def*/),1<<(8-1)/*FS8*/)
    HT_WR(PORT, port_on_chip, CATPRIO, prio_bitfield);
#if (VTSS_PRIOS==4)
    HT_WR(PORT, port_on_chip, CATSUBPRIO, subprio_bitfield);
#endif /* (VTSS_PRIOS==4) */

    /* DSCP priorities */
    prio_bitfield = 0;
    subprio_bitfield = 0;
    for (i=0;i<=31;i++) {
        CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->dscp_prio[i+32]),1<<i)
    }
    HT_WR(PORT, port_on_chip, CATDSMAPH, prio_bitfield);
#if (VTSS_PRIOS==4)
    HT_WR(PORT, port_on_chip, CATDSSUBMAPH, subprio_bitfield);
#endif /* (VTSS_PRIOS==4) */
    prio_bitfield = 0;
    subprio_bitfield = 0;
    for (i=0;i<=31;i++) {
        CHIPPRIO_BITFIELD_ADD(prio_bitfield,subprio_bitfield,chip_prio(qos->dscp_prio[i]),1<<i)
    }
    HT_WR(PORT, port_on_chip, CATDSMAPL, prio_bitfield);
#if (VTSS_PRIOS==4)
    HT_WR(PORT, port_on_chip, CATDSSUBMAPL,subprio_bitfield);
#endif /* (VTSS_PRIOS==4) */

    /* Default ingress VLAN tag priority */
    HT_WRM(PORT, port_on_chip, CATPVID, (qos->usr_prio<<16) | (qos->usr_prio), (0x7<<16) | 0x7);

    /* UDP/TCP port numbers */
    HT_WR(PORT, port_on_chip, CATPORT1, (qos->udp_tcp_val[0]<<16) | qos->udp_tcp_val[1]);
    HT_WR(PORT, port_on_chip, CATPORT2, (qos->udp_tcp_val[2]<<16) | qos->udp_tcp_val[3]);
    HT_WR(PORT, port_on_chip, CATPORT3, (qos->udp_tcp_val[4]<<16) | qos->udp_tcp_val[5]);
    HT_WR(PORT, port_on_chip, CATPORT4, (qos->udp_tcp_val[6]<<16) | qos->udp_tcp_val[7]);
    HT_WR(PORT, port_on_chip, CATPORT5, (qos->udp_tcp_val[8]<<16) | qos->udp_tcp_val[9]);

#if defined(VTSS_ARCH_STANSTED)
    /* Offset set to 2 really gives offset around 20, which is what we want. */
    HT_WRM(PORT, port_on_chip, MAXLEN, 2<<17, 0x1F<<17);
#endif /* VTSS_ARCH_STANSTED */

    /* Policer */
    HT_WR(PORT, port_on_chip, POLICECONF, calc_policer_reg(port_no, qos->policer_port, 0));

    /* Multicast Storm Control */
    HT_WR(PORT, port_on_chip, MCSTORMCONF, calc_policer_reg(port_no, qos->mc_policer_port, 1));

    /* Shaper */
    VTSS_RC(ht_set_shaper(port_no, calc_rate(port_no, qos->shaper_port, 0)));

    return VTSS_OK;
}
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */

#if defined(VTSS_ARCH_HAWX)
/* Calculate rate/fill registers */
static uint calc_rate_reg(vtss_port_no_t port_no, ulong *reg, uint count)
{
    uint           i,fine;
    ulong          rate, fill;
    vtss_speed_t   speed;
    vtss_bitrate_t bitrate;

    /* Fine granularity not supported by HawX revision A */
    fine = (vtss_api_state->hawx_b ? 1 : 0);

    /* Convert rate to register value and check if max rate is exceeded */
    speed = vtss_api_state->setup[port_no].interface_mode.speed;
    for (i = 0; i < count; i++) {
        bitrate = sane_bitrate(speed, reg[i]);
        if (bitrate == VTSS_BITRATE_FEATURE_DISABLED) {
            /* Policer/shaper disabled */
            rate = 0;
            fill = 0x1FF; /* Maximum fill value means disabled */
        } else {
            switch (speed) {
            case VTSS_SPEED_1G:   
                rate = (bitrate/64);      /* Unit is 64 kbps */
                break;
            case VTSS_SPEED_100M: 
                rate = (bitrate*10/128);  /* Unit is 12.8 kbps */
                break;
            case VTSS_SPEED_10M:  
                rate = (bitrate*100/128); /* Unit is 1.28 kbps */
                break;
            default:              
                rate=0xFFF;
                break;
            }
            fill = 27;
        }
        reg[i] = ((rate<<9) | fill);
        
        /* Check if maximum rate has been exceeded */
        if (rate > 0xFFF)
            fine = 0;
    }

    /* Divide all rates by 4 if fine granularity can not be used */
    for (i = 0; fine == 0 && i < count; i++) {
        rate = ((reg[i]>>11) & 0xFFF);
        fill = (reg[i] & 0x1FF);
        reg[i] = ((rate<<9) | fill);
    }
    return fine;
} 

/* Set port QoS setup */
vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos)
{
    vtss_rc rc = VTSS_OK;
    uint    port_on_chip = HT_CHIP_PORT(port_no);
    uint    i, j, fine, fc;
    ulong   value, reg[12]; /* Policer/shaper registers */

    /* Categorizer mode */
    HT_WR(PORT, port_on_chip, CAT_PR_MISC_L2, 
          ((qos->dsap_enable ? 1 : 0)<<30) |
          ((qos->tag_enable ? 1 : 0)<<28) |
          (chip_prio(qos->etype_prio[1])<<24) |
          (chip_prio(qos->etype_prio[0])<<20) |
          (chip_prio(qos->default_prio)<<16) |
          (chip_prio(qos->dsap_prio)<<8) |
          (qos->dsap_val<<0));
    HT_WR(PORT, port_on_chip, CAT_PR_MISC_L3, 
          ((qos->udp_tcp_enable ? 1 : 0)<<23) |
          ((qos->dscp_enable ? 1 : 0)<<21) | 
          ((qos->ip_proto_enable ? 1 : 0)<<20) |
          (chip_prio(qos->udp_tcp_prio[9])<<16) |
          (chip_prio(qos->udp_tcp_prio[8])<<12) |
          (chip_prio(qos->ip_proto_prio)<<8) |
          (qos->ip_proto_val<<0));
    
    /* UDP/TCP port numbers */
    value = 0;
    for (i = 0; i < 10; i += 2) {
        HT_WR(PORT, port_on_chip, CAT_PR_TCPUDP_PORTS+i/2, 
              qos->udp_tcp_val[i+1]<<16 | qos->udp_tcp_val[i]);

        /* Priority for last two ports are in CAT_PR_MISC_L3 register */
        if (i != 8) {
            value |= (chip_prio(qos->udp_tcp_prio[i])<<(4*i));
            value |= (chip_prio(qos->udp_tcp_prio[i+1])<<(4*i+4));
        }
    }
    HT_WR(PORT, port_on_chip, CAT_PR_TCPUDP_QOS, value);

    /* Map from DSCP to priority */
    for (i = 0; i < 64; i++) {
        j = (i % 8);
        if (j == 0)
            value = 0;
        value |= (chip_prio(qos->dscp_prio[i])<<(j*4));
        if (j == 7)
            HT_WR(PORT, port_on_chip, CAT_PR_DSCP_QOS+i/8, value);
    }

    /* Classify based on VLAN tag prio */
    value = 0;
    for (i = 0; i <= 7; i++) {
        value |= (chip_prio(qos->tag_prio[i])<<(4*i));
    }
    HT_WR(PORT, port_on_chip, CAT_PR_USR_PRIO, value);

    /* Ethernet type value */
    HT_WR(PORT, port_on_chip, CAT_PR_ETYPE,
          ((qos->etype_enable ? qos->etype_val[1] : 0xFFFF)<<16) | 
          ((qos->etype_enable ? qos->etype_val[0] : 0xFFFF)<<0));
    
    /* Default ingress VLAN tag priority */
    HT_WRF(PORT, port_on_chip, CAT_VLAN_AB, 12, 0x7, qos->usr_prio);
    HT_WRF(PORT, port_on_chip, CAT_VLAN_AB, 28, 0x7, qos->usr_prio);
    
    /* Calculate policer registers */
    j = 0;
    reg[j++] = qos->policer_port; 
    reg[j++] = qos->mc_policer_port; 
    reg[j++] = qos->bc_policer_port; 
    reg[j++] = qos->policer_cir_port; 
    for (i=VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
        reg[j++] = qos->policer_cir_queue[i];
        reg[j++] = qos->policer_pir_queue[i];
    }
    fine = calc_rate_reg(port_no, reg, j);
    fc = MAKEBOOL01(vtss_api_state->setup[port_no].flowcontrol.generate);

    /* Setup general policer configuration */
    HT_WR(PORT, port_on_chip, POL_CONF,
          (fine<<22) | /* 22: Granularity for HawX revision B */
          (10<<10) |   /* 21..10: Flow Control Hysteresis */
          (fc<<9) |    /* 9: Broadcast mode: 1=FC, 0=drop */
          (fc<<8) |    /* 8: Multicast mode: 1=FC, 0=drop */
          (fc<<7) |    /* 7: Line mode: 1=FC, 0=drop */
          (1<<6) |     /* 6: Enable policer */
          (0<<5) |     /* 5: CPU-Only bypass enable */
          (20<<0));    /* 4..0: Gap value: 20=Network, 0=User */

    /* Setup rate/fill register for all policers */
    j = 0;
    HT_WR(PORT, port_on_chip, POL_LINE, reg[j++]);
    HT_WR(PORT, port_on_chip, POL_MCAST, reg[j++]);
    HT_WR(PORT, port_on_chip, POL_BCAST, reg[j++]);
    HT_WR(PORT, port_on_chip, POL_LINECIR, reg[j++]);

    for (i=VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
        HT_WR(PORT, port_on_chip, POL_Q0CIR+i-VTSS_QUEUE_START, reg[j++]);
        HT_WR(PORT, port_on_chip, POL_Q0PIR+i-VTSS_QUEUE_START, reg[j++]);
    }

    /* Calculate shaper registers */
    j = 0;
    reg[j++] = qos->shaper_port; 
    for (i=VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
        reg[j++] = qos->shaper_queue[i];
    }
    fine = calc_rate_reg(port_no, reg, j);

    /* Setup general shaper configuration */
    HT_WR(PORT, port_on_chip, WS_CONF,
          (fine<<13) | /* 13: Granularity for HawX revision B */
          (0<<12) |    /* 12: fill_excess */
          (0<<11) |    /* 11: empty_lineblock */
          ((qos->shaper_queue_excss_enable[4] ? 1 : 0)<<10) |  /* 10: excess_desired_3 */
          ((qos->shaper_queue_excss_enable[3] ? 1 : 0)<<9) |   /*  9: excess_desired_2 */
          ((qos->shaper_queue_excss_enable[2] ? 1 : 0)<<8) |   /*  8: excess_desired_1 */
          ((qos->shaper_queue_excss_enable[1] ? 1 : 0)<<7) |   /*  7: excess_desired_0 */
          (1<<6) |     /* 6: Enable shaper */
          (0<<5) |     /* 5: CPU injected bypass enable */
          (20<<0));    /* 4..0: Gap value: 20=Network, 0=User */
    
    /* Setup rate/fill register for all shapers */
    j = 0;
    HT_WR(PORT, port_on_chip, WS_LINE, reg[j++]);

    for (i=VTSS_QUEUE_START; i<VTSS_QUEUE_END; i++) {
        HT_WR(PORT, port_on_chip, WS_BUCK0+i-VTSS_QUEUE_START, reg[j++]);
    }

    return rc;
}
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_SPARX_G24) || defined(VTSS_ARCH_SPARX_28)

#if defined(VTSS_ARCH_SPARX_G24)
#define RATE_FACTOR 1428571 /* Arbiter rate factor */
#endif /* VTSS_ARCH_SPARX_G24 */

#if defined(VTSS_ARCH_SPARX_28)
#if defined(G_ROCX)
#define RATE_FACTOR 1176471 /* 8000000/6.8 */
#define RATE_MAX    4595    /* 0xFFF*RATE_FACTOR/0xFFFFF */
#else
#define RATE_FACTOR 1666667 /* 8000000/4.8 */
#define RATE_MAX    6510    /* 0xFFF*RATE_FACTOR/0xFFFFF */
#endif /* G_ROCX */
#endif /* VTSS_ARCH_SPARX_28 */

/* Setup policers and shapers for all ports */
static vtss_rc sparx_policer_shaper_setup(void)
{
    uint                  i, port_on_chip, j, weight, w[VTSS_QUEUES];
    vtss_port_no_t        port_no;
    ulong                 max_rate = 0, policer_rate, shaper_rate;
#if defined(VTSS_ARCH_SPARX_G24)
    ulong                 scale = 0;
#endif /* VTSS_ARCH_SPARX_G24 */
    vtss_port_qos_setup_t *qos;
    
    for (i = 0; i < 2; i++) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (vtss_api_state->port_map.vtss_port_unused[port_no])
                continue;
            
            qos = &vtss_api_state->qos[port_no];
            policer_rate = qos->policer_port;
            if (policer_rate == VTSS_BITRATE_FEATURE_DISABLED)
                policer_rate = 0;
            
            shaper_rate = qos->shaper_port;
            if (shaper_rate == VTSS_BITRATE_FEATURE_DISABLED)
                shaper_rate = 0;
                
            if (i == 0) {
                /* First round: calculate maximum rate */
                if (policer_rate > max_rate)
                    max_rate = policer_rate;

                if (shaper_rate > max_rate)
                    max_rate = shaper_rate;
            } else {
                /* Second round: Setup policer and shaper */
                port_on_chip = HT_CHIP_PORT(port_no);
                for (j = 0; j < VTSS_QUEUES; j++) {
                    weight = qos->weight[j + VTSS_QUEUE_START];
                    w[j] = (qos->wfq_enable ? 
                            (weight == VTSS_WEIGHT_1 ? 3 :
                             weight == VTSS_WEIGHT_2 ? 2 :
                             weight == VTSS_WEIGHT_4 ? 1 :
                             weight == VTSS_WEIGHT_8 ? 0 : 4) : 0);
                    if (w[j] > 3) {
                        VTSS_E(("illegal weight: %d", weight));
                        w[j] = 0;
                    }
                }
#if defined(VTSS_ARCH_SPARX_G24)
                HT_WR(PORT, port_on_chip, RATECONF,
                      (20<<24) | /* Include 20 bytes for line rate policing/shaping */
                      (0<<23) |  /* Disable FC mode */
                      (3<<21) |  /* Policer burst 16 kB */
                      ((policer_rate*scale/RATE_FACTOR)<<16) |
                      (w[0]<<14) | (w[1]<<12) | (w[2]<<10) |  (w[3]<<8) | 
                      ((qos->wfq_enable ? 1 : 0)<<7) |
                      (3<<5) |   /* Shaper burst 16 kB */
                      ((shaper_rate*scale/RATE_FACTOR)<<0));
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
                HT_WR(PORT, port_on_chip, SHAPER_CFG,
                      (20<<24) | /* GAP_VALUE */
                      (w[0]<<22) | (w[1]<<20) | (w[2]<<18) | (w[3]<<16) | 
                      ((qos->wfq_enable ? 1 : 0)<<15) |
                      (1<<12) |  /* EGRESS_BURST: 4 kB */
                      (shaper_rate*0xFFF/max_rate)<<0); /* EGRESS_RATE */
                HT_WR(PORT, port_on_chip, POLICER_CFG,
                      (1<<15) | /* POLICE_FWD */
                      (0<<14) | /* POLICE_FC */
                      (1<<12) | /* INGRESS_BURST: 4 kB */
                      (policer_rate*0xFFF/max_rate)<<0); /* INGRESS RATE */
#endif /* VTSS_ARCH_SPARX_28 */
            }
        }
        if (i == 0) {
            /* Calculate maximum rate */
            if (max_rate > 1000000 || max_rate == 0) /* Maximum 1G */
                max_rate = 1000000;
            
#if defined(VTSS_ARCH_SPARX_G24)
            /* Setup rate unit in arbiter, round down to value multiple of 25 */
            scale = RATE_FACTOR*0x1F/max_rate;
            scale -= (scale % 25);
            HT_WR(ARBITER, 0, RATEUNIT, scale);
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
            /* Setup rate unit */
            if (max_rate < RATE_MAX)
                max_rate = RATE_MAX; 
            HT_WR(SYSTEM, 0, RATEUNIT, 5*(((0xFFF/5)*RATE_FACTOR)/max_rate));
#endif /* VTSS_ARCH_SPARX_28 */
        }
    }
    
    return VTSS_OK;
}
#endif /* VTSS_ARCH_SPARX_G24/SPARX_28 */

#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
/* Set port QoS setup */
vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);
    uint i, cprio, cprio_default, dscp_val_ix;
    uint dscp_q, dscp_val_0_3, dscp_val_4_6;
    uint phist[VTSS_PRIOS], phist_max;

    /* Categorizer mode */
    HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L3, 21, 0x1, MAKEBOOL01(qos->dscp_enable));
    HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L2, 28, 0x1, MAKEBOOL01(qos->tag_enable));
#if defined(VTSS_FEATURE_QOS_IP_TOS_PORT) && defined(SPARX_G5)
    if (vtss_api_state->g58_type == VTSS_LUTON_TYPE_R2) {
        HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L3, 22, 0x1, MAKEBOOL01(qos->tos_enable));
    }
#endif /* VTSS_FEATURE_QOS_IP_TOS_PORT && SPARX_G5 */

    /* Find the most common prio - and use it as default prio */
    memset(phist, 0, sizeof(phist));
    for (i = 0; i < 64; i++)
        phist[chip_prio(qos->dscp_prio[i])]++;
    VTSS_D(("Port %u: phist = %u %u %u %u\n", port_no,
            phist[0], phist[1], phist[2], phist[3]));
    phist_max = phist[0];
    cprio_default = 0;
    for (i = 1; i < VTSS_PRIOS; i++)
        if (phist[i] > phist_max) {
            phist_max = phist[i];
            cprio_default = i;
        }
    /* Map from DSCP to priority */
    dscp_q = (cprio_default << 28) | (cprio_default << 24) | (cprio_default << 20) | (cprio_default << 16) |
        (cprio_default << 12) | (cprio_default << 8) | (cprio_default << 4) | (cprio_default << 0); 
    dscp_val_ix = 0;
    dscp_val_0_3 = dscp_val_4_6 = 0;
    VTSS_D(("Port %u: Default DSCP prio = %u\n", port_no, cprio_default));
    for (i = 0; i < 64; i++) {
        cprio = chip_prio(qos->dscp_prio[i]);
        if (cprio != cprio_default) {
            VTSS_D(("Port %u: DSCP %u prio = %u\n", port_no, i, cprio));
            dscp_q &= ~(3 << (dscp_val_ix * 4));
            dscp_q |= cprio << (dscp_val_ix * 4);
            if (dscp_val_ix < 4)
                dscp_val_0_3 |= i << (dscp_val_ix * 8);
            else
                dscp_val_4_6 |= i << ((dscp_val_ix - 4) * 8);
            if (++dscp_val_ix == 7)
                break;
        }
    }
    HT_WR(PORT, port_on_chip, CAT_PR_DSCP_QOS, dscp_q);
    HT_WR(PORT, port_on_chip, CAT_PR_DSCP_VAL_0_3, dscp_val_0_3);
    HT_WR(PORT, port_on_chip, CAT_PR_DSCP_VAL_4_6, dscp_val_4_6);

    /* Classify based on VLAN tag prio */
    for (i = 0; i <= 7; i++) {
        HT_WRF(PORT, port_on_chip, CAT_PR_USR_PRIO, i*4, 0x3, chip_prio(qos->tag_prio[i]));
    }

    /* Default ingress VLAN tag priority */
    HT_WRF(PORT, port_on_chip, CAT_PORT_VLAN, 12, 0x7, qos->usr_prio);

    /* Default port priority */
    HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L2, 16, 0x3, chip_prio(qos->default_prio));
#if defined(VTSS_FEATURE_QOS_ETYPE_PORT) && defined(SPARX_G5)
    if (vtss_api_state->g58_type == VTSS_LUTON_TYPE_R2) {
        HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L2, 29, 0x1, MAKEBOOL01(qos->etype_enable));
        HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L2, 30, 0x3, MAKEBOOL01(qos->etype_prio));
        HT_WRF(PORT, port_on_chip, CAT_PR_MISC_L2, 0, 0xFF, qos->etype_val);
    }
#endif /* VTSS_FEATURE_QOS_ETYPE_PORT && SPARX_G5 */

#if defined(VTSS_ARCH_SPARX_G24)
    /* Policer/shaper */
    VTSS_RC(sparx_policer_shaper_setup());
#endif /* VTSS_ARCH_SPARX_G24 */

    return VTSS_OK;
}
#endif /* VTSS_ARCH_SPARX_G8/G24 */

#if defined(VTSS_ARCH_SPARX_28)
#define QCL_PORT_MAX 12 /* Number of QCLs per port */
#define QCE_TYPE_FREE      (0<<24)
#define QCE_TYPE_ETYPE     (1<<24)
#define QCE_TYPE_VID       (2<<24)
#define QCE_TYPE_UDP_TCP   (3<<24)
#define QCE_TYPE_DSCP      (4<<24)
#define QCE_TYPE_TOS       (5<<24)
#define QCE_TYPE_TAG       (6<<24)

static BOOL ht_qcl_full(const vtss_qcl_id_t qcl_id)
{
    int              i;
    vtss_qcl_entry_t *entry;

    for (i = 0, entry = vtss_api_state->qcl[qcl_id].qcl_list_used;
         entry != NULL; i++, entry = entry->next) {
        
        switch (entry->qce.type) {
        case VTSS_QCE_TYPE_ETYPE:
        case VTSS_QCE_TYPE_VLAN:
        case VTSS_QCE_TYPE_TOS:
        case VTSS_QCE_TYPE_TAG:
            /* These entries take up a single QCL entry */
            break;
        case VTSS_QCE_TYPE_UDP_TCP:
            if (entry->qce.frame.udp_tcp.low != entry->qce.frame.udp_tcp.high) {
                /* Range, at least two entries required */
                if (i & 1) /* Odd address, three entries requried */
                    i++;
                i++;
            }
            break;
        case VTSS_QCE_TYPE_DSCP:
            if (entry->next != NULL && entry->next->qce.type == VTSS_QCE_TYPE_DSCP) {
                /* If next entry is DSCP, merge */
                entry = entry->next;
            }
            break;
        default: 
            VTSS_E(("Unknown QCE type (%d)", entry->qce.type)); 
            return 0;
        }
    }
    return (i > QCL_PORT_MAX);
}

static vtss_rc ht_qcl_port_setup_set(const vtss_port_no_t port_no, const vtss_qcl_id_t qcl_id)
{
    uint             port_on_chip = HT_CHIP_PORT(port_no);
    uint             i, j;
    ulong            value;
    vtss_qcl_entry_t *entry;
    
    /* Clear range table */
    HT_WR(PORT, port_on_chip, CAT_QCL_RANGE_CFG, 0);

    for (i = 0, entry = vtss_api_state->qcl[qcl_id].qcl_list_used;
         i < QCL_PORT_MAX && entry != NULL; i++, entry = entry->next) {

        switch(entry->qce.type) {
        case VTSS_QCE_TYPE_ETYPE:
            value = (QCE_TYPE_ETYPE | 
                     (chip_prio(entry->qce.frame.etype.prio)<<16) | 
                     (entry->qce.frame.etype.val<<0)); 
            VTSS_D(("Adding ETYPE QCE[%d]: 0x%08lx", i, value)); 
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            break;
        case VTSS_QCE_TYPE_VLAN:
            value = (QCE_TYPE_VID | 
                     (chip_prio(entry->qce.frame.vlan.prio)<<16) | 
                     (entry->qce.frame.vlan.vid<<0));
            VTSS_D(("Adding VLAN QCE[%d]: 0x%08lx", i, value));  
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            break;
        case VTSS_QCE_TYPE_UDP_TCP:
            if (entry->qce.frame.udp_tcp.low != entry->qce.frame.udp_tcp.high) {
                if (i & 1) {
                    VTSS_D(("Adding free QCE[%d] for UDP/TCP range", i));
                    HT_WR(PORT, port_on_chip, CAT_QCE0 + i, QCE_TYPE_FREE);
                    i++;
                    if (i >= QCL_PORT_MAX)
                        break;
                }
                VTSS_D(("Setting bit #%d of QCL range cfg", i/2));  
                HT_WRF(PORT, port_on_chip, CAT_QCL_RANGE_CFG, i/2, 0x1, 1);
            }
            value = (QCE_TYPE_UDP_TCP | 
                     (chip_prio(entry->qce.frame.udp_tcp.prio)<<16) | 
                     (entry->qce.frame.udp_tcp.low<<0)); 
            VTSS_D(("Adding UDP/TCP QCE[%d]: 0x%08lx", i, value));
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            if (entry->qce.frame.udp_tcp.low != entry->qce.frame.udp_tcp.high) {
                i++;
                if (i >= QCL_PORT_MAX)
                    break;
                value = (QCE_TYPE_UDP_TCP | 
                         (chip_prio(entry->qce.frame.udp_tcp.prio)<<16) | 
                         (entry->qce.frame.udp_tcp.high<<0)); 
                VTSS_D(("Adding UDP/TCP QCE[%d]: 0x%08lx", i, value));
                HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            }
            break;
        case VTSS_QCE_TYPE_DSCP:
            value = (QCE_TYPE_DSCP | 
                     (entry->qce.frame.dscp.dscp_val <<  2) | 
                     (chip_prio(entry->qce.frame.dscp.prio) << 0));  /* DSCP0 */ 
            if (entry->next != NULL && entry->next->qce.type == VTSS_QCE_TYPE_DSCP) {
                /* If next entry is DSCP, merge */
                entry = entry->next;
            }
            value |= ((entry->qce.frame.dscp.dscp_val << 10) | 
                      (chip_prio(entry->qce.frame.dscp.prio) << 8)); /* DSCP1 */ 
            VTSS_D(("Adding DSCP QCE[%d]: 0x%08lx", i, value)); 
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            break;
        case VTSS_QCE_TYPE_TOS:
            value = QCE_TYPE_TOS;
            for (j = 0; j < 8; j++) {
                value |= (chip_prio(entry->qce.frame.tos_prio[j])<<(j*2));
            }
            VTSS_D(("Adding TOS QCE[%d]: 0x%08lx", i, value)); 
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            break;
        case VTSS_QCE_TYPE_TAG:
            value = QCE_TYPE_TAG;
            for (j = 0; j < 8; j++) {
                value |= (chip_prio(entry->qce.frame.tag_prio[j])<<(j*2));
            }
            VTSS_D(("Adding TAG QCE[%d]: 0x%08lx", i, value)); 
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, value);
            break;
        default: 
            VTSS_E(("Unknown QCE type (%d)", entry->qce.type)); 
            return VTSS_UNSPECIFIED_ERROR;
        }
    }
    
    /* clear unused entries */
    while (i < QCL_PORT_MAX) {
        HT_WR(PORT, port_on_chip, CAT_QCE0 + i, QCE_TYPE_FREE);
        i++;
    }

    return VTSS_OK;
}

/* Set port QoS setup */
vtss_rc vtss_ll_port_qos_setup_set(vtss_port_no_t port_no, const vtss_port_qos_setup_t *qos)
{
    uint        port_on_chip = HT_CHIP_PORT(port_no);
    uint        i = 0, j, k, max, prio_count[VTSS_PRIO_ARRAY_SIZE];
    vtss_prio_t prio;
    ulong       tos = QCE_TYPE_TOS, dscp = 0, tag = QCE_TYPE_TAG;
    
    VTSS_D(("port_no %d", port_no));

#if defined(VTSS_FEATURE_VSTAX)
    if (vtss_api_state->vstax_port_setup[port_no].enable) {
        /* Mapping from internal priority to VStaX priority:
           0->1, 1->3, 2->5, 3->7 */
        HT_WR(PORT, port_on_chip, CAT_GEN_PRIO_REMAP, 
              (7<<12) | (5<<8) | (3<<4) | (1<<0));

        /* Mapping from VStaX priority to internal priority:
           0->0, 1->0, 2->1, 3->1, 4->2, 5->2, 6->3, 7->3 */
        for (i = 0; i < QCL_PORT_MAX; i++) {
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, QCE_TYPE_FREE | 0xfa50);
        }
    } else
#endif /* VTSS_FEATURE_VSTAX */
    if (qos->qcl_id != VTSS_QCL_ID_NONE) {
        /* setup QCL */
        ht_qcl_port_setup_set(port_no, qos->qcl_id);
        
        /* skip old-style setup below by setting i to QCL_PORT_MAX */
        i = QCL_PORT_MAX;
    } else {
        /* Disable range checkers */
        HT_WR(PORT, port_on_chip, CAT_QCL_RANGE_CFG, 0);
    }

    /* UDP/TCP port numbers */
    if (qos->udp_tcp_enable) {
        for (j = 0; j < 10; j++) {
            if (i < QCL_PORT_MAX && qos->udp_tcp_val[j] != 0) {
                HT_WR(PORT, port_on_chip, CAT_QCE0 + i,
                      QCE_TYPE_UDP_TCP | 
                      (chip_prio(qos->udp_tcp_prio[j])<<16) | 
                      (qos->udp_tcp_val[j]<<0));
                i++;
            }
        }
    }
    
    /* DSCP */
    if (qos->dscp_enable) {
        for (j = 0; j < 8; j++) {
            /* Find most frequent DSCP priority for each ToS value */
            memset(prio_count, 0, sizeof(prio_count));
            for (k = 0; k < 8; k++)
                prio_count[qos->dscp_prio[j*8+k]]++;
            max = VTSS_PRIO_START;
            for (k = VTSS_PRIO_START; k < VTSS_PRIO_END; k++)
                if (prio_count[k] > prio_count[max])
                    max = k;

            /* Update ToS register value */
            tos |= (chip_prio(max)<<(j*2));

            /* Add entries for DSCP priorities different from the most frequent one */
            for (k = 0; k < 8; k++) {
                prio = qos->dscp_prio[j*8+k];
                if (prio != max) {
                    if (dscp == 0) {
                        dscp = QCE_TYPE_DSCP | ((j*8+k)<<10) | (chip_prio(prio)<<8);
                    } else {
                        dscp |= (((j*8+k)<<2) | (chip_prio(prio)<<0));
                        if (i < (QCL_PORT_MAX - 1)) {
                            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, dscp);
                            i++;
                        }
                        dscp = 0;
                    }
                }
            }
        } 
        
        /* If odd number of DSCP exceptions, write one more */
        if (dscp != 0 && i < (QCL_PORT_MAX - 1)) {
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, dscp | ((dscp>>8) & 0xFF));
            i++;
        }

        /* Add ToS entry with most frequent priorities */
        if (i < QCL_PORT_MAX) {
            HT_WR(PORT, port_on_chip, CAT_QCE0 + i, tos);
            i++;
        }
    } else if (qos->tos_enable && i < QCL_PORT_MAX) {
        for (j = 0; j < 8; j++) {
            tos |= (chip_prio(qos->dscp_prio[j*8])<<(j*2));
        }
        HT_WR(PORT, port_on_chip, CAT_QCE0 + i, tos);
        i++;
    }
    
    /* Tag priority */
    if (qos->tag_enable && i < QCL_PORT_MAX) {
        for (j = 0; j < 8; j++) {
            tag |= (chip_prio(qos->tag_prio[j])<<(j*2));
        }
        HT_WR(PORT, port_on_chip, CAT_QCE0 + i, tag);
        i++;
    }

    /* Ethernet Type */
    if (qos->etype_enable && i < QCL_PORT_MAX) {
        HT_WR(PORT, port_on_chip, CAT_QCE0 + i, 
              QCE_TYPE_ETYPE | (chip_prio(qos->etype_prio)<<16) | (qos->etype_val<<0));
        i++;
    }
    
    /* Skip remaining QCEs */
    while (i < QCL_PORT_MAX) {
        HT_WR(PORT, port_on_chip, CAT_QCE0 + i, QCE_TYPE_FREE);
        i++;
    }

    /* Default ingress VLAN tag priority */
    HT_WRF(PORT, port_on_chip, CAT_PORT_VLAN, 12, 0x7, qos->usr_prio);

    /* Default priority */
    HT_WR(PORT, port_on_chip, CAT_QCL_DEFAULT_CFG, chip_prio(qos->default_prio));

    /* Policers and shapers */
    VTSS_RC(sparx_policer_shaper_setup());

    /* Setup queues as water marks depend on policer setup */
    VTSS_RC(vtss_ll_port_queue_setup(port_no));

#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(port_on_chip)) != 0) {
        /* Setup aggregated port */
        VTSS_RC(vtss_ll_port_qos_setup_set(port_no, qos));
    }
#endif /* VTSS_OPT_INT_AGGR */    

    return VTSS_OK;
}
#endif /* VTSS_ARCH_SPARX_28 */

#if defined(VTSS_FEATURE_QCL_PORT)
static vtss_rc ht_qcl_commit(const vtss_qcl_id_t qcl_id)
{
    vtss_port_no_t port_no;
    vtss_rc qcl_rc = VTSS_OK;
    
    if (ht_qcl_full(qcl_id)) {
        VTSS_D(("Warning: QCL %d will be truncated when applied", qcl_id));
        qcl_rc = VTSS_WARNING;
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (vtss_api_state->qos[port_no].qcl_id == qcl_id) {
            /* Reapply QoS settings */
            VTSS_RC(vtss_ll_port_qos_setup_set(port_no, &vtss_api_state->qos[port_no]));
        }
    }

    return qcl_rc;
}

/* Add QCE */
vtss_rc vtss_ll_qce_add(vtss_qcl_id_t    qcl_id,
                        vtss_qce_id_t    qce_id,
                        const vtss_qce_t *qce)
{
    vtss_qcl_t       *qcl;
    vtss_qcl_entry_t *cur, *prev = NULL;
    vtss_qcl_entry_t *new = NULL, *new_prev = NULL, *ins = NULL, *ins_prev = NULL;
    
    VTSS_D(("enter, qcl_id: %d, qce_id: %ld", qcl_id, qce_id));
    
    /* QCE ID 0 is reserved for insertion at end. Also check for same id */
    if (qce->id == VTSS_QCE_ID_LAST || qce->id == qce_id) {
        VTSS_E(("illegal qce id: %lu", qce->id));        
        return VTSS_INVALID_PARAMETER;
    }

    /* Check that the QCL ID is valid */
    if (qcl_id < VTSS_QCL_ID_START || qcl_id >= VTSS_QCL_ID_END) {
        VTSS_E(("illegal qcl_id: %d", qcl_id));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Search for existing entry and place to add */
    qcl = &vtss_api_state->qcl[qcl_id];
    for (cur = qcl->qcl_list_used; cur != NULL; prev = cur, cur = cur->next) {
        if (cur->qce.id == qce->id) {
            /* Entry already exists */
            new_prev = prev;
            new = cur;
        }
        
        if (cur->qce.id == qce_id) {
            /* Found insertion point */
            ins_prev = prev;
            ins = cur;
        }
    }

    if (qce_id == VTSS_QCE_ID_LAST)
        ins_prev = prev;

    /* Check if the place to insert was found */
    if (ins == NULL && qce_id != VTSS_QCE_ID_LAST) {
        VTSS_E(("could not find qce_id: %ld", qce_id));
        return VTSS_ENTRY_NOT_FOUND;
    }
    
    if (new == NULL) {
        /* Take new entry from free list */
        if ((new = qcl->qcl_list_free) == NULL) {
            VTSS_E(("QCL is full"));
            return VTSS_UNSPECIFIED_ERROR;
        }
        qcl->qcl_list_free = new->next;
    } else {
        /* Take existing entry out of list */
        if (ins_prev == new)
            ins_prev = new_prev;
        if (new_prev == NULL)
            qcl->qcl_list_used = new->next;
        else
            new_prev->next = new->next;
    }

    /* Insert new entry in list */
    if (ins_prev == NULL) {
        new->next = qcl->qcl_list_used;
        qcl->qcl_list_used = new;
    } else {
        new->next = ins_prev->next;
        ins_prev->next = new;
    }
    new->qce = *qce;

    return ht_qcl_commit(qcl_id);
}

/* Delete QCE */
vtss_rc vtss_ll_qce_del(vtss_qcl_id_t  qcl_id,
                        vtss_qce_id_t  qce_id)
{
    vtss_qcl_t       *qcl;
    vtss_qcl_entry_t *cur, *prev;
    
    VTSS_D(("enter, qcl_id: %d, qce_id: %ld", qcl_id, qce_id));

    /* Check that the QCL ID is valid */
    if (qcl_id < VTSS_QCL_ID_START || qcl_id >= VTSS_QCL_ID_END) {
        VTSS_E(("illegal QCL ID: %d", qcl_id));
        return VTSS_INVALID_PARAMETER;
    }
  
    qcl = &vtss_api_state->qcl[qcl_id];
    
    for (cur = qcl->qcl_list_used, prev = NULL; cur != NULL; prev = cur, cur = cur->next) {
        if (cur->qce.id == qce_id) {
            VTSS_D(("Found existing ID %lu", qce_id));
            if (prev == NULL)
                qcl->qcl_list_used = cur->next;
            else
                prev->next = cur->next;
            cur->next = qcl->qcl_list_free;
            qcl->qcl_list_free = cur;
            break;
        }
    }
    return (cur == NULL ? VTSS_ENTRY_NOT_FOUND : ht_qcl_commit(qcl_id));
}
#endif /* VTSS_FEATURE_QCL_PORT */

#if defined(VTSS_ARCH_SPARX) && defined(VTSS_FEATURE_QOS_POLICER_MC_SWITCH) && defined(VTSS_FEATURE_QOS_POLICER_BC_SWITCH)
/* Calculate packet rate register field */
static ulong calc_packet_rate(vtss_packet_rate_t rate, ulong *unit)
{
    ulong value;

#if defined(VTSS_ARCH_SPARX_G8)
    /* Rate unit in chip is 1982 pps and LSB must be 1 */
    value = (rate/991);
    if (value > 255)
        value = 255;
    value |= 1;
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24) || defined(VTSS_ARCH_SPARX_28)
    ulong max;
#if defined(VTSS_ARCH_SPARX_28) 
    /* If the rate is greater than 1000 pps, the unit is kpps */
    max = (rate >= 1000 ? (rate/1000) : rate);
    *unit = (rate >= 1000 ? 0 : 1);
#else
    max = (rate/1000);
#endif /* VTSS_ARCH_SPARX_28 */
    for (value = 15; value != 0; value--) {
        if (max >= (1<<value))
            break;
    }
#endif /* VTSS_ARCH_SPARX_G24/SPARX_28 */
    return value;
}
#endif /* VTSS_ARCH_SPARX */

/* Set switch QoS setup */
vtss_rc vtss_ll_qos_setup_set(const vtss_qos_setup_t *qos)
{
#if defined(VTSS_FEATURE_QOS_WFQ_SWITCH)
    vtss_port_no_t port_no;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (!vtss_api_state->port_map.vtss_port_unused[port_no]) {
            VTSS_RC(vtss_ll_port_queue_setup(port_no));
        }
    }
#endif /* VTSS_FEATURE_QOS_WFQ_SWITCH */

#if defined(VTSS_FEATURE_QOS_POLICER_MC_SWITCH) && defined(VTSS_FEATURE_QOS_POLICER_BC_SWITCH)
#if defined(VTSS_ARCH_SPARX_G8)
    HT_WR(ANALYZER, 0, STORMLIMIT,
          (MAKEBOOL01(qos->policer_bc != VTSS_PACKET_RATE_DISABLED)<<31) |
          (MAKEBOOL01(qos->policer_mc != VTSS_PACKET_RATE_DISABLED)<<30) |
          (MAKEBOOL01(qos->policer_uc != VTSS_PACKET_RATE_DISABLED)<<29) |
          (calc_packet_rate(qos->policer_bc, NULL)<<16) |
          (calc_packet_rate(qos->policer_mc, NULL)<<8) |
          (calc_packet_rate(qos->policer_uc, NULL)<<0)); 
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24) || defined(VTSS_ARCH_SPARX_28)
    {
        ulong unit_bc, unit_mc, unit_uc;

        HT_WRF(ANALYZER, 0, STORMLIMIT, 28, 0xf, 6); /* Burst of 64 frames allowed */
        HT_WRF(ANALYZER, 0, STORMLIMIT, 8, 0xf, calc_packet_rate(qos->policer_bc, &unit_bc));
        HT_WRF(ANALYZER, 0, STORMLIMIT, 4, 0xf, calc_packet_rate(qos->policer_mc, &unit_mc));
        HT_WRF(ANALYZER, 0, STORMLIMIT, 0, 0xf, calc_packet_rate(qos->policer_uc, &unit_uc));
        HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 2, 0x1,
               MAKEBOOL01(qos->policer_bc != VTSS_PACKET_RATE_DISABLED));
        HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 1, 0x1,
               MAKEBOOL01(qos->policer_mc != VTSS_PACKET_RATE_DISABLED));
        HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 0, 0x1,
               MAKEBOOL01(qos->policer_uc != VTSS_PACKET_RATE_DISABLED));
#if defined(VTSS_ARCH_SPARX_28)
        HT_WRF(ANALYZER, 0, STORMPOLUNIT, 2, 0x1, unit_bc);
        HT_WRF(ANALYZER, 0, STORMPOLUNIT, 1, 0x1, unit_mc);
        HT_WRF(ANALYZER, 0, STORMPOLUNIT, 0, 0x1, unit_uc);
#endif /* VTSS_ARCH_SPARX_28 */
    }
#endif /* VTSS_ARCH_SPARX_G24/SPARX_28 */
#endif /* VTSS_FEATURE_QOS_POLICER_MC_SWITCH && VTSS_FEATURE_QOS_POLICER_BC_SWITCH */

#if defined(VTSS_FEATURE_QOS_POLICER_CPU_SWITCH)
    {
        ulong              i, unit;
        vtss_packet_rate_t rate;
        
        for (i = 3; i < 6; i++) {
            rate = (i == 3 ? qos->policer_learn : 
                    i == 4 ? qos->policer_cat : qos->policer_mac);
            HT_WRF(ANALYZER, 0, STORMLIMIT, 4*i, 0xf, calc_packet_rate(rate, &unit));
            HT_WRF(ANALYZER, 0, STORMPOLUNIT, i, 0x1, unit);
            HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, i, 0x1, 
                   rate == VTSS_PACKET_RATE_DISABLED ? 0 : 1);
        }
    }
#endif /* VTSS_FEATURE_QOS_POLICER_CPU_SWITCH */

    return VTSS_OK;
}

/* Read port counters */
vtss_rc vtss_ll_port_counters_get(uint port_no, vtss_chip_counters_t * counters)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);
#if defined(VTSS_ARCH_HAWX)
    uint prio;
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_SPARX_28)

/* Counter base address */
#if defined(G_ROCX)
#define COUNTER_BASE 0x1800
#else
#define COUNTER_BASE 0x3000
#endif

    ulong value;
    
    /* Read Rx counters in 32-bit mode */
    HT_WR(PORT, port_on_chip, C_CNTADDR, (1<<31) | (COUNTER_BASE<<0));
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_octets);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_packets);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_rxbcmc */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_rxbadpkt */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_broadcasts);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_multicasts);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_64);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_65_127);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_128_255);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_256_511);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_512_1023);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_1024_1526);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_1527_max);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_pauses);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_drops);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_local_drops);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_classified_drops);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_crc_align_errors);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_shorts);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_longs);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_fragments);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_jabbers);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_rxctrl */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_rxgoodpkt */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_class[0]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_class[1]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_class[2]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_class[3]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_rxtotdrop */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->rx_unicast);

    /* Read Tx counters in 32-bit mode */
    HT_WR(PORT, port_on_chip, C_CNTADDR, (1<<31) | ((COUNTER_BASE+0x40)<<0));
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_octets);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_packets);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_txbcmc */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_txbadpkt */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_broadcasts);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_multicasts);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_64);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_65_127);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_128_255);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_256_511);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_512_1023);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_1024_1526);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_1527_max);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_pauses);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_fifo_drops);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_drops);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_collisions);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_txcfidrop */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_txgoodpkt */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_class[0]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_class[1]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_class[2]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_class[3]);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &value); /* c_txtotdrop */
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_unicast);
    HT_RD(PORT, port_on_chip, C_CNTDATA, &counters->tx_aging);
#else
    HT_RD(PORT, port_on_chip, C_RXOCT, &counters->rx_octets);
    HT_RD(PORT, port_on_chip, C_TXOCT, &counters->tx_octets);
#if defined(VTSS_ARCH_SPARX)
    HT_RD(PORT, port_on_chip, C_RX0, &counters->rx_packets);
#if defined(VTSS_ARCH_SPARX_G24)
    HT_RD(PORT, port_on_chip, C_RX1, &counters->rx_broadcasts);
    HT_RD(PORT, port_on_chip, C_RX2, &counters->rx_multicasts);
    HT_RD(PORT, port_on_chip, C_RX3, &counters->rx_drops);
    HT_RD(PORT, port_on_chip, C_RX4, &counters->rx_errors);
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_G8)
    HT_RD(PORT, port_on_chip, C_RX1, &counters->rx_drops);
    HT_RD(PORT, port_on_chip, C_RX2, &counters->rx_errors);
#endif /* VTSS_ARCH_SPARX_G8 */
    HT_RD(PORT, port_on_chip, C_TX0,&counters->tx_packets);
#if defined(VTSS_ARCH_SPARX_G24)
    HT_RD(PORT, port_on_chip, C_TX1, &counters->tx_broadcasts);
    HT_RD(PORT, port_on_chip, C_TX2, &counters->tx_multicasts);
    HT_RD(PORT, port_on_chip, C_TX3, &counters->tx_drops);
    HT_RD(PORT, port_on_chip, C_TX4, &counters->tx_errors);
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_G8)
    HT_RD(PORT, port_on_chip, C_TX1, &counters->tx_drops);
    HT_RD(PORT, port_on_chip, C_TX2, &counters->tx_errors);
#endif /* VTSS_ARCH_SPARX_G8 */
#else
    HT_RD(PORT, port_on_chip, C_RXDROP, &counters->rx_drops);
#if defined(HEATHROW2)
    /* Errata #5 (601). */
    counters->rx_drops -= vtss_api_state->rx_drops_when_cleared[port_no];
#endif /* HEATHROW2 */
    HT_RD(PORT, port_on_chip, C_RXPKT, &counters->rx_packets);
    HT_RD(PORT, port_on_chip, C_RXBC, &counters->rx_broadcasts);
    HT_RD(PORT, port_on_chip, C_RXMC, &counters->rx_multicasts);
    HT_RD(PORT, port_on_chip, C_RXCRC, &counters->rx_crc_align_errors);
    HT_RD(PORT, port_on_chip, C_RXSHT, &counters->rx_shorts);
    HT_RD(PORT, port_on_chip, C_RXLONG, &counters->rx_longs);
    HT_RD(PORT, port_on_chip, C_RXFRAG, &counters->rx_fragments);
    HT_RD(PORT, port_on_chip, C_RXJAB, &counters->rx_jabbers);
    HT_RD(PORT, port_on_chip, C_RX64, &counters->rx_64);
    HT_RD(PORT, port_on_chip, C_RX65, &counters->rx_65_127);
    HT_RD(PORT, port_on_chip, C_RX128, &counters->rx_128_255);
    HT_RD(PORT, port_on_chip, C_RX256, &counters->rx_256_511);
    HT_RD(PORT, port_on_chip, C_RX512, &counters->rx_512_1023);
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_RD(PORT, port_on_chip, C_RX1024, &counters->rx_1024_max);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    HT_RD(PORT, port_on_chip, C_RX1024, &counters->rx_1024_1526);
    HT_RD(PORT, port_on_chip, C_RXJUMBO, &counters->rx_1527_max);
#endif /* VTSS_ARCH_HAWX */
    HT_RD(PORT, port_on_chip, C_TXDROP, &counters->tx_drops);
    HT_RD(PORT, port_on_chip, C_TXPKT, &counters->tx_packets);
    HT_RD(PORT, port_on_chip, C_TXBC, &counters->tx_broadcasts);
    HT_RD(PORT, port_on_chip, C_TXMC, &counters->tx_multicasts);
    HT_RD(PORT, port_on_chip, C_TXCOL, &counters->tx_collisions);
    HT_RD(PORT, port_on_chip, C_TX64, &counters->tx_64);
    HT_RD(PORT, port_on_chip, C_TX65, &counters->tx_65_127);
    HT_RD(PORT, port_on_chip, C_TX128, &counters->tx_128_255);
    HT_RD(PORT, port_on_chip, C_TX256, &counters->tx_256_511);
    HT_RD(PORT, port_on_chip, C_TX512, &counters->tx_512_1023);
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_RD(PORT, port_on_chip, C_TX1024, &counters->tx_1024_max);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    HT_RD(PORT, port_on_chip, C_TX1024, &counters->tx_1024_1526);
    HT_RD(PORT, port_on_chip, C_TXJUMBO, &counters->tx_1527_max);
#endif /* VTSS_ARCH_HAWX */
    HT_RD(PORT, port_on_chip, C_TXOVFL, &counters->tx_fifo_drops);
#if defined(HEATHROW2)
    /* Errata #6 (631). */
    counters->tx_fifo_drops -= vtss_api_state->tx_fifo_drops_when_cleared[port_no];
#endif /* HEATHROW2 */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_RD(PORT, port_on_chip, C_RXLP, &counters->rx_low_priority);
    HT_RD(PORT, port_on_chip, C_RXHP, &counters->rx_high_priority);
    HT_RD(PORT, port_on_chip, C_TXLP, &counters->tx_low_priority);
    HT_RD(PORT, port_on_chip, C_TXHP, &counters->tx_high_priority);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_HAWX)
    HT_RD(PORT, port_on_chip, C_RXPAUSE, &counters->rx_pauses);
    HT_RD(PORT, port_on_chip, C_TXPAUSE, &counters->tx_pauses);
    HT_RD(PORT, port_on_chip, C_RXCATDROP, &counters->rx_classified_drops);
#endif /* VTSS_ARCH_STANSTED/HAWX */
#if defined(VTSS_ARCH_HAWX)
    HT_RD(PORT, port_on_chip, C_RXBWDROP, &counters->rx_backward_drops);
    for (prio = 0; prio < VTSS_PRIOS; prio++) {
        HT_RD(PORT, port_on_chip, C_RXCLASS0+prio, &counters->rx_class[prio]);
        HT_RD(PORT, port_on_chip, C_TXCLASS0+prio, &counters->tx_class[prio]);
    }
#endif /* VTSS_ARCH_HAWX */
#endif /* !VTSS_ARCH_SPARX */
#endif /* VTSS_ARCH_SPARX_28 */

    return VTSS_OK;
}

#if defined(VTSS_FEATURE_VSTAX)
/* Setup VStaX for switch */
vtss_rc vtss_ll_vstax_setup_set(const vtss_vstax_setup_t * const setup)
{
    vtss_port_no_t port_no;
    
    /* Save setup */
    vtss_api_state->vstax_setup = *setup;

    /* Setup UPSID for all ports enabled for VStaX */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        VTSS_RC(vtss_ll_vlan_port_mode_set(port_no, &vtss_api_state->vlan_port_table[port_no]));
    }

    return VTSS_OK;
}

/* Setup VStaX for port */
vtss_rc vtss_ll_vstax_port_setup_set(const vtss_port_no_t                  port_no,
                                     const vtss_vstax_port_setup_t * const setup)
{
    vtss_port_no_t port;
    uint           i, enabled, port_on_chip = 0;
    vtss_vid_t     vid;
    ulong          mask;

    enabled = (setup->enable ? 1 : 0);

    if (enabled != vtss_api_state->vstax_port_setup[port_no].enable) {
        /* VStaX enabled/disabled, setup all VLANs */
        vtss_api_state->vstax_port_setup[port_no] = *setup;
        for (vid = VTSS_VID_DEFAULT; vid < VTSS_VIDS; vid++) {
            VTSS_RC(vtss_ll_vlan_table_write(vid, vtss_api_state->vlan_table[vid].member));
        }
    }

    /* Setup port and possibly aggregated port */
    for (i = 0; i < 2; i++) {
        if (i == 0)
            port = port_no;
        else {
#if VTSS_OPT_INT_AGGR
            port = vtss_int_aggr_port_no(port_on_chip);
#else
            port = 0;
#endif
        }
        if (port == 0)
            break;

        if ((port_on_chip = HT_CHIP_PORT(port)) < VTSS_CHIP_PORT_AGGR_0) {
            VTSS_E(("illegal VStaX port_no: %d", port_no)); 
            return VTSS_INVALID_PARAMETER;
        }

        /* Save port setup */
        vtss_api_state->vstax_port_setup[port] = *setup;
        
        mask = (1 << port_on_chip);
        HT_WRM(PORT, port_on_chip, STACKCFG, 
               (1<<11) | (1<<10) | (1<<9) | (1<<8) | (1<<6) | (1<<5),
               (0<<11) |
               (1<<10) |
               ((enabled && setup->mirror ? 1 : 0)<<9) |
               ((mask & VTSS_OPT_STACK_B_MASK ? 1 : 0)<<8) |
               (enabled<<6) |
               (enabled<<5));

        if (mask & VTSS_OPT_STACK_A_MASK)
            HT_WR(ANALYZER, 0, STACKPORTSA, enabled ? VTSS_OPT_STACK_A_MASK : 0);
        if (mask & VTSS_OPT_STACK_B_MASK)
            HT_WR(ANALYZER, 0, STACKPORTSB, enabled ? VTSS_OPT_STACK_B_MASK : 0);
        
        HT_WR(PORT, port_on_chip, MAXLEN, 
              vtss_api_state->setup[port].maxframelength + enabled*VTSS_VSTAX_HDR_SIZE);
        
        /* Disable ACLs for VStaX ports */
        HT_WRF(PORT, port_on_chip, MISCCFG, 2, 0x1, enabled ? 0 : 1);
    }
    
    /* Setup QoS for port (including aggregated port) */
    VTSS_RC(vtss_ll_port_qos_setup_set(port_no, &vtss_api_state->qos[port_no]));

    /* Setup VLAN for port (including aggregated port) */
    VTSS_RC(vtss_ll_vlan_port_mode_set(port_no, &vtss_api_state->vlan_port_table[port_no]));
    
    /* Setup mirror ports (including aggregated port) */
    VTSS_RC(vtss_ll_mirror_port_set(vtss_api_state->mirror_port));

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_VSTAX */

/* Set aggregation mode */
vtss_rc vtss_ll_aggr_mode_set(const vtss_aggr_mode_t *mode)
{
#if defined(VTSS_FEATURE_AGGR_MODE_ADV)
    ulong          value;
    vtss_port_no_t port_no;
    uint           port_on_chip;

    /* Setup analyzer */
#if defined(VTSS_ARCH_SPARX_28)
    value = (((mode->random ? 1 : 0)<<3) |
             ((mode->sip_dip_enable || mode->sport_dport_enable ? 1 : 0)<<2) |
             ((mode->dmac_enable ? 1 : 0)<<1) |
             ((mode->smac_enable ? 1 : 0)<<0));
#else
    if (mode->sip_dip_enable || mode->sport_dport_enable) {
        if (mode->smac_enable || mode->dmac_enable) {
            /* SMAC XOR DMAC XOR IPINFO selected */
            value = AGGRCNTL_MODE_SMAC_DMAC_IP;
        } else {
            /* IPINFO selected */
            value = AGGRCNTL_MODE_IP;
        }
    } else {
        value = 0;
        if (mode->smac_enable) {
            /* SMAC included */
            value |= AGGRCNTL_MODE_SMAC;
        }
        if (mode->dmac_enable) {
            /* DMAC included */
            value |= AGGRCNTL_MODE_DMAC;
        }
        if (value==0) {
            /* All fields disabled, select IPINFO */
            value = AGGRCNTL_MODE_IP;
        }
    }
#if defined(VTSS_FEATURE_AGGR_MODE_RANDOM)
    /* Random mode takes precedence, if enabled */
    if (mode->random
#if defined(VTSS_ARCH_HAWX)
        && vtss_api_state->hawx_b
#endif /* VTSS_ARCH_HAWX */
        ) {
        value = AGGRCNTL_MODE_PSEUDORANDOM;
    }
#endif /* VTSS_FEATURE_AGGR_MODE_RANDOM */
#endif /* VTSS_ARCH_SPARX_28 */
    HT_WR(ANALYZER, 0, AGGRCNTL, value);

    /* Setup categorizer */
    value = 0;
    if (mode->sip_dip_enable) {
        /* SIP/DIP included */
        value |= (1<<1);
    }
    if (mode->sport_dport_enable) {
        /* SPORT/DPORT included */
        value |= (1<<0);
    }
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_on_chip = HT_CHIP_PORT(port_no);
        HT_WRF(PORT, port_on_chip, CAT_OTHER_CFG, 0, 0x3, value);
#if VTSS_OPT_INT_AGGR
        /* Setup internally aggregated port */
        if (vtss_int_aggr_port_no(port_on_chip) != 0) {
            HT_WRF(PORT, port_on_chip + 1, CAT_OTHER_CFG, 0, 0x3, value);
        }
#endif /* VTSS_OPT_INT_AGGR */
    }
#else
    HT_WR(ANALYZER, 0, AGGRCNTL, 
          ((mode->smac_enable ? 1 : 0)<<0) |
          ((mode->dmac_enable ? 1 : 0)<<1));
#endif

    return VTSS_OK;
}

#if defined(VTSS_FEATURE_FILTER_SIP)
vtss_rc vtss_ll_filter_sip_set(const vtss_port_no_t port_no,
                               const vtss_ip_t      sip,
                               const vtss_ip_t      mask)
{
    uint  port_on_chip;
    ulong i, width;
    
    /* Count number of bits set in mask and check that mask is contiguous */
    width = 0;
    for (i = 0; i < 32; i++) {
        if (mask & (1<<(31-i))) {
            if (i != width) {
                VTSS_E(("illegal mask: 0x%08lx",mask));
                return VTSS_INVALID_PARAMETER;
            }
            width++;
        }
    }

    /* Mask 255.255.255.254 can not be supported, use 255.255.255.252 instead */
    if (width == 31)
        width = 30;
    
    /* Mask 255.255.255.255 uses width 31 */
    if (width == 32)
        width = 31;

    port_on_chip = HT_CHIP_PORT(port_no);
    HT_WR(PORT, port_on_chip, SIPCONF, (0<<5) | (width<<0));
    HT_WR(PORT, port_on_chip, SIPADDR, sip);
    
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_FILTER_SIP */

#if defined(VTSS_FEATURE_FILTER_UDP_TCP)
vtss_rc vtss_ll_filter_udp_tcp_set(const vtss_filter_action_t * const action,
                                   const vtss_udp_tcp_t               port_1,
                                   const vtss_udp_tcp_t               port_2)
{
    HT_WRF(ANALYZER, 0, CAPENAB, 20, 0x3, 
           action->forward ? (action->cpu ? 1 : 0) : (action->cpu ? 2 : 3));
    HT_WR(ANALYZER, 0, TCPUDP_PORTS, (port_2<<16) | (port_1<<0)); 

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_FILTER_UDP_TCP */

/* ================================================================= *
 * ================================================================= *
 * = CPU Frame Extraction ========================================== *
 * ================================================================= *
 * ================================================================= */

/* Enable/disable frame ready interrupt */
vtss_rc vtss_ll_frame_rx_ready_int(vtss_cpu_rx_queue_t queue_no, BOOL enable)
{
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_WRF(SYSTEM, 0, CPUCTRL, 1, 0x1, enable ? 1 : 0);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    ulong offset = ((vtss_api_state->hawx_b ? 9 : 5)+queue_no-VTSS_CPU_RX_QUEUE_START);
    HT_WRF(SYSTEM, 0, CAPCTRL, offset, 0x1, enable ? 1 : 0);
#endif /* VTSS_ARCH_HAWX */
    return VTSS_OK;
}

#if (VTSS_CPU_RX_QUEUES>1)
/* Setup Rx queue map */
vtss_rc vtss_ll_cpu_rx_queue_map_set(vtss_cpu_rx_queue_map_t * const map)
{
#if defined(VTSS_ARCH_HAWX)
    vtss_port_no_t port_no;
    uint           port_on_chip;
    ulong          value,mask;

    if (vtss_api_state->hawx_b) {
        /* Setup CAT_CPU_QUEUE queues for all ports */
        value = (((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<12) |
                 ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<10) |
                 ((map->arp_bc_queue-VTSS_CPU_RX_QUEUE_START)<<8) |
                 ((map->ip_bc_queue-VTSS_CPU_RX_QUEUE_START)<<6) |
                 ((map->garp_queue-VTSS_CPU_RX_QUEUE_START)<<2) |
                 ((map->bpdu_queue-VTSS_CPU_RX_QUEUE_START)<<0));
        
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (HT_CHIP_PORT(port_no)<0)
                continue;
            port_on_chip = HT_CHIP_PORT(port_no);
            HT_WR(PORT, port_on_chip, CAT_CPU_QUEUE, value);
        }
        
        /* Setup CAPCTRL queues */
        value = (((map->learn_queue-VTSS_CPU_RX_QUEUE_START)<<2) |
                 ((map->mac_vid_queue-VTSS_CPU_RX_QUEUE_START)<<0));
        mask = ((0x3<<2) | (0x3<<0));
    } else {
        /* Setup CAT_CPU_MISC queues for all ports */
        value = (((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<14) |
                 ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<12) |
                 ((map->arp_bc_queue-VTSS_CPU_RX_QUEUE_START)<<10) |
                 ((map->ip_bc_queue-VTSS_CPU_RX_QUEUE_START)<<8) |
                 ((map->garp_queue-VTSS_CPU_RX_QUEUE_START)<<1) |
                 ((map->bpdu_queue-VTSS_CPU_RX_QUEUE_START)<<0));
        mask = ((1<<14) | (1<<12) | (1<<10) | (1<<8) | (1<<1) | (1<<0));
        
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            if (HT_CHIP_PORT(port_no)<0)
                continue;
            port_on_chip = HT_CHIP_PORT(port_no);
            HT_WRM(PORT, port_on_chip, CAT_CPU_MISC, mask, value);
        }
        
        /* Setup CAPCTRL queues */
        value = ((map->mac_vid_queue-VTSS_CPU_RX_QUEUE_START)<<0);
        mask = (0x1<<0);
    }
    HT_WRF(SYSTEM, 0, CAPCTRL, 0, mask, value);
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_G8)
    HT_WRM(SYSTEM, 0, CAPCTRL,
           ((map->arp_bc_queue-VTSS_CPU_RX_QUEUE_START)<<18) |
           ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<17) | 
           ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<16) |
           ((map->garp_queue-VTSS_CPU_RX_QUEUE_START)<<14) |
           ((map->bpdu_queue-VTSS_CPU_RX_QUEUE_START)<<13),
           (1<<18) | (1<<17) | (1<<16) | (1<<15) | (1<<14) | (1<<13));
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24)
    HT_WR(ANALYZER, 0, CAPQUEUE,
	  ((map->arp_bc_queue-VTSS_CPU_RX_QUEUE_START)<<26) |
	  ((map->arp_bc_queue-VTSS_CPU_RX_QUEUE_START)<<25) |
	  ((map->arp_bc_queue-VTSS_CPU_RX_QUEUE_START)<<24) |
	  (0<<23) |         /* Source IP */
	  ((map->udp_tcp_queue-VTSS_CPU_RX_QUEUE_START)<<22) |
	  ((map->learn_queue-VTSS_CPU_RX_QUEUE_START)<<21) |
	  ((map->mac_vid_queue-VTSS_CPU_RX_QUEUE_START)<<20) |
	  ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<19) | 
	  ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<18) |
	  (0<<17) |         /* 01-80-C2-00-00-10 */
	  ((map->bpdu_queue-VTSS_CPU_RX_QUEUE_START)<<16) |
          ((map->garp_queue == VTSS_CPU_RX_QUEUE_START ? 0x0000 : 0xFFFF)<<0));
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
    ulong i, value = 0;
    
    HT_WR(ANALYZER, 0, CAPQUEUE,
          ((map->learn_queue-VTSS_CPU_RX_QUEUE_START)<<12) |
          ((map->mac_vid_queue-VTSS_CPU_RX_QUEUE_START)<<10) |
          ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<8) |
          ((map->ipmc_ctrl_queue-VTSS_CPU_RX_QUEUE_START)<<6) |
          ((map->igmp_queue-VTSS_CPU_RX_QUEUE_START)<<4) |
          (0<<2) | /* 01-80-C2-00-00-10 */
          ((map->bpdu_queue-VTSS_CPU_RX_QUEUE_START)<<0));

    for (i = 0; i < 16; i++) {
        value |= ((map->garp_queue-VTSS_CPU_RX_QUEUE_START)<<(i*2));
    }
    HT_WR(ANALYZER, 0, CAPQUEUEGARP, value);
#endif /* VTSS_ARCH_SPARX_28 */
    return VTSS_OK;
}

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
/* Set Rx queue size */
vtss_rc vtss_ll_cpu_rx_queue_size_set(const vtss_cpu_rx_queue_t queue_no, 
                                      const vtss_cpu_rx_queue_size_t size)
{
#if defined(VTSS_ARCH_HAWX)
    vtss_cpu_rx_queue_t q;
    uint                q_size[VTSS_CPU_RX_QUEUES], sum;

    /* HawX-A does not support setting up queue sizes */
    if (!vtss_api_state->hawx_b)
        return VTSS_UNSPECIFIED_ERROR;

    /* Save queue size state */
    vtss_api_state->rx_queue_size[queue_no-VTSS_CPU_RX_QUEUE_START] = (size/1024);
    
    /* Assign queue sizes, limiting the sum to 32 kB */
    for (q = 0, sum = 0; q < VTSS_CPU_RX_QUEUES; q++) {
        q_size[q] = vtss_api_state->rx_queue_size[q]/2; /* Unit is 2kB */
        if ((q_size[q] + sum) > 16)
            q_size[q] = (16 - sum);
        sum += q_size[q];
    }
    HT_WRM(SYSTEM, 0, CAPCTRL, 
           (q_size[3]<<21) | (q_size[2]<<17) | (q_size[1]<<13), 
           (0xF<<21) | (0xF<<17) | (0xF<<13));
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_28)
    HT_WRF(PORT, VTSS_CHIP_PORT_CPU, Q_EGRESS_WM, 
           (queue_no-VTSS_CPU_RX_QUEUE_START)*8, 0x1F, size/2048);
#endif /* VTSS_ARCH_SPARX_28 */
    return VTSS_OK;
}
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
#endif /* VTSS_CPU_RX_QUEUES>1 */

/* Set frame registration */
vtss_rc vtss_ll_frame_reg_set(const vtss_cpu_rx_registration_t *reg)
{
    vtss_port_no_t port_no;
    uint           port_on_chip;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_on_chip = HT_CHIP_PORT(port_no);
        if (port_on_chip >= 0) {
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
            HT_WRM(PORT, port_on_chip, CATCONF, 
                   ((reg->mcast_igmp_cpu_only ? 1 : 0)<<22) |
                   ((reg->bpdu_cpu_only ? 1 : 0)<<21) |
                   ((reg->bcast_iparp_cpu_copy ? 1 : 0)<<19) |
                   ((reg->ipmc_ctrl_cpu_copy ? 1 : 0)<<17),
                   (1<<22) | (1<<21) | (1<<19) | (1<<17));
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
            
#if defined(VTSS_ARCH_HAWX)
            ulong value;
            int   i;
            
            value = 0;
            for (i = 0; i < 16; i++) {
                value |= ((reg->bpdu_cpu_only[i] ? 1 : 0)<<i);
                value |= ((reg->garp_cpu_only[i] ? 1 : 0)<<(i+16));
            }
            HT_WR(PORT, port_on_chip, CAT_CPU_8021D_DMAC, value);
            
            HT_WR(PORT, port_on_chip, CAT_CPU_MISC, 
                  ((reg->bcast_ip_cpu_copy ? 1 : 0)<<9) |
                  ((reg->bcast_arp_cpu_copy ? 1 : 0)<<11) |
                  ((reg->ipmc_ctrl_cpu_copy ? 1 : 0)<<13) |
                  ((reg->mcast_igmp_cpu_only ? 1 : 0)<<15));
#endif /* VTSS_ARCH_HAWX */
        }
    }
#if defined(VTSS_ARCH_SPARX)
    {
        int   i;
        ulong value = 0;
        
        for (i = 0; i < 16; i++)
            value |= (MAKEBOOL01(reg->garp_cpu_only[i])<<i);

        value |= ((MAKEBOOL01(reg->bpdu_cpu_only)<<16) |
                  (MAKEBOOL01(reg->mcast_igmp_cpu_only)<<18));
#if defined(VTSS_ARCH_SPARX_G8)
        value |= ((MAKEBOOL01(reg->bcast_arp_cpu_copy)<<19) |
                  (MAKEBOOL01(reg->ipmc_ctrl_cpu_copy)<<20));
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24) || defined(VTSS_ARCH_SPARX_28)
        value |= (MAKEBOOL01(reg->ipmc_ctrl_cpu_copy)<<19);
#endif /* VTSS_ARCH_SPARX_G24 */

#if defined(SPARX_G5)
        if (vtss_api_state->g58_type == VTSS_LUTON_TYPE_R2) {
            value |= ((MAKEBOOL01(reg->bcast_ip_cpu_copy)<<21) |
                      (MAKEBOOL01(reg->mcast_mld_cpu_only)<<22));
        }
#endif /* SPARX-G5 */
#if defined(VTSS_ARCH_SPARX_G24)
        value |= ((MAKEBOOL01(reg->bcast_arp_cpu_copy_all)<<23) |
                  (MAKEBOOL01(reg->bcast_arp_cpu_copy_sel)<<25));
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
        value |= (MAKEBOOL01(reg->mcast_mld_cpu_only)<<20);
#endif /* VTSS_ARCH_SPARX_28 */
        
#if defined(VTSS_ARCH_SPARX_G24)
        /* Update all CAPENAB fields except UDP/TCP filter */
        HT_WRM(ANALYZER, 0, CAPENAB, value, 0xFFCFFFFF);

        /* Setup IP address for ARP filter 0 */
        HT_WR(ANALYZER, 0, ARP_IP0, reg->arp_ip);
#else
        /* Update all CAPENAB fields */
        HT_WR(ANALYZER, 0, CAPENAB, value);
#endif /* VTSS_ARCH_SPARX_G24 */
    }
#endif /* VTSS_ARCH_SPARX */
    return VTSS_OK;
}

#if defined(VTSS_FEATURE_VSTAX)
static void ht_ulong2frame(ulong data, uchar *frame)
{ 
    frame[0] = ((data>>24) & 0xff); 
    frame[1] = ((data>>16) & 0xff);
    frame[2] = ((data>>8) & 0xff);
    frame[3] = (data & 0xff);
}

vtss_rc vtss_ll_vstax_header_get(const vtss_port_no_t                 port_no,
                                 const vtss_vstax_tx_header_t * const vstax,
                                 uchar * const                        frame)
{
    ulong vsh1 = 0, vsh2 = 0;
    BOOL super = (vstax->prio == VTSS_PRIO_SUPER ? 1 : 0);
    uint port = (vstax->port_no ? HT_CHIP_PORT(vstax->port_no) : 0);
    
    VSH_PUT(vsh1, vsh2, SPRIO, super);
    VSH_PUT(vsh1, vsh2, IPRIO, 2*chip_prio(super ? (VTSS_PRIO_END - 1) : vstax->prio) + 1);
    VSH_PUT(vsh1, vsh2, TTL, vstax->ttl == VTSS_VSTAX_TTL_PORT ?
            vtss_api_state->vstax_port_setup[port_no].ttl : vstax->ttl);
    VSH_PUT(vsh1, vsh2, LRN_SKIP, 1);
    VSH_PUT(vsh1, vsh2, FWD_MODE, vstax->fwd_mode);
    if (vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_UID_PORT ||
        vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_CPU_UID)
        VSH_PUT(vsh1, vsh2, DST_UID, vstax->uid - VTSS_VSTAX_UID_START);
    if (vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_UID_PORT)
        VSH_PUT(vsh1, vsh2, DST_PORT, port);
    if (vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_CPU_UID ||
        vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_CPU_ALL)
        VSH_PUT(vsh1, vsh2, DST_PORT, vstax->queue_no - VTSS_CPU_RX_QUEUE_START);
    VSH_PUT(vsh1, vsh2, VID, vstax->tci.vid);
    VSH_PUT(vsh1, vsh2, CFI, vstax->tci.cfi);
    VSH_PUT(vsh1, vsh2, UPRIO, vstax->tci.tagprio);
    VSH_PUT(vsh1, vsh2, SRC_UID, 
            vtss_api_state->vstax_setup.uid - VTSS_VSTAX_UID_START);
    if (vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_CPU_UID ||
        vstax->fwd_mode == VTSS_VSTAX_FWD_MODE_CPU_ALL) {
        if (vstax->glag_no != 0) {
            VSH_PUT(vsh1, vsh2, SRC_MODE, 1);
            port = (vstax->glag_no - VTSS_GLAG_NO_START);
        }
        VSH_PUT(vsh1, vsh2, SRC_PORT, port);
    }
    
    ht_ulong2frame((ETYPE_VTSS<<16) | EPID_VSTAX, frame);
    ht_ulong2frame(vsh1, frame + 4);
    ht_ulong2frame(vsh2, frame + 8);
    
    return VTSS_OK;
}

static ulong ht_frame2ulong(const uchar *frame)
{
    return ((frame[0] << 24) | (frame[1] << 16) | (frame[2] << 8) | (frame[3] << 0));
}

static vtss_rc ht_vstax_header_put(ulong vsh0, ulong vsh1, ulong vsh2,
                                   vtss_vstax_rx_header_t *vstax_header)
{
    ulong src_port;
    
    vstax_header->valid = (vsh0 == ((ETYPE_VTSS<<16) | EPID_VSTAX) ? 1 : 0);
    vstax_header->uid = (VSH_GET(vsh1, vsh2, SRC_UID) + VTSS_VSTAX_UID_START);
    src_port = VSH_GET(vsh1, vsh2, SRC_PORT);
    if (VSH_GET(vsh1, vsh2, SRC_MODE)) {
        /* GLAG */
        vstax_header->port_no = 0;
        vstax_header->glag_no = (src_port + VTSS_GLAG_NO_START);
    } else {
        /* Port */
        vstax_header->port_no = vtss_api_state->port_map.vtss_port[src_port];
        vstax_header->glag_no = 0;
    }

    return VTSS_OK;
}

vtss_rc vtss_ll_vstax_header_put(const uchar * const            frame,
                                 vtss_vstax_rx_header_t * const vstax_header)
{
    return ht_vstax_header_put(ht_frame2ulong(frame + 0), /* VSH0 */
                               ht_frame2ulong(frame + 4), /* VSH1 */
                               ht_frame2ulong(frame + 8), /* VSH2 */
                               vstax_header);
}
#endif /* VTSS_FEATURE_VSTAX */    

/* Determine if a frame is ready in the CPU Rx queue */
/* Returns: 0: no frame ready, <0: error, >0: frame ready */
vtss_rc vtss_ll_frame_rx_ready(vtss_cpu_rx_queue_t queue_no)
{
#if VTSS_OPT_NICIO
    return vtss_io_nic_rx_ready();
#else
    ulong ready;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_RDF(SYSTEM, 0, CPUCTRL, 3, 0x1, &ready);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    ulong offset;
#if defined(VTSS_ARCH_HAWX)
    /* HawX-A only supports 2 queues */
    if (!vtss_api_state->hawx_b && (queue_no > 2))
        return 0;
    offset = (vtss_api_state->hawx_b ? 28 : 30);
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    offset = 30;
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_SPARX_28)
    offset = 28;
#endif /* VTSS_ARCH_SPARX_28 */
    HT_RDF(SYSTEM, 0, CAPCTRL, offset + queue_no-VTSS_CPU_RX_QUEUE_START, 0x1, &ready);
#endif /* VTSS_ARCH_HAWX/SPARX */
    return ready;
#endif /* VTSS_OPT_NICIO */
}

#if VTSS_OPT_NICIO
#define VTSS_NICIO_IFH_OFFSET_BYTES     (12)
#define VTSS_NICIO_IFH_LENGTH_BYTES     (8)
#define VTSS_NICIO_IFH_OFFSET           (VTSS_NICIO_IFH_OFFSET_BYTES / sizeof(ulong))
#define VTSS_NICIO_IFH_LENGTH           (VTSS_NICIO_IFH_LENGTH_BYTES / sizeof(ulong))
static ulong vtss_rx_frame_buffer[(VTSS_MAXFRAMELENGTH_MAX + VTSS_NICIO_IFH_LENGTH_BYTES) / sizeof(ulong)];
static BOOL vtss_rx_frame_valid = 0;

#ifndef SPARX_G24
static const char *str_macaddr(const unsigned char *macaddr)
{
    static char buf[32];
    int i;
    char *cp;

    cp = buf;
    for (i = 0; i < 6; i++) {
        sprintf(cp, "%02X-", macaddr[i]);
        cp += 3;
    }
    cp--;
    *cp = '\0';
    return buf;
}
#endif

#if 0
static void dump_frame(const uchar *frame, uint len)
{
    uint i;

    printf("Frame length %u\n", len);
    for (i = 0; i < len; i++) {
        if ((i & 0xF) == 0) {
            printf("\n%5d: ", i);
        }
        printf("%02X ", frame[i]);
    }
    printf("\n");
}
#endif
#else
static vtss_rc ht_cpurx_readbuffer(vtss_cpu_rx_queue_t queue_no, const uint addr, ulong *value)
{
    uint sub, offset;

#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    sub = (S_CAPTURE_DATA+(addr>>8));
    offset = (addr & 0xFF);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    sub = (S_CAPTURE_DATA+(queue_no-VTSS_CPU_RX_QUEUE_START)*2+(addr>>8));
    offset = (addr & 0xFF);
#endif /* VTSS_ARCH_HAWX/SPARX_G8/SPARX_G24 */

#if defined(VTSS_ARCH_SPARX_28)
    sub = (S_CAPTURE_DATA+(queue_no-VTSS_CPU_RX_QUEUE_START)*2);
    offset = 0; /* SparX-28 uses FIFO mode */
#endif /* VTSS_ARCH_SPARX_28 */
    HT_RD(CAPTURE, sub, FRAME_DATA + offset, value);
    return VTSS_OK;
}
#endif /* VTSS_OPT_NICIO */

static ulong ht_cpu_ulong_from_buffer(const uchar *const buffer) __VTSS_ATTRIB_CONST_FUNCTION__;
static ulong ht_cpu_ulong_from_buffer(const uchar *const buffer)
{
    return 
    ( buffer[0] << 24 ) |
    ( buffer[1] << 16 ) |
    ( buffer[2] <<  8 ) |
    ( buffer[3]       ) ;
}

static vtss_rc ht_cpurx_systemheader(vtss_cpu_rx_queue_t queue_no, 
                                     vtss_system_frame_header_t * const sys_header)
{
    ulong ifh0, ifh1;
#if !defined(VTSS_ARCH_SPARX_28)
    ulong cookie;
#endif /* VTSS_ARCH_SPARX_28 */
    
#if VTSS_OPT_NICIO
    if (!vtss_rx_frame_valid) {
        VTSS_RC(vtss_io_nic_rx((uchar * const)vtss_rx_frame_buffer, sizeof(vtss_rx_frame_buffer)));
        vtss_rx_frame_valid = 1;
    }
    {
        uchar *ifh = (uchar *) &vtss_rx_frame_buffer[VTSS_NICIO_IFH_OFFSET];
        /* Dig the ifh - endian aware */
        ifh0 = ht_cpu_ulong_from_buffer(ifh);
        ifh1 = ht_cpu_ulong_from_buffer(ifh + sizeof(ulong));
    }
#else
    VTSS_RC(ht_cpurx_readbuffer(queue_no, 0, &ifh0));
    VTSS_RC(ht_cpurx_readbuffer(queue_no, 1, &ifh1));
#endif /* VTSS_OPT_NICIO */

    sys_header->length = (IFH_GET(ifh0, ifh1, LENGTH) - VTSS_FCS_SIZE);
    sys_header->source_port_no = vtss_api_state->port_map.vtss_port[IFH_GET(ifh0, ifh1, PORT)];
    sys_header->arrived_tagged = IFH_GET(ifh0, ifh1, TAGGED);
    sys_header->tag.tagprio = IFH_GET(ifh0, ifh1, UPRIO);
    sys_header->tag.cfi = IFH_GET(ifh0, ifh1, CFI);
    sys_header->tag.vid = IFH_GET(ifh0, ifh1, VID);
#if !defined(VTSS_ARCH_SPARX_28)
#if defined(VTSS_ARCH_HAWX)
    cookie = (vtss_api_state->hawx_b ? IFH_GET(ifh0, ifh1, COOKIE_B) : 
              IFH_GET(ifh0, ifh1, COOKIE_A));
#else
    cookie = IFH_GET(ifh0, ifh1, COOKIE);
#endif /* VTSS_ARCH_HAWX */    
    
    /* Check cookie */
    if (cookie != CAP_COOKIE) {
        VTSS_E(("illegal cookie, ifh0: 0x%08lx, ifh1: 0x%08lx", ifh0, ifh1));
        return VTSS_DATA_NOT_READY;
    }
#endif /* VTSS_ARCH_SPARX_28 */
    
#if defined(VTSS_FEATURE_VSTAX)
    /* VStaX header is stripped, if present */
    sys_header->vstax.valid = IFH_GET(ifh0, ifh1, VSTAX);
    if (sys_header->vstax.valid && (sys_header->length >= VTSS_VSTAX_HDR_SIZE))
        sys_header->length -= VTSS_VSTAX_HDR_SIZE;
#endif /* VTSS_FEATURE_VSTAX */

    /* Check port */
    if (!VTSS_PORT_IS_PORT(sys_header->source_port_no)) {
        VTSS_E(("illegal portno %u ifh0: 0x%08lx, ifh1: 0x%08lx",
                sys_header->source_port_no, ifh0, ifh1));
        return VTSS_DATA_NOT_READY;
    }

    return VTSS_OK;
}

/* Get frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx(vtss_cpu_rx_queue_t queue_no, vtss_system_frame_header_t *sys_header,
                         uchar *frame, uint maxlength)
{
#if !VTSS_OPT_NICIO
    uint             w;
    uint             len;
    ulong            data;
    uint             addr=2;
#endif
#if defined(VTSS_ARCH_SPARX_28)
    vtss_packet_rx_t *packet;

    packet = &vtss_api_state->rx_packet[queue_no-VTSS_CPU_RX_QUEUE_START];
    if (packet->used) {
        /* Header has already been read, copy from API state */
        *sys_header = packet->sys_header;
    } else {
        /* Read header and copy to API state */
        VTSS_RC(ht_cpurx_systemheader(queue_no, sys_header));
        packet->used = 1;
        packet->sys_header = *sys_header;
    }
#else
    VTSS_RC(ht_cpurx_systemheader(queue_no, sys_header));
#endif /* VTSS_ARCH_SPARX_28 */

    /* Check if the application is just requesting the header */
    if (frame==NULL)
        return VTSS_PACKET_BUF_SMALL;

#if VTSS_OPT_NICIO
    if (maxlength < sys_header->length)
        return VTSS_PACKET_BUF_SMALL;
    /* Now we copy the frame, except we have to leave out the IFH in the middle */
    /* Note that the length has already been corrected to NOT contains the IFH */
    memcpy(frame, vtss_rx_frame_buffer, VTSS_NICIO_IFH_OFFSET_BYTES);
    memcpy(frame + VTSS_NICIO_IFH_OFFSET_BYTES,
           vtss_rx_frame_buffer + VTSS_NICIO_IFH_OFFSET + VTSS_NICIO_IFH_LENGTH,
           sys_header->length - VTSS_NICIO_IFH_OFFSET_BYTES);
    vtss_rx_frame_valid = 0;
    //VTSS_D(("RX port %u vid %u: dst %s type 0x%02X%02X\n",
            //sys_header->source_port_no, sys_header->tag.vid, str_macaddr(frame),
            //frame[12], frame[13]));
    return VTSS_OK;
#else
    len = (sys_header->length<maxlength) ? sys_header->length : maxlength;
    for (w = 0; w < (len+3)/4; w++) {
#if defined(VTSS_FEATURE_VSTAX)
        if (w == 3 && sys_header->vstax.valid) {
            /* Strip VStaX header */
            ulong vsh1, vsh2;

            VTSS_RC(ht_cpurx_readbuffer(queue_no, addr++, &data)); /* VSH0 (ignored) */
            VTSS_RC(ht_cpurx_readbuffer(queue_no, addr++, &vsh1)); /* VSH1 */
            VTSS_RC(ht_cpurx_readbuffer(queue_no, addr++, &vsh2)); /* VSH2 */
            VTSS_RC(ht_vstax_header_put(data, vsh1, vsh2, &sys_header->vstax));
        }
#endif /* VTSS_FEATURE_VSTAX */
        VTSS_RC(ht_cpurx_readbuffer(queue_no, addr++, &data));
        frame[w*4+0]=((data>>24) & 0xff);
        frame[w*4+1]=((data>>16) & 0xff);
        frame[w*4+2]=((data>>8) & 0xff);
        frame[w*4+3]=(data & 0xff);
    }

    if (maxlength<sys_header->length) {
#if defined(VTSS_ARCH_SPARX_28)
        VTSS_E(("Buffer too small"));
#endif /* VTSS_ARCH_SPARX_28 */
        return VTSS_PACKET_BUF_SMALL;
    }
#if defined(VTSS_ARCH_HAWX)
    if (!vtss_api_state->hawx_b) {
        /* Frame release for HawX-A */
        ulong rd_ptr, words2move, move;
        uint  offset, subblk_status, subblk_data;
        
        offset = (queue_no==VTSS_CPU_RX_QUEUE_START ? 0 : 2);
        subblk_status = (S_CAPTURE_STATUS_A + offset);
        subblk_data = (S_CAPTURE_DATA + offset);
        
        HT_RD(CAPTURE, subblk_status, CAPREADP, &rd_ptr);
        rd_ptr=(rd_ptr % 2048);
        
        words2move=((sys_header->length+8+4+7)/8);
        while (words2move) {
            move=words2move;
            if (rd_ptr==2047) {
                move=2049;
            } else if ((rd_ptr+words2move)>2047) {
                move=2047-rd_ptr;
            }
            VTSS_RC(ht_wr(B_CAPTURE, subblk_data, 0, (move>1 ? (move*8-15) : 0)<<16));
            HT_WR(CAPTURE, subblk_status, CAPREADP, 0);
            
            move=(move % 2048);
            words2move-=move;
            rd_ptr=((rd_ptr+move) % 2048);
        }
        return VTSS_OK;
    }
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_G8)
    if (vtss_api_state->g58_type == VTSS_LUTON_TYPE_BASIC) {
        /* Frame release for SparX-G5/G8 */
        ulong rd_ptr, frm_len, frm_words;
        uint  offset, subblk_status, subblk_data;
        
        offset = (queue_no==VTSS_CPU_RX_QUEUE_START ? 0 : 2);
        subblk_status = (S_CAPTURE_STATUS + offset);
        subblk_data = (S_CAPTURE_DATA + offset);

        HT_RD(CAPTURE, subblk_status, CAPREADP, &rd_ptr);
        rd_ptr=(rd_ptr % 1024);
        
        frm_len = (sys_header->length+4);
        frm_words = ((frm_len+8+7)/8);
        if ((rd_ptr + frm_words) >= 1024) {
            VTSS_RC(ht_wr(B_CAPTURE, subblk_data, 0, (frm_len+8192)<<16));
        }
    }
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_28)
#if defined(VTSS_FEATURE_VSTAX)
    if (sys_header->vstax.valid)
        w += (VTSS_VSTAX_HDR_SIZE/4);
#endif /* VTSS_FEATURE_VSTAX */
    packet->words_read = w;
#endif /* VTSS_ARCH_SPARX_28 */
    return vtss_ll_frame_rx_discard(queue_no);
#endif /* VTSS_OPT_NICIO */
}

/* Discard frame from CPU Rx queue */
vtss_rc vtss_ll_frame_rx_discard(vtss_cpu_rx_queue_t queue_no)
{
#if VTSS_OPT_NICIO
    vtss_rx_frame_valid = 0;
#else
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_WR(CAPTURE, S_CAPTURE_STATUS, CAPREADP, 0);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    uint sub;
#if defined(VTSS_ARCH_HAWX)
    sub = (vtss_api_state->hawx_b ? S_CAPTURE_STATUS_B : S_CAPTURE_STATUS_A);
#else
    sub = S_CAPTURE_STATUS;
#endif /* VTSS_ARCH_HAWX */
    HT_WR(CAPTURE, sub + (queue_no-VTSS_CPU_RX_QUEUE_START)*2, CAPREADP, 0);
#endif /* VTSS_ARCH_HAWX/SPARX_G8/SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
    vtss_packet_rx_t *packet;
    ulong            w, w_max, value;

    packet = &vtss_api_state->rx_packet[queue_no-VTSS_CPU_RX_QUEUE_START];
    if (packet->used) {
        
        /* Calculate number of words to read */
        w_max = (packet->sys_header.length+7)/4; /* Include FCS */
#if defined(VTSS_FEATURE_VSTAX)
        if (packet->sys_header.vstax.valid)
            w_max += (VTSS_VSTAX_HDR_SIZE/4); /* Include VStaX header */
#endif /* VTSS_FEATURE_VSTAX */
        if (w_max & 1)
            w_max++; /* Read even number of words */
        
        /* Read out rest of frame */
        for (w = packet->words_read; w < w_max; w++) {
            VTSS_RC(ht_cpurx_readbuffer(queue_no, 0, &value));
        }
        packet->used = 0;
        packet->words_read = 0;
    }
#endif /* defined(VTSS_ARCH_SPARX_28 */
#endif /* VTSS_OPT_NICIO */
    return VTSS_OK;
}

/* ================================================================= *
 * ================================================================= *
 * = CPU Frame Injection =========================================== *
 * ================================================================= *
 * ================================================================= */

static vtss_rc ht_cputx_autoupdate_crc(const BOOL enable)
{
    vtss_port_no_t port_no;
    uint           port_on_chip;

#if VTSS_OPT_NICIO
    ulong mask = (1<<2) | (1<<1);

    for (port_no = VTSS_PORT_NO_START; port_no <= VTSS_PORT_NO_END; port_no++)
#else
    ulong mask = (1<<1);

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
#endif /* !VTSS_OPT_NICIO */
    {
        port_on_chip = HT_CHIP_PORT(port_no);
        HT_WRM(PORT, port_on_chip, TXUPDCFG, enable ? mask : 0, mask);

#if VTSS_OPT_INT_AGGR
        if (vtss_int_aggr_port_no(port_on_chip) != 0) {
            /* Setup internally aggregated port */
            HT_WRM(PORT, port_on_chip + 1, TXUPDCFG, enable ? mask : 0, mask);
        }
#endif /* VTSS_OPT_INT_AGGR */
    }
    return VTSS_OK;
}

#if VTSS_OPT_NICIO
#define CHIP_VLAN_OFFSET 12
/* length is frame length (including header, but excluding checksum) in bytes */
/* Returns <0 if Flow Control in progress prevented enqueueing the frame into the FIFO */
vtss_rc vtss_ll_frame_tx(vtss_port_no_t port_no, const uchar *frame, uint length, vtss_vid_t vid)
{
    uchar localframe[VTSS_MAXFRAMELENGTH_MAX + 4];
    uchar *fp;

    //VTSS_D(("TX port %u vlan %u: dst %s type 0x%02X%02X len %u\n",
            //port_no, vid, str_macaddr(frame),
            //frame[CHIP_VLAN_OFFSET], frame[CHIP_VLAN_OFFSET + 1], length));
    memcpy(localframe, frame, CHIP_VLAN_OFFSET);
    fp = localframe + CHIP_VLAN_OFFSET;
    if (VTSS_PORT_IS_PORT(port_no)) {
        /* Insert Destination Port Tag */
        *fp++ = 0x81;
        *fp++ = 0x00;
        *fp++ = (7/*tagprio*/<<5) | (1/*cfi*/<<4); /* CFI bit set*/
        *fp++ = HT_CHIP_PORT(port_no);
    }
    else {
        /* port_no==0 */
        /* Let the switch decide egress ports */
    }
    if (vid != VTSS_VID_NULL) {
        /* Insert VLAN tag */
        *fp++ = 0x81;
        *fp++ = 0x00;
        *fp++ = (0/*tagprio*/<<5) | (0/*cfi*/<<4) | (vid>>8);
        *fp++ = vid & 0xFF;
    }
    length -= CHIP_VLAN_OFFSET;
    memcpy(fp, frame + CHIP_VLAN_OFFSET, length);
    fp += length;
    /* 12 bytes (DMAC+SMAC) have been moved from frame to prefix */
    return vtss_io_nic_tx(localframe, fp - localframe);
}
#undef CHIP_VLAN_OFFSET
#else

#define VTSS_CPUTX_WAIT_MAXRETRIES 1000000

static vtss_rc ht_wr_cputxdat_chipport(uint port_on_chip, const ulong value)
{
    uint  read_attempt=0;
    ulong pending;

    HT_WR(PORT, port_on_chip, CPUTXDAT, value);
    do {
        HT_RDF(PORT, port_on_chip, MISCSTAT, 8, 0x1, &pending);
        if (!pending)
            return VTSS_OK; /* Done */
    } while (read_attempt++<VTSS_CPUTX_WAIT_MAXRETRIES);

    /* Timeout, cancel transmission */
    HT_WR(PORT, port_on_chip, MISCFIFO, (1<<1) | MISCFIFO_TAILDROP);

    return VTSS_TIMEOUT_RETRYLATER;
}

/* Transmit frame on port, optionally with tag. Padding may be done */
vtss_rc vtss_ll_frame_tx(vtss_port_no_t port_no, const uchar *frame, 
                         uint length, vtss_vid_t vid
#if defined(VTSS_FEATURE_VSTAX)
                         , const vtss_vstax_tx_header_t *vstax
#endif /* VTSS_FEATURE_VSTAX */    
                         )
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    uint  w, addw, framelen;
    ulong ifh0 = 0, ifh1 = 0;

    /* Calculate and send IFH0 and IFH1 */
    addw = 1; /* CRC */
#if defined(VTSS_FEATURE_VSTAX)
    if (vstax != NULL) {
        addw += (VTSS_VSTAX_HDR_SIZE/4); /* VStaX header */
        vid = VTSS_VID_NULL;        /* Never insert VLAN tag */

        IFH_PUT(ifh0, ifh1, VSTAX, 1);
        if (port_on_chip >= VTSS_CHIP_PORT_AGGR_1) {
            IFH_PUT(ifh0, ifh1, STACK_B, 1);
        } else {
            IFH_PUT(ifh0, ifh1, STACK_A, 1);
        }
    }
#endif /* VTSS_FEATURE_VSTAX */    
    if (vid != VTSS_VID_NULL)
        addw++; /* VLAN tag */

    framelen = (length + addw*4);
    IFH_PUT(ifh0, ifh1, LENGTH, framelen < 64 ? 64 : framelen);

#if !defined(VTSS_ARCH_SPARX_28)
#if defined(VTSS_ARCH_HAWX)
    if (vtss_api_state->hawx_b)
        IFH_PUT(ifh0, ifh1, COOKIE_B, CAP_COOKIE)
    else
        IFH_PUT(ifh0, ifh1, COOKIE_A, CAP_COOKIE);
#else
    IFH_PUT(ifh0, ifh1, COOKIE, CAP_COOKIE);
#endif /* VTSS_ARCH_HAWX */
#endif /* VTSS_ARCH_SPARX_28 */

    VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, ifh0));
    VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, ifh1));

    /* Send frame data */
    for (w=0; w <= (length-1)/4; w++) {
        if (w==3) {
#if defined(VTSS_FEATURE_VSTAX)
            if (vstax != NULL) {
                /* Insert VStaX header */
                uchar vsh[VTSS_VSTAX_HDR_SIZE];
                ulong i;

                vtss_ll_vstax_header_get(port_no, vstax, vsh);
                for (i = 0; i < 3; i++) {
                    VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 
                                                    ht_cpu_ulong_from_buffer(&vsh[i*4])));
                }
            }
#endif /* VTSS_FEATURE_VSTAX */    
            if (vid != VTSS_VID_NULL) {
                /* Insert tag */
                VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 
                                                (0x8100<<16) | (0<<13) | (0<<12) | vid));
            }
        }
        VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 
                                        ht_cpu_ulong_from_buffer(&(frame[w*4]))));
    }

    /* Add padding when the frame is too short */
    w += addw;
    while (w < (64/4)) {
        VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 0));
        w++;
    }

    /* Add dummy CRC */
    VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 0));

    /* We must write an even number of longs, so write an extra */
    if (w & 1)
        VTSS_RC(ht_wr_cputxdat_chipport(port_on_chip, 0));

    /* Transmit data */
    HT_WR(PORT, port_on_chip, MISCFIFO, (1<<0) | MISCFIFO_TAILDROP);

    return VTSS_OK;
}
#endif /* VTSS_OPT_NICIO */

#if defined(VTSS_FEATURE_LEARN_PORT)
/* Set learn port mode */
vtss_rc vtss_ll_learn_port_mode_set(const vtss_port_no_t      port_no,
                                    vtss_learn_mode_t * const learn_mode)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    
#if defined(VTSS_ARCH_HAWX)
    if (!vtss_api_state->hawx_b)
        return VTSS_UNSPECIFIED_ERROR;
#endif /* VTSS_ARCH_HAWX */

    HT_WRF(ANALYZER, 0, LEARNDROP, port_on_chip, 0x1, learn_mode->discard);
    HT_WRF(ANALYZER, 0, LEARNAUTO, port_on_chip, 0x1, learn_mode->automatic);
    HT_WRF(ANALYZER, 0, LEARNCPU, port_on_chip, 0x1, learn_mode->cpu);
    
    if (!learn_mode->automatic) {
        /* Flush entries previously learned on port to avoid continous refreshing */
        HT_WRF(ANALYZER, 0, LERNMASK, port_on_chip, 0x1, 0);
        VTSS_RC(vtss_ll_mac_table_flush(1, port_no, 0, 0));
        VTSS_RC(ht_port_learn_set(port_no));
    }

#if VTSS_OPT_INT_AGGR
    {
        vtss_port_no_t port;

        if ((port = vtss_int_aggr_port_no(port_on_chip)) != 0) {
            /* Setup aggregated port */
            VTSS_RC(vtss_ll_learn_port_mode_set(port, learn_mode));
        }
    }
#endif /* VTSS_OPT_INT_AGGR */    

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_LEARN_PORT */ 

#if defined(VTSS_FEATURE_LEARN_SWITCH)
/* Set learn mode */
vtss_rc vtss_ll_learn_mode_set(vtss_learn_mode_t * const learn_mode)
{
    uint cpu_bit;

#if defined(VTSS_ARCH_HAWX)
    if (vtss_api_state->hawx_b)
        return VTSS_UNSPECIFIED_ERROR;
    cpu_bit = 26;
#else
    cpu_bit = 24;
#endif /* VTSS_ARCH_HAWX */

    HT_WRM(ANALYZER, 0, ADVLEARN,
           ((learn_mode->automatic ? 1 : 0)<<31) |
           ((learn_mode->discard ? 1 : 0)<<30) |
           ((learn_mode->cpu ? 1 : 0)<<cpu_bit),
           (1<<31) | (1<<30) | (1<<cpu_bit));
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_LEARN_SWITCH */ 

/* Set logical port mapping */
vtss_rc vtss_ll_pmap_table_write(vtss_port_no_t physical_port, vtss_port_no_t logical_port)
{
#if defined(VTSS_ARCH_SPARX_28)
    uint port_on_chip, lport;
    
#if defined(VTSS_FEATURE_VSTAX)
    /* Aggregated VStaX ports use individual port numbers */
    if (vtss_api_state->vstax_port_setup[physical_port].enable)
        logical_port = physical_port;
#endif /* VTSS_FEATURE_VSTAX */
    port_on_chip = HT_CHIP_PORT(physical_port);
    lport = HT_CHIP_PORT(logical_port);
#if defined(VTSS_FEATURE_AGGR_GLAG)
    {
        vtss_glag_no_t glag_no;
        glag_no = vtss_api_state->port_glag_no[physical_port];
        if (glag_no != 0)
            lport = (30+glag_no-VTSS_GLAG_NO_START);
    }
#endif /* VTSS_FEATURE_AGGR_GLAG */
    HT_WRF(PORT, port_on_chip, STACKCFG, 0, 0x1F, lport);
#if VTSS_OPT_INT_AGGR
    if ((physical_port = vtss_int_aggr_port_no(port_on_chip)) != 0) {
        /* Setup aggregated port */
        port_on_chip = HT_CHIP_PORT(physical_port);
        HT_WRF(PORT, port_on_chip, STACKCFG, 0, 0x1F, lport);
    }
#endif /* VTSS_OPT_INT_AGGR */    
#endif /* VTSS_ARCH_SPARX_28 */

    return VTSS_OK;
}

/* Set VLAN port mode */
vtss_rc vtss_ll_vlan_port_mode_set(vtss_port_no_t port_no, const vtss_vlan_port_mode_t *vlan_mode)
{
    uint       port_on_chip = HT_CHIP_PORT(port_no);
    ulong      value, mask;
    vtss_vid_t uvid;

    /* Ingress */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    HT_WRM(PORT, port_on_chip, CATPVID, 
           (vlan_mode->pvid<<20) | (vlan_mode->pvid<<4), (0xFFF<<20) | (0xFFF<<4));
    HT_WRM(PORT, port_on_chip, CATCONF,
           ((vlan_mode->aware ? 0 : 1)<<30) |
           ((vlan_mode->aware ? 0 : 1)<<25) |
           ((vlan_mode->frame_type == VTSS_VLAN_FRAME_TAGGED ? 1 : 0)<<23),
           (1<<30) | (1<<25) | (1<<23));
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
    HT_WRM(PORT, port_on_chip, CAT_VLAN_AB, 
           (vlan_mode->pvid<<16) | (vlan_mode->pvid<<0), (0xFFF<<16) | (0xFFF<<0));
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX)
    value = vlan_mode->pvid;
#if defined(VTSS_FEATURE_VSTAX)
    /* If VStaX is enabled, the PVID field is used for this purpose */
    if (vtss_api_state->vstax_port_setup[port_no].enable)
        value = (((vtss_api_state->vstax_setup.uid - VTSS_VSTAX_UID_START)<<0) |
                 (vtss_api_state->vstax_port_setup[port_no].ttl<<5));
#endif /* VTSS_FEATURE_VSTAX */    
    HT_WRF(PORT, port_on_chip, CAT_PORT_VLAN, 0, 0xFFF, value);
#endif /* VTSS_ARCH_SPARX */

#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
    HT_WRM(PORT, port_on_chip, CAT_VLAN_MISC, 
           ((vlan_mode->aware ? 0 : 1)<<8) |
           ((vlan_mode->aware ? 0 : 1)<<7),
           (1<<8) | (1<<7));
    HT_WRM(PORT, port_on_chip, CAT_DROP, 
           ((vlan_mode->frame_type == VTSS_VLAN_FRAME_TAGGED ? 1 : 0)<<2) |
           ((vlan_mode->frame_type == VTSS_VLAN_FRAME_UNTAGGED ? 1 : 0)<<1),
           (1<<2) | (1<<1));
#endif /* VTSS_ARCH_HAWX/SPARX */

#if defined(VTSS_FEATURE_VLAN_INGR_FILTER_PORT)
    HT_WRF(ANALYZER, 0, VLANMASK, port_on_chip, 0x1, vlan_mode->ingress_filter ? 1 : 0);
#endif /* VTSS_FEATURE_VLAN_INGR_FILTER_PORT */

    /* Egress */
    uvid = vlan_mode->untagged_vid;
#if defined(VTSS_FEATURE_VSTAX)
    /* If VStaX is enabled, everything is sent untagged */
    if (vtss_api_state->vstax_port_setup[port_no].enable)
        uvid = VTSS_VID_ALL;
#endif /* VTSS_FEATURE_VSTAX */    
    value = (((vlan_mode->untagged_vid & 0xFFF)<<4) |
             ((uvid != VTSS_VID_ALL && uvid != VTSS_VID_NULL ? 1 : 0)<<3) |
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
             (1<<2) |
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
             (uvid != VTSS_VID_ALL ? 1 : 0)<<0);
    mask = ((0xFFF<<4) | 
            (1<<3)  |
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
            (1<<2) |
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
            (1<<0));
    HT_WRM(PORT, port_on_chip, TXUPDCFG, value, mask);
    
#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(port_on_chip)) != 0) {
        /* Setup aggregated port */
        VTSS_RC(vtss_ll_vlan_port_mode_set(port_no, vlan_mode));
    }
#endif /* VTSS_OPT_INT_AGGR */    

    return VTSS_OK;
}

/* ================================================================= *
 * ================================================================= *
 * = VLAN Table ==================================================== *
 * ================================================================= *
 * ================================================================= */

static vtss_rc ht_vlan_table_idle(void)
{
    ulong cmd;

    while (1) {
        HT_RDF(ANALYZER, 0, VLANACES, 0, 0x3, &cmd);
        if (cmd == VLAN_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

/* Set VLAN port members */
vtss_rc vtss_ll_vlan_table_write(vtss_vid_t vid, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t    port_no;
    BOOL              port_member[VTSS_PORT_ARRAY_SIZE], mirror = 0;
    vtss_mstp_entry_t *mstp_entry;
    ulong             value;

    /* Lookup MSTP entry */
    mstp_entry = &vtss_api_state->mstp_table[vtss_api_state->vlan_table[vid].msti];
    
    /* Enable mirror port if egress mirroring enabled on a member port */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_member[port_no] = (member[port_no] && 
                                mstp_entry->state[port_no] == VTSS_MSTP_STATE_FORWARDING);
        if (port_member[port_no] && vtss_api_state->mirror_egress[port_no])
            mirror = 1;
#if defined(VTSS_FEATURE_VSTAX)
        if (vtss_api_state->vstax_port_setup[port_no].enable)
            port_member[port_no] = 1;
#endif /* VTSS_FEATURE_VSTAX */    
    }
#if !defined(VTSS_ARCH_SPARX_28)
    if (mirror)
        port_member[vtss_api_state->mirror_port] = 1;
#endif /* VTSS_ARCH_SPARX_28 */    
    
    value = (vid<<0);
#if defined(VTSS_FEATURE_ISOLATED_PORT)
    value |= ((vtss_api_state->vlan_table[vid].isolated ? 1 : 0)<<15);
#endif /* VTSS_FEATURE_ISOLATED_PORT */
    HT_WR(ANALYZER, 0, VLANTINDX, value);

    HT_WR(ANALYZER, 0, VLANACES, 
          (vtss_chip_port_bitfield(port_member)<<2) |
          (VLAN_CMD_WRITE<<0));

    return ht_vlan_table_idle();
}

/* Clear VLAN table (by default all ports are members of all VLANs) */
static vtss_rc ht_vlan_table_clear(void)
{
    vtss_vid_t vid;

    VTSS_D(("enter"));

    for (vid = VTSS_VID_NULL; vid < VTSS_VIDS; vid++) {
        HT_WR(ANALYZER, 0, VLANTINDX, vid<<0);
        HT_WR(ANALYZER, 0, VLANACES, VLAN_CMD_WRITE<<0);
        VTSS_RC(ht_vlan_table_idle());
    }
    return VTSS_OK;
}

/* Set VLAN MSTP instance */
vtss_rc vtss_ll_vlan_table_mstp_set(vtss_vid_t vid, uint msti)
{
    VTSS_D(("vid: %d, msti: %d", vid, msti));

    /* Update VLAN entry */
    return vtss_ll_vlan_table_write(vid, vtss_api_state->vlan_table[vid].member);
}

/* Set MSTP state for port and mstp instance */
vtss_rc vtss_ll_mstp_table_write(vtss_port_no_t port_no, vtss_msti_t msti, 
                                 vtss_mstp_state_t state)
{
    vtss_vid_t        vid;
    vtss_vlan_entry_t *vlan_entry;
    
    VTSS_D(("port_no: %d, msti: %d", port_no, msti));

    /* Update all VLANs mapping to MSTI */
    for (vid = VTSS_VID_NULL; vid < VTSS_VIDS; vid++) {
        vlan_entry = &vtss_api_state->vlan_table[vid];
        if (vlan_entry->enabled && vlan_entry->msti == msti)
            VTSS_RC(vtss_ll_vlan_table_write(vid, vlan_entry->member));
    }
    return VTSS_OK;
}

#if defined(VTSS_FEATURE_ISOLATED_PORT)
/* Set isolated ports */
vtss_rc vtss_ll_isolated_ports_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;
    BOOL           port_member[VTSS_PORT_ARRAY_SIZE];

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        port_member[port_no] = (member[port_no] ? 0 : 1); 
    
    HT_WR(ANALYZER, 0, PVLAN_MASK, 
          vtss_chip_port_bitfield(port_member) | (1<<VTSS_CHIP_PORT_CPU));

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_ISOLATED_PORT */

/* ================================================================= *
 * ================================================================= *
 * = MAC Table ===================================================== *
 * ================================================================= *
 * ================================================================= */

static vtss_rc ht_mac_table_idle(void)
{
    ulong cmd;
    
    while (1) {
        HT_RDF(ANALYZER, 0, MACACCES, 0, 0x7, &cmd);
        if (cmd == MAC_CMD_IDLE)
            break;
    }
    return VTSS_OK;
}

#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
/* Set MAC address age time */
vtss_rc vtss_ll_mac_table_age_time_set(vtss_mac_age_time_t age_time)
{
    vtss_mac_age_time_t time;
    
    /* Scan two times per age time */
    time = age_time/2;
    if (time > 0xfffff)
        time = 0xfffff;
    HT_WR(ANALYZER, 0, AUTOAGE, time);
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */

/* Age MAC address table */
vtss_rc vtss_ll_mac_table_age(BOOL pgid_age, vtss_pgid_no_t pgid_no, 
                              BOOL vid_age, vtss_vid_t vid)
{
    uint pgid = (pgid_age ? vtss_chip_pgid(pgid_no) : 0);

    HT_WR(ANALYZER, 0, ANAGEFIL,
          ((pgid_age ? 1 : 0)<<31) | 
          (pgid<<16) |
          ((vid_age ? 1 : 0)<<15) |
          (vid<<0));
    HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_TABLE_AGE<<0);
    VTSS_RC(ht_mac_table_idle());

#if VTSS_OPT_INT_AGGR
    if (pgid_age && (pgid_no = vtss_int_aggr_port_no(pgid)) != 0) {
        /* Age aggregated port */
        VTSS_RC(vtss_ll_mac_table_age(pgid_age, pgid_no, vid_age, vid));
    }
#endif /* VTSS_OPT_INT_AGGR */

    return VTSS_OK;
}

/* Flush MAC address table */
vtss_rc vtss_ll_mac_table_flush(BOOL pgid_age, vtss_pgid_no_t pgid_no, 
                                BOOL vid_age, vtss_vid_t vid)
{
    /* Age twice instead of flushing. 
       This ensures that sticky bit for aged entries is updated */ 
    VTSS_RC(vtss_ll_mac_table_age(pgid_age, pgid_no, vid_age, vid));
    return vtss_ll_mac_table_age(pgid_age, pgid_no, vid_age, vid);
}

/* Learn (VID, MAC) */
/* Note: Uses pgid_no, doesn't use entry->destination list. */
vtss_rc vtss_ll_mac_table_learn(const vtss_mac_table_entry_t *entry, vtss_pgid_no_t pgid_no)
{
    ulong mach,macl;
    uint  pgid = 0, locked, aged, fwd_kill = 0, ipv6_mask = 0;
    
    /* Calculate MACH/MACL registers */
    mach = ((entry->vid_mac.vid<<16) |
            (entry->vid_mac.mac.addr[0]<<8) |
            (entry->vid_mac.mac.addr[1]<<0));
    macl = ((entry->vid_mac.mac.addr[2]<<24) |
            (entry->vid_mac.mac.addr[3]<<16) |
            (entry->vid_mac.mac.addr[4]<<8) |
            (entry->vid_mac.mac.addr[5]<<0));
    
#if defined(VTSS_ARCH_SPARX) || defined(VTSS_ARCH_HAWX)
    if (pgid_no == VTSS_PGID_NONE) {
        /* IPv4/IPv6 multicast entry */
        ulong mask;
        
        locked = 1;
        aged = 1;
        mask = vtss_chip_port_bitfield(vtss_api_state->pgid_table[pgid_no].member); 
        if (entry->vid_mac.mac.addr[0] == 0x01) {
            /* IPv4 multicast entry */
#if defined(VTSS_ARCH_SPARX_G8)
            if (vtss_api_state->g58_type < VTSS_LUTON_TYPE_R2) {
                /* Gnats 4756 workaround */
                vtss_ll_mac_table_unlearn(&entry->vid_mac);
            }
#endif /* VTSS_ARCH_SPARX_SPARX_G8 */

#if defined(VTSS_ARCH_SPARX_G24) || defined(VTSS_ARCH_SPARX_28)
            /* Encode port mask directly */
            macl = ((macl & 0x00FFFFFF) | ((mask<<24) & 0xFF000000));
            mach = ((mach & 0xFFFF0000) | ((mask>>8) & 0x0000FFFF));
            pgid = ((mask>>24) & 0xF);
#endif /* VTSS_ARCH_SPARX_G24/SPARX_28 */
        } else {
            /* IPv6 multicast entry */
            fwd_kill = 1;
#if defined(VTSS_ARCH_SPARX_28)
            /* Encode port mask directly */
            mach = ((mach & 0xFFFF0000) | (mask & 0x0000FFFF));
            pgid = ((mask>>16) & 0x3F);
            ipv6_mask = ((mask>>22) & 0x3F);
#endif /* VTSS_ARCH_SPARX_28 */
        }
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8)
        /* Encode port mask in IP multicast register */
        HT_WR(ANALYZER, 0, IPMCACCESS, (1<<31) | (fwd_kill<<30) | mask);
#endif /* VTSS_ARCH_HAWX/SPARX_G8 */    

    } else
#endif /* VTSS_ARCH_SPARX/HAWX */
    {
        /* Not IP multicast entry */
        pgid = vtss_chip_pgid(pgid_no);
        locked = entry->locked;
        aged = 0;
    }
    HT_WR(ANALYZER, 0, MACHDATA,mach);
    HT_WR(ANALYZER, 0, MACLDATA,macl);
    HT_WR(ANALYZER, 0, MACACCES,
          (ipv6_mask<<16) |
          (MAKEBOOL01(entry->copy_to_cpu)<<14) |
          (fwd_kill<<13) |      /* forward kill */
          (0<<12) |             /* Ignore VLAN */
          (MAKEBOOL01(aged)<<11) |
          (1<<10) |             /* Valid */
          (MAKEBOOL01(locked)<<9) |
          (pgid<<3) |
          (MAC_CMD_LEARN<<0));
    
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8)
    if (pgid_no == VTSS_PGID_NONE) {
        /* Disable IP multicast mode again */
        HT_WR(ANALYZER, 0, IPMCACCESS, 0);
    }
#endif /* VTSS_ARCH_HAWX/SPARX_G8 */    
    return ht_mac_table_idle();
}

/* Unlearn (VID, MAC) */
vtss_rc vtss_ll_mac_table_unlearn(const vtss_vid_mac_t *vid_mac)
{
    uint locked = 0, aged = 0, fwd_kill = 0;
    
#if defined(VTSS_ARCH_SPARX) || defined(VTSS_ARCH_HAWX)
    if (
#if defined(VTSS_ARCH_HAWX)
        vtss_api_state->hawx_b &&
#endif /* VTSS_ARCH_HAWX */
        VTSS_MAC_IPV4_MC(vid_mac->mac.addr)) {
        /* IPv4 multicast */
        locked = 1;
    } 
#if defined(SPARX_G5) || defined(VTSS_ARCH_SPARX_28)
    if (
#if defined(SPARX_G5)
        vtss_api_state->g58_type == VTSS_LUTON_TYPE_R2 &&
#endif /* SPARX_G5 */
        VTSS_MAC_IPV6_MC(vid_mac->mac.addr)) {
        /* IPv6 multicast */
        locked = 1;
        fwd_kill = 1;
    }
#endif /* SPARX_G8/VTSS_ARCH_SPARX_28 */
    if (locked) {
        aged = 1;
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8)
        HT_WR(ANALYZER, 0, IPMCACCESS, (1<<31) | (fwd_kill<<30));
#endif /* VTSS_ARCH_HAWX/SPARX_G8 */
    }
#endif /* VTSS_ARCH_SPARX/HAWX */    

    HT_WR(ANALYZER,0, MACHDATA,
          (vid_mac->vid        <<16) |
          (vid_mac->mac.addr[0]<< 8) |
          (vid_mac->mac.addr[1]<< 0));
    HT_WR(ANALYZER, 0, MACLDATA,
          (vid_mac->mac.addr[2]<<24) |
          (vid_mac->mac.addr[3]<<16) |
          (vid_mac->mac.addr[4]<<8) |
          (vid_mac->mac.addr[5]<<0));
    HT_WR(ANALYZER, 0, MACACCES, 
          (fwd_kill<<13) |
          (MAKEBOOL01(aged)<<11) |
          (MAKEBOOL01(locked)<<9) |
          MAC_CMD_FORGET<<0);
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8)
    if (locked) {
        /* Disable IP multicast mode again */
        HT_WR(ANALYZER, 0, IPMCACCESS, 0);
    }
#endif /* VTSS_ARCH_HAWX/SPARX_G8 */
    return ht_mac_table_idle();
}

/* Note: Updates pgid_no, doesn't update entry->destination list. */
/* Note: Leaves entry and pgid_no unchanged if result not valid. */
static vtss_rc ht_get_mac_table_result(vtss_mac_table_entry_t * const entry,
                                       vtss_pgid_no_t * const pgid_no)
{
    ulong value, mach, macl;
    uint  pgid;
    
    HT_RD(ANALYZER, 0, MACACCES, &value);

    /* Check if entry is valid */
    if (!(value & (1<<10))) 
        return VTSS_ENTRY_NOT_FOUND;

    entry->copy_to_cpu = MAKEBOOL01(value & (1<<14));
    entry->aged        = MAKEBOOL01(value & (1<<11));
    entry->locked      = MAKEBOOL01(value & (1<<9));
    pgid = ((value>>3) & 0x3F);

    HT_RD(ANALYZER, 0, MACHDATA, &mach);
    HT_RD(ANALYZER, 0, MACLDATA, &macl);

#if defined(VTSS_ARCH_SPARX) || defined(VTSS_ARCH_HAWX)
    if (entry->locked && 
#if defined(VTSS_ARCH_HAWX)
        vtss_api_state->hawx_b &&
#endif /* VTSS_ARCH_HAWX */
        entry->aged) {
        /* IPv4/IPv6 multicast address */
        ulong          mask;
        vtss_port_no_t port_no;

        *pgid_no = VTSS_PGID_NONE;

        /* Read encoded port mask and update address registers */
        if (value & (1<<13)) {
            /* IPv6 entry (FWD_KILL set) */
            mask = ((((value>>16) & 0x3F)<<22) | (pgid<<16) | (mach & 0xFFFF));
            mach = ((mach & 0xFFFF0000) | 0x00003333);
        } else {
            /* IPv4 entry */
            mask = ((pgid<<24) | ((mach<<8) & 0xFFFF00) | ((macl>>24) & 0xFF));
            mach = ((mach & 0xFFFF0000) | 0x00000100);
            macl = ((macl & 0x00FFFFFF) | 0x5E000000);
        }    

        /* Convert port mask */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            vtss_api_state->pgid_table[*pgid_no].member[port_no] = 
                MAKEBOOL01(mask & (1 << vtss_api_state->port_map.chip_port[port_no]));
        }
    } else
#endif /* VTSS_ARCH_SPARX/HAWX */
    {
        *pgid_no = vtss_pgid(pgid);
    }
    entry->vid_mac.vid = ((mach>>16) & 0xFFF);
    entry->vid_mac.mac.addr[0] = ((mach>>8) & 0xFF);
    entry->vid_mac.mac.addr[1] = ((mach>>0) & 0xFF);
    entry->vid_mac.mac.addr[2] = ((macl>>24) & 0xFF);
    entry->vid_mac.mac.addr[3] = ((macl>>16) & 0xFF);
    entry->vid_mac.mac.addr[4] = ((macl>>8) & 0xFF);
    entry->vid_mac.mac.addr[5] = ((macl>>0) & 0xFF);

    return VTSS_OK;
}

/* Note: Updates pgid_no, doesn't update entry->destination list. */
/* Note: index is different than in datasheet. The API uses the
 *       two LSBits for bucket and the MSBits for line in the MAC table. */
static vtss_rc ht_mac_table_read(uint index_on_chip,
                                 vtss_mac_table_entry_t * const entry,
                                 vtss_pgid_no_t * const pgid_no,
                                 BOOL shadow)
{
    HT_WR(ANALYZER, 0, MACTINDX,
          (shadow                        <<13) |
          ((index_on_chip&0x3)/*bucket*/ <<11) |
          ((index_on_chip>>2)/*index*/   << 0) );
    HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_READ<<0);
    VTSS_RC(ht_mac_table_idle());

    return ht_get_mac_table_result(entry, pgid_no);
}

/* Lookup (VID, MAC) */
/* Note: Updates pgid_no, doesn't update entry->destination list. */
vtss_rc vtss_ll_mac_table_lookup(vtss_mac_table_entry_t *entry, vtss_pgid_no_t *pgid_no)
{
    uint                   vid = entry->vid_mac.vid;
    uchar                  *mac = &entry->vid_mac.mac.addr[0];
    uint                   bucket;
    vtss_mac_table_entry_t try_entry;
    vtss_pgid_no_t         try_pgid_no;
    
    ulong mach = (((vid & 0x3F)<<16) | (mac[0]<<8) | (mac[1]<<0));
    ulong macl = ((mac[2]<<24) | (mac[3]<<16) | (mac[4]<<8) | mac[5]);
    uint hash4 = 4*(((mach>>12) & 0x7FF) ^
                    ((mach>>1) & 0x7FF) ^
                    (((mach<<10) & 0x400) | ((macl>>22) & 0x3FF)) ^
                    ((macl>>11) & 0x7FF) ^
                    (macl & 0x7FF));

    for (bucket = 0; bucket < 4; bucket++) {
        /* Note: idx is different than in datasheet. The API uses the
         *       two LSBits for bucket and the MSBits for line in the MAC table. */
        VTSS_RC(ht_mac_table_read(hash4 | bucket, &try_entry, &try_pgid_no, 1));
        if (try_entry.vid_mac.vid == vid &&
            try_entry.vid_mac.mac.addr[0] == mac[0] &&
            try_entry.vid_mac.mac.addr[1] == mac[1] &&
            try_entry.vid_mac.mac.addr[2] == mac[2] &&
            try_entry.vid_mac.mac.addr[3] == mac[3] &&
            try_entry.vid_mac.mac.addr[4] == mac[4] &&
            try_entry.vid_mac.mac.addr[5] == mac[5]) {
            *entry = try_entry;
            *pgid_no = try_pgid_no;
            return VTSS_OK;
        }
    }
    return VTSS_ENTRY_NOT_FOUND;
}

/* Direct MAC read */
/* Note: index is different than in datasheet. The API uses the
 *       two LSBits for bucket and the MSBits for line in the MAC table. */
vtss_rc vtss_ll_mac_table_read(uint index, vtss_mac_table_entry_t *entry, 
                               vtss_pgid_no_t *pgid_no)
{
    return ht_mac_table_read(index-VTSS_MAC_ADDR_START,entry,pgid_no,0/*shadow*/);
}

/* Get next */
vtss_rc vtss_ll_mac_table_get_next(const vtss_vid_mac_t *vid_mac, vtss_mac_table_entry_t *entry,
                                   vtss_pgid_no_t *pgid_no)
{
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_28)
    HT_WR(ANALYZER, 0, ANAGEFIL, 0);
    HT_WR(ANALYZER, 0, MACHDATA,
          (vid_mac->vid<<16) |
          (vid_mac->mac.addr[0]<<8) |
          (vid_mac->mac.addr[1]<<0));
    HT_WR(ANALYZER, 0, MACLDATA,
          (vid_mac->mac.addr[2]<<24) |
          (vid_mac->mac.addr[3]<<16) |
          (vid_mac->mac.addr[4]<<8) |
          (vid_mac->mac.addr[5]<<0));
    HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_GET_NEXT<<0);
    VTSS_RC(ht_mac_table_idle());
    VTSS_RC(ht_get_mac_table_result(entry, pgid_no));
#endif /* VTSS_ARCH_HAWX/SPARX_28 */
    return VTSS_OK;
}

/* Get MAC table status */
vtss_rc vtss_ll_mac_table_status_get(vtss_mac_table_status_t *status) 
{
    ulong value;

    /* Read and clear sticky register */
    HT_RD(ANALYZER, 0, ANEVENTS, &value);
    HT_WR(ANALYZER, 0, ANEVENTS, value & ((1<<15) | (1<<16) | (1<<17) | (1<<20)));
    
    /* Detect learn events */
    status->learned = ((value & (1<<16)) ? 1 : 0);
    
    /* Detect replace events */
    status->replaced = ((value & (1<<17)) ? 1 : 0);

    /* Detect port move events */
    status->moved = ((value & (1<<15)) ? 1 : 0);
    
    /* Detect age events */
    status->aged = ((value & (1<<20)) ? 1 : 0);

    return VTSS_OK;
}

/* Write PGID entry */
vtss_rc vtss_ll_pgid_table_write(vtss_pgid_no_t pgid_no, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    vtss_port_no_t port_no;
    BOOL           port_member[VTSS_PORT_ARRAY_SIZE], mirror = 0;
    ulong          mask;
    uint           pgid;

    /* Enable mirror port if egress mirroring enabled on a member port */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_member[port_no] = member[port_no];
        if (member[port_no] && vtss_api_state->mirror_egress[port_no])
            mirror = 1;
    }
#if !defined(VTSS_ARCH_SPARX_28)
    if (mirror)
        port_member[vtss_api_state->mirror_port] = 1;
#endif /* VTSS_ARCH_SPARX_28 */
    
    mask = vtss_chip_port_bitfield(port_member);
#if defined(VTSS_FEATURE_AGGR_GLAG)
    if (pgid_no == VTSS_PGID_GLAG_SRC || pgid_no == (VTSS_PGID_GLAG_SRC + 1)) {
        /* Include CPU port in GLAG source masks */
        mask |= (1<<VTSS_CHIP_PORT_CPU);
    }
#endif /* VTSS_FEATURE_AGGR_GLAG */
    pgid = vtss_chip_pgid(pgid_no);
    HT_WR(ANALYZER, 0, DSTMASKS + pgid, mask);

#if VTSS_OPT_INT_AGGR
    /* Update mask for internally aggregated chip port */
    if (vtss_int_aggr_port_no(pgid) != 0) {
        HT_WR(ANALYZER, 0, DSTMASKS + pgid + 1, mask);
    }
#endif /* VTSS_OPT_INT_AGGR */

    return VTSS_OK;
}

/* Write source port entry */
vtss_rc vtss_ll_src_table_write(vtss_port_no_t port_no, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong value, mask;

    mask = (VTSS_CHIP_PORTMASK<<0);
#if defined(VTSS_ARCH_SPARX_28)
    mask |= (1<<(VTSS_CHIP_PORTS + 2)); /* Remove CPU copy flag */
#else
    /* If egress mirroring enabled and ingress mirroring disabled,
       forwarding to mirror port is disabled */
    if (vtss_api_state->mirror_egress[port_no] && !vtss_api_state->mirror_ingress[port_no])
        member[vtss_api_state->mirror_port] = 0;
#endif /* VTSS_ARCH_SPARX_28 */
    
    value = vtss_chip_port_bitfield(member);
    HT_WRM(ANALYZER, 0, SRCMASKS + port_on_chip, value, mask);
    
#if VTSS_OPT_INT_AGGR
    /* Update mask for internally aggregated chip port */
    if (vtss_int_aggr_port_no(port_on_chip) != 0) {
        HT_WRM(ANALYZER, 0, SRCMASKS + port_on_chip + 1, value, mask);
    }
#endif /* VTSS_OPT_INT_AGGR */    

    return VTSS_OK;
}

/* Set monitor port for mirroring */
vtss_rc vtss_ll_mirror_port_set(vtss_port_no_t port_no)
{
#if defined(VTSS_ARCH_SPARX_28)
    BOOL           member[VTSS_PORT_ARRAY_SIZE];
    vtss_port_no_t port;

    /* Calculate mirror ports */
    for (port = VTSS_PORT_NO_START; port < VTSS_PORT_NO_END; port++) {
        member[port] = (port == port_no ? 1 : 0);
#if defined(VTSS_FEATURE_VSTAX)
        /* Include VStaX ports enabled for mirroring */
        if (vtss_api_state->vstax_port_setup[port].enable &&
            vtss_api_state->vstax_port_setup[port].mirror)            
            member[port] = 1;
#endif /* VTSS_FEATURE_VSTAX */
    }
    HT_WR(ANALYZER, 0, MIRRORPORTS, vtss_chip_port_bitfield(member));
#else
    uint port_on_chip = HT_CHIP_PORT(port_no);

    HT_WRF(ANALYZER, 0, AGENCNTL, 0, 0x1f, port_on_chip);
#endif /* VTSS_ARCH_SPARX_28 */
    return VTSS_OK;
}

/* Enable/disable egress mirroring of port */
vtss_rc vtss_ll_dst_mirror_set(vtss_port_no_t port_no, BOOL enable)
{
#if defined(VTSS_ARCH_SPARX_28)
    uint port_on_chip = HT_CHIP_PORT(port_no);
    
    HT_WRF(ANALYZER, 0, EMIRRORMASK, port_on_chip, 0x1, enable ? 1 : 0);
#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(port_on_chip)) != 0) {
        /* Setup egress mirroring for aggregated port */
        HT_WRF(ANALYZER, 0, EMIRRORMASK, HT_CHIP_PORT(port_no), 0x1, enable ? 1 : 0);
    }
#endif /* VTSS_OPT_INT_AGGR */
    
    return VTSS_OK;
#else
    return VTSS_NOT_IMPLEMENTED;
#endif /* VTSS_ARCH_SPARX_28 */
}

/* Enable/disable ingress mirroring of port */
vtss_rc vtss_ll_src_mirror_set(vtss_port_no_t port_no, BOOL enable)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong offset;
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    offset = 24;
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    offset = 26;
#endif /* VTSS_ARCH_HAWX/SPARX_G8/SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
    offset = (VTSS_CHIP_PORTS + 1);
#endif /* VTSS_ARCH_SPARX_28 */

    HT_WRF(ANALYZER, 0, SRCMASKS + port_on_chip, offset, 0x1, enable ? 1 : 0);
#if VTSS_OPT_INT_AGGR
    /* Update mirror flag for internally aggregated chip port */
    if (vtss_int_aggr_port_no(port_on_chip) != 0) {
        HT_WRF(ANALYZER, 0, SRCMASKS + port_on_chip + 1, offset, 0x1, enable ? 1 : 0);
    }
#endif /* VTSS_OPT_INT_AGGR */    
    return VTSS_OK;
}

/* Write aggregation entry */
vtss_rc vtss_ll_aggr_table_write(vtss_ac_no_t ac, BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    ulong mask = vtss_chip_port_bitfield(member);

#if VTSS_OPT_INT_AGGR
    uint  i, port_base, port_next;

    for (i = 0; i < 2; i++) {
        port_base = (i == 0 ? VTSS_CHIP_PORT_AGGR_0 : VTSS_CHIP_PORT_AGGR_1);
    
        if (ac == VTSS_AC_START) {
            vtss_api_state->aggr_chip_port_next[i] = port_base;
        }
    
        /* Exclude one of the internally aggregated ports.
           It is supported that the two 5G ports can be aggregated. */
        if (mask & (1<<port_base)) {
            port_next = vtss_api_state->aggr_chip_port_next[i];
            mask &= ~(1<<port_next);
            vtss_api_state->aggr_chip_port_next[i] = (port_next == port_base ? 
                                                      (port_next + 1) : (port_next - 1));
        }
    }
#endif /* VTSS_OPT_INT_AGGR */

    HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, mask);

    return VTSS_OK;
}

static vtss_rc ht_ipmc_flood_mask_set(ulong mask)
{
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
    vtss_port_no_t port_no;
    uint           port_on_chip;
    BOOL           ipmc_mask_ena;
    
#if defined(VTSS_ARCH_STAPLEFORD) 
    /* Only use flood mask if zero */
    ipmc_mask_ena = MAKEBOOL01(mask == 0);
#else
    ipmc_mask_ena = 1;
#endif /* VTSS_ARCH_STAPLEFORD */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_on_chip = HT_CHIP_PORT(port_no);
        HT_WRF(PORT, port_on_chip, CATCONF, 20, 0x1, ipmc_mask_ena);
    }
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
    HT_WR(ANALYZER, 0, IFLODMSK, mask);

    return VTSS_OK;
}

/* Set IP Multicast flooding ports */
vtss_rc vtss_ll_ipmc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    return ht_ipmc_flood_mask_set(vtss_chip_port_bitfield(member));
}

#if defined(VTSS_FEATURE_CPU_RX_REG_MLD_ADV)
vtss_rc vtss_ll_ipv6_mc_flood_mask_set(const BOOL member[VTSS_PORT_ARRAY_SIZE])
{
    ulong mask;

    mask = vtss_chip_port_bitfield(member);

#if defined(SPARX_G5)
    if (vtss_api_state->g58_type != VTSS_LUTON_TYPE_R2)
        return VTSS_UNSPECIFIED_ERROR;
    mask |= (1<<31);
#endif /* SPARX_G5 */    

    HT_WR(ANALYZER, 0, I6FLODMSK, mask);
    return VTSS_OK;
}

vtss_rc vtss_ll_ipv6_mc_ctrl_flood_set(const BOOL scope)
{
    vtss_port_no_t port_no;
    uint           port_on_chip;

#if defined(SPARX_G5)
    if (vtss_api_state->g58_type != VTSS_LUTON_TYPE_R2)
        return VTSS_UNSPECIFIED_ERROR;
#endif /* SPARX_G5 */    
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_on_chip = HT_CHIP_PORT(port_no);
        HT_WRF(PORT, port_on_chip, CAT_OTHER_CFG, 3, 0x1, scope ? 1 : 0);
    }
    return VTSS_OK;
}
#endif /* VTSS_FEATURE_CPU_RX_REG_MLD_ADV */

#if defined(VTSS_FEATURE_ACL)
/* Apply ACL command */
static vtss_rc ht_acl_cmd(uint cmd, uint index)
{
    ulong busy;

    HT_WR(ACL, S_ACL, UPDATE_CTRL, 
          (0<<20) | 
          (1<<17) |
          ((index < VTSS_ACES ? 1 : 0)<<16) | 
          (index<<4) | 
          (cmd<<1) | 
          (1<<0));
    
    /* Wait until idle */
    while (1) {
        HT_RDF(ACL, S_ACL, UPDATE_CTRL, 0, 0x1, &busy);
        if (!busy)
            break;
    }
    return VTSS_OK;
}

#define VTSS_ACL_DUMP 1

#if VTSS_ACL_DUMP
static char *ht_acl_bits(char *p, const char *txt, ulong *data, int offset, int len)
{
    int   i, count = 0;
    ulong bit_mask;

    if (txt == NULL)
        p += sprintf(p, ".");
    else
        p += sprintf(p, " %s: ", txt);
    for (i = (len - 1); i >= 0; i--) {
        if (count && (count % 8) == 0) {
            *p = '.';
            p++;
        }
        count++;

        bit_mask = (1<<(offset+i));
        *p = ((data[1] & bit_mask) ? 'X' : (data[0] & bit_mask) ? '1' : '0'); 
        p++;
    }
    
    *p = 0;
    return p;
}

static vtss_rc ht_acl_dump(void)
{
    int              i;
    vtss_acl_entry_t *cur = NULL;
    ulong            valid, misc, redir, cnt, mask, status;
    char             buf[128], *p;
    
    for (i = (VTSS_ACES + VTSS_CHIP_PORTS); i >= 0; i--) {
        /* Read entry */
        VTSS_RC(ht_acl_cmd(ACL_CMD_READ, i));

        HT_RD(ACL, S_ACL, STATUS, &status);
        
        if (i == (VTSS_ACES + VTSS_CHIP_PORTS))
            sprintf(buf, "%3d (egress) ", i);
        else if (i < VTSS_ACES) {
            cur = (i == (VTSS_ACES - 1) ? vtss_api_state->acl_list : 
                   cur != NULL ? cur->next : NULL);
            sprintf(buf, "%3d (ace %d, id 0x%08lx)", 
                    i, VTSS_ACES - i - 1, cur == NULL ? 0 : cur->ace.id);
        } else
            sprintf(buf, "%3d (port %2d)", i, i - VTSS_ACES);
        if (status & (1<<4)) {
            /* Egress action */
            HT_RD(ACL, S_ACL, EG_VLD, &valid);
            HT_RD(ACL, S_ACL, EG_PORT_MASK, &mask);
            HT_RD(ACL, S_ACL, EG_CNT, &cnt);
            VTSS_D(("%s: %s 0x%08lx %ld", buf, valid ? "V" : "v", mask, cnt));
        } else {
            /* Ingress action */
            HT_RD(ACL, S_ACL, IN_VLD, &valid);
            HT_RD(ACL, S_ACL, IN_MISC_CFG, &misc);
            HT_RD(ACL, S_ACL, IN_REDIR_CFG, &redir);
            HT_RD(ACL, S_ACL, IN_CNT, &cnt);
            VTSS_D(("%s: %s %s %s (%ld) %s (%ld) %s %s, %s (%ld) %ld", 
                    buf, 
                    valid ? "V" : "v", 
                    misc & (1<<20) ? "H" : "h",
                    misc & (1<<12) ? "C" : "c",
                    (misc>>16) & 0x3,
                    misc & (1<<3) ? "P" : "p",
                    (misc>>4) & 0xf,
                    misc & (1<<1) ? "L" : "l",
                    misc & (1<<0) ? "F" : "f",
                    redir & (1<<0) ? "R" : "r",
                    (redir>>4) & 0x3f,
                    cnt));
        }
        
        /* Frame info */
        if (i < VTSS_ACES) {
            int   j;
            ulong type[2], offset;
            ulong misc[2], smac_hi[2], smac_lo[2], dmac_hi[2], dmac_lo[2];
            ulong etype[2], llc[2], snap_hi[2], snap_lo[2], l3_arp[2], l3_sip[8], l3_dip[2];
            ulong l3_misc[2], l4_port[2], l4_misc[2], l3_ip_hi[2], l3_ip_lo[2];

            /* Type value and mask (mask can not be read back - always zero) */
            type[0] = (status & 0x7);
            HT_RDF(ACL, S_ACL, UPDATE_CTRL, 20, 0x7, &type[1]);
            
            /* Read data and mask */
            for (j = 0; j < 2; j++) {
                offset = (j == 0 ? ACE_DATA_OFFS : ACE_MASK_OFFS);
                switch (type[0]) {
                case ACL_TYPE_ETYPE:
                    strcpy(buf, "ETYPE/ANY");
                    HT_RD(ACL, S_ACL, ETYPE_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, ETYPE_L2_SMAC_HIGH + offset, &smac_hi[j]);
                    HT_RD(ACL, S_ACL, ETYPE_L2_SMAC_LOW + offset, &smac_lo[j]);
                    HT_RD(ACL, S_ACL, ETYPE_L2_DMAC_HIGH + offset, &dmac_hi[j]);
                    HT_RD(ACL, S_ACL, ETYPE_L2_DMAC_LOW + offset, &dmac_lo[j]);
                    HT_RD(ACL, S_ACL, ETYPE_L2_ETYPE + offset, &etype[j]);
                    break;
                case ACL_TYPE_LLC:
                    strcpy(buf, "LLC");
                    HT_RD(ACL, S_ACL, LLC_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, LLC_L2_SMAC_HIGH + offset, &smac_hi[j]);
                    HT_RD(ACL, S_ACL, LLC_L2_SMAC_LOW + offset, &smac_lo[j]);
                    HT_RD(ACL, S_ACL, LLC_L2_DMAC_HIGH + offset, &dmac_hi[j]);
                    HT_RD(ACL, S_ACL, LLC_L2_DMAC_LOW + offset, &dmac_lo[j]);
                    HT_RD(ACL, S_ACL, LLC_L2_LLC + offset, &llc[j]);
                    break;
                case ACL_TYPE_SNAP:
                    strcpy(buf, "SNAP");
                    HT_RD(ACL, S_ACL, SNAP_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, SNAP_L2_SMAC_HIGH + offset, &smac_hi[j]);
                    HT_RD(ACL, S_ACL, SNAP_L2_SMAC_LOW + offset, &smac_lo[j]);
                    HT_RD(ACL, S_ACL, SNAP_L2_DMAC_HIGH + offset, &dmac_hi[j]);
                    HT_RD(ACL, S_ACL, SNAP_L2_DMAC_LOW + offset, &dmac_lo[j]);
                    HT_RD(ACL, S_ACL, SNAP_L2_SNAP_HIGH + offset, &snap_hi[j]);
                    HT_RD(ACL, S_ACL, SNAP_L2_SNAP_LOW + offset, &snap_lo[j]);
                    break;
                case ACL_TYPE_ARP:
                    strcpy(buf, "ARP");
                    HT_RD(ACL, S_ACL, ARP_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, ARP_L2_SMAC_HIGH + offset, &smac_hi[j]);
                    HT_RD(ACL, S_ACL, ARP_L2_SMAC_LOW + offset, &smac_lo[j]);
                    HT_RD(ACL, S_ACL, ARP_L3_ARP + offset, &l3_arp[j]);
                    HT_RD(ACL, S_ACL, ARP_L3_IPV4_DIP + offset, &l3_dip[j]);
                    HT_RD(ACL, S_ACL, ARP_L3_IPV4_SIP + offset, &l3_sip[j]);
                    break;
                case ACL_TYPE_UDP_TCP:
                    strcpy(buf, "UDP/TCP");
                    HT_RD(ACL, S_ACL, UDP_TCP_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, UDP_TCP_L3_MISC_CFG + offset, &l3_misc[j]);
                    HT_RD(ACL, S_ACL, UDP_TCP_L4_PORT + offset, &l4_port[j]);
                    HT_RD(ACL, S_ACL, UDP_TCP_L4_MISC + offset, &l4_misc[j]);
                    HT_RD(ACL, S_ACL, UDP_TCP_L3_IPV4_DIP + offset, &l3_dip[j]);
                    HT_RD(ACL, S_ACL, UDP_TCP_L3_IPV4_SIP + offset, &l3_sip[j]);
                    break;
                case ACL_TYPE_IPV4:
                    strcpy(buf, "IPv4");
                    HT_RD(ACL, S_ACL, IPV4_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, IPV4_L3_MISC_CFG + offset, &l3_misc[j]);
                    HT_RD(ACL, S_ACL, IPV4_DATA_0 + offset, &l3_ip_lo[j]);
                    HT_RD(ACL, S_ACL, IPV4_DATA_1 + offset, &l3_ip_hi[j]);
                    HT_RD(ACL, S_ACL, IPV4_L3_IPV4_DIP + offset, &l3_dip[j]);
                    HT_RD(ACL, S_ACL, IPV4_L3_IPV4_SIP + offset, &l3_sip[j]);
                    break;
                case ACL_TYPE_IPV6:
                    strcpy(buf, "IPv6");
                    HT_RD(ACL, S_ACL, IPV6_TYPE + offset, &misc[j]);
                    HT_RD(ACL, S_ACL, IPV6_L3_MISC_CFG + offset, &l3_misc[j]);
                    HT_RD(ACL, S_ACL, IPV6_L3_IPV6_SIP_0 + offset, &l3_sip[0+j]);
                    HT_RD(ACL, S_ACL, IPV6_L3_IPV6_SIP_1 + offset, &l3_sip[2+j]);
                    HT_RD(ACL, S_ACL, IPV6_L3_IPV6_SIP_2 + offset, &l3_sip[4+j]);
                    HT_RD(ACL, S_ACL, IPV6_L3_IPV6_SIP_3 + offset, &l3_sip[6+j]);
                    break;
                default:
                    VTSS_E(("illegal type: %ld", type[0]));
                    misc[0] = 0; /* Treat as invalid entry */
                    misc[1] = 0;
                    break;
                }
            }
            
            /* Skip invalid entries */
            if ((misc[0] & (1<<0)) == 0)
                continue;
            
            /* Type */
            p = &buf[strlen(buf)];
            p = ht_acl_bits(p, "type", type, 0, 3);
            VTSS_D((buf));
            
            /* Common fields */
            p = &buf[0];
            p = ht_acl_bits(p, "bc", misc, 29, 1);
            p = ht_acl_bits(p, "mc", misc, 28, 1);
            p = ht_acl_bits(p, "vid", misc, 12, 12);
            p = ht_acl_bits(p, "uprio", misc, 24, 3);
            p = ht_acl_bits(p, "cfi", misc, 2, 1);
            p = ht_acl_bits(p, "pag", misc, 4, ACL_PAG_WIDTH);
            p = ht_acl_bits(p, "igr", misc, 1, 1);
            p = ht_acl_bits(p, "vld", misc, 0, 1);
            VTSS_D((buf));

            if (type[0] <= ACL_TYPE_ARP) {
                p = &buf[0];
                p = ht_acl_bits(p, "smac", smac_hi, 0, 16);
                p = ht_acl_bits(p, NULL, smac_lo, 0, 32);
                VTSS_D((buf));
            }
            if (type[0] <= ACL_TYPE_SNAP) {
                p = &buf[0];
                p = ht_acl_bits(p, "dmac", dmac_hi, 0, 16);
                p = ht_acl_bits(p, NULL, dmac_lo, 0, 32);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_ETYPE) {
                p = &buf[0];
                p = ht_acl_bits(p, "etype", etype, 0, 16);
                p = ht_acl_bits(p, "data", etype, 16, 16);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_LLC) {
                p = &buf[0];
                p = ht_acl_bits(p, "llc", etype, 0, 32);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_SNAP) {
                p = &buf[0];
                p = ht_acl_bits(p, "snap", snap_hi, 0, 8);
                p = ht_acl_bits(p, NULL, snap_hi, 0, 32);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_ARP) {
                p = &buf[0];
                p = ht_acl_bits(p, "arp", l3_arp, 1, 1);
                p = ht_acl_bits(p, "req", l3_arp, 0, 1);
                p = ht_acl_bits(p, "unkn", l3_arp, 2, 1);
                p = ht_acl_bits(p, "s_match", l3_arp, 3, 1);
                p = ht_acl_bits(p, "d_match", l3_arp, 4, 1);
                p = ht_acl_bits(p, "len", l3_arp, 5, 1);
                p = ht_acl_bits(p, "ip", l3_arp, 6, 1);
                p = ht_acl_bits(p, "eth", l3_arp, 7, 1);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_UDP_TCP || type[0] == ACL_TYPE_IPV4) {
                p = &buf[0];
                p = ht_acl_bits(p, "proto", l3_misc, 12, 8);
                p = ht_acl_bits(p, "ds", l3_misc, 4, 8);
                p = ht_acl_bits(p, "options", l3_misc, 2, 1);
                p = ht_acl_bits(p, "fragment", l3_misc, 1, 1);
                p = ht_acl_bits(p, "ttl", l3_misc, 0, 1);
                VTSS_D((buf));
            }
            if (type[0] >= ACL_TYPE_ARP && type[0] <= ACL_TYPE_IPV4) {
                p = &buf[0];
                p = ht_acl_bits(p, "sip", l3_sip, 0, 32);
                VTSS_D((buf));
                p = &buf[0];
                p = ht_acl_bits(p, "dip", l3_dip, 0, 32);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_UDP_TCP) {
                p = &buf[0];
                p = ht_acl_bits(p, "sport", l4_port, 16, 16);
                p = ht_acl_bits(p, "dport", l4_port, 0, 16);
                VTSS_D((buf));
                p = &buf[0];
                p = ht_acl_bits(p, "fin", l4_misc, 13, 1);
                p = ht_acl_bits(p, "syn", l4_misc, 12, 1);
                p = ht_acl_bits(p, "rst", l4_misc, 11, 1);
                p = ht_acl_bits(p, "psh", l4_misc, 10, 1);
                p = ht_acl_bits(p, "ack", l4_misc, 9, 1);
                p = ht_acl_bits(p, "urg", l4_misc, 8, 1);
                p = ht_acl_bits(p, "range", l4_misc, 0, 8);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_IPV4) {
                p = &buf[0];
                p = ht_acl_bits(p, "data", l3_ip_hi, 0, 16);
                p = ht_acl_bits(p, NULL, l3_ip_lo, 0, 32);
                VTSS_D((buf));
            }
            if (type[0] == ACL_TYPE_IPV6) {
                p = &buf[0];
                ht_acl_bits(p, "sip", &l3_sip[6], 0, 32);
                VTSS_D((buf));
                ht_acl_bits(p, "sip", &l3_sip[4], 0, 32);
                VTSS_D((buf));
                ht_acl_bits(p, "sip", &l3_sip[2], 0, 32);
                VTSS_D((buf));
                ht_acl_bits(p, "sip", &l3_sip[0], 0, 32);
                VTSS_D((buf));
            }
        }
    }
    return VTSS_OK;
}
#endif /* VTSS_ACL_DUMP */

/* Setup action */
static vtss_rc ht_acl_action_set(const vtss_acl_action_t * action, ulong counter)
{
    HT_WR(ACL, S_ACL, IN_VLD, 1<<0);
    HT_WR(ACL, S_ACL, IN_MISC_CFG,
          ((action->cpu_once ? 1 : 0)<<20) |
          (((action->cpu || action->cpu_once) ? 
            (action->cpu_queue - VTSS_CPU_RX_QUEUE_START) : 0)<<16) | 
          ((action->cpu ? 1 : 0)<<12) |
          ((action->police ? (action->policer_no - VTSS_ACL_POLICER_NO_START) : 0)<<4) |
          ((action->police ? 1 : 0)<<3) |
          ((action->learn ? 1 : 0)<<1) |
          ((action->forward ? 1 : 0)<<0));
    HT_WR(ACL, S_ACL, IN_REDIR_CFG,
          ((action->port_forward ? vtss_chip_pgid(action->port_no) : 0)<<4) |
          ((action->port_forward ? 1 : 0)<<0));
    HT_WR(ACL, S_ACL, IN_CNT, counter);

    return VTSS_OK;
}

/* Allocate UDP/TCP range checker */
static uchar ht_acl_range_alloc(const vtss_ace_udp_tcp_t *port, BOOL sport, BOOL alloc)
{
    int              i, new = 0xff;
    vtss_acl_range_t *range;
    
    if (port->in_range && 
        /* Exact match or wildcard - no range checker required */
        (port->low == port->high || (port->low == 0 && port->high == 0xffff))) {
        return 0x00;
    }

    for (i = 0; i < VTSS_ACL_RANGES; i++) {
        range = &vtss_api_state->acl_range[i];
        
        /* Free range found */
        if (new == 0xff && range->count == 0)
            new = i;
        
        /* Matching entry found */
        if (range->count != 0 && range->sport == sport && 
            range->port.low == port->low && range->port.high == port->high) {
            new = i;
            break;
        }
    }
    
    /* No matching or free entry found */
    if (new == 0xff) {
        return new;
    }

    range = &vtss_api_state->acl_range[new];
    range->port = *port;
    range->sport = sport;
    range->count++;
    if (range->count == 1 && alloc) {
        /* Update range checker in chip */
        HT_WR(ACL, S_ACL, TCP_RNG_ENA_CFG_0 + 2*new, 
              ((sport ? 1 : 0)<<1) | ((sport ? 0 : 1)<<0));
        HT_WR(ACL, S_ACL, TCP_RNG_VALUE_CFG_0 + 2*new, (port->high<<16) | port->low);
    }
    VTSS_D(("%s range %d for %s hi/lo: %d/%d in: %d", 
            range->count == 1 ? "new" : "reusing", 
            new, sport ? "sport" : "dport", port->high, port->low, port->in_range));
    return (1<<new);
}

/* Free all range checkers */
static void ht_acl_range_free(void)
{
    int i;
    
    for (i = 0; i < VTSS_ACL_RANGES; i++) {
        vtss_api_state->acl_range[i].count = 0;
    }
}

vtss_rc vtss_ll_acl_policer_rate_set(vtss_acl_policer_no_t policer_no,
                                     vtss_packet_rate_t    rate)
{
    ulong unit, policer;

    policer = (policer_no - VTSS_ACL_POLICER_NO_START);
    HT_WR(ANALYZER, 0, ACLPOLIDX, policer);
    HT_WRF(ANALYZER, 0, STORMLIMIT, 24, 0xf, calc_packet_rate(rate, &unit));
    HT_WRF(ANALYZER, 0, STORMLIMIT_ENA, 6, 0x1, 1);
#if defined(G_ROCX)
    policer = 0; /* For G-RocX, the same field is used for all policers */
#endif /* G_ROCX */
    HT_WRF(ANALYZER, 0, STORMPOLUNIT, 6 + policer, 0x1, unit);
    
    return VTSS_OK;
}

static vtss_rc ht_port_acl_action_set(uint port_on_chip, const vtss_acl_action_t * action)
{
    ulong counter;
    
    VTSS_RC(ht_acl_cmd(ACL_CMD_READ, VTSS_ACES + port_on_chip));
    HT_RD(ACL, S_ACL, IN_CNT, &counter);
    VTSS_RC(ht_acl_action_set(action, counter));
    VTSS_RC(ht_acl_cmd(ACL_CMD_WRITE, VTSS_ACES + port_on_chip));
    
    return VTSS_OK;
}

vtss_rc vtss_ll_acl_port_action_set(vtss_port_no_t            port_no,
                                    const vtss_acl_action_t * action)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    
    VTSS_RC(ht_port_acl_action_set(port_on_chip, action));
        
#if VTSS_OPT_INT_AGGR
    if (vtss_int_aggr_port_no(port_on_chip) != 0) {
        VTSS_RC(ht_port_acl_action_set(port_on_chip + 1, action));
    }
#endif /* VTSS_OPT_INT_AGGR */    

    return VTSS_OK;
}

static vtss_rc ht_acl_port_counter_get(uint port_on_chip, ulong *counter)
{
    VTSS_RC(ht_acl_cmd(ACL_CMD_READ, VTSS_ACES + port_on_chip));
    HT_RD(ACL, S_ACL, IN_CNT, counter);
    return VTSS_OK;
}

vtss_rc vtss_ll_acl_port_counter_get(const vtss_port_no_t            port_no,
                                     vtss_acl_port_counter_t * const counter)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);

    VTSS_RC(ht_acl_port_counter_get(port_on_chip, counter));
#if VTSS_OPT_INT_AGGR
    if (vtss_int_aggr_port_no(port_on_chip) != 0) {
        ulong value;
        VTSS_RC(ht_acl_port_counter_get(port_on_chip + 1, &value));
        *counter += value;
    }
#endif /* VTSS_OPT_INT_AGGR */    
    return VTSS_OK;
}

static vtss_rc ht_acl_port_counter_clear(uint port_on_chip)
{
    VTSS_RC(ht_acl_cmd(ACL_CMD_READ, VTSS_ACES + port_on_chip));
    HT_WR(ACL, S_ACL, IN_CNT, 0);
    VTSS_RC(ht_acl_cmd(ACL_CMD_WRITE, VTSS_ACES + port_on_chip));
    return VTSS_OK;
}

vtss_rc vtss_ll_acl_port_counter_clear(const vtss_port_no_t port_no)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);

    VTSS_RC(ht_acl_port_counter_clear(port_on_chip));
#if VTSS_OPT_INT_AGGR
    if (vtss_int_aggr_port_no(port_on_chip) != 0) {
        VTSS_RC(ht_acl_port_counter_clear(port_on_chip + 1));
    }
#endif /* VTSS_OPT_INT_AGGR */    
    return VTSS_OK;
}

vtss_rc vtss_ll_acl_policy_no_set(vtss_port_no_t       port_no,
                                  vtss_acl_policy_no_t policy_no)
{
    uint  port_on_chip = HT_CHIP_PORT(port_no);
    ulong enabled = (policy_no == VTSS_ACL_POLICY_NO_NONE ? 0 : 1);
    
#if defined(VTSS_FEATURE_VSTAX)
    if (vtss_api_state->vstax_port_setup[port_no].enable)
        enabled = 0;
#endif /* VTSS_FEATURE_VSTAX */

    /* Enable/disable ACL on port */
    HT_WRF(PORT, port_on_chip, MISCCFG, 2, 0x1, enabled);

    if (enabled) 
        HT_WR(ACL, S_ACL, PAG_CFG + port_on_chip, 
              ((policy_no - VTSS_ACL_POLICY_NO_START)<<(ACL_PAG_WIDTH - 3)) | 
              (port_on_chip<<0));
#if VTSS_OPT_INT_AGGR
    if ((port_no = vtss_int_aggr_port_no(port_on_chip)) != 0)
        return vtss_ll_acl_policy_no_set(port_no, policy_no);
#endif /* VTSS_OPT_INT_AGGR */    

    return VTSS_OK;
}

/* Write ACE data and mask */
#define HT_ACE_WR(reg, data, mask) \
{ \
    vtss_rc rc; \
    ulong val = data; \
    ulong msk = ~(mask); \
    if ((rc = ht_rd_wr(B_ACL, S_ACL, R_ACL_##reg + ACE_DATA_OFFS, &val, 1)) < 0) \
        return rc; \
    if ((rc = ht_rd_wr(B_ACL, S_ACL, R_ACL_##reg + ACE_MASK_OFFS, &msk, 1)) < 0) \
        return rc; \
}

/* Convert to 32-bit MAC data/mask register values */
#define HT_ACE_MAC(mac_hi, mac_lo, mac) \
 mac_hi[0] = ((mac.value[0]<<8) | mac.value[1]); \
 mac_hi[1] = ((mac.mask[0]<<8) | mac.mask[1]); \
 mac_lo[0] = ((mac.value[2]<<24) | (mac.value[3]<<16) | (mac.value[4]<<8) | mac.value[5]); \
 mac_lo[1] = ((mac.mask[2]<<24) | (mac.mask[3]<<16) | (mac.mask[4]<<8) | mac.mask[5]);

/* Convert to 32-bit IPv6 data/mask registers */
#define HT_ACE_IPV6(ipv6, addr, i) \
 ipv6[0] = ((addr.value[i+0]<<24) | (addr.value[i+1]<<16) | \
            (addr.value[i+2]<<8) | addr.value[i+3]); \
 ipv6[1] = ((addr.mask[i+0]<<24) | (addr.mask[i+1]<<16) | \
            (addr.mask[i+2]<<8) | addr.mask[i+3]);

/* Determine if ACE is UDP/TCP entry */
#define HT_ACE_UDP_TCP(ace) \
 ((ace)->type == VTSS_ACE_TYPE_IPV4 && (ace)->frame.ipv4.proto.mask == 0xff && \
  ((ace)->frame.ipv4.proto.value == 6 || (ace)->frame.ipv4.proto.value == 17) ? 1 : 0)

static vtss_rc ht_acl_commit(void) 
{
    int                i;
    vtss_acl_entry_t   *cur;
    vtss_ace_t         *ace;
    ulong              misc[2], smac_hi[2], smac_lo[2], dmac_hi[2], dmac_lo[2];
    ulong              l3_misc[2], l3_hi[2], l3_lo[2], ipv6[2];
    BOOL               udp_tcp = 0, tcp = 0;
    uint               port, policy, type, type_mask;
    vtss_ace_udp_tcp_t *sport, *dport;
    uchar              srange, drange;
    
    ht_acl_range_free();

    /* Add entries */
    for (cur = vtss_api_state->acl_list, i = (VTSS_ACES - 1); 
         cur != NULL && i >= 0; 
         cur = cur->next, i--) {
        ace = &cur->ace;
        
        /* Check rule type and determine PAG fields */
        switch (ace->rule) {
        case VTSS_ACE_RULE_PORT:
            policy = 0;
            port = ace->port_no;
            break;
        case VTSS_ACE_RULE_POLICY:
            policy = ace->policy_no;
            port = 0;
            break;
        case VTSS_ACE_RULE_SWITCH:
            policy = 0;
            port = 0;
            break;
        default:
            VTSS_E(("illegal rule: %d", ace->rule));
            return VTSS_INVALID_PARAMETER;
        }

        /* Determine frame type and mask */
        type_mask = 0x0;
        switch (ace->type) {
        case VTSS_ACE_TYPE_ANY:
            type = ACL_TYPE_IPV6;
            type_mask = 0x7;
            memset(&ace->frame, 0, sizeof(ace->frame));
            break;
        case VTSS_ACE_TYPE_ETYPE:
            type = ACL_TYPE_ETYPE;
            break;
        case VTSS_ACE_TYPE_LLC:
            type = ACL_TYPE_LLC;
            break;
        case VTSS_ACE_TYPE_SNAP:
            type = ACL_TYPE_SNAP;
            break;
        case VTSS_ACE_TYPE_ARP:
            type = ACL_TYPE_ARP;
            break;
        case VTSS_ACE_TYPE_IPV4:
            udp_tcp = HT_ACE_UDP_TCP(ace);
            tcp = (udp_tcp && ace->frame.ipv4.proto.value == 6);
            if (udp_tcp) { 
                /* UDP/TCP */
                type = ACL_TYPE_UDP_TCP;
            } else {
                /* IPv4 */
                type = ACL_TYPE_IPV4;
                type_mask = 0x1;
            }
            l3_misc[0] = ((ace->frame.ipv4.proto.value<<12) | 
                          (ace->frame.ipv4.ds.value<<4) |
                          ((ace->frame.ipv4.options == VTSS_ACE_BIT_1 ? 1 : 0)<<2) |
                          ((ace->frame.ipv4.fragment == VTSS_ACE_BIT_1 ? 1 : 0)<<1) |
                          ((ace->frame.ipv4.ttl == VTSS_ACE_BIT_1 ? 1 : 0)<<0));
            l3_misc[1] = ((ace->frame.ipv4.proto.mask<<12) | 
                          (ace->frame.ipv4.ds.mask<<4) |
                          ((ace->frame.ipv4.options == VTSS_ACE_BIT_ANY ? 0 : 1)<<2) |
                          ((ace->frame.ipv4.fragment == VTSS_ACE_BIT_ANY ? 0 : 1)<<1) |
                          ((ace->frame.ipv4.ttl == VTSS_ACE_BIT_ANY ? 0 : 1)<<0));
            break;
        case VTSS_ACE_TYPE_IPV6:
            type = ACL_TYPE_IPV6;
            break;
        default:
            VTSS_E(("illegal type: %d", ace->type));
            return VTSS_INVALID_PARAMETER;
        }

        misc[0] = (((ace->dmac_bc == VTSS_ACE_BIT_1 ? 1 : 0)<<29) |
                   ((ace->dmac_mc == VTSS_ACE_BIT_1 ? 1 : 0)<<28) |
                   ((ace->vlan.usr_prio.value & 0x7)<<24) |
                   ((ace->vlan.vid.value & 0xfff)<<12) |
                   ((policy == 0 ? 0 : (policy - VTSS_ACL_POLICY_NO_START))<<(ACL_PAG_WIDTH + 1)) | 
                   ((port == 0 ? 0 : HT_CHIP_PORT(port))<<4) |
                   ((ace->vlan.cfi == VTSS_ACE_BIT_1 ? 1 : 0)<<2) |
                   (1<<1) |
                   (1<<0));
        misc[1] = (((ace->dmac_bc == VTSS_ACE_BIT_ANY ? 0 : 1)<<29) |
                   ((ace->dmac_mc == VTSS_ACE_BIT_ANY ? 0 : 1)<<28) |
                   ((ace->vlan.usr_prio.mask & 0x7)<<24) |
                   ((ace->vlan.vid.mask & 0xfff)<<12) |
                   (((policy == 0 ? 0 : 0x7))<<(ACL_PAG_WIDTH + 1)) | 
                   (((port == 0 ? 0 : ((1<<(ACL_PAG_WIDTH - 3)) - 1)))<<4) |
                   ((ace->vlan.cfi == VTSS_ACE_BIT_ANY ? 0 : 1)<<2) |
                   (1<<1) |
                   (1<<0));

        if (type_mask != 0) {
            /* Update type mask before writing data mask */
            HT_WR(ACL, S_ACL, UPDATE_CTRL, 
                  (type_mask<<20) | 
                  (0<<17) |
                  (0<<16) | 
                  (0<<4) | 
                  (0<<1) | 
                  (0<<0));
        }
        
        switch (type) {
        case ACL_TYPE_ETYPE:
            HT_ACE_WR(ETYPE_TYPE, misc[0], misc[1]);
            HT_ACE_MAC(smac_hi, smac_lo, ace->frame.etype.smac);
            HT_ACE_MAC(dmac_hi, dmac_lo, ace->frame.etype.dmac);
            HT_ACE_WR(ETYPE_L2_SMAC_HIGH, smac_hi[0], smac_hi[1]);
            HT_ACE_WR(ETYPE_L2_SMAC_LOW, smac_lo[0], smac_lo[1]);
            HT_ACE_WR(ETYPE_L2_DMAC_HIGH, dmac_hi[0], dmac_hi[1]);
            HT_ACE_WR(ETYPE_L2_DMAC_LOW, dmac_lo[0], dmac_lo[1]);
            HT_ACE_WR(ETYPE_L2_ETYPE, 
                      (ace->frame.etype.data.value[0]<<24) |
                      (ace->frame.etype.data.value[1]<<16) |
                      (ace->frame.etype.etype.value[0]<<8) |
                      (ace->frame.etype.etype.value[1]),
                      ((ace->frame.etype.data.mask[0]<<24) |
                       (ace->frame.etype.data.mask[1]<<16) |
                       (ace->frame.etype.etype.mask[0]<<8) |
                       (ace->frame.etype.etype.mask[1])));
            break;
        case ACL_TYPE_LLC:
            HT_ACE_WR(LLC_TYPE, misc[0], misc[1]);
            HT_ACE_MAC(smac_hi, smac_lo, ace->frame.llc.smac);
            HT_ACE_MAC(dmac_hi, dmac_lo, ace->frame.llc.dmac);
            HT_ACE_WR(LLC_L2_SMAC_HIGH, smac_hi[0], smac_hi[1]);
            HT_ACE_WR(LLC_L2_SMAC_LOW, smac_lo[0], smac_lo[1]);
            HT_ACE_WR(LLC_L2_DMAC_HIGH, dmac_hi[0], dmac_hi[1]);
            HT_ACE_WR(LLC_L2_DMAC_LOW, dmac_lo[0], dmac_lo[1]);
            HT_ACE_WR(LLC_L2_LLC, 
                      (ace->frame.llc.llc.value[0]<<24) |
                      (ace->frame.llc.llc.value[1]<<16) |
                      (ace->frame.llc.llc.value[2]<<8) |
                      ace->frame.llc.llc.value[3],
                      (ace->frame.llc.llc.mask[0]<<24) |
                      (ace->frame.llc.llc.mask[1]<<16) |
                      (ace->frame.llc.llc.mask[2]<<8) |
                      ace->frame.llc.llc.mask[3]);
            break;
        case ACL_TYPE_SNAP:
            HT_ACE_WR(SNAP_TYPE, misc[0], misc[1]);
            HT_ACE_MAC(smac_hi, smac_lo, ace->frame.snap.smac);
            HT_ACE_MAC(dmac_hi, dmac_lo, ace->frame.snap.dmac);
            HT_ACE_WR(SNAP_L2_SMAC_HIGH, smac_hi[0], smac_hi[1]);
            HT_ACE_WR(SNAP_L2_SMAC_LOW, smac_lo[0], smac_lo[1]);
            HT_ACE_WR(SNAP_L2_DMAC_HIGH, dmac_hi[0], dmac_hi[1]);
            HT_ACE_WR(SNAP_L2_DMAC_LOW, dmac_lo[0], dmac_lo[1]);
            HT_ACE_WR(SNAP_L2_SNAP_HIGH, 
                      ace->frame.snap.snap.value[0], ace->frame.snap.snap.mask[0]);
            HT_ACE_WR(SNAP_L2_SNAP_LOW, 
                      (ace->frame.snap.snap.value[1]<<24) |
                      (ace->frame.snap.snap.value[2]<<16) |
                      (ace->frame.snap.snap.value[3]<<8) |
                      ace->frame.snap.snap.value[4],
                      (ace->frame.snap.snap.mask[1]<<24) |
                      (ace->frame.snap.snap.mask[2]<<16) |
                      (ace->frame.snap.snap.mask[3]<<8) |
                      ace->frame.snap.snap.mask[4]);
            break;
        case ACL_TYPE_ARP:
            HT_ACE_WR(ARP_TYPE, misc[0], misc[1]);
            HT_ACE_MAC(smac_hi, smac_lo, ace->frame.arp.smac);
            HT_ACE_WR(ARP_L2_SMAC_HIGH, smac_hi[0], smac_hi[1]);
            HT_ACE_WR(ARP_L2_SMAC_LOW, smac_lo[0], smac_lo[1]);
            HT_ACE_WR(ARP_L3_ARP, 
                      ((ace->frame.arp.ethernet == VTSS_ACE_BIT_1 ? 1 : 0)<<7) |
                      ((ace->frame.arp.ip == VTSS_ACE_BIT_1 ? 1 : 0)<<6) |
                      ((ace->frame.arp.length == VTSS_ACE_BIT_1 ? 1 : 0)<<5) |
                      ((ace->frame.arp.dmac_match == VTSS_ACE_BIT_1 ? 1 : 0)<<4) |
                      ((ace->frame.arp.smac_match == VTSS_ACE_BIT_1 ? 1 : 0)<<3) |
                      ((ace->frame.arp.unknown == VTSS_ACE_BIT_1 ? 1 : 0)<<2) |
                      ((ace->frame.arp.arp == VTSS_ACE_BIT_1 ? 0 : 1)<<1) |
                      ((ace->frame.arp.req == VTSS_ACE_BIT_1 ? 0 : 1)<<0),
                      ((ace->frame.arp.ethernet == VTSS_ACE_BIT_ANY ? 0 : 1)<<7) |
                      ((ace->frame.arp.ip == VTSS_ACE_BIT_ANY ? 0 : 1)<<6) |
                      ((ace->frame.arp.length == VTSS_ACE_BIT_ANY ? 0 : 1)<<5) |
                      ((ace->frame.arp.dmac_match == VTSS_ACE_BIT_ANY ? 0 : 1)<<4) |
                      ((ace->frame.arp.smac_match == VTSS_ACE_BIT_ANY ? 0 : 1)<<3) |
                      ((ace->frame.arp.unknown == VTSS_ACE_BIT_ANY ? 0 : 1)<<2) |
                      ((ace->frame.arp.arp == VTSS_ACE_BIT_ANY ? 0 : 1)<<1) |
                      ((ace->frame.arp.req == VTSS_ACE_BIT_ANY ? 0 : 1)<<0));
            HT_ACE_WR(ARP_L3_IPV4_DIP, ace->frame.arp.dip.value, ace->frame.arp.dip.mask);
            HT_ACE_WR(ARP_L3_IPV4_SIP, ace->frame.arp.sip.value, ace->frame.arp.sip.mask);
            break;
        case ACL_TYPE_UDP_TCP:
            HT_ACE_WR(UDP_TCP_TYPE, misc[0], misc[1]);
            HT_ACE_WR(UDP_TCP_L3_MISC_CFG, l3_misc[0], l3_misc[1]); 
            HT_ACE_WR(UDP_TCP_L3_IPV4_DIP, ace->frame.ipv4.dip.value, ace->frame.ipv4.dip.mask);
            HT_ACE_WR(UDP_TCP_L3_IPV4_SIP, ace->frame.ipv4.sip.value, ace->frame.ipv4.sip.mask);
            sport = &ace->frame.ipv4.sport;
            dport = &ace->frame.ipv4.dport;
            srange = (udp_tcp ? ht_acl_range_alloc(sport, 1, 1) : 0);
            drange = (udp_tcp ? ht_acl_range_alloc(dport, 0, 1) : 0);
            HT_ACE_WR(UDP_TCP_L4_PORT, 
                      (sport->low<<16) | dport->low,
                      ((srange == 0 && sport->low == sport->high ? 0xffff : 0)<<16) |
                      (drange == 0 && dport->low == dport->high ? 0xffff : 0));
            HT_ACE_WR(UDP_TCP_L4_MISC,
                      ((ace->frame.ipv4.tcp_fin == VTSS_ACE_BIT_1 ? 1 : 0)<<13) |
                      ((ace->frame.ipv4.tcp_syn == VTSS_ACE_BIT_1 ? 1 : 0)<<12) |
                      ((ace->frame.ipv4.tcp_rst == VTSS_ACE_BIT_1 ? 1 : 0)<<11) |
                      ((ace->frame.ipv4.tcp_psh == VTSS_ACE_BIT_1 ? 1 : 0)<<10) |
                      ((ace->frame.ipv4.tcp_ack == VTSS_ACE_BIT_1 ? 1 : 0)<<9) |
                      ((ace->frame.ipv4.tcp_urg == VTSS_ACE_BIT_1 ? 1 : 0)<<8) |
                      (((sport->in_range ? srange : 0) | (dport->in_range ? drange : 0))<<0),
                      ((tcp && ace->frame.ipv4.tcp_fin != VTSS_ACE_BIT_ANY ? 1 : 0)<<13) |
                      ((tcp && ace->frame.ipv4.tcp_syn != VTSS_ACE_BIT_ANY ? 1 : 0)<<12) |
                      ((tcp && ace->frame.ipv4.tcp_rst != VTSS_ACE_BIT_ANY ? 1 : 0)<<11) |
                      ((tcp && ace->frame.ipv4.tcp_psh != VTSS_ACE_BIT_ANY ? 1 : 0)<<10) |
                      ((tcp && ace->frame.ipv4.tcp_ack != VTSS_ACE_BIT_ANY ? 1 : 0)<<9) |
                      ((tcp && ace->frame.ipv4.tcp_urg != VTSS_ACE_BIT_ANY ? 1 : 0)<<8) |
                      ((srange | drange)<<0));
            break;
        case ACL_TYPE_IPV4:
            HT_ACE_WR(IPV4_TYPE, misc[0], misc[1]);
            HT_ACE_WR(IPV4_L3_MISC_CFG, l3_misc[0], l3_misc[1]); 
            HT_ACE_WR(IPV4_L3_IPV4_DIP, ace->frame.ipv4.dip.value, ace->frame.ipv4.dip.mask);
            HT_ACE_WR(IPV4_L3_IPV4_SIP, ace->frame.ipv4.sip.value, ace->frame.ipv4.sip.mask);
            HT_ACE_MAC(l3_hi, l3_lo, ace->frame.ipv4.data);
            HT_ACE_WR(IPV4_DATA_1, l3_hi[0], l3_hi[1]);
            HT_ACE_WR(IPV4_DATA_0, l3_lo[0], l3_lo[1]);
            break;
        case ACL_TYPE_IPV6:
            HT_ACE_WR(IPV6_TYPE, misc[0], misc[1]);
            HT_ACE_WR(IPV6_L3_MISC_CFG, 
                      ace->frame.ipv6.proto.value<<8, ace->frame.ipv6.proto.mask<<8);
            HT_ACE_IPV6(ipv6, ace->frame.ipv6.sip, 0);
            HT_ACE_WR(IPV6_L3_IPV6_SIP_3, ipv6[0], ipv6[1]); 
            HT_ACE_IPV6(ipv6, ace->frame.ipv6.sip, 4);
            HT_ACE_WR(IPV6_L3_IPV6_SIP_2, ipv6[0], ipv6[1]); 
            HT_ACE_IPV6(ipv6, ace->frame.ipv6.sip, 8);
            HT_ACE_WR(IPV6_L3_IPV6_SIP_1, ipv6[0], ipv6[1]); 
            HT_ACE_IPV6(ipv6, ace->frame.ipv6.sip, 12);
            HT_ACE_WR(IPV6_L3_IPV6_SIP_0, ipv6[0], ipv6[1]); 
            break;
        default:
            VTSS_E(("illegal type: %d", type));
            return VTSS_INVALID_PARAMETER;
        }
    
        /* Action */
        VTSS_RC(ht_acl_action_set(&ace->action, cur->counter));
        
        /* Add entry */
        VTSS_RC(ht_acl_cmd(ACL_CMD_WRITE, i));
    }

    /* Delete next entry */
    if (i >= 0) {
        HT_WR(ACL, S_ACL, ETYPE_TYPE + ACE_DATA_OFFS, 0<<0);
        HT_WR(ACL, S_ACL, ETYPE_TYPE + ACE_MASK_OFFS, 0<<0);
        HT_WR(ACL, S_ACL, IN_VLD, 0<<0);
        VTSS_RC(ht_acl_cmd(ACL_CMD_WRITE, i));
    }

    return VTSS_OK;
}
#ifdef VTSS_TRACE_ENABLED
static const char *ht_ace_bit_txt(vtss_ace_bit_t flag)
{
    return (flag == VTSS_ACE_BIT_ANY ? "*" :
            flag == VTSS_ACE_BIT_1 ? "1" :
            flag == VTSS_ACE_BIT_0 ? "0" : "?");
}

static char *ht_ace_uchar6_txt(const vtss_ace_uchar6_t *data, char *buf)
{
    sprintf(buf, "%02x-%02x-%02x-%02x-%02x-%02x/%02x-%02x-%02x-%02x-%02x-%02x",
            data->value[0], data->value[1], data->value[2], 
            data->value[3], data->value[4], data->value[5], 
            data->mask[0], data->mask[1], data->mask[2], 
            data->mask[3], data->mask[4], data->mask[5]);
    return buf;
}

static char *ht_ace_uchar2_txt(const vtss_ace_uchar2_t *data, char *buf)
{
    sprintf(buf, "%02x%02x/%02x%02x",
            data->value[0], data->value[1],
            data->mask[0], data->mask[1]);
    return buf;
}
#endif
/* Read all ACE counters and store in state memory */
static vtss_rc ht_ace_counters_read(void) 
{
    int              i;
    vtss_acl_entry_t *cur;
    
    for (cur = vtss_api_state->acl_list, i = (VTSS_ACES - 1); 
         cur != NULL; 
         cur = cur->next, i--) {
        /* Read entry */
        VTSS_RC(ht_acl_cmd(ACL_CMD_READ, i));
        HT_RD(ACL, S_ACL, IN_CNT, &cur->counter);
    }
    return VTSS_OK;
}

vtss_rc vtss_ll_ace_add(vtss_ace_id_t      ace_id,
                        const vtss_ace_t * ace)
{
    vtss_acl_entry_t *cur, *prev = NULL;
    vtss_acl_entry_t *new = NULL, *new_prev = NULL, *ins = NULL, *ins_prev = NULL;
#ifdef VTSS_TRACE_ENABLED    
    char             buf[64];
#endif    
    VTSS_D(("ace_id: %ld", ace->id));
    VTSS_D(("rule type: %s (%d)",
            ace->rule == VTSS_ACE_RULE_PORT ? "Port" :
            ace->rule == VTSS_ACE_RULE_POLICY ? "Policy" :
            ace->rule == VTSS_ACE_RULE_SWITCH ? "Switch" : "?",
            ace->rule == VTSS_ACE_RULE_PORT ? ace->port_no :
            ace->rule == VTSS_ACE_RULE_POLICY ? ace->policy_no : 0));
    VTSS_D(("frame type: %s",
            ace->type == VTSS_ACE_TYPE_ANY ? "ANY" :
            ace->type == VTSS_ACE_TYPE_ETYPE ? "ETYPE" :
            ace->type == VTSS_ACE_TYPE_LLC ? "LLC" :
            ace->type == VTSS_ACE_TYPE_SNAP ? "SNAP" :
            ace->type == VTSS_ACE_TYPE_ARP ? "ARP" :
            ace->type == VTSS_ACE_TYPE_IPV4 ? "IPV4" :
            ace->type == VTSS_ACE_TYPE_IPV6 ? "IPV6" : "?"));
    VTSS_D(("DMAC flags: bc: %s, mc: %s", 
            ht_ace_bit_txt(ace->dmac_bc), ht_ace_bit_txt(ace->dmac_mc)));  
    VTSS_D(("vid: %03x/%03x, usr_prio: %02x/%02x, cfi: %s",
            ace->vlan.vid.value, ace->vlan.vid.mask,
            ace->vlan.usr_prio.value, ace->vlan.usr_prio.mask,
            ht_ace_bit_txt(ace->vlan.cfi)));
    
    switch (ace->type) {
    case VTSS_ACE_TYPE_ETYPE:
        VTSS_D(("DMAC: %s", ht_ace_uchar6_txt(&ace->frame.etype.dmac, buf)));
        VTSS_D(("SMAC: %s", ht_ace_uchar6_txt(&ace->frame.etype.smac, buf)));
        VTSS_D(("EType: %s", ht_ace_uchar2_txt(&ace->frame.etype.etype, buf)));
        VTSS_D(("Data: %s", ht_ace_uchar2_txt(&ace->frame.etype.data, buf)));
        break;
    case VTSS_ACE_TYPE_LLC:
        VTSS_D(("DMAC: %s", ht_ace_uchar6_txt(&ace->frame.llc.dmac, buf)));
        VTSS_D(("SMAC: %s", ht_ace_uchar6_txt(&ace->frame.llc.smac, buf)));
        VTSS_D(("LLC: %02x-%02x-%02x-%02x/%02x-%02x-%02x-%02x",
                ace->frame.llc.llc.value[0], ace->frame.llc.llc.value[1], 
                ace->frame.llc.llc.value[2], ace->frame.llc.llc.value[3], 
                ace->frame.llc.llc.mask[0], ace->frame.llc.llc.mask[1], 
                ace->frame.llc.llc.mask[2], ace->frame.llc.llc.mask[3]));
        break;
    case VTSS_ACE_TYPE_SNAP:
        VTSS_D(("DMAC: %s", ht_ace_uchar6_txt(&ace->frame.snap.dmac, buf)));
        VTSS_D(("SMAC: %s", ht_ace_uchar6_txt(&ace->frame.snap.smac, buf)));
        VTSS_D(("SNAP: %02x-%02x-%02x-%02x-%02x/%02x-%02x-%02x-%02x-%02x",
                ace->frame.snap.snap.value[0], ace->frame.snap.snap.value[1], 
                ace->frame.snap.snap.value[2], ace->frame.snap.snap.value[3], 
                ace->frame.snap.snap.value[4],
                ace->frame.snap.snap.mask[0], ace->frame.snap.snap.mask[1], 
                ace->frame.snap.snap.mask[2], ace->frame.snap.snap.mask[3], 
                ace->frame.snap.snap.mask[4]));
        break;
    case VTSS_ACE_TYPE_ARP:
        VTSS_D(("SMAC: %s", ht_ace_uchar6_txt(&ace->frame.arp.smac, buf)));
        VTSS_D(("ARP flags: arp: %s, req: %s, unknown: %s, smac: %s", 
                ht_ace_bit_txt(ace->frame.arp.arp), 
                ht_ace_bit_txt(ace->frame.arp.req), 
                ht_ace_bit_txt(ace->frame.arp.unknown), 
                ht_ace_bit_txt(ace->frame.arp.smac_match)));
        VTSS_D(("ARP flags: dmac: %s, length: %s, ip: %s, ethernet: %s", 
                ht_ace_bit_txt(ace->frame.arp.dmac_match), 
                ht_ace_bit_txt(ace->frame.arp.length), 
                ht_ace_bit_txt(ace->frame.arp.ip), 
                ht_ace_bit_txt(ace->frame.arp.ethernet)));
        VTSS_D(("sip: %08lx/%08lx, dip: %08lx/%08lx",
                ace->frame.arp.sip.value, ace->frame.arp.sip.mask,
                ace->frame.arp.dip.value, ace->frame.arp.dip.mask));
        break;
    case VTSS_ACE_TYPE_IPV4:
        VTSS_D(("IP flags: ttl: %s, fragment: %s, options: %s", 
                ht_ace_bit_txt(ace->frame.ipv4.ttl), 
                ht_ace_bit_txt(ace->frame.ipv4.fragment),  
                ht_ace_bit_txt(ace->frame.ipv4.options)));
        VTSS_D(("proto: %02x/%02x, ds: %02x/%02x",
                ace->frame.ipv4.proto.value, ace->frame.ipv4.proto.mask,
                ace->frame.ipv4.ds.value, ace->frame.ipv4.ds.mask));
        VTSS_D(("sip: %08lx/%08lx, dip: %08lx/%08lx",
                ace->frame.ipv4.sip.value, ace->frame.ipv4.sip.mask,
                ace->frame.ipv4.dip.value, ace->frame.ipv4.dip.mask));
        VTSS_D(("ip_data: %s", ht_ace_uchar6_txt(&ace->frame.ipv4.data, buf)));
        VTSS_D(("sport: %d-%d, in_range: %d", 
                ace->frame.ipv4.sport.low, 
                ace->frame.ipv4.sport.high, 
                ace->frame.ipv4.sport.in_range));
        VTSS_D(("dport: %d-%d, in_range: %d", 
                ace->frame.ipv4.dport.low, 
                ace->frame.ipv4.dport.high, 
                ace->frame.ipv4.dport.in_range));
        VTSS_D(("TCP flags: fin: %s, syn: %s, rst: %s, psh: %s, ack: %s, urg: %s", 
                ht_ace_bit_txt(ace->frame.ipv4.tcp_fin), 
                ht_ace_bit_txt(ace->frame.ipv4.tcp_syn), 
                ht_ace_bit_txt(ace->frame.ipv4.tcp_rst), 
                ht_ace_bit_txt(ace->frame.ipv4.tcp_psh), 
                ht_ace_bit_txt(ace->frame.ipv4.tcp_ack), 
                ht_ace_bit_txt(ace->frame.ipv4.tcp_urg)));
        break;
    case VTSS_ACE_TYPE_IPV6:
        VTSS_D(("proto: %02x/%02x", ace->frame.ipv6.proto.value, ace->frame.ipv6.proto.mask));
        VTSS_D(("sip : %02x%02x%02x%02x-%02x%02x%02x%02x-%02x%02x%02x%02x-%02x%02x%02x%02x",
                ace->frame.ipv6.sip.value[0], ace->frame.ipv6.sip.value[1],
                ace->frame.ipv6.sip.value[2], ace->frame.ipv6.sip.value[3],
                ace->frame.ipv6.sip.value[4], ace->frame.ipv6.sip.value[5],
                ace->frame.ipv6.sip.value[6], ace->frame.ipv6.sip.value[7],
                ace->frame.ipv6.sip.value[8], ace->frame.ipv6.sip.value[9],
                ace->frame.ipv6.sip.value[10], ace->frame.ipv6.sip.value[11],
                ace->frame.ipv6.sip.value[12], ace->frame.ipv6.sip.value[13],
                ace->frame.ipv6.sip.value[14], ace->frame.ipv6.sip.value[15]));
        VTSS_D(("mask : %02x%02x%02x%02x-%02x%02x%02x%02x-%02x%02x%02x%02x-%02x%02x%02x%02x",
                ace->frame.ipv6.sip.mask[0], ace->frame.ipv6.sip.mask[1],
                ace->frame.ipv6.sip.mask[2], ace->frame.ipv6.sip.mask[3],
                ace->frame.ipv6.sip.mask[4], ace->frame.ipv6.sip.mask[5],
                ace->frame.ipv6.sip.mask[6], ace->frame.ipv6.sip.mask[7],
                ace->frame.ipv6.sip.mask[8], ace->frame.ipv6.sip.mask[9],
                ace->frame.ipv6.sip.mask[10], ace->frame.ipv6.sip.mask[11],
                ace->frame.ipv6.sip.mask[12], ace->frame.ipv6.sip.mask[13],
                ace->frame.ipv6.sip.mask[14], ace->frame.ipv6.sip.mask[15]));
        break;
    case VTSS_ACE_TYPE_ANY:
    default:
        break;
    }
    
    /* Check ACE ID */
    if (ace->id == VTSS_ACE_ID_LAST || ace->id == ace_id) {
        VTSS_E(("illegal ace id: %ld", ace->id));
        return VTSS_INVALID_PARAMETER;
    }
    
    /* Check rule type */
    if (ace->rule > VTSS_ACE_RULE_SWITCH) {
        VTSS_E(("illegal rule: %d", ace->rule));
        return VTSS_INVALID_PARAMETER;
    }

    /* Check frame type */
    if (ace->type > VTSS_ACE_TYPE_IPV6) {
        VTSS_E(("illegal type: %d", ace->type));
        return VTSS_INVALID_PARAMETER;
    }

    /* Free range checkers to be able to check if out of range checkers */
    ht_acl_range_free();

    /* Search for existing entry and place to add */
    for (cur = vtss_api_state->acl_list; cur != NULL; prev = cur, cur = cur->next) {
        if (cur->ace.id == ace->id) {
            /* Entry already exists */
            new_prev = prev;
            new = cur;
        } else if (HT_ACE_UDP_TCP(&cur->ace)) {
            /* Allocate range checkers for other entries */
            ht_acl_range_alloc(&cur->ace.frame.ipv4.sport, 1, 0);
            ht_acl_range_alloc(&cur->ace.frame.ipv4.dport, 0, 0);
        }
        
        if (cur->ace.id == ace_id) {
            /* Found insertion point */
            ins_prev = prev;
            ins = cur;
        }
    }

    if (ace_id == VTSS_ACE_ID_LAST)
        ins_prev = prev;

    /* Check if the place to insert was found */
    if (ins == NULL && ace_id != VTSS_ACE_ID_LAST) {
        VTSS_E(("could not find ace ID: %ld", ace_id));
        return VTSS_ENTRY_NOT_FOUND;
    }
    
    /* Check if range checker can be allocated for new entry */
    if (HT_ACE_UDP_TCP(ace) && 
        (ht_acl_range_alloc(&ace->frame.ipv4.sport, 1, 0) == 0xff ||
         ht_acl_range_alloc(&ace->frame.ipv4.dport, 0, 0) == 0xff)) {
        VTSS_E(("no more range checkers available"));
        return VTSS_UNSPECIFIED_ERROR;
    }

    /* Read current ACE counters */
    VTSS_RC(ht_ace_counters_read());
    
    if (new == NULL) {
        /* Take new entry from free list */
        if ((new = vtss_api_state->acl_free) == NULL) {
            VTSS_E(("ACL is full"));
            return VTSS_UNSPECIFIED_ERROR;
        }
        new->counter = 0;
        vtss_api_state->acl_free = new->next;
    } else {
        /* Take existing entry out of list */
        if (ins_prev == new)
            ins_prev = new_prev;
        if (new_prev == NULL)
            vtss_api_state->acl_list = new->next;
        else
            new_prev->next = new->next;
    }

    /* Insert new entry in list */
    if (ins_prev == NULL) {
        new->next = vtss_api_state->acl_list;
        vtss_api_state->acl_list = new;
    } else {
        new->next = ins_prev->next;
        ins_prev->next = new;
    }
    new->ace = *ace;

    return ht_acl_commit();
}

vtss_rc vtss_ll_ace_del(vtss_ace_id_t ace_id)
{
    vtss_acl_entry_t *cur, *prev;

    VTSS_D(("ace_id: %ld", ace_id));

    /* Read current ACE counters */
    VTSS_RC(ht_ace_counters_read());

    /* Search for entry */
    for (cur = vtss_api_state->acl_list, prev = NULL; 
         cur != NULL; 
         prev = cur, cur = cur->next) {
        if (cur->ace.id == ace_id) {
            if (prev == NULL)
                vtss_api_state->acl_list = cur->next;
            else
                prev->next = cur->next;
            cur->next = vtss_api_state->acl_free;
            vtss_api_state->acl_free = cur;
            break;
        }
    }
    return (cur == NULL ? VTSS_ENTRY_NOT_FOUND : ht_acl_commit());
}

vtss_rc vtss_ll_ace_counter_get(vtss_ace_id_t        ace_id,
                                vtss_ace_counter_t * counter)
{
    int              i;
    vtss_acl_entry_t *cur;
    
    /* Lookup entry with ACE ID */
    for (cur = vtss_api_state->acl_list, i = (VTSS_ACES - 1); 
         cur != NULL; 
         cur = cur->next, i--) {
        if (cur->ace.id == ace_id) {
            /* Read entry */
            VTSS_RC(ht_acl_cmd(ACL_CMD_READ, i));
            HT_RD(ACL, S_ACL, IN_CNT, counter);
            return VTSS_OK;
        }
    }
    return VTSS_ENTRY_NOT_FOUND;
}

vtss_rc vtss_ll_ace_counter_clear(vtss_ace_id_t ace_id)
{
    int              i;
    vtss_acl_entry_t *cur;
    
    /* Lookup entry with ACE ID */
    for (cur = vtss_api_state->acl_list, i = (VTSS_ACES - 1); 
         cur != NULL; 
         cur = cur->next, i--) {
        if (cur->ace.id == ace_id) {
            /* Clear counter for ACE */
            VTSS_RC(ht_acl_cmd(ACL_CMD_READ, i));
            HT_WR(ACL, S_ACL, IN_CNT, 0);
            VTSS_RC(ht_acl_cmd(ACL_CMD_WRITE, i));
            return VTSS_OK;
        }
    }
    return VTSS_ENTRY_NOT_FOUND;
}
#endif /* VTSS_FEATURE_ACL */

/* PI/SI register read */
vtss_rc vtss_ll_register_read(ulong reg, ulong *value)
{
#if VTSS_ACL_DUMP
    if (reg == 0) {
        VTSS_RC(ht_acl_dump());
    }
#endif /* VTSS_ACL_DUMP */    

    return ht_rd((reg>>12) & 0x7, (reg>>8) & 0xF, reg & 0xFF, value);
}

/* PI/SI register write */
vtss_rc vtss_ll_register_write(ulong reg, ulong value)
{
    return ht_wr((reg>>12) & 0x7, (reg>>8) & 0xF, reg & 0xFF, value);
}

/* Get chip ID and revision */
/* Note: Use chipid=NULL for checking CPU access to the switch chip. */
vtss_rc vtss_ll_chipid_get(vtss_chipid_t *chipid)
{
    ulong value;
    
    HT_RD(SYSTEM, 0, CHIPID, &value);

    if (value >= 1 && value < 8) {
        /* Heathrow-II */
        if (chipid) {
            chipid->part_number = 0x7301;
            chipid->revision = value;
        }
    }
    else if (((value>>1) & 0x7FF)==0x74) {
        if (chipid) {
            chipid->part_number = (value>>12) & 0xFFFF;
            chipid->revision = (value>>28)+1; /* Start at revision 1. */
            /* Map SparX-G5/SparX-G5e rev 2 to SparX-G5m */
            if (chipid->part_number == 0x7395 && chipid->revision == 3) {
                chipid->part_number = 0x7396;
            }
        }
    }
    else if (value == 0x00000000 || value == 0xFFFFFFFF) {
        VTSS_E(("CPU interface error, chipid: 0x%08lx", value));
        return VTSS_DATA_NOT_READY;
    } else {
        VTSS_E(("CPU interface error, chipid: 0x%08lx", value));
        return VTSS_UNSPECIFIED_ERROR;
    }
    return VTSS_OK;
}

/* - Runtime Optimisations ----------------------------------------- */

#if defined(VTSS_ARCH_STAPLEFORD)
static vtss_rc ht_opt_port_fifo_queues_status(const vtss_port_no_t port_no, 
                                              BOOL * const rx_empty, 
                                              BOOL * const tx_empty, 
                                              BOOL * const rx_inactive, 
                                              BOOL * const tx_inactive)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);
    ulong dbqhprx, dbqlprx, dbqhptx, dbqlptx;

    /* Snapshot the queue pointers */
    HT_WRF(PORT, port_on_chip, MISCFIFO, 2, 0x1, 1);

    /* Check the snapshotted queue pointers */
    HT_RD(PORT, port_on_chip, DBQHPRX, &dbqhprx);
    HT_RD(PORT, port_on_chip, DBQLPRX, &dbqlprx);
    HT_RD(PORT, port_on_chip, DBQHPTX, &dbqhptx);
    HT_RD(PORT, port_on_chip, DBQLPTX, &dbqlptx);
    *rx_empty = (((dbqhprx>>16) == (dbqhprx&0xFFFF)) &&
                 ((dbqlprx >>16) == (dbqlprx &0xFFFF)));
    *tx_empty = (((dbqhptx>>16) == (dbqhptx&0xFFFF)) &&
                 ((dbqlptx >>16) == (dbqlptx &0xFFFF)));
    *rx_inactive = (dbqhprx == vtss_api_state->dbqhprx_prev[port_no] &&
                    dbqlprx == vtss_api_state->dbqlprx_prev[port_no]);
    *tx_inactive = (dbqhptx == vtss_api_state->dbqhptx_prev[port_no] &&
                    dbqlptx == vtss_api_state->dbqlptx_prev[port_no]);
    vtss_api_state->dbqhprx_prev[port_no] = dbqhprx;
    vtss_api_state->dbqlprx_prev[port_no] = dbqlprx;
    vtss_api_state->dbqhptx_prev[port_no] = dbqhptx;
    vtss_api_state->dbqlptx_prev[port_no] = dbqlptx;

    return VTSS_OK;
}

static vtss_rc ht_opt_check_fc_congestion(const vtss_port_no_t port_no, 
                                          const BOOL queues_empty, 
                                          const BOOL queues_inactive)
{
    uint  port_on_chip;
    ulong value;
    
    if (!queues_empty && queues_inactive) {
        /* Congestion */
        if (vtss_api_state->congested_count[port_no]++ >= 20) {
            /* Congestion has persisted some time now */
            VTSS_D(("Remove mutual congestion on port %d",port_no));

            port_on_chip = HT_CHIP_PORT(port_no);
            /* Briefly adjust the egress thresholds */
            HT_RD(PORT, port_on_chip, POOLCFG, &value);
            HT_WRM(PORT, port_on_chip, POOLCFG, 
                   (0x3F<<24) | (0x3F<<16), (0x3F<<24) | (0x3F<<16));
            HT_WR(PORT, port_on_chip, POOLCFG, value);
            vtss_api_state->congested_count[port_no] = 0;
        }
    } else {
        /* No congestion */
        vtss_api_state->congested_count[port_no] = 0;
    }
    return VTSS_OK;
}

#if VTSS_OPT_FC_SHAPING_BUCKET_RATE==1 /*Auto*/

static vtss_rc ht_opt_port_fifo_drops_status(const vtss_port_no_t port_no, 
                                             ushort * const rx_drops, 
                                             ushort * const tx_drops, 
                                             BOOL * const rx_dropping, 
                                             BOOL * const tx_dropping)
{
    uint port_on_chip = HT_CHIP_PORT(port_no);
    ushort rx_drops_prev, tx_drops_prev;
    ulong dropcnt;

    HT_RD(PORT, port_on_chip, DROPCNT, &dropcnt);
    
    *rx_drops = dropcnt >> 16;
    *tx_drops = dropcnt & 0xFFFF;
    rx_drops_prev = vtss_api_state->dropcnt_prev[port_no] >> 16;
    tx_drops_prev = vtss_api_state->dropcnt_prev[port_no] & 0xFFFF;
    *rx_dropping = *rx_drops != rx_drops_prev;
    *tx_dropping = *tx_drops != tx_drops_prev;
    vtss_api_state->dropcnt_prev[port_no] = dropcnt;

    return VTSS_OK;
}

static vtss_rc ht_opt_fc_shaping( const vtss_port_no_t port_no, const BOOL ingress_or_egress_queue_empty )
{
    const uint port_on_chip = HT_CHIP_PORT(port_no);
    ulong shapeconf;
    uint  shapeconf_bucket_rate;
    BOOL  shapeconf_shaping_activated;
    uint shapeconf_bucket_rate_wanted = vtss_api_state->shapeconf_bucket_rate_wanted[port_no];
    BOOL shapeconf_shaping_activated_wanted = shapeconf_bucket_rate_wanted!=0;
    ushort rx_drops, tx_drops;
    BOOL rx_dropping, tx_dropping;
    vtss_port_setup_t *setup;

    HT_RD(PORT, port_on_chip, SHAPECONF, &shapeconf);
    shapeconf_bucket_rate = shapeconf & 0xFFF;
    shapeconf_shaping_activated = shapeconf_bucket_rate!=0;

    /*This function updates rxdrops_prev, and must be called every time ht_opt_fc_shaping is called.*/;
    VTSS_RC(ht_opt_port_fifo_drops_status(port_no, &rx_drops, &tx_drops, &rx_dropping, &tx_dropping ));
    
    if (shapeconf_bucket_rate!=vtss_api_state->shapeconf_bucket_rate_prev[port_no]) {
        /* SHAPECONF has been changed, so allow one wild run for the fifos to settle before evaluating the new status. */
        VTSS_D(("Allow wild run on port %d because SHAPECONF changed.",port_no));
        vtss_api_state->shapeconf_bucket_rate_prev[port_no] = shapeconf_bucket_rate;
        return VTSS_OK;
    }

    setup = &vtss_api_state->setup[port_no];
    if ((setup->interface_mode.speed == VTSS_SPEED_10M || 
         setup->interface_mode.speed == VTSS_SPEED_100M) &&
        setup->fdx && (setup->flowcontrol.obey || setup->flowcontrol.generate) ) {
        /* 10/100 FDX with Flow Control enabled */
        if (rx_dropping) {
            vtss_api_state->shaping_disable_count[port_no] = 0;
        }
        if (rx_dropping && !shapeconf_shaping_activated) {
            /* Activate shaper, limit to 66.4% bandwidth. */
            shapeconf_bucket_rate = 1360;
            if (shapeconf_shaping_activated_wanted && shapeconf_bucket_rate>shapeconf_bucket_rate_wanted) {
                /* Maximum bandwidth as configured. */
                shapeconf_bucket_rate=shapeconf_bucket_rate_wanted;
            }
            vtss_api_state->limit_reached[port_no] = 0 /*FALSE*/;
            VTSS_D(("Activate shaper on port %d to ca. %d%%.",port_no,shapeconf_bucket_rate*(244144/1000)/5));
            VTSS_RC(ht_set_shaper_internal(port_no, shapeconf_bucket_rate));
        }
        else if (shapeconf_shaping_activated) {
            if (rx_dropping) {
                /* Decrease bandwidth by 2%. */
                shapeconf_bucket_rate -= 40;
                if (shapeconf_shaping_activated_wanted && shapeconf_bucket_rate>shapeconf_bucket_rate_wanted) {
                    /* Maximum bandwidth as configured. */
                    shapeconf_bucket_rate=shapeconf_bucket_rate_wanted;
                } else {
                    if (shapeconf_bucket_rate < 1300) {
                        /* Don't decrease below 63.5% bandwidth. */
                        shapeconf_bucket_rate = 1300;
                    }
                }
                /* Prohibit increasing bandwidth. */
                vtss_api_state->limit_reached[port_no] = 1/*TRUE*/;
                VTSS_D(("Decrease shaping bandwidth on port %d to ca. %d%%.",port_no,shapeconf_bucket_rate*(244144/1000)/5));
                VTSS_RC(ht_set_shaper_internal(port_no, shapeconf_bucket_rate));
            } else {
                if (!vtss_api_state->limit_reached[port_no]) {
                    /* Increase bandwidth by 1%. */
                    shapeconf_bucket_rate += 20;
                    if (shapeconf_shaping_activated_wanted) {
                        if (shapeconf_bucket_rate>shapeconf_bucket_rate_wanted) {
                            /* Maximum bandwidth as configured. */
                            shapeconf_bucket_rate=shapeconf_bucket_rate_wanted;
                        }
                    } else {
                        if (shapeconf_bucket_rate > 2048) {
                            /* Maximum bandwidth at 100%. */
                            shapeconf_bucket_rate = 2048;
                        }
                    }
                    VTSS_D(("Increase shaping bandwidth on port %d to ca. %d%%.",port_no,shapeconf_bucket_rate*(244144/1000)/5));
                    VTSS_RC(ht_set_shaper_internal(port_no, shapeconf_bucket_rate));
                }
                if (ingress_or_egress_queue_empty) {
                    if (vtss_api_state->shaping_disable_count[port_no]++ >= 10) {
                        /* Back to normal. */
                        /* Just set it as configured. */
                        VTSS_D(("Set shaper back to normal, i.e. as configured on port %d to ca. %d%%.",port_no,shapeconf_bucket_rate_wanted*(244144/1000)/5));
                        VTSS_RC(ht_set_shaper_internal(port_no, shapeconf_bucket_rate_wanted));
                    }
                } else {
                    vtss_api_state->shaping_disable_count[port_no] = 0;
                }
            }
        }
        if (rx_dropping) {
            /* Make sure drops from before the shaper was adjusted don't count the next time. */
            VTSS_RC(ht_opt_port_fifo_drops_status( port_no, &rx_drops, &tx_drops, &rx_dropping, &tx_dropping ));
        }
    } else {
        /* Just set it as configured. */
        VTSS_N(("Set shaper as configured on port %d to ca. %d%%.",port_no,shapeconf_bucket_rate_wanted*(244144/1000)/5));
        VTSS_RC(ht_set_shaper_internal(port_no, shapeconf_bucket_rate_wanted));
        vtss_api_state->limit_reached[port_no] = 0 /*FALSE*/;
    }
    return VTSS_OK;
}

#endif /* VTSS_OPT_FC_SHAPING_BUCKET_RATE==1 */

/* Note: Call this function when Flow Control Mode is chosen for a port. */
static vtss_rc ht_opt_post_fc_port_setup(vtss_port_no_t port_no)
{
    BOOL rx_empty, tx_empty, rx_inactive, tx_inactive;

    VTSS_RC(ht_opt_port_fifo_queues_status(port_no, &rx_empty, &tx_empty, &rx_inactive, &tx_inactive));
    vtss_api_state->congested_count[port_no] = 0;

#if VTSS_OPT_FC_SHAPING_BUCKET_RATE==1 /*Auto*/
    {
        /* Design Consideration #1. */
        ushort rx_drops, tx_drops;
        BOOL rx_dropping, tx_dropping;

        VTSS_D(("Prepare for automatic flow control shaping on port %d.",port_no));

        /* Clear the rx_dropping, tx_dropping state variables. */
        VTSS_RC(ht_opt_port_fifo_drops_status( port_no, &rx_drops, &tx_drops, &rx_dropping, &tx_dropping ));

        vtss_api_state->limit_reached[port_no] = 0 /*FALSE*/;
        vtss_api_state->shaping_disable_count[port_no] = 0;
    }
#endif
    return VTSS_OK;
}

static vtss_rc ht_opt_check_fifo_error(void)
{
    static const ulong ERRORBITS = 0x05FF0000;
    ulong  value;

    vtss_port_no_t port_no;
    BOOL error = 0;
    BOOL all_port_array[VTSS_PORT_ARRAY_SIZE];

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        all_port_array[port_no] = 1;
    }

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        uint port_on_chip = HT_CHIP_PORT(port_no);
        HT_RD(PORT, port_on_chip, MISCSTAT, &value);
        if (value & ERRORBITS) {
            error = 1;
            break;
        }
    }
    /* If error on any port, do recovery */
    if (error) {
        uint wait_attempt;

        VTSS_D(("Perform FIFO error recovery."));

        /* Stop all transfers on packet bus */
        HT_WR(ARBITER, 0, ARBDISC, vtss_chip_port_bitfield(all_port_array));

        /* Reset all ports */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            uint port_on_chip = HT_CHIP_PORT(port_no);
            HT_WR(PORT, port_on_chip, MAC_CFG, (1<<29) | (1<<5) | (1<<4));
        }

        /* Wait until Arbiter empty for all ports */
        for (wait_attempt=0; wait_attempt<VTSS_ARBITER_WAIT_MAXRETRIES; wait_attempt++) {
            BOOL empty;
            VTSS_RC(ht_arbiter_empty_allports(&empty));
            if (empty)
                break;
        }
        if (wait_attempt>=VTSS_ARBITER_WAIT_MAXRETRIES) {
            /* Timeout */
            VTSS_E(("Timeout: Arbiter does not empty all ports."));
            return VTSS_FATAL_ERROR;
        }

        /* Resume all transfers on packet bus */
        HT_WR(ARBITER, 0, ARBDISC, 0);

        /* Reinitialize ports */
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            /* Reset and setup the port, watermarks etc. */
            VTSS_RC(ht_port_setup(port_no, &vtss_api_state->setup[port_no]));
            VTSS_RC(ht_port_queue_enable(port_no, 1));
        }
    }
    
    return VTSS_OK;
}
#endif /* VTSS_ARCH_STAPLEFORD */

/* Optimization function called every second */
vtss_rc vtss_ll_optimize_1sec(void)
{
#if defined(VTSS_ARCH_STAPLEFORD)
    /* Design Consideration #3. */
    return ht_opt_check_fifo_error();
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_SPARX_28)
    vtss_port_no_t    port_no;
    vtss_port_setup_t *ps;
    uint              port_on_chip;
    ulong             value;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        /* Skip ports not running 10fdx or down */
        ps = &vtss_api_state->setup[port_no];
        if (ps->fdx || 
            ps->interface_mode.speed != VTSS_SPEED_10M ||
            !VTSS_STP_UP(vtss_api_state->stp_state[port_no]))
            continue;
        
        /* Read Tx packet counter, skip port if changed */
        port_on_chip = HT_CHIP_PORT(port_no);
        HT_WR(PORT, port_on_chip, C_CNTADDR, (1<<31) | (0x3042<<0));
        HT_RD(PORT, port_on_chip, C_CNTDATA, &value);
        if (vtss_api_state->tx_packets[port_no] != value) {
            vtss_api_state->tx_packets[port_no] = value;
            continue;
        }
        
        /* Read egress FIFO used slices */
        HT_RD(PORT, port_on_chip, FREEPOOL, &value);
        HT_RDF(PORT, port_on_chip, FREEPOOL, 0, 0x1f, &value);
        if (value == 0)
            continue;

        /* No Tx activity and FIFO not empty, restart port */
        VTSS_D(("optimizing port %d", port_no));
        VTSS_RC(vtss_ll_port_speed_mode_tbi_gmii(port_no, ps));
    }
#endif /* VTSS_ARCH_SPARX_28 */
    return VTSS_OK;
}

/* Optimization function called every 100th millisecond */
vtss_rc vtss_ll_optimize_100msec(void)
{
#if defined(VTSS_ARCH_STAPLEFORD)
    vtss_port_no_t port_no;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        BOOL rx_empty, tx_empty, rx_inactive, tx_inactive;
        BOOL both_queues_empty, some_queue_empty, both_queues_inactive;

        VTSS_RC(ht_opt_port_fifo_queues_status(port_no, &rx_empty, &tx_empty, &rx_inactive, &tx_inactive));
        both_queues_empty = rx_empty && tx_empty;
        some_queue_empty = rx_empty || tx_empty;
        both_queues_inactive = rx_inactive && tx_inactive;

        /* Design Consideration #2. */
        if (vtss_api_state->setup[port_no].flowcontrol.generate) {
            VTSS_RC(ht_opt_check_fc_congestion( port_no, both_queues_empty, both_queues_inactive ));
        }
#if VTSS_OPT_FC_SHAPING_BUCKET_RATE==1 /*Auto*/
        /* Design Consideration #1. */
        VTSS_RC(ht_opt_fc_shaping( port_no, some_queue_empty ));
#endif
    }
#endif /* VTSS_ARCH_STAPLEFORD */
    return VTSS_OK;
}

/* - GPIOs --------------------------------------------------------- */
#if defined(VTSS_GPIOS)

/* Set GPIO direction */
vtss_rc vtss_ll_gpio_direction_set(vtss_gpio_no_t gpio_no, BOOL output)
{
    ulong offset;
#if defined(VTSS_ARCH_STAPLEFORD)
    offset = (10-gpio_no);
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED)
    offset = (9-gpio_no);
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_HAWX)
    offset = (15-gpio_no);
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
    offset = (4+gpio_no);
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_SPARX_28)
    offset = (16+gpio_no);
#endif /* VTSS_ARCH_SPARX_28 */
    HT_WRF(SYSTEM, 0, GPIO, offset, 0x1, output ? 1 : 0);
    return VTSS_OK;
}

static ulong gpio_offset(vtss_gpio_no_t gpio_no)
{
#if defined(VTSS_ARCH_STAPLEFORD)
    return (5-gpio_no);
#endif /* VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_STANSTED)
    return (4-gpio_no);
#endif /* VTSS_ARCH_STANSTED */
#if defined(VTSS_ARCH_HAWX)
    return (7-gpio_no);
#endif /* VTSS_ARCH_HAWX */
#if defined(VTSS_ARCH_SPARX)
    return (0+gpio_no);
#endif /* SPARX */
}


/* Read GPIO input pin */
vtss_rc vtss_ll_gpio_input_read(vtss_gpio_no_t gpio_no, BOOL *value)
{
    ulong val, offset;

    offset = gpio_offset(gpio_no);
    HT_RDF(SYSTEM, 0, GPIO, offset, 0x1, &val);
    *value=MAKEBOOL01(val);
    
    return VTSS_OK;
}

/* Write GPIO output pin */
vtss_rc vtss_ll_gpio_output_write(vtss_gpio_no_t gpio_no, BOOL value)
{
    ulong offset;
    
    if (gpio_no >= VTSS_GPIO_NO_START && gpio_no < VTSS_GPIO_NO_END) {
        offset = gpio_offset(gpio_no);
        HT_WRF(SYSTEM, 0, GPIO, offset, 0x1, value ? 1 : 0);
        return VTSS_OK;
    }
    if (gpio_no >= VTSS_GPO_IRQ(0) && gpio_no < VTSS_GPO_IRQ(VTSS_GPO_IRQS)) {
#if defined(VTSS_ARCH_SPARX)
        offset = (2+(gpio_no-VTSS_GPO_IRQ(0)));
        HT_WRF(SYSTEM, 0, CPUCTRL, offset, 0x1, value ? 1 : 0);
        return VTSS_OK;
#endif /* SPARX */
    }
    VTSS_E(("illegal gpio_no: %d",gpio_no));
    return VTSS_INVALID_PARAMETER;
}
#endif

#if defined(VTSS_FEATURE_SERIAL_LED)
vtss_rc vtss_ll_serial_led_set(const vtss_led_port_t port, 
                               const vtss_led_mode_t mode[3])
{
    ulong value, val, i;
    
    if (port > 29) {
        VTSS_E(("illegal port: %d", port));
        return VTSS_INVALID_PARAMETER;
    }

    /* Set shared LED/GPIO pins to LED mode */
    HT_WRM(SYSTEM, 0, GPIOCTRL, (0<<11) | (0<<10), (1<<11) | (1<<10));
    
    /* Select port */
    HT_WR(SYSTEM, 0, LEDTIMER, (0<<31) | (port<<26) | (178<<16) | (25000<<0));
    
    /* Setup LED mode */
    value = 0;
    for (i = 0; i < 3; i++) {
        switch (mode[i]) {
        case VTSS_LED_MODE_DISABLED:
            val = 7;
            break;
        case VTSS_LED_MODE_OFF:
            val = 0;
            break;
        case VTSS_LED_MODE_ON:
            val = 1;
            break;
        case VTSS_LED_MODE_2_5:
            val = 2;
            break;
        case VTSS_LED_MODE_5:
            val = 3;
            break;
        case VTSS_LED_MODE_10:
            val = 4;
            break;
        case VTSS_LED_MODE_20:
            val = 5;
            break;
        default:
            val = 0;
            break;
        }
        value |= (val<<(3*i));
    }
    HT_WR(SYSTEM, 0, LEDMODES, value);

    return VTSS_OK;
}
#endif /* VTSS_FEATURE_SERIAL_LED */

/* ================================================================= *
 *  Chip Reset, polarity/endian Setup and Interrupts
 * ================================================================= */

static vtss_rc ht_reset_memories(void)
{
    uint  i, memid;

    VTSS_D(("enter"));

    for (i = 0; i < 2; i++) {
        for (memid = 0; memid <= MEMINIT_MAXID; memid++) {
            /* Skip certain blocks */
            if (memid >= MEMID_SKIP_MIN && memid <= MEMID_SKIP_MAX) 
                continue; 

            if (i == 0) {
                /* First round: Memory initialization */
                HT_WR(MEMINIT, S_MEMINIT, MEMINIT,(MEMINIT_CMD_INIT<<8) | memid);
                VTSS_MSLEEP(1);
            } else {
                /* Second round: Memory check */
#if defined(VTSS_ARCH_SPARX)
                /* Skip this for SparX */
                break;
#else
                ulong value;
                
                HT_WR(MEMINIT, S_MEMINIT, MEMINIT,(MEMINIT_CMD_READ<<8) | memid);
                VTSS_MSLEEP(1);
                HT_RD(MEMINIT, S_MEMINIT, MEMRES, &value);
                if ((value & 0x3) != MEMRES_OK) {
                    VTSS_E(("memory init failed, block: %d", memid));
                    return VTSS_UNSPECIFIED_ERROR;
                }
#endif /* VTSS_ARCH_SPARX */
            }
        }
        if (i == 0)
            VTSS_MSLEEP(30);
    }

    HT_WR(ANALYZER, 0, MACACCES, MAC_CMD_TABLE_CLEAR<<0);  /* Clear MAC table */
    HT_WR(ANALYZER, 0, VLANACES, VLAN_CMD_TABLE_CLEAR<<0); /* Clear VLAN table */
#if defined(VTSS_FEATURE_ACL)
    /* Clear ACL table and enable ACLs */
    HT_WR(ACL, S_ACL, ACL_CFG, 1<<0);
    HT_WR(ACL, S_ACL, ETYPE_TYPE + ACE_DATA_OFFS, 0<<0);
    HT_WR(ACL, S_ACL, ETYPE_TYPE + ACE_MASK_OFFS, 0<<0);
    VTSS_RC(ht_acl_cmd(ACL_CMD_INIT, 0));
    HT_WR(ACL, S_ACL, EG_VLD, 1<<0);
#if defined(G_ROCX)
    HT_WR(ACL, S_ACL, EG_MISC, 0);
#endif /* G_ROCX */
    HT_WR(ACL, S_ACL, EG_PORT_MASK, VTSS_CHIP_PORTMASK + (1<<VTSS_CHIP_PORT_CPU));
    VTSS_RC(ht_acl_cmd(ACL_CMD_WRITE, VTSS_ACES + VTSS_CHIP_PORTS));
#endif /* VTSS_FEATURE_ACL */    

    VTSS_MSLEEP(40);

    return VTSS_OK;
}

static ulong repeat4(const uchar b)
{
    return (b<<24) | (b<<16) | (b<<8) | b ;
}

/* Setup SI/PI CPU Inteface */
static vtss_rc ht_setup_cpu_if(const vtss_init_setup_t *setup)
{
    ulong value;

    VTSS_D(("enter"));

#if defined(VTSS_FEATURE_PI_WIDTH)    
    if (!setup->use_cpu_si) {
        /* Setup PI width */
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
        value = (setup->pi_width==VTSS_PI_WIDTH_8 ? 0xFFFFFFFF : 0);
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX) || defined(VTSS_ARCH_SPARX)
        switch (setup->pi_width) {
        case VTSS_PI_WIDTH_8:  
            value = repeat4(1<<3 | 1<<2 | 0x1<<0); 
            break;
        case VTSS_PI_WIDTH_16: 
#if defined(VTSS_ARCH_SPARX_28)
            value = repeat4(1<<3 | 1<<2 | 0x0<<0); 
#else
            value = repeat4(1<<3 | 1<<2 | 0x2<<0); 
#endif /* VTSS_ARCH_SPARX_28 */
            break;
#if defined(VTSS_ARCH_HAWX)
        case VTSS_PI_WIDTH_32: 
            value = repeat4(1<<3 | 1<<2 | 0x0<<0); 
            break;
#endif /* HAWX */
        }
#endif /* VTSS_ARCH_HAWX/SPARX */
        HT_WR(SYSTEM, 0, PICONF, value);
    }
#endif /* VTSS_FEATURE_PI_WIDTH */
    
    /* Setup endianness. SI is always big-endian. PI depends on CPU endianness */
    value = 0x01020304; /* Endianness test value used in next line */
    value = ((setup->use_cpu_si || *((uchar *)&value) == 0x01) ? 0x99999999 : 0x81818181);
    HT_WR(SYSTEM, 0, CPUMODE, value);

    if (setup->use_cpu_si) {
#if defined(VTSS_ARCH_SPARX)
        HT_WR(SYSTEM, 0, SIPAD, 0);
#endif /* VTSS_ARCH_SPARX */
    } else {
        /* Setup CPU PI interface */
#if defined(VTSS_FEATURE_PI_TIMING_CS) && defined(VTSS_FEATURE_PI_SLOWMODE)
        uint pi_wait;
        if (setup->pi_cs_wait_ns == VTSS_PI_CS_WAIT_MAX) {
            pi_wait = 0xF;
        } else {
#if defined(VTSS_ARCH_STANSTED) || defined(VTSS_ARCH_STAPLEFORD)
            pi_wait = (setup->pi_cs_wait_ns+7)/8; /* The PI Wait unit is 8 ns */
#endif /* VTSS_ARCH_STANSTED/STAPLEFORD */
#if defined(VTSS_ARCH_HAWX)
            pi_wait = (setup->pi_cs_wait_ns*10+95)/96; /* The PI Wait unit is 9.6 ns */
#endif /* HAWX */
#if defined(VTSS_ARCH_SPARX)
            pi_wait = (setup->pi_cs_wait_ns*10+111)/112; /* The PI Wait unit is 11.2 ns */
#endif /* SPARX */
            if (pi_wait > 0xF) {
                VTSS_E(("illegal PI wait: %d ns", setup->pi_cs_wait_ns));
                return VTSS_INVALID_PARAMETER;
            }
        }
        HT_WR(SYSTEM, 0, CPUCTRL, pi_wait<<8 | (setup->pi_use_extended_buscycle ? 0 : 1)<<5);
#endif /* VTSS_FEATURE_PI_TIMING_CS && VTSS_FEATURE_PI_SLOWMODE */
    }
    return VTSS_OK;
}

#if defined(VTSS_ARCH_SPARX_G24)
#if 0 
/*jqiu delete because FAE said it is no use for current version 7390. And it is just for A version bug fix.*/
static vtss_rc boost_icpu(void)
{
    static unsigned char booster[] = {
        0x10, 0x00, 0x8B, 0x00, 0x7B, 0x1C, 0xE4, 0xFD, 0x7F, 0xE0, 0x12, 0x00, 0x17, 0x7F, 0x09, 0x7E, 0x00, 0x7D, 0x00, 0x7C, 
        0x10, 0x00, 0x9B, 0x00, 0x00, 0x12, 0x00, 0x1E, 0x7A, 0xC0, 0x79, 0x34, 0x12, 0x00, 0xBD, 0x75, 0x87, 0x02, 0x80, 0xFE, 
        0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0xAB, 
        0x10, 0x00, 0xAB, 0x00, 0x78, 0xFE, 0xE4, 0xF6, 0xD8, 0xFD, 0x75, 0x0A, 0x00, 0x75, 0x0B, 0x00, 0x75, 0x81, 0x0B, 0x02, 
        0x02, 0x00, 0xBB, 0x00, 0x00, 0x8B, 
        0x10, 0x00, 0x03, 0x00, 0xEF, 0x2D, 0xF5, 0xF9, 0x8B, 0xFA, 0x30, 0xF8, 0xFD, 0xD2, 0xF8, 0xAC, 0xFF, 0xAD, 0xFE, 0xAE, 
        0x10, 0x00, 0x13, 0x00, 0xFD, 0xAF, 0xFC, 0x22, 0xEF, 0x2D, 0xF5, 0x08, 0x8B, 0x09, 0x22, 0x8C, 0xFF, 0x8D, 0xFE, 0x8E, 
        0x10, 0x00, 0x23, 0x00, 0xFD, 0x8F, 0xFC, 0xE5, 0x08, 0xF5, 0xF9, 0xE5, 0x09, 0xF5, 0xFB, 0x30, 0xF8, 0xFD, 0xD2, 0xF8, 
        0x10, 0x00, 0x33, 0x00, 0x22, 0xC2, 0xAF, 0xE4, 0xF5, 0xFF, 0xF5, 0xFE, 0xF5, 0xFD, 0x75, 0xFC, 0x18, 0x75, 0xF9, 0xE0, 
        0x10, 0x00, 0x43, 0x00, 0x75, 0xFB, 0x14, 0x30, 0xF8, 0xFD, 0xD2, 0xF8, 0xE4, 0xF5, 0xFF, 0xF5, 0xFE, 0xF5, 0xFD, 0x75, 
        0x10, 0x00, 0x53, 0x00, 0xFC, 0x01, 0x75, 0xF9, 0xE0, 0x75, 0xFB, 0x14, 0xD2, 0xF8, 0xE4, 0xF5, 0xFF, 0xF5, 0xFE, 0x75, 
        0x10, 0x00, 0x63, 0x00, 0xFD, 0x2B, 0x75, 0xFC, 0x8E, 0x75, 0xF9, 0xA0, 0x75, 0xFB, 0x18, 0x30, 0xF8, 0xFD, 0xD2, 0xF8, 
        0x10, 0x00, 0x73, 0x00, 0xE4, 0xF5, 0xFF, 0xF5, 0xFE, 0xF5, 0xFD, 0x75, 0xFC, 0x09, 0x75, 0xF9, 0xE0, 0x75, 0xFB, 0x1C, 
        0x08, 0x00, 0x83, 0x00, 0x30, 0xF8, 0xFD, 0xD2, 0xF8, 0xD2, 0xAF, 0x22, 
        0x06, 0x00, 0xBD, 0x00, 0x8A, 0x83, 0x89, 0x82, 0xE4, 0x73, 
        0x00, 0x00, 0x00, 0x01
    };
    unsigned char *dp;
    unsigned char len;
    ulong addr;

    dp = booster;
    for (;;) {
        len = *dp++;
        addr = ((ulong)*dp++) << 8;
        addr |= *dp++;
        if (*dp++)
            break;
        VTSS_D(("Booster: addr 0x%lx len %u\n", addr, len));
        HT_WR(SYSTEM, 0, ICPU_ADDR, addr);
        while (len--)
            HT_WR(SYSTEM, 0, ICPU_DATA, *dp++);
    }
    return VTSS_OK;
}
#endif
#endif /* VTSS_ARCH_SPARX_G24 */

#if VTSS_OPT_ICPU_LOAD
#include "vtss_icpu.c"

static vtss_rc ht_icpu_load(void)
{
    uchar *dp;
    uint len = sizeof(lutonu);

    VTSS_D(("Holding ICPU reset"));
    HT_WR(SYSTEM, 0, ICPU_CTRL, (1<<7) | (1<<3) | (1<<2) | (0<<0));  
    
    VTSS_D(("Loading ICPU (%d bytes)", len));
    dp = lutonu;
    HT_WR(SYSTEM, 0, ICPU_ADDR, 0);
    while (len--)
        HT_WR(SYSTEM, 0, ICPU_DATA, *dp++);
    VTSS_D(("ICPU loaded"));
    
    VTSS_D(("Switch master reset"));
    HT_WR(SYSTEM, 0, GLORESET, (1<<0));
    VTSS_NSLEEP(VTSS_T_RESET);
    
    VTSS_D(("Releasing ICPU from reset"));
    HT_WR(SYSTEM, 0, ICPU_CTRL, (1<<8) | (1<<3) | (1<<1) | (1<<0)); 

    return VTSS_OK;
}
#endif /* VTSS_OPT_ICPU_LOAD */    

/* Initialize low level layer */
vtss_rc vtss_ll_init(const vtss_init_setup_t *setup)
{
    ulong         value;
    vtss_chipid_t chipid;

    VTSS_D(("enter"));

    /* I/O Layer */
    vtss_io_init();

#if VTSS_OPT_ICPU_LOAD
    VTSS_RC(ht_setup_cpu_if(setup));
    return ht_icpu_load(); 
#endif /* VTSS_OPT_ICPU_LOAD */

    if (setup->reset_chip) {
        VTSS_RC(ht_setup_cpu_if(setup));

#if defined(VTSS_ARCH_SPARX_28) && !defined(G_ROCX)
        /* Cannot reset reliably */
#else
        /* Write to RESET register */
#if defined(HEATHROW2) || defined(VTSS_ARCH_STAPLEFORD)
        value = 0xFFFFFFFF;
#else
        value = (1<<0);
#endif /* HEATHROW2/VTSS_ARCH_STAPLEFORD */
#if defined(VTSS_ARCH_SPARX_G24) || defined(G_ROCX)
        HT_WR(SYSTEM, 0, GLORESET, (1<<4)|(1<<3)|(1<<2)); /* Lock iCPU and MEM locks */
        VTSS_NSLEEP(VTSS_T_RESET);
#endif /* VTSS_ARCH_SPARX_G24/G_ROCX*/
        HT_WR(SYSTEM, 0, GLORESET, value);
        VTSS_NSLEEP(VTSS_T_RESET);

        VTSS_RC(ht_setup_cpu_if(setup)); /* Setup again after reset */
#endif /* VTSS_ARCH_SPARX_28 && !G_ROCX */

#if defined(VTSS_ARCH_SPARX_G24)       
        /* pre:
        ** SOFT_RST_HOLD <= 1
        ** SOFT_RST      <= 0
        ** EXT_ACC_EN    <= 1
        */
        HT_WR(SYSTEM, 0, ICPU_CTRL,
              (1<<7) |          /* SOFT_RST_HOLD = 1 */
              (1<<3) |          /* BOOT_EN       = 1 */
              (1<<2) |          /* EXT_ACC_EN    = 1 */
              (0<<0));          /* SOFT_RST      = 0 */
#if 0 
        jqiu delete because FAE said it is no use for current version 7390. And it is just for A version bug fix.
        boost_icpu(); /* Issue #4481 */        
#endif 
        /* post:
        ** CLK_DIV        <= 1
        ** BOOT_EN        <= 1
        ** CLK_EN         <= 1
        ** SOFT_RST       <= 1
        ** (SOFT_RST_HOLD <= 0)
        ** (EXT_ACC_EN    <= 0)
        */
        HT_WR(SYSTEM, 0, ICPU_CTRL,
              (1<<8) |          /* CLK_DIV  = 1 */              
              (1<<3) |          /* BOOT_EN  = 1 */
              (1<<1) |          /* CLK_EN   = 1 */
              (1<<0));          /* SOFT_RST = 1 */
       
        VTSS_NSLEEP(VTSS_T_RESET);

        /* 
        ** the above effectively results in a switchcore reset, so we
        ** redo setup of the CPU IF following this reset 
        */
        VTSS_RC(ht_setup_cpu_if(setup));

        VTSS_RC(vtss_ll_chipid_get(&chipid)); /* Check CPU interface */

        HT_RD(ARBITER, 0, RATEUNIT, &value);
        if(value != 11150) {
            VTSS_E(("Booster initialization error. Rateunit = %lu", value));
        }
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24)
        HT_WR(SYSTEM, 0, GLORESET, 1<<1); /* Release Internal PHYs */
        VTSS_NSLEEP(VTSS_T_RESET);
#endif /* VTSS_ARCH_SPARX_G8/G24 */
#if defined(VTSS_ARCH_SPARX_28)
        HT_WR(SYSTEM, 0, TIMECMP, HT_TIMECMP_DEFAULT);
#if VTSS_OPT_UART
        /* Set shared UART/GPIO pins to UART mode */
        HT_WRM(SYSTEM, 0, GPIOCTRL, (1<<3)|(1<<2)|(0<<1)|(0<<0), (1<<3)|(1<<2)|(1<<1)|(1<<0));
#endif /* VTSS_OPT_UART */
#if VTSS_OPT_REF_CLK_SINGLE_ENDED
        /* Improve clock for single ended ref clock mode, Current just 7407 will run here. jqiu 2010-06-01*/
        if(setup->use_diff_clock)
        {
            HT_WRM(SYSTEM, 0, MACRO_CTRL, (0 << 3), (1 << 3));
        }
        else
        {
            HT_WRM(SYSTEM, 0, MACRO_CTRL, (1 << 3), (1 << 3));
        }
#endif /* VTSS_OPT_REF_CLK_SINGLE_ENDED */
#endif /* VTSS_ARCH_SPARX_28 */

        VTSS_RC(vtss_ll_chipid_get(&chipid));
        VTSS_D(("found VSC%04x_%d", chipid.part_number, chipid.revision));
#if defined(SPARX_G8)
        vtss_api_state->g58_type = (chipid.part_number == 0x7398) ? VTSS_LUTON_TYPE_EXT : VTSS_LUTON_TYPE_BASIC;
#endif /* SPARX_G5 */
#if defined(SPARX_G5)
        switch (chipid.part_number) {
        case 0x7396 :           /* SparX-G5m */
            vtss_api_state->g58_type = VTSS_LUTON_TYPE_R2;
            break;
        case 0x7395 :           /* SparX-G5e */
            vtss_api_state->g58_type = VTSS_LUTON_TYPE_EXT;
            break;
        case 0x7385 :           /* SparX-G5 */
        default :
            vtss_api_state->g58_type = VTSS_LUTON_TYPE_BASIC;
            break;
        }
#endif /* SPARX_G5 */
#if defined(VTSS_ARCH_HAWX)
        vtss_api_state->hawx_b = (chipid.revision == 2);
#endif /* VTSS_ARCH_HAWX */
        VTSS_RC(ht_reset_memories());     /* Reset the memories. */

        VTSS_RC(ht_cputx_autoupdate_crc(1/*TRUE*/));

        VTSS_RC(ht_vlan_table_clear());
        
#if defined(VTSS_ARCH_HAWX)
        if (vtss_api_state->hawx_b) {
            /* Allocate 20 kB for queue 0 and 12 kB for queue 1 */
            HT_WRM(SYSTEM, 0, CAPCTRL, 
                   (0<<21) | (0<<17) | (6<<13), (0xF<<21) | (0xF<<17) | (0xF<<13));
            vtss_api_state->rx_queue_size[0] = 20;
            vtss_api_state->rx_queue_size[1] = 12;
            vtss_api_state->rx_queue_size[2] = 0;
            vtss_api_state->rx_queue_size[3] = 0;
        } else {
            /* Allocate 16 kB for each CPU Rx queue and reset capture block */
            HT_WRF(SYSTEM, 0, CAPCTRL, 7, 0x1F, 16);
            HT_WR(CAPTURE, S_CAPTURE_RESET, CAPRST, 0);
        }
        {
            uint port_on_chip;

            for (port_on_chip = 0; port_on_chip < VTSS_CHIP_PORTS; port_on_chip++) {
                /* Set S-Tag to 0x8100 */
                HT_WRF(PORT, port_on_chip, CAT_FA_TAG_ANALYSIS, 0, 0xFFFF, 0x8100);

                /* Allow zero SMAC/DMAC, discard multicast SMAC */
                HT_WRM(PORT, port_on_chip, CAT_DROP, (1<<6) | (0<<0), (1<<6) | (1<<0));
            }
        }
#endif /* VTSS_ARCH_HAWX */

#if defined(VTSS_ARCH_SPARX_G8) || defined(VTSS_ARCH_SPARX_G24) || defined(G_ROCX)
        /* Release internal PHYs from reset */
        HT_WRM(SYSTEM, 0, GLORESET, (1<<1), (1<<1));
#endif /* VTSS_ARCH_SPARX_G8/G24/G_ROCX */
#if defined(VTSS_ARCH_SPARX)
        {
            uint port_on_chip;
            
            /* Setup all used chip ports */
            for (port_on_chip = 0; port_on_chip <= VTSS_CHIP_PORTS; port_on_chip++) {
                if (
#if VTSS_OPT_NICIO
                    port_on_chip != VTSS_MII_PORT_NO &&
#endif /* VTSS_OPT_NICIO */
                    (VTSS_CHIP_PORTMASK & (1<<port_on_chip)) == 0)
                    continue;

                /* Allow zero SMAC/DMAC, discard multicast SMAC */
                HT_WRM(PORT, port_on_chip, CAT_DROP, (1<<6) | (0<<0), (1<<6) | (1<<0));
#if defined(VTSS_ARCH_SPARX_G8)
                /* Configure which 3 counters to support */
                HT_WR(PORT, port_on_chip, CNT_CTRL_CFG,
                      (14<<26) | /* TX2: Drops (includes errors) */
                      (13<<21) | /* TX1: FIFO drops */
                      (25<<16) | /* TX0: Total good packets  */
                      (2<<10)  | /* RX2: Total error packets */
                      (13<<5)  | /* RX1: FIFO drops */
                      (25<<0));  /* RX0: Total packets (good and bad) */
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24)
                /* Configure which 5 counters to support */
                HT_WR(PORT, port_on_chip, CNT_CTRL_CFG,
                      (4<<26)  | /* TX2: Good multicast packets */
                      (3<<21)  | /* TX1: Good broadcast packets */
                      (25<<16) | /* TX0: Total good packets  */
                      (4<<10)  | /* RX2: Good multicast packets */
                      (3<<5)   | /* RX1: Good broadcast packets */
                      (0<<0));   /* RX0: Total packets (good and bad) */
                HT_WR(PORT, port_on_chip, CNT_CTRL_CFG2,
                      (14<<21) | /* TX4: Drops (includes errors) */
                      (13<<16) | /* TX3: FIFO drops */
                      (30<<5)  | /* RX4: Drops (includes errors) */
                      (13<<0));  /* RX3: FIFO drops */
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
                /* Clear counters */
                HT_WR(PORT, port_on_chip, C_CLEAR, 0);
                
                /* Enable ACLs and physical port in IFH for LACP frames */
#if defined(G_ROCX)                
                if (port_on_chip != 4) /* ACL disabled on internal port */
#endif /* G_ROCX */
                    HT_WR(PORT, port_on_chip, MISCCFG, (1<<3) | (1<<2));
#endif /* VTSS_ARCH_SPARX_28 */
#if defined(VTSS_FEATURE_VSTAX)
                /* Enable untagged VID 0 */
                HT_WRF(PORT, port_on_chip, TXUPDCFG, 20, 0x1, 1);
#endif /* VTSS_FEATURE_VSTAX */
#if defined(VTSS_FEATURE_ACL)
                /* Setup one-to-one PAG mapping taking internal aggregations into account */
                value = port_on_chip;
#if VTSS_OPT_INT_AGGR
                if (port_on_chip == (VTSS_CHIP_PORT_AGGR_0 + 1) ||
                    port_on_chip == (VTSS_CHIP_PORT_AGGR_1 + 1))
                    value--;
#endif /* VTSS_OPT_INT_AGGR */
                HT_WR(ACL, S_ACL, PAG_CFG + port_on_chip, value);
#endif /* VTSS_FEATURE_ACL */
            } /* Port loop */
#if defined(VTSS_FEATURE_VSTAX)
            /* Always enable VStaX in Analyzer */
            HT_WR(ANALYZER, 0, STACKCFG, 
                  (1<<17) | (1<<16) | (1<<15) | (1<<7) | (1<<6) | (1<<5) | (1<<4) | (1<<3));
#endif /* VTSS_FEATURE_VSTAX */
#if defined(VTSS_ARCH_SPARX_G8)
            /* Allocate 8/10 kB for each CPU Rx queue */
            HT_WRF(SYSTEM, 0, CAPCTRL, 7, 0x1F, vtss_api_state->g58_type >= VTSS_LUTON_TYPE_EXT ? 10 : 8);
#endif /* VTSS_ARCH_SPARX_G8 */
#if defined(VTSS_ARCH_SPARX_G24)
            /* Allocate 10 kB for each CPU Rx queue */
            HT_WRF(SYSTEM, 0, CAPCTRL, 7, 0x1F, 10);
#endif /* VTSS_ARCH_SPARX_G24 */
#if defined(VTSS_ARCH_SPARX_28)
            /* E-StaX: 32/16 kB for Q0/Q1. G-RocX: 16/8 kB for Q0/Q1 */
            HT_WR(PORT, VTSS_CHIP_PORT_CPU, Q_EGRESS_WM, (0<<24) | (0<<16) | (8<<8) | (16<<0));
            HT_WR(PORT, VTSS_CHIP_PORT_CPU, MISCCFG, 1<<1); /* Enable dropping */
#else
            /* Reset capture block */
            HT_WR(CAPTURE, S_CAPTURE_RESET, CAPRST, 0);
#endif /* VTSS_ARCH_SPARX_28 */
#if VTSS_OPT_NICIO
            /* Enable MII port with VLAN awareness */
            HT_WRM(PORT, VTSS_MII_PORT_NO, CAT_VLAN_MISC, (0<<8) | (0<<7), ((1<<8) | (1<<7)));
            VTSS_RC(ht_port_setup(HT_MII_PORT_NO, &ht_mii_port_setup));
            VTSS_RC(ht_port_queue_enable(HT_MII_PORT_NO, 1));
#endif /* VTSS_OPT_NICIO */
        }
#endif /* VTSS_ARCH_SPARX */
        
        {
            vtss_ac_no_t ac;
            ulong        mask = VTSS_CHIP_PORTMASK;
            
            /* Enable all ports in IP MC flood mask */
            VTSS_RC(ht_ipmc_flood_mask_set(mask));

#if VTSS_OPT_NICIO
            mask |= 1 << VTSS_MII_PORT_NO; /* Include MII port in recvmask */
            HT_WRF(ANALYZER, 0, AGENCNTL, 15, 1, 1); /* Set CPU_AWARE */
#endif /* VTSS_OPT_NICIO */

#if defined(VTSS_ARCH_SPARX_28)
            /* Ignore SMAC flags to avoid frames from own MAC addresses
               to be looped back when injected via CPU device */
            HT_WRF(ANALYZER, 0, AGENCNTL, 13, 0x1, 1);
            mask |= (1<<VTSS_CHIP_PORT_CPU);
#endif /* VTSS_ARCH_SPARX_28 */

            /* Enable all ports in RECVMASK */
            HT_WR(ANALYZER, 0, RECVMASK, mask);

            /* Clear aggregation masks */
            for (ac = VTSS_AC_START; ac < VTSS_AC_END; ac++) {
                HT_WR(ANALYZER, 0, AGGRMSKS + ac - VTSS_AC_START, 0);
            }
        }

        /* Disable learning for frames discarded by VLAN ingress filtering */
        HT_WRF(ANALYZER, 0, ADVLEARN, 29, 0x1, 0x1);

        /* Disable learning */
        HT_WR(ANALYZER, 0, LERNMASK, 0);

        return VTSS_OK;
    } 
    return VTSS_NOT_IMPLEMENTED;
}
