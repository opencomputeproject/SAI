/*

 Vitesse PHY API software.

 Copyright (c) 2004 Vitesse Semiconductor Corporation. All Rights Reserved.
 Unpublished rights reserved under the copyright laws of the United States of 
 America, other countries and international treaties. The software is provided
 without fee. Permission to use, copy, store, modify, disclose, transmit or 
 distribute the software is granted, provided that this copyright notice must 
 appear in any copy, modification, disclosure, transmission or distribution of 
 the software. Vitesse Semiconductor Corporation retains all ownership, 
 copyright, trade secret and proprietary rights in the software. THIS SOFTWARE
 HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY INCLUDING, 
 WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_phy_io.c,v 1.3 2005/05/03 12:22:55 hlb Exp $
 $Revision: 1.3 $

*/

#define VTSS_TRACE_LAYER 1
#define VTSS_TRACE_FILE "pio"

#if (defined(VTSS_FORCE_CPLD_MIIM) || !defined(VTSS_API)) && defined(VTSS_VITGENIO)
#include <linux/vitgenio.h>
#include <sys/ioctl.h> /* ioctl() */
#endif /* (VTSS_FORCE_CPLD_MIIM || !VTSS_API) && VTSS_VITGENIO */

#include "vtss_phy.h"

static vtss_phy_io_state_t * vtss_phy_io_state;

/* Select PHY I/O context */
void vtss_phy_io_select_context( vtss_phy_io_state_t * io )
{
    vtss_phy_io_state=io;
}

/* Reset PHY I/O Layer, must be called before any other function */
void vtss_phy_io_init(void)
{
    VTSS_D(("enter"));
}

/* Read PHY register */
vtss_rc vtss_phy_io_read(   const vtss_phy_io_bus_t bus,
                            const uint              addr,
                            const uint              reg,
                            ushort *const           value )
{
    vtss_rc rc;
#if (defined(VTSS_FORCE_CPLD_MIIM) || !defined(VTSS_API)) && defined(VTSS_VITGENIO)
    int val;
    /* arg=(phy_address<<5)|phy_register, returns result */
    val = ioctl(vtss_phy_io_state->fd,VITGENIO_GET_CPLD_MIIM,addr<<5|reg);
    if (val<0) {
        rc = VTSS_UNSPECIFIED_ERROR;
    } else {
        *value = val;
        rc = VTSS_OK;
    }
#else
#ifdef VTSS_API
    /* Use VTSS Switch API for accessing PHY management bus. */
    rc = vtss_miim_phy_read( VTSS_PHY_CHIPMIIM(bus), addr, reg, value );
#endif /* VTSS_API */
#endif /* !VTSS_API && VTSS_VITGENIO */
#ifdef VTSS_MYIO
    /* Insert your PHY read function here */
#endif /* VTSS_MYIO */
    if (rc<VTSS_WARNING) {
        VTSS_N(("bus: 0x%04x, addr: 0x%02x, reg: 0x%02x, value: ERROR",
                bus,addr,reg));
    } else {
        VTSS_N(("bus: 0x%04x, addr: 0x%02x, reg: 0x%02x, value: 0x%04x",
                bus,addr,reg,*value));
    }
    return rc;
}

/* Write PHY register */
vtss_rc vtss_phy_io_write(  const vtss_phy_io_bus_t bus,
                            const uint              addr,
                            const uint              reg,
                            const ushort            value )
{
    vtss_rc rc;
#if (defined(VTSS_FORCE_CPLD_MIIM) || !defined(VTSS_API)) && defined(VTSS_VITGENIO)
    /* arg=(phy_address<<(16+5))|(phy_register<<16)|value */
    if (ioctl( vtss_phy_io_state->fd, VITGENIO_SET_CPLD_MIIM, addr<<(16+5)|reg<<16|value )<0) {
        rc = VTSS_UNSPECIFIED_ERROR;
    } else {
        rc = VTSS_OK;
    }
#else
#ifdef VTSS_API
    /* Use VTSS Switch API for accessing PHY management bus. */
    rc = vtss_miim_phy_write( VTSS_PHY_CHIPMIIM(bus), addr, reg, value );
#endif /* VTSS_API */
#endif /* !VTSS_API && VTSS_VITGENIO */
#ifdef VTSS_MYIO
    /* Insert your PHY write function here */
#endif /* VTSS_MYIO */
    VTSS_N(("bus: 0x%04x, addr: 0x%02x, reg: 0x%02x, value: 0x%04x%s",
            bus,addr,reg,value,rc<0?" FAILED":""));
    return rc;
}
