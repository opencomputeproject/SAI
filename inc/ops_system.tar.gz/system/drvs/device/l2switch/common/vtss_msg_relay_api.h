/*

 Vitesse Switch Software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_msg_relay_api.h,v 1.3 2007/05/15 12:52:36 cpj Exp $
 $Revision: 1.3 $

*/

#ifndef _VTSS_MSG_RELAY_API_H_
#define _VTSS_MSG_RELAY_API_H_

#include "vtss_switch_api.h"

/****************************************************************************/
/* Message Relay initialization structure. */
/****************************************************************************/
typedef struct  {
    /* Logical stack port numbers */
    vtss_port_no_t stack_port_a;
    vtss_port_no_t stack_port_b;

    /* CPU queue to be used for Message PDUs */
    vtss_cpu_rx_queue_t cpu_qu;
} vtss_msg_relay_init_t;

/****************************************************************************
 * vtss_msg_relay_init()
 * 
 * Initializes Message Relay module. Must be called only once.
 ****************************************************************************/
vtss_rc vtss_msg_relay_init(vtss_msg_relay_init_t *setup);

/****************************************************************************
 * vtss_msg_relay_rx_pkt()
 * 
 * Message Protocol PDU received
 * 
 * Application must call this function when frames of the following 
 * type have been extracted from CPU extraction queue:
 * 
 *  0                   1                   2                   3
 *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |                             DMAC                              |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |           DMAC, cont.         |            * (SMAC)           |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |                            * (SMAC)                           |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |             0x8880            |1|             *               | (a)
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |                               *                               | (a)
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |                               *                               | (a)
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |             0x8880            |           0x0002              |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |             0x0002            |              *                |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * | * ...                                                         |
 *
 * Legend
 * ------
 * '*': Any value.
 * (a): These three 32-bit words, must be removed from 
 *      the frame prior to calling vtss_msg_relay_rx_pkt().
 ****************************************************************************/
vtss_rc vtss_msg_relay_rx_pkt(vtss_port_no_t port_no, uchar *frm, uint len);

#endif /* _VTSS_MSG_RELAY_API_H_ */

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
