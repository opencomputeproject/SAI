#ifndef _L2_SWITCH_H_
#define _L2_SWITCH_H_
#include "stdint.h"

typedef struct
{
    ulonglong rx_packets;
    ulonglong tx_packets;
    ulonglong rx_bytes;
    ulonglong tx_bytes;
    ulonglong rx_errors;
    ulonglong tx_errors;
    ulonglong rx_dropped;
    ulonglong tx_dropped;
} port_stats_t;

typedef struct spi_readwrite {
	unsigned char buffer[6];
} spi_readwrite;

#undef SOFT_SPI
#define HARDWARE_SPI
#define GET_PORT_ID(port) (port+1)

#ifdef SOFT_SPI
#define di_offset 0x200/4;
#define do_offset 0x208/4;
#define	clk_offset 0x20c/4;
#define en_offset 0x204/4;

volatile ulong *clk_addr;
volatile ulong *do_addr;
volatile ulong *di_addr;
volatile ulong *en_addr;


#define date_out(bit) if (bit) *do_addr |= 0xffffffff; else *do_addr &= 0x00000000
#define clk(bit)   if (bit) *clk_addr |= 0xffffffff; else *clk_addr &= 0x00000000

#elif defined (HARDWARE_SPI)
/* 
control_off: SPI control register offset
status_off : SPI status register offset
cmd_off: SPI command and address register offset
read_off: SPI read data register offset
write_off: SPI write data register offset
*/
//volatile ulong *control_addr;
//volatile ulong *status_addr;
//volatile ushort *cmd_addr;
//volatile ulong *read_addr;
//volatile ulong *write_addr;

#define control_off 	0x00
#define status_off  	0x08
#define cmd_off     	0x10
#define	read_off    	0x18
#define write_off   	0x14
#define SPI_BUSY    	0x3000000
#define TIMEOUT     	0x7ff

#endif
//void swap(ulong *value);
int vtss_port_check_link(uint8_t port);
void vtss_enable_port(uint8_t port);
void vtss_disable_port(uint8_t port);
void vtss_port_get_stats(uint8_t port, port_stats_t *stats);
int vtss_en_phy_loopback(uint8_t port);
int vtss_en_phy_far_end_loopback(uint8_t port);
int vtss_dis_phy_loopback(uint8_t port);
int vtss_dis_phy_far_end_loopback(uint8_t port);
#endif

