/*
 
 Vitesse Switch Software.
 
 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_sparx_g5_g8_qs.h,v 1.4 2007/05/15 12:52:37 cpj Exp $
 $Revision: 1.4 $

*/

/****************************************************************************/
/*                                                                          */
/*  Typedefs for SparX-G5/G8 watermarks                                     */
/*                                                                          */
/****************************************************************************/

#ifndef _SPARX_G5_G8_QS_H_
#define _SPARX_G5_G8_QS_H_

#define VTSS_SPARX_WM_COUNT    4

typedef unsigned short vtss_qs_t;

typedef struct _vtss_sparx_g5_g8_qs_units_t {
    vtss_qs_t early_tx;
    vtss_qs_t fwdp_start;
    vtss_qs_t fwdp_stop;
    vtss_qs_t emin[VTSS_SPARX_WM_COUNT];
    vtss_qs_t emax[VTSS_SPARX_WM_COUNT];
    vtss_qs_t imin[VTSS_SPARX_WM_COUNT];
    vtss_qs_t imax[VTSS_SPARX_WM_COUNT];
    vtss_qs_t zeropause;
    vtss_qs_t pausevalue;
} vtss_sparx_g5_g8_qs_units_t;

typedef struct _vtss_sparx_g5_g8_qs_t
{
    vtss_sparx_g5_g8_qs_units_t norm_4s_drop;
    vtss_sparx_g5_g8_qs_units_t norm_4w_drop;
    vtss_sparx_g5_g8_qs_units_t norm_4s_fc;
    vtss_sparx_g5_g8_qs_units_t norm_4w_fc;
    vtss_sparx_g5_g8_qs_units_t jumbo_4s_drop;
    vtss_sparx_g5_g8_qs_units_t jumbo_4w_drop;
    vtss_sparx_g5_g8_qs_units_t jumbo_4s_fc;
    vtss_sparx_g5_g8_qs_units_t jumbo_4w_fc;
} vtss_sparx_g5_g8_qs_t;

extern const vtss_sparx_g5_g8_qs_t vtss_sparx_g5_g8_qs;
extern const vtss_sparx_g5_g8_qs_t vtss_sparx_g5e_g8e_qs;

#endif /* _SPARX_G5_G8_QS_H_ */
