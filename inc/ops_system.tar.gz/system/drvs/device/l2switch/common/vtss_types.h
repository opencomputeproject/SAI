/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2003 Vitesse Semiconductor Corporation. All Rights Reserved.
 Unpublished rights reserved under the copyright laws of the United States of 
 America, other countries and international treaties. The software is provided
 without fee. Permission to use, copy, store, modify, disclose, transmit or 
 distribute the software is granted, provided that this copyright notice must 
 appear in any copy, modification, disclosure, transmission or distribution of 
 the software. Vitesse Semiconductor Corporation retains all ownership, 
 copyright, trade secret and proprietary rights in the software. THIS SOFTWARE
 HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY INCLUDING, 
 WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_types.h,v 1.3 2006/09/07 14:30:30 cpj Exp $
 $Revision: 1.3 $

*/

#ifndef _VTSS_TYPES_H_
#define _VTSS_TYPES_H_

/* - Port Numbers -------------------------------------------------- */

/* Port Number: 1..VTSS_PORTS */
typedef uint vtss_port_no_t;    /* VTSS_PORT_NO_START..(VTSS_PORT_NO_END-1) */

/* - MAC interface ------------------------------------------------- */

/* The different interfaces for connecting MAC and PHY. */
typedef enum _vtss_port_interface_t {
    VTSS_PORT_INTERFACE_NO_CONNECTION, /* No connection */
    VTSS_PORT_INTERFACE_LOOPBACK,      /* Internal loopback in MAC */
    VTSS_PORT_INTERFACE_INTERNAL,      /* Internal interface */
    VTSS_PORT_INTERFACE_MII,           /* MII (RMII does not exist) */
    VTSS_PORT_INTERFACE_GMII,          /* GMII */
    VTSS_PORT_INTERFACE_RGMII,         /* RGMII */
    VTSS_PORT_INTERFACE_TBI,           /* TBI */
    VTSS_PORT_INTERFACE_RTBI,          /* RTBI */
    VTSS_PORT_INTERFACE_SGMII,         /* SGMII */
    VTSS_PORT_INTERFACE_SERDES,        /* SERDES */
    VTSS_PORT_INTERFACE_VAUI,          /* VAUI */
    VTSS_PORT_INTERFACE_XGMII          /* XGMII */
} vtss_port_interface_t;

/* - Speed --------------------------------------------------------- */

/* Speed type */
typedef enum _vtss_speed_t {
    VTSS_SPEED_UNDEFINED,
    VTSS_SPEED_10M,
    VTSS_SPEED_100M,
    VTSS_SPEED_1G,
    VTSS_SPEED_2500M, /* 2.5G */
    VTSS_SPEED_5G,    /* 5G or 2x2.5G */
    VTSS_SPEED_10G
} vtss_speed_t;

/* - Port Status --------------------------------------------------- */

typedef struct _vtss_port_status_t {
    vtss_event_t link_down;  /* Link down event occurred since last call */
    BOOL         link;       /* Link is up. Remaining fields only valid if TRUE */
    vtss_speed_t speed;      /* Speed */
    BOOL         fdx;        /* Full duplex */
    
    /* Auto negotiation result */
    struct {
        BOOL obey_pause;     /* This port should obey PAUSE frames */
        BOOL generate_pause; /* Link partner obeys PAUSE frames */
    } aneg;
} vtss_port_status_t;

#define VTSS_RC(expr) { vtss_rc rc = (expr); if (rc < VTSS_OK) return rc; }

#endif /* _VTSS_TYPES_H_ */
