/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_options.h,v 1.22 2007/10/29 13:41:30 cpj Exp $
 $Revision: 1.22 $

*/

#ifndef _VTSS_OPTIONS_H_
#define _VTSS_OPTIONS_H_

/* ================================================================= *
   Introduction:
   The API consists of a number of components. Each component may
   have its own source files, API and compile options. This file 
   describes each component briefly. Compile options for switch/PHY 
   API and the application component are also included.
   For other components, please refer to the API header files listed.
 * ================================================================= */


/* ================================================================= *
   Switch API component
   --------------------
   Description: Switch API (PHY API must be included)
   Directory  : gw_api
   API        : vtss_switch_api.h
   Files      : vtss_os.c, vtss_basic_trace.c, vtss_io.c, 
                vtss_sparx_g8_qs.c vtss_sparx_g8e_qs.c, 
                vtss_sparx.c/vtss_gatwick.c, vtss_switch.c
   Build      : Define target switch chip, for example E_STAX_34.
 * ================================================================= */
   

/* ================================================================= *
   PHY API component
   -----------------
   Description: PHY API
   API        : vtss_phy.h
   Directory  : gw_api
   Files      : vtss_phy_io.c, vtss_phy.c, vtss_phy_veriphy.c
   Build      : Supports all PHY types at runtime.
 * ================================================================= */

  
/* ================================================================= *
   Application component
   ---------------------
   Description: Application example.
   Directory  : gw_api
   Files      : vtss_appl.c 
   Build      : May include TRACE, SPROUT, MLD and ROUTER.
 * ================================================================= */


/* ================================================================= *
   TRACE component
   ---------------
   Description: Code trace system for debugging. 
   Directory  : sw_misc_util
   API        : vtss_trace_api.h
   Files      : vtss_trace.c, vtss_trace_io.c
   Build      : Define VTSS_TRACE to include this. If this is not defined,
                switch/PHY API trace macros are mapped to printf or
                similar (vtss_basic_trace.h).
 * ================================================================= */


/* ================================================================= *
   FDMA component
   Description: Frame DMA API for E_STAX_34 switch.
   Directory  : sw_fdma
   API        : vtss_fdma_api.h
   Files      : vtss_fdma.c
   Build      : Currently not used by vtss_appl.c.
 * ================================================================= */


/* ================================================================= *
   SPROUT component
   ----------------
   Description: Stacking protocol for E_STAX_34 switch. 
   Directory  : sw_sprout
   API        : vtss_sprout_api.h
   Files      : *.c
   Build      : SPROUT API may be included in vtss_appl.c.
 * ================================================================= */

/* Set this to 1 to enable SPROUT in vtss_appl.c */
#ifndef VTSS_OPT_SPROUT
#if defined(VTSS_FEATURE_VSTAX)
#define VTSS_OPT_SPROUT 1
#else
#define VTSS_OPT_SPROUT 0
#endif /* VTSS_FEATURE_VSTAX */
#endif /* VTSS_OPT_SPROUT */ 

/* ================================================================= *
   MLD component
   -------------
   Description: MLD snooping for SPARX_G5 switch. 
   Directory  : gw_api
   API        : vtss_mld_api.h
   Files      : vtss_mld.c
   Build      : MLD API may be included in vtss_appl.c.
 * ================================================================= */

/* Set this to 1 to enable MLD snooping API and control in vtss_appl.c */
#ifndef VTSS_OPT_MLD
#define VTSS_OPT_MLD 0
#endif /* VTSS_OPT_MLD */

/* MLD maximum number of multicast groups */
#if !defined(VTSS_OPT_MLD_MAXGROUPS)
#define VTSS_OPT_MLD_MAXGROUPS 200
#endif /* VTSS_OPT_MLD_MAXGROUPS */

/* MLD age timer. Use [Multicast Listener Interval] as age timer.
   Add a little time to allow for jitter and timer drift in the GQ-transmitting router.
   RFC 2710 default [Multicast Listener Interval] is 260 seconds. */
#if !defined(VTSS_OPT_MLD_AGE_TIMER)
#define VTSS_OPT_MLD_AGE_TIMER (260000+500) /**< milliseconds */
#endif /* VTSS_OPT_MLD_AGE_TIMER */

/* ================================================================= *
   Message Protocol Relaying component
   ----------------
   Description: Message Protcol Relaying for E_STAX_34 switch.
   Directory  : gw_api
   API        : vtss_msg_relay_api.h
   Files      : vtss_msg_relay.c
   Build      : Msg Relay API may be included in vtss_appl.c.
 * ================================================================= */
/* Set this to 1 to enable Message Protocol Relaying in vtss_appl.c */
#ifndef VTSS_OPT_MSG_RELAY
#if defined(VTSS_FEATURE_VSTAX)
#define VTSS_OPT_MSG_RELAY 1
#else
#define VTSS_OPT_MSG_RELAY 0
#endif /* VTSS_FEATURE_VSTAX */
#endif /* VTSS_OPT_MSG_RELAY */ 

/* ================================================================= *
   Router component
   ----------------
   Description: Router for SPARX_G5 or G-RocX switch. 
   Directory  : gw_api
   Build      : Define VTSS_OPT_ROUTER=1 to include this in vtss_appl.c.
 * ================================================================= */

/* The router includes the following setup:
   
     +-------+
     | Router|  
     +-------+
         | Router port(s)
   +----------+
   |  Switch  |      
   +----------+
    | | | |  | <-- WAN port (optional)  
   (LAN ports)     

   By default, all ports are VLAN unaware and included in VLAN 1 only.
   If an optional WAN port is specified, the following VLAN setup is used:
   - LAN ports in VLAN 1
   - WAN port in VLAN 2
   - Router port is in both VLANs and sends tagged frames.
   - G-RocX: If a second router port is present, the first router port is in VLAN 1 and 
     the second router port is in VLAN 2. Both router ports then send untagged frames.
*/

/* Enable router by setting this to 1 */
#ifdef G_ROCX /* Router always enabled for G-RocX */
#define VTSS_OPT_ROUTER 1
#endif /* G_ROCX */
#ifdef VTSS_OPT_SPARX_G5_ROUTER /* Backward compatibility */
#define VTSS_OPT_ROUTER VTSS_OPT_SPARX_G5_ROUTER 
#endif /* VTSS_OPT_SPARX_G5_ROUTER */
#ifndef VTSS_OPT_ROUTER
#define VTSS_OPT_ROUTER 0
#endif /* VTSS_OPT_ROUTER */

/* Select router port flow control mode */
#ifndef VTSS_OPT_ROUTER_PORT_FLOW_CONTROL
#define VTSS_OPT_ROUTER_PORT_FLOW_CONTROL 1
#endif /* VTSS_OPT_ROUTER_PORT_FLOW_CONTROL */

/* Select router WAN port:
   0  : No WAN port is present
   1-5: Selected port is WAN port */
#ifndef VTSS_OPT_ROUTER_PORT_WAN
#define VTSS_OPT_ROUTER_PORT_WAN 0
#endif /* VTSS_OPT_ROUTER_PORT_WAN */

/* Second router WAN port */
#ifndef VTSS_OPT_ROUTER_PORT_WAN2
#define VTSS_OPT_ROUTER_PORT_WAN2 0
#endif /* VTSS_OPT_ROUTER_PORT_WAN2 */

/* Set this to 1 to enable GMII on router port for SparX-G5 (default RGMII) */
#ifndef VTSS_OPT_ROUTER_PORT_CPU_IF
#define VTSS_OPT_ROUTER_PORT_CPU_IF 0
#endif /* VTSS_OPT_ROUTER_PORT_CPU_IF */

/* Set this to 1 to enable GMII on chip port 5 on G-RocX (default RGMII) */
#ifndef VTSS_OPT_ROUTER_PORT_5_IF
#define VTSS_OPT_ROUTER_PORT_5_IF 0
#endif /* VTSS_OPT_ROUTER_PORT_CPU_IF */

/* Set this to 1 to enable WLAN port on chip port 6 via RGMII on G-RocX */
#ifndef VTSS_OPT_ROUTER_WLAN_RGMII
#define VTSS_OPT_ROUTER_WLAN_RGMII 0
#endif /* VTSS_OPT_ROUTER_WLAN_RGMII */

/* ================================================================= *
   CLI component
   -------------
   Description: 'Mini' Command Line Interface. 
   Directory  : gw_api
   Files      : vtss_cli.c
   Build      : CLI API may be included in vtss_appl.c.
 * ================================================================= */

/* Set this to 1 to enable CLI in vtss_appl.c */
#ifndef VTSS_OPT_CLI
#define VTSS_OPT_CLI 1
#endif /* VTSS_OPT_CLI */


/* ================================================================= *
 *  Switch/PHY API options
 * ================================================================= */

/* - Number of ports ----------------------------------------------- */

#if !defined(VTSS_OPT_PORT_COUNT)
#define VTSS_OPT_PORT_COUNT 0
#endif /* VTSS_OPT_PORT_COUNT */

/* - Internal VCore-II (ARM) CPU ----------------------------------- */

#if !defined(VTSS_OPT_VCORE_II)
#if defined(VTSS_ARCH_SPARX_28)
/* Internal VCore-II (ARM) CPU is enabled */
#define VTSS_OPT_VCORE_II 1
#else
#define VTSS_OPT_VCORE_II 0
#endif /* VTSS_ARCH_SPARX_28 */
#endif /* VTSS_OPT_VCORE_II */

/* Single ended clock design */
#if !defined(VTSS_OPT_REF_CLK_SINGLE_ENDED)
#if defined(VTSS_ARCH_SPARX_28)
#define VTSS_OPT_REF_CLK_SINGLE_ENDED 1
#else
#define VTSS_OPT_REF_CLK_SINGLE_ENDED 0
#endif /* VTSS_ARCH_SPARX_28 */
#endif /* VTSS_OPT_REF_CLK_SINGLE_ENDED */

/* Shared UART/GPIO pins in UART mode */
#if !defined(VTSS_OPT_UART)
#if VTSS_OPT_VCORE_II
#define VTSS_OPT_UART 1
#else
#define VTSS_OPT_UART 0
#endif /* VTSS_OPT_VCORE_II */
#endif /* VTSS_OPT_UART */

/* Internal aggregation of VAUI port pairs */
#if !defined(VTSS_OPT_INT_AGGR)
#if defined(VTSS_FEATURE_VSTAX)
#define VTSS_OPT_INT_AGGR 1
#else
#define VTSS_OPT_INT_AGGR 0
#endif /* VTSS_FEATURE_VSTAX */
#endif /* VTSS_OPT_INT_AGGR */

/* Chip port masks for stack A stack B */
#if !defined(VTSS_OPT_STACK_A_MASK)
#define VTSS_OPT_STACK_A_MASK 0x03000000 /* Port 24 and 25 */
#endif /* VTSS_OPT_STACK_A_MASK */
#if !defined(VTSS_OPT_STACK_B_MASK)
#define VTSS_OPT_STACK_B_MASK 0x0c000000 /* Port 26 and 27 */
#endif /* VTSS_OPT_STACK_B_MASK */

/* VAUI equalization control, change value to 10 if PCB trace is more than 15 cm */
#if !defined(VTSS_OPT_VAUI_EQ_CTRL)
#define VTSS_OPT_VAUI_EQ_CTRL 6
#endif /* VTSS_OPT_VAUI_EQ_CTRL */

/* Load code to VCore-I (iCPU) */
#if !defined(VTSS_OPT_ICPU_LOAD)
#define VTSS_OPT_ICPU_LOAD 0
#endif /* VTSS_OPT_ICPU_LOAD */

/* Maximum number of entries for MAC address table age scan */
/* Backward compatibility define */
#if defined(VTSS_MAC_AGE_MAX)
#define VTSS_OPT_MAC_AGE_MAX VTSS_MAC_AGE_MAX
#endif /* VTSS_MAC_AGE_MAX */
#if !defined(VTSS_OPT_MAC_AGE_MAX)
#define VTSS_OPT_MAC_AGE_MAX 8192
#endif /* VTSS_OPT_MAC_AGE_MAX */

/* Maximum number of entries for MAC address table port flush */
#if !defined(VTSS_OPT_MAC_FLUSH_PORT_MAX)
#define VTSS_OPT_MAC_FLUSH_PORT_MAX 8192
#endif /* VTSS_OPT_MAC_FLUSH_PORT_MAX */

#if defined(HEATHROW3) || defined(STAPLEFORD)
/* - Design Consideration #1 --------------------------------------- *
 * VTSS_OPT_FC_SHAPING_BUCKET_RATE == 0 : Disabled
 * VTSS_OPT_FC_SHAPING_BUCKET_RATE == 1 : Auto
 * VTSS_OPT_FC_SHAPING_BUCKET_RATE > 1 : Value for shaper bucket rate
 */
#define VTSS_OPT_FC_SHAPING_BUCKET_RATE 1
#endif

/* Maximum number of entries for MAC address table synchronization.
   The value zero means disabled. */
#if defined(FAIROAKS48) || defined(GATWICK48)
#if !defined(VTSS_OPT_MAC_SYNC_MAX)
#define VTSS_OPT_MAC_SYNC_MAX 128
#endif /* VTSS_OPT_MAC_SYNC_MAX */
#endif /* FAIROAKS48/GATWICK48 */

/* Number of updated MAC table entries for get next traversal. 
   Must be a multiplum of 4. The value zero means disabled */
#if !defined(VTSS_OPT_MAC_NEXT_MAX)
#define VTSS_OPT_MAC_NEXT_MAX 1024
#endif /* VTSS_OPT_MAC_NEXT_MAX */

/* - VeriPHY included when compiling ------------------------------- *
 * VTSS_PHY_OPT_VERIPHY == 0 : Omit VeriPHY functions
 * VTSS_PHY_OPT_VERIPHY == 1 : Include VeriPHY functions
 */
#if !defined(VTSS_PHY_OPT_VERIPHY)
#define VTSS_PHY_OPT_VERIPHY 1
#endif /* VTSS_PHY_OPT_VERIPHY */

/* External CPU */
#if !defined(EXTERNAL_CPU_VERIPHY)
#define EXTERNAL_CPU_VERIPHY 1
#endif /* EXTERNAL_CPU_VERIPHY */

/* Maximum ARP block size for Layer 3 */
#if !defined(VTSS_OPT_ARP_MAX)
#define VTSS_OPT_ARP_MAX 256
#endif /* VTSS_OPT_ARP_MAX */ 

/* DMA packet extraction for Fairoaks-Ie/Gatwick-Ie */
#if !defined(VTSS_OPT_DMA)
#define VTSS_OPT_DMA 0
#endif /* VTSS_OPT_DMA */

/* MII NIC packet extraction/injection for SparX-G24 */
#if !defined(VTSS_OPT_NICIO)
#ifdef SPARX_G24
#define VTSS_OPT_NICIO 1
#define VTSS_LINUX_RAWSOCK_IO /* Use Linux packet socket for I/O layer */
#else
#define VTSS_OPT_NICIO 0
#undef VTSS_LINUX_RAWSOCK_IO
#endif
#endif /* VTSS_OPT_NICIO */

/* SparX-G24 revision C queue system setup using early transmit */
#if !defined(VTSS_OPT_EARLY_TX)
#define VTSS_OPT_EARLY_TX 0
#endif /* VTSS_OPT_EARLY_TX */

/* Fast core clock for 12G on Fairoaks-Ie/Gatwick-Ie */ 
#if !defined(VTSS_OPT_12G)
#if defined(FAIROAKS48) || defined(GATWICK48)
#define VTSS_OPT_12G 1
#else
#define VTSS_OPT_12G 0
#endif
#endif

/* Flow control on internal ports for 48-port solutions */
#if !defined(VTSS_OPT_INT_PORT_FC)
#define VTSS_OPT_INT_PORT_FC 0
#endif /* VTSS_OPT_INT_PORT_FC */

/* Allow mirror port on each chip for 48-port platforms */
#if !defined(VTSS_OPT_DUAL_MIRROR_PORTS)
#define VTSS_OPT_DUAL_MIRROR_PORTS 0
#endif /* VTSS_OPT_DUAL_MIRROR_PORTS */

#if defined(VTSS_ARCH_GATWICK)
/* Include FCS in CPU injected/extracted packets */
#if !defined(VTSS_OPT_INCLUDE_FCS)
#define VTSS_OPT_INCLUDE_FCS 0
#endif /* VTSS_OPT_INCLUDE_FCS */
#endif /* VTSS_ARCH_GATWICK */

#endif /* _VTSS_OPTIONS_H_ */

