/*

 Vitesse Switch API software.

 Copyright (c) 2003 Vitesse Semiconductor Corporation. All Rights Reserved.
 Unpublished rights reserved under the copyright laws of the United States of 
 America, other countries and international treaties. The software is provided
 without fee. Permission to use, copy, store, modify, disclose, transmit or 
 distribute the software is granted, provided that this copyright notice must 
 appear in any copy, modification, disclosure, transmission or distribution of 
 the software. Vitesse Semiconductor Corporation retains all ownership, 
 copyright, trade secret and proprietary rights in the software. THIS SOFTWARE
 HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY INCLUDING, 
 WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_io.h,v 1.14 2005/10/05 13:41:29 kimrp Exp $
 $Revision: 1.14 $

*/

#ifndef _VTSS_IO_H_
#define _VTSS_IO_H_


/* I/O architecture */
#if defined(VTSS_ARCH_HEATHROW)
#define VTSS_IO_HEATHROW    /* Heathrow chip i/o architecture */
#endif /* VTSS_ARCH_HEATHROW */

#if defined(VTSS_ARCH_GATWICK)
#define VTSS_IO_GATWICK     /* Gatwick chip i/o architecture */
#endif /* VTSS_ARCH_GATWICK */

/* I/O layer state information */
typedef struct _vtss_io_state_t {
#ifdef VTSS_VITGENIO
    int   fd; /* File descriptor */
#if VTSS_OPT_DMA
    int   dma_ch;   /* DMA channel number */
    uchar *dma_mem; /* DMA memory start pointer */
    uint  dma_size; /* DMA memory size */
    int   dma_offs; /* DMA memory offset to next byte to read */
#endif /* VTSS_OPT_DMA */
#endif /* VTSS_VITGENIO */
//#ifdef VTSS_MEMORYMAPPEDIO
    volatile ulong *baseaddr; /* Base address of the chip */
    void *spi_handle;  /*handle of the spi low level operations */
//#endif /* VTSS_MEMORYMAPPEDIO */
#if VTSS_OPT_NICIO
#ifdef VTSS_LINUX_RAWSOCK_IO
    int nic_fd;     /* RAW NIC socket on Linux */
#endif
#endif
} vtss_io_state_t;

/* Select I/O */
void vtss_io_select_chip(vtss_io_state_t *io);

/* Initialize I/O Layer, must be called before any other function */
void vtss_io_init(void);

#if defined(VTSS_IO_HEATHROW)

vtss_rc vtss_io_si_rd(uint block, uint subblock, const uint reg, ulong * const value);
vtss_rc vtss_io_si_wr(uint block, uint subblock, const uint reg, const ulong value);

vtss_rc vtss_io_pi_rd(uint block, uint subblock, const uint reg, ulong * const value);
vtss_rc vtss_io_pi_wr(uint block, uint subblock, const uint reg, const ulong value);

#endif /* VTSS_IO_HEATHROW */

#if defined(VTSS_IO_GATWICK)

/* Setup DMA driver */
vtss_rc vtss_io_dma_init(void);

/* Read DMA buffer */
vtss_rc vtss_io_dma_read(int len, uchar *data, int skip);

/* Read SI register */
vtss_rc vtss_io_si_rd(uint target, uint address, ulong *value);

/* Write SI register */
vtss_rc vtss_io_si_wr(uint target, uint address, ulong value);

/* Read PI register */
vtss_rc vtss_io_pi_rd(uint block, uint address, ulong *value);

/* Write PI register */
vtss_rc vtss_io_pi_wr(uint block, uint address, ulong value);

/* Read target register using PI */
vtss_rc vtss_io_pi_tgt_rd(uint target, uint address, ulong *value);

/* Write target register using PI */
vtss_rc vtss_io_pi_tgt_wr(uint target, uint address, ulong value);

#endif /* VTSS_IO_GATWICK */

#if VTSS_OPT_NICIO
/* Copy raw frame to OS driver's tx frame buffer and enqueue OS buffer for transmission */
vtss_rc vtss_io_nic_tx(const uchar * const frame,
                       const uint          length);

/* Is an OS rx frame buffer ready for reading */
/* Returns: 0: no frame ready, <0: error, >0: frame ready */
vtss_rc vtss_io_nic_rx_ready(void);

/* Copy raw frame from OS driver's rx frame buffer and release OS driver's rx frame buffer */
vtss_rc vtss_io_nic_rx(uchar * const frame,
                       const uint maxlength);
#endif

#endif /* _VTSS_IO_H_ */
