/*

 Vitesse Switch/PHY API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_basic_trace.h,v 1.6 2007/05/15 12:52:36 cpj Exp $
 $Revision: 1.6 $

*/

/*
 * This file contains trace macroes for use within the switch API.
 * The macroes should not be used outside the switch API.
 *
 * Optionally the macroes can be mapped into the more advanced
 * trace system in vtss_trace_api.h.
 */

#ifndef _VTSS_BASIC_TRACE_H_
#define _VTSS_BASIC_TRACE_H_
#undef VTSS_TRACE_ENABLED
#undef VTSS_TRACE
#if defined(VTSS_TRACE)
/* Redirect basic trace to vtss_trace_api.h */
#define VTSS_BASIC_TRACE_USE_ADVANCED 1
#endif

#if defined(VTSS_BASIC_TRACE_USE_ADVANCED)
/* 
 * Function during initialization phase when remapping basic_trace to
 * vtss_trace_api.h.
 */
void vtss_basic_trace_register(void);
#endif

/* ================================================================= *
 *  Debugging Macros:
 *    VTSS_E(args) - Error.
 *    VTSS_I(args) - Info. Use only temporarily for bug hunting.
 *    VTSS_D(args) - Debug.
 *    VTSS_N(args) - Noise.
 *    VTSS_A(expr,args) - Assert with error message.
 *
 *    Usage Examples:
 *      VTSS_E(("Port %d",port_no));
 *      VTSS_A(rc>=VTSS_WARNING,("Port %d rc=%d",port_no,rc));
 * ================================================================= */

#if !defined(VTSS_E)
//#define VTSS_E(args) { if (VTSS_CUR_LEVEL <= VTSS_TRACE_LVL_ERROR) { vtss_trace_module = VTSS_TRACE_MODULE_ID; vtss_trace_level = VTSS_TRACE_LVL_ERROR; vtss_trace_func = __FUNCTION__; vtss_trace_line = __LINE__; vtss_basic_trace args; }}
//#define VTSS_E(args) { }
/* You may define your own VTSS_E here. */
#endif
#if !defined(VTSS_I)
#define VTSS_I(args) { }
/* You may define your own VTSS_I here. */
#endif
#if !defined(VTSS_D)
#define VTSS_D(args) { }
/* You may define your own VTSS_D here. */
#endif
#if !defined(VTSS_N)
#define VTSS_N(args) { }
/* You may define your own VTSS_N here. */
#endif
#if !defined(VTSS_A)
/* You may define your own VTSS_A here. */
#endif

#if !defined(VTSS_TRACE_FILE)
#define VTSS_TRACE_FILE "app"
#endif /* VTSS_TRACE_FILE */

#if defined(VTSS_BASIC_TRACE_USE_ADVANCED) && defined(VTSS_TRACE_LAYER)
/* 
 * VTSS_X macroes must be mapped to sw_misc_util/trace.* 
 *
 * In such context VTSS_X macros are only to be used by switch API.
 * Other modules must use sw_misc_util/trace.* directly.
 */
#include <vtss_trace_lvl_api.h>
#include <vtss_trace_api.h>
#include <vtss_module_id.h>

extern vtss_trace_reg_t vtss_trace_reg_api[3];
extern vtss_trace_grp_t vtss_trace_grps_api[3][1];

extern const char *vtss_trace_func;
extern int vtss_trace_line;
extern int vtss_trace_module;
extern int vtss_trace_level;
void vtss_basic_trace(const char *fmt, ...);

#if (VTSS_TRACE_LAYER == 1)
#define VTSS_TRACE_MODULE_ID        VTSS_MODULE_ID_API_IO
#define VTSS_TRACE_REG_API_IDX 0
#elif (VTSS_TRACE_LAYER == 2)
#define VTSS_TRACE_MODULE_ID        VTSS_MODULE_ID_API_CI
#define VTSS_TRACE_REG_API_IDX 1
#elif (VTSS_TRACE_LAYER == 3)
#define VTSS_TRACE_MODULE_ID        VTSS_MODULE_ID_API_AI
#define VTSS_TRACE_REG_API_IDX 2
#elif (VTSS_TRACE_LAYER == 4)
/* Application layer has done its own default group registration */
#else
#error "Unknown value of VTSS_TRACE_LAYER"
#endif

#if (VTSS_TRACE_ENABLED)

/* Current trace level comes from application registration or API registration */ 
#if (VTSS_TRACE_LAYER == 4)
#define VTSS_CUR_LEVEL (trace_grps[VTSS_TRACE_GRP_DEFAULT].lvl)
#else
#define VTSS_CUR_LEVEL (vtss_trace_grps_api[VTSS_TRACE_REG_API_IDX][0].lvl)
#endif 

#if !defined(VTSS_E)
#define VTSS_E(args) { if (VTSS_CUR_LEVEL <= VTSS_TRACE_LVL_ERROR) { vtss_trace_module = VTSS_TRACE_MODULE_ID; vtss_trace_level = VTSS_TRACE_LVL_ERROR; vtss_trace_func = __FUNCTION__; vtss_trace_line = __LINE__; vtss_basic_trace args; }}
#endif /* VTSS_E */

#if !defined(VTSS_I)
#define VTSS_I(args) { if (VTSS_CUR_LEVEL <= VTSS_TRACE_LVL_INFO) { vtss_trace_module = VTSS_TRACE_MODULE_ID; vtss_trace_level = VTSS_TRACE_LVL_INFO; vtss_trace_func = __FUNCTION__; vtss_trace_line = __LINE__; vtss_basic_trace args; }}
#endif /* VTSS_I */

#if !defined(VTSS_D)
#define VTSS_D(args) { if (VTSS_CUR_LEVEL <= VTSS_TRACE_LVL_DEBUG) { vtss_trace_module = VTSS_TRACE_MODULE_ID; vtss_trace_level = VTSS_TRACE_LVL_DEBUG; vtss_trace_func = __FUNCTION__; vtss_trace_line = __LINE__; vtss_basic_trace args; }}
#endif /* VTSS_D */

#if !defined(VTSS_N)
#define VTSS_N(args) { if (VTSS_CUR_LEVEL <= VTSS_TRACE_LVL_NOISE) { vtss_trace_module = VTSS_TRACE_MODULE_ID; vtss_trace_level = VTSS_TRACE_LVL_NOISE; vtss_trace_func = __FUNCTION__; vtss_trace_line = __LINE__; vtss_basic_trace args; }}
#endif /* VTSS_N */
#else 
#define VTSS_E(args) { }
#define VTSS_I(args) { }
#define VTSS_D(args) { }
#define VTSS_N(args) { }
#endif /* VTSS_TRACE_ENABLED */


#endif /* VTSS_BASIC_TRACE_USE_ADVANCED && VTSS_TRACE_LAYER */

#if defined(VTSS_OPSYS_ECOS)
#include <stdio.h>
#if !defined(VTSS_E)
#define VTSS_E(args) { printf("E:" VTSS_TRACE_FILE ":%s#%d: ",__FUNCTION__,__LINE__); printf args; printf("\n"); }
#endif /* VTSS_E */
#if !defined(VTSS_I)
#define VTSS_I(args) { printf("I:" VTSS_TRACE_FILE ":%s#%d: ",__FUNCTION__,__LINE__); printf args; printf("\n"); }
#endif /* VTSS_I */
#if !defined(VTSS_D) 
#define VTSS_D(args) 
#endif /* VTSS_D */
#if !defined(VTSS_N)
#define VTSS_N(args) /* Empty */
#endif /* VTSS_N */
#define VTSS_A(expr,args) { const BOOL v=(expr); if (!v) { printf("A:" VTSS_TRACE_FILE ":%s#%d:(%s)=%d: ",__FUNCTION__,__LINE__,#expr,v); printf args; printf("\n"); VTSS_ASSERT(v); } }
#endif /* VTSS_OPSYS_ECOS */

#if defined(SWITCH_APP_TRACE)
/* Debugging for an VTSS internal application. */
#include <stdio.h>
#include <stdarg.h>

#include "vtss_os.h"
#include "vtss_errors.h"
#include "../sw_linux_switch/switch_app/trace.h"

extern const char *vtss_trace_func;
extern int vtss_trace_line;
extern int vtss_trace_module;
extern int vtss_trace_level;
void vtss_basic_trace(const char *fmt, ...);

#if !defined(VTSS_E)
#define VTSS_E(args) {vtss_trace_module=(VTSS_TRACE_LAYER==1 ? TR_MOD_API_IO : VTSS_TRACE_LAYER==2 ? TR_MOD_API_LL : TR_MOD_API_HL); if (trace_table[vtss_trace_module].level>=TR_LVL_ERR) { vtss_trace_level=TR_LVL_ERR; vtss_trace_func=__FUNCTION__; vtss_trace_line=__LINE__; vtss_basic_trace args;}}
#endif /* VTSS_E */
#if !defined(VTSS_I)
#define VTSS_I(args) {vtss_trace_module=(VTSS_TRACE_LAYER==1 ? TR_MOD_API_IO : VTSS_TRACE_LAYER==2 ? TR_MOD_API_LL : TR_MOD_API_HL); if (trace_table[vtss_trace_module].level>=TR_LVL_INFO) { vtss_trace_level=TR_LVL_INFO; vtss_trace_func=__FUNCTION__; vtss_trace_line=__LINE__; vtss_basic_trace args;}}
#endif /* VTSS_I */
#if !defined(VTSS_D)
#define VTSS_D(args) {vtss_trace_module=(VTSS_TRACE_LAYER==1 ? TR_MOD_API_IO : VTSS_TRACE_LAYER==2 ? TR_MOD_API_LL : TR_MOD_API_HL); if (trace_table[vtss_trace_module].level>=TR_LVL_DEBUG) { vtss_trace_level=TR_LVL_DEBUG; vtss_trace_func=__FUNCTION__; vtss_trace_line=__LINE__; vtss_basic_trace args;}}
#endif /* VTSS_D */
#if !defined(VTSS_N)
#define VTSS_N(args) {vtss_trace_module=(VTSS_TRACE_LAYER==1 ? TR_MOD_API_IO : VTSS_TRACE_LAYER==2 ? TR_MOD_API_LL : TR_MOD_API_HL); if (trace_table[vtss_trace_module].level>=TR_LVL_NOISE) { vtss_trace_level=TR_LVL_NOISE; vtss_trace_func=__FUNCTION__; vtss_trace_line=__LINE__; vtss_basic_trace args;}}
#endif /* VTSS_N */
#endif /* SWITCH_APP_TRACE */

#if (_POSIX_C_SOURCE > 0)
#include <stdio.h>
#if !defined(VTSS_E)
#define VTSS_E(args) { printf("E:" VTSS_TRACE_FILE ":%s#%d: ",__FUNCTION__,__LINE__); printf args; printf("\n"); }
#endif /* VTSS_E */
#if !defined(VTSS_I)
#define VTSS_I(args) { printf("I:" VTSS_TRACE_FILE ":%s#%d: ",__FUNCTION__,__LINE__); printf args; printf("\n"); }
#endif /* VTSS_I */
#if !defined(VTSS_D)
#define VTSS_D(args) { printf("D:" VTSS_TRACE_FILE ":%s#%d: ",__FUNCTION__,__LINE__); printf args; printf("\n"); }
#endif /* VTSS_D */
#if !defined(VTSS_N)
#define VTSS_N(args) /* Empty */
#endif /* VTSS_N */
#define VTSS_A(expr,args) { const BOOL v=(expr); if (!v) { printf("A:" VTSS_TRACE_FILE ":%s#%d:(%s)=%d: ",__FUNCTION__,__LINE__,#expr,v); printf args; printf("\n"); VTSS_ASSERT(v); } }
#endif /* _POSIX_C_SOURCE > 0 */

#if !defined(VTSS_E)
/* Fallback. */
#define VTSS_E(args)
#endif

#if !defined(VTSS_I)
/* Fallback. */
#define VTSS_I(args)
#endif

#if !defined(VTSS_D)
/* Fallback. */
#define VTSS_D(args)
#endif

#if !defined(VTSS_N)
/* Fallback. */
#define VTSS_N(args)
#endif

#if !defined(VTSS_A)
/* Fallback. */
#define VTSS_A(expr,args) { const BOOL v=(expr); if (!v) { VTSS_E("Assertion failing: (%s)=%d",#expr,v); VTSS_E(args); VTSS_ASSERT(v); } }
/* #define VTSS_A(expr,args) VTSS_ASSERT(expr) */
#endif

#endif /* _VTSS_BASIC_TRACE_H_ */

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
