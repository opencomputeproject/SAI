/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_appl.c,v 1.78 2007/10/25 07:08:56 cpj Exp $
 $Revision: 1.78 $
*/

/* Standard headers */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#if defined(VTSS_VITGENIO)
#include <linux/vitgenio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#endif /* VTSS_VITGENIO */

#if defined(VTSS_TRACE)
/* Advanced trace system used */
#include <vtss_trace_lvl_api.h>
#include <vtss_trace_api.h>

#define VTSS_TRACE_MODULE_ID   VTSS_MODULE_ID_UNMGD
#define VTSS_TRACE_GRP_DEFAULT 0
#define TRACE_GRP_CNT          1
#define VTSS_TRACE_LAYER       4
#else
#define VTSS_TRACE_FILE        "ap"
#define VTSS_TRACE_LAYER       3
#endif /* VTSS_TRACE */

/* API public headers */
#include "vtss_switch_api.h"
#if VTSS_OPT_MLD
#include "vtss_mld_api.h"
#endif /* VTSS_OPT_MLD */
#if VTSS_OPT_SPROUT
#include <vtss_sprout_api.h>
#endif /* VTSS_OPT_SPROUT */
#if VTSS_OPT_CLI
#include <vtss_cli.h>
#endif /* VTSS_OPT_SPROUT */
#if VTSS_OPT_MSG_RELAY
#include <vtss_msg_relay_api.h>
#endif /* VTSS_OPT_MSG_RELAY */
#if defined(VTSS_OPT_RAPI) && VTSS_OPT_RAPI
#include "vtss_rapi.h"
#endif /* VTSS_OPT_RAPI */
#include "vtss_appl_api.h"

/* SparX-G5 router definitions */
#define VTSS_ROUTER_VLAN_LAN  1
#define VTSS_ROUTER_VLAN_WAN  2
#define VTSS_ROUTER_VLAN_WAN2 3

#define STACK_PORT_A 25
#define STACK_PORT_B 26

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static vtss_trace_reg_t trace_reg =
{ 
    .module_id = VTSS_TRACE_MODULE_ID,
    .name      = "main",
    .descr     = "Main appl"
};


static vtss_trace_grp_t trace_grps[TRACE_GRP_CNT] =
{
    [VTSS_TRACE_GRP_DEFAULT] = { 
        .name      = "default",
        .descr     = "Default",
        .lvl       = VTSS_TRACE_LVL_ERROR,
        .timestamp = 0,
    },
};
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

/* Port status */
static vtss_appl_port_status_t port_status[VTSS_PORT_ARRAY_SIZE];

/* Port configuration */
static vtss_appl_port_conf_t port_conf[VTSS_PORT_ARRAY_SIZE];

/* ================================================================= *
 *  Board specific functions
 * ================================================================= */

/* Initialize CPU/switch interface */
static void board_cpu_if_init(vtss_io_state_t *io) 
{
#if defined(VTSS_MEMORYMAPPEDIO)
    /* Setup base address for memory mapped I/O */
    io->baseaddr = (ulong *) VTSS_MEMORYMAPPEDIO_BASE;
#endif

#if defined(VTSS_VITGENIO)
    int                             fd;
#if !defined(G_ROCX)
    struct vitgenio_cs_setup_timing timing;
#endif /* G_ROCX */

    /* Open driver */
    if ((fd = open("/dev/vitgenio", 0)) < 0) {
        VTSS_E(("open(\"/dev/vitgenio\"): %s",strerror(errno)));
        return;
    }

#if defined(VTSS_OPT_USE_CPU_SI)
    {   /* Setup SI interface */
        struct vitgenio_cpld_spi_setup timing = {
            /* char ss_select; Which of the GPIOs is used for Slave Select */
            VITGENIO_SPI_SS_CPLD_GPIO0,
            VITGENIO_SPI_SS_ACTIVE_LOW, /* char ss_activelow; Slave Select (Chip Select) active low: true, active high: false */
            VITGENIO_SPI_CPOL_0, /* char sck_activelow; CPOL=0: false, CPOL=1: true */
            VITGENIO_SPI_CPHA_0, /* char sck_phase_early; CPHA=0: false, CPHA=1: true */
            VITGENIO_SPI_MSBIT_FIRST, /* char bitorder_msbfirst; */
            0, /* char reserved1; currently unused, only here for alignment purposes */
            0, /* char reserved2; currently unused, only here for alignment purposes */
            0, /* char reserved3; currently unused, only here for alignment purposes */
            500 /* unsigned int ndelay; minimum delay in nanoseconds, two of these delays are used per clock cycle */
        };
        
        VTSS_D(("Setting up SPI timing"));
        /* Setup the SPI timing of the I/O Layer driver */
        ioctl(fd, VITGENIO_ENABLE_CPLD_SPI);
        ioctl(fd, VITGENIO_CPLD_SPI_SETUP, &timing);
    }
#endif /* VTSS_OPT_USE_CPU_SI */

    /* Setup Parallel Interface timing */
#if defined(BOARD_SPARX_G5_EVAL) || defined(BOARD_SPARX_G8_EVAL) || defined(BOARD_SPARX_G24_EVAL)
    timing.cs = VITGENIO_CS3;
#if defined(BOARD_SPARX_G24_EVAL)
    timing.bw = 16; /* Bus Width: bme=0,1,2 (aliases 8,16,32 accepted) */
#else
    timing.bw = 8; /* Bus Width: bme=0,1,2 (aliases 8,16,32 accepted) */
#endif /* BOARD_SPARX_G24_EVAL */
    timing.bme = 0; /* Burst Mode Enable. */
    timing.twt = 40; /* Transfer Wait. Only used when bme=0. (255 is max) */
    timing.fwt = 0; /* First Wait. Only used when bme=1. */
    timing.bwt = 0; /* Burst Wait. Only used when bme=1. */
    timing.csn = 1; /* Chip Select */
    timing.oen = 1; /* Output Enable */
    timing.wbn = 0; /* Write Byte Enable On */
    timing.wbf = 1; /* Write Byte Enable Off */
    timing.th = 2;  /* Transfer Hold (7 is max) */
    timing.re = 0;  /* Ready Enable */
    timing.sor = 0; /* Sample On Ready */
    timing.bem = 1; /* Byte Enable Mode */
    timing.pen = 0; /* Parity Enable */
    ioctl(fd, VITGENIO_CS_SETUP_TIMING, &timing);
#endif /* BOARD_SPARX_G8_EVAL/G5_EVAL */

#if !defined(G_ROCX)
    VTSS_D(("Using CS%d", timing.cs));
    ioctl(fd, VITGENIO_CS_SELECT, timing.cs );
#endif /* G_ROCX */
    io->fd = fd;
#endif /* VTSS_VITGENIO */
}

/* Board port map */
static vtss_mapped_port_t board_port_map[VTSS_PORT_ARRAY_SIZE] = { 
    { -1,-1, -1 } /*unused*/,
#if defined(SPARX_G5)
    {  0, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_MIIM_CONTROLLER_0,  1 },
    {  2, VTSS_MIIM_CONTROLLER_0,  2 },
    {  3, VTSS_MIIM_CONTROLLER_0,  3 },
    {  4, VTSS_MIIM_CONTROLLER_0,  4 },
#if VTSS_OPT_ROUTER
    {  6, VTSS_MIIM_CONTROLLER_NONE, -1 }
#else
    {  6, VTSS_MIIM_CONTROLLER_1,  3 }
#endif /* VTSS_OPT_ROUTER */
#endif /* SPARX_G5 */
#if defined(SPARX_G8)
    {  0, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_MIIM_CONTROLLER_0,  1 },
    {  2, VTSS_MIIM_CONTROLLER_0,  2 },
    {  7, VTSS_MIIM_CONTROLLER_0,  3 },
    {  3, VTSS_MIIM_CONTROLLER_0,  4 },
    {  6, VTSS_MIIM_CONTROLLER_0,  5 },
    {  4, VTSS_MIIM_CONTROLLER_0,  6 },
    {  5, VTSS_MIIM_CONTROLLER_0,  7 }
#endif /* SPARX_G8 */
#if defined(BOARD_SPARX_G24_EVAL)
    {  0, VTSS_MIIM_CONTROLLER_1,  0 },
    {  1, VTSS_MIIM_CONTROLLER_1,  1 },
    {  2, VTSS_MIIM_CONTROLLER_1,  2 },
    {  3, VTSS_MIIM_CONTROLLER_1,  3 },
    {  4, VTSS_MIIM_CONTROLLER_1,  4 },
    {  5, VTSS_MIIM_CONTROLLER_1,  5 },
    {  6, VTSS_MIIM_CONTROLLER_1,  6 },
    {  7, VTSS_MIIM_CONTROLLER_1,  7 },
    {  8, VTSS_MIIM_CONTROLLER_0,  0 },
    {  9, VTSS_MIIM_CONTROLLER_0,  1 },
    { 10, VTSS_MIIM_CONTROLLER_0,  2 },
    { 11, VTSS_MIIM_CONTROLLER_0,  3 },
    { 12, VTSS_MIIM_CONTROLLER_0,  4 },
    { 13, VTSS_MIIM_CONTROLLER_0,  5 },
    { 14, VTSS_MIIM_CONTROLLER_0,  6 },
    { 15, VTSS_MIIM_CONTROLLER_0,  7 },
    { 16, VTSS_MIIM_CONTROLLER_1, 16 },
    { 17, VTSS_MIIM_CONTROLLER_1, 17 },
    { 18, VTSS_MIIM_CONTROLLER_1, 18 },
    { 19, VTSS_MIIM_CONTROLLER_1, 19 },
    { 20, VTSS_MIIM_CONTROLLER_1, 20 },
    { 21, VTSS_MIIM_CONTROLLER_1, 21 },
    { 22, VTSS_MIIM_CONTROLLER_1, 22 },
    { 23, VTSS_MIIM_CONTROLLER_1, 23 }
#endif /* BOARD_SPARX_G24_EVAL */
#if defined(BOARD_ESTAX_34_REF)
    {  0, VTSS_MIIM_CONTROLLER_0,  0 },
    {  1, VTSS_MIIM_CONTROLLER_0,  1 },
    {  2, VTSS_MIIM_CONTROLLER_0,  2 },
    {  3, VTSS_MIIM_CONTROLLER_0,  3 },
    {  4, VTSS_MIIM_CONTROLLER_0,  4 },
    {  5, VTSS_MIIM_CONTROLLER_0,  5 },
    {  6, VTSS_MIIM_CONTROLLER_0,  6 },
    {  7, VTSS_MIIM_CONTROLLER_0,  7 },
    {  8, VTSS_MIIM_CONTROLLER_1,  8 },
    {  9, VTSS_MIIM_CONTROLLER_1,  9 },
    { 10, VTSS_MIIM_CONTROLLER_1, 10 },
    { 11, VTSS_MIIM_CONTROLLER_1, 11 },
    { 12, VTSS_MIIM_CONTROLLER_1, 12 },
    { 13, VTSS_MIIM_CONTROLLER_1, 13 },
    { 14, VTSS_MIIM_CONTROLLER_1, 14 },
    { 15, VTSS_MIIM_CONTROLLER_1, 15 },
    { 16, VTSS_MIIM_CONTROLLER_1, 16 },
    { 17, VTSS_MIIM_CONTROLLER_1, 17 },
    { 18, VTSS_MIIM_CONTROLLER_1, 18 },
    { 19, VTSS_MIIM_CONTROLLER_1, 19 },
    { 20, VTSS_MIIM_CONTROLLER_1, 20 },
    { 21, VTSS_MIIM_CONTROLLER_1, 21 },
    { 22, VTSS_MIIM_CONTROLLER_1, 22 },
    { 23, VTSS_MIIM_CONTROLLER_1, 23 },
    { 24, VTSS_MIIM_CONTROLLER_NONE, -1 },
    { 26, VTSS_MIIM_CONTROLLER_NONE, -1 }
#endif /* BOARD_ESTAX_34_REF */
#if defined(BOARD_GROCX_EVAL)
    {  5, VTSS_MIIM_CONTROLLER_1, 2 },    /* 5: (R)GMII */
    {  6, VTSS_MIIM_CONTROLLER_1, 3 },    /* 6: RGMII */
    {  0, VTSS_MIIM_CONTROLLER_0, 0 },    /* 0: Internal PHY */
    {  1, VTSS_MIIM_CONTROLLER_0, 1 },    /* 1: Internal PHY */
    {  2, VTSS_MIIM_CONTROLLER_0, 2 },    /* 2: Internal PHY */
    {  3, VTSS_MIIM_CONTROLLER_0, 3 },    /* 3: Internal PHY */
    {  4, VTSS_MIIM_CONTROLLER_NONE, -1 } /* 4: Internal GMII */
#endif /* BOARD_GROCX_EVAL */
#if defined(BOARD_GROCX_REF)
    {  5, VTSS_MIIM_CONTROLLER_1, 0 },     /* 5: (R)GMII (WAN) */
    {  0, VTSS_MIIM_CONTROLLER_0, 0 },     /* 0: Internal PHY */
    {  1, VTSS_MIIM_CONTROLLER_0, 1 },     /* 1: Internal PHY */
    {  2, VTSS_MIIM_CONTROLLER_0, 2 },     /* 2: Internal PHY */
    {  3, VTSS_MIIM_CONTROLLER_0, 3 },     /* 3: Internal PHY */
#if (VTSS_PORTS == 7)
    {  6, VTSS_MIIM_CONTROLLER_NONE, -1 }, /* 6: Internal GMII or external RGMII (Wi) */
#endif /* VTSS_PORTS == 7 */
    {  4, VTSS_MIIM_CONTROLLER_NONE, -1 }, /* 4: Internal GMII */
#endif /* BOARD_GROCX_REF */
};

/* Release PHYs from reset */
static void board_phy_reset(void) 
{
#if defined(BOARD_ESTAX_34_REF)
    /* Release PHYs from reset (Switch GPIO9) */
    vtss_gpio_direction_set(9, 1);
    vtss_gpio_output_write(9, 0);
    vtss_gpio_output_write(9, 1);
    VTSS_MSLEEP(500);
#endif /* BOARD_ESTAX_34_REF */
}

#if VTSS_OPT_SPROUT
/* Get Board MAC address */
static void board_mac_get(uchar *mac)
{
#if defined(BOARD_ESTAX_34_REF) && defined(VTSS_OPSYS_LINUX)
    char *p;
    int  i, addr[6];
    if((p = getenv("MAC"))) {
        if(sscanf(p, "%2x:%2x:%2x:%2x:%2x:%2x",
                  &addr[0], &addr[1], &addr[2], &addr[3], &addr[4], &addr[5]) == 6) {
            for (i = 0; i < 6; i++)
                mac[i] = addr[i];
            return;
        }
        printf("Invalid MAC: %s!\n", p);
    } 
#endif
#if defined(BOARD_ESTAX_34_REF) && defined(VTSS_OPSYS_ECOS)
    char *p, *conf = (void *)0x80FC0000;
    int  i, addr[6];

    for (i = 0; i < 256; i++) {
        p = conf + i;
        if (strncmp("MAC=", p, 4) == 0 &&
            sscanf(p + 4, "%2x:%2x:%2x:%2x:%2x:%2x",
                   &addr[0], &addr[1], &addr[2], &addr[3], &addr[4], &addr[5]) == 6) {
            for (i = 0; i < 6; i++)
                mac[i] = addr[i];
            return;
        } 
    }
#endif /* BOARD_ESTAX_34_REF */

    /* Default address */
    mac[0] = 0x00;
    mac[1] = 0x01;
    mac[2] = 0xC1;
    mac[3] = 0x00;
    mac[4] = 0x00;
    mac[5] = 0x00;
}
#endif /* VTSS_OPT_SPROUT */

#if VTSS_OPT_ROUTER
/* Determine if port is first router port */
static BOOL board_router_port_0(vtss_port_no_t port_no)
{
#if defined(SPARX_G5)
    return (board_port_map[port_no].chip_port == 6);
#endif /* SPARX_G5 */
#if defined(G_ROCX)
    return (board_port_map[port_no].chip_port == 4);
#endif /* G_ROCX */
} 

/* Determine if port is second router port */
static BOOL board_router_port_1(vtss_port_no_t port_no)
{
#if defined(SPARX_G5)
    return 0;
#endif /* SPARX_G5 */
#if defined(G_ROCX)
#if VTSS_OPT_ROUTER_WLAN_RGMII
    return 0;
#endif /* VTSS_OPT_ROUTER_WLAN_RGMII */
    return (board_port_map[port_no].chip_port == 6 && 
            board_port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE);
#endif /* G_ROCX */
} 

/* Determine if port is router port */
static BOOL board_router_port(vtss_port_no_t port_no)
{
    return (board_router_port_0(port_no) || board_router_port_1(port_no));
}
#endif /* VTSS_OPT_ROUTER */

#if VTSS_OPT_ROUTER_PORT_WAN
/* Setup router VLANs */
static void board_router_vlan_setup(void)
{
    vtss_port_no_t        port_no;
    BOOL                  member[VTSS_PORT_ARRAY_SIZE];
    vtss_vlan_port_mode_t mode;
    uint                  count = 0;

    /* Count number of router ports */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        if (board_router_port(port_no))
            count++;
    
    /* Setup VLAN port mode */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        mode.aware = ((count == 1 && board_router_port(port_no)) ||
                      (count == 2 && VTSS_OPT_ROUTER_PORT_WAN2 && 
                       board_router_port_1(port_no)));
        mode.pvid = (port_no == VTSS_OPT_ROUTER_PORT_WAN || board_router_port_1(port_no) ? 
                     VTSS_ROUTER_VLAN_WAN : 
                     (port_no == VTSS_OPT_ROUTER_PORT_WAN2 ? VTSS_ROUTER_VLAN_WAN2 : 
                      VTSS_ROUTER_VLAN_LAN));
        mode.untagged_vid = (mode.aware ? VTSS_VID_NULL : VTSS_VID_ALL);
        mode.frame_type = VTSS_VLAN_FRAME_ALL;
        mode.ingress_filter = 0;
        vtss_vlan_port_mode_set(port_no, &mode);
        member[port_no] = (mode.pvid == VTSS_ROUTER_VLAN_LAN);
    }
    
    /* Setup LAN VLAN members */
    vtss_vlan_port_members_set(VTSS_ROUTER_VLAN_LAN, member);
    
    /* Setup WAN VLAN members */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        member[port_no] = (port_no == VTSS_OPT_ROUTER_PORT_WAN || 
                           (count == 1 && board_router_port_0(port_no)) ||
                           (count == 2 && board_router_port_1(port_no)));
    vtss_vlan_port_members_set(VTSS_ROUTER_VLAN_WAN, member);
    
#if VTSS_OPT_ROUTER_PORT_WAN2
    /* Setup WAN2 VLAN members */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        member[port_no] = (port_no == VTSS_OPT_ROUTER_PORT_WAN2 || 
                           (count == 1 && board_router_port_0(port_no)) ||
                           (count == 2 && board_router_port_1(port_no)));
    vtss_vlan_port_members_set(VTSS_ROUTER_VLAN_WAN2, member);
#endif /* VTSS_OPT_ROUTER_PORT_WAN2 */
}
#endif /* VTSS_OPT_ROUTER_PORT_WAN */

static BOOL board_port_vaui(vtss_port_no_t port_no)
{
#if defined(VTSS_FEATURE_VAUI)
    return (port_no > 24 ? 1 : 0);
#else
    return 0;
#endif /* VTSS_FEATURE_VAUI */
}

/* Determine port MAC interface */
static vtss_port_interface_t board_port_mac_interface(vtss_port_no_t port_no)
{
    int                   chip_port;
    vtss_port_interface_t if_type;

    chip_port = board_port_map[port_no].chip_port;
    
    /* Determine interface type */
#if defined(VTSS_FEATURE_VAUI)
    if_type = (board_port_vaui(port_no) ? VTSS_PORT_INTERFACE_VAUI : 
               VTSS_PORT_INTERFACE_SGMII);
#endif /* VTSS_FEATURE_VAUI */

#if defined(VTSS_ARCH_SPARX_G24)
    if_type = (chip_port < 8 || chip_port > 15 ? VTSS_PORT_INTERFACE_SGMII : 
               VTSS_PORT_INTERFACE_INTERNAL);
#endif /* SPARX_G24 */

#if defined(SPARX_G8)
    if_type = VTSS_PORT_INTERFACE_INTERNAL;
#endif /* SPARX_G8 */

#if defined(SPARX_G5)
    if_type = (chip_port < 6 ? VTSS_PORT_INTERFACE_INTERNAL : 
               VTSS_OPT_ROUTER_PORT_CPU_IF ? VTSS_PORT_INTERFACE_GMII :
               VTSS_PORT_INTERFACE_RGMII);
#endif /* SPARX_G5 */

#if defined(G_ROCX)
    if_type = VTSS_PORT_INTERFACE_INTERNAL;
    if (chip_port == 5)
        if_type = (VTSS_OPT_ROUTER_PORT_5_IF ? VTSS_PORT_INTERFACE_GMII : 
                   VTSS_PORT_INTERFACE_RGMII);
    if (chip_port == 6 && !board_router_port_1(port_no))
        if_type = VTSS_PORT_INTERFACE_RGMII;
#endif /* G_ROCX */

    return if_type;
}

static void board_port_led_init(void)
{
#if defined(BOARD_GROCX_REF) /* LED init for GROCX_REF Board */
    vtss_led_port_t led_port; 
    vtss_led_mode_t led_mode[3];

    led_mode[0] = VTSS_LED_MODE_OFF;
    led_mode[1] = VTSS_LED_MODE_OFF;
    led_mode[2] = VTSS_LED_MODE_OFF;
    /* set the first four ports to "off" mode */
    for (led_port = 0; led_port <= 3; led_port++) {
        vtss_serial_led_set(led_port, &led_mode[0]);
    }    

    led_mode[0] = VTSS_LED_MODE_DISABLED;
    led_mode[1] = VTSS_LED_MODE_DISABLED;
    led_mode[2] = VTSS_LED_MODE_DISABLED;
    /* set the rest ports to "disable" mode */
    for (led_port = 4; led_port <= 15; led_port++) {
        vtss_serial_led_set(led_port, &led_mode[0]);
    }
    
    /* use enhanced led mode for VSC8601 */
    vtss_phy_write(1, 31, 0x1);
    vtss_phy_write(1, 17, 0x10);
    vtss_phy_write(1, 16, 0x61a);
    vtss_phy_write(1, 17, 0x14d6);
    vtss_phy_write(1, 31, 0x0);
#endif /* BOARD_GROCX_REF */
}

static void board_port_led_update(vtss_port_no_t port_no, vtss_port_status_t *port_status, BOOL act_update)
{   
#if defined(BOARD_GROCX_REF)
    static BOOL             is_init = 0;
    static vtss_counter_t   port_counter[4];
    static BOOL             act_status[4] = {0,0,0,0};
    static vtss_mtimer_t           act_timer;

    /* BOARD_GROCX_REF LED hardware spec(configuration B).
       
       Logical port number       LED port number
       =======================================
       P5/P4/P3/P2 ACT ---> LED0/1/2/3.0
       P5/P4/P3/P2 10/100 mode --> LED0/1/2/3.1
       P5/P4/P3/P2 GIGA mode --> LED0/1/2/3.2 
       
     */   
    vtss_port_no_t     port_maps[8] = {0xff,0xff,3,2,1,0,0xff,0xff}; /* Logic port map to LED port(Config B) */
    vtss_led_port_t    led_port; 
    vtss_led_mode_t    led_mode[3];
    vtss_poag_counters_t    counters;
    vtss_counter_t          current_counter;
    BOOL                    is_act = 0;
    
     if (is_init == 0) {
        memset(port_counter, 0, sizeof(port_counter));
        is_init = 1;
    }
    
    /* Check Active LED timer */
    if (VTSS_MTIMER_TIMEOUT(&act_timer)) {
        memset(act_status, 0, sizeof(act_status));
        VTSS_MTIMER_START(&act_timer, 200); /* 200ms */
    }
       
    led_port = port_maps[port_no];
    if (led_port == 0xff) {
        return;
    }
    
    if (act_status[led_port] == 1 && act_update == 1) {
        return; /* Don't change LED status too fast */
    } else if (act_update == 1) {
        vtss_poag_counters_get(port_no, &counters);
        current_counter  = (counters.if_group.ifInOctets + counters.if_group.ifOutOctets);
        if (current_counter != port_counter[port_no-2]) {
            is_act = 1;
            act_status[led_port] = 1;
            port_counter[port_no-2] = current_counter;
        }            
    }
        
    if (port_status->link) {
        /* Link up */
        if (!is_act) {
            led_mode[0] = VTSS_LED_MODE_OFF;
        } else {
            led_mode[0] = VTSS_LED_MODE_5;   
        }    
        if (port_status->speed == VTSS_SPEED_1G)
        {   /* Giga mode*/
            led_mode[1] = VTSS_LED_MODE_OFF;
            led_mode[2] = VTSS_LED_MODE_ON;
        } else {
            /* 10/100 mode */
            led_mode[1] = VTSS_LED_MODE_ON;
            led_mode[2] = VTSS_LED_MODE_OFF;
        }
        vtss_serial_led_set(led_port, &led_mode[0]);
    }            
    else {
        /* Link down */
        led_mode[0] = VTSS_LED_MODE_OFF;
        led_mode[1] = VTSS_LED_MODE_OFF;
        led_mode[2] = VTSS_LED_MODE_OFF;
        vtss_serial_led_set(led_port, &led_mode[0]);
    }             
#endif
} 

#define MAC_AGE_TIME_DEFAULT 300 /* 300 seconds MAC age timer by default */
/* ================================================================= *
 *  SPROUT functions
 * ================================================================= */

#if VTSS_OPT_SPROUT
static BOOL mac_age_fast;

static vtss_rc sprout_log_msg(char *msg)
{
    VTSS_D((msg));
    return VTSS_OK;
}

static ulong sprout_secs_since_boot(void)
{
    return time(NULL);
}

static vtss_rc tx_vstax2_pkt(
    vtss_port_no_t         port_no,
    vtss_vstax_tx_header_t *vstax2_hdr_p,
    uchar                  *pkt_p,
    uint                   len)
{
    return vtss_tx_vstax_frame(port_no, vstax2_hdr_p, pkt_p, len);
}

static vtss_rc sprout_state_change(uchar mask)
{
    VTSS_D(("mask: 0x%02x", mask));

    if (mask & VTSS_SPROUT_STATE_CHANGE_MASK_TTL) {
        mac_age_fast = 1;
    }
    return VTSS_OK;
}

static vtss_rc sprout_cfg_save(vtss_sprout_cfg_save_t *cfg) 
{
    return VTSS_OK;
} 

static void sprout_init(void)
{
    vtss_sprout_init_t         sprout_init;
    vtss_sprout_switch_init_t  sprout_switch_init;
    
    /* Sproutlogy module initialization */
    sprout_init.callback.log_msg         = sprout_log_msg;
    sprout_init.callback.state_change    = sprout_state_change;
    sprout_init.callback.cfg_save        = sprout_cfg_save;
    sprout_init.callback.tx_vstax2_pkt   = tx_vstax2_pkt;
    sprout_init.callback.secs_since_boot = sprout_secs_since_boot;
    vtss_sprout_init(&sprout_init);

    /* Sproutlogy module switch setup, MAC address read from configuration */
    memset(&sprout_switch_init, 0, sizeof(sprout_switch_init));
    board_mac_get(sprout_switch_init.switch_addr.addr);
    sprout_switch_init.cpu_qu = VTSS_CPU_RX_QUEUE_START;
    sprout_switch_init.mst_capable   = 0;
    sprout_switch_init.chip.uid_pref = 0; /* No preference */
    sprout_switch_init.chip.stack_port[0].port_no = STACK_PORT_A;
    sprout_switch_init.chip.stack_port[1].port_no = STACK_PORT_B;
    vtss_sprout_switch_init(&sprout_switch_init);

    vtss_sprout_stack_port_adm_state_set(STACK_PORT_A, 1);
    vtss_sprout_stack_port_adm_state_set(STACK_PORT_B, 1);
    
    mac_age_fast = 0;
}
#endif /* VTSS_OPT_SPROUT */

#if VTSS_OPT_MSG_RELAY
static void msg_relay_init(void)
{
    vtss_msg_relay_init_t msg_relay_init;
    
    // Tell message module on which ports to expect to receive and
    // transmit message protocol frames, i.e. the stack ports.
    memset(&msg_relay_init, 0, sizeof(msg_relay_init));
    msg_relay_init.stack_port_a = STACK_PORT_A;
    msg_relay_init.stack_port_b = STACK_PORT_B;
    msg_relay_init.cpu_qu       = VTSS_CPU_RX_QUEUE_START;

    vtss_msg_relay_init(&msg_relay_init);
}
#endif /* VTSS_OPT_MSG_RELAY */

/* ================================================================= *
 *  Main functions
 * ================================================================= */

/* Setup port based on configuration and auto negotiation result */
static void port_setup(vtss_port_no_t port_no, BOOL conf)
{
    vtss_appl_port_status_t *ps;
    vtss_appl_port_conf_t   *pc;
    vtss_port_setup_t       setup;
    vtss_phy_setup_t        phy;
    
    pc = &port_conf[port_no];
    memset(&setup, 0, sizeof(setup));
    setup.interface_mode.interface_type = board_port_mac_interface(port_no);
    setup.powerdown = (pc->enable ? 0 : 1);
    setup.flowcontrol.smac.addr[5] = port_no;
    setup.maxframelength = pc->max_length;
    setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
    setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
    setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
#if defined(VTSS_FEATURE_SGMII)
    setup.sgmii_dc_coupled = 0;
#endif /* VTSS_FEATURE_SGMII */
    
    if (conf) {
        /* Configure port */
        if (board_port_map[port_no].miim_controller != VTSS_MIIM_CONTROLLER_NONE) {
            /* Setup PHY */
            phy.mode = (pc->enable ? 
                        (pc->autoneg || pc->speed == VTSS_SPEED_1G ? 
                         VTSS_PHY_MODE_ANEG : VTSS_PHY_MODE_FORCED) : 
                        VTSS_PHY_MODE_POWER_DOWN);
            phy.aneg.speed_10m_hdx = 1;
            phy.aneg.speed_10m_fdx = 1;
            phy.aneg.speed_100m_hdx = 1;
            phy.aneg.speed_100m_fdx = 1;
            phy.aneg.speed_1g_fdx = 1;
            phy.aneg.symmetric_pause = pc->flow_control;
            phy.aneg.asymmetric_pause = pc->flow_control;
            phy.forced.speed = pc->speed;
            phy.forced.fdx = pc->fdx;
            vtss_phy_setup(port_no, &phy);
        }
        /* Use configured values */
        setup.interface_mode.speed = pc->speed;
        setup.fdx = pc->fdx;
        setup.flowcontrol.obey = pc->flow_control;
        setup.flowcontrol.generate = pc->flow_control;
    } else {
        /* Setup port based on auto negotiation status */
        ps = &port_status[port_no];
        setup.interface_mode.speed = ps->speed;
        setup.fdx = ps->fdx;
        setup.flowcontrol.obey = ps->aneg.obey_pause;
        setup.flowcontrol.generate = ps->aneg.generate_pause;
    }
    vtss_port_setup(port_no, &setup);
}

/* Rx frames to CPU */
static void cpu_frame_rx(void) 
{
    vtss_system_frame_header_t header;
    uchar                      frame[VTSS_MAXFRAMELENGTH_STANDARD];
    vtss_cpu_rx_queue_t        queue_no;
    ushort                     etype;
    ulong                      data;

    for (queue_no=VTSS_CPU_RX_QUEUE_START; queue_no<VTSS_CPU_RX_QUEUE_END; queue_no++) {
        /* Check if frame is ready in Rx queue */
        if (vtss_cpu_rx_frameready(queue_no) <= 0)
            continue;
    
        /* Get frame */
        if (vtss_cpu_rx_frame(queue_no, &header, frame, 
                              VTSS_MAXFRAMELENGTH_STANDARD) != VTSS_OK)
            continue;
        
        VTSS_D(("received frame on port_no: %d, queue_no: %d, length: %d",
                header.source_port_no, queue_no, header.length));

        /* Process frame */
        {
            int  i;
            char buf[100], *p;

            for (i = 0, p = &buf[0]; i < header.length; i++) {
                if ((i % 16) == 0) {
                    p = &buf[0];
                    p += sprintf(p, "%04x: ", i);
                }
                p += sprintf(p,"%02x%c", frame[i], ((i+9)%16)==0 ? '-' : ' ');
                if (((i+1) % 16) == 0 || (i+1) == header.length) {
                    VTSS_D(("%s", buf));
                }
            }
        }
        etype = ((frame[12]<<8) | (frame[13]<<0));
        data  = ((frame[14]<<24) | (frame[15]<<16) | (frame[16]<<8) | (frame[17]<<0));
#if VTSS_OPT_MLD
        /* MLD frame handling */
        if (vtss_mldsnooping_frame_is_mld(&header, frame) == VTSS_OK ) {
            vtss_mldsnooping_frame(&header, frame);
            continue;
        }
#endif /* VTSS_OPT_MLD */
#if VTSS_OPT_SPROUT
        if (etype == 0x8880 && data == 0x00020001) {
            vtss_sprout_rx_pkt(header.source_port_no, frame, header.length);
        }
#endif /* VTSS_OPT_SPROUT */
#if  VTSS_OPT_MSG_RELAY
       if (etype == 0x8880 && data == 0x00020002) {
            vtss_msg_relay_rx_pkt(header.source_port_no, frame, header.length);
       }
#endif /* VTSS_OPT_MSG_RELAY */
    }
}

int main(void)
{
    vtss_state_t            *api_state;
    vtss_init_setup_t       init_setup;
    vtss_port_no_t          port_no;
    vtss_phy_reset_setup_t  phy_reset;
    vtss_mtimer_t           mac_timer;
    BOOL                    mac_timer_started, link_old, port_poll[VTSS_PORT_ARRAY_SIZE];
#if VTSS_OPT_MLD
    vtss_mtimer_t           mld_timer;
#endif /* VTSS_OPT_MLD */
#if VTSS_OPT_SPROUT
    vtss_mtimer_t           sprout_timer;
#endif /* VTSS_OPT_SPROUT */
    vtss_port_status_t      status;
    vtss_appl_port_status_t *ps;
    vtss_appl_port_conf_t   *pc;
    
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    VTSS_TRACE_REG_INIT(&trace_reg, trace_grps, TRACE_GRP_CNT);
    VTSS_TRACE_REGISTER(&trace_reg);
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#if defined(VTSS_OPT_RAPI) && VTSS_OPT_RAPI
    if (vtss_rapi_init()) {
        VTSS_E(("Socket interface initialization failed"));
        exit(-1);
    }
#endif /* VTSS_OPT_RAPI */

    /* Allocate API state memory */
    if ((api_state = malloc(sizeof(vtss_state_t)))==NULL ||
        (api_state->al = malloc(vtss_sizeof_al()))==NULL) {
        VTSS_E(("malloc api_state failed"));
        return 0;
    }

    /* Allocate PHY API state memory */
    if ((api_state->phy = malloc(sizeof(vtss_phy_state_t)))==NULL ||
        (((vtss_phy_state_t*)(api_state->phy))->al = 
         malloc(vtss_phy_sizeof_al(VTSS_PORTS)))==NULL) {
        VTSS_E(("malloc phy_api_state failed"));
        return 0;
    }
    
    /* Setup API state */
    vtss_select_chip(api_state);

    /* Initialize CPU interface */
    board_cpu_if_init(&api_state->io);

    /* Initialize switch chip */
    init_setup.reset_chip = 1;
    init_setup.use_cpu_si = 0;
#if defined(VTSS_FEATURE_PI_WIDTH)
    init_setup.pi_width = VTSS_PI_WIDTH_16;
#endif /* VTSS_FEATURE_PI_WIDTH */
#if defined(VTSS_FEATURE_PI_TIMING_CS)
    init_setup.pi_cs_wait_ns = 0;
#endif /* VTSS_FEATURE_PI_TIMING_CS */
#if defined(VTSS_FEATURE_PI_SLOWMODE)
    init_setup.pi_use_extended_buscycle = 0;
#endif /* VTSS_FEATURE_PI_SLOWMODE */
#if defined(VTSS_OPT_USE_CPU_SI)
    init_setup.use_cpu_si = 1;
#endif /* VTSS_OPT_USE_CPU_SI */
    vtss_init(&init_setup);
#if VTSS_OPT_ICPU_LOAD
    VTSS_D(("vtss_init done, exiting"));
    return 0;
#endif /* VTSS_OPT_ICPU_LOAD */
    
    /* Setup port map for board */
    vtss_port_map_set(board_port_map);
    
#if VTSS_OPT_ROUTER_PORT_WAN
    /* Setup router VLANs */
    board_router_vlan_setup();
#endif /* VTSS_OPT_ROUTER_PORT_WAN */        

#if VTSS_OPT_MLD
    {
        vtss_mldsnooping_init_setup_t config;
        
        VTSS_D(("Initialize MLD snooping"));
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
            config.router_port[port_no] = board_router_port(port_no);
        config.lan_vid = VTSS_ROUTER_VLAN_LAN;
        vtss_mldsnooping_init(&config);
    }
#endif /* VTSS_OPT_MLD */

#if VTSS_OPT_SPROUT
    sprout_init();
#endif /* VTSS_OPT_SPROUT */

#if VTSS_OPT_MSG_RELAY
    msg_relay_init();
#endif /* VTSS_OPT_MSG_RELAY */

    /* Release PHYs from reset */
    board_phy_reset();

    /* Reset all ports */
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        port_status[port_no].link = 0;

        /* Default port configuration */
        pc = &port_conf[port_no];
        pc->enable = 1;
        pc->autoneg = 0;
        pc->speed = VTSS_SPEED_1G;
        pc->fdx = 1;
        pc->flow_control = 0;
        pc->max_length = VTSS_MAXFRAMELENGTH_STANDARD;
        port_poll[port_no] = 1;
        
        if (board_port_map[port_no].miim_controller == VTSS_MIIM_CONTROLLER_NONE) {
            /* No PHY */
            if (board_port_vaui(port_no)) {
                /* Setup for 5G, full duplex, flow control disabled */
                pc->speed = VTSS_SPEED_5G;
            } else {
                /* Setup for 1G, full duplex, flow control disabled */
                vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
                port_poll[port_no] = 0;
            }
        } else {
            /* Reset PHY */
            pc->autoneg = 1;
            pc->flow_control = 1;
            phy_reset.mac_if = board_port_mac_interface(port_no);
            phy_reset.rgmii.rx_clk_skew_ps = 1800;
            phy_reset.rgmii.tx_clk_skew_ps = 1800;
            phy_reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;
            vtss_phy_reset(port_no, &phy_reset);
        
#if defined(BOARD_ESTAX_34_REF)            
            /* LED control */
            vtss_phy_write(port_no, 29, 0xee64);
        
            /* Make PHY GPIO0 and GPIO1 output for VAUI port LED control */
            vtss_phy_write(port_no, 13 | VTSS_PHY_REG_GPIO, 0xffff);
            vtss_phy_write(port_no, 17 | VTSS_PHY_REG_GPIO, 0x0003);
#endif /* BOARD_ESTAX_34_REF */
        }

#if VTSS_OPT_ROUTER
        if (board_router_port(port_no)) {
            /* Setup for 1G, full duplex, always up */
#if VTSS_OPT_ROUTER_PORT_FLOW_CONTROL
            pc->flow_control = 1;
#endif /* VTSS_OPT_ROUTER_PORT_FLOW_CONTROL */
            vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
            port_poll[port_no] = 0;
#if defined(VTSS_FEATURE_ACL)
            /* Disable ACL on router port */
            vtss_acl_policy_no_set(port_no, VTSS_ACL_POLICY_NO_NONE);
#endif /* VTSS_FEATURE_ACL */
        }
#endif /* VTSS_OPT_ROUTER */
        port_setup(port_no, 1);
    }

#if defined(VTSS_FEATURE_MAC_AGE_AUTO)
    /* Automatic aging used */
    vtss_mac_table_age_time_set(MAC_AGE_TIME_DEFAULT);
    mac_timer_started = 0;
#else
    /* Manual aging used */
    VTSS_MTIMER_START(&mac_timer, 5000);
    mac_timer_started = 1;
#endif /* VTSS_FEATURE_MAC_AGE_AUTO */
#if VTSS_OPT_MLD
    VTSS_MTIMER_START(&mld_timer, VTSS_OPT_MLD_AGE_TIMER);
#endif /* VTSS_OPT_MLD */
#if VTSS_OPT_SPROUT
    VTSS_MTIMER_START(&sprout_timer, 100); /* 100 msec */
#endif /* VTSS_OPT_SPROUT */
#if VTSS_OPT_CLI
    cli_init();
#endif /* VTSS_OPT_CLI */
    /* Initialize Board LED */
    board_port_led_init();

    /* Detect link up/down and do MAC address ageing */
    for (;;) {
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
            /* Receive frame to CPU */
            cpu_frame_rx();
            
            /* Check MAC address age timer */
            if (mac_timer_started && VTSS_MTIMER_TIMEOUT(&mac_timer)) {
#if VTSS_OPT_SPROUT
                mac_timer_started = 0;
                vtss_mac_table_age_time_set(MAC_AGE_TIME_DEFAULT);
#else
                vtss_mac_table_age();
                VTSS_MTIMER_START(&mac_timer, MAC_AGE_TIME_DEFAULT*1000/2);
#endif /* VTSS_OPT_SPROUT */
            }
#if VTSS_OPT_SPROUT
            if (mac_age_fast) {
                if (!mac_timer_started) {
                    mac_timer_started = 1;
                    vtss_mac_table_age_time_set(VTSS_SPROUT_FAST_MAC_AGING_TIMER);
                }
                mac_age_fast = 0;
                VTSS_MTIMER_START(&mac_timer, VTSS_SPROUT_FAST_MAC_AGING_PERIOD*1000);
            }
            
            if (VTSS_MTIMER_TIMEOUT(&sprout_timer)) {
                vtss_sprout_service_100msec();
                VTSS_MTIMER_START(&sprout_timer, 100); /* 100 msec */
            }
#endif /* VTSS_OPT_SPROUT */

#if VTSS_OPT_MLD
            /* Check MLD timer */
            if (VTSS_MTIMER_TIMEOUT(&mld_timer)) {
                vtss_mldsnooping_aging();
                VTSS_MTIMER_START(&mld_timer, VTSS_OPT_MLD_AGE_TIMER);
            }
#endif /* VTSS_OPT_MLD */

            if (!port_poll[port_no])
                continue; /* Skip port status polling */

            /* Get current status */
            vtss_port_status_get(port_no, &status);
            ps = &port_status[port_no];
            link_old = ps->link;
            ps->link = status.link;
            ps->speed = status.speed;
            ps->fdx = status.fdx;
            ps->aneg.obey_pause = status.aneg.obey_pause;
            ps->aneg.generate_pause = status.aneg.generate_pause;
            
            if (board_port_vaui(port_no)) {
                /* VAUI port LED control */
                vtss_phy_write(port_no == 25 ? 9 : 17, 16 | VTSS_PHY_REG_GPIO,
                               (1<<1) | ((status.link ? 0 : 1)<<0));
            }
                
            /* Detect link down and disable port */
            if ((!status.link || status.link_down) && link_old) {
                VTSS_D(("link down event on port_no: %d", port_no));
                vtss_port_stp_state_set(port_no, VTSS_STP_STATE_DISABLED);
                vtss_mac_table_forget_port(port_no);
#if VTSS_OPT_SPROUT
                if (board_port_vaui(port_no))
                    vtss_sprout_stack_port_link_state_set(port_no, 0);
#endif /* VTSS_OPT_SPROUT */  
                board_port_led_update(port_no, &status, 0);
            }
            
            /* Detect link up and setup port */
            if (status.link && !link_old) { 
                VTSS_D(("link up event on port_no: %d", port_no));
                vtss_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);
#if VTSS_OPT_SPROUT
                if (board_port_vaui(port_no))
                    vtss_sprout_stack_port_link_state_set(port_no, 1);
#endif /* VTSS_OPT_SPROUT */  
                if (port_conf[port_no].autoneg)
                    port_setup(port_no, 0);
                board_port_led_update(port_no, &status, 0);
            }
            
            /* Detect traffic when link is up */
            if (status.link) {    
                board_port_led_update(port_no, &status, 1);
            }
        } /* Port loop */
#if VTSS_OPT_CLI
        cli_tsk();
#endif /* VTSS_OPT_SPROUT */
#if defined(VTSS_OPT_RAPI) && VTSS_OPT_RAPI
        /* Poll RAPI */
        vtss_rapi_poll();
#endif /* VTSS_OPT_RAPI */
    } /* Forever loop */
    
    return 0;
}

/* ================================================================= *
 *  API functions
 * ================================================================= */

vtss_rc vtss_appl_port_status_get(const vtss_port_no_t            port_no,
                                  vtss_appl_port_status_t * const status)
{
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    
    *status = port_status[port_no];
    return VTSS_OK;
}

/* Get port configuration */
vtss_rc vtss_appl_port_conf_get(const vtss_port_no_t          port_no,
                                vtss_appl_port_conf_t * const conf)
{
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    *conf = port_conf[port_no];
    return VTSS_OK;
}

/* Set port configuration */
vtss_rc vtss_appl_port_conf_set(const vtss_port_no_t                port_no,
                                const vtss_appl_port_conf_t * const conf)
{
    if (!VTSS_PORT_IS_PORT(port_no)) {
        VTSS_E(("illegal port_no: %d",port_no));
        return VTSS_INVALID_PARAMETER;
    }
    port_conf[port_no] = *conf;
    port_setup(port_no, 1);
    return VTSS_OK;
}

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
