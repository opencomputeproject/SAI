/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_cli.c,v 1.13 2007/09/28 08:23:48 cpj Exp $
s $Revision: 1.13 $

*/


# /* Standard Headers */
#include <ctype.h>
#include <stdlib.h>

#if !defined(VTSS_OPSYS_ECOS)
#include <stdio.h>
#include <termios.h>
#include <string.h>
#endif /* VTSS_OPSYS_ECOS */

#if defined(VTSS_OPSYS_ECOS)
#include <cyg/hal/luton28.h>
#include <cyg/io/io.h>
#include <cyg/io/serialio.h>
#include <cyg/io/config_keys.h>
#include <cyg/io/flash.h>
#include <cyg/crc/crc.h>
#endif /* VTSS_OPSYS_ECOS */

#if defined(VTSS_TRACE)
/* Advanced trace system used */
#include <vtss_trace_lvl_api.h>
#include <vtss_trace_api.h>

#define VTSS_TRACE_MODULE_ID   VTSS_MODULE_ID_CLI
#define VTSS_TRACE_GRP_DEFAULT 0
#define TRACE_GRP_CNT          1
#define VTSS_TRACE_LAYER       4
#else
#define VTSS_TRACE_FILE        "cli"
#define VTSS_TRACE_LAYER       3
#endif /* VTSS_TRACE */

# /* API public headers */
#include "vtss_switch_api.h"
#include "vtss_appl_api.h"
#include "vtss_cli.h"

#if VTSS_OPT_CLI

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static vtss_trace_reg_t trace_reg =
{ 
    .module_id = VTSS_TRACE_MODULE_ID,
    .name      = "cli",
    .descr     = "Mini CLI"
};

static vtss_trace_grp_t trace_grps[TRACE_GRP_CNT] =
{
    [VTSS_TRACE_GRP_DEFAULT] = { 
        .name      = "default",
        .descr     = "Default",
        .lvl       = VTSS_TRACE_LVL_ERROR,
        .timestamp = 0,
    },
};
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

#define MAX_CMD_LEN      (80 + 1)
#define MAX_CMD_HISTORY_LEN 20

#define MAX_PARM_COUNT 15

#define CURSOR_UP    0X41
#define CURSOR_DOWN  0X42
#define CURSOR_RIGHT 0x43
#define CURSOR_LEFT  0x44

#define CURSOR_HOME  0x48
#define CURSOR_END   0x4B

#if defined(VTSS_OPSYS_ECOS)
#define BS  0x08
#else
#define BS 0x7f
#endif
#define BEL 0x07
#define LF  0x0a
#define CR  0x0d
#define ESC 0x1b

#define SKIP_SPACES(p) while(*curp && *curp==' ') {curp++;}
#define IS_HEX(p) (*curp=='0' && toupper(*(curp+1)) == 'X')

static void append_line (void);
static BOOL cli_char_available(unsigned char *c);
static char *cmd_get (void);
static void cmd_history_get (void);
static void cmd_history_put (void);
static BOOL cmd_ready (void);
static void cursor_home (void);
static void cursor_left (void);
static void cursor_right (void);
static void delete_char (void);
static void delete_to_eol (void);
static BOOL empty_cmd_line (void);
static void get_old_cmd (void);
static void handle_command(void);
static void insert_char (char ch);
static void process_escape_seq (char ch_1, char ch_2);
static void prompt(void);
static void retreive_params(BOOL);
static void rewrite_to_eol (void);
static void port_counters_show(vtss_port_no_t port_no);
static void port_conf_show(vtss_port_no_t port_no);
const char *port_mgmt_mode_txt(vtss_speed_t speed, BOOL fdx);
static void port_counters_clear(vtss_port_no_t port);
const char *cli_bool_txt(BOOL enabled);

static ulong parms[10];
static uint  parms_count;
static char  cmd;
static char cmd_buf [MAX_CMD_LEN];
static uint cmd_len = 0;
static uint cmd_cursor = 0;

static BOOL switchapp_suspendended = FALSE;

#if !defined(VTSS_OPSYS_ECOS)
static struct termios stored_settings;
static fd_set fdset;
static struct timeval tv;

void restore_keypress(void);
void restore_keypress(void)
{
    tcsetattr(0,TCSANOW,&stored_settings);
}

static void set_keypress(void);
static void set_keypress(void)
{
    struct termios new_settings;

    tcgetattr(0,&stored_settings);

    new_settings = stored_settings;

    /* Disable canonical mode, and set buffer size to 1 byte */
    new_settings.c_lflag &= (~ICANON);
    new_settings.c_lflag &= (~ECHO);
    new_settings.c_cc[VTIME] = 0;
    new_settings.c_cc[VMIN] = 1;

    tcsetattr(0,TCSANOW,&new_settings);
    
    atexit(restore_keypress);
    
    return;
}
#endif /* VTSS_OPSYS_ECOS */

#if defined(VTSS_OPSYS_ECOS)
static cyg_io_handle_t ser_handle;
#endif  /* VTSS_OPSYS_ECOS */

struct {
    uint idx;
    uint len;
    uint scroll;
    struct {
        uint  cmd_len;
        char cmd [MAX_CMD_LEN];
    } buf [MAX_CMD_HISTORY_LEN];

} cmd_history;

static BOOL cli_char_available(unsigned char *c)
{
#if defined(VTSS_OPSYS_ECOS)
    Cyg_ErrNo err;    
    cyg_uint32 len = 1;
    err = cyg_io_read(ser_handle, c, &len);
    if((ENOERR == err) && (len > 0)) {
        return TRUE;
    }
    return FALSE;
#else
    FD_ZERO(&fdset);
    FD_SET(0, &fdset);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    if(select(1, &fdset, NULL, NULL, &tv) > 0) {
        *c = getchar();        
        return TRUE;
    }
    return FALSE;
#endif
}

static void port_counters_show(vtss_port_no_t port)
{
    vtss_poag_counters_t counters;
    vtss_port_no_t       port_no;
    
    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if ((port != 0 && port != port_no) ||
            vtss_poag_counters_get(port_no, &counters) != VTSS_OK)
            continue;
    
        printf("Port %d Statistics:\n\n",port_no);
        printf("Rx Packets:       %20llu   Tx Packets:       %20llu\n", 
               counters.rmon.rx_etherStatsPkts, 
               counters.rmon.tx_etherStatsPkts);;
#if defined(VTSS_FEATURE_PORT_CNT_PKT_CAST)
        printf("Rx Unicast:       %20llu   Tx Unicast:       %20llu\n",
               counters.if_group.ifInUcastPkts,
               counters.if_group.ifOutUcastPkts);
        printf("Rx Multicast:     %20llu   Tx Multicast:     %20llu\n", 
               counters.rmon.rx_etherStatsMulticastPkts,
               counters.rmon.tx_etherStatsMulticastPkts);
        printf("Rx Broadcast:     %20llu   Tx Broadcast:     %20llu\n", 
               counters.rmon.rx_etherStatsBroadcastPkts,
               counters.rmon.tx_etherStatsBroadcastPkts);
#endif /* VTSS_FEATURE_PORT_CNT_PKT_CAST */
#if defined(VTSS_FEATURE_PORT_CNT_PAUSE)
        printf("Rx Pause:         %20llu   Tx Pause:         %20llu\n", 
               counters.ethernet_like.dot3InPauseFrames,
               counters.ethernet_like.dot3OutPauseFrames);
#endif /* VTSS_FEATURE_PORT_CNT_PAUSE */
        printf("\n");
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        printf("Rx        64 :    %20llu   Tx        64 :    %20llu\n",
               counters.rmon.rx_etherStatsPkts64Octets,
               counters.rmon.tx_etherStatsPkts64Octets);
        printf("Rx   65- 127 :    %20llu   Tx   65- 127 :    %20llu\n",
               counters.rmon.rx_etherStatsPkts65to127Octets,
               counters.rmon.tx_etherStatsPkts65to127Octets);
        printf("Rx  128- 255 :    %20llu   Tx  128- 255 :    %20llu\n",
               counters.rmon.rx_etherStatsPkts128to255Octets,
               counters.rmon.tx_etherStatsPkts128to255Octets);
        printf("Rx  256- 511 :    %20llu   Tx  256- 511 :    %20llu\n",
               counters.rmon.rx_etherStatsPkts256to511Octets,
               counters.rmon.tx_etherStatsPkts256to511Octets);
        printf("Rx  512-1023 :    %20llu   Tx  512-1023 :    %20llu\n",
               counters.rmon.rx_etherStatsPkts512to1023Octets,
               counters.rmon.tx_etherStatsPkts512to1023Octets);
        printf("Rx 1024-1518 :    %20llu   Tx 1024-1518 :    %20llu\n",
               counters.rmon.rx_etherStatsPkts1024to1518Octets,
               counters.rmon.tx_etherStatsPkts1024to1518Octets);
#if defined(VTSS_FEATURE_PORT_CNT_JUMBO)
        printf("Rx 1519-     :    %20llu   Tx 1519-     :    %20llu\n",
               counters.rmon.rx_etherStatsPkts1519toMaxOctets,
               counters.rmon.tx_etherStatsPkts1519toMaxOctets);
#endif /* VTSS_FEATURE_PORT_CNT_JUMBO */
        printf("\n");
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
        
        printf("Rx Drops:         %20llu   Tx Drops:         %20llu\n",
               counters.rmon.rx_etherStatsDropEvents,
               counters.rmon.tx_etherStatsDropEvents);
#if defined(VTSS_FEATURE_PORT_CNT_ETHER_LIKE)
        printf("Rx CRC/Alignment: %20llu   Tx Late Collisions:%19llu\n",
               counters.rmon.rx_etherStatsCRCAlignErrors,
               counters.ethernet_like.dot3StatsLateCollisions);
        printf("Rx Symbol:        %20llu   Tx Excessive Coll.:%19llu\n",
               counters.ethernet_like.dot3StatsSymbolErrors,
               counters.ethernet_like.dot3StatsExcessiveCollisions);
        printf("Rx Undersize:     %20llu   Tx Carrier Sense: %20llu\n",
               counters.rmon.rx_etherStatsUndersizePkts,
               counters.ethernet_like.dot3StatsCarrierSenseErrors);
#else
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        printf("Rx CRC/Alignment: %20llu   Tx Late/Exc. Coll.:%19llu\n",
               counters.rmon.rx_etherStatsCRCAlignErrors,
               counters.if_group.ifOutErrors);
        printf("Rx Undersize:     %20llu\n",
               counters.rmon.rx_etherStatsUndersizePkts);
#else
        printf("Rx Errors:        %20llu   Tx Errors:        %20llu\n",
               counters.if_group.ifInErrors,
               counters.if_group.ifOutErrors);
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
#endif /* VTSS_FEATURE_PORT_CNT_ETHER_LIKE */
#if defined(VTSS_FEATURE_PORT_CNT_RMON_ADV)
        printf("Rx Oversize:      %20llu\n",
               counters.rmon.rx_etherStatsOversizePkts);
        printf("Rx Fragments:     %20llu\n",
               counters.rmon.rx_etherStatsFragments);
        printf("Rx Jabbers:       %20llu\n",
            counters.rmon.rx_etherStatsJabbers); 
#endif /* VTSS_FEATURE_PORT_CNT_RMON_ADV */
        printf("\n");
    }
}


const char *cli_bool_txt(BOOL enabled)
{
    return (enabled ? "Enabled " : "Disabled");
}


const char *port_mgmt_mode_txt(vtss_speed_t speed, BOOL fdx)
{
    switch (speed) {
    case VTSS_SPEED_10M:
        return (fdx ? "10fdx" : "10hdx");
    case VTSS_SPEED_100M:
        return (fdx ? "100fdx" : "100hdx");
    case VTSS_SPEED_1G:
        return (fdx ? "1Gfdx" : "1Ghdx");
    case VTSS_SPEED_2500M:
        return (fdx ? "2.5Gfdx" : "2.5Ghdx");
    case VTSS_SPEED_5G:
        return (fdx ? "5Gfdx" : "5Ghdx");
    case VTSS_SPEED_10G:
        return (fdx ? "10Gfdx" : "10Ghdx");
    default:
        return "?";
    }
}


static void cli_table_header(const char *txt)
{
    int         i, j, len, count = 0;
    BOOL        parm = 0;
    
    len = strlen(txt);
    printf("%s\n", txt);
    for (i = 0; i < len; i++) {
        if (txt[i] == ' ') {
            count++;
        } else {
            for (j = 0; j < count; j++) {
                printf("%c", count > 1 && (parm || j >= (count - 2)) ? ' ' : '-'); 
            }
            printf("-");
            count = 0;
        }
    }
    for (j = 0; j < count; j++) {
        printf("%c", count > 1 && (parm || j >= (count - 2)) ? ' ' : '-'); 
    }
    printf("\n");
}


/* Port configuration */
static void port_conf_show(vtss_port_no_t port)
{
    vtss_appl_port_conf_t   conf;
    vtss_appl_port_status_t status;
    BOOL                    first = 1;
    vtss_port_no_t          port_no;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if ((port != 0 && port != port_no) || 
            vtss_appl_port_conf_get(port_no, &conf) != VTSS_OK ||
            vtss_appl_port_status_get(port_no, &status) != VTSS_OK)
            continue;

        if (first) {
            first = 0;
            cli_table_header("Port  State    Speed   Flow Control  Rx Pause  Tx Pause  Length  Link    ");
        }
        printf("%-2d    %s %-7s %-13s %s  %s  %d    %s\n", 
               port_no,
               cli_bool_txt(conf.enable),
               conf.autoneg ? "Auto" : port_mgmt_mode_txt(conf.speed, conf.fdx),
               cli_bool_txt(conf.flow_control),
               cli_bool_txt(status.link ? status.aneg.obey_pause : 0), 
               cli_bool_txt(status.link ? status.aneg.generate_pause : 0),
               conf.max_length,
               status.link ? port_mgmt_mode_txt(status.speed, status.fdx) : "Down");
    }
}

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
static void cprintf_repeat_char(char c, uint n)
{
    for(;n > 0; n--) {
        printf("%c", c);
    }
} /* cprintf_repeat_char */

static void trace_modules_show(void)
{
    /* No level to be set => Print trace information */
    {
        int mid_start,  mid_stop;
        int gidx_start, gidx_stop;

        int mid=-1, gidx=-1;
        char *module_name;
        char *grp_name;

        int md_value;
        int grp_value;
        
        /* Work-around for problem with printf("%*s", ...) */
        char name_format[10];
        char lvl_format[10];
        sprintf(name_format, "%%-%ds", VTSS_TRACE_MAX_NAME_LEN);
        sprintf(lvl_format, "%%-%ds",  VTSS_TRACE_MAX_LVL_LEN);
        mid_start = -1;
        mid_stop  = -1;
        gidx_start = -1;
        gidx_stop  = -1;

        // Output format:
        //
        // Module      Group  Level  Timestamp  Usec  Description
        // ----------  -----  -----  ---------  ----  -----------
        // mirror                    yes        no    Bla bla bla
        //             g1     error  no         no    adsfasdfasdf
        //             g2     error  no         no    adsfasdfasdf
        /* Header */
        printf(name_format, "Module");
        printf("  ");
        printf(name_format, "Group");
        printf("  ");
        printf(lvl_format, "Level");
        printf("  ");
        printf("Timestamp  ");
        printf("Usec  ");
        printf("Description\n");

        cprintf_repeat_char('-', VTSS_TRACE_MAX_NAME_LEN);
        printf("  ");
        cprintf_repeat_char('-', VTSS_TRACE_MAX_NAME_LEN);
        printf("  ");
        cprintf_repeat_char('-', VTSS_TRACE_MAX_LVL_LEN);
        printf("  ");
        cprintf_repeat_char('-', strlen("Timestamp"));
        printf("  ");
        cprintf_repeat_char('-', strlen("Usec"));
        printf("  ");
        cprintf_repeat_char('-', strlen("Description"));
        printf("\n");

        /* Modules */
        mid = mid_start;
        while ((module_name = vtss_trace_module_name_get_nxt(&mid))) {
            BOOL one_line_format = 0;

            gidx = gidx_start;
            if (strcmp(vtss_trace_grp_name_get_nxt(mid, &gidx), "default") == 0) {
                /* First group to print is named "default" 
                 * => 
                 * print group name on same line as module name and
                 * skip printing group description */
                one_line_format = 1;
            }

            /* Module value added */
            vtss_trace_module_to_val(module_name, &md_value); 
            printf("%d/",md_value);                         

            printf(name_format, module_name);
            if (!one_line_format) {
                printf(name_format, "");
                printf("  ");
                printf(lvl_format,  "");
                printf("  ");
                cprintf_repeat_char(' ', strlen("Timestamp"));
                printf("  ");
                cprintf_repeat_char(' ', strlen("Usec"));
                printf("  ");
                printf("%s\n", vtss_trace_module_get_descr(mid));
            }

            /* Groups */
            gidx = gidx_start;
            while ((grp_name = vtss_trace_grp_name_get_nxt(mid, &gidx))) {
                if (!one_line_format) {
                    printf(name_format, "");
                    printf("  ");
                }

                /* Group value added */
                vtss_trace_grp_to_val(grp_name, mid, &grp_value); 
                printf("%d/",grp_value);                          
                
                printf(name_format, grp_name);
                /* Level value added */
                printf("%d/",vtss_trace_module_lvl_get(mid, gidx));                   
                printf(lvl_format, vtss_trace_lvl_to_str(vtss_trace_module_lvl_get(mid, gidx)));

                printf("%-9s  ", vtss_trace_grp_get_parm(VTSS_TRACE_MODULE_PARM_TIMESTAMP, mid, gidx) ? "yes" : "no");
                printf("%-4s  ", vtss_trace_grp_get_parm(VTSS_TRACE_MODULE_PARM_USEC, mid, gidx) ? "yes" : "no");
                if (!one_line_format) {
                    printf("%s\n", vtss_trace_grp_get_descr(mid, gidx));
                } else {
                    printf("%s\n", vtss_trace_module_get_descr(mid));
                }
                one_line_format = 0; /* one_line_format only applicable to first group */
                
                if (gidx == gidx_stop) break;
            }

            if (mid == mid_stop) break;
        }
    }
} /* cli_cmd_debug_trace_print_info */
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

/* Clear Port conters */
static void port_counters_clear(vtss_port_no_t port)
{
    vtss_port_no_t port_no;

    for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++) {
        if (port != 0 && port != port_no)
            continue;
        vtss_poag_counters_clear(port_no);
    }
}


static void handle_command(void)
{
    ulong res;
    ushort phyreg;

    switch(toupper(cmd)) {

    /* Read chip register*/
    case 'R':
        if(parms_count > 2) {
            parms[0] &= 0xFF;
            parms[0] <<= 12;
            
            parms[1] &= 0xFF;
            parms[1] <<= 8;
            
            parms[2] &= 0xFF;
            vtss_register_read(parms[0] | parms[1] | parms[2], &res);
            printf("0x%08lX\n", res);
            return;
        }
        break;

    case 'W':
        if(parms_count > 3) {
            parms[0] &= 0xFF;
            parms[0] <<= 12;
            
            parms[1] &= 0xFF;
            parms[1] <<= 8;
            
            parms[2] &= 0xFF;
            vtss_register_writemasked(parms[0] | parms[1] | parms[2], parms[3], parms[4]);
            return;
        }
        break;

    case 'I':
        if(VTSS_PORT_IS_PORT(parms[0])) {
            if(parms_count == 1) {
                /* Dump all std. page regs from PHY */
                uint i;
                for(i = 0; i < 32; i++) {
                    if(vtss_phy_read(parms[0], i, &phyreg)) {
                        return;
                    }
                    printf("%04X ", phyreg);
                    if((i&7)==7) {
                        printf("\n");
                    }
                }
                return;
            } else if(parms_count > 1) {
                /* dump a single register */
                vtss_phy_read(parms[0], parms[1], &phyreg);
                printf("%04X\n", phyreg);
                return;
            }
        }
        break;

    case 'O':
        if(VTSS_PORT_IS_PORT(parms[0])) {
            if(parms_count > 2) {
                vtss_phy_writemasked(parms[0], parms[1], parms[2], parms[3]);
                return;
            }
        }
        break;

    case 'F':
        /* Firmware programming */
        if(parms_count == 2 && parms[0] == 0 && parms[1] > 0) {
            unsigned int header[2], i;
            unsigned char ch, *buf, *p;
#if defined(VTSS_OPSYS_ECOS) && defined(CYG_HAL_STARTUP_ROMRAM)
            unsigned int crc;
#endif

            VTSS_D(("Now send firmware - %lu bytes!\n", parms[1]));

            for(p = (void*) header, i = 0; i < sizeof(header); i++) {
                while (!cli_char_available(&ch))
                    ;
                p[i] = ch;
            }

            buf = malloc(parms[1]);
            if(buf) {
                if(parms[1] == (header[1]+sizeof(header))) { /* Header has real file length */
                    unsigned int len = header[1];
                    VTSS_D(("Header length OK, proceeding\n"));
                    for(i = 0; i < len; i++) {
                        while (!cli_char_available(&ch))
                            ;
                        buf[i] = ch;
                    }
                    VTSS_D(("Received firmware\n"));

#if defined(VTSS_OPSYS_ECOS) && defined(CYG_HAL_STARTUP_ROMRAM)
                    crc = cyg_posix_crc32(buf, len);
                    VTSS_D(("POSIX cksum = %u %u (0x%08x 0x%08x)\n", crc, len, crc, len));
                    if(crc == header[0]) {
                        int err;
                        unsigned char *flash = (void*)(LUTON28_FLASH_PHYS_BASE + parms[0]);
                        ulong err_address;
                        ulong * perr_address = &err_address;

                        if(memcmp(flash, buf, len) != 0) {
                            VTSS_D(("Checksum correct. Updating - *do not turn off power*!.\n"));
                            flash_init(printf);    

                            if((err = flash_erase(flash, len, (void**)&perr_address)) == FLASH_ERR_OK) {
                                VTSS_D(("Erased flash..."));
                                if((err = flash_program(flash, buf, len, (void**)&perr_address)) == FLASH_ERR_OK) {
                                    VTSS_I(("Program OK"));
                                    HAL_PLATFORM_RESET();
                                } else {
                                    VTSS_E(("Flash program error: %d %s", err, flash_errmsg(err)));
                                }
                            } else {
                                VTSS_E(("Flash erase error: %d %s", err, flash_errmsg(err)));
                            }
                        } else {
                            VTSS_I(("Flash already contains that image, update skipped!\n"));
                        }
                    } else {
                        VTSS_E(("Checksum error, aborting flash update!\n"));
                    }
#else
                    VTSS_E(("Firmware update not supported by platform\n"));
#endif
                }
                free(buf);
            } else {
                printf("Memory allocation error - unable to upgrade flash!\n");
            }
        } else {
            printf("Usage: PROGRAM <offset> <length>\n");
        }
        return;
        /* ENOTREACHED */

    case 'H': case '?': case 0:
        printf(
            "Usage:\n\
  R <block> <subblock> <register>\n\
    Read chip register\n\
  W <block> <subblock> <register> <value> [mask = 0xFFFFFFFF]\n\
    Write chip register\n\
  I <port> [phy register]\n\
    Read one (or all) PHY register(s)\n\
  O <port> <phy register> <value> [mask = 0xFFFF]\n\
    Write PHY register\n\
  P Port commands\n\
  T Trace commands\n\
  S Suspend switch app\n\
  V Print Build information\n"
"  ~ Reset system\n");
        return;
        break;

    case 'S':
        switchapp_suspendended ^= 1;
        printf("Switch application is now %s\n", switchapp_suspendended?"suspended":"running");
        return;
        break;

    case 'V':
/*        printf("%s\n", version_string); */
          printf("Built %s %s\n", __TIME__, __DATE__); 
        return;
        break;

    case '~':
#if defined(VTSS_OPSYS_ECOS)
        HAL_PLATFORM_RESET();
#else
        exit(0);
#endif
        printf("Your platform reset routine is not implemented correctly!!!\n"); /* not reached*/
        break; 
        
        
    case 'P':
        if(parms_count == 0) {
            printf("Port commands:\n"
                   "  P 0 <port>   Show statistics for the given port\n"
                   "  P 1 <port>   Clear statistics for the given port\n"
                   "  P 2 <port>   Show the config of a given port\n");
        } else {
            vtss_port_no_t port_no = 0;

            if (parms_count == 2) {
                port_no = parms[1];
                if (!VTSS_PORT_IS_PORT(port_no)) {
                    printf("'%d' is not valid port no.\n", port_no);
                    break;
                }
            }
            
            switch(parms[0]) {
            case 0: 
                port_counters_show(port_no);
                break;
            case 1: 
                port_counters_clear(port_no);
                break;                
            case 2: 
                port_conf_show(port_no);
                break;
            default:
                /* The CMD character is not known */
                printf("Unknown port command!!!\n");
            }
        }
        break;

    case 'T':
#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
        if(parms_count == 0) {
            printf("Trace commands:\n\
  T 0 Show Trace modules and levels\n\
  T 1 <module nr> <group nr> <level nr>  Change the trace settings. (Numerical format, Wildcard = -1) \n\
      Level:  None=%d, Error=%d, Warning=%d, Info=%d, Debug=%d, Noise=%d, Racket=%d, All=%d \n\
  T 2 Reverse the trace settings\n\
  T 3 <module nr> <group nr> <0/1> Enable/Disable Timestamp\n\
  T 4 <module nr> <group nr> <0/1> Include Usec time stamp in trace\n",VTSS_TRACE_LVL_NONE, VTSS_TRACE_LVL_ERROR, VTSS_TRACE_LVL_WARNING, VTSS_TRACE_LVL_INFO, VTSS_TRACE_LVL_DEBUG, VTSS_TRACE_LVL_NOISE, VTSS_TRACE_LVL_RACKET, VTSS_TRACE_LVL_ALL);
            return;
        } else {
            switch(parms[0]) {
            case 0: 
                trace_modules_show();
                break;
            case 1:                 
                if(parms_count == 4) {                    
                    vtss_trace_module_lvl_set(parms[1], parms[2], parms[3]);
                } else {
                    printf("Wrong parameter count.\n");
                }
                break;
            case 2: 
                vtss_trace_lvl_reverse();
                printf("Trace level reversed.\n");
                break;
            case 3: 
                if(parms_count == 4) {                    
                    vtss_trace_module_parm_set(VTSS_TRACE_MODULE_PARM_TIMESTAMP, parms[1], parms[2], parms[3]);
                } else {
                    printf("Wrong parameter count.\n");
                }
                break;
            case 4: 
                if(parms_count == 4) {                    
                    vtss_trace_module_parm_set(VTSS_TRACE_MODULE_PARM_USEC, parms[1], parms[2], parms[3]);
                } else {
                    printf("Wrong parameter count.\n");
                }
                break;


            default:
                /* The CMD character is not known */
                printf("Unknown or invalid command!!!\n");
            }
            return;
        }
    default:
        /* The CMD character is not known */
        printf("Unknown or invalid command!!!\n");
#else 
        printf("Trace level is configured at compile time\n");
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */
    }

}

static void prompt(void)
{
    putchar('>');
    fflush(stdout);
}

static void cursor_left (void)
{
    if (cmd_cursor > 0) {
        cmd_cursor--;

        putchar(ESC);
        putchar(0x5b);
        putchar(CURSOR_LEFT);
        fflush(stdout);
    }
}

static void cursor_right (void)
{
    if (cmd_cursor < cmd_len) {
        cmd_cursor++;

        putchar(ESC);
        putchar(0x5b);
        putchar(CURSOR_RIGHT);
        fflush(stdout);
    }
}

static void cursor_home (void)
{
    while (cmd_cursor > 0) {
        cursor_left();
    }
}

static void delete_to_eol (void)
{
    putchar(ESC);
    putchar(0x5b);
    putchar(CURSOR_END);
    fflush(stdout);
}

static void rewrite_to_eol (void)
{
    while (cmd_cursor < cmd_len) {
        putchar(cmd_buf[cmd_cursor++]);
    }
    fflush(stdout);
}

static void delete_line (void)
{
    cursor_home();
    delete_to_eol();
}

static void append_line (void)
{
    uint cursor_save;

    cursor_save = cmd_cursor;
    rewrite_to_eol();
    while (cmd_cursor > cursor_save) {
        cursor_left();
    }
}

static void delete_char (void)
{
    uint j;

    cursor_left();
    delete_to_eol();

    /* concatenate command string */
    cmd_len--;
    for (j = cmd_cursor; j < cmd_len; j++) {
        cmd_buf[j] = cmd_buf[j + 1];
    }

    /* rewrite command part to the right of cursor */
    append_line();
}

static void insert_char (char ch)
{
    uint j;

    delete_to_eol();
    for (j = cmd_len; j > cmd_cursor; j--) {
        cmd_buf[j] = cmd_buf[j - 1];
    }
    cmd_len++;
    cmd_buf[cmd_cursor++] = ch;

    append_line();
}

static void get_old_cmd (void)
{
    delete_line();
    cmd_history_get();
    rewrite_to_eol();
}

static void process_escape_seq (char ch_1, char ch_2)
{
    if (ch_1 == 0x5b) {
        switch (ch_2) {
        case CURSOR_UP:
            if (cmd_history.scroll < cmd_history.len) {
                cmd_history.scroll++;
                get_old_cmd();
            }
            else {
                putchar(BEL);
                fflush(stdout);
            }
            break;

        case CURSOR_DOWN:
            if (cmd_history.scroll > 0) {
                cmd_history.scroll--;

                if (cmd_history.scroll > 0) {
                    get_old_cmd();
                }
                else {
                    delete_line();
                    cmd_len = 0;
                    cmd_cursor = 0;
                }
            }
            else {
                putchar(BEL);
                fflush(stdout);
            }
            break;

        case CURSOR_RIGHT:
            cursor_right();
            break;

        case CURSOR_LEFT:
            cursor_left();
            break;

        case CURSOR_HOME:
            cursor_home();
            break;

        case CURSOR_END:
            while (cmd_cursor < cmd_len) {
                cursor_right();
            }
            break;

        default:
            break;
        }
    }
}

static void cmd_history_put (void)
{
    memcpy(&cmd_history.buf[cmd_history.idx].cmd, &cmd_buf, cmd_len);
    cmd_history.buf[cmd_history.idx].cmd_len = cmd_len - 1; /* don't include CR */
    if (cmd_history.len < MAX_CMD_HISTORY_LEN) {
        cmd_history.len++;
    }
    if (++cmd_history.idx >= MAX_CMD_HISTORY_LEN) {
        cmd_history.idx = 0;
    }
    cmd_history.scroll = 0;
}

static void cmd_history_get (void)
{
    uint idx;

    if (cmd_history.idx >= cmd_history.scroll) {
        idx = cmd_history.idx - cmd_history.scroll;
    }
    else {
        idx = MAX_CMD_HISTORY_LEN - (cmd_history.scroll - cmd_history.idx);
    }

    cmd_len = cmd_history.buf[idx].cmd_len;
    memcpy(&cmd_buf, &cmd_history.buf[idx].cmd, cmd_len);

}

static BOOL empty_cmd_line (void)
{
    uint j;

    for (j = 0; j < cmd_len; j++) {
        if ((cmd_buf[j] != ' ') && (cmd_buf[j] != CR)) {
            return FALSE;
        }
    }
    return TRUE;
}

static BOOL cmd_ready (void)
{
    unsigned char ch;
    uint loop_count;
#if defined(VTSS_OPSYS_ECOS)
    static uint escape_seq_flag = FALSE;
    static uint escape_seq_count = 0;
    static char escape_seq [2];
#endif

    loop_count = 0;
    while (cli_char_available(&ch) && (loop_count++ < 20)) {

#if !defined(VTSS_OPSYS_ECOS)
/*        printf("CHAR_1: %02X\n", ch);  */
        /* convert LF into CR for linux terminal usage */
        if(ch==LF) ch=CR;
#endif
        if (ch != LF) { /* discard LF chars */
            
            if (ch == BS) { /* handle backspace char */
                if (cmd_len > 0) {
                    delete_char();
                }
            }
#if defined(VTSS_OPSYS_ECOS)
            else if (ch == ESC) {
                escape_seq_flag = TRUE;
                escape_seq_count = 0;
            }
            else if (escape_seq_flag) {
                escape_seq[escape_seq_count++] = ch;
                if (escape_seq_count >= 2) {
                    process_escape_seq(escape_seq[0], escape_seq[1]);
                    escape_seq_flag = FALSE;
                }
            }
#else
            else if (ch == ESC) {                
                ch = getc(stdin);
                process_escape_seq(ch, getc(stdin));
            }
#endif

            else {
                
                if (cmd_len < MAX_CMD_LEN) {
                    /* echo */
                    putchar(ch);
                    fflush(stdout);
                }
                
                if (ch != CR) {
                    if (cmd_len < MAX_CMD_LEN) {
                        if (cmd_cursor < cmd_len) {
                            insert_char(ch);
                        }
                        else {
                            cmd_buf[cmd_cursor++] = ch;
                            if (cmd_len < cmd_cursor) {
                                cmd_len++;
                            }
                        }
                    }
                }
                else {
                    putchar(LF);
                    fflush(stdout);

                    /* error handling: ensure that CR is present in buffer in case of buffer overflow */
                    if (cmd_len == MAX_CMD_LEN) {
                        cmd_buf[MAX_CMD_LEN - 1] = CR;
                    }
                    else {
                        cmd_buf[cmd_len++] = CR;
                    }
                    if (!empty_cmd_line()) {
                        cmd_history_put();
                    }
                    cmd_buf[cmd_len++] = '\0';                    

                    fflush(stdout);
                    return TRUE;
                }
            }
        }
    }
    return FALSE;
}

static char *cmd_get (void)
{
    cmd_len = 0;
    cmd_cursor = 0;

    return &cmd_buf[0];
}


static void retreive_params (BOOL force_hex)
{
    int n = 0;
    int res;    
    char * curp;
    char cmdstr[1+MAX_CMD_LEN];

    cmd = 0;
    curp = cmd_get();
    parms_count = 0;


    /* preset params */
    memset(parms, 0xFF, sizeof(parms));
    
    /* read command char */
    SKIP_SPACES(curp);  
    sscanf(curp, "%s%n", cmdstr, &n);
    curp += n;
    if(n >= 1) {
        cmd = cmdstr[0];
    }

    for(;;) {
        SKIP_SPACES(curp);
        if(IS_HEX(curp) || force_hex) {
            res = sscanf(curp, "%lx%n", &parms[parms_count], &n);
        } else {
            res = sscanf(curp, "%lu%n", &parms[parms_count], &n);
        }
        if(res == EOF || res == 0) {
            break;
        }
              
        curp += n;
        
        if(res > 0) {
            parms_count++;
        }
    }

}

/* 
** this variable is nice-to-have when debugging; can be used in a GDB script
** to check if the CPU survived the SwC reset...
*/
uint cli_initialized = 0;

void cli_init (void)
{

#if defined(VTSS_TRACE) && (VTSS_TRACE_ENABLED)
    VTSS_TRACE_REG_INIT(&trace_reg, trace_grps, TRACE_GRP_CNT);
    VTSS_TRACE_REGISTER(&trace_reg);
#endif /* VTSS_TRACE && VTSS_TRACE_ENABLED */

#if !defined(VTSS_OPSYS_ECOS)
    set_keypress();
#endif

#if defined(VTSS_OPSYS_ECOS)
    Cyg_ErrNo err;
    cyg_uint32 val, len = sizeof(val);

    err = cyg_io_lookup("/dev/ser1", &ser_handle);
    if(ENOERR == err) {
        /* set read nonblocking */
        val = 0;
        err = cyg_io_set_config(ser_handle, 
                                CYG_IO_SET_CONFIG_READ_BLOCKING,
                                &val,
                                &len);
        if(err != ENOERR) {
            printf("CLI: Error setting nonblocking read\n");
        }                                
    }
#endif /* VTSS_OPSYS_ECOS */

    cmd_history.len = 0;
    cmd_history.idx = 0;
    cmd_history.scroll = 0;
    prompt();
    cli_initialized = 1;
}

void cli_tsk(void)
{
    do {
        if(cmd_ready()) {
            retreive_params(FALSE);
            handle_command();
            prompt();
        }
    } while(switchapp_suspendended);
}
   
#endif /* VTSS_OPT_CLI */
/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/
