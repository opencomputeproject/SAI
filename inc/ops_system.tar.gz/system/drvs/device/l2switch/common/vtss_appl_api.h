/*

 Vitesse Switch API software.

 Copyright (c) 2002-2007 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.
 
 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.
 
 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.
 
 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: vtss_appl_api.h,v 1.1 2007/09/28 08:22:18 cpj Exp $
 $Revision: 1.1 $
*/

#ifndef _VTSS_APPL_API_H_
#define _VTSS_APPL_API_H_

/* Port status */
typedef struct {
    BOOL         link;       /* Link status, remaining fields only valid if link up */
    vtss_speed_t speed;      /* Speed */
    BOOL         fdx;        /* Full duplex */
    
    /* Auto negotiation result */
    struct {
        BOOL obey_pause;     /* This port should obey PAUSE frames */
        BOOL generate_pause; /* Link partner obeys PAUSE frames */
    } aneg;
} vtss_appl_port_status_t;

/* Get port status */
vtss_rc vtss_appl_port_status_get(const vtss_port_no_t            port_no,
                                  vtss_appl_port_status_t * const status);

/* Port configuration */
typedef struct {
    BOOL         enable;       /* Admin enable/disable */
    BOOL         autoneg;      /* Auto negotiation */
    vtss_speed_t speed;        /* Forced port speed */
    BOOL         fdx;          /* Forced duplex mode */
    BOOL         flow_control; /* Flow control */
    uint         max_length;   /* Max frame length */
} vtss_appl_port_conf_t;

/* Get port configuration */
vtss_rc vtss_appl_port_conf_get(const vtss_port_no_t          port_no,
                                vtss_appl_port_conf_t * const conf);

/* Set port configuration */
vtss_rc vtss_appl_port_conf_set(const vtss_port_no_t                port_no,
                                const vtss_appl_port_conf_t * const conf);

#endif /* _VTSS_APPL_API_H_ */
