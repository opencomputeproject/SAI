/*

 Vitesse Switch API software.

 Copyright (c) 2003 Vitesse Semiconductor Corporation. All Rights Reserved.
 Unpublished rights reserved under the copyright laws of the United States of 
 America, other countries and international treaties. The software is provided
 without fee. Permission to use, copy, store, modify, disclose, transmit or 
 distribute the software is granted, provided that this copyright notice must 
 appear in any copy, modification, disclosure, transmission or distribution of 
 the software. Vitesse Semiconductor Corporation retains all ownership, 
 copyright, trade secret and proprietary rights in the software. THIS SOFTWARE
 HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY INCLUDING, 
 WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 PARTICULAR USE AND NON-INFRINGEMENT.
 
 $Id: heathrow_qs.h,v 1.51 2006/06/14 11:54:52 bjo Exp $
 $Revision: 1.51 $

*/

#if defined(VTSS_ARCH_HAWX)
/* HawX queue system settings */

/* VTSS_<maxsize>_<prios><strict/weighted priority>_<drop/flowcontrol mode>[_ uplink]_<register> */
/* define   ::= VTSS_(NORM|9600)_(1|2|4|8)(S|W)_(DROP|FC)[_U]_<register> */
/* register ::= EARLY_TX | FWDP_(START|STOP) | (E|I)(MIN|MAX)(0-7) | ZEROPAUSE | PAUSEVALUE */


/* StaplefordIIDropModeNormal */

#define VTSS_NORM_8S_DROP_EARLY_TX      0
#define VTSS_NORM_8S_DROP_FWDP_START    44
#define VTSS_NORM_8S_DROP_FWDP_STOP     44
#define VTSS_NORM_8S_DROP_EMIN0         0
#define VTSS_NORM_8S_DROP_EMAX0         20
#define VTSS_NORM_8S_DROP_IMIN0         0
#define VTSS_NORM_8S_DROP_IMAX0         64
#define VTSS_NORM_8S_DROP_EMIN1         0
#define VTSS_NORM_8S_DROP_EMAX1         24
#define VTSS_NORM_8S_DROP_IMIN1         0
#define VTSS_NORM_8S_DROP_IMAX1         64
#define VTSS_NORM_8S_DROP_EMIN2         0
#define VTSS_NORM_8S_DROP_EMAX2         28
#define VTSS_NORM_8S_DROP_IMIN2         0
#define VTSS_NORM_8S_DROP_IMAX2         64
#define VTSS_NORM_8S_DROP_EMIN3         0
#define VTSS_NORM_8S_DROP_EMAX3         32
#define VTSS_NORM_8S_DROP_IMIN3         0
#define VTSS_NORM_8S_DROP_IMAX3         64
#define VTSS_NORM_8S_DROP_EMIN4         0
#define VTSS_NORM_8S_DROP_EMAX4         36
#define VTSS_NORM_8S_DROP_IMIN4         0
#define VTSS_NORM_8S_DROP_IMAX4         64
#define VTSS_NORM_8S_DROP_EMIN5         0
#define VTSS_NORM_8S_DROP_EMAX5         40
#define VTSS_NORM_8S_DROP_IMIN5         0
#define VTSS_NORM_8S_DROP_IMAX5         64
#define VTSS_NORM_8S_DROP_EMIN6         0
#define VTSS_NORM_8S_DROP_EMAX6         44
#define VTSS_NORM_8S_DROP_IMIN6         0
#define VTSS_NORM_8S_DROP_IMAX6         64
#define VTSS_NORM_8S_DROP_EMIN7         0
#define VTSS_NORM_8S_DROP_EMAX7         48
#define VTSS_NORM_8S_DROP_IMIN7         0
#define VTSS_NORM_8S_DROP_IMAX7         64
#define VTSS_NORM_8S_DROP_ZEROPAUSE     0
#define VTSS_NORM_8S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_NORM_8W_DROP_EARLY_TX      0
#define VTSS_NORM_8W_DROP_FWDP_START    44
#define VTSS_NORM_8W_DROP_FWDP_STOP     44
#define VTSS_NORM_8W_DROP_EMIN0         8
#define VTSS_NORM_8W_DROP_EMAX0         20
#define VTSS_NORM_8W_DROP_IMIN0         8
#define VTSS_NORM_8W_DROP_IMAX0         64
#define VTSS_NORM_8W_DROP_EMIN1         8
#define VTSS_NORM_8W_DROP_EMAX1         24
#define VTSS_NORM_8W_DROP_IMIN1         8
#define VTSS_NORM_8W_DROP_IMAX1         64
#define VTSS_NORM_8W_DROP_EMIN2         8
#define VTSS_NORM_8W_DROP_EMAX2         28
#define VTSS_NORM_8W_DROP_IMIN2         8
#define VTSS_NORM_8W_DROP_IMAX2         64
#define VTSS_NORM_8W_DROP_EMIN3         8
#define VTSS_NORM_8W_DROP_EMAX3         32
#define VTSS_NORM_8W_DROP_IMIN3         8
#define VTSS_NORM_8W_DROP_IMAX3         64
#define VTSS_NORM_8W_DROP_EMIN4         8
#define VTSS_NORM_8W_DROP_EMAX4         36
#define VTSS_NORM_8W_DROP_IMIN4         8
#define VTSS_NORM_8W_DROP_IMAX4         64
#define VTSS_NORM_8W_DROP_EMIN5         8
#define VTSS_NORM_8W_DROP_EMAX5         40
#define VTSS_NORM_8W_DROP_IMIN5         8
#define VTSS_NORM_8W_DROP_IMAX5         64
#define VTSS_NORM_8W_DROP_EMIN6         8
#define VTSS_NORM_8W_DROP_EMAX6         44
#define VTSS_NORM_8W_DROP_IMIN6         8
#define VTSS_NORM_8W_DROP_IMAX6         64
#define VTSS_NORM_8W_DROP_EMIN7         8
#define VTSS_NORM_8W_DROP_EMAX7         48
#define VTSS_NORM_8W_DROP_IMIN7         8
#define VTSS_NORM_8W_DROP_IMAX7         64
#define VTSS_NORM_8W_DROP_ZEROPAUSE     0
#define VTSS_NORM_8W_DROP_PAUSEVALUE    0 /*Don't care*/


#define VTSS_NORM_8S_DROP_U_EARLY_TX    0
#define VTSS_NORM_8S_DROP_U_FWDP_START  116
#define VTSS_NORM_8S_DROP_U_FWDP_STOP   116
#define VTSS_NORM_8S_DROP_U_EMIN0       0
#define VTSS_NORM_8S_DROP_U_EMAX0       100
#define VTSS_NORM_8S_DROP_U_IMIN0       0
#define VTSS_NORM_8S_DROP_U_IMAX0       144
#define VTSS_NORM_8S_DROP_U_EMIN1       0
#define VTSS_NORM_8S_DROP_U_EMAX1       104
#define VTSS_NORM_8S_DROP_U_IMIN1       0
#define VTSS_NORM_8S_DROP_U_IMAX1       144
#define VTSS_NORM_8S_DROP_U_EMIN2       0
#define VTSS_NORM_8S_DROP_U_EMAX2       108
#define VTSS_NORM_8S_DROP_U_IMIN2       0
#define VTSS_NORM_8S_DROP_U_IMAX2       144
#define VTSS_NORM_8S_DROP_U_EMIN3       0
#define VTSS_NORM_8S_DROP_U_EMAX3       112
#define VTSS_NORM_8S_DROP_U_IMIN3       0
#define VTSS_NORM_8S_DROP_U_IMAX3       144
#define VTSS_NORM_8S_DROP_U_EMIN4       0
#define VTSS_NORM_8S_DROP_U_EMAX4       116
#define VTSS_NORM_8S_DROP_U_IMIN4       0
#define VTSS_NORM_8S_DROP_U_IMAX4       144
#define VTSS_NORM_8S_DROP_U_EMIN5       0
#define VTSS_NORM_8S_DROP_U_EMAX5       120
#define VTSS_NORM_8S_DROP_U_IMIN5       0
#define VTSS_NORM_8S_DROP_U_IMAX5       144
#define VTSS_NORM_8S_DROP_U_EMIN6       0
#define VTSS_NORM_8S_DROP_U_EMAX6       124
#define VTSS_NORM_8S_DROP_U_IMIN6       0
#define VTSS_NORM_8S_DROP_U_IMAX6       144
#define VTSS_NORM_8S_DROP_U_EMIN7       0
#define VTSS_NORM_8S_DROP_U_EMAX7       128
#define VTSS_NORM_8S_DROP_U_IMIN7       0
#define VTSS_NORM_8S_DROP_U_IMAX7       144
#define VTSS_NORM_8S_DROP_U_ZEROPAUSE   0
#define VTSS_NORM_8S_DROP_U_PAUSEVALUE  0 /*Don't care*/

#define VTSS_NORM_8W_DROP_U_EARLY_TX    0
#define VTSS_NORM_8W_DROP_U_FWDP_START  116
#define VTSS_NORM_8W_DROP_U_FWDP_STOP   116
#define VTSS_NORM_8W_DROP_U_EMIN0       8
#define VTSS_NORM_8W_DROP_U_EMAX0       100
#define VTSS_NORM_8W_DROP_U_IMIN0       8
#define VTSS_NORM_8W_DROP_U_IMAX0       144
#define VTSS_NORM_8W_DROP_U_EMIN1       8
#define VTSS_NORM_8W_DROP_U_EMAX1       104
#define VTSS_NORM_8W_DROP_U_IMIN1       8
#define VTSS_NORM_8W_DROP_U_IMAX1       144
#define VTSS_NORM_8W_DROP_U_EMIN2       8
#define VTSS_NORM_8W_DROP_U_EMAX2       108
#define VTSS_NORM_8W_DROP_U_IMIN2       8
#define VTSS_NORM_8W_DROP_U_IMAX2       144
#define VTSS_NORM_8W_DROP_U_EMIN3       8
#define VTSS_NORM_8W_DROP_U_EMAX3       112
#define VTSS_NORM_8W_DROP_U_IMIN3       8
#define VTSS_NORM_8W_DROP_U_IMAX3       144
#define VTSS_NORM_8W_DROP_U_EMIN4       8
#define VTSS_NORM_8W_DROP_U_EMAX4       116
#define VTSS_NORM_8W_DROP_U_IMIN4       8
#define VTSS_NORM_8W_DROP_U_IMAX4       144
#define VTSS_NORM_8W_DROP_U_EMIN5       8
#define VTSS_NORM_8W_DROP_U_EMAX5       120
#define VTSS_NORM_8W_DROP_U_IMIN5       8
#define VTSS_NORM_8W_DROP_U_IMAX5       144
#define VTSS_NORM_8W_DROP_U_EMIN6       8
#define VTSS_NORM_8W_DROP_U_EMAX6       124
#define VTSS_NORM_8W_DROP_U_IMIN6       8
#define VTSS_NORM_8W_DROP_U_IMAX6       144
#define VTSS_NORM_8W_DROP_U_EMIN7       8
#define VTSS_NORM_8W_DROP_U_EMAX7       128
#define VTSS_NORM_8W_DROP_U_IMIN7       8
#define VTSS_NORM_8W_DROP_U_IMAX7       144
#define VTSS_NORM_8W_DROP_U_ZEROPAUSE   0
#define VTSS_NORM_8W_DROP_U_PAUSEVALUE  0 /*Don't care*/


/* StaplefordIIDropMode9600 */

#define VTSS_9600_8S_DROP_EARLY_TX      0
#define VTSS_9600_8S_DROP_FWDP_START    36
#define VTSS_9600_8S_DROP_FWDP_STOP     36
#define VTSS_9600_8S_DROP_EMIN0         0
#define VTSS_9600_8S_DROP_EMAX0         44
#define VTSS_9600_8S_DROP_IMIN0         0
#define VTSS_9600_8S_DROP_IMAX0         64
#define VTSS_9600_8S_DROP_EMIN1         0
#define VTSS_9600_8S_DROP_EMAX1         46
#define VTSS_9600_8S_DROP_IMIN1         0
#define VTSS_9600_8S_DROP_IMAX1         64
#define VTSS_9600_8S_DROP_EMIN2         0
#define VTSS_9600_8S_DROP_EMAX2         48
#define VTSS_9600_8S_DROP_IMIN2         0
#define VTSS_9600_8S_DROP_IMAX2         64
#define VTSS_9600_8S_DROP_EMIN3         0
#define VTSS_9600_8S_DROP_EMAX3         50
#define VTSS_9600_8S_DROP_IMIN3         0
#define VTSS_9600_8S_DROP_IMAX3         64
#define VTSS_9600_8S_DROP_EMIN4         0
#define VTSS_9600_8S_DROP_EMAX4         52
#define VTSS_9600_8S_DROP_IMIN4         0
#define VTSS_9600_8S_DROP_IMAX4         64
#define VTSS_9600_8S_DROP_EMIN5         0
#define VTSS_9600_8S_DROP_EMAX5         54
#define VTSS_9600_8S_DROP_IMIN5         0
#define VTSS_9600_8S_DROP_IMAX5         64
#define VTSS_9600_8S_DROP_EMIN6         0
#define VTSS_9600_8S_DROP_EMAX6         56
#define VTSS_9600_8S_DROP_IMIN6         0
#define VTSS_9600_8S_DROP_IMAX6         64
#define VTSS_9600_8S_DROP_EMIN7         0
#define VTSS_9600_8S_DROP_EMAX7         58
#define VTSS_9600_8S_DROP_IMIN7         0
#define VTSS_9600_8S_DROP_IMAX7         64
#define VTSS_9600_8S_DROP_ZEROPAUSE     0
#define VTSS_9600_8S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_9600_8W_DROP_EARLY_TX      0
#define VTSS_9600_8W_DROP_FWDP_START    36
#define VTSS_9600_8W_DROP_FWDP_STOP     36
#define VTSS_9600_8W_DROP_EMIN0         8
#define VTSS_9600_8W_DROP_EMAX0         30
#define VTSS_9600_8W_DROP_IMIN0         8
#define VTSS_9600_8W_DROP_IMAX0         64
#define VTSS_9600_8W_DROP_EMIN1         8
#define VTSS_9600_8W_DROP_EMAX1         32
#define VTSS_9600_8W_DROP_IMIN1         8
#define VTSS_9600_8W_DROP_IMAX1         64
#define VTSS_9600_8W_DROP_EMIN2         8
#define VTSS_9600_8W_DROP_EMAX2         34
#define VTSS_9600_8W_DROP_IMIN2         8
#define VTSS_9600_8W_DROP_IMAX2         64
#define VTSS_9600_8W_DROP_EMIN3         8
#define VTSS_9600_8W_DROP_EMAX3         36
#define VTSS_9600_8W_DROP_IMIN3         8
#define VTSS_9600_8W_DROP_IMAX3         64
#define VTSS_9600_8W_DROP_EMIN4         8
#define VTSS_9600_8W_DROP_EMAX4         38
#define VTSS_9600_8W_DROP_IMIN4         8
#define VTSS_9600_8W_DROP_IMAX4         64
#define VTSS_9600_8W_DROP_EMIN5         8
#define VTSS_9600_8W_DROP_EMAX5         40
#define VTSS_9600_8W_DROP_IMIN5         8
#define VTSS_9600_8W_DROP_IMAX5         64
#define VTSS_9600_8W_DROP_EMIN6         8
#define VTSS_9600_8W_DROP_EMAX6         42
#define VTSS_9600_8W_DROP_IMIN6         8
#define VTSS_9600_8W_DROP_IMAX6         64
#define VTSS_9600_8W_DROP_EMIN7         8
#define VTSS_9600_8W_DROP_EMAX7         44
#define VTSS_9600_8W_DROP_IMIN7         8
#define VTSS_9600_8W_DROP_IMAX7         64
#define VTSS_9600_8W_DROP_ZEROPAUSE     0
#define VTSS_9600_8W_DROP_PAUSEVALUE    0 /*Don't care*/


#define VTSS_9600_8S_DROP_U_EARLY_TX    0
#define VTSS_9600_8S_DROP_U_FWDP_START  116
#define VTSS_9600_8S_DROP_U_FWDP_STOP   116
#define VTSS_9600_8S_DROP_U_EMIN0       0
#define VTSS_9600_8S_DROP_U_EMAX0       100
#define VTSS_9600_8S_DROP_U_IMIN0       0
#define VTSS_9600_8S_DROP_U_IMAX0       144
#define VTSS_9600_8S_DROP_U_EMIN1       0
#define VTSS_9600_8S_DROP_U_EMAX1       104
#define VTSS_9600_8S_DROP_U_IMIN1       0
#define VTSS_9600_8S_DROP_U_IMAX1       144
#define VTSS_9600_8S_DROP_U_EMIN2       0
#define VTSS_9600_8S_DROP_U_EMAX2       108
#define VTSS_9600_8S_DROP_U_IMIN2       0
#define VTSS_9600_8S_DROP_U_IMAX2       144
#define VTSS_9600_8S_DROP_U_EMIN3       0
#define VTSS_9600_8S_DROP_U_EMAX3       112
#define VTSS_9600_8S_DROP_U_IMIN3       0
#define VTSS_9600_8S_DROP_U_IMAX3       144
#define VTSS_9600_8S_DROP_U_EMIN4       0
#define VTSS_9600_8S_DROP_U_EMAX4       116
#define VTSS_9600_8S_DROP_U_IMIN4       0
#define VTSS_9600_8S_DROP_U_IMAX4       144
#define VTSS_9600_8S_DROP_U_EMIN5       0
#define VTSS_9600_8S_DROP_U_EMAX5       120
#define VTSS_9600_8S_DROP_U_IMIN5       0
#define VTSS_9600_8S_DROP_U_IMAX5       144
#define VTSS_9600_8S_DROP_U_EMIN6       0
#define VTSS_9600_8S_DROP_U_EMAX6       124
#define VTSS_9600_8S_DROP_U_IMIN6       0
#define VTSS_9600_8S_DROP_U_IMAX6       144
#define VTSS_9600_8S_DROP_U_EMIN7       0
#define VTSS_9600_8S_DROP_U_EMAX7       128
#define VTSS_9600_8S_DROP_U_IMIN7       0
#define VTSS_9600_8S_DROP_U_IMAX7       144
#define VTSS_9600_8S_DROP_U_ZEROPAUSE   0
#define VTSS_9600_8S_DROP_U_PAUSEVALUE  0 /*Don't care*/

#define VTSS_9600_8W_DROP_U_EARLY_TX    0
#define VTSS_9600_8W_DROP_U_FWDP_START  116
#define VTSS_9600_8W_DROP_U_FWDP_STOP   116
#define VTSS_9600_8W_DROP_U_EMIN0       8
#define VTSS_9600_8W_DROP_U_EMAX0       100
#define VTSS_9600_8W_DROP_U_IMIN0       8
#define VTSS_9600_8W_DROP_U_IMAX0       144
#define VTSS_9600_8W_DROP_U_EMIN1       8
#define VTSS_9600_8W_DROP_U_EMAX1       104
#define VTSS_9600_8W_DROP_U_IMIN1       8
#define VTSS_9600_8W_DROP_U_IMAX1       144
#define VTSS_9600_8W_DROP_U_EMIN2       8
#define VTSS_9600_8W_DROP_U_EMAX2       108
#define VTSS_9600_8W_DROP_U_IMIN2       8
#define VTSS_9600_8W_DROP_U_IMAX2       144
#define VTSS_9600_8W_DROP_U_EMIN3       8
#define VTSS_9600_8W_DROP_U_EMAX3       112
#define VTSS_9600_8W_DROP_U_IMIN3       8
#define VTSS_9600_8W_DROP_U_IMAX3       144
#define VTSS_9600_8W_DROP_U_EMIN4       8
#define VTSS_9600_8W_DROP_U_EMAX4       116
#define VTSS_9600_8W_DROP_U_IMIN4       8
#define VTSS_9600_8W_DROP_U_IMAX4       144
#define VTSS_9600_8W_DROP_U_EMIN5       8
#define VTSS_9600_8W_DROP_U_EMAX5       120
#define VTSS_9600_8W_DROP_U_IMIN5       8
#define VTSS_9600_8W_DROP_U_IMAX5       144
#define VTSS_9600_8W_DROP_U_EMIN6       8
#define VTSS_9600_8W_DROP_U_EMAX6       124
#define VTSS_9600_8W_DROP_U_IMIN6       8
#define VTSS_9600_8W_DROP_U_IMAX6       144
#define VTSS_9600_8W_DROP_U_EMIN7       8
#define VTSS_9600_8W_DROP_U_EMAX7       128
#define VTSS_9600_8W_DROP_U_IMIN7       8
#define VTSS_9600_8W_DROP_U_IMAX7       144
#define VTSS_9600_8W_DROP_U_ZEROPAUSE   0
#define VTSS_9600_8W_DROP_U_PAUSEVALUE  0 /*Don't care*/


/* StaplefordIIFlowControlNormal */

#define VTSS_NORM_8S_FC_EARLY_TX        0
#define VTSS_NORM_8S_FC_FWDP_START      24
#define VTSS_NORM_8S_FC_FWDP_STOP       18
#define VTSS_NORM_8S_FC_EMIN0           0
#define VTSS_NORM_8S_FC_EMAX0           34
#define VTSS_NORM_8S_FC_IMIN0           0
#define VTSS_NORM_8S_FC_IMAX0           54
#define VTSS_NORM_8S_FC_EMIN1           0
#define VTSS_NORM_8S_FC_EMAX1           34
#define VTSS_NORM_8S_FC_IMIN1           0
#define VTSS_NORM_8S_FC_IMAX1           54
#define VTSS_NORM_8S_FC_EMIN2           0
#define VTSS_NORM_8S_FC_EMAX2           34
#define VTSS_NORM_8S_FC_IMIN2           0
#define VTSS_NORM_8S_FC_IMAX2           54
#define VTSS_NORM_8S_FC_EMIN3           0
#define VTSS_NORM_8S_FC_EMAX3           34
#define VTSS_NORM_8S_FC_IMIN3           0
#define VTSS_NORM_8S_FC_IMAX3           54
#define VTSS_NORM_8S_FC_EMIN4           0
#define VTSS_NORM_8S_FC_EMAX4           34
#define VTSS_NORM_8S_FC_IMIN4           0
#define VTSS_NORM_8S_FC_IMAX4           54
#define VTSS_NORM_8S_FC_EMIN5           0
#define VTSS_NORM_8S_FC_EMAX5           34
#define VTSS_NORM_8S_FC_IMIN5           0
#define VTSS_NORM_8S_FC_IMAX5           54
#define VTSS_NORM_8S_FC_EMIN6           0
#define VTSS_NORM_8S_FC_EMAX6           34
#define VTSS_NORM_8S_FC_IMIN6           0
#define VTSS_NORM_8S_FC_IMAX6           54
#define VTSS_NORM_8S_FC_EMIN7           0
#define VTSS_NORM_8S_FC_EMAX7           34
#define VTSS_NORM_8S_FC_IMIN7           0
#define VTSS_NORM_8S_FC_IMAX7           54
#define VTSS_NORM_8S_FC_ZEROPAUSE       1
#define VTSS_NORM_8S_FC_PAUSEVALUE      0xff

/* Not used */
#define VTSS_NORM_8W_FC_EARLY_TX        0
#define VTSS_NORM_8W_FC_FWDP_START      0
#define VTSS_NORM_8W_FC_FWDP_STOP       0
#define VTSS_NORM_8W_FC_EMIN0           0
#define VTSS_NORM_8W_FC_EMAX0           0
#define VTSS_NORM_8W_FC_IMIN0           0
#define VTSS_NORM_8W_FC_IMAX0           0
#define VTSS_NORM_8W_FC_EMIN1           0
#define VTSS_NORM_8W_FC_EMAX1           0
#define VTSS_NORM_8W_FC_IMIN1           0
#define VTSS_NORM_8W_FC_IMAX1           0
#define VTSS_NORM_8W_FC_EMIN2           0
#define VTSS_NORM_8W_FC_EMAX2           0
#define VTSS_NORM_8W_FC_IMIN2           0
#define VTSS_NORM_8W_FC_IMAX2           0
#define VTSS_NORM_8W_FC_EMIN3           0
#define VTSS_NORM_8W_FC_EMAX3           0
#define VTSS_NORM_8W_FC_IMIN3           0
#define VTSS_NORM_8W_FC_IMAX3           0
#define VTSS_NORM_8W_FC_EMIN4           0
#define VTSS_NORM_8W_FC_EMAX4           0
#define VTSS_NORM_8W_FC_IMIN4           0
#define VTSS_NORM_8W_FC_IMAX4           0
#define VTSS_NORM_8W_FC_EMIN5           0
#define VTSS_NORM_8W_FC_EMAX5           0
#define VTSS_NORM_8W_FC_IMIN5           0
#define VTSS_NORM_8W_FC_IMAX5           0
#define VTSS_NORM_8W_FC_EMIN6           0
#define VTSS_NORM_8W_FC_EMAX6           0
#define VTSS_NORM_8W_FC_IMIN6           0
#define VTSS_NORM_8W_FC_IMAX6           0
#define VTSS_NORM_8W_FC_EMIN7           0
#define VTSS_NORM_8W_FC_EMAX7           0
#define VTSS_NORM_8W_FC_IMIN7           0
#define VTSS_NORM_8W_FC_IMAX7           0
#define VTSS_NORM_8W_FC_ZEROPAUSE       1
#define VTSS_NORM_8W_FC_PAUSEVALUE      0xFF


#define VTSS_NORM_8S_FC_U_EARLY_TX      0
#define VTSS_NORM_8S_FC_U_FWDP_START    64
#define VTSS_NORM_8S_FC_U_FWDP_STOP     54
#define VTSS_NORM_8S_FC_U_EMIN0         0
#define VTSS_NORM_8S_FC_U_EMAX0         118
#define VTSS_NORM_8S_FC_U_IMIN0         0
#define VTSS_NORM_8S_FC_U_IMAX0         118
#define VTSS_NORM_8S_FC_U_EMIN1         0
#define VTSS_NORM_8S_FC_U_EMAX1         118
#define VTSS_NORM_8S_FC_U_IMIN1         0
#define VTSS_NORM_8S_FC_U_IMAX1         118
#define VTSS_NORM_8S_FC_U_EMIN2         0
#define VTSS_NORM_8S_FC_U_EMAX2         118
#define VTSS_NORM_8S_FC_U_IMIN2         0
#define VTSS_NORM_8S_FC_U_IMAX2         118
#define VTSS_NORM_8S_FC_U_EMIN3         0
#define VTSS_NORM_8S_FC_U_EMAX3         118
#define VTSS_NORM_8S_FC_U_IMIN3         0
#define VTSS_NORM_8S_FC_U_IMAX3         118
#define VTSS_NORM_8S_FC_U_EMIN4         0
#define VTSS_NORM_8S_FC_U_EMAX4         118
#define VTSS_NORM_8S_FC_U_IMIN4         0
#define VTSS_NORM_8S_FC_U_IMAX4         118
#define VTSS_NORM_8S_FC_U_EMIN5         0
#define VTSS_NORM_8S_FC_U_EMAX5         118
#define VTSS_NORM_8S_FC_U_IMIN5         0
#define VTSS_NORM_8S_FC_U_IMAX5         118
#define VTSS_NORM_8S_FC_U_EMIN6         0
#define VTSS_NORM_8S_FC_U_EMAX6         118
#define VTSS_NORM_8S_FC_U_IMIN6         0
#define VTSS_NORM_8S_FC_U_IMAX6         118
#define VTSS_NORM_8S_FC_U_EMIN7         0
#define VTSS_NORM_8S_FC_U_EMAX7         118
#define VTSS_NORM_8S_FC_U_IMIN7         0
#define VTSS_NORM_8S_FC_U_IMAX7         118
#define VTSS_NORM_8S_FC_U_ZEROPAUSE     1
#define VTSS_NORM_8S_FC_U_PAUSEVALUE    0xFF

/* Not used */
#define VTSS_NORM_8W_FC_U_EARLY_TX      0
#define VTSS_NORM_8W_FC_U_FWDP_START    0
#define VTSS_NORM_8W_FC_U_FWDP_STOP     0
#define VTSS_NORM_8W_FC_U_EMIN0         0
#define VTSS_NORM_8W_FC_U_EMAX0         0
#define VTSS_NORM_8W_FC_U_IMIN0         0
#define VTSS_NORM_8W_FC_U_IMAX0         0
#define VTSS_NORM_8W_FC_U_EMIN1         0
#define VTSS_NORM_8W_FC_U_EMAX1         0
#define VTSS_NORM_8W_FC_U_IMIN1         0
#define VTSS_NORM_8W_FC_U_IMAX1         0
#define VTSS_NORM_8W_FC_U_EMIN2         0
#define VTSS_NORM_8W_FC_U_EMAX2         0
#define VTSS_NORM_8W_FC_U_IMIN2         0
#define VTSS_NORM_8W_FC_U_IMAX2         0
#define VTSS_NORM_8W_FC_U_EMIN3         0
#define VTSS_NORM_8W_FC_U_EMAX3         0
#define VTSS_NORM_8W_FC_U_IMIN3         0
#define VTSS_NORM_8W_FC_U_IMAX3         0
#define VTSS_NORM_8W_FC_U_EMIN4         0
#define VTSS_NORM_8W_FC_U_EMAX4         0
#define VTSS_NORM_8W_FC_U_IMIN4         0
#define VTSS_NORM_8W_FC_U_IMAX4         0
#define VTSS_NORM_8W_FC_U_EMIN5         0
#define VTSS_NORM_8W_FC_U_EMAX5         0
#define VTSS_NORM_8W_FC_U_IMIN5         0
#define VTSS_NORM_8W_FC_U_IMAX5         0
#define VTSS_NORM_8W_FC_U_EMIN6         0
#define VTSS_NORM_8W_FC_U_EMAX6         0
#define VTSS_NORM_8W_FC_U_IMIN6         0
#define VTSS_NORM_8W_FC_U_IMAX6         0
#define VTSS_NORM_8W_FC_U_EMIN7         0
#define VTSS_NORM_8W_FC_U_EMAX7         0
#define VTSS_NORM_8W_FC_U_IMIN7         0
#define VTSS_NORM_8W_FC_U_IMAX7         0
#define VTSS_NORM_8W_FC_U_ZEROPAUSE     1
#define VTSS_NORM_8W_FC_U_PAUSEVALUE    0xFF


/* StaplefordIIFlowControl9600 */

#define VTSS_9600_8S_FC_EARLY_TX        0
#define VTSS_9600_8S_FC_FWDP_START      24
#define VTSS_9600_8S_FC_FWDP_STOP       18
#define VTSS_9600_8S_FC_EMIN0           0
#define VTSS_9600_8S_FC_EMAX0           34
#define VTSS_9600_8S_FC_IMIN0           0
#define VTSS_9600_8S_FC_IMAX0           54
#define VTSS_9600_8S_FC_EMIN1           0
#define VTSS_9600_8S_FC_EMAX1           34
#define VTSS_9600_8S_FC_IMIN1           0
#define VTSS_9600_8S_FC_IMAX1           54
#define VTSS_9600_8S_FC_EMIN2           0
#define VTSS_9600_8S_FC_EMAX2           34
#define VTSS_9600_8S_FC_IMIN2           0
#define VTSS_9600_8S_FC_IMAX2           54
#define VTSS_9600_8S_FC_EMIN3           0
#define VTSS_9600_8S_FC_EMAX3           34
#define VTSS_9600_8S_FC_IMIN3           0
#define VTSS_9600_8S_FC_IMAX3           54
#define VTSS_9600_8S_FC_EMIN4           0
#define VTSS_9600_8S_FC_EMAX4           34
#define VTSS_9600_8S_FC_IMIN4           0
#define VTSS_9600_8S_FC_IMAX4           54
#define VTSS_9600_8S_FC_EMIN5           0
#define VTSS_9600_8S_FC_EMAX5           34
#define VTSS_9600_8S_FC_IMIN5           0
#define VTSS_9600_8S_FC_IMAX5           54
#define VTSS_9600_8S_FC_EMIN6           0
#define VTSS_9600_8S_FC_EMAX6           34
#define VTSS_9600_8S_FC_IMIN6           0
#define VTSS_9600_8S_FC_IMAX6           54
#define VTSS_9600_8S_FC_EMIN7           0
#define VTSS_9600_8S_FC_EMAX7           34
#define VTSS_9600_8S_FC_IMIN7           0
#define VTSS_9600_8S_FC_IMAX7           54
#define VTSS_9600_8S_FC_ZEROPAUSE       1
#define VTSS_9600_8S_FC_PAUSEVALUE      0xFF

/* Not used */
#define VTSS_9600_8W_FC_EARLY_TX        0
#define VTSS_9600_8W_FC_FWDP_START      0
#define VTSS_9600_8W_FC_FWDP_STOP       0
#define VTSS_9600_8W_FC_EMIN0           0
#define VTSS_9600_8W_FC_EMAX0           0
#define VTSS_9600_8W_FC_IMIN0           0
#define VTSS_9600_8W_FC_IMAX0           0
#define VTSS_9600_8W_FC_EMIN1           0
#define VTSS_9600_8W_FC_EMAX1           0
#define VTSS_9600_8W_FC_IMIN1           0
#define VTSS_9600_8W_FC_IMAX1           0
#define VTSS_9600_8W_FC_EMIN2           0
#define VTSS_9600_8W_FC_EMAX2           0
#define VTSS_9600_8W_FC_IMIN2           0
#define VTSS_9600_8W_FC_IMAX2           0
#define VTSS_9600_8W_FC_EMIN3           0
#define VTSS_9600_8W_FC_EMAX3           0
#define VTSS_9600_8W_FC_IMIN3           0
#define VTSS_9600_8W_FC_IMAX3           0
#define VTSS_9600_8W_FC_EMIN4           0
#define VTSS_9600_8W_FC_EMAX4           0
#define VTSS_9600_8W_FC_IMIN4           0
#define VTSS_9600_8W_FC_IMAX4           0
#define VTSS_9600_8W_FC_EMIN5           0
#define VTSS_9600_8W_FC_EMAX5           0
#define VTSS_9600_8W_FC_IMIN5           0
#define VTSS_9600_8W_FC_IMAX5           0
#define VTSS_9600_8W_FC_EMIN6           0
#define VTSS_9600_8W_FC_EMAX6           0
#define VTSS_9600_8W_FC_IMIN6           0
#define VTSS_9600_8W_FC_IMAX6           0
#define VTSS_9600_8W_FC_EMIN7           0
#define VTSS_9600_8W_FC_EMAX7           0
#define VTSS_9600_8W_FC_IMIN7           0
#define VTSS_9600_8W_FC_IMAX7           0
#define VTSS_9600_8W_FC_ZEROPAUSE       1
#define VTSS_9600_8W_FC_PAUSEVALUE      0xFF


#define VTSS_9600_8S_FC_U_EARLY_TX      0
#define VTSS_9600_8S_FC_U_FWDP_START    64
#define VTSS_9600_8S_FC_U_FWDP_STOP     54
#define VTSS_9600_8S_FC_U_EMIN0         0
#define VTSS_9600_8S_FC_U_EMAX0         118
#define VTSS_9600_8S_FC_U_IMIN0         0
#define VTSS_9600_8S_FC_U_IMAX0         118
#define VTSS_9600_8S_FC_U_EMIN1         0
#define VTSS_9600_8S_FC_U_EMAX1         118
#define VTSS_9600_8S_FC_U_IMIN1         0
#define VTSS_9600_8S_FC_U_IMAX1         118
#define VTSS_9600_8S_FC_U_EMIN2         0
#define VTSS_9600_8S_FC_U_EMAX2         118
#define VTSS_9600_8S_FC_U_IMIN2         0
#define VTSS_9600_8S_FC_U_IMAX2         118
#define VTSS_9600_8S_FC_U_EMIN3         0
#define VTSS_9600_8S_FC_U_EMAX3         118
#define VTSS_9600_8S_FC_U_IMIN3         0
#define VTSS_9600_8S_FC_U_IMAX3         118
#define VTSS_9600_8S_FC_U_EMIN4         0
#define VTSS_9600_8S_FC_U_EMAX4         118
#define VTSS_9600_8S_FC_U_IMIN4         0
#define VTSS_9600_8S_FC_U_IMAX4         118
#define VTSS_9600_8S_FC_U_EMIN5         0
#define VTSS_9600_8S_FC_U_EMAX5         118
#define VTSS_9600_8S_FC_U_IMIN5         0
#define VTSS_9600_8S_FC_U_IMAX5         118
#define VTSS_9600_8S_FC_U_EMIN6         0
#define VTSS_9600_8S_FC_U_EMAX6         118
#define VTSS_9600_8S_FC_U_IMIN6         0
#define VTSS_9600_8S_FC_U_IMAX6         118
#define VTSS_9600_8S_FC_U_EMIN7         0
#define VTSS_9600_8S_FC_U_EMAX7         118
#define VTSS_9600_8S_FC_U_IMIN7         0
#define VTSS_9600_8S_FC_U_IMAX7         118
#define VTSS_9600_8S_FC_U_ZEROPAUSE     1
#define VTSS_9600_8S_FC_U_PAUSEVALUE    0xFF

/* Not used */
#define VTSS_9600_8W_FC_U_EARLY_TX      0
#define VTSS_9600_8W_FC_U_FWDP_START    0
#define VTSS_9600_8W_FC_U_FWDP_STOP     0
#define VTSS_9600_8W_FC_U_EMIN0         0
#define VTSS_9600_8W_FC_U_EMAX0         0
#define VTSS_9600_8W_FC_U_IMIN0         0
#define VTSS_9600_8W_FC_U_IMAX0         0
#define VTSS_9600_8W_FC_U_EMIN1         0
#define VTSS_9600_8W_FC_U_EMAX1         0
#define VTSS_9600_8W_FC_U_IMIN1         0
#define VTSS_9600_8W_FC_U_IMAX1         0
#define VTSS_9600_8W_FC_U_EMIN2         0
#define VTSS_9600_8W_FC_U_EMAX2         0
#define VTSS_9600_8W_FC_U_IMIN2         0
#define VTSS_9600_8W_FC_U_IMAX2         0
#define VTSS_9600_8W_FC_U_EMIN3         0
#define VTSS_9600_8W_FC_U_EMAX3         0
#define VTSS_9600_8W_FC_U_IMIN3         0
#define VTSS_9600_8W_FC_U_IMAX3         0
#define VTSS_9600_8W_FC_U_EMIN4         0
#define VTSS_9600_8W_FC_U_EMAX4         0
#define VTSS_9600_8W_FC_U_IMIN4         0
#define VTSS_9600_8W_FC_U_IMAX4         0
#define VTSS_9600_8W_FC_U_EMIN5         0
#define VTSS_9600_8W_FC_U_EMAX5         0
#define VTSS_9600_8W_FC_U_IMIN5         0
#define VTSS_9600_8W_FC_U_IMAX5         0
#define VTSS_9600_8W_FC_U_EMIN6         0
#define VTSS_9600_8W_FC_U_EMAX6         0
#define VTSS_9600_8W_FC_U_IMIN6         0
#define VTSS_9600_8W_FC_U_IMAX6         0
#define VTSS_9600_8W_FC_U_EMIN7         0
#define VTSS_9600_8W_FC_U_EMAX7         0
#define VTSS_9600_8W_FC_U_IMIN7         0
#define VTSS_9600_8W_FC_U_IMAX7         0
#define VTSS_9600_8W_FC_U_ZEROPAUSE     1
#define VTSS_9600_8W_FC_U_PAUSEVALUE    0xFF


#endif /* VTSS_ARCH_HAWX */

#if defined(SPARX_G5) || defined(SPARX_G8)
/* SparX-G5/G8 queue system settings */

/* VTSS_<maxsize>_<prios><strict/weighted priority>_<drop/flowcontrol mode>_<register> */
/* define   ::= VTSS_(NORM|9600)_(1|2|4)(S|W)_(DROP|FC)_<register> */
/* register ::= EARLY_TX | FWDP_(START|STOP) | (E|I)(MIN|MAX)(0-3) | ZEROPAUSE | PAUSEVALUE */


/* LutonDropModeNormal */

#define VTSS_NORM_4S_DROP_EARLY_TX      0
#define VTSS_NORM_4S_DROP_FWDP_START    20
#define VTSS_NORM_4S_DROP_FWDP_STOP     20
#define VTSS_NORM_4S_DROP_EMIN0         0
#define VTSS_NORM_4S_DROP_EMAX0         21
#define VTSS_NORM_4S_DROP_IMIN0         0
#define VTSS_NORM_4S_DROP_IMAX0         24
#define VTSS_NORM_4S_DROP_EMIN1         0
#define VTSS_NORM_4S_DROP_EMAX1         22
#define VTSS_NORM_4S_DROP_IMIN1         0
#define VTSS_NORM_4S_DROP_IMAX1         24
#define VTSS_NORM_4S_DROP_EMIN2         0
#define VTSS_NORM_4S_DROP_EMAX2         23
#define VTSS_NORM_4S_DROP_IMIN2         0
#define VTSS_NORM_4S_DROP_IMAX2         24
#define VTSS_NORM_4S_DROP_EMIN3         0
#define VTSS_NORM_4S_DROP_EMAX3         24
#define VTSS_NORM_4S_DROP_IMIN3         0
#define VTSS_NORM_4S_DROP_IMAX3         24
#define VTSS_NORM_4S_DROP_ZEROPAUSE     0

#define VTSS_NORM_4S_DROP_PAUSEVALUE    0 /*Don't care*/
#define VTSS_NORM_4W_DROP_EARLY_TX      0
#define VTSS_NORM_4W_DROP_FWDP_START    12
#define VTSS_NORM_4W_DROP_FWDP_STOP     12
#define VTSS_NORM_4W_DROP_EMIN0         2
#define VTSS_NORM_4W_DROP_EMAX0         14
#define VTSS_NORM_4W_DROP_IMIN0         2
#define VTSS_NORM_4W_DROP_IMAX0         18
#define VTSS_NORM_4W_DROP_EMIN1         2
#define VTSS_NORM_4W_DROP_EMAX1         14
#define VTSS_NORM_4W_DROP_IMIN1         2
#define VTSS_NORM_4W_DROP_IMAX1         18
#define VTSS_NORM_4W_DROP_EMIN2         2
#define VTSS_NORM_4W_DROP_EMAX2         14
#define VTSS_NORM_4W_DROP_IMIN2         2
#define VTSS_NORM_4W_DROP_IMAX2         18
#define VTSS_NORM_4W_DROP_EMIN3         2
#define VTSS_NORM_4W_DROP_EMAX3         14
#define VTSS_NORM_4W_DROP_IMIN3         2
#define VTSS_NORM_4W_DROP_IMAX3         18
#define VTSS_NORM_4W_DROP_ZEROPAUSE     0
#define VTSS_NORM_4W_DROP_PAUSEVALUE    0 /*Don't care*/


/* LutonFlowControlNormal */

#define VTSS_NORM_4S_FC_EARLY_TX        0
#define VTSS_NORM_4S_FC_FWDP_START      12
#define VTSS_NORM_4S_FC_FWDP_STOP       8
#define VTSS_NORM_4S_FC_EMIN0           0
#define VTSS_NORM_4S_FC_EMAX0           6
#define VTSS_NORM_4S_FC_IMIN0           0
#define VTSS_NORM_4S_FC_IMAX0           20
#define VTSS_NORM_4S_FC_EMIN1           0
#define VTSS_NORM_4S_FC_EMAX1           7
#define VTSS_NORM_4S_FC_IMIN1           0
#define VTSS_NORM_4S_FC_IMAX1           20
#define VTSS_NORM_4S_FC_EMIN2           0
#define VTSS_NORM_4S_FC_EMAX2           8
#define VTSS_NORM_4S_FC_IMIN2           0
#define VTSS_NORM_4S_FC_IMAX2           20
#define VTSS_NORM_4S_FC_EMIN3           0
#define VTSS_NORM_4S_FC_EMAX3           9
#define VTSS_NORM_4S_FC_IMIN3           0
#define VTSS_NORM_4S_FC_IMAX3           20
#define VTSS_NORM_4S_FC_ZEROPAUSE       1
#define VTSS_NORM_4S_FC_PAUSEVALUE      0xFF /*Don't care*/

/* Not used */
#define VTSS_NORM_4W_FC_EARLY_TX        0
#define VTSS_NORM_4W_FC_FWDP_START      12
#define VTSS_NORM_4W_FC_FWDP_STOP       8
#define VTSS_NORM_4W_FC_EMIN0           2
#define VTSS_NORM_4W_FC_EMAX0           6
#define VTSS_NORM_4W_FC_IMIN0           2
#define VTSS_NORM_4W_FC_IMAX0           20
#define VTSS_NORM_4W_FC_EMIN1           2
#define VTSS_NORM_4W_FC_EMAX1           7
#define VTSS_NORM_4W_FC_IMIN1           2
#define VTSS_NORM_4W_FC_IMAX1           20
#define VTSS_NORM_4W_FC_EMIN2           2
#define VTSS_NORM_4W_FC_EMAX2           8
#define VTSS_NORM_4W_FC_IMIN2           2
#define VTSS_NORM_4W_FC_IMAX2           20
#define VTSS_NORM_4W_FC_EMIN3           2
#define VTSS_NORM_4W_FC_EMAX3           9
#define VTSS_NORM_4W_FC_IMIN3           2
#define VTSS_NORM_4W_FC_IMAX3           20
#define VTSS_NORM_4W_FC_ZEROPAUSE       1
#define VTSS_NORM_4W_FC_PAUSEVALUE      0xFF /*Don't care*/


/* LutonDropMode9600 */
#define VTSS_9600_4S_DROP_EARLY_TX      0
#define VTSS_9600_4S_DROP_FWDP_START    18
#define VTSS_9600_4S_DROP_FWDP_STOP     18
#define VTSS_9600_4S_DROP_EMIN0         0
#define VTSS_9600_4S_DROP_EMAX0         21
#define VTSS_9600_4S_DROP_IMIN0         0
#define VTSS_9600_4S_DROP_IMAX0         21
#define VTSS_9600_4S_DROP_EMIN1         0
#define VTSS_9600_4S_DROP_EMAX1         22
#define VTSS_9600_4S_DROP_IMIN1         0
#define VTSS_9600_4S_DROP_IMAX1         21
#define VTSS_9600_4S_DROP_EMIN2         0
#define VTSS_9600_4S_DROP_EMAX2         23
#define VTSS_9600_4S_DROP_IMIN2         0
#define VTSS_9600_4S_DROP_IMAX2         21
#define VTSS_9600_4S_DROP_EMIN3         0
#define VTSS_9600_4S_DROP_EMAX3         24
#define VTSS_9600_4S_DROP_IMIN3         0
#define VTSS_9600_4S_DROP_IMAX3         21
#define VTSS_9600_4S_DROP_ZEROPAUSE     0
#define VTSS_9600_4S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_9600_4W_DROP_EARLY_TX      0
#define VTSS_9600_4W_DROP_FWDP_START    12
#define VTSS_9600_4W_DROP_FWDP_STOP     12
#define VTSS_9600_4W_DROP_EMIN0         4
#define VTSS_9600_4W_DROP_EMAX0         15
#define VTSS_9600_4W_DROP_IMIN0         4
#define VTSS_9600_4W_DROP_IMAX0         15
#define VTSS_9600_4W_DROP_EMIN1         4
#define VTSS_9600_4W_DROP_EMAX1         15
#define VTSS_9600_4W_DROP_IMIN1         4
#define VTSS_9600_4W_DROP_IMAX1         15
#define VTSS_9600_4W_DROP_EMIN2         4
#define VTSS_9600_4W_DROP_EMAX2         15
#define VTSS_9600_4W_DROP_IMIN2         4
#define VTSS_9600_4W_DROP_IMAX2         15
#define VTSS_9600_4W_DROP_EMIN3         4
#define VTSS_9600_4W_DROP_EMAX3         15
#define VTSS_9600_4W_DROP_IMIN3         4
#define VTSS_9600_4W_DROP_IMAX3         15
#define VTSS_9600_4W_DROP_ZEROPAUSE     0
#define VTSS_9600_4W_DROP_PAUSEVALUE    0 /*Don't care*/


/* LutonFlowControl9600 */

#define VTSS_9600_4S_FC_EARLY_TX        0
#define VTSS_9600_4S_FC_FWDP_START      6
#define VTSS_9600_4S_FC_FWDP_STOP       2
#define VTSS_9600_4S_FC_EMIN0           0
#define VTSS_9600_4S_FC_EMAX0           14
#define VTSS_9600_4S_FC_IMIN0           0
#define VTSS_9600_4S_FC_IMAX0           26
#define VTSS_9600_4S_FC_EMIN1           0
#define VTSS_9600_4S_FC_EMAX1           15
#define VTSS_9600_4S_FC_IMIN1           0
#define VTSS_9600_4S_FC_IMAX1           26
#define VTSS_9600_4S_FC_EMIN2           0
#define VTSS_9600_4S_FC_EMAX2           16
#define VTSS_9600_4S_FC_IMIN2           0
#define VTSS_9600_4S_FC_IMAX2           26
#define VTSS_9600_4S_FC_EMIN3           0
#define VTSS_9600_4S_FC_EMAX3           17
#define VTSS_9600_4S_FC_IMIN3           0
#define VTSS_9600_4S_FC_IMAX3           26
#define VTSS_9600_4S_FC_ZEROPAUSE       1
#define VTSS_9600_4S_FC_PAUSEVALUE      0xFF /*Don't care*/

#define VTSS_9600_4W_FC_EARLY_TX        0
#define VTSS_9600_4W_FC_FWDP_START      6
#define VTSS_9600_4W_FC_FWDP_STOP       2
#define VTSS_9600_4W_FC_EMIN0           4
#define VTSS_9600_4W_FC_EMAX0           14
#define VTSS_9600_4W_FC_IMIN0           4
#define VTSS_9600_4W_FC_IMAX0           26
#define VTSS_9600_4W_FC_EMIN1           4
#define VTSS_9600_4W_FC_EMAX1           15
#define VTSS_9600_4W_FC_IMIN1           4
#define VTSS_9600_4W_FC_IMAX1           26
#define VTSS_9600_4W_FC_EMIN2           4
#define VTSS_9600_4W_FC_EMAX2           16
#define VTSS_9600_4W_FC_IMIN2           4
#define VTSS_9600_4W_FC_IMAX2           26
#define VTSS_9600_4W_FC_EMIN3           4
#define VTSS_9600_4W_FC_EMAX3           17
#define VTSS_9600_4W_FC_IMIN3           4
#define VTSS_9600_4W_FC_IMAX3           26
#define VTSS_9600_4W_FC_ZEROPAUSE       1
#define VTSS_9600_4W_FC_PAUSEVALUE      0xFF /*Don't care*/

#endif /* SPARX_G5/SPARX_G8 */


#if defined(SPARX_G5E) || defined(SPARX_G8E)
/* SparX-G5E/G8E queue system settings */

/* VTSS_<maxsize>_<prios><strict/weighted priority>_<drop/flowcontrol mode>_<register> */
/* define   ::= VTSS_(NORM|9600)_(1|2|4)(S|W)_(DROP|FC)_<register> */
/* register ::= EARLY_TX | FWDP_(START|STOP) | (E|I)(MIN|MAX)(0-3) | ZEROPAUSE | PAUSEVALUE */


/* Luton8eDropModeNormal */
#define VTSS_NORM_4S_DROP_PAUSEVALUE    0
#define VTSS_NORM_4S_DROP_EARLY_TX      0
#define VTSS_NORM_4S_DROP_FWDP_START    16
#define VTSS_NORM_4S_DROP_FWDP_STOP     16
#define VTSS_NORM_4S_DROP_EMIN0        	0
#define VTSS_NORM_4S_DROP_EMAX0         14
#define VTSS_NORM_4S_DROP_IMIN0        	0
#define VTSS_NORM_4S_DROP_IMAX0         21
#define VTSS_NORM_4S_DROP_EMIN1         0
#define VTSS_NORM_4S_DROP_EMAX1        	16
#define VTSS_NORM_4S_DROP_IMIN1        	0
#define VTSS_NORM_4S_DROP_IMAX1        	21
#define VTSS_NORM_4S_DROP_EMIN2        	0
#define VTSS_NORM_4S_DROP_EMAX2        	18
#define VTSS_NORM_4S_DROP_IMIN2         0
#define VTSS_NORM_4S_DROP_IMAX2         21
#define VTSS_NORM_4S_DROP_EMIN3        	0
#define VTSS_NORM_4S_DROP_EMAX3        	20
#define VTSS_NORM_4S_DROP_IMIN3        	0
#define VTSS_NORM_4S_DROP_IMAX3        	21
#define VTSS_NORM_4S_DROP_ZEROPAUSE    	0


#define VTSS_NORM_4W_DROP_PAUSEVALUE    0 /*Don't care*/
#define VTSS_NORM_4W_DROP_EARLY_TX      0
#define VTSS_NORM_4W_DROP_FWDP_START    16
#define VTSS_NORM_4W_DROP_FWDP_STOP     16
#define VTSS_NORM_4W_DROP_EMIN0         6
#define VTSS_NORM_4W_DROP_EMAX0         18
#define VTSS_NORM_4W_DROP_IMIN0         6
#define VTSS_NORM_4W_DROP_IMAX0         22
#define VTSS_NORM_4W_DROP_EMIN1         6
#define VTSS_NORM_4W_DROP_EMAX1         18
#define VTSS_NORM_4W_DROP_IMIN1         6
#define VTSS_NORM_4W_DROP_IMAX1         22
#define VTSS_NORM_4W_DROP_EMIN2         6
#define VTSS_NORM_4W_DROP_EMAX2         18
#define VTSS_NORM_4W_DROP_IMIN2         6
#define VTSS_NORM_4W_DROP_IMAX2         22
#define VTSS_NORM_4W_DROP_EMIN3         6
#define VTSS_NORM_4W_DROP_EMAX3         18
#define VTSS_NORM_4W_DROP_IMIN3         6
#define VTSS_NORM_4W_DROP_IMAX3         22
#define VTSS_NORM_4W_DROP_ZEROPAUSE     0
#define VTSS_NORM_4W_DROP_PAUSEVALUE    0 /*Don't care*/


/* Luton8eFlowControlNormal */

#define VTSS_NORM_4S_FC_EARLY_TX        0
#define VTSS_NORM_4S_FC_FWDP_START      16
#define VTSS_NORM_4S_FC_FWDP_STOP       12
#define VTSS_NORM_4S_FC_EMIN0           0
#define VTSS_NORM_4S_FC_EMAX0           10
#define VTSS_NORM_4S_FC_IMIN0           0
#define VTSS_NORM_4S_FC_IMAX0           24
#define VTSS_NORM_4S_FC_EMIN1           0
#define VTSS_NORM_4S_FC_EMAX1           11
#define VTSS_NORM_4S_FC_IMIN1           0
#define VTSS_NORM_4S_FC_IMAX1           24
#define VTSS_NORM_4S_FC_EMIN2           0
#define VTSS_NORM_4S_FC_EMAX2           12
#define VTSS_NORM_4S_FC_IMIN2           0
#define VTSS_NORM_4S_FC_IMAX2           24
#define VTSS_NORM_4S_FC_EMIN3           0
#define VTSS_NORM_4S_FC_EMAX3           13
#define VTSS_NORM_4S_FC_IMIN3           0
#define VTSS_NORM_4S_FC_IMAX3           24
#define VTSS_NORM_4S_FC_ZEROPAUSE       1
#define VTSS_NORM_4S_FC_PAUSEVALUE      0xFF /*Don't care*/

/* Not used */
#define VTSS_NORM_4W_FC_EARLY_TX        0
#define VTSS_NORM_4W_FC_FWDP_START      16
#define VTSS_NORM_4W_FC_FWDP_STOP       12
#define VTSS_NORM_4W_FC_EMIN0           6
#define VTSS_NORM_4W_FC_EMAX0           10
#define VTSS_NORM_4W_FC_IMIN0           6
#define VTSS_NORM_4W_FC_IMAX0           24
#define VTSS_NORM_4W_FC_EMIN1           6
#define VTSS_NORM_4W_FC_EMAX1           11
#define VTSS_NORM_4W_FC_IMIN1           6
#define VTSS_NORM_4W_FC_IMAX1           24
#define VTSS_NORM_4W_FC_EMIN2           6
#define VTSS_NORM_4W_FC_EMAX2           12
#define VTSS_NORM_4W_FC_IMIN2           6
#define VTSS_NORM_4W_FC_IMAX2           24
#define VTSS_NORM_4W_FC_EMIN3           6
#define VTSS_NORM_4W_FC_EMAX3           13
#define VTSS_NORM_4W_FC_IMIN3           6
#define VTSS_NORM_4W_FC_IMAX3           24
#define VTSS_NORM_4W_FC_ZEROPAUSE       1
#define VTSS_NORM_4W_FC_PAUSEVALUE      0xFF /*Don't care*/


/* Luton8eDropMode9600 */
#define VTSS_9600_4S_DROP_EARLY_TX      4 /* Only for 1G. '0' for 10/100 */
#define VTSS_9600_4S_DROP_FWDP_START    16
#define VTSS_9600_4S_DROP_FWDP_STOP     16
#define VTSS_9600_4S_DROP_EMIN0         0
#define VTSS_9600_4S_DROP_EMAX0         14
#define VTSS_9600_4S_DROP_IMIN0         0
#define VTSS_9600_4S_DROP_IMAX0         21
#define VTSS_9600_4S_DROP_EMIN1         0
#define VTSS_9600_4S_DROP_EMAX1         16
#define VTSS_9600_4S_DROP_IMIN1         0
#define VTSS_9600_4S_DROP_IMAX1         21
#define VTSS_9600_4S_DROP_EMIN2         0
#define VTSS_9600_4S_DROP_EMAX2         18
#define VTSS_9600_4S_DROP_IMIN2         0
#define VTSS_9600_4S_DROP_IMAX2         21
#define VTSS_9600_4S_DROP_EMIN3         0
#define VTSS_9600_4S_DROP_EMAX3         20
#define VTSS_9600_4S_DROP_IMIN3         0
#define VTSS_9600_4S_DROP_IMAX3         21
#define VTSS_9600_4S_DROP_ZEROPAUSE     0
#define VTSS_9600_4S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_9600_4W_DROP_EARLY_TX      4 /* Only for 1G. '0' for 10/100 */
#define VTSS_9600_4W_DROP_FWDP_START    16
#define VTSS_9600_4W_DROP_FWDP_STOP     16
#define VTSS_9600_4W_DROP_EMIN0         8
#define VTSS_9600_4W_DROP_EMAX0         19
#define VTSS_9600_4W_DROP_IMIN0         8
#define VTSS_9600_4W_DROP_IMAX0         21
#define VTSS_9600_4W_DROP_EMIN1         8
#define VTSS_9600_4W_DROP_EMAX1         19
#define VTSS_9600_4W_DROP_IMIN1         8
#define VTSS_9600_4W_DROP_IMAX1         21
#define VTSS_9600_4W_DROP_EMIN2         8
#define VTSS_9600_4W_DROP_EMAX2         19
#define VTSS_9600_4W_DROP_IMIN2         8
#define VTSS_9600_4W_DROP_IMAX2         21
#define VTSS_9600_4W_DROP_EMIN3         8
#define VTSS_9600_4W_DROP_EMAX3         19
#define VTSS_9600_4W_DROP_IMIN3         8
#define VTSS_9600_4W_DROP_IMAX3         21
#define VTSS_9600_4W_DROP_ZEROPAUSE     0
#define VTSS_9600_4W_DROP_PAUSEVALUE    0 /*Don't care*/


/* Luton8eFlowControl9600 */

#define VTSS_9600_4S_FC_EARLY_TX        0
#define VTSS_9600_4S_FC_FWDP_START      8
#define VTSS_9600_4S_FC_FWDP_STOP       4
#define VTSS_9600_4S_FC_EMIN0           0
#define VTSS_9600_4S_FC_EMAX0           18
#define VTSS_9600_4S_FC_IMIN0           0
#define VTSS_9600_4S_FC_IMAX0           30
#define VTSS_9600_4S_FC_EMIN1           0
#define VTSS_9600_4S_FC_EMAX1           19
#define VTSS_9600_4S_FC_IMIN1           0
#define VTSS_9600_4S_FC_IMAX1           30
#define VTSS_9600_4S_FC_EMIN2           0
#define VTSS_9600_4S_FC_EMAX2           20
#define VTSS_9600_4S_FC_IMIN2           0
#define VTSS_9600_4S_FC_IMAX2           30
#define VTSS_9600_4S_FC_EMIN3           0
#define VTSS_9600_4S_FC_EMAX3           21
#define VTSS_9600_4S_FC_IMIN3           0
#define VTSS_9600_4S_FC_IMAX3           30
#define VTSS_9600_4S_FC_ZEROPAUSE       1
#define VTSS_9600_4S_FC_PAUSEVALUE      0xFF /*Don't care*/

/* Not used */
#define VTSS_9600_4W_FC_EARLY_TX        0
#define VTSS_9600_4W_FC_FWDP_START      8
#define VTSS_9600_4W_FC_FWDP_STOP       4
#define VTSS_9600_4W_FC_EMIN0           8
#define VTSS_9600_4W_FC_EMAX0           18
#define VTSS_9600_4W_FC_IMIN0           8
#define VTSS_9600_4W_FC_IMAX0           30
#define VTSS_9600_4W_FC_EMIN1           8
#define VTSS_9600_4W_FC_EMAX1           19
#define VTSS_9600_4W_FC_IMIN1           8
#define VTSS_9600_4W_FC_IMAX1           30
#define VTSS_9600_4W_FC_EMIN2           8
#define VTSS_9600_4W_FC_EMAX2           20
#define VTSS_9600_4W_FC_IMIN2           8
#define VTSS_9600_4W_FC_IMAX2           30
#define VTSS_9600_4W_FC_EMIN3           8
#define VTSS_9600_4W_FC_EMAX3           21
#define VTSS_9600_4W_FC_IMIN3           8
#define VTSS_9600_4W_FC_IMAX3           30
#define VTSS_9600_4W_FC_ZEROPAUSE       1
#define VTSS_9600_4W_FC_PAUSEVALUE      0xFF /*Don't care*/

#endif /* SPARX_G5E/SPARX_G8E */

#if defined(SPARX_G16) || defined(SPARX_G24)
/* SparX-G16/G24 queue system settings */

/* VTSS_<maxsize>_<prios><strict/weighted priority>_<drop/flowcontrol mode>_<register> */
/* define   ::= VTSS_(NORM|9600)_(1|2|4)(S|W)_(DROP|FC)_<register> */
/* register ::= EARLY_TX | FWDP_(START|STOP) | IMIN | IDISC | EMIN | EMAX(0-3) | ZEROPAUSE | PAUSEVALUE */


/* Luton24DropModeWithoutPrio */
/* Luton24DropMode9600WithoutPrio */
#define VTSS_NORM_1S_DROP_EARLY_TX      0
#define VTSS_NORM_1S_DROP_FWDP_START    39
#define VTSS_NORM_1S_DROP_FWDP_STOP     39
#define VTSS_NORM_1S_DROP_IMIN          0
#define VTSS_NORM_1S_DROP_IDISC         34
#define VTSS_NORM_1S_DROP_EMIN          0
#define VTSS_NORM_1S_DROP_EMAX0         28 
#define VTSS_NORM_1S_DROP_EMAX1         28
#define VTSS_NORM_1S_DROP_EMAX2         28
#define VTSS_NORM_1S_DROP_EMAX3         28
#define VTSS_NORM_1S_DROP_ZEROPAUSE     0  
#define VTSS_NORM_1S_DROP_PAUSEVALUE    0  /*Don't care*/


/* Luton24DropModeNormal */
#define VTSS_NORM_4S_DROP_EARLY_TX      0
#define VTSS_NORM_4S_DROP_FWDP_START    36
#define VTSS_NORM_4S_DROP_FWDP_STOP     38
#define VTSS_NORM_4S_DROP_IMIN          0
#define VTSS_NORM_4S_DROP_IDISC         32
#define VTSS_NORM_4S_DROP_EMIN          0
#define VTSS_NORM_4S_DROP_EMAX0         19
#define VTSS_NORM_4S_DROP_EMAX1         22
#define VTSS_NORM_4S_DROP_EMAX2         25
#define VTSS_NORM_4S_DROP_EMAX3         28
#define VTSS_NORM_4S_DROP_ZEROPAUSE     0
#define VTSS_NORM_4S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_NORM_4W_DROP_EARLY_TX      0
#define VTSS_NORM_4W_DROP_FWDP_START    32
#define VTSS_NORM_4W_DROP_FWDP_STOP     20
#define VTSS_NORM_4W_DROP_IMIN          4
#define VTSS_NORM_4W_DROP_IDISC         39
#define VTSS_NORM_4W_DROP_EMIN          4
#define VTSS_NORM_4W_DROP_EMAX0         16
#define VTSS_NORM_4W_DROP_EMAX1         16
#define VTSS_NORM_4W_DROP_EMAX2         16
#define VTSS_NORM_4W_DROP_EMAX3         16
#define VTSS_NORM_4W_DROP_ZEROPAUSE     0
#define VTSS_NORM_4W_DROP_PAUSEVALUE    0 /*Don't care*/


/* Luton24FlowControlNormal */
#define VTSS_NORM_4S_FC_EARLY_TX        0
#define VTSS_NORM_4S_FC_FWDP_START      12
#define VTSS_NORM_4S_FC_FWDP_STOP       8
#define VTSS_NORM_4S_FC_IMIN            0
#define VTSS_NORM_4S_FC_IDISC           36
#define VTSS_NORM_4S_FC_EMIN            0
#define VTSS_NORM_4S_FC_EMAX0           12
#define VTSS_NORM_4S_FC_EMAX1           12
#define VTSS_NORM_4S_FC_EMAX2           12
#define VTSS_NORM_4S_FC_EMAX3           12
#define VTSS_NORM_4S_FC_ZEROPAUSE       1
#define VTSS_NORM_4S_FC_PAUSEVALUE      0xFF


#define VTSS_NORM_4W_FC_EARLY_TX        0
#define VTSS_NORM_4W_FC_FWDP_START      12
#define VTSS_NORM_4W_FC_FWDP_STOP       8
#define VTSS_NORM_4W_FC_IMIN            4
#define VTSS_NORM_4W_FC_IDISC           36
#define VTSS_NORM_4W_FC_EMIN            4
#define VTSS_NORM_4W_FC_EMAX0           12
#define VTSS_NORM_4W_FC_EMAX1           12
#define VTSS_NORM_4W_FC_EMAX2           12
#define VTSS_NORM_4W_FC_EMAX3           12
#define VTSS_NORM_4W_FC_ZEROPAUSE       1
#define VTSS_NORM_4W_FC_PAUSEVALUE      0xFF

#if !VTSS_OPT_EARLY_TX
/* Luton24DropMode9600 -- Rev A-B with Early Tx Disabled */
#define VTSS_9600_4S_DROP_EARLY_TX      0 /* Always 0 */
#define VTSS_9600_4S_DROP_FWDP_START    0
#define VTSS_9600_4S_DROP_FWDP_STOP     34
#define VTSS_9600_4S_DROP_IMIN          39
#define VTSS_9600_4S_DROP_IDISC         39
#define VTSS_9600_4S_DROP_EMIN          0
#define VTSS_9600_4S_DROP_EMAX0         19
#define VTSS_9600_4S_DROP_EMAX1         22
#define VTSS_9600_4S_DROP_EMAX2         25
#define VTSS_9600_4S_DROP_EMAX3         28
#define VTSS_9600_4S_DROP_ZEROPAUSE     0
#define VTSS_9600_4S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_9600_4W_DROP_EARLY_TX      0 /* Always 0 */
#define VTSS_9600_4W_DROP_FWDP_START    39
#define VTSS_9600_4W_DROP_FWDP_STOP     34
#define VTSS_9600_4W_DROP_IMIN          4
#define VTSS_9600_4W_DROP_IDISC         32
#define VTSS_9600_4W_DROP_EMIN          4
#define VTSS_9600_4W_DROP_EMAX0         16
#define VTSS_9600_4W_DROP_EMAX1         16
#define VTSS_9600_4W_DROP_EMAX2         16
#define VTSS_9600_4W_DROP_EMAX3         16
#define VTSS_9600_4W_DROP_ZEROPAUSE     0
#define VTSS_9600_4W_DROP_PAUSEVALUE    0 /*Don't care*/

#else

/* Luton24DropMode9600 -- Rev C with Early Tx Enabled */
#define VTSS_9600_4S_DROP_EARLY_TX      2  /* Only for 1G. '0' for 10/100 */
#define VTSS_9600_4S_DROP_FWDP_START    33 /* Only for 1G. '39' for 10/100 */
#define VTSS_9600_4S_DROP_FWDP_STOP     39
#define VTSS_9600_4S_DROP_EMIN          0
#define VTSS_9600_4S_DROP_EMAX0         13
#define VTSS_9600_4S_DROP_EMAX1         14
#define VTSS_9600_4S_DROP_EMAX2         15
#define VTSS_9600_4S_DROP_EMAX3         16
#define VTSS_9600_4S_DROP_IMIN          0
#define VTSS_9600_4S_DROP_IDISC         32
#define VTSS_9600_4S_DROP_ZEROPAUSE     0
#define VTSS_9600_4S_DROP_PAUSEVALUE    0 /*Don't care*/

#define VTSS_9600_4W_DROP_EARLY_TX      2 /* Only for 1G. '0' for 10/100 */
#define VTSS_9600_4W_DROP_FWDP_START    37
#define VTSS_9600_4W_DROP_FWDP_STOP     39
#define VTSS_9600_4W_DROP_IMIN          4
#define VTSS_9600_4W_DROP_IDISC         32
#define VTSS_9600_4W_DROP_EMIN          4
#define VTSS_9600_4W_DROP_EMAX0         16
#define VTSS_9600_4W_DROP_EMAX1         16
#define VTSS_9600_4W_DROP_EMAX2         16
#define VTSS_9600_4W_DROP_EMAX3         16
#define VTSS_9600_4W_DROP_ZEROPAUSE     0
#define VTSS_9600_4W_DROP_PAUSEVALUE    0 /*Don't care*/
#endif /* VTSS_OPT_EARLY_TX */

/* Luton24FlowControl9600 */
#define VTSS_9600_4S_FC_EARLY_TX        0
#define VTSS_9600_4S_FC_FWDP_START      10
#define VTSS_9600_4S_FC_FWDP_STOP       6
#define VTSS_9600_4S_FC_IMIN            0
#define VTSS_9600_4S_FC_IDISC           36
#define VTSS_9600_4S_FC_EMIN            0
#define VTSS_9600_4S_FC_EMAX0           12
#define VTSS_9600_4S_FC_EMAX1           12
#define VTSS_9600_4S_FC_EMAX2           12
#define VTSS_9600_4S_FC_EMAX3           12
#define VTSS_9600_4S_FC_ZEROPAUSE       1
#define VTSS_9600_4S_FC_PAUSEVALUE      0xFF /*Don't care*/

/* Not used */
#define VTSS_9600_4W_FC_EARLY_TX        0
#define VTSS_9600_4W_FC_FWDP_START      10
#define VTSS_9600_4W_FC_FWDP_STOP       6
#define VTSS_9600_4W_FC_IMIN            4
#define VTSS_9600_4W_FC_IDISC           36
#define VTSS_9600_4W_FC_EMIN            4
#define VTSS_9600_4W_FC_EMAX0           12
#define VTSS_9600_4W_FC_EMAX1           12
#define VTSS_9600_4W_FC_EMAX2           12
#define VTSS_9600_4W_FC_EMAX3           12
#define VTSS_9600_4W_FC_ZEROPAUSE       1
#define VTSS_9600_4W_FC_PAUSEVALUE      0xFF /*Don't care*/

#endif /* SPARX_G16/SPARX_G24 */

#if defined(SPARX_II_16) || defined(SPARX_II_24) || defined(E_STAX_26) || defined(E_STAX_34)
/* SparX-28 queue system settings */

/* VTSS_<maxsize>_<prios><strict/weighted priority>_<drop/flowcontrol mode>_<register> */
/* define   ::= VTSS_(NORM|9600)_(1|2|4)(S|W)_(DROP|FC)_<register> */
/* register ::= EARLY_TX | FWDP_(START|STOP) | IMIN | IDISC | EMIN | EMAX(0-3) | ZEROPAUSE | PAUSEVALUE */

/* level:    Memory usage in slices */
/* wmaction: 0 = Drop from head, 1 = Drop during reception, 2 = Urgent, 3 = FC */
/* cmpwith:  0 = Total, 1 = Ingress, 2 = Spec, 3 = Egress */
/* qmask:    Which queues to apply, 1=q0, 2=q1, 4=q2, 8=q3, 16=CPU  */
/* chkmin:   Check IMIN WM */
/* lowonly:  Apply only to lowest prio queue with data. */

/* Luton28 strict priority, drop mode */
#define VTSS_NORM_4S_DROP_LEVEL_0    19
#define VTSS_NORM_4S_POLICER_LEVEL_0 12   /* Used if policer enabled */
#define VTSS_NORM_4S_DROP_ACTION_0   2
#define VTSS_NORM_4S_DROP_CMPWITH_0  0
#define VTSS_NORM_4S_DROP_QMASK_0    0x1F
#define VTSS_NORM_4S_DROP_CHKMIN_0   1
#define VTSS_NORM_4S_DROP_LOWONLY_0  0

#define VTSS_NORM_4S_DROP_LEVEL_1    0
#define VTSS_NORM_4S_DROP_ACTION_1   2
#define VTSS_NORM_4S_DROP_CMPWITH_1  2
#define VTSS_NORM_4S_DROP_QMASK_1    0x01
#define VTSS_NORM_4S_DROP_CHKMIN_1   0
#define VTSS_NORM_4S_DROP_LOWONLY_1  0

#define VTSS_NORM_4S_DROP_LEVEL_2    0
#define VTSS_NORM_4S_DROP_ACTION_2   2
#define VTSS_NORM_4S_DROP_CMPWITH_2  2
#define VTSS_NORM_4S_DROP_QMASK_2    0x03
#define VTSS_NORM_4S_DROP_CHKMIN_2   0
#define VTSS_NORM_4S_DROP_LOWONLY_2  0

#define VTSS_NORM_4S_DROP_LEVEL_3    0
#define VTSS_NORM_4S_DROP_ACTION_3   2
#define VTSS_NORM_4S_DROP_CMPWITH_3  2
#define VTSS_NORM_4S_DROP_QMASK_3    0x07
#define VTSS_NORM_4S_DROP_CHKMIN_3   0
#define VTSS_NORM_4S_DROP_LOWONLY_3  0

#define VTSS_NORM_4S_DROP_LEVEL_4    1
#define VTSS_NORM_4S_DROP_ACTION_4   2
#define VTSS_NORM_4S_DROP_CMPWITH_4  2
#define VTSS_NORM_4S_DROP_QMASK_4    0x7
#define VTSS_NORM_4S_DROP_CHKMIN_4   0
#define VTSS_NORM_4S_DROP_LOWONLY_4  0

#define VTSS_NORM_4S_DROP_LEVEL_5    21
#define VTSS_NORM_4S_POLICER_LEVEL_5 14   /* Used if policer enabled */
#define VTSS_NORM_4S_DROP_ACTION_5   1
#define VTSS_NORM_4S_DROP_CMPWITH_5  1
#define VTSS_NORM_4S_DROP_QMASK_5    0xf
#define VTSS_NORM_4S_DROP_CHKMIN_5   1
#define VTSS_NORM_4S_DROP_LOWONLY_5  0

#define VTSS_NORM_4S_DROP_IMIN          0
#define VTSS_NORM_4S_DROP_EARLY_TX      0
#define VTSS_NORM_4S_DROP_EMIN          3
#define VTSS_NORM_4S_DROP_EMAX0         14
#define VTSS_NORM_4S_DROP_EMAX1         14
#define VTSS_NORM_4S_DROP_EMAX2         14
#define VTSS_NORM_4S_DROP_EMAX3         14
#define VTSS_NORM_4S_DROP_ZEROPAUSE     0
#define VTSS_NORM_4S_DROP_PAUSEVALUE    0 /*Don't care*/


/* Luton28 weighted priority, drop mode */
#define VTSS_NORM_4W_DROP_LEVEL_0    17
#define VTSS_NORM_4W_POLICER_LEVEL_0 12   /* Used if policer enabled */
#define VTSS_NORM_4W_DROP_ACTION_0   2
#define VTSS_NORM_4W_DROP_CMPWITH_0  0
#define VTSS_NORM_4W_DROP_QMASK_0    0x1F
#define VTSS_NORM_4W_DROP_CHKMIN_0   1
#define VTSS_NORM_4W_DROP_LOWONLY_0  0

#define VTSS_NORM_4W_DROP_LEVEL_1    14
#define VTSS_NORM_4W_DROP_ACTION_1   1
#define VTSS_NORM_4W_DROP_CMPWITH_1  1
#define VTSS_NORM_4W_DROP_QMASK_1    0x1F
#define VTSS_NORM_4W_DROP_CHKMIN_1   0
#define VTSS_NORM_4W_DROP_LOWONLY_1  0

#define VTSS_NORM_4W_DROP_LEVEL_2    31
#define VTSS_NORM_4W_DROP_ACTION_2   0
#define VTSS_NORM_4W_DROP_CMPWITH_2  0
#define VTSS_NORM_4W_DROP_QMASK_2    0
#define VTSS_NORM_4W_DROP_CHKMIN_2   0
#define VTSS_NORM_4W_DROP_LOWONLY_2  0

#define VTSS_NORM_4W_DROP_LEVEL_3    31
#define VTSS_NORM_4W_DROP_ACTION_3   0
#define VTSS_NORM_4W_DROP_CMPWITH_3  0
#define VTSS_NORM_4W_DROP_QMASK_3    0
#define VTSS_NORM_4W_DROP_CHKMIN_3   0
#define VTSS_NORM_4W_DROP_LOWONLY_3  0

#define VTSS_NORM_4W_DROP_LEVEL_4    31
#define VTSS_NORM_4W_DROP_ACTION_4   0
#define VTSS_NORM_4W_DROP_CMPWITH_4  0
#define VTSS_NORM_4W_DROP_QMASK_4    0
#define VTSS_NORM_4W_DROP_CHKMIN_4   0
#define VTSS_NORM_4W_DROP_LOWONLY_4  0

#define VTSS_NORM_4W_DROP_LEVEL_5    31
#define VTSS_NORM_4W_POLICER_LEVEL_5 14   /* Used if policer enabled */
#define VTSS_NORM_4W_DROP_ACTION_5   1
#define VTSS_NORM_4W_DROP_CMPWITH_5  1
#define VTSS_NORM_4W_DROP_QMASK_5    0xf
#define VTSS_NORM_4W_DROP_CHKMIN_5   1
#define VTSS_NORM_4W_DROP_LOWONLY_5  0

#define VTSS_NORM_4W_DROP_IMIN          0
#define VTSS_NORM_4W_DROP_EARLY_TX      0
#define VTSS_NORM_4W_DROP_EMIN          3
#define VTSS_NORM_4W_DROP_EMAX0         14
#define VTSS_NORM_4W_DROP_EMAX1         14
#define VTSS_NORM_4W_DROP_EMAX2         14
#define VTSS_NORM_4W_DROP_EMAX3         14
#define VTSS_NORM_4W_DROP_ZEROPAUSE     0
#define VTSS_NORM_4W_DROP_PAUSEVALUE    0 /*Don't care*/

/* Luton28 flow control mode */
/* Note! */
/* 2.5GB Stack ports need modified WM: */
/* #define VTSS_NORM_4S_FC_LEVEL_2    4 */


/* Luton28 flow control mode */
#define VTSS_NORM_4S_FC_LEVEL_0    31
#define VTSS_NORM_4S_FC_ACTION_0   0
#define VTSS_NORM_4S_FC_CMPWITH_0  1
#define VTSS_NORM_4S_FC_QMASK_0    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_0   1
#define VTSS_NORM_4S_FC_LOWONLY_0  1

#define VTSS_NORM_4S_FC_LEVEL_1    15
#define VTSS_NORM_4S_FC_ACTION_1   2
#define VTSS_NORM_4S_FC_CMPWITH_1  1
#define VTSS_NORM_4S_FC_QMASK_1    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_1   1
#define VTSS_NORM_4S_FC_LOWONLY_1  1

#define VTSS_NORM_4S_FC_LEVEL_2    6
#define VTSS_NORM_4S_FC_ACTION_2   3
#define VTSS_NORM_4S_FC_CMPWITH_2  1
#define VTSS_NORM_4S_FC_QMASK_2    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_2   0
#define VTSS_NORM_4S_FC_LOWONLY_2  0		   

#define VTSS_NORM_4S_FC_LEVEL_3    4
#define VTSS_NORM_4S_FC_ACTION_3   3
#define VTSS_NORM_4S_FC_CMPWITH_3  1
#define VTSS_NORM_4S_FC_QMASK_3    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_3   0
#define VTSS_NORM_4S_FC_LOWONLY_3  0		   

#define VTSS_NORM_4S_FC_LEVEL_4    31
#define VTSS_NORM_4S_FC_ACTION_4   0
#define VTSS_NORM_4S_FC_CMPWITH_4  0
#define VTSS_NORM_4S_FC_QMASK_4    0
#define VTSS_NORM_4S_FC_CHKMIN_4   0
#define VTSS_NORM_4S_FC_LOWONLY_4  0		

#define VTSS_NORM_4S_FC_LEVEL_5    31
#define VTSS_NORM_4S_FC_ACTION_5   0
#define VTSS_NORM_4S_FC_CMPWITH_5  0
#define VTSS_NORM_4S_FC_QMASK_5    0
#define VTSS_NORM_4S_FC_CHKMIN_5   0
#define VTSS_NORM_4S_FC_LOWONLY_5  0		

#define VTSS_NORM_4S_FC_IMIN          0
#define VTSS_NORM_4S_FC_EARLY_TX      0		   
#define VTSS_NORM_4S_FC_EMIN          0
#define VTSS_NORM_4S_FC_EMAX0         6
#define VTSS_NORM_4S_FC_EMAX1         6
#define VTSS_NORM_4S_FC_EMAX2         6
#define VTSS_NORM_4S_FC_EMAX3         6
#define VTSS_NORM_4S_FC_ZEROPAUSE     1
#define VTSS_NORM_4S_FC_PAUSEVALUE    0xFF

/* Special settings for 10 Mbps half duplex operation */
#define VTSS_NORM_10_HDX_EMIN         0
#define VTSS_NORM_10_HDX_EMAX0        1
#define VTSS_NORM_10_HDX_EMAX1        1
#define VTSS_NORM_10_HDX_EMAX2        1
#define VTSS_NORM_10_HDX_EMAX3        1

#endif /* SPARX_II_16/SPARX_II_24/E_STAX_26/E_STAX_34 */

#if defined(G_ROCX)
/* G-RocX queue system settings */

/* VTSS_<maxsize>_<prios><strict/weighted priority>_<drop/flowcontrol mode>_<register> */
/* define   ::= VTSS_(NORM|9600)_(1|2|4)(S|W)_(DROP|FC)_<register> */
/* register ::= EARLY_TX | FWDP_(START|STOP) | IMIN | IDISC | EMIN | EMAX(0-3) | ZEROPAUSE | PAUSEVALUE */

/* level:    Memory usage in slices */
/* wmaction: 0 = Drop from head, 1 = Drop during reception, 2 = Urgent, 3 = FC */
/* cmpwith:  0 = Total, 1 = Ingress, 2 = Spec, 3 = Egress */
/* qmask:    Which queues to apply, 1=q0, 2=q1, 4=q2, 8=q3, 16=CPU  */
/* chkmin:   Check IMIN WM */
/* lowonly:  Apply only to lowest prio queue with data. */

/* G-RocX strict priority, drop mode */
#define VTSS_NORM_4S_DROP_LEVEL_0    19
#define VTSS_NORM_4S_POLICER_LEVEL_0 9   /* Used if policer enabled */
#define VTSS_NORM_4S_DROP_ACTION_0   2
#define VTSS_NORM_4S_DROP_CMPWITH_0  0
#define VTSS_NORM_4S_DROP_QMASK_0    0x1F
#define VTSS_NORM_4S_DROP_CHKMIN_0   1
#define VTSS_NORM_4S_DROP_LOWONLY_0  0

#define VTSS_NORM_4S_DROP_LEVEL_1    0
#define VTSS_NORM_4S_DROP_ACTION_1   2
#define VTSS_NORM_4S_DROP_CMPWITH_1  2
#define VTSS_NORM_4S_DROP_QMASK_1    0x01
#define VTSS_NORM_4S_DROP_CHKMIN_1   0
#define VTSS_NORM_4S_DROP_LOWONLY_1  0

#define VTSS_NORM_4S_DROP_LEVEL_2    0
#define VTSS_NORM_4S_DROP_ACTION_2   2
#define VTSS_NORM_4S_DROP_CMPWITH_2  2
#define VTSS_NORM_4S_DROP_QMASK_2    0x03
#define VTSS_NORM_4S_DROP_CHKMIN_2   0
#define VTSS_NORM_4S_DROP_LOWONLY_2  0

#define VTSS_NORM_4S_DROP_LEVEL_3    0
#define VTSS_NORM_4S_DROP_ACTION_3   2
#define VTSS_NORM_4S_DROP_CMPWITH_3  2
#define VTSS_NORM_4S_DROP_QMASK_3    0x07
#define VTSS_NORM_4S_DROP_CHKMIN_3   0
#define VTSS_NORM_4S_DROP_LOWONLY_3  0

#define VTSS_NORM_4S_DROP_LEVEL_4    0
#define VTSS_NORM_4S_DROP_ACTION_4   2
#define VTSS_NORM_4S_DROP_CMPWITH_4  2
#define VTSS_NORM_4S_DROP_QMASK_4    0x7
#define VTSS_NORM_4S_DROP_CHKMIN_4   0
#define VTSS_NORM_4S_DROP_LOWONLY_4  0

#define VTSS_NORM_4S_DROP_LEVEL_5    21
#define VTSS_NORM_4S_POLICER_LEVEL_5 11   /* Used if policer enabled */
#define VTSS_NORM_4S_DROP_ACTION_5   1
#define VTSS_NORM_4S_DROP_CMPWITH_5  1
#define VTSS_NORM_4S_DROP_QMASK_5    0xf
#define VTSS_NORM_4S_DROP_CHKMIN_5   1
#define VTSS_NORM_4S_DROP_LOWONLY_5  0

#define VTSS_NORM_4S_DROP_IMIN          0
#define VTSS_NORM_4S_DROP_EARLY_TX      0
#define VTSS_NORM_4S_DROP_EMIN          3
#define VTSS_NORM_4S_DROP_EMAX0         14
#define VTSS_NORM_4S_DROP_EMAX1         14
#define VTSS_NORM_4S_DROP_EMAX2         14
#define VTSS_NORM_4S_DROP_EMAX3         14
#define VTSS_NORM_4S_DROP_ZEROPAUSE     0
#define VTSS_NORM_4S_DROP_PAUSEVALUE    0 /*Don't care*/


/* G-RocX weighted priority, drop mode */
#define VTSS_NORM_4W_DROP_LEVEL_0    17
#define VTSS_NORM_4W_POLICER_LEVEL_0 9   /* Used if policer enabled */
#define VTSS_NORM_4W_DROP_ACTION_0   2
#define VTSS_NORM_4W_DROP_CMPWITH_0  0
#define VTSS_NORM_4W_DROP_QMASK_0    0x1F
#define VTSS_NORM_4W_DROP_CHKMIN_0   1
#define VTSS_NORM_4W_DROP_LOWONLY_0  0

#define VTSS_NORM_4W_DROP_LEVEL_1    31
#define VTSS_NORM_4W_DROP_ACTION_1   0
#define VTSS_NORM_4W_DROP_CMPWITH_1  0
#define VTSS_NORM_4W_DROP_QMASK_1    0
#define VTSS_NORM_4W_DROP_CHKMIN_1   0
#define VTSS_NORM_4W_DROP_LOWONLY_1  0

#define VTSS_NORM_4W_DROP_LEVEL_2    31
#define VTSS_NORM_4W_DROP_ACTION_2   0
#define VTSS_NORM_4W_DROP_CMPWITH_2  0
#define VTSS_NORM_4W_DROP_QMASK_2    0
#define VTSS_NORM_4W_DROP_CHKMIN_2   0
#define VTSS_NORM_4W_DROP_LOWONLY_2  0

#define VTSS_NORM_4W_DROP_LEVEL_3    31
#define VTSS_NORM_4W_DROP_ACTION_3   0
#define VTSS_NORM_4W_DROP_CMPWITH_3  0
#define VTSS_NORM_4W_DROP_QMASK_3    0
#define VTSS_NORM_4W_DROP_CHKMIN_3   0
#define VTSS_NORM_4W_DROP_LOWONLY_3  0

#define VTSS_NORM_4W_DROP_LEVEL_4    31
#define VTSS_NORM_4W_DROP_ACTION_4   0
#define VTSS_NORM_4W_DROP_CMPWITH_4  0
#define VTSS_NORM_4W_DROP_QMASK_4    0
#define VTSS_NORM_4W_DROP_CHKMIN_4   0
#define VTSS_NORM_4W_DROP_LOWONLY_4  0

#define VTSS_NORM_4W_DROP_LEVEL_5    31
#define VTSS_NORM_4W_POLICER_LEVEL_5 11   /* Used if policer enabled */
#define VTSS_NORM_4W_DROP_ACTION_5   1
#define VTSS_NORM_4W_DROP_CMPWITH_5  1
#define VTSS_NORM_4W_DROP_QMASK_5    0xf
#define VTSS_NORM_4W_DROP_CHKMIN_5   1
#define VTSS_NORM_4W_DROP_LOWONLY_5  0

#define VTSS_NORM_4W_DROP_IMIN          0
#define VTSS_NORM_4W_DROP_EARLY_TX      0
#define VTSS_NORM_4W_DROP_EMIN          3
#define VTSS_NORM_4W_DROP_EMAX0         14
#define VTSS_NORM_4W_DROP_EMAX1         14
#define VTSS_NORM_4W_DROP_EMAX2         14
#define VTSS_NORM_4W_DROP_EMAX3         14
#define VTSS_NORM_4W_DROP_ZEROPAUSE     0
#define VTSS_NORM_4W_DROP_PAUSEVALUE    0 /*Don't care*/

/* G-RocX flow control mode */
/* Note! */
/* 2.5GB Stack ports need modified WM: */
/* #define VTSS_NORM_4S_FC_LEVEL_2    4 */


/* G-RocX flow control mode */
#define VTSS_NORM_4S_FC_LEVEL_0    31
#define VTSS_NORM_4S_FC_ACTION_0   0
#define VTSS_NORM_4S_FC_CMPWITH_0  1
#define VTSS_NORM_4S_FC_QMASK_0    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_0   1
#define VTSS_NORM_4S_FC_LOWONLY_0  1

#define VTSS_NORM_4S_FC_LEVEL_1    15
#define VTSS_NORM_4S_FC_ACTION_1   2
#define VTSS_NORM_4S_FC_CMPWITH_1  1
#define VTSS_NORM_4S_FC_QMASK_1    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_1   1
#define VTSS_NORM_4S_FC_LOWONLY_1  1

#define VTSS_NORM_4S_FC_LEVEL_2    6
#define VTSS_NORM_4S_FC_ACTION_2   3
#define VTSS_NORM_4S_FC_CMPWITH_2  1
#define VTSS_NORM_4S_FC_QMASK_2    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_2   0
#define VTSS_NORM_4S_FC_LOWONLY_2  0		   

#define VTSS_NORM_4S_FC_LEVEL_3    4
#define VTSS_NORM_4S_FC_ACTION_3   3
#define VTSS_NORM_4S_FC_CMPWITH_3  1
#define VTSS_NORM_4S_FC_QMASK_3    0x1F
#define VTSS_NORM_4S_FC_CHKMIN_3   0
#define VTSS_NORM_4S_FC_LOWONLY_3  0		   

#define VTSS_NORM_4S_FC_LEVEL_4    31
#define VTSS_NORM_4S_FC_ACTION_4   0
#define VTSS_NORM_4S_FC_CMPWITH_4  0
#define VTSS_NORM_4S_FC_QMASK_4    0
#define VTSS_NORM_4S_FC_CHKMIN_4   0
#define VTSS_NORM_4S_FC_LOWONLY_4  0		

#define VTSS_NORM_4S_FC_LEVEL_5    31
#define VTSS_NORM_4S_FC_ACTION_5   0
#define VTSS_NORM_4S_FC_CMPWITH_5  0
#define VTSS_NORM_4S_FC_QMASK_5    0
#define VTSS_NORM_4S_FC_CHKMIN_5   0
#define VTSS_NORM_4S_FC_LOWONLY_5  0		

#define VTSS_NORM_4S_FC_IMIN          0
#define VTSS_NORM_4S_FC_EARLY_TX      0		   
#define VTSS_NORM_4S_FC_EMIN          0
#define VTSS_NORM_4S_FC_EMAX0         6
#define VTSS_NORM_4S_FC_EMAX1         6
#define VTSS_NORM_4S_FC_EMAX2         6
#define VTSS_NORM_4S_FC_EMAX3         6
#define VTSS_NORM_4S_FC_ZEROPAUSE     1
#define VTSS_NORM_4S_FC_PAUSEVALUE    0xFF

#endif /* G_ROCX */
