/****************************************************************************
 * l2-switch-g5.c :     l2 switch interface layer of Pizza Box
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         R0.01
 * Author         :         Jian Zhu
 * Date           :         2007-2
 * Reason         :         First Create
 ****************************************************************************/
#include "vtss_switch_api.h"
#include "vtss_state.h"
#include "vtss_phy_veriphy.h"
#include "l2-switch-g5.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>


#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>  
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <errno.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <string.h>


//volatile ulong *pci_baseaddr;
//vtss_state_t *chip1_api_state;

extern vtss_rc vtss_ll_init(const vtss_init_setup_t *setup);

#define CTC_HW_DEV_NAME     "/dev/ctc_hw"

/*
void swap(ulong *value)
{
    ulong tmp;
	uint mask1 = 0xff;
	uint mask2 = 0xff000000;
	uint mask3 = 0x00ff0000;
	uint mask4 = 0x0000ff00;
	ulong result = 0;
	tmp = *value;
	result = ((tmp >> 24)&mask1)|((tmp << 24)&mask2)|((tmp << 8)&mask3)|((tmp >> 8)&mask4);
	*value = result;
}
*/
static vtss_port_interface_t port_mac_interface(vtss_port_no_t port_no) 
{
#if defined(VTSS_FEATURE_10G)
    /* 10G ports */
    if (vtss_port_no_is_10g(port_no)) {
        return VTSS_PORT_INTERFACE_XGMII;
    }
#endif /* VTSS_FEATURE_10G */
    
#if defined(VTSS_FEATURE_VAUI)
    if (port_vaui(port_no))
        return VTSS_PORT_INTERFACE_VAUI;
    else
        return VTSS_PORT_INTERFACE_SGMII;
#endif /* VTSS_FEATURE_VAUI */

#if defined(SPARX_G24)
    return (port_no < 9 || port_no > 16 ? VTSS_PORT_INTERFACE_SGMII : 
            VTSS_PORT_INTERFACE_INTERNAL);
#endif /* SPARX_G24 */

#if defined(SPARX_G16)
    return (port_no < 9 ? VTSS_PORT_INTERFACE_SGMII : VTSS_PORT_INTERFACE_INTERNAL);
#endif /* SPARX_G16 */

#if defined(SPARX_G8)
    return VTSS_PORT_INTERFACE_INTERNAL;
#endif /* SPARX_G8 */

#if defined(SPARX_G5)
    return (port_no < 6 ? VTSS_PORT_INTERFACE_INTERNAL : VTSS_PORT_INTERFACE_RGMII);
#endif /* SPARX_G5 */

#if defined(VTSS_ARCH_HAWX)
    return VTSS_PORT_INTERFACE_SGMII;
#else
    return VTSS_PORT_INTERFACE_RGMII;
#endif
}

int vtss_port_check_link(uint8_t port)
{
    vtss_port_no_t port_no;
    vtss_port_status_t status;

    port_no  = (vtss_port_no_t) (port);
    
    /* Get current status */
    memset(&status, 0, sizeof(status));
    vtss_port_status_get(port_no, &status);
    
    return status.link;
}

void vtss_enable_port(uint8_t port)
{

    vtss_port_no_t port_no;
    vtss_phy_setup_t setup;
	vtss_phy_reset_setup_t reset;
	
    port_no  = (vtss_port_no_t) (port);
	reset.mac_if = port_mac_interface(port_no);
	/* Media interface: Copper by default */
	reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;
	
	vtss_phy_reset(port_no, &reset);
	
	/* Setup PHY for fix speed */
	setup.mode = VTSS_PHY_MODE_FORCED;
	setup.forced.speed = VTSS_SPEED_100M;
	setup.forced.fdx = 1;

    vtss_phy_setup(port_no, &setup);

}

void vtss_disable_port(uint8_t port)
{

    vtss_port_no_t port_no;
    vtss_phy_setup_t setup;
    
    port_no  = (vtss_port_no_t) (port);
    setup.mode = VTSS_PHY_MODE_POWER_DOWN;
    vtss_phy_setup(port_no, &setup);
}

void vtss_port_get_stats(uint8_t port, port_stats_t *stats)
{

    vtss_poag_no_t poag_no;    
    vtss_poag_counters_t big_counters;

    poag_no = (vtss_poag_no_t)(port);
    vtss_poag_counters_get(poag_no, &big_counters);
    stats->rx_bytes = big_counters.rmon.rx_etherStatsOctets;
    stats->rx_dropped = big_counters.rmon.rx_etherStatsDropEvents;
    stats->rx_errors = big_counters.if_group.ifInErrors;
    stats->rx_packets = big_counters.rmon.rx_etherStatsPkts;
    stats->tx_bytes = big_counters.rmon.tx_etherStatsOctets;
    stats->tx_dropped = big_counters.rmon.tx_etherStatsDropEvents;
    stats->tx_errors = big_counters.if_group.ifOutErrors;
    stats->tx_packets = big_counters.rmon.tx_etherStatsPkts;

}

/*port 0-2*/
int vtss_en_phy_loopback(uint8_t port)
{
    int ret;
	ushort x;
	ushort mask;
	ret = vtss_phy_read(port, 0x00, &x);
	if (ret<0)
		return ret;
	mask = (0x1<<14);
    x = x|mask;
	ret = vtss_phy_write(port, 0x00, x);

	return ret;
}

/*port 0-2*/
int vtss_en_phy_far_end_loopback(uint8_t port)
{
    int ret;
	ushort x;
	ushort mask;
	ret = vtss_phy_read(port, 0x17, &x);
	if (ret<0)
		return ret;
	mask = (0x1<<3);
	x = x|mask;
	ret = vtss_phy_write(port, 0x17, x);

	return ret;
}

int vtss_dis_phy_loopback(uint8_t port)
{

    int ret;
	ushort x;
	ushort mask;
	ret = vtss_phy_read(port, 0x00, &x);
	if (ret<0)
		return ret;
	mask = (0x1<<14);
	x = x&(~mask);
	ret = vtss_phy_write(port, 0x00, x);

	return ret;
}

int vtss_dis_phy_far_end_loopback(uint8_t port)
{
    int ret;
	ushort x;
	ushort mask;
	ret = vtss_phy_read(port, 0x17, &x);
	if (ret<0)
		return ret;
	mask = (0x1<<3);
	x = x & (~mask);
	ret = vtss_phy_write(port, 0x17, x);

	return ret;
}

/****************************************************************************/
/*                                                                          */
/*  End of file.                                                            */
/*                                                                          */
/****************************************************************************/

