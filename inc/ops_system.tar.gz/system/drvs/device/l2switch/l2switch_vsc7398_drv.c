/****************************************************************************
 * l2switch_vsc7398.c  
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2010-08-19.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#define SPARX_G8
#define VTSS_MEMORYMAPPEDIO

#include "ctc_spi.h"
#include "l2switch_api.h"
#include "l2switch_drv.h"
#include "vtss_switch_api.h"
#include "vtss_phy.h"
#include "l2-switch-g5.h"
#include "vsc7398.h"
#include "l2switch_vsc7398_drv.h"
#include "drv_debug.h"
#include "l2switch_err.h"



/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

    
/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/


/****************************************************************************
 *
* Functions  
*
****************************************************************************/        
static int32 _vsc7398_port_with_phy(vtss_mapped_port_t * map, uint32 port_no)
{
    return map[port_no].miim_controller != VTSS_MIIM_CONTROLLER_NONE;
}


BOOL vsc7398_get_port_down(vtss7398_switch_data_t* vtss_data, vtss_port_no_t port_no) 
{
    if (port_no >= VTSS_PORT_NO_END)
    {
        return FALSE;
    }
    
    return vtss_data->port.p_port_down[port_no];

}

vtss_port_interface_t vsc7398_get_port_mac_speed(vtss7398_switch_data_t* vtss_data, vtss_port_no_t port_no) 
{
    vtss_speed_t *p_port_speed = NULL;
    
    p_port_speed = vtss_data->port.p_port_speed;
    if(p_port_speed != NULL)
        return p_port_speed[port_no];
    else
        return VTSS_SPEED_100M;
}

vtss_port_interface_t vsc7398_port_mac_interface(vtss7398_switch_data_t* vtss_data, vtss_port_no_t port_no) 
{
    vtss_port_interface_t *p_port_intf = NULL;

    p_port_intf =vtss_data->port.p_port_intf;
    if(p_port_intf != NULL)
        return p_port_intf[port_no];
    else
        return VTSS_PORT_INTERFACE_NO_CONNECTION;
}

int32 
vsc7398_allocMem(switch_handle_t* switch_dev,spi_handle_t *spi_phdl)
{
    vtss_state_t *api_state;
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info; 
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_allocMem start!");
    L2SWITCH_DEV_PTR_CHECK(switch_dev);

    p_l2_switch_info = switch_dev->l2switch_info;
    
    /* Allocate API state memory */
    /* modified by kcao for bug 13571, 2010-11-22 : sizeof(vtss_state_info_t) > 128k, not support for DRV_MALLOC */
    if ((api_state = DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, sizeof(vtss_state_t)))==NULL ||
        (api_state->al = sal_malloc(vtss7398_sizeof_al()))==NULL) 
    {
        DRV_LOG_ERR("malloc api_state failed\n");
        return L2SWITCH_E_NO_MEMORY;
    }
    vtss_data = (vtss7398_switch_data_t*)p_l2_switch_info->data;
    vtss_data->vtss_api_state = api_state;

    /* Allocate PHY API state memory */
    if ((api_state->phy = DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, sizeof(vtss_phy_state_t)))==NULL ||
        (((vtss_phy_state_t*)(api_state->phy))->al = 
        DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, vtss7398_phy_sizeof_al(VTSS_PORTS)))==NULL) 
    {
        DRV_LOG_ERR("malloc phy_api_state failed\n");
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO,api_state->al);
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO,api_state);
        return L2SWITCH_E_NO_MEMORY;
    }
 
    api_state->io.spi_handle = (void *)spi_phdl;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_allocMem end!");
    return L2SWITCH_SUCCESS;    
}

int32 
vsc7398_initChip(switch_handle_t* switch_handle)
{
    vtss7398_switch_data_t* vtss_data;    
    l2switch_info_t *p_l2_switch_info;  
    vtss_chipid_t chipid;
    vtss_mapped_port_t *p_map_port = NULL;
    int32 ret;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_initChip start!");
    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t*)p_l2_switch_info->data;

    if ((vtss_data == NULL) || (vtss_data->vtss_api_state == NULL) || 
        (vtss_data->port_map == NULL) || (vtss_data->port.p_port_down == NULL))
    {
        DRV_LOG_ERR("VSC7398 vtss_data null pointer error!\n");
        return L2SWITCH_E_ERROR;
    }    
    
    vtss7398_select_chip(vtss_data->vtss_api_state);
    
    /* Reset chip and use serial interface */    
    vtss_init_setup_t setup;
    setup.reset_chip = 1;
    setup.use_cpu_si = 1;
    vtss7398_init(&setup);
    
    /* Read chip ID */
    if (vtss7398_chipid_get(&chipid)<0) {
        DRV_LOG_ERR("vtss7398 chip id get failed\n");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vtss7398 chip id get failed!");
        VTSS_E(("vtss_chipid_get failed"));
    } else {
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "chip id get success,part_number: 0x%04x, revision: %d\n",
                                                                                 chipid.part_number, chipid.revision);
        VTSS_D(("part_number: 0x%04x, revision: %d",
                chipid.part_number, chipid.revision));
    }

    /*port map set*/
    p_map_port = vtss_data->port_map ;
    
    vtss7398_port_map_set(p_map_port);
    
    /*force speed and duplex for debug */
    {
        vtss_port_no_t    port_no;
    
        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        {
            if (_vsc7398_port_with_phy(p_map_port, port_no) ) 
            {
                vtss_phy_reset_setup_t reset;
                vtss_phy_setup_t       setup;
                
                /* 1G port, reset PHY and start auto negotiation */
                reset.mac_if = vsc7398_port_mac_interface(vtss_data, port_no);
                /* Media interface: Copper by default */
                reset.media_if = VTSS_PHY_MEDIA_INTERFACE_COPPER;

                vtss7398_phy_reset(port_no, &reset);

                /* Setup PHY for fix speed */

                setup.mode = VTSS_PHY_MODE_FORCED;
                setup.forced.speed = vsc7398_get_port_mac_speed(vtss_data, port_no);
                setup.forced.fdx = 1;
                
                ret = vtss7398_phy_setup(port_no, &setup);
                if(ret < 0)
                {
                    DRV_LOG_ERR("ERROR vtss_phy_setup\n");
                    return ret;
                }
            }
        }
    }
   
    {
        vtss_port_no_t port_no;

        for (port_no = VTSS_PORT_NO_START; port_no < VTSS_PORT_NO_END; port_no++)
        {
            vtss_port_setup_t setup;

            vtss7398_port_stp_state_set(port_no, VTSS_STP_STATE_ENABLED);

            sal_memset(&setup, 0, sizeof(setup));
            setup.interface_mode.interface_type = vsc7398_port_mac_interface(vtss_data, port_no);
            setup.interface_mode.speed = vsc7398_get_port_mac_speed(vtss_data, port_no);
            setup.powerdown = vsc7398_get_port_down(vtss_data, port_no);
            setup.fdx = 1;
            setup.flowcontrol.obey = 0;
            setup.flowcontrol.generate = 0;
            setup.flowcontrol.smac.addr[5] = port_no;
            setup.maxframelength = VTSS_MAXFRAMELENGTH_MAX;
            setup.frame_gaps.hdx_gap_1 = VTSS_FRAME_GAP_DEFAULT;
            setup.frame_gaps.hdx_gap_2 = VTSS_FRAME_GAP_DEFAULT;
            setup.frame_gaps.fdx_gap = VTSS_FRAME_GAP_DEFAULT;
            setup.port_enable = setup.powerdown ? FALSE : TRUE;
            vtss7398_port_setup(port_no, &setup);
            ret = vtss7398_poag_counters_clear(port_no);            
        } /* Port loop */
    }
    
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_initChip end!");
    return L2SWITCH_SUCCESS;
}


/*used when system running, could be called many times*/
int32 
vsc7398_runningInit(switch_handle_t* switch_handle)
{
    return vsc7398_initChip(switch_handle);
}

int32 
vsc7398_switch_init(switch_handle_t* switch_handle,spi_handle_t *spi_phdl)
{   
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_switch_init start!");
    vsc7398_allocMem(switch_handle,spi_phdl);
    vsc7398_runningInit(switch_handle);

    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_switch_init fixup start!");
    if(switch_handle->l2switch_fixup != NULL)
    {
       DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_switch_init fixup !");    
       switch_handle->l2switch_fixup(); 
    }
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_switch_init fixup end!");
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "vsc7398_switch_init end!");
    return L2SWITCH_SUCCESS;
}


int32
vsc7398_get_counter(switch_handle_t* switch_handle, uint8 chip_port, l2switch_port_stats_t *counter)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    vtss_poag_no_t poag_no;    
    vtss_poag_counters_t big_counters;
    
    L2SWITCH_DEV_PTR_CHECK(switch_handle);

    p_l2_switch_info = switch_handle->l2switch_info;

    poag_no = chip_port ;
    sal_memset(&big_counters,0,sizeof(vtss_poag_counters_t));
    vtss_data = p_l2_switch_info->data;
    vtss7398_select_chip(vtss_data->vtss_api_state);
    vtss7398_poag_counters_get(poag_no, &big_counters);

    counter->rx_bytes = big_counters.rmon.rx_etherStatsOctets;
    counter->rx_dropped = big_counters.rmon.rx_etherStatsDropEvents;
    counter->rx_errors = big_counters.if_group.ifInErrors;
    counter->rx_packets = big_counters.rmon.rx_etherStatsPkts;
    counter->tx_bytes = big_counters.rmon.tx_etherStatsOctets;
    counter->tx_dropped = big_counters.rmon.tx_etherStatsDropEvents;
    counter->tx_errors = big_counters.if_group.ifOutErrors;
    counter->tx_packets = big_counters.rmon.tx_etherStatsPkts;
    
    return L2SWITCH_SUCCESS;
}




int32
vsc7398_clear_counter(switch_handle_t* switch_handle, uint8 chip_port)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    vtss7398_poag_counters_clear(chip_port );
    return L2SWITCH_SUCCESS;
}



int32
vsc7398_enable_port(switch_handle_t* switch_handle, uint8 chip_port, uint8 enable)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    
    /* Modified by kcao 2010-06-18 for bug 11772 : use vtss driver do enable/disable */
    return vtss7398_port_enable(chip_port , enable);
}




int32
vsc7398_reg_read(switch_handle_t* switch_handle, uint32 reg, uint32 *value)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc7398 register read: reg %x, value pointer %p", 
                                reg, value);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    return vtss7398_register_read(reg, (ulong*)value);
}



int32
vsc7398_reg_write(switch_handle_t* switch_handle, uint32 reg, const uint32 value)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc73985 register write: reg %x, value %x", 
                                reg, value);

    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    return vtss7398_register_write(reg, value);
}




int32 
vsc7398_phy_read(switch_handle_t* switch_handle, uint32 port, uint32 reg, uint16* value)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    
    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc7398 phy read: port %d, reg %x, value pointer %p", 
                                port, reg, value);
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    return vtss7398_phy_read(port, reg, value);
}

int32 
vsc7398_add_static_mac(switch_handle_t* switch_handle, uint8 port, uint8 * mac)
{
    uint32 dst_portid;    
    vtss_mac_table_entry_t entry;

    sal_memset(entry.destination, 0, sizeof(entry.destination));
    entry.copy_to_cpu = 0;
    entry.locked = 1;
    entry.aged = 0;    

    dst_portid = port;
    entry.vid_mac.vid = VTSS_VID_DEFAULT;
    entry.vid_mac.mac.addr[0] = mac[0];
    entry.vid_mac.mac.addr[1] = mac[1];
    entry.vid_mac.mac.addr[2] = mac[2];
    entry.vid_mac.mac.addr[3] = mac[3];
    entry.vid_mac.mac.addr[4] = mac[4];
    entry.vid_mac.mac.addr[5] = mac[5];
    entry.destination[dst_portid] = 1;


    vtss7398_mac_table_learn(&entry);
    return 0; 
}


int32 
vsc7398_phy_write(switch_handle_t* switch_handle, uint32 port, uint32 reg, const uint16 value)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "vsc7398 phy write:port %d, reg %x, value %x", 
                                port, reg, value);
    
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    return vtss7398_phy_write(port, reg, value);
}

#ifdef BOOTUP_DIAG
/*result: bit[30:30] 0-pass,1-fail; bit[29:28] chip id; bit[27:0] error port; */
int32 
vsc7398_self_diagnostic(switch_handle_t * switch_handle)
{
    vtss7398_switch_data_t* vtss_data;
    l2switch_info_t *p_l2_switch_info;
    vtss_chipid_t chipid;
    vtss_rc ret;
    int32 result=0;

    L2SWITCH_DEV_PTR_CHECK(switch_handle);
    p_l2_switch_info = switch_handle->l2switch_info;
    vtss_data = (vtss7398_switch_data_t* )(p_l2_switch_info->data);
    vtss7398_select_chip(vtss_data->vtss_api_state);
    ret = vtss7398_chipid_get(&chipid);
    if(ret != VTSS_OK)
        result = (1<<30);
    return result;
}
#endif

/****************************************************************************
 * Name	: register_vsc7398_l2switch_dev
 * Purpose: register VSC7398 l2switch device handler
 * Input	:  the pointer to l2switch infomation struct
 * Output:  
 * Return:  the handler of the L2switch
 * Note	:
****************************************************************************/	
switch_handle_t *
register_vsc7398_l2switch_dev(l2switch_info_t *l2switch_info, void (*l2switch_fixup)(void))
{
    switch_handle_t *p_switch_hdl;
    l2switch_info_t *p_l2switch_info;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "register_vsc7398_l2switch_dev start!");
    p_switch_hdl = (switch_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, 
                                          sizeof(switch_handle_t));
    if(NULL == p_switch_hdl)
    {
        DRV_LOG_ERR("switch handle malloc fail!\n");
        return NULL;
    }

    p_l2switch_info = (l2switch_info_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, 
                                          sizeof(l2switch_info_t));
    if(NULL == p_l2switch_info)
    {
        DRV_LOG_ERR("l2switch info malloc fail!\n");
        goto err_out1;
    }

    sal_memcpy((uint8 *)p_l2switch_info, (uint8 *)l2switch_info, 
                sizeof(l2switch_info_t));
    
    p_l2switch_info->data = DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, sizeof(vtss7398_switch_data_t));
    if(NULL == p_l2switch_info->data)
    {
        DRV_LOG_ERR("l2switch info data malloc fail!\n");
        goto err_out2;
    }

    sal_memcpy((uint8_t *)(p_l2switch_info->data), (uint8_t *)(l2switch_info->data), 
                sizeof(vtss7398_switch_data_t));
    
    p_switch_hdl->l2switch_info = p_l2switch_info;
    p_switch_hdl->switch_init = vsc7398_switch_init;
    p_switch_hdl->get_counter = vsc7398_get_counter;
    p_switch_hdl->clear_counter = vsc7398_clear_counter;
    p_switch_hdl->enable_port = vsc7398_enable_port;
    p_switch_hdl->reg_read = vsc7398_reg_read;
    p_switch_hdl->reg_write = vsc7398_reg_write;
    p_switch_hdl->phy_read = vsc7398_phy_read;
    p_switch_hdl->phy_write = vsc7398_phy_write;
#ifdef BOOTUP_DIAG    
    p_switch_hdl->self_diagnostic = vsc7398_self_diagnostic;
#endif
    p_switch_hdl->l2switch_fixup = l2switch_fixup;
    p_switch_hdl->add_static_mac = vsc7398_add_static_mac;
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "register_vsc7398_l2switch_dev end!");    
    return p_switch_hdl;
    
err_out2:
    if(NULL != p_l2switch_info)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO , p_l2switch_info);
        p_l2switch_info = NULL;
    }
err_out1:
    if (NULL != p_switch_hdl)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_L2SWITCH_INFO , p_switch_hdl);
        p_switch_hdl = NULL;
    }

    return NULL;
}


