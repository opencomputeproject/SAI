/****************************************************************************
 * api_l2switch.c    l2 switch dev init and access api
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2010-08-17.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/

#include "l2switch_drv.h"
#include "l2switch_api.h"
#include "drv_debug.h"
#include "l2switch_err.h"

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
#define API_GET_L2SWITCH_DRV(chip_id, p_switch_dev)  \
do{        \
    if(chip_id >= g_l2switch_max_nums) \
        return L2SWITCH_E_INVALID_CHIP; \
    p_switch_dev = g_l2switch_hdl[chip_id];   \
}while(0)
    
/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static switch_handle_t **g_l2switch_hdl = NULL;
 
static uint32_t g_l2switch_max_nums = 0; 

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
static int32
_l2switch_init_dev(uint8 l2switch_id)
{
    switch_handle_t* p_l2switch_dev = NULL;
    spi_handle_t *spi_phdl = NULL;

    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, switch_init);

    p_l2switch_dev->l2switch_info->spi_info.len = L2SWITCH_DATA_LENTH; 
    p_l2switch_dev->l2switch_info->spi_info.alen = L2SWITCH_ADDRESS_LENTH;
    spi_phdl = spi_create_handle((void *)(&(p_l2switch_dev->l2switch_info->spi_info)));
    if (NULL == spi_phdl)
    {
        DRV_LOG_ERR("_l2switch_init_dev spi_create_handle invalid.");
        return L2SWITCH_E_INVALID_PTR;
    } 
    
    return p_l2switch_dev->switch_init(p_l2switch_dev, spi_phdl);
}

/****************************************************************************
 * Name	: l2switch_get_port_num
 * Purpose: get l2switch port number
 * Input:   uint8 l2switch_id                          the index of l2switch
 
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/
int32 
l2switch_get_port_num(uint8 l2switch_id)
{
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;
      
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, reg_read);
    
    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    return max_port_nums;
}


/****************************************************************************
 * Name	: l2switch_port_get_stats
 * Purpose: get l2switch port counter
 * Input:  uint8 l2switch_id                          the index of l2switch
         uint8 port                                   the index of port
         l2switch_port_stats_t *counter               the pointer of counter struct
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/
int32 
l2switch_port_get_stats(uint8 l2switch_id, uint8 port_id, l2switch_port_stats_t *stats)
{
    switch_handle_t* p_l2switch_dev = NULL;
    uint32 max_port_nums;

    if (NULL == stats)
    {
        DRV_LOG_ERR("l2switch_port_get_stats stats null pointer!\n.");
        return L2SWITCH_E_INVALID_PTR;
    } 
       
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, get_counter);
    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    if((port_id + 1 ) > max_port_nums)
    {
        DRV_LOG_ERR("invalid port id!\n.");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "invalid port id!port index start from 0 to %d!\n.",
                        (max_port_nums - 1));
        return L2SWITCH_E_INVALID_PARAM;
    }
    p_l2switch_dev->get_counter(p_l2switch_dev, port_id + 1, stats);

    return L2SWITCH_SUCCESS;
}

/****************************************************************************
 * Name	: l2switch_clear_port_stat
 * Purpose: clear l2switch port counter 
 * Input:  uint8 l2switch_id                          the index of l2switch
         uint8 port_id                                   the index of port
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/
int32
l2switch_clear_port_stat(uint8 l2switch_id, uint8 port_id)
{	
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;

    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, clear_counter);

    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    if((port_id + 1 ) > max_port_nums)
    {
        DRV_LOG_ERR("invalid port id!\n.");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "invalid port id!port index start from 0 to %d!\n.",
                        (max_port_nums - 1));
        return L2SWITCH_E_INVALID_PARAM;
    }
    
    return p_l2switch_dev->clear_counter(p_l2switch_dev, port_id + 1);		
}

/****************************************************************************
 * Name	: l2switch_clear_allport_stat
 * Purpose: clear all port counter 
 * Input:  uint8 l2switch_id                          the index of l2switch
         
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/
int32
l2switch_clear_allport_stat(uint8 l2switch_id)
{	
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;
    uint8 port_id;
    int32 ret = 0;

    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, clear_counter);
    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    
    for(port_id = 1; port_id < max_port_nums; port_id++)
    {
        ret += p_l2switch_dev->clear_counter(p_l2switch_dev, port_id);     
    }

	return ret;
}

/****************************************************************************
 * Name	: l2switch_enable_port
 * Purpose: enable/disable l2switch port
 * Input:  uint8 l2switch_id                          the index of l2switch
         uint8 port                                   the index of port
         uint8 enable                                 enable/disable port flag
 * Output: N/A  
 * Return:  
 * Note	: N/A
****************************************************************************/
int32
l2switch_enable_port(uint8 l2switch_id, uint8 port_id, uint8 enable)
{
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, enable_port);

    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    if((port_id + 1 ) > max_port_nums)
    {
        DRV_LOG_ERR("invalid port id!\n.");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "invalid port id!port index start from 0 to %d!\n.",
                        (max_port_nums - 1));
        return L2SWITCH_E_INVALID_PARAM;
    }

    return p_l2switch_dev->enable_port(p_l2switch_dev, port_id + 1, enable);
}

/****************************************************************************
 * Name	: l2switch_phy_read
 * Purpose: read l2switch phy register
 * Input:  uint8 l2switch_id                          the index of l2switch
         uint32 local_portid                          the index of port
         uint32 address                               the address of l2switch phy register
         uint16 *value                                 the pointer of read value
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/	
int32 
l2switch_phy_read(uint8 l2switch_id, uint32 port_id, 
                                uint32 address, uint16 *value)
{
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;
    
    if (NULL == value)
    {
        DRV_LOG_ERR("l2switch_phy_read value null pointer!\n.");
        return L2SWITCH_E_INVALID_PTR;
    }   
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, phy_read);

    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    if((port_id + 1 ) > max_port_nums)
    {
        DRV_LOG_ERR("invalid port id!\n.");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "invalid port id!port index start from 0 to %d!\n.",
                        (max_port_nums - 1));
        return L2SWITCH_E_INVALID_PARAM;
    }

    return p_l2switch_dev->phy_read(p_l2switch_dev, port_id + 1, address, value);
}

/****************************************************************************
 * Name	: l2switch_phy_write
 * Purpose: write l2switch phy register
 * Input:  uint8 l2switch_id                          the index of l2switch
         uint32 local_portid                          the index of port
         uint32 address                               the address of l2switch phy register
         uint16 value                                 write value
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/	
int32 
l2switch_phy_write(uint8 l2switch_id, uint32 port_id, 
                                uint32 address, uint16 value)
{
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, phy_write);

    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    if((port_id + 1 ) > max_port_nums)
    {
        DRV_LOG_ERR("invalid port id!\n.");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "invalid port id!port index start from 0 to %d!\n.",
                        (max_port_nums - 1));
        return L2SWITCH_E_INVALID_PARAM;
    }
    
    return p_l2switch_dev->phy_write(p_l2switch_dev, port_id + 1, address, value);
}

/****************************************************************************
 * Name	: l2switch_register_read
 * Purpose: read l2switch  register
 * Input:   uint8 l2switch_id                         the index of l2switch
         uint32 regAddr                               the address of l2switch register
         uint32 *value                                the pointer of read value
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/	
/*regAddr:  bit15-12: block, bit11-8: subblock, bit7-0:regAddr*/
int32 
l2switch_register_read(uint8 l2switch_id, uint32 regAddr, uint32* value)
{
    switch_handle_t* p_l2switch_dev;

     if (NULL == value)
    {
        DRV_LOG_ERR("l2switch_register_read value null pointer!\n.");
        return L2SWITCH_E_INVALID_PTR;
    }   
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, reg_read);

    return p_l2switch_dev->reg_read(p_l2switch_dev, regAddr, value);
}

/****************************************************************************
 * Name	: l2switch_register_write
 * Purpose: write l2switch  register
 * Input:  uint8 l2switch_id                          the index of l2switch
         uint32 regAddr                               the address of l2switch register
         uint32 value                                 write value
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/	
int32 
l2switch_register_write(uint8 l2switch_id, uint32 regAddr, uint32 value)
{
    switch_handle_t* p_l2switch_dev;
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, reg_write);

    return p_l2switch_dev->reg_write(p_l2switch_dev, regAddr, value);
}

/****************************************************************************
 * Name	: l2switch_add_static_mac
 * Purpose: add static mac 
 * Input:  uint8 l2switch_id                          the index of l2switch
           uint8 port_id                              the index of port
           uint8 *mac                                 the pointer of mac value
           
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/
int32
l2switch_add_static_mac(uint8 l2switch_id, uint8 port_id, uint8 *mac)
{	
    switch_handle_t* p_l2switch_dev;
    uint32 max_port_nums;

    if (NULL == mac)
    {
        DRV_LOG_ERR("l2switch_add static mac null pointer!\n.");
        return L2SWITCH_E_INVALID_PTR;
    }  
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, add_static_mac);

    max_port_nums = p_l2switch_dev->l2switch_info->port_nums;
    if((port_id + 1 ) > max_port_nums)
    {
        DRV_LOG_ERR("invalid port id!\n.");
        DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "invalid port id!port index start from 0 to %d!\n.",
                        (max_port_nums - 1));
        return L2SWITCH_E_INVALID_PARAM;
    }
    
    return p_l2switch_dev->add_static_mac(p_l2switch_dev, port_id + 1, mac);		
}
/****************************************************************************
 * Name	: l2switch_init
 * Purpose: init  l2switch and then config 
 * Input:  l2switch_info_t * l2switch_info             the pointer to l2switch infomation struct
         uint8 l2switch_nums                           the number of l2switch
         void (*l2switch_fixup)(void)                  the pointer to user fixup function
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/	
int32 
l2switch_init(l2switch_info_t *l2switch_info, uint8 l2switch_nums,l2switch_fixup_t *l2switch_fixup)
{
    int32 i = 0;
    int32 ret;

    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "l2switch_init begin!");

    if (NULL == l2switch_info)
    {
         DRV_LOG_ERR( "L2switch init l2switch_info null pointer!\n");
         return L2SWITCH_E_INVALID_PTR;
    }
    
    g_l2switch_hdl = (switch_handle_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_L2SWITCH_INFO, 
                                    sizeof(switch_handle_t *)*l2switch_nums);
    if(NULL == g_l2switch_hdl)
    {
        DRV_LOG_ERR("L2swtich alloc handler fail!\n");
        return L2SWITCH_E_NO_MEMORY;
    }

    g_l2switch_max_nums = l2switch_nums;

    for (i = 0; i < l2switch_nums; i++)
    {
        if(l2switch_fixup[i] == NULL)
        {
            g_l2switch_hdl[i] = l2switch_register(&l2switch_info[i],NULL);
        }
        else
        {
            g_l2switch_hdl[i] = l2switch_register(&l2switch_info[i],l2switch_fixup[i]);
        }
        
    }

     for (i = 0; i < l2switch_nums; i++)
    {
        ret = _l2switch_init_dev(i);
        if(ret == -1)
        {
            DRV_LOG_ERR("L2swtich dev init fail!\n");
            return L2SWITCH_E_INIT_FAILED;        
        }
     }
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_NORMAL, "l2switch_init end!");
    return L2SWITCH_SUCCESS;
}

int32
l2switch_mgt_port_status(uint8 l2switch_id)
{   
    switch_handle_t* p_l2switch_dev;
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, mgt_port_status);
    
    return p_l2switch_dev->mgt_port_status(p_l2switch_dev);        
}

int32
l2switch_agg_members_set(uint8 l2switch_id, uint8 agg_id, uint8 members[])
{
    switch_handle_t* p_l2switch_dev;
    
    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, agg_port_members_set);
    
    return p_l2switch_dev->agg_port_members_set(p_l2switch_dev, agg_id, members);     
}

/*Bug29433 work around, resolve l2switch access problem. 2014-09-03*/
int32
l2switch_check_work_status(uint8 l2switch_id)
{
    uint32 regAddr;
    uint32 value;
    uint32 block = 0;
    uint32 subblock = 0;
    uint32 reg = 0;

    block = 2;
    subblock = 0;
    reg = 0x10;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    if(value != 0x01ffffff)
    {
        return -1;
    }
    l2switch_register_read( l2switch_id, regAddr, &value);
    if(value != 0x01ffffff)
    {
        return -1;
    }
    block = 2;
    subblock = 0;
    reg = 0xf0;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    if(value != 0x8000)
    {
        return -1;
    }
    return 0;
}

/*Bug29433 work around, resolve l2switch access problem. 2014-09-03*/
int32
l2switch_re_init(uint8 l2switch_id)
{
    switch_handle_t* p_l2switch_dev = NULL;

    API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
    API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, switch_reinit);
    
    return p_l2switch_dev->switch_reinit(p_l2switch_dev);    
}

/****************************************************************************
 * Name	: dump_l2switch_key_register
 * Purpose:dump l2switch key register 
 * Input:   N/A
 * Output: N/A 
 * Return:  
 * Note	: N/A
****************************************************************************/	
int32 dump_l2switch_key_register(uint8 l2switch_id,uint32 port_id)
{
    uint32 regAddr;
    uint32 value;
    uint32 block = 0;
    uint32 subblock = 0;
    uint32 reg = 0;
    uint16 phy_value;

    block = 7;
    subblock = 0;
    reg = 0x0;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "cpu transfer mode register :0x%08x",value);

    block = 7;
    subblock = 0;
    reg = 0x14;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "global reset register:block:  0x%08x",value);

    block = 7;
    subblock = 0;
    reg = 0x18;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "chip identification register:0x%08x",value);

    block = 1;
    subblock = port_id;
    reg = 0x0;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "mac %d configuration register:0x%08x",port_id,value);

    block = 1;
    subblock = port_id;
    reg = 0x19;
    regAddr = ((block&0x7)<<12) | ((subblock&0xf)<<8) | ((reg)&0xff);
    l2switch_register_read( l2switch_id, regAddr, &value);
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "mac %d advanced port mode setup register:0x%08x",port_id,value);
    

    reg = 0x0;
    l2switch_phy_read(l2switch_id, port_id, reg, &phy_value);    
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "phy %d ctrl register:0x%08x",port_id,phy_value);

    reg = 0x1;
    l2switch_phy_read(l2switch_id, port_id, reg, &phy_value);    
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "phy %d status register:0x%08x",port_id,phy_value);

    
    reg = 0x1c;
    l2switch_phy_read(l2switch_id, port_id, reg, &phy_value);    
    DRV_LOG_DEBUG(l2switch , DRV_L2SWITCH_READ, "phy %d auxiliary control and status register:0x%08x",port_id,phy_value);

    return L2SWITCH_SUCCESS;
}

#ifdef BOOTUP_DIAG 
/*result: bit[30:30] 0-pass,1-fail; bit[29:28] chip id; bit[27:0] error port; */
int32
l2switch_diagnostic_test()
{
    uint32 l2switch_id;
    switch_handle_t* p_l2switch_dev;    
    int32 ret=0;
    
    for (l2switch_id = 0; l2switch_id < g_l2switch_max_nums; l2switch_id++)
    {    
        API_GET_L2SWITCH_DRV(l2switch_id, p_l2switch_dev);
        API_L2SWITCH_OPT_PTR_CHECK(p_l2switch_dev, self_diagnostic);

        ret = p_l2switch_dev->self_diagnostic(p_l2switch_dev);
        if(ret != 0)
        {
            ret = ret + (1<<(28+l2switch_id));
            return ret;
        }
    }
    return ret;
}
#endif

