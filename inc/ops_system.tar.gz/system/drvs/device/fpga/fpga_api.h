/****************************************************************************
* $Id$
*  The header file of the fpga api.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Jian Zhu
* Date          : 2008-07-29 
* Reason        : First Create.
****************************************************************************/
#ifndef __FPGA_API_H__
#define __FPGA_API_H__

#include "fpga_drv.h"
#include "glb_hw_define.h"

#define CTC_FPGA_BASE               0
#define CTC_FPGA_BOARD_VERSION      0
#define CTC_FPGA_FPGA_VERSION       1

#define E300_FPGA_I2C_CTL           0x18
#define E310_FPGA_I2C_CTL           0x18

enum fpga_reg
{
    FPGA_BOARD_VERSION = 0,
    FPGA_VERSION,
    FPGA_RESET,
    FPGA_TEST,
    FPGA_BAY_INT_STATUS,    
    FPGA_BAY_INT_MASK,
    FPGA_SHARE_INT_MASK,
    FPGA_PHY_INT,
    FPGA_CF_PRESENT,
    FPGA_SPRK_OUT,
    FPGA_PHY_INT_MASK,
    FPGA_RESET_EPLD,
    FPGA_BAY_LED_STATUS,
    FPGA_WATCHDOG_EN,
    FPGA_WATCHDOG_TIMER,
    FPGA_SFP_PRESENT,
    FPGA_SFP_DISABLE,
    FPGA_SFP_FAULT_REG,
    FPGA_SERDES_SWITCH1_DATA_EN,
    FPGA_SERDES_SWITCH2_DATA_EN,    
    FPGA_SERDES_SWITCH1_SWITCH_SE,
    FPGA_SERDES_SWITCH2_SWITCH_SE,
    FPGA_SERDES_SWITCH1_PRE_CTL,
    FPGA_SERDES_SWITCH2_PRE_CTL,
    FPGA_REPLICATOR_MUX,
    /*FOR E810 jcao*/
    FPGA_RICHMOND_INT_STATUS,           /*base_addr:0x000, reg_off:0x10, bit_range:(0:3)*/
    FPGA_PERI_INT_STATUS,               /*base_addr:0x000, reg_off:0x14, bit_range:(0:4)*/
    FPGA_I2C_SCL,                       /*base_addr:0x000, reg_off:0x18, bit_range:(0:3)*/
    FPGA_I2C_SDA,                       /*base_addr:0x000, reg_off:0x1c, bit_range:(0:3)*/
    FPGA_RICHMOND_LED,                  /*base_addr:0x000, reg_off:0x28, bit_range:(0:3)*/
    FPGA_RICHMOND_INT_MASK,             /*base_addr:0x000, reg_off:0x30, bit_range:(0:3)*/
    FPGA_PERI_INT_MASK,                 /*base_addr:0x000, reg_off:0x34, bit_range:(0:4)*/

    FPGA_CF_PIO_RD_DATA,                /*base_addr:0x100, reg_off:0x0, bit_range:(0:15)*/
    FPGA_CF_ERROR,                      /*base_addr:0x100, reg_off:0x4, bit_range:(0:7)*/
    FPGA_CF_SECTOR_COUNT,               /*base_addr:0x100, reg_off:0x8, bit_range:(0:7)*/
    FPGA_CF_SECTOR_NO,                  /*base_addr:0x100, reg_off:0xc, bit_range:(0:7)*/
    FPGA_CF_CYLINDER_LOW,               /*base_addr:0x100, reg_off:0x10, bit_range:(0:7)*/
    FPGA_CF_CYLINDER_HIGH,              /*base_addr:0x100, reg_off:0x14, bit_range:(0:7)*/
    FPGA_CF_SELECT_CARD,                /*base_addr:0x100, reg_off:0x18, bit_range:(0:7)*/
    FPGA_CF_STATUS,                     /*base_addr:0x100, reg_off:0x1c, bit_range:(0:7)*/

    FPGA_RICHMOND_READ_ADDR,             /*base_addr:0x600, reg_off:0x0, bit_range:(0:31)*/
    FPGA_RICHMOND_WRITE_ADDR,            /*base_addr:0x600, reg_off:0x4, bit_range:(0:31)*/
    FPGA_RICHMOND_WRITE_DATA,            /*base_addr:0x600, reg_off:0x8, bit_range:(0:31)*/
    FPGA_RICHMOND_READ_DATA,             /*base_addr:0x600, reg_off:0xC, bit_range:(0:31)*/
    FPGA_RICHMOND_READ_STATUS,           /*base_addr:0x600, reg_off:0x10, bit_range:(0:31)*/
    FPGA_RICHMOND_CONFIG,                /*base_addr:0x600, reg_off:0x14, bit_range:(0:8)*/
    FPGA_REG_MAX_NUM
};

typedef struct fpga_hw_info_s
{
    glb_board_type_t board_type;
    int16 valid;                              /* the fpga info is valid */
    int16 fpga_start_version;                 /* start version of epld */
    int16 fpga_end_version;                   /* end version of epld */
    int16 fpga_reg_index;                     /* index to the reg struct */
} fpga_hw_info_t;

fpga_info_t * fpga_get_info(glb_board_type_t *board_type, int32 fpga_version);
inline int32 fpga_set_reg_desc(fpga_reg_t * reg_desc, int32 reg_offset, int32 start_bit,
                               int32 end_bit, int32 item_bitwidth);
int32 fpga_item_write(uint32 op_reg, int32 value);
int32 fpga_item_read(uint32 op_reg, int32 *value);

int32 fpga_write(uint8 byte_width, int32 offset, uint32 value);
int32 fpga_read(uint8 byte_width, int32 offset, uint32* value);
int32 fpga_cfg_phy_interrupt_mask(int32 mask_en);
/* init function */
int32 fpga_init(fpga_info_t *p_fpga_info);

#endif /* !__FPGA_API_H__ */
