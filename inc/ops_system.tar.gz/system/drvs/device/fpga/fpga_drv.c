/****************************************************************************
 * fpga_drv.c    Control FPGA access interface
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Zhu Jian
 * Date:         2010-08-26.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctc_pci.h"
#include "drv_debug.h"
#include "fpga_drv.h"

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static fpga_handle_t* fpga_create_handle(void* fpga_dev_info);

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
int32
fpga_drv_read(const fpga_handle_t* phdl, fpga_access_t* paccess)
{
    fpga_info_t* p_fpga_info = NULL; 
    
    if(NULL == phdl || NULL == paccess || NULL == phdl->info)
    {
        printf("FPGA pci read: invalid pointer\n");
        return -1;
    }
    
    p_fpga_info = (fpga_info_t*)phdl->info;
    if(1 == paccess->width)
    {
        PCIIO_RD_8(p_fpga_info->base_addr + paccess->addr, paccess->val.val_8bit);
    }
    else if(2 == paccess->width)
    {
        PCIIO_RD_16(p_fpga_info->base_addr + paccess->addr, paccess->val.val_16bit);
    }
    else if(4 == paccess->width)
    {
        PCIIO_RD_32(p_fpga_info->base_addr + paccess->addr, paccess->val.val_32bit);
    }
    else
    {
        return -1;
    }

    return 0;
}

int32
fpga_drv_write(const fpga_handle_t* phdl, fpga_access_t* paccess)
{   
    fpga_info_t* p_fpga_info = NULL; 
    
    if(NULL == phdl || NULL == paccess || NULL == phdl->info)
    {
        printf("FPGA pci write: invalid pointer\n");
        return -1;
    }

    p_fpga_info = (fpga_info_t*)phdl->info;
    if(1 == paccess->width)
    {
        PCIIO_WR_8(p_fpga_info->base_addr + paccess->addr, paccess->val.val_8bit);
    }
    else if(2 == paccess->width)
    {
        PCIIO_WR_16(p_fpga_info->base_addr + paccess->addr, paccess->val.val_16bit);
    }
    else if(4 == paccess->width)
    {
        PCIIO_WR_32(p_fpga_info->base_addr + paccess->addr, paccess->val.val_32bit);
    }
    else
    {
        return -1;
    }
    
    return 0;
}

/*****************************************************************************
 * Name         :   fpga_item_read
 * Purpose      :   read value from fpga's register 
 * Input        :   fpga handler
 *              :   op_reg  define in pci_drv.h
 * Output       :   value
 * Return       :   Success/Error Number 
 * Note         :   Function read value from epld's responed bit of item_no
 *              :   and adjust the value to the lowest bit in parameter 
 *****************************************************************************/
int32 
fpga_drv_item_read(const fpga_handle_t* phdl, uint32 op_reg, int32* value)
{
    int32 offset;
    int32 start_bit;
    int32 item_bitwidth;
    uint32 fpga_reg_value;
    fpga_info_t* p_fpga_info = NULL; 
    
    if(NULL == phdl || NULL == phdl->info)
    {
        printf("FPGA read item: invalid pointer\n");
        return -1;
    }

    p_fpga_info= phdl->info;
    if(0 == p_fpga_info->reg_desc[op_reg].reg_valid)
    {
        *value = 0;
        return 0;
    }
    offset = p_fpga_info->reg_desc[op_reg].reg_offset;
    start_bit = p_fpga_info->reg_desc[op_reg].start_bit;
    item_bitwidth = p_fpga_info->reg_desc[op_reg].item_bitwidth;
    fpga_reg_value = 0;
    
    PCIIO_RD_32(p_fpga_info->base_addr + offset, fpga_reg_value);
    
    fpga_reg_value >>= start_bit;

    fpga_reg_value &= ((1 << item_bitwidth) - 1);

    * value = (int32)fpga_reg_value;
   
    return 0;
}

/*****************************************************************************
 * Name         :   fpga_item_write
 * Purpose      :   write value into fpga's register 
 * Input        :   fpga fpga handler        
 *              :   op_reg  defined in fpga_drv.h
 *              :   value   the value to be write
 * Output       :   
 * Return       :   Success/Error number 
 * Note         :   The value to be write is stored from the bit0 
 *              :   function will adjust to the responed bit in epld
 * *****************************************************************************/
int32 
fpga_drv_item_write(const fpga_handle_t* phdl, uint32 op_reg, int32 value)
{
    int32 offset;
    int32 start_bit;
    int32 item_bitwidth;
    uint32 fpga_reg_value;    
    uint32 temp_value = 0;
    fpga_info_t* p_fpga_info = NULL;

    if(NULL == phdl || NULL == phdl->info)
    {
        printf("FPGA write item: invalid pointer\n");
        return -1;
    }

    p_fpga_info = phdl->info;
    if(0 == p_fpga_info->reg_desc[op_reg].reg_valid)
    {
        return 0;
    }
    offset = p_fpga_info->reg_desc[op_reg].reg_offset;
    start_bit = p_fpga_info->reg_desc[op_reg].start_bit;
    item_bitwidth = p_fpga_info->reg_desc[op_reg].item_bitwidth;
    fpga_reg_value = 0;
    
    PCIIO_RD_32(p_fpga_info->base_addr + offset, fpga_reg_value);
    
    value <<= start_bit;

    temp_value = (((1 << item_bitwidth) - 1) << start_bit);
    
    fpga_reg_value &= (~temp_value);
    fpga_reg_value |= value;
    PCIIO_WR_32(p_fpga_info->base_addr + offset, fpga_reg_value);

    return 0;
}

static fpga_handle_t*
fpga_create_handle(void *fpga_dev_info)
{
    fpga_handle_t *phdl = NULL; 
    fpga_info_t *p_fpga_info = NULL; 
    
    if (NULL == fpga_dev_info)
    {
        printf("fpga create handle: invalid pointer\n");
        return NULL;
    }

    phdl = (fpga_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_FPGA_INFO, sizeof(fpga_handle_t));
    if (NULL == phdl)
    {
        goto err_out;
    }
    
    phdl->info = (fpga_info_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_FPGA_INFO, sizeof(fpga_info_t));
    if (NULL == phdl->info)
    {
        goto err_out;
    }

    sal_memcpy((int8_t *)phdl->info, (int8_t *)fpga_dev_info, sizeof(fpga_info_t));

    p_fpga_info = (fpga_info_t *)fpga_dev_info;

    phdl->item_read = fpga_drv_item_read;
    phdl->item_write = fpga_drv_item_write;
    phdl->read = fpga_drv_read;
    phdl->write = fpga_drv_write;
    
    return phdl;
    
err_out:
    if (NULL != phdl && NULL != phdl->info)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_FPGA_INFO, phdl->info);
        phdl->info = NULL;
    }

    if (NULL != phdl)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_FPGA_INFO, phdl);
        phdl = NULL;
    }

    return NULL;
}
    
/****************************************************************************
 * Name : fpga_dev_register
 * Purpose: register epld dev driver, initialize the handler
 * Input    : epld access type, the pointer of fpga memory base addr
 * Output:  
 * Return:  the handler of the epld dev
 * Note :
****************************************************************************/   
fpga_handle_t *
fpga_dev_register(void *info)
{    
    return fpga_create_handle(info);
}

