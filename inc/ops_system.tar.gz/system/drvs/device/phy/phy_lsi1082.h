#ifndef __PHY_LSI1082_H__
#define __PHY_LSI1082_H__

#include "phy_drv.h"

phy_handle_t* phy_lsi1082_dev_register(phy_info_t* pphy_info);

#endif /* !__PHY_LSI1082_H__ */

