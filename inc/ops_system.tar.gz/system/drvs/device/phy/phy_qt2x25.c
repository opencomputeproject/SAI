/****************************************************************************
* $Id$
* phy qt2x25 device driver
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : mayc
* Date          : 2010-08-18
* Reason        : First Create.
****************************************************************************/
#include "sal_common.h"
#include "drv_debug.h"
#include "mdio.h"
#include "glb_macro.h"
#include "glb_phy_define.h"
#include "phy_qt2x25.h"
#include "epld_api.h"
#include <sys/time.h>


#define XGPHY_PMA_RX_ALARM_CTL_REG      0x9000
#define XGPHY_PMA_TX_ALARM_CTL_REG      0x9001
#define XGPHY_PMA_LASICTL_REG       	0x9002
#define XGPHY_PMA_RX_ALARM_STAT_REG     0x9003
#define XGPHY_PMA_LASISTS_REG       	0x9005
#define XGPHY_PMA_LED1_REG              0xd006
#define XGPHY_PMA_LED2_REG              0xd007

#define QTXGPHY_PCS_STATUS_REG        	0x20

#define XGPHY_LS_RX_INTR_EN             0x05
#define XGPHY_LS_INTR_EN            	0x01

static uint8 phy_qt2x25_fast_detect=0;
/*bug 16503. jqiu 2011-11-01.*/
void glb_enable_phy_fast_detect(uint8 flag)
{
    phy_qt2x25_fast_detect = flag;
}

uint8 phy_qt2x25_is_fast_detect()
{
    if(phy_qt2x25_fast_detect)
        return TRUE;
    else
        return FALSE;
}

int32 qt2x25_reg_read(phy_handle_t* phy_handle, phyreg_param_t* op_param, uint16* value)
{
    phy_handle_t *phdl;
    mdio_bus_para_t para;

    int32 ret;
    
    if(NULL == phy_handle || NULL == op_param || NULL == value)
    {
        return RESULT_ERROR;
    }
    phdl = phy_handle;

    para.xgphy_para.devno = op_param->dev_no;
    para.xgphy_para.reg = op_param->dat.regaddr16;
    para.xgphy_para.phy_addr = phdl->phy_info.port.phy_addr;
        
    if(NULL == phdl->mdio_hdl || NULL == phdl->mdio_hdl->read)
    {
        return RESULT_ERROR;
    }
    ret = phdl->mdio_hdl->read(phdl->mdio_hdl, &para);
    if(ret)
    {
        return RESULT_ERROR;
    }
    *value = para.xgphy_para.val;
    //DRV_LOG_DEBUG(phy, DRV_PHY_READ,"QT2X25 phy addr %d: read reg %d.%xh: 0x%x", 
    //    pphy_info->port.phy_addr, para.xgphy_para.devno, op_param->dat.regaddr16, *value);

    return RESULT_OK;
}

static int32 qt2x25_reg_write(phy_handle_t* phy_handle, phyreg_param_t* op_param, uint16 value)
{
    phy_handle_t *phdl;
    mdio_bus_para_t para;
    int32 ret;
    
    if(NULL == phy_handle || NULL == op_param)
    {
        return RESULT_ERROR;
    }
    phdl = phy_handle;
    /*DRV_LOG_DEBUG(phy, DRV_PHY_WRITE,"QT2X25 phy addr %d: write reg 0x%x value 0x%x", 
                    pphy_info->port.phy_addr, op_param->dat.regaddr8, value);*/

    para.xgphy_para.devno = op_param->dev_no;
    para.xgphy_para.phy_addr = phdl->phy_info.port.phy_addr;
    para.xgphy_para.reg = op_param->dat.regaddr16;
    para.xgphy_para.val = value;

    if(NULL == phdl->mdio_hdl || NULL == phdl->mdio_hdl->write)
    {
        return RESULT_ERROR;
    }
    ret = phdl->mdio_hdl->write(phdl->mdio_hdl, &para);
    if(ret)
    {
        return RESULT_ERROR;
    }
    
    return RESULT_OK;
}
static void _qt2x25_clean_alarm_en(phy_handle_t* phy_handle)
{
    phyreg_param_t phyreg_para;    
    uint16 value;

    
    /*Clear interrupts*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LASISTS_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);
    if(phy_qt2x25_is_fast_detect())
    {
        phyreg_para.dat.regaddr16 = XGPHY_PMA_RX_ALARM_STAT_REG;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value);       
    }
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,"clear rx alarm 0x%x", value);
    /*Enable LS_ALARM interrupt*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LASICTL_REG;
    if(phy_handle->phy_info.phy_manage_info.media_type != GLB_MEDIA_1000BX)
    {
        if(phy_qt2x25_is_fast_detect())
        {
            phy_handle->reg_write(phy_handle, &phyreg_para, XGPHY_LS_RX_INTR_EN);
        }
        else
        {
            phy_handle->reg_write(phy_handle, &phyreg_para, XGPHY_LS_INTR_EN);
        }
    }
    else
    {
        phy_handle->reg_write(phy_handle, &phyreg_para, 0);
    }

    return ;
}

static void _xgphy_qt2x25_status_get(phy_handle_t* phy_handle, glb_phy_state_t* phy_state_val)
{
    phyreg_param_t phyreg_para;    
    uint16 pcs_status, lasi_status, rx_alarm;

    /* FAE said should use 3.0020[12] to check pcs link up status.*/
    phyreg_para.dev_no = XGPHY_PCS_DEV;
    phyreg_para.dat.regaddr16 = QTXGPHY_PCS_STATUS_REG;        
    phy_handle->reg_read(phy_handle, &phyreg_para, &pcs_status);

    if(phy_qt2x25_is_fast_detect())
    {
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LASISTS_REG;
        phy_handle->reg_read(phy_handle, &phyreg_para, &lasi_status);
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_RX_ALARM_STAT_REG;
        phy_handle->reg_read(phy_handle, &phyreg_para, &rx_alarm);
        /*fix bug 14579. if phy is not exist, access will return 0xffff, set to link down.*/
        if(((pcs_status & 0x1000) == 0)||(pcs_status == 0xffff)||((rx_alarm&0x21d)!=0))
            phy_state_val->link_up = 0;/*link down */
        else
            phy_state_val->link_up = 1;
    }
    else
    {
        if(((pcs_status & 0x1000) == 0)||(pcs_status == 0xffff))
            phy_state_val->link_up = 0;/*link down */
        else
            phy_state_val->link_up = 1;
    }
    phy_state_val->speed = GLB_SPEED_10G;
    phy_state_val->duplex = GLB_DUPLEX_FULL;
    phy_state_val->linkup_media = GLB_PORT_TYPE_FIBER;
    
    phy_state_val->flowctrl.send = phy_handle->phy_info.phy_manage_info.flowctrl.send;
    phy_state_val->flowctrl.recv = phy_handle->phy_info.phy_manage_info.flowctrl.recv;
    return;
}
/*Fix bug 14685. jqiu 2011-06-01. support dynamic modify qt2225 work mode.*/
static int _xgphy_qt2x25_load_firmware(phy_handle_t* phy_handle)
{
    phyreg_param_t phyreg_para;
    int ret;
    FILE* fp;
    uint8* tmpbuf;
    int count = 0;
    int ii, jj;

    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "QT2x25 init, start");
    fp = sal_fopen("/etc/qt2x25_firmware_mdio.bin", "rb");
    if(fp < 0) 
    {
        DRV_LOG_ERR("Open /etc/qt2x25_firmware_mdio.bin failed.");
        return RESULT_ERROR;
    }

    tmpbuf = (uint8* )DRV_MALLOC(CTCLIB_MEM_DRIVER_PHY_INFO, 1024);
    if(NULL == tmpbuf)
    {
        sal_fclose(fp);
        DRV_LOG_ERR("QT2x25 init, out of memory");
        return RESULT_ERROR;
    }

    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0x8000;
    for(ii = 0; ii < 16; ii++)
    {
        count = sal_fread(tmpbuf, 1, 1024, fp);
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,"QT2x25 init, read %d bytes", count); 
        if(count < 0)
        {
                DRV_FREE(CTCLIB_MEM_DRIVER_PHY_INFO, tmpbuf);
                DRV_LOG_ERR("QT2x25 init, read failed"); 
                sal_fclose(fp);
                return RESULT_ERROR;
        }
        for(jj = 0; jj < count; jj++)
        {
            ret = phy_handle->reg_write(phy_handle, &phyreg_para, tmpbuf[jj]);
            phyreg_para.dat.regaddr16++;
            if(ret)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_PHY_INFO, tmpbuf);
                DRV_LOG_ERR("QT2x25 init, load firmware failed"); 
                sal_fclose(fp);
                return RESULT_ERROR;
            }
        }
    }

    phyreg_para.dev_no = 4;
    phyreg_para.dat.regaddr16 = 0x8000;
    for(ii = 0; ii < 8; ii++)
    {
        count = sal_fread(tmpbuf, 1, 1024, fp);
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,"QT2x25 init, read %d bytes", count); 
        if(count < 0)
        {
                DRV_FREE(CTCLIB_MEM_DRIVER_PHY_INFO, tmpbuf);
                DRV_LOG_ERR("QT2x25 init, read failed"); 
                sal_fclose(fp);
                return RESULT_ERROR;
        }
        for(jj = 0; jj < count; jj++)
        {
            ret = phy_handle->reg_write(phy_handle, &phyreg_para, tmpbuf[jj]);
            phyreg_para.dat.regaddr16++;
            if(ret)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_PHY_INFO, tmpbuf);
                DRV_LOG_ERR("QT2x25 init, load firmware failed"); 
                sal_fclose(fp);
                return RESULT_ERROR;
            }
        }
    }
    
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "QT2x25 init, end");
    sal_fclose(fp);
    DRV_FREE(CTCLIB_MEM_DRIVER_PHY_INFO, tmpbuf);
    return RESULT_OK;
}

/* Why here not config QT2225 to SFP+ self configure mode?  jqiu 2011-05-23
   1. In SFP+ self configure mode, the phy loopback won't work. phy loopback just work in force mode.
   2. In SFP+ self configure mode, if insert SFP+, it auto work on 10G mode, but sometime we want it 
     still work on 1G mode.
media_type: cfg work mode of qt2225, include XFP, SFP/SFP+ 1GMode, SFP/SFP+ 10GMode, and so on
is_init: describe whether this func is called when board init. */
int32 qt2x25_phy_reset(phy_handle_t* phy_handle, uint8 mac_if, uint8 media_type, uint8 is_init)
{
    phyreg_param_t phyreg_para;    
    uint16 value;
    int count = 0;
    int ret=0;
    
    if(NULL == phy_handle || NULL == phy_handle->reg_write)
    {
        return RESULT_ERROR;
    }

    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc300;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x0);
    
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc302;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x4);

    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc319;
    // XFP
    if(media_type == GLB_MEDIA_XFP)
    {
        //op_mode_config 1:XFP/SFP+
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x8);
    }    
    //1G mode
    else if(media_type == GLB_MEDIA_1000BX)
    {    
        //op_mode_config 1:XFP/SFP+, TXOUT not inversion for SFP+,SFP
        phy_handle->reg_write(phy_handle, &phyreg_para, 0xc8);
    }
    //SFP+, RJ45, AUTO and so on, all process as SFP+.
    else  // if(media_type == GLB_PORT_TYPE_SFP_PLUS)
    {
        //op_mode_config 1:XFP/SFP+, TXOUT not inversion for SFP+
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x48);
        //SFP+ self configure mode
        //phy_handle->reg_write(phy_handle, &phyreg_para, 0x78);
    }

    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc31a;
    // XFP
    if(media_type == GLB_MEDIA_XFP)
    {
        //MODULE_TYPE XFP
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x90);
    }    
    //1G mode
    else if(media_type == GLB_MEDIA_1000BX)
    {    
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x98);
    }
    //SFP+, RJ45, AUTO and so on, all process as SFP+.
    else //if(media_type == GLB_PORT_TYPE_SFP_PLUS)
    {        
        //MODULE_TYPE SFP+
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x98);
    }

    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0x26;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0xe00);

    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0x27;
    // XFP
    if(media_type == GLB_MEDIA_XFP)
    {
        //LED_CTRL:firmware not control, DOM_MODE: Module A2 in 1.A000, RX_PCS_RESET_CTRL 1 
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x881);
    }    
    //1G mode
    else if(media_type == GLB_MEDIA_1000BX)
    {
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x1092);        
    }
    //SFP+, RJ45, AUTO and so on, all process as SFP+.
    else //if(media_type == GLB_PORT_TYPE_SFP_PLUS)
    {
        //LED_CTRL:firmware not control, DOM_MODE: Module A2 in 1.A000, RX_PCS_RESET_CTRL 1 
        //SFP+ hostboard transmit/receiver path Loss Parameter
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x893);
    }

    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0x28;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0xa528);    
    
    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0x29;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x3);

    phyreg_para.dev_no = 4;
    phyreg_para.dat.regaddr16 = 0xc05b;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);
    GLB_SET_BIT(value, 10);
    GLB_SET_BIT(value, 12);
    phy_handle->reg_write(phy_handle, &phyreg_para, value);

    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc308;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    GLB_SET_BIT(value, 14);
    phy_handle->reg_write(phy_handle, &phyreg_para, value);
    
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc30a;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x6e1);

    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc300;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x2);

    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0xe854;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0xc0);

    if(is_init)
    {
        ret = _xgphy_qt2x25_load_firmware(phy_handle);
        if(RESULT_OK != ret)
        {
            return ret;
        }
    }

    phyreg_para.dev_no = 3;
    phyreg_para.dat.regaddr16 = 0xe854;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x40);

    /*Fix bug 14190. phy rx clock recover error.*/
    value = 0;
    count = 0;
    /*wait for heart beat changed*/
    while((value == 0)&&(count < 10))
    {
        usleep(10000);
        count ++;
        phyreg_para.dev_no = 3;
        phyreg_para.dat.regaddr16 = 0xd7ee;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value);        
    }
    value = 0;
    count = 0;
    /*wait for UC_STATUS become normal*/
    while(((value == 0)||(value == 0x10))&&(count < 100))
    {
        usleep(100000);
        count ++;
        phyreg_para.dev_no = 3;
        phyreg_para.dat.regaddr16 = 0xd7fd;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    }

    if(is_init)
    {
        /*Because xgphy is broadcast, even this phy is ready, other phy maybe still not ready, here still delay a while*/
        usleep(100000);
    }

    /*LOSOUTB pad output enable*/
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc313;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0xfff);
    /* LOSOUTB inverted after PAD */
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xd005;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x4);
    
    if(phy_handle->phy_info.led_type == GLB_PHY_LED_1)
    {
        /* set led1 mode: rx link*/
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LED1_REG;
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x9);
        /*set led2 mode: rx act*/
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LED2_REG;
        phy_handle->reg_write(phy_handle, &phyreg_para, 0xa);
    }
    else if(phy_handle->phy_info.led_type == GLB_PHY_LED_2)
    {
        /* set led1 mode: rx link and act*/
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LED1_REG;
        phy_handle->reg_write(phy_handle, &phyreg_para, 0xb);
        /*set led2 mode: rx link and act*/
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LED2_REG;
        phy_handle->reg_write(phy_handle, &phyreg_para, 0xb);        
    }
    /*disable rx optical power alarm*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_RX_ALARM_CTL_REG;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x21d);
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_TX_ALARM_CTL_REG;
    phy_handle->reg_write(phy_handle, &phyreg_para, 0x0);

    _qt2x25_clean_alarm_en(phy_handle);

    /*fix bug 14074.*/
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xf052;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
    value |= 0x6;
    phy_handle->reg_write(phy_handle, &phyreg_para, value);

    /*change the cross connect when 1G <=> 10G switch.*/
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc303;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);
    if(media_type == GLB_MEDIA_1000BX)
    {       
        value &= 0xbfdf;
        phy_handle->reg_write(phy_handle, &phyreg_para, value); 
        /* set 1G mode led1,led2 off, led3 tx link*/
        phyreg_para.dev_no = XGPHY_PCS_DEV;
        phyreg_para.dat.regaddr16 = 0xd70d;
        phy_handle->reg_write(phy_handle, &phyreg_para, 0x1);
        epld_cfg_phy_switch_smi(0, phy_handle->phy_info.switch_chnl_id, 0);
    }
    else
    {
        value &= 0xbfdf;
        value |= 0x20;
        phy_handle->reg_write(phy_handle, &phyreg_para, value); 
        epld_cfg_phy_switch_smi(0, phy_handle->phy_info.switch_chnl_id, 1);
    }

    return RESULT_OK;
}


int32 qt2x25_init(phy_handle_t* phy_handle)
{
    int ret;
    
    if(NULL == phy_handle || NULL == phy_handle->reg_write)
    {
        return RESULT_ERROR;
    }
    /*Fix bug 14685. jqiu 2011-06-01. support dynamic modify qt2225 work mode.*/
    ret = qt2x25_phy_reset(phy_handle, phy_handle->phy_info.phy_manage_info.mac_if, phy_handle->phy_info.phy_manage_info.media_type, 1);    
    return ret;
}

int32 qt2x25_enable(phy_handle_t* phy_handle, int8 enable)
{
    phyreg_param_t phyreg_para;    
    phy_info_t* pphy_info;
    uint16 value;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    pphy_info = &phy_handle->phy_info;
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "QT2X25 phy addr %d enable: speed %d duplex %d", 
        pphy_info->port.phy_addr, pphy_info->phy_manage_info.speed, 
        pphy_info->phy_manage_info.duplex);
#if 0
    /* close tx led*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LED1_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    value &= 0xfff8;
    value |= 0x4;    
    phy_handle->reg_write(phy_handle, &phyreg_para, value);    
    
    /*close rx led*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LED2_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    value &= 0xfff8;
    value |= 0x4;    
    phy_handle->reg_write(phy_handle, &phyreg_para, value);
#endif
#if 0
    /*firmware Power control*/
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xc319;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);     
    if(enable)
    {
          value &= 0xfffd;
        phy_handle->reg_write(phy_handle, &phyreg_para, value);
    }
    else
    {
          value |= 0x2;
        phy_handle->reg_write(phy_handle, &phyreg_para, value);
    }
#else
     /* fix bug 13796 wuzh  */   
    phyreg_para.dev_no = 1;
    phyreg_para.dat.regaddr16 = 0xf052;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
    
    if(enable)
    {
        value &= 0xfff9;
        phy_handle->reg_write(phy_handle, &phyreg_para, value);
    }
    else
    {
        value |= 0x6;
        phy_handle->reg_write(phy_handle, &phyreg_para, value);
    }
#endif    
    /*Clear interrupts and enable interrupt*/
    _qt2x25_clean_alarm_en(phy_handle);
    return RESULT_OK;
}

static int32 qt2x25_linkup_setting(phy_handle_t* phy_handle)
{
#if 0    
    phyreg_param_t phyreg_para;    
    uint16 value;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    /*Rx led on*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LED1_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    value &= 0xfff8;
    value |= 0x1;    
    phy_handle->reg_write(phy_handle, &phyreg_para, value);    
    
    /*Tx led on*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LED2_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    value &= 0xfff8;
    value |= 0x2;    
    phy_handle->reg_write(phy_handle, &phyreg_para, value);
#endif    
    phyreg_param_t phyreg_para;  
    if(phy_qt2x25_is_fast_detect())
    {
        /*Enable LS_ALARM interrupt*/
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LASICTL_REG;
        if(phy_handle->phy_info.phy_manage_info.media_type != GLB_MEDIA_1000BX)
        {
            phy_handle->reg_write(phy_handle, &phyreg_para, XGPHY_LS_RX_INTR_EN);
        }
    }
    return RESULT_OK;
}

static int32 qt2x25_linkdown_setting(phy_handle_t* phy_handle)
{
#if 0    
    phyreg_param_t phyreg_para;    
    uint16 value;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    
    /*Rx led off*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LED1_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    value &= 0xfff8;
    value |= 0x4;    
    phy_handle->reg_write(phy_handle, &phyreg_para, value);    
    
    /*Tx led off*/
    phyreg_para.dev_no = XGPHY_PMA_DEV;
    phyreg_para.dat.regaddr16 = XGPHY_PMA_LED2_REG;
    phy_handle->reg_read(phy_handle, &phyreg_para, &value);    
    value &= 0xfff8;
    value |= 0x4;    
    phy_handle->reg_write(phy_handle, &phyreg_para, value);
#endif
    phyreg_param_t phyreg_para;
    if(phy_qt2x25_is_fast_detect())
    {
        /*Enable LS_ALARM interrupt*/
        phyreg_para.dev_no = XGPHY_PMA_DEV;
        phyreg_para.dat.regaddr16 = XGPHY_PMA_LASICTL_REG;
        if(phy_handle->phy_info.phy_manage_info.media_type != GLB_MEDIA_1000BX)
        {
            phy_handle->reg_write(phy_handle, &phyreg_para, XGPHY_LS_INTR_EN);
        }
    }
    return RESULT_OK;
}

int32 qt2x25_link_poll(phy_handle_t* phy_handle, glb_phy_state_t *phy_val, 
                            phy_state_change_t *phy_change)
{
    phy_info_t *phy_info;
    
    if(NULL == phy_handle || NULL == phy_val || NULL == phy_change)
    {
        return RESULT_ERROR;
    }
       
    phy_info = &phy_handle->phy_info;


    /*get pcs status*/
    _xgphy_qt2x25_status_get(phy_handle, phy_val);
     
    /*Link status in changed*/
    if(phy_info->phy_stat_flag.link_up != phy_val->link_up)
    {
        if(phy_val->link_up == GLB_LINK_UP)     /* link down to link up */
        {
            phy_change->action = 1;
            if(phy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
                phy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
            {
                phy_change->flowctrl_change = 1;
            }
            DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "QT2X25 phy addr %d link up",phy_info->port.phy_addr); 
            qt2x25_linkup_setting(phy_handle);
        }
        else
        {
            phy_change->action = 0;  /* link down to link up */
            DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "QT2X25 phy addr %d link down",phy_info->port.phy_addr); 
            qt2x25_linkdown_setting(phy_handle);
        }        
    }
    /*No change*/
    else
    {
        phy_change->action = -1;
        if(phy_val->link_up == GLB_LINK_UP)
        {
            if(phy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
                phy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
            {
                phy_change->flowctrl_change = 1;
            }
        }
    }
    if(phy_qt2x25_is_fast_detect())
    {
        /*jqiu temp add start*/
        if(phy_val->link_up == GLB_LINK_UP)
        {
            qt2x25_linkup_setting(phy_handle);
        }
        else
        {
            qt2x25_linkdown_setting(phy_handle);
        }
        /*jqiu temp add end*/
    }

    
        
    phy_info->phy_stat_flag.link_up = phy_val->link_up;
    phy_info->phy_stat_flag.speed = phy_val->speed;
    phy_info->phy_stat_flag.duplex = phy_val->duplex;
    phy_info->phy_stat_flag.linkup_media = phy_val->linkup_media;
    /*When link is down, not update flow ctrl*/
    if(phy_val->link_up == GLB_LINK_UP)
    {
        phy_info->phy_stat_flag.flowctrl.send = phy_val->flowctrl.send;
        phy_info->phy_stat_flag.flowctrl.recv = phy_val->flowctrl.recv;
    }
    
    return RESULT_OK;
}

int32 qt2x25_link_interrupt(phy_handle_t* phy_handle, glb_phy_state_t *phy_val, 
                                  phy_state_change_t *phy_change)
{
    phy_info_t *phy_info;
   
    if(NULL == phy_handle || NULL == phy_val || NULL == phy_change)
    {
        return RESULT_ERROR;
    }

    _qt2x25_clean_alarm_en(phy_handle);
    
    phy_info = &phy_handle->phy_info;
    
    _xgphy_qt2x25_status_get(phy_handle, phy_val);
    
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "qt2x25_link_interrupt %d link up %d->%d", 
      phy_info->port.phy_addr, phy_info->phy_stat_flag.link_up, phy_val->link_up); 
    /*Link status in changed*/
    if(phy_info->phy_stat_flag.link_up != phy_val->link_up)
    {
        if(phy_val->link_up == GLB_LINK_UP)     /* link down to link up */
        {
            phy_change->action = 1;
            if(phy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
                phy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
            {
                phy_change->flowctrl_change = 1;
            }
            qt2x25_linkup_setting(phy_handle);
        }
        else
        {
            phy_change->action = 0;  /* link up to link down */
            qt2x25_linkdown_setting(phy_handle);
        }        
    }
    /*No change*/
    else
    {
        phy_change->action = -1;
        if(phy_val->link_up == GLB_LINK_UP)
        {
            if(phy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
                phy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
            {
                phy_change->flowctrl_change = 1;
            }
        }
    }
    if(phy_qt2x25_is_fast_detect())
    {
        /*jqiu temp add start*/
        if(phy_val->link_up == GLB_LINK_UP)
        {
            qt2x25_linkup_setting(phy_handle);
        }
        else
        {
            qt2x25_linkdown_setting(phy_handle);
        }
        /*jqiu temp add end*/
    }
    
    phy_info->phy_stat_flag.link_up = phy_val->link_up;
    phy_info->phy_stat_flag.speed = phy_val->speed;
    phy_info->phy_stat_flag.duplex = phy_val->duplex;
    phy_info->phy_stat_flag.linkup_media = phy_val->linkup_media;
    /*When link is down, not update flow ctrl*/
    if(phy_val->link_up == GLB_LINK_UP)
    {
        phy_info->phy_stat_flag.flowctrl.send = phy_val->flowctrl.send;
        phy_info->phy_stat_flag.flowctrl.recv = phy_val->flowctrl.recv;
    }
    
    return RESULT_OK;
}

/* modified by liuht for bug 26641, 2014-0422 */
/* get current phy status */
int32 qt2x25_cur_status(phy_handle_t* phy_handle, glb_phy_state_t *phy_val)
{
    _xgphy_qt2x25_status_get(phy_handle, phy_val);
    return 0;
}
/* end of liuht modified */

/*Fix bug 14685. jqiu 2011-06-01. support loopback.*/
int32 qt2x25_config_loopback(phy_handle_t* phy_handle, uint8 lb_mode)
{
    phyreg_param_t phyreg_para;    
    uint16 value;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    switch (lb_mode)
    {
    case GLB_LB_NONE:
        /*clear near loopback*/
        phyreg_para.dev_no = 1;
        phyreg_para.dat.regaddr16 = 0x0;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
        value &= 0xfffe;
        phy_handle->reg_write(phy_handle, &phyreg_para, value); 
        /*clear far loopback*/
        phyreg_para.dev_no = 4;
        phyreg_para.dat.regaddr16 = 0x0;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
        GLB_CLEAR_BIT(value, 14);
        phy_handle->reg_write(phy_handle, &phyreg_para, value); 
        break;
    case GLB_LB_PHY_FAR:
        /*update far loopback from PMA to XGXS, for syncE need clock recover.*/
        phyreg_para.dev_no = 4;
        phyreg_para.dat.regaddr16 = 0x0;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
        GLB_SET_BIT(value, 14); 
        phy_handle->reg_write(phy_handle, &phyreg_para, value); 
        break;
    case GLB_LB_PHY_NEAR:
        phyreg_para.dev_no = 1;
        phyreg_para.dat.regaddr16 = 0x0;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
        value |= 1; 
        phy_handle->reg_write(phy_handle, &phyreg_para, value); 
        break;
    default:
        return RESULT_ERROR;
    }    
    return RESULT_OK;
}
int32 qt2x25_config_medium(phy_handle_t* phy_handle, uint8 mac_if, uint8 media_if)
{
    int32 ret = RESULT_OK;
    phy_info_t *pphy_info;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    pphy_info = &phy_handle->phy_info;
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,
        "QT2x25 phy addr %d config medium mac_if %d media_if %d", pphy_info->port.phy_addr, mac_if, media_if);
    ret = qt2x25_phy_reset(phy_handle, mac_if, media_if, 0);
    /*After medium config, speed/duplex/loopback need re-config. */
    if(GLB_LB_NONE != pphy_info->phy_manage_info.lb_mode)
    {
        ret |= qt2x25_config_loopback(phy_handle, pphy_info->phy_manage_info.lb_mode);
    }
    /*Fix bug30023. After medium config, enable need re-config*/
    if(0 == pphy_info->phy_manage_info.enable)
    {
        ret |= qt2x25_enable(phy_handle, 0);
    }
    return ret;    
}

int32 qt2x25_config_flowctrl(phy_handle_t* phy_handle, uint8 symmetric, uint8 asymmetric)
{
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

int32 qt2x25_enable_syncE(phy_handle_t* phy_handle, int8 enable)
{
    phyreg_param_t phyreg_para;
    uint16 value;
    
    if(enable)
    {
        /*enable XPLLOUT_CLK_EN */
        phyreg_para.dev_no = 1;
        phyreg_para.dat.regaddr16 = 0xc0fd;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
        GLB_SET_BIT(value, 1);
        phy_handle->reg_write(phy_handle, &phyreg_para, value);
    }
    else
    {
        /*disable XPLLOUT_CLK_EN */
        phyreg_para.dev_no = 1;
        phyreg_para.dat.regaddr16 = 0xc0fd;
        phy_handle->reg_read(phy_handle, &phyreg_para, &value); 
        GLB_CLEAR_BIT(value, 1);
        phy_handle->reg_write(phy_handle, &phyreg_para, value);
    }
    return RESULT_OK;
}

int32 phy_update_qt2225_handle(phy_handle_t* phdl, phy_info_t* p_phyinfo)
{
    sal_memcpy(&phdl->phy_info, p_phyinfo, sizeof(phy_info_t));
    phdl->phy_init = qt2x25_init;
    phdl->config_enable = qt2x25_enable;    
    phdl->get_link_poll = qt2x25_link_poll;    
    phdl->get_link_interupt = qt2x25_link_interrupt;
    phdl->get_cur_status = qt2x25_cur_status; /* modified by liuht for bug 26641, 2014-0422 */
    phdl->enable_syncE = qt2x25_enable_syncE;
    phdl->reg_read = qt2x25_reg_read;
    phdl->reg_write = qt2x25_reg_write;
    return RESULT_OK;
}

phy_handle_t* phy_qt2x25_dev_register(phy_info_t* pphy_info)
{
    phy_handle_t* phdl = NULL;
    mdio_handle_t* p_mdio_hdl = NULL;
    mdio_info_t mdio_info;

    sal_memset(&mdio_info, 0, sizeof(mdio_info));
    
    if(NULL == pphy_info)
    {
        return NULL;
    }
    
    phdl = (phy_handle_t* )DRV_CALLOC(CTCLIB_MEM_DRIVER_PHY_INFO, sizeof(phy_handle_t));
    if(NULL == phdl)
    {
        DRV_LOG_ERR("malloc failed");
        return NULL;
    }

    sal_memcpy(&phdl->phy_info, pphy_info, sizeof(phy_info_t));

    phdl->phy_init = qt2x25_init;
    phdl->config_enable = qt2x25_enable;
    phdl->config_medium = qt2x25_config_medium;
    phdl->config_loopback = qt2x25_config_loopback;
    phdl->config_flowctrl = qt2x25_config_flowctrl;
    phdl->get_link_poll = qt2x25_link_poll;    
    phdl->get_link_interupt = qt2x25_link_interrupt;
    phdl->get_cur_status = qt2x25_cur_status; /* modified by liuht for bug 26641, 2014-0422 */
    phdl->enable_syncE = qt2x25_enable_syncE;
    phdl->reg_read = qt2x25_reg_read;
    phdl->reg_write = qt2x25_reg_write;

    mdio_info.base_addr = pphy_info->base_addr;
    mdio_info.bus_type  = pphy_info->mdio_bus;
    p_mdio_hdl = mdio_create_handle(&mdio_info);
    
    if( NULL == p_mdio_hdl)
    {
        goto err_out;
    }
    
    phdl->mdio_hdl = p_mdio_hdl;
 
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_PHY_INFO, phdl);
        phdl = NULL;
    }

    return NULL;
}
