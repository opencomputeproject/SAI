/****************************************************************************
* $Id$
* phy Null device driver
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jqiu 
* Date          : 2013-03-18
* Reason        : First Create.
****************************************************************************/
#include "sal_common.h"
#include "drv_debug.h"
#include "glb_phy_define.h"
#include "glb_hw_define.h"
#include "phy_null.h"
#include "ctc_api.h"
#include "epld_api.h"
#include "fiber_api.h"

int32 phy_null_enable(phy_handle_t* phy_handle, int8 enable)
{
    int32 ret=0;
    phy_info_t *pphy_info;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;
    ret = ctc_port_set_mac_en(pphy_info->port.port_info.port_id, enable);
    if(ret == CTC_E_PORT_MAC_IS_DISABLE)
        return RESULT_OK;
    return ret;
}
/*bug32103 jqiu 20150305. change serdes mode when config speed.*/
int32 phy_null_config_speed(phy_handle_t* phy_handle, uint8 speed)
{
    int32 ret = 0;
    uint8 i, serdes_cfg_loop=1;
    phy_info_t *pphy_info;
    ctc_chip_serdes_info_t serdes_info;
    
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;

#ifdef _DRV_OSP_
    if(speed == GLB_SPEED_100G)
    {
#ifdef GOLDENGATE
        serdes_info.serdes_mode = CTC_CHIP_SERDES_CG_MODE;
        serdes_cfg_loop = 4;
#endif
    }
    else if(speed == GLB_SPEED_40G)
    {
#ifdef GOLDENGATE
        serdes_info.serdes_mode = CTC_CHIP_SERDES_XLG_MODE;  
        serdes_cfg_loop = 4;
#endif
    }
#else
    if(speed == GLB_SPEED_100G)
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_CG_MODE;
        serdes_cfg_loop = 4;
    }
    else if(speed == GLB_SPEED_40G)
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_XLG_MODE;
        serdes_cfg_loop = 4;
    }
#endif /* !_DRV_OSP_ */
    else if(speed == GLB_SPEED_10G)
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_XFI_MODE;        
    }
#ifdef GOLDENGATE
    else if(speed == GLB_SPEED_1G)
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_SGMII_MODE;
    }
#else
    else if(speed == GLB_SPEED_1G)
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_XSGMII_MODE;
    }
#endif
    else if(speed == GLB_SPEED_100M)
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_SGMII_MODE;
    }
    else
    {
        serdes_info.serdes_mode = CTC_CHIP_SERDES_SGMII_MODE;
    }
    
    /*When change serdes mode, must disable port first.*/
    ret = ctc_port_set_mac_en(pphy_info->port.port_info.port_id, 0);
    if(ret == CTC_E_PORT_MAC_IS_DISABLE)
    {
        ret = 0;
    }
    for(i=0; i<serdes_cfg_loop; i++)
    {
        serdes_info.serdes_id = pphy_info->port.port_info.serdes_id+i;
        ret += ctc_chip_set_serdes_mode(pphy_info->port.port_info.lchip, &serdes_info);
    }
    /*bug 33648 jqiu 2015-06-02. If phy has next handle and enable=1, phy must be force
      enable, so set sigdet to 1. This is used for 10/100/1000 copper SFP, when use this 
      kind of sfp, phy_null must be enable always.*/
    if((NULL != pphy_info->next_phy_hdl)&&(pphy_info->phy_manage_info.enable))
    {
        pphy_info->phy_stat_flag.sig_det = 1;
    }
    /* Fix bug32927, enable MAC per global enable status and sig_det after serdes dynamic switch
     * qicx, 2015-04-22 */
    ret += phy_null_enable(phy_handle, pphy_info->phy_manage_info.enable);
    if(speed == GLB_SPEED_100M)
    {
        ctc_port_set_speed(pphy_info->port.port_info.port_id, CTC_PORT_SPEED_100M);
    }

    if((speed == GLB_SPEED_1G)&&(GLB_DUPLEX_FULL==pphy_info->phy_manage_info.duplex))
    {
        ret += ctc_port_set_auto_neg(pphy_info->port.port_info.port_id, 0);
    }
    /* modified by liuht for bug 32360, 2015-0402 */
    else if((speed == GLB_SPEED_1G)&&(GLB_DUPLEX_AUTO==pphy_info->phy_manage_info.duplex))
    {
        ret += ctc_port_set_auto_neg(pphy_info->port.port_info.port_id, 1);
    }

    return ret;
}

/*bug32103 jqiu 20150305. change auto-mode when change duplex.*/
int32 phy_null_config_duplex(phy_handle_t* phy_handle, uint8 duplex)
{
    int32 ret = 0;
    phy_info_t *pphy_info;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;

    if((pphy_info->phy_manage_info.speed == GLB_SPEED_1G)&&(GLB_DUPLEX_FULL==duplex))
    {
        ret = ctc_port_set_auto_neg(pphy_info->port.port_info.port_id, 0);
    }
    /* modified by liuht for bug 32360, 2015-0402 */
    else if((pphy_info->phy_manage_info.speed == GLB_SPEED_1G)&&(GLB_DUPLEX_AUTO==duplex))
    {
        ret = ctc_port_set_auto_neg(pphy_info->port.port_info.port_id, 1);
    }

    return ret;
}

int32 phy_null_config_flowctrl(phy_handle_t* phy_handle, uint8 symmetric, uint8 asymmetric)
{
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

int32 phy_null_config_medium(phy_handle_t* phy_handle, uint8 mac_if, uint8 media_if)
{
    return RESULT_OK;
}

int32 phy_null_get_cur_status(phy_handle_t* phy_handle, glb_phy_state_t *phy_val)
{
    phy_info_t *pphy_info;
    int is_up, link_up;
    //uint32 los=0;
    //uint32 new_detect = TRUE;
    uint16 gport;
    int32 ret = RESULT_OK;

    if (NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    pphy_info = &phy_handle->phy_info;
    gport = pphy_info->port.port_info.port_id;
    /*When disable, GB get mac linkup function will access fail.*/
    if(pphy_info->phy_manage_info.enable)
    {
        ret = ctc_port_get_mac_link_up(gport, &is_up);
    }
    else
    {
        is_up = GLB_LINK_DOWN;
    }
    if(is_up)
    {
        link_up = GLB_LINK_UP;
    }
    else
    {
        link_up = GLB_LINK_DOWN;
    }
#ifdef GOLDENGATE 
    if(pphy_info->phy_stat_flag.link_up != link_up)
    {
        if(is_up)
        {
            ctc_port_set_property(gport,CTC_PORT_PROP_LINK_INTRRUPT_EN,TRUE);
        }
        else
        {
            ctc_port_set_property(gport,CTC_PORT_PROP_LINK_INTRRUPT_EN,FALSE);
        }
    }
#endif
    phy_val->link_up = link_up;
    phy_val->speed = (pphy_info->phy_manage_info.speed==GLB_SPEED_AUTO)?GLB_SPEED_1G:pphy_info->phy_manage_info.speed;
    phy_val->duplex = GLB_DUPLEX_FULL;
    phy_val->linkup_media = GLB_PORT_TYPE_FIBER;
    phy_val->flowctrl.recv = phy_handle->phy_info.phy_manage_info.flowctrl.recv;
    phy_val->flowctrl.send = phy_handle->phy_info.phy_manage_info.flowctrl.send;
    return ret;
}

int32 phy_null_get_link_poll(phy_handle_t* phy_handle, glb_phy_state_t* phy_val, 
                            phy_state_change_t* phy_change)
{
    phy_info_t *pphy_info;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;
    phy_null_get_cur_status(phy_handle, phy_val);
    
    /*link change from down to up*/
    if((pphy_info->phy_stat_flag.link_up != phy_val->link_up)
        &&(phy_val->link_up != GLB_LINK_DOWN))
    {
        phy_change->action = 1;
        if(pphy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
            pphy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
        {
            phy_change->flowctrl_change = 1;
        }
        /*bug 30833, 2014-11-20 When use GB fast link, only can enable intr when link is up*/
        if(pphy_info->fast_link)
            ctc_port_set_link_intr(pphy_info->port.port_info.port_id, 1);
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null addr %d link up",pphy_info->port.port_info.port_id) 
    }
    /*link change from up to down*/
    else if((pphy_info->phy_stat_flag.link_up != phy_val->link_up)
        &&(phy_val->link_up == GLB_LINK_DOWN))
    {
        phy_change->action = 0;
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null addr %d link down",pphy_info->port.port_info.port_id) 
        /*bug 30833, 2014-11-20 When use GB fast link, must disable intr when link is down, or it will report intr continully*/
        if(pphy_info->fast_link)
           ctc_port_set_link_intr(pphy_info->port.port_info.port_id, 0); 
    }
    /*link always up*/
    else if(phy_val->link_up == GLB_LINK_UP)
    {
        phy_change->action = -1;
        if(pphy_info->phy_stat_flag.speed != phy_val->speed)
        {            
            phy_change->speed_change = 1;
        }
        if(pphy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
            pphy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
        {
            phy_change->flowctrl_change = 1;
        }
    }
    /*link always down*/
    else
    {
        phy_change->action = -1;
    }
    pphy_info->phy_stat_flag.link_up = phy_val->link_up;
    pphy_info->phy_stat_flag.speed = phy_val->speed;
    pphy_info->phy_stat_flag.duplex = phy_val->duplex;
    pphy_info->phy_stat_flag.linkup_media = phy_val->linkup_media;
    /*When link is down, not update flow ctrl*/
    if(phy_val->link_up == GLB_LINK_UP)
    {
        pphy_info->phy_stat_flag.flowctrl.send = phy_val->flowctrl.send;
        pphy_info->phy_stat_flag.flowctrl.recv = phy_val->flowctrl.recv;
    }

    return RESULT_OK;

}

int32 
phy_null_config_phy_sig_test_mode(phy_handle_t* phy_handle, uint8 serdes_id, uint8 mode)
{
// TODO: by weij for merge GB trunk to GG
#if 0
    ctc_chip_serdes_reg_access_t reg_access;
    
    if(mode == PHY_SIG_TEST_MODE_NORMAL)
    {
        reg_access.serdes_id = serdes_id;
        reg_access.direction = 1;
        reg_access.addr = 1;
        reg_access.value = 0;
        ctc_chip_set_property(0, CTC_CHIP_REG_ACCESS, (void *)&reg_access);
    }
    else if(mode == PHY_SIG_TEST_MODE_PRBS9)
    {
        reg_access.serdes_id = serdes_id;
        reg_access.direction = 1;
        reg_access.addr = 1;
        reg_access.value = 0x1008;
        ctc_chip_set_property(0, CTC_CHIP_REG_ACCESS, (void *)&reg_access);
    }
    else if(mode == PHY_SIG_TEST_MODE_PRBS31)
    {
        reg_access.serdes_id = serdes_id;
        reg_access.direction = 1;
        reg_access.addr = 1;
        reg_access.value = 0xe;
        ctc_chip_set_property(0, CTC_CHIP_REG_ACCESS, (void *)&reg_access);
    }
#endif
    return RESULT_OK;
}

phy_handle_t* phy_null_dev_register(phy_info_t* pphy_info)
{
    phy_handle_t* phdl = NULL;
    
    if(NULL == pphy_info)
    {
        return NULL;
    }
    
    phdl = (phy_handle_t* )DRV_CALLOC(CTCLIB_MEM_DRIVER_PHY_INFO, sizeof(phy_handle_t));
    if(NULL == phdl)
    {
        DRV_LOG_ERR("malloc failed");
        return NULL;
    }

    sal_memcpy(&phdl->phy_info, pphy_info, sizeof(phy_info_t));

    phdl->config_enable = phy_null_enable;
    phdl->config_speed = phy_null_config_speed;
    phdl->config_duplex = phy_null_config_duplex;
    phdl->config_medium = phy_null_config_medium;
    phdl->config_flowctrl = phy_null_config_flowctrl;
    phdl->get_link_poll = phy_null_get_link_poll;
    phdl->config_master_slave= NULL;
    phdl->get_cur_status = phy_null_get_cur_status; /* modified by liuht for bug 26641, 2014-0422 */
    phdl->config_phy_sig_test_mode = phy_null_config_phy_sig_test_mode;
    return phdl;
}




