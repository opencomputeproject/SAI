#ifndef __PHY_QT2X25_DRV__
#define __PHY_QT2X25_DRV__

#include "phy_drv.h"

phy_handle_t* phy_qt2x25_dev_register(phy_info_t* pphy_info);
int32 phy_update_qt2225_handle(phy_handle_t* phdl, phy_info_t* p_phyinfo);


#endif /* __PHY_QT2X25_DRV__ */
