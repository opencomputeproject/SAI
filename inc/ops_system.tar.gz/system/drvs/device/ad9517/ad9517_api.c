/****************************************************************************
 * ad9517_api.c    ad9517 api 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2010-08-07.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "ad9517_api.h"
#include "ad9517_drv.h"
#include "ad9517_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/


/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
/* ad9517 handler */
static ad9517_handle_t **g_ad9517_hdl;


/****************************************************************************
 *
* Functions  
*
****************************************************************************/

/*********************************************************************
 * Name    : ad9517_dev_init
 * Purpose :  configuration ad9517
 * Input   : uint32 idx         - the index of ad9517, usually index = 0
          uint32 clock_type     - the flag of clock type, such as richmod type, 
                                  humber type and 10G phy type etc
                              
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9517_dev_init(uint32 idx, uint32 clock_type)
{
    return 0;
    
    int32 ret = 0;
    uint32 val = 0;
    uint8 mask = 0;
    uint8 time = 10;
    
    mask = (0x1<<AD_VCO_CAL_FINISHED)|(0x1<<AD_DIGITAL_LOCK);

    ret += ad9517_write(idx, 0x0, 0x99); 
    ret += ad9517_write(idx, 0x10, 0x7c); 
    ret += ad9517_write(idx, 0x13, 0x4 ); 
    ret += ad9517_write(idx, 0x14, 0x6); 
    ret += ad9517_write(idx, 0x16, 0x5); 
    ret += ad9517_write(idx, 0x18, 0x7); 
    ret += ad9517_write(idx, 0x1b, 0xe3); 
    ret += ad9517_write(idx, 0x1c, 0x2); 

    if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0xf1, 0x8); 
    }

     if(clock_type == E_AD9517_CLOCK_TYPE_3)
    {
        ret += ad9517_write(idx, 0xf5, 0x8); 
    }
          
    ret += ad9517_write(idx, 0x1e0, 0x0); 
    ret += ad9517_write(idx, 0x1e1, 0x2 ); 
    
    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x140, 0x5b); 
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x140, 0x5a); 
    }
    else if(clock_type == E_AD9517_CLOCK_TYPE_2)
    {
        ret += ad9517_write(idx, 0x140, 0x4a); 
    }

    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x141, 0x5b); 
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x141, 0x5a); 
    }
    
    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x142, 0x5a);     
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x142, 0x4b);     
    }
    else if(clock_type == E_AD9517_CLOCK_TYPE_2)
    {
        ret += ad9517_write(idx, 0x142, 0x43);     
    }

    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x143, 0x4a); 
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x143, 0x5a); 
    }
              
    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x190, 0x99); 
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_2) 
          || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x190, 0x33); 
    }
        
    ret += ad9517_write(idx, 0x191, 0x0 ); 

    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x196, 0x99);     
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x196, 0x33);     
    }

    if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x199, 0x99);     
    }
    else if(clock_type == E_AD9517_CLOCK_TYPE_2)
    {
        ret += ad9517_write(idx, 0x199, 0xbc);     
    }
    
    ret += ad9517_write(idx, 0x19c, 0x20 ); 

    
    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x19e, 0x21);      
    }
    else if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x19e, 0xcb);      
    }

    if(clock_type == E_AD9517_CLOCK_TYPE_0)
    {
        ret += ad9517_write(idx, 0x1a0, 0x44);    
    }    
    
    if((clock_type == E_AD9517_CLOCK_TYPE_1) || (clock_type == E_AD9517_CLOCK_TYPE_3))
    {
        ret += ad9517_write(idx, 0x1a1, 0x20);    
    } 
    
    ret += ad9517_write(idx, 0x232, 0x1 ); 
    ret += ad9517_write(idx, 0x18, 0x6); 
    ret += ad9517_write(idx, 0x232, 0x1 ); 
    ret += ad9517_write(idx, 0x18, 0x7); 
    ret += ad9517_write(idx, 0x232, 0x1 ); 
    sal_udelay(1000);
    ret += ad9517_read(idx, 0x1f, (uint32 *)(&val)); 
    while((mask != (val&mask))&&(--time))
    {        
        sal_udelay(1000);
        ret += ad9517_read(idx, 0x1f, (uint32 *)(&val)); 
    }
  
    if(!time)
        return AD9517_E_TIMEOUT;
    
    return ret;    
}

/*********************************************************************
 * Name    : ad9517_read
 * Purpose :  read ad9517 register
 * Input   : uint32 idx         - the index of ad9517, usually index = 0
          uint16 addr           - the address of ad9517 internal register 
          uint32 *val           - the pointer of read value
                              
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ad9517_read(uint32 idx, uint16 addr, uint32  *val)
{
    ad9517_access_t ad9517_access;

    DRV_CTC_CHK_PTR(val);

    DRV_CTC_CHK_PTR(g_ad9517_hdl[idx]);
    
    ad9517_access.addr= addr;
    ad9517_access.val = val;

    DRV_LOG_DEBUG(clkgen, DRV_CLK_GEN_READ, "ad9517_read %d, addr %d, val pointer %p",
                            idx, ad9517_access.addr, ad9517_access.val);
    
    return g_ad9517_hdl[idx]->read(g_ad9517_hdl[idx], &ad9517_access);
}

/*********************************************************************
 * Name    : ad9517_write
 * Purpose :  write ad9517 register
 * Input   : uint32 idx         - the index of ad9517, usually index = 0
          uint16 addr           - the address of ad9517 internal register 
          uint32 val            - write value 
                              
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ad9517_write(uint32 idx, uint16 addr, uint32  val)
{
    ad9517_access_t ad9517_access;
    
    DRV_CTC_CHK_PTR(g_ad9517_hdl[idx]);
    
    ad9517_access.addr= addr;
    ad9517_access.val = &val;

    DRV_LOG_DEBUG(clkgen, DRV_CLK_GEN_WRITE, "ad9517_write %d, addr %d, val pointer %p",
                            idx, ad9517_access.addr, ad9517_access.val);
    
    return g_ad9517_hdl[idx]->write(g_ad9517_hdl[idx], &ad9517_access);
}

/*********************************************************************
 * Name    : ad9517_close
 * Purpose :  free memory and pointer
 * Input   : uint32 idx     - the index of ad9517, usually index = 0
          
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9517_close(uint32 idx)
{
    DRV_CTC_CHK_PTR(g_ad9517_hdl[idx]);
    
    return g_ad9517_hdl[idx]->close(g_ad9517_hdl[idx]);
}

/*********************************************************************
 * Name    : ad9517_init
 * Purpose :  init some data structure and config ad9517
 * Input   : spi_gen_t *spi_gen     - some info about the way of ad9517'spi bus implement
          uint32 num         - the number of ad9517
          uint32 clock_type   - 
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/
int32 
ad9517_init(spi_gen_t *spi_gen, uint32 num, uint32 clock_type)
{
    int32 i = 0;
    int32 ret;
    
    DRV_CTC_CHK_PTR(spi_gen);
    
    g_ad9517_hdl = (ad9517_handle_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_AD9517_INFO,sizeof(ad9517_handle_t *)*num);
    if(NULL == g_ad9517_hdl)
    {
        DRV_LOG_ERR("AD9517 alloc handler fail!\n");
        return AD9517_E_INVALID_PTR;
    }

    for (i = 0; i < num; i++)
    {
        g_ad9517_hdl[i] = ad9517_register(E_AD9517_SPI, (const void *)&spi_gen[i]);
    }

    for (i = 0; i < num; i++)
    {
        ret = ad9517_dev_init(i, clock_type);
        if(ret != 0)
        {
            DRV_LOG_ERR("AD9517 dev init fail!\n");
            return AD9517_E_INIT_FAILED;        
        }
    }
    
    return AD9517_SUCCESS;
}



