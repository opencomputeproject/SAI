/****************************************************************************
 * $Id$
 *  AD9517 err
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Jcao
 * Date          : 2010-08-07 
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __AD9517_ERR_H__
#define __AD9517_ERR_H__
enum ad9517_error_e
{
    AD9517_SUCCESS = 0,
    AD9517_E_ERROR = -999,
    AD9517_E_NO_MEMORY,
    AD9517_E_NOT_INIT,
    AD9517_E_INIT_FAILED,
    AD9517_E_TIMEOUT,    
    AD9517_E_READ,    
    AD9517_E_WRITE,
    /* parameter check error */
    AD9517_E_INVALID_PARAM,
    AD9517_E_INVALID_PTR,
    AD9517_E_INVALID_INDEX,    
    AD9517_E_INVALID_LENGTH,
    AD9517_E_INVALID_CHIP,

};

#endif /*!__AD9517_ERR_H__*/
