/****************************************************************************
* $Id$
* B330 driver
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : wus
* Date          : 2011-07-30
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "poe_drv.h"
#include "drv_debug.h"

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
static int32
poe_i2c_read(poe_hdl_t* poe_hdl, poe_para_t* poe_para)
{
    i2c_handle_t* i2c_hdl = NULL;
    i2c_op_para_t op_para = {0};
    int32 ret;

    if(NULL == poe_hdl || NULL == poe_para)
    {
        DRV_LOG_ERR("POE poe_i2c_read: Invalid parameter.");
        return RESULT_ERROR;
    }

    i2c_hdl = poe_hdl->i2c_hdl;
    if(NULL == i2c_hdl || NULL == i2c_hdl->read)
    {
        DRV_LOG_ERR("POE poe_i2c_read: Invalid ptr.");
        return RESULT_ERROR;
    }

    op_para.offset = poe_para->offset;
    op_para.len = poe_para->len;
    op_para.p_val = poe_para->val;
    
    ret = i2c_hdl->read(i2c_hdl, &op_para);

    /*DRV_LOG_DEBUG(poe, DRV_POE_READ, "Read I2C POE: len %d, offset %x, val[0] %d, val[1] %d, ret %d\n",
        op_para.len, op_para.offset, *op_para.p_val, *(op_para.p_val+1), ret);*/
    if(ret < 0)
    {
        DRV_LOG_ERR("POE poe_i2c_read: i2c read failed.");
        return RESULT_ERROR;
    }

    return RESULT_OK;
}

static int32 
poe_i2c_write(poe_hdl_t* poe_hdl, poe_para_t* poe_para)
{
    i2c_handle_t* i2c_hdl = NULL;
    i2c_op_para_t op_para;
    int32 ret;

    if(NULL == poe_hdl || NULL == poe_para)
    {
        DRV_LOG_ERR("POE poe_i2c_write: Invalid parameter");
        return RESULT_ERROR;
    }

    i2c_hdl = poe_hdl->i2c_hdl;
    op_para.offset = poe_para->offset;
    op_para.len = poe_para->len;
    op_para.p_val = poe_para->val;

    ret = i2c_hdl->write(i2c_hdl, &op_para);
    /*DRV_LOG_DEBUG(poe, DRV_POE_WRITE, "Write I2C POE: len %d, offset %x, val[0] %d, val[1] %d, ret %d\n",
        op_para.len, op_para.offset, *op_para.p_val, *(op_para.p_val+1), ret);*/    
    if(ret < 0)
    {
        DRV_LOG_ERR("POE poe_i2c_write: i2c write failed.");
        return RESULT_ERROR;
    }

    return RESULT_OK;
}

int32 
poe_select_cfg_mode(poe_hdl_t* poe_hdl, poe_cfg_key_t mode)
{
    int32 ret = 0;
    poe_para_t para = {0};
    uint8 data[2] = {0};

    if(NULL == poe_hdl)
    {
        DRV_LOG_ERR("POE poe_select_cfg_mode: Invalid parameter.");
        return RESULT_ERROR;
    }
    para.len = 2;
    para.val = data;    
    para.offset = POE_SOFT_CFG_REG;
    if(mode == POE_CFG_MODE)
    {
        data[0] = 0xdc;
        data[1] = 0x3;
    }
    else
    {
        data[0] = 0xdc;
        data[1] = 0x0;
    }
    ret += poe_hdl->reg_write(poe_hdl, &para);

    para.offset = POE_COM_EXTER_SYNC_REG;
    data[0] = 0x0;
    data[1] = 0x20;
    ret += poe_hdl->reg_write(poe_hdl, &para);

    para.offset = POE_EXTER_INTR_EVENT_REG_FOR_SYNC_REG;
    data[0] = 0x0;
    data[1] = 0x20;
    ret += poe_hdl->reg_write(poe_hdl, &para);

    para.offset = POE_SOFT_CFG_REG;
    ret += poe_hdl->reg_read(poe_hdl, &para);

    if(mode == POE_CFG_MODE)
    {
        if(data[0] != 0x0 || data[1] != 0x3)
        {
            DRV_LOG_ERR("poe_select_cfg_mode: expect value 0x0003 data[0] %d, data[1] %d\n",
                data[0], data[1]);
            return RESULT_ERROR;
        }
    }
    else
    {
        if(data[0] != 0x0 || data[1] != 0x0)
        {
            DRV_LOG_ERR("poe_select_cfg_mode: expect value 0x0000 data[0] %d, data[1] %d\n",
                data[0], data[1]);
            return RESULT_ERROR;
        }
    }

    return ret;
}


static int32
poe_chip_enable(poe_hdl_t* poe_hdl, poe_admin_t enable)
{
    poe_port_info_t* port_info;
    poe_para_t para;
    int32 chip_port_idx;
    uint32 reg_val;
    uint8 data[2];
    int32 ret = 0;
    
    if(NULL == poe_hdl)
    {
        DRV_LOG_ERR("POE enalbe: Invalid parameter.");
        return RESULT_ERROR;
    }

    para.len = 2;
    para.offset = POE_ALL_PORT_ADMIN_REG;
    para.val = data;

    if(enable == POE_ENABLE)
    {
        port_info = poe_hdl->port_info;
        reg_val = 0x0; /* bit val == 0, means enable */
        /* As reg:POE_ALL_PORT_ADMIN_REG is also managed by system soft */
        for(chip_port_idx = 0; chip_port_idx < POE_CHIP_PORT; chip_port_idx++)
        {
            /* TODO: stat_info.ofer must by locked */
            if(POE_PD_PRIORITY_OFF == port_info[chip_port_idx].stat_info.oper ||
               POE_PD_OVL_OFF == port_info[chip_port_idx].stat_info.oper)
            {
                reg_val |= (0x1 << chip_port_idx);
            }
        }
        data[0] = (reg_val >> 8) & 0xff;
        data[1] = (reg_val) & 0xff;
    }
    else
    {
        data[0] = 0x0f;
        data[1] = 0xff;
    }
    
    ret += poe_hdl->reg_write(poe_hdl, &para);

    if(ret)
    {
        DRV_LOG_ERR("POE chip enable: reg write err.");
        return RESULT_ERROR;
    }   
    return RESULT_OK;
}

#if 0
static int32 
poe_chip_init(poe_hdl_t* poe_hdl)
{
    poe_para_t para;
    uint8 data[2];
    uint32 poe_total_budget;
    uint8 port_idx;
    int32 ret = 0;

    if(NULL == poe_hdl)
    {
        DRV_LOG_ERR("POE poe_chip_init: Invalid parameter.");
        return RESULT_ERROR;
    }

    para.len = 2;
    para.val = data;
   
    /* cfg locked reg sequence as follow: */
    /* 1.sys disable all ports */
    ret += poe_hdl->poe_chip_enable(poe_hdl,POE_DISABLE);
    sal_task_sleep(500);
    
    /* 2.change stand alone master/slave mode to cfg mode */
    ret += poe_select_cfg_mode(poe_hdl, POE_CFG_MODE);

    /* 3.start config */
    /* DC disconnect[0]=1, legacy disable [2]=1, INT Out[5]=0, Vmain discon if under 51V [9]=0 */
    /* info from FAE: dynamic mode: [6]=[4]=1, [11]=[10]=0, static mode: [6]=1, [4]=[11]=[10]=0 */
    /* defaut: static mode */
    para.offset = POE_PM_MODE_REG;
    ret += poe_hdl->reg_read(poe_hdl, &para);
    data[0] = (data[0] & (~0xe)) | 0x0;
    data[1] = (data[1] & (~0x75)) | 0x45;

    ret += poe_hdl->reg_write(poe_hdl, &para);

    /* Note: system max budget is from LCM */
    if(poe_hdl->chip_info.ctrl_level == POE_MASTER)
    {
        poe_total_budget = poe_hdl->sys_info.mgt_info.budget;
        para.offset = POE_SYS_POWER_BUDGET0_REG;
        data[0] = (((poe_total_budget + POE_SYS_BUDGET_REDUNDANCY) / 100) >> 8) & 0xff; /* (budget(mw)/1000 * 10)*/
        data[1] = ((poe_total_budget + POE_SYS_BUDGET_REDUNDANCY) / 100) & 0xff;
        ret += poe_hdl->reg_write(poe_hdl, &para);
    }

    /* Power Interface: Alternative A is pre_defined in reg:0x131a-30 by default */
    
    /* System Vmain High threshold 57V, Vmain AT Low threshold 44V */
    para.offset = POE_VMAIN_HIGH_TH_REG;
    data[0] = 0x3;
    data[1] = 0xa6;
    ret += poe_hdl->reg_write(poe_hdl, &para);

    data[0] = 0x2;
    data[1] = 0xd1;
    para.offset = POE_VMAIN_AT_LOW_TH_REG;
    ret += poe_hdl->reg_write(poe_hdl, &para);
    
    //para.offset = POE_VMAIN_AF_LOW_TH_REG;
    //ret += poe_hdl->reg_write(poe_hdl, &para);

    /* Alarm temperature is 70'C, Disconnection temperature is 95'C*/
    para.offset = POE_ALARM_TMPR_TH_REG;
    data[0] = 0x0;
    data[1] = 0xaf;
    ret += poe_hdl->reg_write(poe_hdl, &para);

    para.offset = POE_DISCON_TMPR_TH_REG;
    data[0] = 0x0;
    data[1] = 0xee;
    ret += poe_hdl->reg_write(poe_hdl, &para);

    /* init each port budget 30W + 2W */
    for(port_idx = 0; port_idx < POE_CHIP_PORT; port_idx++)
    {
        para.offset = POE_PORT0_POWER_ALLOC_LIMIT_REG + (2 * port_idx);
        data[0] = 0xff & ((30000 + POE_PORT_BUDGET_REDUNDANCY)/ 100 >> 8); /* milli-watt, reg value is (budget/1000*10) */
        data[1] = 0xff & ((30000 + POE_PORT_BUDGET_REDUNDANCY) / 100);
        ret += poe_hdl->reg_write(poe_hdl, &para);
    }
    /* 4.change cfg mode to stand alone master/slave mode */
    ret += poe_select_cfg_mode(poe_hdl, POE_MASTER_SLAVE_MODE);

    /* 5. enable all ports */
    ret += poe_hdl->poe_chip_enable(poe_hdl, POE_ENABLE);
    
    /* Interrupt event enable: must mask detection failed intr */
    para.offset = POE_INTR_EVENT_MASK_REG;
    data[0] = 0x00;
    data[1] = 0xfb;
    ret += poe_hdl->reg_write(poe_hdl, &para);

    return ret;
}
#endif

poe_hdl_t*
poe_dev_reg(poe_chip_info_t* poe_chip_info, poe_port_info_t* poe_port_info, poe_sys_info_t* poe_sys_info)
{
    i2c_handle_t* i2c_hdl;
    poe_hdl_t* poe_hdl;
    i2c_gen_t i2c_gen;
    int32 chip_port_id;

    if(NULL == poe_chip_info || NULL == poe_port_info || NULL == poe_sys_info)
    {
        DRV_LOG_ERR("POE poe_dev_reg: Invalid arguments.\n");
        return NULL;
    }

    sal_memset(&i2c_gen, 0, sizeof(i2c_gen_t));
    poe_hdl = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(poe_hdl_t));
    if(NULL == poe_hdl)
    {
        DRV_LOG_ERR("POE poe_dev_reg: out of memory.");
        return NULL;
    }
    
    sal_memcpy(poe_hdl->port_info, poe_port_info, sizeof(poe_port_info_t) * POE_CHIP_PORT);
    for(chip_port_id = 0; chip_port_id < POE_CHIP_PORT; chip_port_id++)
    {
        if(sal_mutex_create(&poe_hdl->port_info[chip_port_id].pmutex))
        {
            DRV_FREE(CTCLIB_MEM_DRIVER_POE_INFO, poe_hdl);
            return NULL;
        }
    }
    
    i2c_gen.i2c_type = E_I2C_CPM;
    i2c_gen.bridge_flag = 0;
    i2c_gen.alen = 2;
    i2c_gen.addr = poe_chip_info->base_addr;
    i2c_hdl = i2c_create_handle(&i2c_gen);

    if(NULL == i2c_hdl)
    {
        DRV_LOG_ERR("POE poe_dev_reg: i2c create hdl err.");
        DRV_FREE(CTCLIB_MEM_DRIVER_POE_INFO, poe_hdl);        
        return NULL;
    }
 
    if(poe_chip_info->ctrl_level == POE_MASTER)
    {
        sal_memcpy(&poe_hdl->sys_info, poe_sys_info, sizeof(poe_sys_info_t));
        if(sal_mutex_create(&poe_hdl->sys_info.pmutex))
        {
            DRV_FREE(CTCLIB_MEM_DRIVER_POE_INFO, poe_hdl);
            return NULL;
        }

        if(sal_mutex_create(&poe_hdl->sys_info.soft_pmutex))
        {
            DRV_FREE(CTCLIB_MEM_DRIVER_POE_INFO, poe_hdl);
            return NULL;
        }
    }
    else
    {
        sal_memset(&poe_hdl->sys_info, 0, sizeof(poe_sys_info_t));
    }

    poe_hdl->i2c_hdl = i2c_hdl;
    poe_hdl->chip_info.base_addr = poe_chip_info->base_addr;
    poe_hdl->chip_info.ctrl_level = poe_chip_info->ctrl_level;
    poe_hdl->reg_read = poe_i2c_read;
    poe_hdl->reg_write = poe_i2c_write;
    //poe_hdl->poe_chip_init = poe_chip_init;
    poe_hdl->poe_chip_enable = poe_chip_enable;

    return poe_hdl;    
}
