#ifndef __POE_DRV_H__
#define __POE_DRV_H__

#include "sal_common.h"
#include "sal_mutex.h"
#include "ctc_i2c.h"

#define POE_CHIP_PORT 12
#define POE_VMAIN_LOW_THRESHOLD  44
#define POE_VMAIN_NORMAL         50
#define POE_VMAIN_HIGH_THRESHOLD 57
#define POE_PORT_FORCE_POWER_BUDGET  15400
#define POE_PSU_ACCURACY         0.03
#define POE_SYS_BUDGET_REDUNDANCY 700800 /* 1440 - 739.2 = 700.8 */
#define POE_SYS_BUDGET 1536000
#define POE_PORT_BUDGET 32000
#define POE_PORT_BUDGET_REDUNDANCY 2000  /* note: each port budget must less than 32W*/

#define POE_SOFT_CFG_REG         0x139e
#define POE_COM_EXTER_SYNC_REG   0x1318
#define POE_EXTER_INTR_EVENT_REG_FOR_SYNC_REG    0x1144
#define POE_PM_MODE_REG          0x1160
#define POE_SYS_POWER_BUDGET0_REG   0x138c
#define POE_VMAIN_VOLTAGE_REG       0x105c
#define POE_VMAIN_HIGH_TH_REG     0x12fe
#define POE_VMAIN_AT_LOW_TH_REG    0x1300
#define POE_VMAIN_AF_LOW_TH_REG    0x1302
#define POE_INTR_EVENT_MASK_REG    0x13a4
#define POE_ALARM_TMPR_TH_REG   0x130e
#define POE_DISCON_TMPR_TH_REG  0x130c
#define POE_ALL_PORT_ADMIN_REG  0x1332
#define POE_SYS_TOTAL_REAL_POWER_CONS_REG   0x12e8
#define POE_SYS_SLAVE0_REAL_POWER_CONS_REG  0x12ec
#define POE_PORT_INTR_OUT_REG     0x13a6
#define POE_PORT0_CLASS_REG    0x11c2
#define POE_PORT0_STATUS_REG    0x11aa
#define POE_PORT0_POWER_CONS_REG    0x12b4
#define POE_PORT0_POWER_ALLOC_LIMIT_REG    0x1334
#define POE_PORT0_CFG_REG    0x131a
#define POE_CLEAR_INTR_REG   0x0324
#define POE_STARTUP_CMPL_VOL_THRES  0x11a8

typedef struct poe_timer_t {
    struct sal_timeval  timeout;
    struct sal_timeval  now;
} poe_timer_t;

#define POE_TIMER_START(timer,sec) { \
        sal_gettimeofday(&((timer)->timeout)); \
        (timer)->timeout.tv_sec += (sec);\
    }
#define POE_TIMER_TIMEOUT(timer) (((timer)->now.tv_sec > (timer)->timeout.tv_sec) || \
    (((timer)->timeout.tv_sec == (timer)->timeout.tv_usec) && ((timer)->now.tv_usec >= (timer)->timeout.tv_usec)))

typedef enum poe_port_intr_valid_e
{
    POE_PORT_INTR_INVALID = 0,
    POE_PORT_INTR_VALID,
    POE_PORT_INTR_MAX
} poe_port_intr_valid_t;

typedef enum poe_mgt_mode_e
{
    POE_MGT_MIN_MODE = 0,
    POE_MGT_SOFT_MODE,
    POE_MGT_HW_MODE
} poe_mgt_mode_t;

typedef enum poe_chip_card_present_e
{
    POE_CHIP_CARD_PRESENT = 0,
    POE_CHIP_CARD_NOT_PRESENT
} poe_chip_card_present_t;

typedef enum poe_psu_status_e
{
    POE_PSU_GOOD = 0,
    POE_PSU_FAIL
} poe_psu_status_t;

typedef enum poe_sys_led_e
{
    POE_SYS_LED_OFF = 0,
    POE_SYS_LED_ON
} poe_sys_led_t;

typedef struct poe_para_s
{
    uint32 offset;  /* I2C internal address */
    uint32 len;     /* data/addr length */
    uint8_t* val;   /* data/addr */
} poe_para_t;

typedef enum poe_cfg_key_e
{
    POE_CFG_MODE = 0,
    POE_MASTER_SLAVE_MODE,
    POE_CFG_KEY_NOT_DEFINED
} poe_cfg_key_t;

typedef enum poe_admin_e
{
    POE_ENABLE = 0,
    POE_DISABLE,
    POE_FORCE,
    POE_ADMIN_NOT_DEFINED
} poe_admin_t;

typedef enum poe_oper_e
{
    POE_PD_OFF = 0, /* POE off as admin off */
    POE_PD_ON,
    POE_PD_DETECTION,
    POE_PD_STARTUP_ERROR,
    POE_PD_POWERUP_ERROR,
    POE_PD_FORCE_READY,
    POE_PD_FORCE_ERROR,
    POE_PD_OVL_OFF,       /* POE off as overload */
    POE_PD_OVL,           /* POE chip detect OVL, but still power on */
    POE_PD_PRIORITY_OFF,  /* POE off as software priority calc */
    POE_PD_ERR_DISABLE_OFF, /* POE off as PD status changed frequently 8 times in 3s */
    POE_PD_UNKNOWN,
    POE_PD_OPER_MAX
} poe_oper_t;

typedef enum poe_port_priority_e
{
    POE_PORT_PRI_NONE = 0,
    POE_PORT_PRI_LOW,
    POE_PORT_PRI_HIGH,
    POE_PORT_PRI_CRITICAL,
    POE_PORT_PRI_MAX
} poe_port_priority_t;

typedef enum poe_ctrl_level_e
{
    POE_SLAVE = 0,
    POE_MASTER,
    POE_CTRL_LEVEL_NOT_DEFINED
} poe_ctrl_level_t;

typedef enum poe_pm_e
{
    POE_PM_STATIC = 0,
    POE_PM_DYNAMIC,
    POE_PM_NOT_DEFINED
} poe_pm_t;

/* IEEE standard class */
typedef enum poe_class_e
{
    POE_CLASS0 = 0,
    POE_CLASS1,
    POE_CLASS2,
    POE_CLASS3,
    POE_CLASS4,
    POE_CLASS_NOT_DEFINED
} poe_class_t;

typedef enum poe_legacy_cap_s
{
    POE_DISABLE_LEGACY_CAP = 0,
    POE_ENABLE_LEGACY_CAP,
    POE_LEGACY_CAP_NOT_DEFINED
} poe_legacy_cap_t;

typedef enum poe_daughter_card_work_mode_e
{
    POE_DAUGHTER_CARD_USER_MODE = 0,  /* used to normal user mode */
    POE_DAUGHTER_CARD_SIFOS_AT_MODE,  /* used to sifos AT test*/
    POE_DAUGHTER_CARD_SIFOS_AF_MODE   /* used to sifos AF test */
} poe_daughter_card_work_mode_t;

typedef struct poe_chip_info_s
{
    uint32 base_addr; /* I2C component address*/
    poe_ctrl_level_t ctrl_level; /* master or slave CHIP */
} poe_chip_info_t;

typedef struct poe_sys_mgt_info_s
{
    uint32 budget; /* system total supply power budget (milli-watt) */
    poe_pm_t pm;  /* poe power management mechanism */
    poe_legacy_cap_t legacy_cap;  /* system enable or disable POE legacy PD detection */
    uint32 budget_reserved; /* percentage, system security reserved budget */
    uint32 budget_warn_thrshd; /* percentage, system budget consumption's warn threshold */
} poe_sys_mgt_info_t;

typedef struct poe_port_mgt_info_s
{
    poe_admin_t admin; /* each port enable or disable POE */
    uint32 budget; /* port max supply power budget (milli-watt)*/
    poe_port_priority_t priority;
} poe_port_mgt_info_t;

typedef struct poe_sys_stat_info_s
{
    uint32 budget;  /* system max comsumption limit (milli-watt), accuracy 100 mw */
    uint32 cur_consump;   /* system total real time comsumption power (milli-watt)*/
    uint32 aver_consump;  /* count info */
    uint32 peak_consump;  /* count info */
    uint32 budget_reserved; /* percentage, from mgt info */
    uint32 budget_warn_threshold; /* percentage, from mgt info */
    poe_pm_t pm;  /* poe power management mechanism */
    poe_legacy_cap_t legacy_cap;  /* system enable or disable POE legacy PD detection */
    uint32 cur_volt;       /* current voltage (milli-volt) */
    uint32 aver_volt;      /* average voltage (milli-volt) */
    uint32 peak_volt;      /* peak voltage (milli-volt) */
} poe_sys_stat_info_t;

typedef struct poe_port_stat_s
{
    poe_admin_t admin; /* each port enable, disable or force POE */
    poe_oper_t oper; /* status: on | off | faulty | power-deny */
    poe_class_t class; /* IEEE af/at standard class0/1/2/3/4 */
    uint32 pre_consumption; /* used for PM calc */
    uint32 cur_consump; /* port consumption (milli-watt), accuracy 100 mw */
    uint32 aver_consump; /* average */ 
    uint32 peak_consump; /* history peak */
    uint32 budget; /* port consumption limit (milli-watt) */
    poe_port_priority_t priority;
} poe_port_stat_info_t;

typedef struct poe_item_tmp_store_s
{
    uint32 phase;      /* in which phase of item deal */
    uint32 tmp_val;    /* when start, store it. After complete it, used it*/
} poe_item_tmp_store_t;

typedef struct poe_port_info_s
{
    sal_mutex_t* pmutex;
    //uint8 poe_chip_port_idx; /* poe chip internal port idx */
    //int32 stat_change_interval; /* poll cnt: only operated by software mgt mdoe */
    int32 stat_change_cnt;     /* used to err-disable ,reset to 0 only val less than 8 in 3s */
    int32 punish_cnt_reduce;      /* only operated when port is punished */
    int32 punish_cnt;
    uint32 port_status_reg;    /* PD port status: chip reg val */
    poe_item_tmp_store_t port_admin_item;  /* used for storing the poe item deal*/
    poe_timer_t ovl_timer;         /* overload timer */
    poe_timer_t ovl_cnt_timer;     /**/
    poe_timer_t err_dis_timer;     /* err-disable timer */
    poe_port_mgt_info_t mgt_info;
    poe_port_stat_info_t stat_info;
} poe_port_info_t;

typedef struct poe_sys_info_s
{
    sal_mutex_t* pmutex;
    sal_mutex_t* soft_pmutex;
    poe_item_tmp_store_t pm_item;
    poe_item_tmp_store_t lega_item;
    int32 priority_off_cnt; /* the cnt of pri off ports */
    poe_sys_mgt_info_t mgt_info;
    poe_sys_stat_info_t stat_info;
} poe_sys_info_t;

typedef struct poe_panel_port_s
{
    uint8 chip_idx;
    uint8 poe_support;  /* 0 means not support, 1 means support */
    uint32 poe_addr;    /* each poe chip hdl is based on addr */ 
    uint8 logic_port_idx;
    uint8 poe_chip_port_idx; /* poe chip internal port idx */
} poe_panel_port_t;

typedef struct poe_hdl_s poe_hdl_t;
struct poe_hdl_s
{
    int32 (* reg_read)(poe_hdl_t*, poe_para_t* );
    int32 (* reg_write)(poe_hdl_t*, poe_para_t* );
    //int32 (* poe_chip_init)(poe_hdl_t*);
    int32 (* poe_chip_enable)(poe_hdl_t*, poe_admin_t );
    poe_chip_info_t chip_info;
    uint32 poe_chip_intr;  /* reg val: LSB 12 bit indicate the intr of each port */
    poe_port_info_t port_info[POE_CHIP_PORT]; /* Each POE chip supports 12 ports */
    poe_sys_info_t sys_info; /* system POE infomation */
    i2c_handle_t* i2c_hdl;    /* I2C BUS handle */
};


int32 poe_select_cfg_mode(poe_hdl_t* poe_hdl, poe_cfg_key_t mode);
poe_hdl_t* poe_dev_reg(poe_chip_info_t* poe_chip_info, poe_port_info_t* poe_port_info, poe_sys_info_t* poe_sys_info);
#endif

