/****************************************************************************
 * $Id$
 *  ds26503 err
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : liangf
 * Date          : 2013-08-17 
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __DS26503_ERR_H__
#define __DS26503_ERR_H__
enum ds26503_error_e
{
    DS26503_SUCCESS = 0,
    DS26503_E_ERROR = -999,
    DS26503_E_NO_MEMORY,
    DS26503_E_NOT_INIT,
    DS26503_E_INIT_FAILED,
    DS26503_E_TIMEOUT,    
    DS26503_E_READ,    
    DS26503_E_WRITE,
    /* parameter check error */
    DS26503_E_INVALID_PARAM,
    DS26503_E_INVALID_PTR,
    DS26503_E_INVALID_INDEX,    
    DS26503_E_INVALID_LENGTH,
    DS26503_E_INVALID_CHIP,

};

#endif /*!__ds26503_ERR_H__*/
