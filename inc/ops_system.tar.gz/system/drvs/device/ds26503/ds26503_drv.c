/****************************************************************************
 * ds26503_drv.c   ds26503 access interface
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       liangf
 * Date:         2013-08-17.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "ctc_spi.h"
#include "drv_debug.h"
#include "ds26503_drv.h"
#include "ds26503_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static ds26503_handle_t* ds26503_spi_create_handle();
static ds26503_handle_t* ds26503_spi_register(spi_gen_t* spi_pgen);

/****************************************************************************
 *
* Functions  
*
****************************************************************************/


/*********************************************************************
 * Name    : ds26503_spi_close
 * Purpose :  free memory and pointer
 * Input   : ds26503_handle_t *phdl       - the handler of the ds26503
          
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds26503_spi_close(ds26503_handle_t* phdl)
{
    spi_handle_t* spi_phdl = NULL;
    int32 ret = 0;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(phdl->handle);
    
    spi_phdl = (spi_handle_t*)phdl->handle;
    ret = spi_phdl->close(spi_phdl);

    DRV_FREE( CTCLIB_MEM_DRIVER_DS26503_INFO, phdl);
    phdl = NULL;

    return ret;
}

/*********************************************************************
 * Name    : ds26503_spi_write
 * Purpose :  write a spi type ds26503 register
 * Input   : const ds26503_handle_t *phdl       - the handler of the ds26503
          ds26503_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds26503_spi_write(const ds26503_handle_t* phdl, ds26503_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;
    uint32 value = 0;
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
    sal_memset(&spi_para, 0, sizeof(spi_op_para_t)); 
    /*0-000000-A7 A6-A0-0*/
    spi_para.addr= (DS26503_SPI_WRITE<<15) | (((paccess->addr) & 0xff) <<1)| (DS26503_SPI_ACCESS_MODE);
    value = *(paccess->val); 
    spi_para.val = &value;   

    //DRV_LOG_DEBUG(ds26503, DRV_DS26503_WRITE, "ds26503_spi_write addr %x, val %x",
    //                        spi_para.addr, *(spi_para.val));
    return spi_phdl->write(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ds26503_spi_read
 * Purpose :  read a spi type ds26503 register
 * Input   : const ds26503_handle_t *phdl       - the handler of the ds26503
          ds26503_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds26503_spi_read(const ds26503_handle_t* phdl, ds26503_access_t* paccess)
{   
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;    
    
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);

    sal_memset(&spi_para, 0, sizeof(spi_op_para_t));   
    spi_phdl = (spi_handle_t *)phdl->handle;
    /*1-000000-A7 A6-A0-0*/
    spi_para.addr= (DS26503_SPI_READ<<15) | (((paccess->addr) & 0xff) << 1) | (DS26503_SPI_ACCESS_MODE);
    spi_para.val = (paccess->val);

    //DRV_LOG_DEBUG(ds26503, DRV_DS26503_READ,"ds26503_spi_read addr %x, val %x",
    //                        spi_para.addr, *(spi_para.val));    

    return spi_phdl->read(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ds26503_spi_create_handle
 * Purpose :  create a ds26503 device handler
 * Input   : spi_handle_t *spi_phdl       - the handler of the spi bus layer          
                                       
 * Output  : N/A
 * Return  : the handler of the ds26503
          
 * Note    : N/A
*********************************************************************/

static ds26503_handle_t*
ds26503_spi_create_handle(spi_handle_t* spi_phdl)
{
    ds26503_handle_t* phdl = NULL; 
    
    DRV_CTC_CHK_PTR_NULL(spi_phdl);
    
    phdl = (ds26503_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_DS26503_INFO,sizeof(ds26503_handle_t));

    if (NULL == phdl)
    {
        goto err_out;
    }

    phdl->handle = (void *)spi_phdl;

    phdl->close = ds26503_spi_close;
    phdl->read = ds26503_spi_read;
    phdl->write = ds26503_spi_write;
    
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        DRV_FREE( CTCLIB_MEM_DRIVER_DS26503_INFO,phdl);
        phdl = NULL;
    }

    return NULL;
}

/*********************************************************************
 * Name    : ds26503_spi_register
 * Purpose :  register spi type ds26503
 * Input   : spi_gen_t *spi_pgen      - some info about the way of ds26503'spi bus implement, 
                                        such as gpio, fpga etc
                                       
 * Output  : N/A
 * Return  : the handler of the ds26503
          
 * Note    : N/A
*********************************************************************/

static ds26503_handle_t*
ds26503_spi_register(spi_gen_t* spi_pgen)
{
    spi_handle_t* spi_phdl = NULL;
    
    /* the spi ds26503 */
  
    spi_pgen->alen = DS26503_ADDRESS_LENTH;
    spi_pgen->len = DS26503_DATA_LENTH;
    
    spi_phdl = spi_create_handle(spi_pgen);

    return ds26503_spi_create_handle(spi_phdl);      
}


/*********************************************************************
 * Name    : ds26503_register
 * Purpose :  register a ds26503 device handler
 * Input   : const void *pgen        - some info about the way of ds26503'spi bus implement, 
                                       such as gpio, fpga etc
          ds26503_type_t type         - the type of accessing ds26503, now just have one type ds26503
          
 * Output  : N/A
 * Return  : the handler of the ds26503
           
 * Note    : N/A
*********************************************************************/

ds26503_handle_t*
ds26503_register(ds26503_type_t type, const void* pgen)
{       
    spi_gen_t* spi_pgen = (spi_gen_t*)pgen;
    
    DRV_CTC_CHK_PTR_NULL(pgen);
    
    switch(type)
    {
        case E_DS26503_SPI:           
            return ds26503_spi_register(spi_pgen);

        default:
            break;        
    }
    
    return NULL;
}


