/****************************************************************************
* $Id$
*  The header file of the ds26503 api.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : liangf
* Date          : 2013-08-17 
* Reason        : First Create.
****************************************************************************/
#ifndef __DS26503_API_H__
#define __DS26503_API_H__

#include "ctc_spi.h"

int32 ds26503_read(uint32 idx, uint8 addr, uint32  *val);
int32 ds26503_write(uint32 idx, uint8 addr, uint32  val);
int32 ds26503_close(uint32 idx);
int32 ds26503_init(spi_gen_t *spi_gen, uint32 num);

#endif 

