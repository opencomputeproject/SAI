/****************************************************************************
 * ctc_hw.c :        for immap/ioctl/interrupt
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         R0.01
 * Author         :         caoj
 * Date           :         2011-05-05
 * Reason         :         First Create
 ****************************************************************************/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/irq.h>
#include <asm/types.h>
#include <asm/io.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/phy.h>
#include <asm/delay.h>
#include <asm/ctc_platform.h>

#include "ctc_hw.h"

extern ctc_board_t ctc_bd_info;
extern struct mii_bus *ctc_p1020_new_bus;

/*Fix bug 15622. support cavium CPU card on humberDemo board. Kernel is 64 bit width*/
//static ulong pci_phy_addr;
void __iomem *epld_base_addr;
static int trigger;
volatile ulong* pci_logic_addr;

#define CTC_HW_MAX_INTR_NUM 3

typedef irqreturn_t (*p_func) (int irq, void* dev_id);
p_func ctc_normal_int_isr[CTC_HW_MAX_INTR_NUM];
static uint normal_irq[CTC_HW_MAX_INTR_NUM];
static char normal_irq_str[CTC_HW_MAX_INTR_NUM][25] = 
{
    "Normal 0 interrupt",
    "Normal 1 interrupt",
    "Normal 2 interrupt",
};


u32 phy_int_val = 0xffffffff;


static uint normal_irq_0;
static uint normal_irq_1;
static uint normal_irq_2;
static uint normal_int0_offset;
static uint normal_int0_mask_offset;
static uint normal_int1_offset;
static uint normal_int1_mask_offset;
static uint normal_int2_offset;
static uint normal_int2_mask_offset;
static u8 normal_irq_count;

static struct timer_list feeddog_timer;


static DECLARE_WAIT_QUEUE_HEAD(poll_interrupt); 

static irqreturn_t 
ctc_normal_int0_isr(int irq, void *dev_id)
{
    u8 tmp_val = 0;
    tmp_val = ioread8(epld_base_addr + normal_int0_offset);
    phy_int_val = (0xffff00 | tmp_val) & 0xffffff;
    iowrite8(0xff, epld_base_addr + normal_int0_mask_offset);
    trigger = 1;
    wake_up(&poll_interrupt);
    return IRQ_HANDLED;
}   

static irqreturn_t 
ctc_normal_int1_isr(int irq, void *dev_id)
{
    u16 tmp_val = 0;
    tmp_val = ioread8(epld_base_addr + normal_int1_offset);
    phy_int_val = (0xff00ff | (tmp_val<<8)) & 0xffffff;
    iowrite8(0xff, epld_base_addr + normal_int1_mask_offset);
    trigger = 1;
    wake_up(&poll_interrupt);
    return IRQ_HANDLED;
}   

static irqreturn_t 
ctc_normal_int2_isr(int irq, void *dev_id)
{
    u32 tmp_val = 0;
    tmp_val = ioread8(epld_base_addr + normal_int2_offset);
    phy_int_val = (0x00ffff | (tmp_val<<16)) & 0xffffff;
    iowrite8(0xff, epld_base_addr + normal_int2_mask_offset);
    trigger = 1;
    wake_up(&poll_interrupt);
    return IRQ_HANDLED;
}   


void feeddog_timer_handle(unsigned long data)
{

    /*Bug18151. Add flag to control watchdog feed. another control position is octeon_restart().*/
    if(ctc_bd_info.watchdog_is_feed)
    {

        mod_timer(&feeddog_timer, jiffies + HZ/2);    
    }
}

extern void si_meminfo(struct sysinfo *val);

static int memusage_proc(long *val)
{
    unsigned long flags;
    unsigned long freeram;
#define K(x) ((x) << (PAGE_SHIFT - 10))

    local_irq_save(flags);
    freeram = global_page_state(NR_FREE_PAGES);
    *val = K(freeram);
    local_irq_restore(flags);
    
    return 0;
}

int hw_cpu_mdio_read(unsigned int phy_addr, unsigned int offset, unsigned int *value)
{
    *value = ctc_p1020_new_bus->read(ctc_p1020_new_bus, phy_addr, offset);
    return 0;
}

int hw_cpu_mdio_write(unsigned int phy_addr, unsigned int offset, unsigned int value)
{
    ctc_p1020_new_bus->write(ctc_p1020_new_bus, phy_addr, offset, value);
    return 0;
}


static int
hw_user_read_cpu_mdio(unsigned long arg)
{
    hw_cpu_mdio_cfg_ioctl_t hw_cpu_mdio_cfg;
    hw_cpu_mdio_cfg_ioctl_t* tmp;
    if(copy_from_user(&hw_cpu_mdio_cfg, (void*)arg, sizeof(hw_cpu_mdio_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    if(hw_cpu_mdio_read(hw_cpu_mdio_cfg.phy_addr, hw_cpu_mdio_cfg.reg, &hw_cpu_mdio_cfg.value))
    {
        printk("hw_user_read_cpu_mdio failed.\n");
        return -EFAULT;
    }

    if(copy_to_user((hw_cpu_mdio_cfg_ioctl_t*)arg, (void*)&hw_cpu_mdio_cfg, sizeof(hw_cpu_mdio_cfg_ioctl_t)))
    {
        return -EFAULT;
    }
    tmp = (hw_cpu_mdio_cfg_ioctl_t*)arg;
    
    return 0;
}

static int
hw_user_write_cpu_mdio(unsigned long arg)
{
    hw_cpu_mdio_cfg_ioctl_t hw_cpu_mdio_cfg;
    if(copy_from_user(&hw_cpu_mdio_cfg, (void*)arg, sizeof(hw_cpu_mdio_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    return hw_cpu_mdio_write(hw_cpu_mdio_cfg.phy_addr, hw_cpu_mdio_cfg.reg, hw_cpu_mdio_cfg.value);
}


#ifdef CONFIG_COMPAT
 static long ctc_hw_ioctl (struct file *file, 
             unsigned int cmd, unsigned long parameter) 
#else            
static long ctc_hw_ioctl (struct inode* inode, struct file* file,
                unsigned int cmd, unsigned long parameter)            
#endif         
{
    int ret;
    long val;

    switch (cmd)
    {
        case RD_PERI_IRQ_STAT:
            ret = put_user(phy_int_val , (u32*)parameter);
            if (ret<0)
                printk(KERN_WARNING"invalid user space pointer");
            return ret;
        case CTC_EN_WATCHDOG:
            /*now just humber demo&seoul g24eu don't support watchdog*/
            if(ctc_bd_info.watchdog_support)
            {
                /*modified by xgu for bug 14828 , 2011-05-09*/
                if(NULL != feeddog_timer.function)
                {
                    return 0;
                }

                /* feed dog before enable it */
                {

                }
                ctc_bd_info.watchdog_is_feed = 1;
                /* start feed dog timer */
                init_timer(&feeddog_timer);
                feeddog_timer.function = &feeddog_timer_handle;
                feeddog_timer.data = (unsigned long)0; 
                feeddog_timer.expires = jiffies + HZ/2;
                add_timer(&feeddog_timer);
              
                /* enable GPIO feed dog */
            }
            
            return 0;
        case CTC_DIS_WATCHDOG:
            /*now just humber demo&seoul g24eu don't support watchdog*/
            if(ctc_bd_info.watchdog_support)
            {
                /* disable GPIO feed dog while enable EPLD feed dog automatically */

                /* stop feed dog timer */
                if(feeddog_timer.function != NULL)
                {
                    del_timer(&feeddog_timer);
                    feeddog_timer.function = NULL;
                }
            }            
            
            return 0;
        case CTC_DIS_FEED_WATCHDOG:
            /*now just humber demo&seoul g24eu don't support watchdog*/
            if(ctc_bd_info.watchdog_support)
            {
                /* stop feed dog timer */
                if(feeddog_timer.function != NULL)
                {
                    del_timer(&feeddog_timer);
                    feeddog_timer.function = NULL;
                }
            }
                        
            return 0;
         case CTC_GET_MEM_FREE:
            memusage_proc(&val);
            ret = put_user(val, (u32*)parameter);
            if (ret<0)
                printk(KERN_WARNING"invalid user space pointer");
            
            return ret;
         case CTC_CPU_MDIO_READ:
            return hw_user_read_cpu_mdio(parameter);

         case CTC_CPU_MDIO_WRITE:
            return hw_user_write_cpu_mdio(parameter);            
            
         default:
            break;
    }

    return 0;
}

static unsigned int ctc_hw_poll (struct file *filp, struct poll_table_struct *p)
{
    unsigned int mask = 0;
    unsigned long flags;
    
    poll_wait(filp, &poll_interrupt, p);
    local_irq_save(flags);
    if (trigger)
    {
        trigger = 0;
        mask |= POLLIN | POLLRDNORM;
    }
    local_irq_restore(flags);
    
    return mask;
}

static struct file_operations fops = 
{
    .owner = THIS_MODULE,
#ifdef CONFIG_COMPAT
    .compat_ioctl = ctc_hw_ioctl,
#else
    .ioctl = ctc_hw_ioctl,
#endif    
    .poll = ctc_hw_poll,
};


static int __init ctc_hw_init(void)
{
    int ret;
    int i;
    
    ret = register_chrdev(CTC_HW_DEV_MAJOR, "ctc_hw", &fops);
    if (ret<0)
    {
        printk(KERN_WARNING "%s failed with %d\n", "Sorry, registering the character device", ret);
        return ret;
    }   
    
    if(ctc_bd_info.watchdog_support)
    {
        /*modified by xgu for bug 14828 , 2011-05-09*/
        memset(&feeddog_timer, 0, sizeof(feeddog_timer));
        init_timer(&feeddog_timer);
    }

    epld_base_addr = ctc_bd_info.epld_logic_addr;        
    normal_irq_0 = ctc_bd_info.normal_irq_0;
    normal_irq_1 = ctc_bd_info.normal_irq_1;
    normal_irq_2 = ctc_bd_info.normal_irq_2;
    normal_int0_offset = ctc_bd_info.normal_int0_offset;
    normal_int0_mask_offset = ctc_bd_info.normal_int0_mask_offset;
    normal_int1_offset = ctc_bd_info.normal_int1_offset;
    normal_int1_mask_offset = ctc_bd_info.normal_int1_mask_offset;
    normal_int2_offset = ctc_bd_info.normal_int2_offset;
    normal_int2_mask_offset = ctc_bd_info.normal_int2_mask_offset;

    normal_irq_count = ctc_bd_info.normal_irq_count;
    
    ctc_normal_int_isr[0] = ctc_normal_int0_isr;
    ctc_normal_int_isr[1] = ctc_normal_int1_isr;
    ctc_normal_int_isr[2] = ctc_normal_int2_isr;
    normal_irq[0] = normal_irq_0;
    normal_irq[1] = normal_irq_1;
    normal_irq[2] = normal_irq_2;
 
    for (i = 0; i < normal_irq_count; i++ )
    {
        ret = request_irq(normal_irq[i], ctc_normal_int_isr[i], IRQF_DISABLED, normal_irq_str[i], ctc_normal_int_isr[i]);
        if (ret)
        {
            printk(KERN_WARNING "%s failed with %d:%d\n", "Sorry, requesting irq for normal interrupt", ret, normal_irq[i]);
        }
    }

    return 0;
}

static void __exit ctc_hw_exit(void)
{
    unregister_chrdev(CTC_HW_DEV_MAJOR, "ctc_hw");
}


module_init(ctc_hw_init);                                                                                                                   
module_exit(ctc_hw_exit);                                                                                                                   

EXPORT_SYMBOL(pci_logic_addr);
MODULE_LICENSE("GPL");

