/****************************************************************************
 * ctc_hw.c :        for immap/ioctl/interrupt
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         R0.01
 * Author         :         caoj
 * Date           :         2011-05-05
 * Reason         :         First Create
 ****************************************************************************/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/irq.h>
#include <asm/types.h>
#include <asm/io.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/phy.h>
#include <asm/delay.h>
#include <asm/p1020_ctc.h>

#include "ctc_hw.h"

void __iomem *epld_base_addr;
static int trigger;
volatile ulong* pci_logic_addr;

int mpc8308_irq[4];
static DECLARE_WAIT_QUEUE_HEAD(poll_interrupt); 

static int memusage_proc(long *val)
{
    unsigned long flags;
    unsigned long freeram;
#define K(x) ((x) << (PAGE_SHIFT - 10))

    local_irq_save(flags);
    freeram = global_page_state(NR_FREE_PAGES);
    *val = K(freeram);
    local_irq_restore(flags);
    
    return 0;
}


#ifdef CONFIG_COMPAT
 static long ctc_hw_ioctl (struct file *file, 
             unsigned int cmd, unsigned long parameter) 
#else            
static long ctc_hw_ioctl (struct inode* inode, struct file* file,
                unsigned int cmd, unsigned long parameter)            
#endif         
{
    int ret;
    long val;

    switch (cmd)
    {
         case CTC_GET_MEM_FREE:
            memusage_proc(&val);
            ret = put_user(val, (u32*)parameter);
            if (ret<0)
                printk(KERN_WARNING"invalid user space pointer");
            
            return ret;
        case CTC_HW_CMD_GET_IRQ:
            ret = copy_to_user((unsigned int *)parameter, (void*)&mpc8308_irq, sizeof(mpc8308_irq));
            if (ret<0)
                printk(KERN_WARNING"invalid user space pointer");
            
            return ret;
           
         default:
            break;
    }

    return 0;
}



static unsigned int ctc_hw_poll (struct file *filp, struct poll_table_struct *p)
{
    unsigned int mask = 0;
    unsigned long flags;
    
    poll_wait(filp, &poll_interrupt, p);
    local_irq_save(flags);
    if (trigger)
    {
        trigger = 0;
        mask |= POLLIN | POLLRDNORM;
    }
    local_irq_restore(flags);
    
    return mask;
}


static struct file_operations fops = 
{
    .owner = THIS_MODULE,
#ifdef CONFIG_COMPAT
    .compat_ioctl = ctc_hw_ioctl,
#else
    .ioctl = ctc_hw_ioctl,
#endif    
    .poll = ctc_hw_poll,
};


struct file_operations ctc_hw_fops = {
    .owner =    THIS_MODULE,
    .ioctl =    ctc_hw_ioctl,
};



static int __init ctc_hw_init(void)
{
    int ret;
    struct device_node *np;

    /* chani 20130719 */
    np = of_find_compatible_node(NULL, NULL, "fsl,mpc8308-fpga");
    if(np) {
        mpc8308_irq[0] = irq_of_parse_and_map(np, 0);
        mpc8308_irq[1] = irq_of_parse_and_map(np, 1);
        mpc8308_irq[2] = irq_of_parse_and_map(np, 2);
        mpc8308_irq[3] = irq_of_parse_and_map(np, 3);
        printk(KERN_ERR "interrupt 0 %d 1 %d 2 %d 3 %d\n",mpc8308_irq[0],mpc8308_irq[1],mpc8308_irq[2],mpc8308_irq[3]);
    }

    ret = register_chrdev(CTC_HW_DEV_MAJOR, "ctc_hw", &fops);
    if (ret<0)
    {
        printk(KERN_WARNING "%s failed with %d\n", "Sorry, registering the character device", ret);
        return ret;
    }

    return 0;
}

static void __exit ctc_hw_exit(void)
{
    unregister_chrdev(CTC_HW_DEV_MAJOR, "ctc_hw");
}


module_init(ctc_hw_init);                                                                                                                   
module_exit(ctc_hw_exit);                                                                                                                   

EXPORT_SYMBOL(pci_logic_addr);
MODULE_LICENSE("GPL");

