#ifndef __CTC_HW_H__
#define __CTC_HW_H__

#define CTC_HW_DEV_NAME     "/dev/ctc_hw"
#define CTC_HW_DEV_MAJOR    100
/* modified by liuht for supporting dpll interrupt */
#define CTC_DPLL_DEV_NAME     "/dev/ctc_dpll"
#define CTC_DPLL_DEV_MAJOR    107       
          
#define SI_MASK  0x1
#define BIT_WIDTH_8  8

#define RD_PERI_IRQ_STAT        _IO(CTC_HW_DEV_MAJOR, 6)
#define EN_ASIC_NORMAL_INT      _IO(CTC_HW_DEV_MAJOR, 7)
#define EN_ASIC_FATAL_INT       _IO(CTC_HW_DEV_MAJOR, 8)
#define REG_ASIC_NORMAL_INT     _IO(CTC_HW_DEV_MAJOR, 9) 
#define REG_ASIC_FATAL_INT      _IO(CTC_HW_DEV_MAJOR, 10)
#define CTC_EN_WATCHDOG         _IO(CTC_HW_DEV_MAJOR, 11)
#define CTC_DIS_WATCHDOG        _IO(CTC_HW_DEV_MAJOR, 12)
#define CTC_DIS_FEED_WATCHDOG   _IO(CTC_HW_DEV_MAJOR, 13)
#define CTC_DIS_ALL_IRQS        _IO(CTC_HW_DEV_MAJOR, 14)
#define EN_FOAM_NORMAL_INT      _IO(CTC_HW_DEV_MAJOR, 15)
#define REG_FOAM_NORMAL_INT     _IO(CTC_HW_DEV_MAJOR, 16) 
#define CTC_GET_MEM_FREE        _IO(CTC_HW_DEV_MAJOR, 17)

#define CTC_CPU_MDIO_READ _IO(CTC_HW_DEV_MAJOR, 18)
#define CTC_CPU_MDIO_WRITE _IO(CTC_HW_DEV_MAJOR, 19)
#define CTC_HW_CMD_GET_IRQ _IO(CTC_HW_DEV_MAJOR, 20)

struct hw_cpu_mdio_cfg_ioctl_s
{
    unsigned int phy_addr;
    unsigned int reg;
    unsigned int value;
}; 
typedef struct hw_cpu_mdio_cfg_ioctl_s  hw_cpu_mdio_cfg_ioctl_t;


#endif
