#ifndef __CTC_HW_H__
#define __CTC_HW_H__

#define CTC_HW_DEV_NAME     "/dev/ctc_hw"
#define CTC_HW_DEV_MAJOR    100
/* modified by liuht for supporting dpll interrupt */
#define CTC_DPLL_DEV_NAME     "/dev/ctc_dpll"
#define CTC_DPLL_DEV_MAJOR    107   

/* Added by liuht for bug27035, 2014-03-05 */
#define CTC_POWER_DEV_NAME     "/dev/ctc_power"
#define CTC_POWER_DEV_MAJOR    102

#define CTC_RESET_DEV_NAME     "/dev/ctc_reset"
#define CTC_RESET_DEV_MAJOR    112

#define CTC_FLF_DEV_NAME    "/dev/ctc_flf"
#define CTC_FLF_DEV_MAJOR   113

#define SI_MASK  0x1
#define BIT_WIDTH_8  8


#define SIU_INT_IRQ2    ((uint)0x14)
#define GB_PTN_ACCESS_EPLD 0x5
#define GB_PTN_PHY_INT_OFFSET 0xC
#define GB_PTN_PHY_INT_MASK_OFFSET 0xE 
#define EPLD_SPI_SWITCH 0x9
#define GB_PTN_DS3104_INT_OFFSET 0x5
#define CTC_FPGA_PERI_INT_OFF 0x14
#define CTC_FPGA_SHARE_INT_MASK  0x34

#define RD_PERI_IRQ_STAT        _IO(CTC_HW_DEV_MAJOR, 6)
#define EN_ASIC_NORMAL_INT      _IO(CTC_HW_DEV_MAJOR, 7)
#define EN_ASIC_FATAL_INT       _IO(CTC_HW_DEV_MAJOR, 8)
#define REG_ASIC_NORMAL_INT     _IO(CTC_HW_DEV_MAJOR, 9) 
#define REG_ASIC_FATAL_INT      _IO(CTC_HW_DEV_MAJOR, 10)
#define CTC_EN_WATCHDOG         _IO(CTC_HW_DEV_MAJOR, 11)
#define CTC_DIS_WATCHDOG        _IO(CTC_HW_DEV_MAJOR, 12)
#define CTC_DIS_FEED_WATCHDOG   _IO(CTC_HW_DEV_MAJOR, 13)
#define CTC_DIS_ALL_IRQS        _IO(CTC_HW_DEV_MAJOR, 14)
#define EN_FOAM_NORMAL_INT      _IO(CTC_HW_DEV_MAJOR, 15)
#define REG_FOAM_NORMAL_INT     _IO(CTC_HW_DEV_MAJOR, 16) 
#define CTC_GET_MEM_FREE        _IO(CTC_HW_DEV_MAJOR, 17)

#define CTC_CPU_MDIO_READ _IO(CTC_HW_DEV_MAJOR, 18)
#define CTC_CPU_MDIO_WRITE _IO(CTC_HW_DEV_MAJOR, 19)

#define RD_PERI_IRQ2_STAT       _IO(CTC_HW_DEV_MAJOR, 21)

struct hw_cpu_mdio_cfg_ioctl_s
{
    unsigned int phy_addr;
    unsigned int reg;
    unsigned int value;
}; 
typedef struct hw_cpu_mdio_cfg_ioctl_s  hw_cpu_mdio_cfg_ioctl_t;


#endif
