/****************************************************************************
 * ctc_hw.c :        for immap/ioctl/interrupt
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         R0.01
 * Author         :         caoj
 * Date           :         2011-05-05
 * Reason         :         First Create
 ****************************************************************************/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/irq.h>
#include <asm/types.h>
#include <asm/io.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/phy.h>
#include <asm/delay.h>
#include <asm/ctc_platform.h>
#include <linux/delay.h>

#include "ctc_hw.h"

extern ctc_board_t ctc_bd_info;
extern struct mii_bus *ctc_p1020_new_bus;

/*Fix bug 15622. support cavium CPU card on humberDemo board. Kernel is 64 bit width*/
//static ulong pci_phy_addr;
void __iomem *epld_base_addr;
static int trigger;
static int reset_trigger;
/* Added by liuht for bug27035, 2014-03-05 */
static int power_trigger;

volatile ulong* pci_logic_addr;

#define CTC_HW_MAX_INTR_NUM 3

typedef irqreturn_t (*p_func) (int irq, void* dev_id);
p_func ctc_normal_int_isr[CTC_HW_MAX_INTR_NUM];
static uint normal_irq[CTC_HW_MAX_INTR_NUM];
static char normal_irq_str[CTC_HW_MAX_INTR_NUM][25] = 
{
    "Normal 0 interrupt",
    "Normal 1 interrupt",
    "Normal 2 interrupt",
};

/* EPLD board type Defines */
enum glb_board_series_e
{
    GLB_SERIES_E350 = 0x1,
    GLB_SERIES_MAX
};
typedef enum glb_board_series_e glb_board_series_t;

#define GLB_BOARD_GREATBELT_DEMO 0x1
#define GLB_BOARD_E350_48T4X2Q  0x1
#define GLB_BOARD_E350_48T4XG  0x2
/* Added by liuht for bug 27657, 2014-03-25 */
#define GLB_BOARD_E350_24T4XG 0x4
/* Added by liuht for bug27056, 2014-01-24 */
/* To distinguish phicomm board and centec board for 8T12X */
#define GLB_BOARD_E350_8T12XG  0x5
#define GLB_BOARD_E350_PHICOMM_8T12XG  0x3
#define GLB_BOARD_E350_8T4S12XG  0x6
#define GLB_BOARD_E350_8TS12X  0x7

u32 phy_int_val = 0xffffffff;

#define CTC_RESET_IRQ_NUM   24
#define CTC_RESET_IRQ_MASK  0x9
/* Added by liuht for bug 27657, 2014-03-25 */
#define CTC_POWER_INTR_NUM 18       /* For E350-48T4XG2Q/E350-48T4XG/E350-24T4XG */
#define CTC_POWER_INTR_MASK 0xa     /* For E350-48T4XG2Q/E350-48T4XG/E350-24T4XG */

#define CTC_POWER_INTR_NUM2 19      /* For E350-8TS12X */
#define CTC_POWER_INTR_MASK2 0x15    /* For E350-8TS12X */

static uint normal_irq_0;
static uint normal_irq_1;
static uint normal_irq_2;
static uint normal_int0_offset;
static uint normal_int0_mask_offset;
static uint normal_int1_offset;
static uint normal_int1_mask_offset;
static uint normal_int2_offset;
static uint normal_int2_mask_offset;
static u8 normal_irq_count;
static int trigger_dpll;
static u8 is_ctrl_fpga;
static uint dpll_irq;
static uint dpll_int_offset;
static uint dpll_int_mask_offset;

static struct timer_list feeddog_timer;


static DECLARE_WAIT_QUEUE_HEAD(poll_interrupt); 
static DECLARE_WAIT_QUEUE_HEAD(reset_poll_interrupt); 
/* Added by liuht for bug 27657, 2014-03-25 */
static DECLARE_WAIT_QUEUE_HEAD(power_poll_interrupt); 
static DECLARE_WAIT_QUEUE_HEAD(poll_interrupt_dpll); 

static irqreturn_t 
ctc_normal_int0_isr(int irq, void *dev_id)
{
    u8 tmp_val = 0;
    tmp_val = ioread8(epld_base_addr + normal_int0_offset);
    phy_int_val = (0xffff00 | tmp_val) & 0xffffff;
    iowrite8(0xff, epld_base_addr + normal_int0_mask_offset);
    trigger = 1;
    wake_up(&poll_interrupt);
    return IRQ_HANDLED;
}   

static irqreturn_t 
ctc_reset_isr(int irq, void *dev_id)
{
    u8 tmp_val = 0x1;
    iowrite8(tmp_val, epld_base_addr + CTC_RESET_IRQ_MASK);
    reset_trigger = 1;
    wake_up(&reset_poll_interrupt);
    return IRQ_HANDLED;
}   

static irqreturn_t 
ctc_normal_int1_isr(int irq, void *dev_id)
{
    u16 tmp_val = 0;
    tmp_val = ioread8(epld_base_addr + normal_int1_offset);
    phy_int_val = (0xff00ff | (tmp_val<<8)) & 0xffffff;
    iowrite8(0xff, epld_base_addr + normal_int1_mask_offset);
    trigger = 1;
    wake_up(&poll_interrupt);
    return IRQ_HANDLED;
}   

static irqreturn_t 
ctc_normal_int2_isr(int irq, void *dev_id)
{
    u32 tmp_val = 0;
    tmp_val = ioread8(epld_base_addr + normal_int2_offset);
    phy_int_val = (0x00ffff | (tmp_val<<16)) & 0xffffff;
    iowrite8(0xff, epld_base_addr + normal_int2_mask_offset);
    trigger = 1;
    wake_up(&poll_interrupt);
    return IRQ_HANDLED;
}   

/* Added by liuht for bug 27657, 2014-03-25 */
static irqreturn_t 
ctc_power_isr(int irq, void *dev_id)
{
    u8 tmp_val = 0;
    if ((GLB_BOARD_E350_48T4X2Q == ctc_bd_info.board_type)
        || (GLB_BOARD_E350_48T4XG == ctc_bd_info.board_type)
        || (GLB_BOARD_E350_24T4XG == ctc_bd_info.board_type))
    {
        tmp_val = ioread8(epld_base_addr + CTC_POWER_INTR_MASK);
        tmp_val |= (1<<3);
        iowrite8(tmp_val, epld_base_addr + CTC_POWER_INTR_MASK);
    }
    else if (GLB_BOARD_E350_8TS12X == ctc_bd_info.board_type)
    {
        iowrite8(0x1, epld_base_addr + CTC_POWER_INTR_MASK2);
    }
    power_trigger = 1;
    wake_up(&power_poll_interrupt);
    return IRQ_HANDLED;
}


void feeddog_timer_handle(unsigned long data)
{
    /* Added by liuht for bug 27693, 2014-03-31 */
    unsigned int val;
    unsigned int mask;

    /*Bug18151. Add flag to control watchdog feed. another control position is octeon_restart().*/
    if(ctc_bd_info.watchdog_is_feed)
    {
        val = in_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset);
        mask = 0x80000000 >> ctc_bd_info.watchdog_feed_gpio;
        if(val & mask)
            out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val & (~mask));
        else
            out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val | mask);

        mod_timer(&feeddog_timer, jiffies + HZ/2);  
    }
}

extern void si_meminfo(struct sysinfo *val);

static int memusage_proc(long *val)
{
    unsigned long flags;
    unsigned long freeram;
#define K(x) ((x) << (PAGE_SHIFT - 10))

    local_irq_save(flags);
    freeram = global_page_state(NR_FREE_PAGES);
    *val = K(freeram);
    local_irq_restore(flags);
    
    return 0;
}

int hw_cpu_mdio_read(unsigned int phy_addr, unsigned int offset, unsigned int *value)
{
    phy_addr |= 0xff0000; /* add flag to indicate PHY VSC8512, qicx, bug25630, 2013-11-04 */
    /* *value = ctc_p1020_new_bus->read(ctc_p1020_new_bus, phy_addr, offset); */
    *value = mdiobus_read(ctc_p1020_new_bus, phy_addr, offset);
    return 0;
}

int hw_cpu_mdio_write(unsigned int phy_addr, unsigned int offset, unsigned int value)
{
    phy_addr |= 0xff0000; /* add flag to indicate PHY VSC8512, qicx, bug25630, 2013-11-04 */
    /* ctc_p1020_new_bus->write(ctc_p1020_new_bus, phy_addr, offset, value); */
    mdiobus_write(ctc_p1020_new_bus, phy_addr, offset, value);
    return 0;
}


static int
hw_user_read_cpu_mdio(unsigned long arg)
{
    hw_cpu_mdio_cfg_ioctl_t hw_cpu_mdio_cfg;
    hw_cpu_mdio_cfg_ioctl_t* tmp;
    if(copy_from_user(&hw_cpu_mdio_cfg, (void*)arg, sizeof(hw_cpu_mdio_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    if(hw_cpu_mdio_read(hw_cpu_mdio_cfg.phy_addr, hw_cpu_mdio_cfg.reg, &hw_cpu_mdio_cfg.value))
    {
        printk("hw_user_read_cpu_mdio failed.\n");
        return -EFAULT;
    }

    if(copy_to_user((hw_cpu_mdio_cfg_ioctl_t*)arg, (void*)&hw_cpu_mdio_cfg, sizeof(hw_cpu_mdio_cfg_ioctl_t)))
    {
        return -EFAULT;
    }
    tmp = (hw_cpu_mdio_cfg_ioctl_t*)arg;
    
    return 0;
}

static int
hw_user_write_cpu_mdio(unsigned long arg)
{
    hw_cpu_mdio_cfg_ioctl_t hw_cpu_mdio_cfg;
    if(copy_from_user(&hw_cpu_mdio_cfg, (void*)arg, sizeof(hw_cpu_mdio_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    return hw_cpu_mdio_write(hw_cpu_mdio_cfg.phy_addr, hw_cpu_mdio_cfg.reg, hw_cpu_mdio_cfg.value);
}

static irqreturn_t 
ctc_dpll_isr(int irq, void *dev_id)
{
    iowrite8(0xff, epld_base_addr + dpll_int_mask_offset);
    trigger_dpll = 1;
    wake_up(&poll_interrupt_dpll);
    return IRQ_HANDLED;
}


#ifdef CONFIG_COMPAT
 static long ctc_hw_ioctl (struct file *file, 
             unsigned int cmd, unsigned long parameter) 
#else            
static long ctc_hw_ioctl (struct inode* inode, struct file* file,
                unsigned int cmd, unsigned long parameter)            
#endif         
{
    int ret;
    unsigned int val, mask;

    switch (cmd)
    {
        case RD_PERI_IRQ_STAT:
            ret = put_user(phy_int_val , (u32*)parameter);
            if (ret<0)
                printk(KERN_WARNING"invalid user space pointer");
            return ret;
        case CTC_EN_WATCHDOG:
            /*now just humber demo&seoul g24eu don't support watchdog*/
            if(ctc_bd_info.watchdog_support)
            {
                /*modified by xgu for bug 14828 , 2011-05-09*/
                if(NULL != feeddog_timer.function)
                {
                    return 0;
                }
                /* Added by liuht for bug 27693, 2014-03-31 */
                val = in_be32(ctc_bd_info.gpio_logic_addr);
                mask = 0x80000000 >> ctc_bd_info.watchdog_feed_gpio;
                out_be32(ctc_bd_info.gpio_logic_addr , val | mask);		

                /* feed dog before enable it */
                {
                    val = in_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset);
                    mask = 0x80000000 >> ctc_bd_info.watchdog_feed_gpio;
                    if(val & mask)
                        out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val & (~mask));
                    else
                        out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val | mask);
                }
                ctc_bd_info.watchdog_is_feed = 1;
                /* start feed dog timer */
                init_timer(&feeddog_timer);
                feeddog_timer.function = &feeddog_timer_handle;
                feeddog_timer.data = (unsigned long)0; 
                feeddog_timer.expires = jiffies + HZ/2;
                add_timer(&feeddog_timer);
                /* Added by liuht for bug 28365, 2014-04-27 */
                /* delay 20ms to ensure feed watchdog signal out before enable watchdog signal */
                mdelay(20);
                /* enable GPIO feed dog */
                /* Added by liuht for bug 27693, 2014-03-31 */
                val = in_be32(ctc_bd_info.gpio_logic_addr);
                mask = 0x80000000 >> ctc_bd_info.watchdog_en_gpio;
                out_be32(ctc_bd_info.gpio_logic_addr, val | mask);
                if((ctc_bd_info.board_type == GLB_BOARD_E350_24T4XG) 
                	||(ctc_bd_info.board_type == GLB_BOARD_E350_48T4XG) 
                	||(ctc_bd_info.board_type == GLB_BOARD_E350_48T4X2Q))
                {
                    val = in_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset);
                    mask = 0x80000000 >> ctc_bd_info.watchdog_en_gpio;
                    out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val | mask);				
                }
                else if((ctc_bd_info.board_type == GLB_BOARD_E350_8T12XG) 
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_PHICOMM_8T12XG)
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_8T4S12XG)
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_8TS12X))
                {
                    val = in_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset);
                    mask = 0x80000000 >> ctc_bd_info.watchdog_en_gpio;
                    out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val & (~mask));
                }
            }
            
            return 0;
        case CTC_DIS_WATCHDOG:
            /*now just humber demo&seoul g24eu don't support watchdog*/
            if(ctc_bd_info.watchdog_support)
            {
                /* disable GPIO feed dog while enable EPLD feed dog automatically */
                if((ctc_bd_info.board_type == GLB_BOARD_E350_24T4XG) 
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_48T4XG) 
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_48T4X2Q))
                {
                    val = in_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset);
                    mask = 0x80000000 >> ctc_bd_info.watchdog_en_gpio;
                    out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val & (~mask));
                }
                else if((ctc_bd_info.board_type == GLB_BOARD_E350_8T12XG) 
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_PHICOMM_8T12XG)
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_8T4S12XG)
                    ||(ctc_bd_info.board_type == GLB_BOARD_E350_8TS12X))
                {
                    val = in_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset);
                    mask = 0x80000000 >> ctc_bd_info.watchdog_en_gpio;
                    out_be32(ctc_bd_info.gpio_logic_addr + ctc_bd_info.gpio_date_offset, val | mask);
                }
                /* stop feed dog timer */
                if(feeddog_timer.function != NULL)
                {
                    del_timer(&feeddog_timer);
                    feeddog_timer.function = NULL;
                }
            }            
            
            return 0;
        case CTC_DIS_FEED_WATCHDOG:
            /*now just humber demo&seoul g24eu don't support watchdog*/
            if(ctc_bd_info.watchdog_support)
            {
                /* stop feed dog timer */
                if(feeddog_timer.function != NULL)
                {
                    del_timer(&feeddog_timer);
                    feeddog_timer.function = NULL;
                }
            }
                        
            return 0;
         case CTC_GET_MEM_FREE:
            memusage_proc(&val);
            ret = put_user(val, (u32*)parameter);
            if (ret<0)
                printk(KERN_WARNING"invalid user space pointer");
            
            return ret;
         case CTC_CPU_MDIO_READ:
            return hw_user_read_cpu_mdio(parameter);

         case CTC_CPU_MDIO_WRITE:
            return hw_user_write_cpu_mdio(parameter);            
            
         default:
            break;
    }

    return 0;
}

static unsigned int ctc_hw_poll (struct file *filp, struct poll_table_struct *p)
{
    unsigned int mask = 0;
    unsigned long flags;
    
    poll_wait(filp, &poll_interrupt, p);
    local_irq_save(flags);
    if (trigger)
    {
        trigger = 0;
        mask |= POLLIN | POLLRDNORM;
    }
    local_irq_restore(flags);
    
    return mask;
}

static unsigned int ctc_dpll_poll (struct file *filp, struct poll_table_struct *p)
{
    unsigned int mask = 0;
    unsigned long flags; 
    poll_wait(filp, &poll_interrupt_dpll, p);
    local_irq_save(flags); 
    if (trigger_dpll) 
    {
        trigger_dpll = 0;
        mask |= POLLIN | POLLRDNORM;
    }
    local_irq_restore(flags);
    
    return mask;
} 


static struct file_operations fops = 
{
    .owner = THIS_MODULE,
#ifdef CONFIG_COMPAT
    .compat_ioctl = ctc_hw_ioctl,
#else
    .ioctl = ctc_hw_ioctl,
#endif    
    .poll = ctc_hw_poll,
};

static struct file_operations ctc_dpll_fops = 
{
    .owner = THIS_MODULE,
    .ioctl = NULL,
    .poll = ctc_dpll_poll,
    .mmap = NULL,
};

static unsigned int ctc_reset_poll (struct file *filp, struct poll_table_struct *p)
{
    unsigned int mask = 0;
    unsigned long flags;
    
    poll_wait(filp, &reset_poll_interrupt, p);
    local_irq_save(flags);
    if (reset_trigger)
    {
        reset_trigger = 0;
        mask |= POLLIN | POLLRDNORM;
    }
    local_irq_restore(flags);
    
    return mask;
}

/* Added by liuht for bug 27657, 2014-03-25 */
static unsigned int ctc_power_poll (struct file *filp, struct poll_table_struct *p)
{
    unsigned int mask = 0;
    unsigned long flags;
    poll_wait(filp, &power_poll_interrupt, p);
    local_irq_save(flags);
    if (power_trigger)
    {
        power_trigger = 0;
        mask |= POLLIN | POLLRDNORM;
    }
    local_irq_restore(flags);
    
    return mask;
}

static struct file_operations reset_fops = 
{
    .owner = THIS_MODULE,   
    .poll = ctc_reset_poll,
};

/* Added by liuht for bug 27657, 2014-03-25 */
static struct file_operations power_fops = 
{
    .owner = THIS_MODULE, 
    .poll = ctc_power_poll,
};

static int __init ctc_hw_init(void)
{
    int ret;
    int i;
    
    ret = register_chrdev(CTC_HW_DEV_MAJOR, "ctc_hw", &fops);
    if (ret<0)
    {
        printk(KERN_WARNING "%s failed with %d\n", "Sorry, registering the character device", ret);
        return ret;
    }   

    if(ctc_bd_info.board_series == GLB_SERIES_E350)
    {
        /* Added by liuht for bug27056, 2014-01-24 */
        /* To distinguish phicomm board and centec board for 8T12X */
        if((ctc_bd_info.board_type == GLB_BOARD_E350_8T12XG) || (ctc_bd_info.board_type == GLB_BOARD_E350_PHICOMM_8T12XG))
        {
            ret = register_chrdev(CTC_RESET_DEV_MAJOR, "ctc_reset", &reset_fops);
            if (ret<0)
            {
                printk(KERN_WARNING "%s failed with %d\n", "Sorry, registering the resetcharacter device", ret);
                return ret;
            } 
        }
    }
    /* Added by liuht for bug 27657, 2014-03-25 */
    if(ctc_bd_info.board_series == GLB_SERIES_E350)
    {
        if((ctc_bd_info.board_type == GLB_BOARD_E350_48T4XG) ||(ctc_bd_info.board_type == GLB_BOARD_E350_48T4X2Q) 
            ||(ctc_bd_info.board_type == GLB_BOARD_E350_24T4XG) 
            ||(ctc_bd_info.board_type == GLB_BOARD_E350_8TS12X))
        {
            ret = register_chrdev(CTC_POWER_DEV_MAJOR, "ctc_power", &power_fops);
            if (ret<0)
            {
                printk(KERN_WARNING "%s failed with %d\n", "Sorry, registering the power character device", ret);
                return ret;
            } 
        }
    }	


    if(ctc_bd_info.board_series == GLB_SERIES_GREATBELT_DEMO)
    {
        ret = register_chrdev(CTC_DPLL_DEV_MAJOR, "ctc_dpll", &ctc_dpll_fops);
        if (ret<0) 
        {
            printk(KERN_WARNING "%s failed with %d\n", "Sorry, registering the dpll character device", ret);
            return ret;
        }   
        
        dpll_irq = ctc_bd_info.dpll_irq;
        dpll_int_offset = ctc_bd_info.dpll_int_offset;
        dpll_int_mask_offset = ctc_bd_info.dpll_int_mask_offset;
        
    }	
    
    if(ctc_bd_info.watchdog_support)
    {
        /*modified by xgu for bug 14828 , 2011-05-09*/
        memset(&feeddog_timer, 0, sizeof(feeddog_timer));
        init_timer(&feeddog_timer);
    }

    epld_base_addr = ctc_bd_info.epld_logic_addr;        
    printk(KERN_WARNING "EPLD base address is 0x%x, value 0x%x\n", (unsigned int)epld_base_addr, ioread8(epld_base_addr + 0xf1));
    normal_irq_0 = ctc_bd_info.normal_irq_0;
    normal_irq_1 = ctc_bd_info.normal_irq_1;
    normal_irq_2 = ctc_bd_info.normal_irq_2;
    normal_int0_offset = ctc_bd_info.normal_int0_offset;
    normal_int0_mask_offset = ctc_bd_info.normal_int0_mask_offset;
    normal_int1_offset = ctc_bd_info.normal_int1_offset;
    normal_int1_mask_offset = ctc_bd_info.normal_int1_mask_offset;
    normal_int2_offset = ctc_bd_info.normal_int2_offset;
    normal_int2_mask_offset = ctc_bd_info.normal_int2_mask_offset;

    normal_irq_count = ctc_bd_info.normal_irq_count;
    
    ctc_normal_int_isr[0] = ctc_normal_int0_isr;
    ctc_normal_int_isr[1] = ctc_normal_int1_isr;
    ctc_normal_int_isr[2] = ctc_normal_int2_isr;
    normal_irq[0] = normal_irq_0;
    normal_irq[1] = normal_irq_1;
    normal_irq[2] = normal_irq_2;
 
    for (i = 0; i < normal_irq_count; i++ )
    {
        ret = request_irq(normal_irq[i], ctc_normal_int_isr[i], IRQF_DISABLED, normal_irq_str[i], ctc_normal_int_isr[i]);
        if (ret)
        {
            printk(KERN_WARNING "%s failed with %d\n", "Sorry, requesting irq for normal %d interrupt", ret, i);
        }
    }

    if(ctc_bd_info.board_series == GLB_SERIES_E350)
    {
        /* Added by liuht for bug27056, 2014-01-24 */
        /* To distinguish phicomm board and centec board for 8T12X */    
        if((ctc_bd_info.board_type == GLB_BOARD_E350_8T12XG) ||(ctc_bd_info.board_type == GLB_BOARD_E350_PHICOMM_8T12XG) )
        {
            ret = request_irq(CTC_RESET_IRQ_NUM, ctc_reset_isr, IRQF_DISABLED, "ctc_reset", ctc_reset_isr);
            if (ret)
            {
                printk(KERN_WARNING "%s failed with %d\n", "Sorry, requesting irq for normal %d interrupt", ret, i);
            }
        }
    }
    /* Added by liuht for bug 27657, 2014-03-25 */
    if(ctc_bd_info.board_series == GLB_SERIES_E350)
    {   
        if((ctc_bd_info.board_type == GLB_BOARD_E350_48T4XG) ||(ctc_bd_info.board_type == GLB_BOARD_E350_48T4X2Q) 
            ||(ctc_bd_info.board_type == GLB_BOARD_E350_24T4XG))
        {
            ret = request_irq(CTC_POWER_INTR_NUM, ctc_power_isr, IRQF_DISABLED, "ctc_power", ctc_power_isr);
            if (ret)
            {
                printk(KERN_WARNING "%s failed with %d\n", "Sorry, requesting irq for power interrupt", ret);
            }
        }
        else if (ctc_bd_info.board_type == GLB_BOARD_E350_8TS12X)
        {
            ret = request_irq(CTC_POWER_INTR_NUM2, ctc_power_isr, IRQF_DISABLED, "ctc_power", ctc_power_isr);
            if (ret)
            {
                printk(KERN_WARNING "%s failed with %d\n", "Sorry, requesting irq for power interrupt", ret);
            }
        }
    }

    if(ctc_bd_info.board_series == GLB_SERIES_GREATBELT_DEMO)
    {
        ret = request_irq(dpll_irq, ctc_dpll_isr, IRQF_DISABLED, "ctc_phy_dpll", NULL);
        if (ret)
        {
            printk(KERN_WARNING "%s failed with %d\n", "Sorry, requesting irq for dpll ", ret);
            return ret;
        }
    }
    return 0;
}

static void __exit ctc_hw_exit(void)
{
    unregister_chrdev(CTC_HW_DEV_MAJOR, "ctc_hw");
    /* Added by liuht for bug 27657, 2014-03-25 */
    unregister_chrdev(CTC_POWER_DEV_MAJOR, "ctc_power");	
}


module_init(ctc_hw_init);                                                                                                                   
module_exit(ctc_hw_exit);                                                                                                                   

EXPORT_SYMBOL(pci_logic_addr);
MODULE_LICENSE("GPL");

