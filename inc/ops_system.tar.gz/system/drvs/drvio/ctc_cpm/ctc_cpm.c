/****************************************************************************
 * ctc_cpm.c :        lkm for cpm access
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision         :         R0.01
 * Author           :         Zhu Jian
 * Date             :         2010-1-30
 * Reason         :         First Create
 ****************************************************************************/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>	/* printk() */
#include <linux/types.h>	/* size_t */
#include <linux/fs.h>		/* everything... */
#include <linux/mm.h>
#include <asm/uaccess.h>   /*copy_from_user */
#include <linux/cdev.h>
#include <linux/spinlock_types.h>
#include <linux/ioctl.h> /* needed for the _IOW etc stuff used later */

#include "ctc_cpm.h"


struct ctc_cpm_dev {    
	spinlock_t iorw_spinlock;    /* spin lock     */    
	struct cdev cdev;	         /* Char device structure*/
};

int ctc_cpm_major = CTC_CPM_MAJOR;
int ctc_cpm_minor = 0;
int ctc_cpm_nr_devs = CTC_CPM_NR_DEVS;	/* number of bare ctc_cpm devices */
struct ctc_cpm_dev *ctc_cpm_devices;	    

/*
 * The ioctl() implementation
 */
int ctc_cpm_ioctl(struct inode *inode, struct file *filp,
                 unsigned int cmd, unsigned long arg)
{
#if 0
	int err = 0;
    int val = 0;
	int retval = 0;

	switch(cmd) {
	  case CTC_CPM_WRITE: 
		if (! capable (CAP_SYS_ADMIN))
			return -EPERM;
		retval = __get_user(val, (int __user *)arg);
		break;
	  case CTC_CPM_READ: 
		retval = __put_user(val, (int __user *)arg);
		break;
	  default:  /* redundant, as cmd was checked against MAXNR */
		return -ENOTTY;
	}
#endif
	return 0;
}

int ctc_cpm_mmap(struct file *flip, struct vm_area_struct *vma)
{	
    uint32_t  cpm_phy_addr = CTC_CPM_ADDR;
    size_t size = vma->vm_end - vma->vm_start;
    unsigned long pfn;
    
    if (size > CTC_CPM_SIZE)
        return -EINVAL;
    
    pfn = cpm_phy_addr >> PAGE_SHIFT;
#ifdef _CTC_OCTEON_CN50XX_
    vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);        
#else
    vma->vm_page_prot = phys_mem_access_prot(flip, pfn, size, vma->vm_page_prot);
#endif    
    if (remap_pfn_range(vma, vma->vm_start, pfn, size, vma->vm_page_prot))
        return -EAGAIN;
    
    return 0;
}

/*
 * Open and close
 */
int ctc_cpm_open(struct inode *inode, struct file *filp)
{
	struct ctc_cpm_dev *dev; /* device information */

	dev = container_of(inode->i_cdev, struct ctc_cpm_dev, cdev);
	filp->private_data = dev; /* for other methods */
    
	return 0;          /* success */
}

int ctc_cpm_release(struct inode *inode, struct file *filp)
{
	return 0;
}

struct file_operations ctc_cpm_fops = {
	.owner =    THIS_MODULE,
    .mmap =     ctc_cpm_mmap,    
	.ioctl =    ctc_cpm_ioctl,
	.open =     ctc_cpm_open,
	.release =  ctc_cpm_release,
};

/*
 * The cleanup function is used to handle initialization failures as well.
 * Thefore, it must be careful to work correctly even if some of the items
 * have not been initialized
 */
void ctc_cpm_cleanup_module(void)
{
	int i;
	dev_t devno = MKDEV(ctc_cpm_major, ctc_cpm_minor);

	/* Get rid of our char dev entries */
	if (ctc_cpm_devices) {
		for (i = 0; i < ctc_cpm_nr_devs; i++) {
			cdev_del(&ctc_cpm_devices[i].cdev);
		}
		kfree(ctc_cpm_devices);
	}

	/* cleanup_module is never called if registering failed */
	unregister_chrdev_region(devno, ctc_cpm_nr_devs);
}


/*
 * Set up the char_dev structure for this device.
 */
static void ctc_cpm_setup_cdev(struct ctc_cpm_dev *dev, int index)
{
	int err, devno = MKDEV(ctc_cpm_major, ctc_cpm_minor + index);

	cdev_init(&dev->cdev, &ctc_cpm_fops);
	dev->cdev.owner = THIS_MODULE;
	dev->cdev.ops = &ctc_cpm_fops;
	err = cdev_add (&dev->cdev, devno, 1);
	/* Fail gracefully if need be */
	if (err)
		printk(KERN_NOTICE "Error %d adding ctc_cpm%d", err, index);
}


int ctc_cpm_init_module(void)
{
	int result, i;
	dev_t dev = 0;

/*
 * Get a range of minor numbers to work with, asking for a dynamic
 * major unless directed otherwise at load time.
 */
	dev = MKDEV(ctc_cpm_major, ctc_cpm_minor);
	result = register_chrdev_region(dev, ctc_cpm_nr_devs, "ctc_cpm");
    
	if (result < 0) {
		printk(KERN_WARNING "ctc_cpm: can't get major %d\n", ctc_cpm_major);
		return result;
	}
    
/* 
 * allocate the devices -- we can't have them static, as the number
 * can be specified at load time
 */
	ctc_cpm_devices = kmalloc(ctc_cpm_nr_devs * sizeof(struct ctc_cpm_dev), GFP_KERNEL);
	if (!ctc_cpm_devices) {
		result = -ENOMEM;
		goto fail;  /* Make this more graceful */
	}
    
	memset(ctc_cpm_devices, 0, ctc_cpm_nr_devs * sizeof(struct ctc_cpm_dev));

    /* Initialize each device. */
	for (i = 0; i < ctc_cpm_nr_devs; i++) {
        ctc_cpm_devices[i].iorw_spinlock = SPIN_LOCK_UNLOCKED;
		ctc_cpm_setup_cdev(&ctc_cpm_devices[i], i);
	}

	return 0; /* succeed */
    
fail:
	ctc_cpm_cleanup_module();
	return result;
}

module_init(ctc_cpm_init_module);
module_exit(ctc_cpm_cleanup_module);
MODULE_LICENSE("GPL");
