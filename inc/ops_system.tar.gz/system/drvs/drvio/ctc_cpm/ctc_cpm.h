#ifndef _CTC_CPM_H_
#define _CTC_CPM_H_




#define CTC_CPM_DEV_NAME     "/dev/ctc_cpm"
/*
 * Macros to help debugging
 */

#undef PDEBUG             /* undef it, just in case */
#undef CTC_CPM_DEBUG
#ifdef CTC_CPM_DEBUG
#ifdef __KERNEL__
     /* This one if debugging is on, and kernel space */
#define PDEBUG(fmt, args...) printk( KERN_DEBUG "ctc_cpm: " fmt, ## args)
#else
     /* This one for user space */
#define PDEBUG(fmt, args...) fprintf(stderr, fmt, ## args)
#endif
#else
#define PDEBUG(fmt, args...) /* not debugging: nothing */
#endif

#undef PDEBUGG
#define PDEBUGG(fmt, args...) /* nothing: it's a placeholder */

/* MPC8247 */
#define CTC_CPM_ADDR	    ((uint32_t)0xF0000000)  /* from Linux/arch/ppc/syslib/cpm2_common.h */
#define CTC_CPM_SIZE        0x40000         /* size from from Linux/arch/ppc/syslib/cpm2_common.h "cpm2_map_t" */

#define CTC_CPM_MAJOR       105
#define CTC_CPM_NR_DEVS     1



/*
 * Split minors in two parts
 */
#define TYPE(minor)	(((minor) >> 4) & 0xf)	/* high nibble */
#define NUM(minor)	((minor) & 0xf)		/* low  nibble */


#define CTC_CPM_IOCSQUANTUM _IOW(CTC_CPM_IOC_MAGIC,  1, int)
#define CTC_CPM_IOCSQSET    _IOW(CTC_CPM_IOC_MAGIC,  2, int)
#define CTC_CPM_IOCTQUANTUM _IO(CTC_CPM_IOC_MAGIC,   3)
#define CTC_CPM_IOCTQSET    _IO(CTC_CPM_IOC_MAGIC,   4)
#define CTC_CPM_IOCGQUANTUM _IOR(CTC_CPM_IOC_MAGIC,  5, int)
#define CTC_CPM_IOCGQSET    _IOR(CTC_CPM_IOC_MAGIC,  6, int)
#define CTC_CPM_IOCQQUANTUM _IO(CTC_CPM_IOC_MAGIC,   7)
#define CTC_CPM_IOCQQSET    _IO(CTC_CPM_IOC_MAGIC,   8)
#define CTC_CPM_IOCXQUANTUM _IOWR(CTC_CPM_IOC_MAGIC, 9, int)
#define CTC_CPM_IOCXQSET    _IOWR(CTC_CPM_IOC_MAGIC,10, int)
#define CTC_CPM_IOCHQUANTUM _IO(CTC_CPM_IOC_MAGIC,  11)
#define CTC_CPM_IOCHQSET    _IO(CTC_CPM_IOC_MAGIC,  12)

#define CTC_CPM_READ        _IO(CTC_CPM_IOC_MAGIC,   15)
#define CTC_CPM_WRITE       _IO(CTC_CPM_IOC_MAGIC,   16)


/*
 * The other entities only have "Tell" and "Query", because they're
 * not printed in the book, and there's no need to have all six.
 * (The previous stuff was only there to show different ways to do it.
 */
#define CTC_CPM_P_IOCTSIZE _IO(CTC_CPM_IOC_MAGIC,   13)
#define CTC_CPM_P_IOCQSIZE _IO(CTC_CPM_IOC_MAGIC,   14)
/* ... more to come */

#define CTC_CPM_IOC_MAXNR 14

#endif /* _CTC_CPM_H_ */

