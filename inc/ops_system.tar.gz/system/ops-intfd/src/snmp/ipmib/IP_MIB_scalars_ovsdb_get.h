#ifndef IP_MIB_SCALARS_OVSDB_GET_H
#define IP_MIB_SCALARS_OVSDB_GET_H

#include "vswitch-idl.h"
#include "ovsdb-idl.h"
extern struct ovsdb_idl *idl;

#endif