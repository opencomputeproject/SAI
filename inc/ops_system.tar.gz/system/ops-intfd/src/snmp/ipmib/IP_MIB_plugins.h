#ifndef IP_MIB_PLUGINS_H
#define IP_MIB_PLUGINS_H

void ops_snmp_init(void);
void ops_snmp_run(void);
void ops_snmp_wait(void);
void ops_snmp_shutdown(void);

#endif