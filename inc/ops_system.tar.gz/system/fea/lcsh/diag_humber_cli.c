#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>

#include "cli.h"
#include "clish.h"
#include "lcsh_lcmtlk.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "ctclib_show.h"
#include "glb_phy_define.h"
#include "ctclib_show.h"

#include "glb_debug_define.h"
#include "glb_hw_define.h"
#include "sal.h"
#include "lcsh_client.h"

#include "lcsh_debug.h"
#include "lcsh_error.h"
#include "clish.h"
#include "glb_tempfile_define.h"

#include "diag_chip.h"

int32 diag_chip_do_diag(struct cli *cli, diag_chip_opcode_t opcode, uint32 chip, 
                        uint32 from_idx, uint32 to_idx, uint32 *buf1,uint32 buf1_size, uint32 *buf2,uint32 buf2_size)
{
    int32 ret = 0;
    char buf[256];
    FILE *fp;
   
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_chip_req_t req ;

    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&req, 0, sizeof(diag_chip_req_t));
    sal_memset(buf, 0, sizeof(buf));
    
    req.opcode = opcode;
    req.chip_id = chip;
    req.fromIdx= from_idx;
    req.toIdx= to_idx;
    if(buf1 != NULL)
    {
        sal_memcpy(req.buf1, (uint8 *)buf1, buf1_size*4);
    }
    
    if(buf2 != NULL)
    {
        sal_memcpy(req.buf2, (uint8 *)buf2, buf2_size*4);
    }    
    
    sal_memcpy(st_msg.msg, &req, sizeof(diag_chip_req_t));
    st_msg.msg_len = sizeof(diag_chip_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_DIAG_CHIP;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message fail, error id is %d", ret);
        cli_out(cli, "Lcsh: send message fail!\n");
        return ret;
    }

    if (LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "operation fail.\n");
         /* Open the file. */
        fp = sal_fopen (DIAG_CHIP_TEMP_FILE, "r");
        if (fp == NULL)
        {
            cli_out(cli, "open diag temp file err\n");
            return CLI_ERROR;
        }
        
        while (fgets (buf, 256, fp))
        {
            cli_out (cli, "%s", buf);
        }

        fclose (fp);
        return CLI_ERROR;
    }
          
    /* Open the file. */
    fp = sal_fopen (DIAG_CHIP_TEMP_FILE, "r");
    if (fp == NULL)
    {
        cli_out(cli, "open diag temp file err\n");
        return CLI_ERROR;
    }
    
    while (fgets (buf, 256, fp))
    {
        cli_out (cli, "%s", buf);
    }

    fclose (fp);
    return CLI_SUCCESS;

}


CLI(diag_tcam_write_entry,
    diag_tcam_write_entry_cmd,
    "tcam write humber CHIP_ID entry INDEX DATA  MASK (internal|external)",
    "tcam",
    "write",
    "humber",
    "chip index",
    "entry",
    "entry index",
    "data value",
    "mask value",
    "internal",
    "external")
{
    uint32 chip = 0;
    uint32 entry_index;
    uint8 is_internal = 0;
    uint32 data[4];
    uint32 mask[4];
    char *data_string;
    char *mask_string;
    int8 data_len;
    int8 mask_len;
    char datastuff[24];
    char maskstuff[24];
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE("entry index", entry_index, argv[1], 0, 0xFFFFFFFF);

    if((argv[2][0] != '0')||(argv[2][1] != 'x')||(argv[3][0] != '0')||(argv[3][1] != 'x'))
    {
        cli_out(cli, "Please input Hex value\n");
        return CLI_ERROR;
    }
    
    data_string = argv[2];
    mask_string = argv[3];

    if (sal_strcmp(argv[4], "internal") == 0) 
    {
        is_internal = 1;
    }
    data_len = sal_strlen(data_string);
    mask_len = sal_strlen(mask_string );
    
    if((data_len > (20 +2))||(mask_len > (20 +2)))
    {
        cli_out(cli,"Input value is too large, it must under 20 bytes\n");
        return CLI_ERROR;
    }    

    sal_memset(data, 0,sizeof(data));
    sal_memset(mask, 0,sizeof(mask));
    sal_memset(datastuff, '0',sizeof(datastuff));
    sal_memset(maskstuff, '0',sizeof(maskstuff));

    sal_memcpy((uint8 *)datastuff+(20-(data_len-2))+4, data_string + 2,data_len-2); 
    sal_memcpy((uint8 *)maskstuff+(20-(mask_len-2))+4, mask_string + 2,mask_len-2); 

    sal_sscanf(datastuff, "%8x", &data[1]);
    sal_sscanf((datastuff + 8),"%8x", &data[2]);
    sal_sscanf((datastuff + 16),"%8x", &data[3]);

    sal_sscanf(maskstuff, "%8x", &mask[1]);
    sal_sscanf((maskstuff + 8),"%8x", &mask[2]);
    sal_sscanf((maskstuff + 16),"%8x", &mask[3]);

    return diag_chip_do_diag(cli, DIAG_CHIP_WRITE_TCAM_ENTRY, chip, entry_index, is_internal, data,4, mask,4); 

}

CLI(diag_tcam_read_entry,
    diag_tcam_read_entry_cmd,
    "tcam read humber CHIP_ID entry INDEX (internal|external)",
    "tcam",
    "read",
    "humber",
    "chip index",
    "entry",
    "entry index",
    "internal tcam",
    "external tcam")
{
    uint32 chip = 0;
    uint32 entry_index;
    uint8 is_internal = 0;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE("entry index", entry_index, argv[1], 0, 0xFFFFFFFF);
    
    if (sal_strcmp(argv[2], "internal") == 0) 
    {
        is_internal = 1;
    }
    return diag_chip_do_diag(cli, DIAG_CHIP_READ_TCAM_ENTRY, chip, entry_index, is_internal, NULL,0,NULL,0); 
}

CLI(diag_tcam_read_register,
    diag_tcam_read_register_cmd,
    "tcam read humber CHIP_ID register INDEX",
    "tcam",
    "read",
    "humber",
    "chip index",
    "register",
    " index")
{
    uint32 chip = 0;
    uint32 index;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(" index", index, argv[1], 0, 0xFFFFFFFF);
    
    return diag_chip_do_diag(cli, DIAG_CHIP_READ_TCAM_REG, chip, index, 0,  NULL,0,NULL,0); 
}

CLI(diag_tcam_write_register,
    diag_tcam_write_register_cmd,
    "tcam write humber CHIP_ID register INDEX VALUE",
    "tcam",
    "write",
    "humber",
    "chip index",
    "register",
    "index",
    "value")
{
    uint32 chip = 0;
    uint32 index;
    uint32 data[4];  
    char *data_string;
    int8 data_len;
    char datastuff[24];

    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE("index", index, argv[1], 0, 0xFFFFFFFF);

    if((argv[2][0] != '0')||(argv[2][1] != 'x'))
    {
        cli_out(cli, "Please input Hex value\n");
        return CLI_ERROR;
    }
    
    data_string = argv[2];
    
    data_len = sal_strlen(data_string);

    
    if(data_len > (20 +2))
    {
        cli_out(cli,"Input value is too large, it must under 20 bytes\n");
        return CLI_ERROR;
    }    

    sal_memset(data, 0,sizeof(data));
    
    sal_memset(datastuff, '0',sizeof(datastuff));


    sal_memcpy((uint8 *)datastuff+(20-(data_len-2))+4, data_string + 2,data_len-2); 
 

    sal_sscanf(datastuff, "%8x", &data[1]);
    sal_sscanf((datastuff + 8),"%8x", &data[2]);
    sal_sscanf((datastuff + 16),"%8x", &data[3]);

    return diag_chip_do_diag(cli, DIAG_CHIP_WRITE_TCAM_REG, chip, index, 0, data,4, NULL,0); 

}

CLI(diag_humber_run_capture,
    diag_humber_run_capture_cmd,
    "run capture humber CHIP_ID (exttcam|inttcam|ddr|qdr)",
    "run",
    "capture",
    "humber",
    "chip index",
    "external tcam",
    "internal tcam",
    "ddr",
    "qdr")
{
    uint32 chip = 0;
    capture_type_t capture_type;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    
    if (sal_strcmp(argv[1], "exttcam") == 0) 
    {
        capture_type = CAPTURE_EXTCAM;
    }
    else if (sal_strcmp(argv[1], "inttcam") == 0) 
    {
        capture_type = CAPTURE_INTCAM;
    }
    else if (sal_strcmp(argv[1], "ddr") == 0) 
    {
        capture_type = CAPTURE_DDR;
    }
    else if (sal_strcmp(argv[1], "qdr") == 0) 
    {
        capture_type = CAPTURE_QDR;
    }
    else
    {
        cli_out(cli, "unknown capture type\n");
        return CLI_ERROR;
    }
    
    return diag_chip_do_diag(cli, DIAG_CHIP_CAPTURE_START, chip, capture_type, 0, NULL,0,NULL,0); 
}

CLI(diag_humber_check_capture,
    diag_humber_check_capture_cmd,
    "check capture humber CHIP_ID (exttcam|inttcam|ddr|qdr)",
    "check",
    "capture",
    "humber",
    "chip index",
    "external tcam",
    "internal tcam",
    "ddr",
    "qdr")
{
    uint32 chip = 0;
    capture_type_t capture_type;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    
    if (sal_strcmp(argv[1], "exttcam") == 0) 
    {
        capture_type = CAPTURE_EXTCAM;
    }
    else if (sal_strcmp(argv[1], "inttcam") == 0) 
    {
        capture_type = CAPTURE_INTCAM;
    }
    else if (sal_strcmp(argv[1], "ddr") == 0) 
    {
        capture_type = CAPTURE_DDR;
    }
    else if (sal_strcmp(argv[1], "qdr") == 0) 
    {
        capture_type = CAPTURE_QDR;
    }
    else
    {
        cli_out(cli, "unknown capture type\n");
        return CLI_ERROR;
    }
    
    return diag_chip_do_diag(cli, DIAG_CHIP_CAPTURE_STOP, chip, capture_type, 0, NULL,0,NULL,0); 
}


CLI(diag_humber_run_bist,
    diag_humber_run_bist_cmd,
    "run bist humber CHIP_ID (exttcam|inttcam|ddr|qdr)",
    "run",
    "bist",
    "humber",
    "chip index",
    "external tcam",
    "internal tcam",
    "ddr",
    "qdr")
{
    uint32 chip = 0;
    bist_type_t bist_type;
//	uint32 latency = 0;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
	
	if (sal_strcmp(argv[1], "exttcam") == 0) 
    {
        bist_type = BIST_EXTCAM;
    }
    else if (sal_strcmp(argv[1], "inttcam") == 0) 
    {
        bist_type = BIST_INTCAM;
    }
    else if (sal_strcmp(argv[1], "ddr") == 0) 
    {
        bist_type = BIST_DDR;
    }
    else if (sal_strcmp(argv[1], "qdr") == 0) 
    {
        bist_type = BIST_QDR;
    }
    else
    {
        cli_out(cli, "unknown bist type\n");
        return CLI_ERROR;
    }

	return diag_chip_do_diag(cli, DIAG_CHIP_BIST_START, chip, bist_type, 0, NULL,0,NULL,0); 
}

CLI(diag_humber_check_bist,
    diag_humber_check_bist_cmd,
    "check bist humber CHIP_ID (exttcam|inttcam|ddr|qdr)",
    "check",
    "bist",
    "humber",
    "chip index",
    "external tcam",
    "internal tcam",
    "ddr",
    "qdr")
{
    uint32 chip = 0;
    bist_type_t bist_type;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    
    if (sal_strcmp(argv[1], "exttcam") == 0) 
    {
        bist_type = BIST_EXTCAM;
    }
    else if (sal_strcmp(argv[1], "inttcam") == 0) 
    {
        bist_type = BIST_INTCAM;
    }
    else if (sal_strcmp(argv[1], "ddr") == 0) 
    {
        bist_type = BIST_DDR;
    }
    else if (sal_strcmp(argv[1], "qdr") == 0) 
    {
        bist_type = BIST_QDR;
    }
    else
    {
        cli_out(cli, "unknown bist type\n");
        return CLI_ERROR;
    }
    
    return diag_chip_do_diag(cli, DIAG_CHIP_BIST_STOP, chip, bist_type, 0, NULL,0,NULL,0); 
}


CLI(diag_humber_show_humber_discard,
    diag_humber_show_humber_discard_cmd,
    "show humber CHIP_ID discard",
    "show information",
    "humber",
    "chip index",
    "discard type")
{
    uint32 chip = 0;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    return diag_chip_do_diag(cli, DIAG_CHIP_SHOW_DISCARD_TYPE, chip, 0, 0, NULL,0,NULL,0); 
}

CLI(diag_humber_show_humber_info,
    diag_humber_show_humber_info_cmd,
    "show humber CHIP_ID (gmac|xgmac|sgmac|qmac|muxnetrxtx|ipe|fwd|epe|cpumac|eloop|fabric|interrupt|internal| \
                        oam|parser|shareds|tbinfoarb|tcam|queueid|queuedepth|hashds) (INDEX|)",
    "show information",
    "humber",
    "chip index",
    "gmac",
    "xgmac",
    "sgmac",
    "qmac",
    "muxnetrxtx",
    "ipe",
    "fwd",
    "epe",
    "cpumac",
    "eloop",
    "fabric",
    "interrupt",
    "internal",
    "oam",
    "parser",
    "shareds",
    "tbinfoarb",
    "tcam",
    "queueid",
    "queuedepth",
    "hashds",
    "index")
{
    uint32 chip = 0;
    humber_info_type_t humber_info_type;
    uint32 index = 0;
    
    CLI_GET_INTEGER_RANGE("chip index", chip, argv[0], 0, 0);
    
    if (sal_strcmp(argv[1], "gmac") == 0) 
    {
        humber_info_type = HUMBER_INFO_GMAC;
    }
    else if (sal_strcmp(argv[1], "xgmac") == 0) 
    {
        humber_info_type = HUMBER_INFO_XGMAC;
    }
    else if (sal_strcmp(argv[1], "sgmac") == 0) 
    {
        humber_info_type = HUMBER_INFO_SGMAC;
    }
    else if (sal_strcmp(argv[1], "qmac") == 0) 
    {
        humber_info_type = HUMBER_INFO_QMAC;
    }
    else if (sal_strcmp(argv[1], "muxnetrxtx") == 0) 
    {
        humber_info_type = HUMBER_INFO_MUXNETRXTX;
    }
    else if (sal_strcmp(argv[1], "ipe") == 0) 
    {
        humber_info_type = HUMBER_INFO_IPE;
    }
    else if (sal_strcmp(argv[1], "fwd") == 0) 
    {
        humber_info_type = HUMBER_INFO_FWD;
    }
    else if (sal_strcmp(argv[1], "epe") == 0) 
    {
        humber_info_type = HUMBER_INFO_EPE;
    }
    else if (sal_strcmp(argv[1], "cpumac") == 0) 
    {
        humber_info_type = HUMBER_INFO_CPUMAC;
    }
    else if (sal_strcmp(argv[1], "eloop") == 0) 
    {
        humber_info_type = HUMBER_INFO_ELOOP;
    }
    else if (sal_strcmp(argv[1], "fabric") == 0) 
    {
        humber_info_type = HUMBER_INFO_FABRIC;
    }
    else if (sal_strcmp(argv[1], "interrupt") == 0) 
    {
        humber_info_type = HUMBER_INFO_INTERRUPT;
    }
    else if (sal_strcmp(argv[1], "internal") == 0) 
    {
        humber_info_type = HUMBER_INFO_INTERNAL;
    }
    else if (sal_strcmp(argv[1], "oam") == 0) 
    {
        humber_info_type = HUMBER_INFO_OAM;
    }
    else if (sal_strcmp(argv[1], "parser") == 0) 
    {
        humber_info_type = HUMBER_INFO_PARSER;
    }
    else if (sal_strcmp(argv[1], "shareds") == 0) 
    {
        humber_info_type = HUMBER_INFO_SHAREDS;
    }
    else if (sal_strcmp(argv[1], "tbinfoarb") == 0) 
    {
        humber_info_type = HUMBER_INFO_TBINFOARB;
    }
    else if (sal_strcmp(argv[1], "tcam") == 0) 
    {
        humber_info_type = HUMBER_INFO_TCAM;
    }
    else if (sal_strcmp(argv[1], "queueid") == 0) 
    {
        humber_info_type = HUMBER_INFO_QUEUEID;
    }
    else if (sal_strcmp(argv[1], "queuedepth") == 0) 
    {
        humber_info_type = HUMBER_INFO_QUEUEDEPTH;
    }
    else if (sal_strcmp(argv[1], "hashds") == 0) 
    {
        humber_info_type = HUMBER_INFO_HASHDS;
    }    
    else
    {
        cli_out(cli, "unknown humber info type\n");
        return CLI_ERROR;
    }

    if(argc > 2)
    {
        CLI_GET_INTEGER_RANGE("chip index", index, argv[2], 0, 0xFFFFFFFF);
    }
    return diag_chip_do_diag(cli, DIAG_CHIP_SHOW_INFO, chip, humber_info_type, index, NULL,0,NULL,0); 
}

CLI(diag_oam_regwalk,
    diag_oam_regwalk_cmd,
    "oam register walk (sup|core)",
    "oam",
    "register",
    "walk",
    "sup",
    "core")
{
    regwalk_type_t regwalk_type;
        
    if (sal_strcmp(argv[0], "sup") == 0) 
    {
        regwalk_type = REG_WALK_SUP;
    }
    else if (sal_strcmp(argv[0], "core") == 0) 
    {
        regwalk_type = REG_WALK_CORE;
    }
    else
    {
        cli_out(cli, "unknown register walk type\n");
        return CLI_ERROR;
    }
    
    return diag_chip_do_diag(cli, DIAG_OAM_REGWALK, 0, 0, regwalk_type, NULL,0,NULL,0); 
}

CLI(diag_oam_show_stats,
    diag_oam_show_stats_cmd,
    "show oam stats",
    "show information",
    "oma fpga",
    "debug stats")
{        
    return diag_chip_do_diag(cli, DIAG_OAM_DEBUG_STATS, 0, 0, 0, NULL,0,NULL,0); 
}

CLI(diag_oam_run_bist,
    diag_oam_run_bist_cmd,
    "run oam bist",
    "run",
    "oma fpga",
    "bist")
{        
    return diag_chip_do_diag(cli, DIAG_OAM_BIST_START, 0, 0, 0, NULL,0,NULL,0); 
}

CLI(diag_oam_check_bist,
    diag_oam_check_bist_cmd,
    "check oam bist",
    "check",
    "oma fpga",
    "bist")
{        
    return diag_chip_do_diag(cli, DIAG_OAM_BIST_STOP, 0, 0, 0, NULL,0,NULL,0); 
}

CLI(diag_humber_show_humber_bus_info,
    diag_humber_show_humber_bus_info_cmd,
    "show humber CHIP_ID bus (busHa2Im|busIm2LmPI|busIm2LmPR|busLm2PpPI|busLm2PpPR|busMfEnqMsgFifo \
              |ha2NhPiBus|nh2HpPiBus|pr2HpPrBus|aqos2EditPiBus|cla2EditPiBus) START_MSG MSG_NUM",
    "show information",
    "humber",
    "show bus",
    "chip index",
    "show busHa2Im bus",
    "show busIm2LmPI bus",
    "show busIm2LmPR bus",
    "busLm2PpPI",
    "busLm2PpPR",
    "busMfEnqMsgFifo",
    "ha2NhPiBus",
    "nh2HpPiBus",
    "pr2HpPrBus",
    "aqos2EditPiBus",
    "cla2EditPiBus",
    "show START-MSG",
    "message number")
{
    uint32 msg_idx = 0;
    uint32 msg_num = 0;
    uint32 index = 0;
    uint32 chip_index = 0;
    uint32 humber_bus_info_type = 0;

    CLI_GET_INTEGER_RANGE("chip index", chip_index, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE("chip start msg", msg_idx, argv[2], 0, 0xFFFF);
    CLI_GET_INTEGER_RANGE("chip msg num", msg_num, argv[3], 0, 0xFFFF);
   
    if (0 == strncmp(argv[1], "busHa2Im", strlen("busHa2Im")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_BUSHA2IM;
    }
    else if (0 == strncmp(argv[1], "busIm2LmPI", strlen("busIm2LmPI")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_BUSIM2LMPI;
    }
    else if (0 == strncmp(argv[1], "busIm2LmPR", strlen("busIm2LmPR")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_BUSIM2LMPR;
    }
    else if (0 == strncmp(argv[1], "busLm2PpPI", strlen("busLm2PpPI")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_BUSLM2PPPI;
    }
    else if (0 == strncmp(argv[1], "busLm2PpPR", strlen("busLm2PpPR")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_BUSLM2PPPR;
    }
    else if (0 == strncmp(argv[1], "busMfEnqMsgFifo", strlen("busMfEnqMsgFifo")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_BUSMFENQMSGFIFO;
    }
    else if (0 == strncmp(argv[1], "ha2NhPiBus", strlen("ha2NhPiBus")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_HA2NHPIBUS;
    }
    else if (0 == strncmp(argv[1], "nh2HpPiBus", strlen("nh2HpPiBus")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_NH2HPPIBUS;
    }
    else if (0 == strncmp(argv[1], "pr2HpPrBus", strlen("pr2HpPrBus")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_PR2HPPRBUS;
    }
    else if (0 == strncmp(argv[1], "aqos2EditPiBus", strlen("aqos2EditPiBus")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_AQOS2EDITPIBUS;
    }
    else if (0 == strncmp(argv[1], "cla2EditPiBus", strlen("cla2EditPiBus")))
    {
        humber_bus_info_type = HUMBER_BUS_INFO_CLA2EDITPIBUS;
    }

    index = 1000*msg_idx + msg_num;
    return diag_chip_do_diag(cli, DIAG_CHIP_SHOW_BUS_INFO, chip_index, humber_bus_info_type, index, NULL,0,NULL,0);
}

int
diag_humber_cli_init(struct cli_tree *cli_tree)
{
/*modify by chenxw for bug 23980, 2013-07-29.*/
#if 0
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_tcam_read_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_tcam_write_entry_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_tcam_read_register_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_tcam_write_register_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_run_capture_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_check_capture_cmd);

	cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_run_bist_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_check_bist_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_show_humber_discard_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_show_humber_info_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_oam_regwalk_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_oam_show_stats_cmd);
    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_oam_run_bist_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_oam_check_bist_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_humber_show_humber_bus_info_cmd);
#endif    
    return 0;
}

