/**
 @file show_nh_table.c

 @date 2009-10-20

 @version v1.0


*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include "cli.h"
#include "clish.h"
#include "lcsh_lcmtlk.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "ctclib_show.h"
#include "glb_phy_define.h"
#include "ctclib_show.h"
#include "glb_debug_define.h"
#include "glb_hw_define.h"
#include "sal.h"
#include "lcsh_client.h"
#include "lcsh_debug.h"
#include "lcsh_error.h"
#include "clish.h"
#include "glb_tempfile_define.h"
#include "SRAMEntryMsg.h"
#include "LcmMsg.h"

/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/

extern int32 
lcsm_lcapi_show_sram_table( diag_sram_entry_req_t* p_req, diag_sram_entry_resp_t *p_resp);
extern int32 
diag_show_return_infor( struct cli *cli, diag_sram_entry_resp_t* resp);
extern void  
diag_show_sram_dsnexthop_head_explain(struct cli *cli);
extern void 
diag_show_sram_dsnexthop_head(struct cli *cli);
extern void 
diag_show_sram_dsnexthop_entry(struct cli *cli, diag_sram_entry_resp_t* resp, 
                               uint32 new_l2edit_ptr, uint32 new_l3edit_ptr);
extern void 
diag_show_sram_dsnh_8w_head_explain(struct cli *cli);
extern void 
diag_show_sram_dsnh_8w_head(struct cli *cli);
extern void
diag_show_sram_dsnh_8w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp );
extern void 
diag_show_sram_epe_dsnh_4w_head_explain(struct cli *cli);
void 
diag_show_sram_epe_dsnh_4w_head(struct cli *cli);
void
diag_show_sram_epe_dsnh_4w_entry(struct cli *cli, diag_sram_entry_resp_t* resp, 
                                 uint32 new_l2edit_ptr, uint32 new_l3edit_ptr );
void 
diag_show_sram_epe_dsnh_8w_head_explain(struct cli *cli);
void 
diag_show_sram_epe_dsnh_8w_head(struct cli *cli);
void
diag_show_sram_epe_dsnh_8w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp );
extern int32  
diag_show_sram_l2edit_lookback( struct cli *cli, diag_sram_entry_req_t* req, 
                                diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32  
diag_show_sram_l2edit_eth4w( struct cli *cli, diag_sram_entry_req_t* req, 
                             diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32 
diag_show_sram_l2edit_eth8w( struct cli *cli, diag_sram_entry_req_t* req, 
                             diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32  
diag_show_sram_l3edit_mpls4w( struct cli *cli, diag_sram_entry_req_t* req, 
                              diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32 
diag_show_sram_l3edit_mpls8w( struct cli *cli, diag_sram_entry_req_t* req, 
                              diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32 
diag_show_sram_l3edit_tunnelv4( struct cli *cli, diag_sram_entry_req_t* req, 
                                diag_sram_entry_resp_t* resp,int if_list, int if_explain);
int32
lcsm_lcapi_show_reg_table( diag_reg_entry_req_t* p_req, diag_reg_entry_resp_t *p_resp);

/****************************************************************************
*  
* Function
*
*****************************************************************************/
int32 
diag_rewrite_next_hop_edit_ptr(diag_sram_entry_req_t* req, 
                               uint32 old_l2edit_ptr, uint32 old_l3edit_ptr, 
                               uint32 *new_l2edit_ptr, uint32 *new_l3edit_ptr)
{
    diag_reg_entry_req_t reg_entry_req;
    diag_reg_entry_resp_t  reg_entry_resp;
    
    sal_memset(&reg_entry_req, 0, sizeof(diag_reg_entry_req_t));
    sal_memset(&reg_entry_resp, 0, sizeof(diag_reg_entry_resp_t));

    reg_entry_req.chip_id = req->chip_id;
    reg_entry_req.reg_type = DIAG_EPE_NEXT_HOP_CTL;

    /* retrieve  EPE_NEXT_HOP_CTL reg table */
    DIAG_SHOW_IF_ERROR_RETURN(lcsm_lcapi_show_reg_table(&reg_entry_req, &reg_entry_resp));

    switch (reg_entry_resp.epe_next_hop_ctl.edit_ptr_bits_num)
    {   /*see humber_epe_retrieve_nexthop() */
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_10BIT: 
            *new_l3edit_ptr = ((old_l2edit_ptr >>10)<<18) | old_l3edit_ptr;
            *new_l2edit_ptr = old_l2edit_ptr & 0x3FF;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_11BIT:
            *new_l3edit_ptr = ((old_l2edit_ptr >>11)<<18) | old_l3edit_ptr;
            *new_l2edit_ptr = old_l2edit_ptr & 0x7FF;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_13BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0x1FFFF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>17)<<12) | old_l2edit_ptr;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_14BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0xFFFF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>16)<<12) | old_l2edit_ptr;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_15BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0x7FFF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>15)<<12) | old_l2edit_ptr;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_16BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0x3FFF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>14)<<12) | old_l2edit_ptr;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_17BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0x1FFF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>13)<<12) | old_l2edit_ptr;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_18BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0xFFF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>12)<<12) | old_l2edit_ptr;

            break;
        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_19BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0x7FF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>11)<<12) | old_l2edit_ptr;

        case diag_HUMBER_EDIT_PTR_TYPE_L2EDIT_20BIT:
            *new_l3edit_ptr = old_l3edit_ptr & 0x3FF;
            *new_l2edit_ptr = ((old_l3edit_ptr >>10)<<12) | old_l2edit_ptr;

        default:
            *new_l3edit_ptr = old_l3edit_ptr;
            *new_l2edit_ptr = old_l2edit_ptr;
            break;
    }

    return CLI_SUCCESS;
}

/*see humber_epe_retrieve_nexthop() */
int32 
diag_show_sram_dsnh( struct cli *cli, diag_sram_entry_req_t* req, 
                     diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    uint32 l2_rewrite_type = 0;
    uint32 l3_rewrite_type = 0;
    uint32 l2edit_ptr = 0;
    uint32 l3edit_ptr = 0;

    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    
    if ( if_explain )
    {
        switch (req->table_type)        
        {
            case DIAG_DS_NEXTHOP:
                diag_show_sram_dsnexthop_head_explain(cli);
                break;
            case DIAG_DS_NEXTHOP8W:
                diag_show_sram_dsnh_8w_head_explain(cli);
                break;
            case DIAG_EPE_NEXT_HOP_INTERNAL4W:
                diag_show_sram_epe_dsnh_4w_head_explain(cli);
                break;
            case DIAG_EPE_NEXT_HOP_INTERNAL8W:
                diag_show_sram_epe_dsnh_8w_head_explain(cli);
                break;
            default:
                cli_out(cli,"%%The table type is not match in dsnh");
                return CLI_SUCCESS;
                break;
        }
        
         cli_out(cli,"\n");
    }
    
    switch (req->table_type)        
    {
        case DIAG_DS_NEXTHOP:
            diag_rewrite_next_hop_edit_ptr(req, 
                                           resp->dsnh.l2edit_ptr, 
                                           resp->dsnh.l3edit_ptr, 
                                           &l2edit_ptr, 
                                           &l3edit_ptr);

            diag_show_sram_dsnexthop_head( cli );
            diag_show_sram_dsnexthop_entry( cli, resp, l2edit_ptr, l3edit_ptr);

            l2_rewrite_type = resp->dsnh.l2_rewrite_type;
            l3_rewrite_type = resp->dsnh.l3_rewrite_type;
            break;
        case DIAG_DS_NEXTHOP8W:
            diag_show_sram_dsnh_8w_head( cli );
            diag_show_sram_dsnh_8w_entry( cli, resp );

            l2_rewrite_type = resp->ds_nexthop8w_t.l2_rewrite_type;
            l3_rewrite_type = resp->ds_nexthop8w_t.l3_rewrite_type;
            
            l2edit_ptr = resp->ds_nexthop8w_t.l2edit_ptr12to0 
                              | resp->ds_nexthop8w_t.l2edit_ptr19to13 << 13;
            
            l3edit_ptr = resp->ds_nexthop8w_t.l3edit_ptr170 
                              | resp->ds_nexthop8w_t.l3edit_ptr18 << 18 
                              | resp->ds_nexthop8w_t.l3edit_ptr18 << 19;
            break;
        case DIAG_EPE_NEXT_HOP_INTERNAL4W:
            diag_rewrite_next_hop_edit_ptr(req, 
                                           resp->ds_nexthop_interl_4w_t.l2edit_ptr, 
                                           resp->ds_nexthop_interl_4w_t.l3edit_ptr,
                                           &l2edit_ptr,
                                           &l3edit_ptr);

            diag_show_sram_epe_dsnh_4w_head( cli );
            diag_show_sram_epe_dsnh_4w_entry( cli, resp, l2edit_ptr, l3edit_ptr);

            l2_rewrite_type = resp->ds_nexthop_interl_4w_t.l2_rewrite_type;
            l3_rewrite_type = resp->ds_nexthop_interl_4w_t.l3_rewrite_type;
            
            break;
        case DIAG_EPE_NEXT_HOP_INTERNAL8W:
            diag_show_sram_epe_dsnh_8w_head( cli );
            diag_show_sram_epe_dsnh_8w_entry( cli, resp );

            l2_rewrite_type = resp->ds_nexthop_interl_8w_t.l2_rewrite_type;
            l3_rewrite_type = resp->ds_nexthop_interl_8w_t.l3_rewrite_type;

            l2edit_ptr = resp->ds_nexthop_interl_8w_t.l2edit_ptr12to0 
                              | resp->ds_nexthop_interl_8w_t.l2edit_ptr19to13 << 13;
            
            l3edit_ptr = resp->ds_nexthop_interl_8w_t.l3edit_ptr170
                              | resp->ds_nexthop_interl_8w_t.l3edit_ptr18 << 18
                              | resp->ds_nexthop_interl_8w_t.l3edit_ptr18 << 19;
            break;
        default:
            cli_out(cli,"%%The table type is not match in dsnh");
            return CLI_SUCCESS;
            break;
    }

    cli_out(cli, " \n"); 

    if ( !if_list )
    {
        return CLI_SUCCESS;
    }

    if ( DIAG_L2_REW_LOOPBACK == l2_rewrite_type )
    {
        req->table_type = DIAG_DS_L2_EDIT_LOOPBACK;
        req->index = l2edit_ptr;
        diag_show_sram_l2edit_lookback(cli, req, resp, if_list, if_explain);
        cli_out(cli,"\n");
    }
    else if ( DIAG_L2_REW_ETH_4W == l2_rewrite_type  )
    {
        req->table_type = DIAG_DS_L2_EDIT_ETH4W;
        req->index = l2edit_ptr;
        diag_show_sram_l2edit_eth4w(cli, req, resp, if_list, if_explain);
        cli_out(cli,"\n");
    }
    else if ( DIAG_L2_REW_ETH_8W == l2_rewrite_type  )
    {
        req->table_type = DIAG_DS_L2_EDIT_ETH4W;
        req->index = l2edit_ptr;
        diag_show_sram_l2edit_eth8w(cli, req, resp, if_list, if_explain);
        cli_out(cli,"\n");
    }
    if (DIAG_L3_REW_TUNNEL_V4 == l3_rewrite_type ) 
    {
        req->table_type = DIAG_DS_L3EDIT_TUNNEL_V4;
        req->index = l3edit_ptr;
        diag_show_sram_l3edit_tunnelv4(cli, req, resp, if_list, if_explain);
        cli_out(cli,"\n");
    }
    else if (DIAG_L3_REW_MPLS_4W == l3_rewrite_type ) 
    {
        req->table_type = DIAG_DS_L3EDIT_MPLS4W;
        req->index = l3edit_ptr;
        diag_show_sram_l3edit_mpls4w(cli, req, resp, if_list, if_explain);
        cli_out(cli,"\n");
    }
    else if (DIAG_L3_REW_MPLS_8W == l3_rewrite_type ) 
    {
        req->table_type = DIAG_DS_L3EDIT_MPLS8W;
        req->index = l3edit_ptr;
        diag_show_sram_l3edit_mpls8w(cli, req, resp, if_list, if_explain);
        cli_out(cli,"\n");
    }
    return CLI_SUCCESS;
}

