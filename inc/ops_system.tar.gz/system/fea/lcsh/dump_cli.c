/**
 @file dump_cli.c

 @date 2010-10-25

 @version v1.0


*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include <sys/types.h>
#include <netinet/in.h>

#include "sal.h"
#include "cli.h"
#include "clish.h"
#include "lcsh_client.h"
#include "lcsh_lcmtlk.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "glb_phy_define.h"
#include "ctclib_show.h"

/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/


/****************************************************************************
*  
* Function
*
*****************************************************************************/

int32
lcsh_dump_tx_show_by_dump_file(struct cli* cli, bool del_file, lcapi_show_req_t* p_req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t req;
    lcapi_lcm_lcsh_msg_t resp;

    sal_memset(&req, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    req.msg_type = LCAPI_LCM_LCSH_SHOW_BY_DUMP_FILE;
    sal_memcpy(req.msg, p_req, sizeof(lcapi_show_req_t));
    req.msg_len = sizeof(lcapi_show_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    ret = lcsh_clnt_send_msg(&req, &resp);
    if (ret)
    {
        cli_out(cli, "Internal error %d\n", ret);
        return ret;
    }

    if (resp.errcode) 
    {
        cli_out(cli, "msg %d errcode %d len %d \n", resp.msg_type, resp.errcode, resp.msg_len);    
        return CLI_SUCCESS; 
    }

    CTCLIB_DUMP_OUT_FILE_LINE(cli);
    if (del_file)
    {
        CTCLIB_DUMP_CLOSE_DELETE_FILE();
    }
    
    return CLI_SUCCESS;    
}


CLI(show_hagt_intr,
    show_hagt_intr_cmd,
    "show hagt intr (file|)",
    "Show running information",
    "HAL agent",
    "Interrupt",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_HAGT_INTR;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);

    return CLI_SUCCESS;
}

CLI(show_hagt_acl,
    show_hagt_acl_cmd,
    "show hagt acl (file|)",
    "Show running information",
    "HAL agent",
    "ACL module",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_HAGT_ACL;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);

    return CLI_SUCCESS;
}


CLI(show_hagt_qos,
    show_hagt_qos_cmd,
    "show hagt qos (file|)",
    "Show running information",
    "HAL agent",
    "QoS module",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_HAGT_QOS;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);

    return CLI_SUCCESS;
}

CLI(show_hagt_cpu_pdu,
    show_hagt_cpu_pdu_cmd,
    "show hagt cpu pdu (file|)",
    "Show running information",
    "HAL agent",
    "CPU PDU module",
    "PDU module",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_HAGT_PDU;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);

    return CLI_SUCCESS;
}

CLI(show_hagt_rmt,
    show_hagt_rmt_cmd,
    "show hagt rmt (file|)",
    "Show running information",
    "HAL agent",
    "RMT",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_HAGT_RMT;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);

    return CLI_SUCCESS;
}

CLI(show_cli_nexthop_by_nhid_type,
        show_cli_nexthop_by_nhid_type_cmd,
        "show sdk nexthop NHID (mcast|ipuc|ecmp|mpls|brguc|iloop|rspan|downmep) (detail|) (file|)",
        "Show running information",
        "SDK",
        "Nexthop module",
        "The nexthop ID",
        "Multicast nexthop",
        "IPUC nexthopID",
        "ECMP nexthopID",
        "MPLS nexthopID", 
        "BridgeUC nexthopID",
        "IPE Loopback nexthopID",
        "RSPAN nexthopID",
        "Downmep nexthopID",
        "Display detail information",
        "Keep dump file")
{
    lcapi_show_req_t req;
    bool detail = FALSE;
    bool del_file = TRUE;
    uint32 sub_type = 0;
    uint32 nhid;

    CLI_GET_INTEGER_RANGE("NexthopID", nhid, argv[0], 0, 0xFFFFFFFF);
    
    if (0 == sal_strncmp(argv[1], "mcast", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_MCAST;
    }
    else if(0 == sal_strncmp(argv[1], "brguc", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_BRGUC;
    }
    else if(0 == sal_strncmp(argv[1], "ipuc", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_IPUC;
    }
    else if(0 == sal_strncmp(argv[1], "mpls", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_MPLS;
    }
    else if(0 == sal_strncmp(argv[1], "ecmp", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_ECMP;
    }
    else if(0 == sal_strncmp(argv[1], "iloop", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_ILOOP;
    }
    else if(0 == sal_strncmp(argv[1], "rspan", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_RSPAN;
    }
    else if(0 == sal_strncmp(argv[1], "downmep", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_DOWNMEP;
    }
    else
    {
        cli_out(cli, "Invalid Nexthop Type Input\n");
    }

    if (3 == argc)
    {
        if ((sal_strncmp (argv[1], "file", 4) == 0))
        {
            del_file = FALSE;
        }
        if ((sal_strncmp (argv[1], "detail", 6) == 0))
        {
            detail = TRUE;
        }
    }
    else
    {
        detail = TRUE;
        del_file = FALSE;        
    }

    req.opcode = LCAPI_SHOW_SDK_NEXTHOP;
    req.param[0] = LCAPI_SHOW_SDK_NEXTHOP_BY_NHID;    
    req.param[1] = sub_type;
    req.param[2] = detail;
    req.param[3] = nhid;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);

    return CLI_SUCCESS;

}

CLI(show_cli_nexthop_all_by_type,
        show_cli_nexthop_all_by_type_cmd,
        "show sdk nexthop (mcast|brguc|ipuc|ecmp|mpls|iloop|rspan|downmep|all) (detail|) (file|)",
        "Show running information",
        "SDK",
        "Nexthop module",
        "All multicast nexthop",
        "All bridge unicast nexthop",
        "All ipuc nexthop",
        "All ecmp nexthop",
        "All mpls nexthop",
        "All iloop nexthop",
        "All RSPAN nexthop",
        "All Downmep nexthop",
        "All nexthop",
        "Display detail information",
        "Keep dump file")
{
    lcapi_show_req_t req;
    bool detail = FALSE;
    bool del_file = TRUE;
    uint32 sub_type = 0;
    
    if (0 == sal_strncmp(argv[0], "mcast", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_MCAST;
    }
    else if(0 == sal_strncmp(argv[0], "brguc", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_BRGUC;
    }
    else if(0 == sal_strncmp(argv[0], "ipuc", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_IPUC;
    }
    else if(0 == sal_strncmp(argv[0], "mpls", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_MPLS;
    }
    else if(0 == sal_strncmp(argv[0], "ecmp", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_ECMP;
    }
    else if(0 == sal_strncmp(argv[0], "iloop", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_ILOOP;
    }
    else if(0 == sal_strncmp(argv[0], "rspan", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_RSPAN;
    }
    else if(0 == sal_strncmp(argv[0], "downmep", 5))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_DOWNMEP;
    }  
    else if(0 == sal_strncmp(argv[0], "all", 3))
    {
        sub_type = LCAPI_SHOW_SDK_NH_TYPE_MAX;
    }
    else
    {
        cli_out(cli, "Invalid Nexthop Type Input\n");
    }

    if (2 == argc)
    {
        if ((sal_strncmp (argv[1], "file", 4) == 0))
        {
            del_file = FALSE;
        }
        if ((sal_strncmp (argv[1], "detail", 6) == 0))
        {
            detail = TRUE;
        }
    }
    else
    {
        detail = TRUE;
        del_file = FALSE;        
    }

    req.opcode = LCAPI_SHOW_SDK_NEXTHOP;
    req.param[0] = LCAPI_SHOW_SDK_NEXTHOP_ALL;    
    req.param[1] = sub_type;
    req.param[2] = detail;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;

}


CLI(show_cli_nexthop_table_offset_all_by_type,
        show_cli_nexthop_table_offset_all_by_type_cmd,
        "show sdk nexthop private-offset-pool (dsfwd|dsmet|nh4w|nh8w|l2editeth4w"
        "|l2editeth8w|l2editlpbk|l3editmpls4w|l3editmpls8w|l3edittunnelv4|l3edittunnelv6|all) (file|)",
        "Show running information",
        "SDK",
        "Nexthop module",
        "Private offset pool",
        "DsFwd",
        "DsMet",
        "DsNexthop4W",
        "DsNexthop8W",
        "DsL2EditEthernet4W",
        "DsL2EditEthernet8W",
        "DsL2EditLoopback",        
        "DsL3EditMPLS4W",
        "DsL3EditMPLS8W",
        "DsL3EditTunnelV4",
        "DsL3EditTunnelV6",
        "All nexthop table",
        "Keep dump file")
{
    lcapi_show_req_t req;
    bool detail = FALSE;
    bool del_file = TRUE;
    lcapi_show_sdk_nh_table_type_t sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_MAX;
    
    if (0 == sal_strncmp(argv[0], "dsfwd", 5))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_FWD;
    }
    else if(0 == sal_strncmp(argv[0], "dsmet", 5))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_MET;
    }
    else if(0 == sal_strncmp(argv[0], "nh4w", 4))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_NEXTHOP_4W;
    }
    else if(0 == sal_strncmp(argv[0], "nh8w", 4))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_NEXTHOP_8W;
    }
    else if(0 == sal_strncmp(argv[0], "l2editeth4w", 11))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L2EDIT_ETH_4W;
    }
    else if(0 == sal_strncmp(argv[0], "l2editeth8w", 11))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L2EDIT_ETH_8W;
    }
    else if(0 == sal_strncmp(argv[0], "l2editlpbk", 10))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L2EDIT_LPBK;
    }
    else if(0 == sal_strncmp(argv[0], "l3editmpls4w", 12))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L3EDIT_MPLS_4W;
    }  
    else if(0 == sal_strncmp(argv[0], "l3editmpls8w", 5))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L3EDIT_MPLS_8W;
    }
    else if(0 == sal_strncmp(argv[0], "l3edittunnelv4", 14))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L3EDIT_TUNNEL_V4;
    }  
    else if(0 == sal_strncmp(argv[0], "l3edittunnelv6", 14))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_L3EDIT_TUNNEL_V6;
    }
    else if(0 == sal_strncmp(argv[0], "all", 3))
    {
        sub_type = LCM_API_SHOW_SDK_NH_TABLE_TYPE_MAX;
    }
    else
    {
        cli_out(cli, "Invalid Nexthop Table Type Input\n");
    }

    if (2 == argc)
    {
        if ((sal_strncmp (argv[1], "file", 4) == 0))
        {
            del_file = FALSE;
        }
        if ((sal_strncmp (argv[1], "detail", 6) == 0))
        {
            detail = TRUE;
        }
    }
    else
    {
        detail = TRUE;
        del_file = FALSE;        
    }

    req.opcode = LCAPI_SHOW_SDK_NEXTHOP;
    req.param[0] = LCAPI_SHOW_SDK_NEXTHOP_PRIV_OFFSET_POOL;    
    req.param[1] = sub_type;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;

}

CLI(show_cli_nexthop_sram_offset_info,
        show_cli_nexthop_sram_offset_info_cmd,
        "show sdk nexthop global-offset (file|)",
        "Show running information",
        "SDK",
        "Nexthop module",
        "Global dynamic sram(Global DsNexthop and Global DsMet) offset allocation information",
        "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_SDK_NEXTHOP;
    req.param[0] = LCAPI_SHOW_SDK_NEXTHOP_GLB_OFFSET;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

/*modified by jiangz for bug16559, 2011-10-08, for merge sdk, start*/
enum dump_cli_humber_opf_type
{
    /*module ower self-define,format OPF_TYPE_XXXX*/
    OPF_USRID_VLAN_KEY,
    OPF_USRID_MAC_KEY,
    OPF_USRID_IPV4_KEY,
    OPF_USRID_IPV6_KEY,
    /* add by chenzh for bug 17689, 2012-01-12*/
    LOCAL_MET_DSFWD_SRAM,   /*Local DsMet and DsFwd*/
    LOCAL_NEXTHOP_SRAM,     /*Nexthop 4w and 8w*/
    L2EDIT_SRAM,            /*L2edit 4w and 8w*/
    L3EDIT_SRAM,            /*L3edit 4w and 8w*/
    FDB_SRAM_HASH_COLLISION_KEY, 
    NHID_INTERNAL,
    OPF_ACL_INGRESS_LABEL,
#if 1 /* SYSTEM MODIFIED, jiangz for bug16559, 2011-10-08, merge sdk to 1.0.48 */
    OPF_ACL_EGRESS_LABEL = OPF_ACL_INGRESS_LABEL,
#else
    OPF_ACL_EGRESS_LABEL,
#endif
    OPF_ACL_PBR_LABEL,
    OPF_QOS_INGRESS_LABEL,
#if 1 /* SYSTEM MODIFIED, jiangz for bug16559, 2011-10-08, merge sdk to 1.0.48 */
    OPF_QOS_EGRESS_LABEL = OPF_QOS_INGRESS_LABEL,
#else
    OPF_QOS_EGRESS_LABEL,
#endif
    ACL_MAC_MPLS_IPV4_KEY,
    ACL_IPV6_KEY,
    ACL_PBR_IPV4_KEY,
    ACL_PBR_IPV6_KEY,
    QOS_MAC_MPLS_IPV4_KEY,
    QOS_IPV6_KEY,
    OPF_QOS_FLOW_POLICER,
    OPF_QOS_FLOW_POLICER_WITH_STATS,
    OPF_QOS_POLICER_PROFILE,
    FWD_STATS_SRAM,
    OPF_QUEUE_DROP_PROFILE,
    OPF_QUEUE_SHAPE_PROFILE,
    OPF_GROUP_SHAPE_PROFILE,
    OPF_QUEUE_GROUP,
    OPF_SERVICE_QUEUE,
    OPF_OAM_TCAM_KEY, /* used by DsEthOamKey, DsPbtOamKey, DsMplsOmaLableKey.. */
    OPF_OAM_MEP_RMEP, /* used by DsEthMep, dsEthRmep, DsMplsMep, DsMplsRmep */
    OPF_OAM_MA,       /* used by DsMa */
    OPF_OAM_MA_NAME,  /* used by DsMaName */  
    OPF_IPV4_UC_BLOCK,
    OPF_IPV6_UC_BLOCK,
    OPF_IPV4_MC_BLOCK,
    OPF_IPV6_MC_BLOCK,
    OPF_ACL_FWD_SRAM,
    ACL_MAC_MPLS_IPV4_KEY_HEAD,
    ACL_MAC_MPLS_IPV4_KEY_TAIL,
    ACL_IPV6_KEY_HEAD,
    ACL_IPV6_KEY_TAIL,
    ACL_PBR_IPV4_KEY_HEAD,
    ACL_PBR_IPV4_KEY_TAIL,
    ACL_PBR_IPV6_KEY_HEAD,
    ACL_PBR_IPV6_KEY_TAIL,
    QOS_MAC_MPLS_IPV4_KEY_HEAD,
    QOS_MAC_MPLS_IPV4_KEY_TAIL,
    QOS_IPV6_KEY_HEAD,
    QOS_IPV6_KEY_TAIL,
    OPF_FOAM_MEP, /* start from 2 */
    OPF_FOAM_MA,  /* start from 0 */
    OPF_TUNNEL_IPV4_SA,
    OPF_TUNNEL_IPV6_IP,  
    OPF_TUNNEL_IPV4_IPUC,
    OPF_TUNNEL_IPV6_IPUC,
    OPF_FOAM_MA_NAME,  /* start from 0 */    
    /*SYSTEM Modified by xgu for bug 16061, 2011-08-29*/
    OPF_USERID_VLAN_DEFAULT_KEY, /*used for userid vlan default entry*/
    MAX_OPF_TBL_NUM
};
/*modified by jiangz for bug16559, 2011-10-08, for merge sdk, end*/

struct dump_cli_opf_arg_entry
{
    enum dump_cli_humber_opf_type   arg_num;
    const char           *arg_name;
};

/* this data structure is related with enum sys_humber_opf_type */
struct dump_cli_opf_arg_entry dump_cli_opf_arg_list[] = 
{
    {OPF_USRID_VLAN_KEY, "usrid-vlan-key"},
    {OPF_USRID_MAC_KEY, "usrid-mac-key"},
    {OPF_USRID_IPV4_KEY, "usrid-ipv4-key"},
    {OPF_USRID_IPV6_KEY, "usrid-ipv6-key"},
    /*mod  by chenzh for bug 18009, 2012-02-29*/
    {LOCAL_MET_DSFWD_SRAM, "local-met-dsfwd-sram"},
    {LOCAL_NEXTHOP_SRAM, "local-nexthop-sram"},
    {L2EDIT_SRAM, "l2edit-sram"},
    {L3EDIT_SRAM, "l3edit-sram"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {FDB_SRAM_MAC_FL_KEY, "fdb-mac-filtering-key"},
#endif
    {FDB_SRAM_HASH_COLLISION_KEY, "fdb-hash-collision-key"},
    {NHID_INTERNAL, "nhid-internal"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {OPF_ACL_LABEL, "opf-acl-label"},
#endif
    {OPF_ACL_PBR_LABEL, "opf-pbr-label"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {OPF_QOS_LABEL, "opf-qos-label"},
#endif
    {ACL_MAC_MPLS_IPV4_KEY, "acl-mac-mpls-ipv4-key"},
    {ACL_IPV6_KEY, "acl-ipv6-key"},
    {ACL_PBR_IPV4_KEY, "pbr-ipv4-key"},
    {ACL_PBR_IPV6_KEY, "pbr-ipv6-key"},
    {QOS_MAC_MPLS_IPV4_KEY, "qos-mac-mpls-ipv4-key"},
    {QOS_IPV6_KEY, "qos-ipv6-key"},  
    {OPF_QOS_FLOW_POLICER, "opf-qos-flow-policer"},
    {OPF_QOS_FLOW_POLICER_WITH_STATS, "opf-qos-flow-policer-with-stats"},
    {OPF_QOS_POLICER_PROFILE, "opf-qos-policer-profile"},
    {FWD_STATS_SRAM, "fwd-stats-sram"},
    {OPF_QUEUE_DROP_PROFILE, "opf-queue-drop-profile"},
    {OPF_QUEUE_SHAPE_PROFILE, "opf-queue-shape-profile"},
    {OPF_GROUP_SHAPE_PROFILE, "opf-group-shape-profile"},
    {OPF_QUEUE_GROUP, "opf-queue-group"},
    {OPF_SERVICE_QUEUE, "opf-service-queue"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {OPF_QUEUE_INTERNAL_PORT, "opf-queue-internal-port"},
#endif
    {OPF_OAM_TCAM_KEY, "opf-oam-tcam-key"},
    {OPF_OAM_MEP_RMEP, "opf-oam-mep-rmep"},
    {OPF_OAM_MA, "opf-oam-ma"},
    {OPF_OAM_MA_NAME, "opf-oam-ma-name"},
    {OPF_IPV4_UC_BLOCK, "opf-ipucv4-block"},
    {OPF_IPV6_UC_BLOCK, "opf-ipucv6-block"},
    {OPF_IPV4_MC_BLOCK, "opf-ipmcv4-block"},
    {OPF_IPV6_MC_BLOCK, "opf-ipmcv6-block"},
    {ACL_PBR_IPV4_KEY_HEAD, "acl-pbr-ipv4-head"},
    {ACL_PBR_IPV4_KEY_TAIL, "acl-pbr-ipv4-tail"},
    {ACL_PBR_IPV6_KEY_HEAD, "acl-pbr-ipv6-head"},
    {ACL_PBR_IPV6_KEY_TAIL, "acl-pbr-ipv6-tail"},
    {OPF_FOAM_MEP, "opf-foam-mep"},
    {OPF_FOAM_MA, "opf-foam-ma-name"},
    {OPF_FOAM_MA_NAME, "opf-foam-ma-name"},
    /*SYSTEM Modified by xgu for bug 16061, 2011-08-29*/
    {OPF_USERID_VLAN_DEFAULT_KEY, "usrid-vlan-default-key"},
    {MAX_OPF_TBL_NUM, "all"},
    {(MAX_OPF_TBL_NUM+1), NULL},
};

CLI(show_cli_opf_alloc_info,
        show_cli_opf_alloc_info_cmd,
        "show sdk opf alloc (usrid-vlan-key|usrid-mac-key|usrid-ipv4-key|usrid-ipv6-key|\
           local-met-dsfwd-sram|local-nexthop-sram|l2edit-sram|l3edit-sram|\
           fdb-mac-filtering-key|fdb-hash-collision-key|nhid-internal|\
           opf-acl-label|opf-pbr-label|opf-qos-label|acl-mac-mpls-ipv4-key|acl-ipv6-key|\
           acl-pbr-ipv4-key|acl-pbr-ipv6-key|\
           qos-mac-mpls-ipv4-key|qos-ipv6-key|\
           opf-qos-flow-policer|opf-qos-flow-policer-with-stats|\
           opf-qos-policer-profile|fwd-stats-sram|opf-queue-drop-profile|\
           opf-queue-shape-profile|opf-group-shape-profile|opf-queue-group|\
           opf-service-queue|opf-queue-internal-port|opf-oam-tcam-key|opf-oam-mep-rmep|opf-oam-ma|\
           opf-oam-ma-name|opf-ipucv4-block|opf-ipucv6-block|\
           opf-ipmcv4-block|opf-ipmcv6-block|acl-pbr-ipv4-head|\
           acl-pbr-ipv4-tail|acl-pbr-ipv6-head|acl-pbr-ipv6-tail|\
           opf-foam-mep|opf-foam-ma-name|\
           opf-foam-ma-name|usrid-vlan-default-key|all) index INDEX",
        CLI_SHOW_STR,
        "SDK",
        "Offset pool freelist",
        "OPF alloc info",
        "OPF_USRID_VLAN_KEY",
        "OPF_USRID_MAC_KEY",
        "OPF_USRID_IPV4_KEY",
        "OPF_USRID_IPV6_KEY",
        "Local MET DSFWD SRAM, eg: DsFwd, Met",
        "Local Nexthop DYN SRAM, eg: DsNexthop, etc",
        "L2Edit DYN SRAM, eg: L2Edit, etc",
        "L3Edit DYN SRAM, eg: L3Edit, etc",
        "FDB_SRAM_MAC_FL_KEY",
        "FDB_SRAM_HASH_COLLISION_KEY",
        "NHID_INTERNAL",    
        "OPF_ACL_LABEL",
        "OPF_ACL_PBR_LABEL",
        "OPF_QOS_LABEL",
        "ACL_MAC_MPLS_IPV4_KEY",
        "ACL_IPV6_KEY",
        "ACL_PBR_IPV4_KEY",
        "ACL_PBR_IPV6_KEY",
        "QOS_MAC_MPLS_IPV4_KEY",
        "QOS_IPV6_KEY",
        "OPF_QOS_FLOW_POLICER",
        "OPF_QOS_FLOW_POLICER_WITH_STATS",
        "OPF_QOS_POLICER_PROFILE",
        "FWD_STATS_SRAM",
        "OPF_QUEUE_DROP_PROFILE",
        "OPF_QUEUE_SHAPE_PROFILE",
        "OPF_GROUP_SHAPE_PROFILE",
        "OPF_QUEUE_GROUP",
        "OPF_SERVICE_QUEUE",
        "OPF_QUEUE_INTERNAL_PORT",
        "OPF_OAM_TCAM_KEY",
        "OPF_OAM_MEP_RMEP",
        "OPF_OAM_MA",
        "OPF_OAM_MA_NAME", 
        "OPF_IPV4_UC_BLOCK",
        "OPF_IPV6_UC_BLOCK",
        "OPF_IPV4_MC_BLOCK",
        "OPF_IPV6_MC_BLOCK",
        "ACL_PBR_IPV4_KEY_HEAD",
        "ACL_PBR_IPV4_KEY_TAIL",
        "ACL_PBR_IPV6_KEY_HEAD",
        "ACL_PBR_IPV6_KEY_TAIL",
        "OPF_FOAM_MEP",
        "OPF_FOAM_MA",
        "OPF_FOAM_MA_NAME",
        "OPF_USERID_VLAN_DEFAULT_KEY",
        "All opf pool",
        "the index of OPF(ChipID)",
        "the index of OPF(CHipID)")
{
    int16 i2_num = 0;
    uint32 opf_type = 0;
    uint32 opf_index;
    bool del_file = TRUE;
    lcapi_show_req_t req;

    CLI_GET_INTEGER ("index", opf_index, argv[1]);     

    for (i2_num = 0; i2_num <= MAX_OPF_TBL_NUM; i2_num++)
    {

        if (sal_strlen(argv[0]) != sal_strlen(dump_cli_opf_arg_list[i2_num].arg_name))
        {
            continue;
        }

        if (0 == sal_memcmp(argv[0], dump_cli_opf_arg_list[i2_num].arg_name, sal_strlen(argv[0])))
        {
            opf_type =  dump_cli_opf_arg_list[i2_num].arg_num;
            break;
        }
    }

    if (dump_cli_opf_arg_list[i2_num].arg_name == NULL)
    {
        cli_out(cli, "%% Invaild input:%s \n", argv[0]);
        return CLI_ERROR; 
    }

    if (argc > 2)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    memset(&req, 0, sizeof(req));
    req.opcode = LCAPI_SHOW_SDK_OPF;
    req.param[0] = opf_type;
    req.param[1] = opf_index;
    if(MAX_OPF_TBL_NUM == opf_type)
    /*Dump all table*/
    {
        req.param[2] = 1;
    }
    
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_alloc_info,
        show_cli_alloc_info_cmd,
        "show sdk alloc (file|)",
        "Show running information",
        "SDK",
        "Alloc module",
        "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_SDK_ALLOC;
    req.param[0] = LCAPI_SHOW_SDK_ALLOC_INFO;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_master_info,
        show_cli_master_info_cmd,
        "show sdk master (file|)",
        "Show running information",
        "SDK",
        "Master module",
        "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_SDK_MASTER;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_drv_get_reg_or_tbl,
    show_cli_drv_get_reg_or_tbl_cmd,
    "read humber <0-1> (reg|tbl) (TBL_REG_NAME|) (detail|) (file|)",
    "Read registers",
    "Humber",
    "Index of humber",
    "Register",
    "Table",
    "Register or table name",
    "Detail",
    "Keep dump file")
{
    lcapi_show_req_t req;
    uint32 chip = 0;
    bool del_file = TRUE;
    uint32 all = TRUE;
    uint32 detail = FALSE;
    lcapi_chip_access_opcode_t reg_or_tbl = 0;
    
    CLI_GET_INTEGER_RANGE("Chip", chip, argv[0], 0, 1);

    if ((sal_strncmp (argv[1], "reg", 3) == 0))
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_S_REG;
    }
    else
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_S_TBL;
    }
    
    if (argc > 2)
    {
        if (argc == 5)
        {
            all = FALSE;
            detail = TRUE;
            del_file = FALSE;
        }
        else if (argc == 4)
        {
            if ((sal_strncmp (argv[2], "detail", 6) == 0))
            {
                all = TRUE;
                detail = TRUE;
                del_file = FALSE;
            }
            else
            {
                all = FALSE;
                if ((sal_strncmp (argv[3], "detail", 6) == 0))
                {
                    detail = TRUE;
                    del_file = TRUE;
                }
                else
                {
                    detail = FALSE;
                    del_file = FALSE;
                }
            }
        }
        else
        {
            if ((sal_strncmp (argv[2], "detail", 6) == 0))
            {
                all = TRUE;
                detail = TRUE;
                del_file = TRUE;
            }
            else if ((sal_strncmp (argv[2], "file", 4) == 0))
            {
                all = TRUE;
                detail = FALSE;
                del_file = FALSE;
            }
            else
            {
                all = FALSE;
                detail = FALSE;
                del_file = TRUE;
            }
        }
    }

    if (!all)
    { 
        sal_strncpy(req.buf, argv[2], LCAPI_SHOW_BUF_SIZE);
    }
    req.opcode = LCAPI_CHIP_ACCESS;
    req.param[0] = reg_or_tbl;
    req.param[1] = all;
    req.param[2] = detail;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_drv_read_reg_or_tbl_field,
    show_cli_drv_read_reg_or_tbl_field_cmd,
    "read humber <0-1> (reg|tbl) TBL_REG_NAME INDEX (<1-8192>|) (file|)",
    "Read registers",
    "Humber",
    "Index of humber",
    "Register",
    "Table",
    "Register or table name",
    "Register or table index",
    "The counts of sequential registers you need to read",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    uint32 chip = 0;
    uint32 index = 0;
    uint32 num = 1;
    lcapi_chip_access_opcode_t reg_or_tbl = 0;

    if ((sal_strncmp (argv[1], "reg", 3) == 0))
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_R_REG;
    }
    else
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_R_TBL;
    }
    CLI_GET_INTEGER_RANGE("Chip", chip, argv[0], 0, 1);
    CLI_GET_INTEGER_RANGE("Index", index, argv[3], 0, 0xFFFFFFFF);

    if (argc > 4)
    {
        if ((sal_strncmp (argv[4], "file", 4) == 0))
        {
            del_file = FALSE;
        }
        else
        {
            CLI_GET_INTEGER_RANGE("Number", num, argv[4], 1, 8192);
        }

        if (argc > 5)
        {
            del_file = FALSE;
        }
    }
    
    req.opcode = LCAPI_CHIP_ACCESS;
    req.param[0] = reg_or_tbl;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = num;
    sal_strncpy(req.buf, argv[2], LCAPI_SHOW_BUF_SIZE);

    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_drv_write_reg_or_tbl_field,
    show_cli_drv_write_reg_or_tbl_field_cmd,
    "write humber <0-1> (reg|tbl) TBL_REG_NAME FLD_ID INDEX VALUE",
    "Write registers",
    "Humber",
    "Index of humber",
    "Register",
    "Table",
    "Register or table name",
    "Field ID",
    "Register or table index",
    "Value")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    uint32 chip = 0;
    uint32 field_id = 0;
    uint32 index = 0;
    uint32 value = 0;
    lcapi_chip_access_opcode_t reg_or_tbl = 0;

    if ((sal_strncmp (argv[1], "reg", 3) == 0))
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_W_REG;
    }
    else
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_W_TBL;
    }
    CLI_GET_INTEGER_RANGE("Chip", chip, argv[0], 0, 1);
    CLI_GET_INTEGER_RANGE("Field ID", field_id, argv[3], 0, 0xFFFFFFFF);
    CLI_GET_INTEGER_RANGE("Index", index, argv[4], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE("Value", value, argv[5], 0, 0xFFFFFFFF);
        
    req.opcode = LCAPI_CHIP_ACCESS;
    req.param[0] = reg_or_tbl;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = field_id;
    req.param[4] = value;
    sal_strncpy(req.buf, argv[2], LCAPI_SHOW_BUF_SIZE);
    
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

#ifdef FOAM_SUPPORT  /* Added by kcao 2011-05-13 */
CLI(show_cli_drv_get_foam_reg_or_tbl,
    show_cli_drv_get_foam_reg_or_tbl_cmd,
    "read foam (reg|tbl) (TBL_REG_NAME|) (detail|) (file|)",
    "Read registers",
    "Foam",
    "Register",
    "Table",
    "Register or table name",
    "Detail",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    uint32 all = TRUE;
    uint32 detail = FALSE;
    lcapi_chip_access_opcode_t reg_or_tbl = 0;

    if ((sal_strncmp (argv[0], "reg", 3) == 0))
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_S_REG;
    }
    else
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_S_TBL;
    }
    
    if (argc > 1)
    {
        if (argc == 4)
        {
            all = FALSE;
            detail = TRUE;
            del_file = FALSE;
        }
        else if (argc == 3)
        {
            if ((sal_strncmp (argv[1], "detail", 6) == 0))
            {
                all = TRUE;
                detail = TRUE;
                del_file = FALSE;
            }
            else
            {
                all = FALSE;
                if ((sal_strncmp (argv[2], "detail", 6) == 0))
                {
                    detail = TRUE;
                    del_file = TRUE;
                }
                else
                {
                    detail = FALSE;
                    del_file = FALSE;
                }
            }
        }
        else
        {
            if ((sal_strncmp (argv[1], "detail", 6) == 0))
            {
                all = TRUE;
                detail = TRUE;
                del_file = TRUE;
            }
            else if ((sal_strncmp (argv[1], "file", 4) == 0))
            {
                all = TRUE;
                detail = FALSE;
                del_file = FALSE;
            }
            else
            {
                all = FALSE;
                detail = FALSE;
                del_file = TRUE;
            }
        }
    }

    if (!all)
    { 
        sal_strncpy(req.buf, argv[1], LCAPI_SHOW_BUF_SIZE);
    }
    req.opcode = LCAPI_FOAM_ACCESS;
    req.param[0] = reg_or_tbl;
    req.param[1] = all;
    req.param[2] = detail;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_drv_read_foam_reg_or_tbl_field,
    show_cli_drv_read_foam_reg_or_tbl_field_cmd,
    "read foam (reg|tbl) TBL_REG_NAME INDEX (<1-8192>|) (file|)",
    "Read registers",
    "Foam",
    "Register",
    "Table",
    "Register or table name",
    "Register or table index",
    "The counts of sequential registers you need to read",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    uint32 chip = 0;
    uint32 index = 0;
    uint32 num = 1;
    lcapi_chip_access_opcode_t reg_or_tbl = 0;

    if ((sal_strncmp (argv[0], "reg", 3) == 0))
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_R_REG;
    }
    else
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_R_TBL;
    }
    CLI_GET_INTEGER_RANGE("Index", index, argv[2], 0, 0xFFFFFFFF);

    if (argc > 3)
    {
        if ((sal_strncmp (argv[3], "file", 4) == 0))
        {
            del_file = FALSE;
        }
        else
        {
            CLI_GET_INTEGER_RANGE("Number", num, argv[3], 1, 8192);
        }

        if (argc > 4)
        {
            del_file = FALSE;
        }
    }
    
    req.opcode = LCAPI_FOAM_ACCESS;
    req.param[0] = reg_or_tbl;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = num;
    sal_strncpy(req.buf, argv[1], LCAPI_SHOW_BUF_SIZE);

    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_drv_write_foam_reg_or_tbl_field,
    show_cli_drv_write_foam_reg_or_tbl_field_cmd,
    "write foam (reg|tbl) TBL_REG_NAME FLD_ID INDEX VALUE",
    "Write registers",
    "Foam",
    "Register",
    "Table",
    "Register or table name",
    "Field ID",
    "Register or table index",
    "Value")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    uint32 chip = 0;
    uint32 field_id = 0;
    uint32 index = 0;
    uint32 value = 0;
    lcapi_chip_access_opcode_t reg_or_tbl = 0;

    if ((sal_strncmp (argv[0], "reg", 3) == 0))
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_W_REG;
    }
    else
    {
        reg_or_tbl = LCAPI_CHIP_ACCESS_W_TBL;
    }
    CLI_GET_INTEGER_RANGE("Field ID", field_id, argv[2], 0, 0xFFFFFFFF);
    CLI_GET_INTEGER_RANGE("Index", index, argv[3], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE("Value", value, argv[4], 0, 0xFFFFFFFF);
        
    req.opcode = LCAPI_FOAM_ACCESS;
    req.param[0] = reg_or_tbl;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = field_id;
    req.param[4] = value;
    sal_strncpy(req.buf, argv[1], LCAPI_SHOW_BUF_SIZE);
    
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_drv_read_foam_mep,
    show_cli_drv_read_foam_mep_cmd,
    "read foam mep INDEX (file|)",
    "Read registers",
    "Foam",
    "MEP",
    "Index",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    uint32 index = 0;

    if (argc > 1)
    {
        del_file = FALSE;
    }

    CLI_GET_INTEGER_RANGE("Index", index, argv[0], 0, 0xFFFFFFFF);
        
    req.opcode = LCAPI_FOAM_MEP;
    req.param[0] = index;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}
#endif /* !FOAM_SUPPORT */

CLI(show_cli_sdk_queue,
    show_cli_sdk_queue_cmd,
    "show sdk queue (file|)",
    "Show running information",
    "SDK",
    "Queue information",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_SDK_QUEUE;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

/*SYSTEM_MODIFIED by sunw for bug 14736, 2011-4-13*/
CLI(show_cli_mem_show_bucket_used_count,
    show_cli_mem_show_bucket_used_count_cmd,
    "show sdk mem bucket (file|)",
    "Show running information",
    "SDK",
    "Memory information",
    "Bucket used count",
    "Keep dump file")
{
    lcapi_show_req_t req;
    bool del_file = TRUE;
    
    if (argc > 0)
    {
        if ((sal_strncmp (argv[0], "file", 4) == 0))
        {
            del_file = FALSE;
        }
    }
    req.opcode = LCAPI_SHOW_SDK_MEM;
    req.param[0] = LCAPI_SHOW_SDK_MEM_INFO;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
    return CLI_SUCCESS;
}

CLI(show_cli_mem_all_by_type,
    show_cli_mem_all_by_type_cmd,
    "show sdk mem type (system|fdb|mpls|aclqos|queue|ipuc|ipmc|nexthop|\
avl|stats|l3if|port|vlan|aps|vpn|sortkey|linkagg|usrid|linklist|cli|vector|hash|\
opf|kal|oam|ptp|all) (detail|) (file|)",
    "Show running information",
    "SDK",
    "Memory information",
    "Show by type",
    "Memory used by SYSTEM module",
    "Memory used by FDB module",
    "Memory used by MPLS module",
    "Memory used by ACLQOS module",
    "Memory used by QUEUE module",
    "Memory used by IPUC module",
    "Memory used by IPMC module",
    "Memory used by NEXTHOP module",
    "Memory used by AVL module",
    "Memory used by STATS module",
    "Memory used by L3IF module",
    "Memory used by PORT module",
    "Memory used by VLAN module",
    "Memory used by APS module",
    "Memory used by VPN module",
    "Memory used by SORT_KEY module",
    "Memory used by LINKAGG module",
    "Memory used by USRID module",
    "Memory used by LINKLIST module",
    "Memory used by CLI module",
    "Memory used by VECTOR module",
    "Memory used by HASH module",
    "Memory used by OPF module",
    "Memory used by KAL module",
    "Memory used by OAM module",
    "Memory used by PTP module",
    "Show all module",
    "Detail",
    "Keep dump file")
{
	return CLI_ERROR;
#if 0 // TODO: Commented by xgu for compile, 20121120   
    lcapi_show_req_t req;
    bool detail = FALSE;
    bool del_file = TRUE;
    uint32 sub_type = 0;
    
    if (0 == sal_strncmp(argv[0], "system", 6))
    {
        sub_type = MEM_SYSTEM_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "fdb", 3))
    {
        sub_type = MEM_FDB_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "mpls", 4))
    {
        sub_type = MEM_MPLS_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "aclqos", 6))
    {
        sub_type = MEM_ACLQOS_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "queue", 5))
    {
        sub_type = MEM_QUEUE_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "ipuc", 4))
    {
        sub_type = MEM_IPUC_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "ipmc", 4))
    {
        sub_type = MEM_IPMC_MODULE;
    }
    else if(0 == sal_strncmp(argv[0], "nexthop", 7))
    {
        sub_type = MEM_NEXTHOP_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "avl", 3))
    {
        sub_type = MEM_AVL_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "stats", 5))
    {
        sub_type = MEM_STATS_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "L3IF", 4))
    {
        sub_type = MEM_L3IF_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "PORT", 4))
    {
        sub_type = MEM_PORT_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "vlan", 4))
    {
        sub_type = MEM_VLAN_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "aps", 3))
    {
        sub_type = MEM_APS_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "vpn", 3))
    {
        sub_type = MEM_VPN_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "sortkey", 8))
    {
        sub_type = MEM_SORT_KEY_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "linkagg", 7))
    {
        sub_type = MEM_LINKAGG_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "usrid", 5))
    {
        sub_type = MEM_USRID_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "linklist", 8))
    {
        sub_type = MEM_LINKLIST_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "cli", 3))
    {
        sub_type = MEM_CLI_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "vector", 6))
    {
        sub_type = MEM_VECTOR_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "hash", 4))
    {
        sub_type = MEM_HASH_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "opf", 3))
    {
        sub_type = MEM_OPF_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "kal", 3))
    {
        sub_type = MEM_KAL_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "oam", 3))
    {
        sub_type = MEM_OAM_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "ptp", 3))
    {
        sub_type = MEM_PTP_MODULE;
    }  
    else if(0 == sal_strncmp(argv[0], "all", 3))
    {
        sub_type = MEM_MAX_TYPE;
    }
    else
    {
        cli_out(cli, "Invalid Nexthop Type Input\n");
    }

    if (2 == argc)
    {
        if ((sal_strncmp (argv[1], "file", 4) == 0))
        {
            del_file = FALSE;
        }
        if ((sal_strncmp (argv[1], "detail", 6) == 0))
        {
            detail = TRUE;
        }
    }
    else if(3 == argc)
    {
        detail = TRUE;
        del_file = FALSE;        
    }

    req.opcode = LCAPI_SHOW_SDK_MEM;
    req.param[0] = LCAPI_SHOW_SDK_MEM_BY_TYPE;    
    req.param[1] = sub_type;
    req.param[2] = detail;
    lcsh_dump_tx_show_by_dump_file(cli, del_file, &req);
#endif	
    return CLI_SUCCESS;
}


int32
lcsh_show_hagt_init(struct cli_tree *cli_tree)
{
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_hagt_intr_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_hagt_acl_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_hagt_qos_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_hagt_cpu_pdu_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_hagt_rmt_cmd);

    /* SDK dump CLI */
    /* nexthop module */
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_nexthop_by_nhid_type_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_nexthop_all_by_type_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_nexthop_table_offset_all_by_type_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_nexthop_sram_offset_info_cmd);

    /* alloc module */
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_alloc_info_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_master_info_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_opf_alloc_info_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_get_reg_or_tbl_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_read_reg_or_tbl_field_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_write_reg_or_tbl_field_cmd);

#ifdef FOAM_SUPPORT  /* Added by kcao 2011-05-13 */    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_get_foam_reg_or_tbl_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_read_foam_reg_or_tbl_field_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_write_foam_reg_or_tbl_field_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_drv_read_foam_mep_cmd);
#endif /* !FOAM_SUPPORT */    
    /*SYSTEM_MODIFIED by sunw for bug 14736, 2011-4-13*/
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_mem_show_bucket_used_count_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_mem_all_by_type_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_cli_sdk_queue_cmd);
    
    return 0;
}

