
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include "cli.h"
//#include <readline/readline.h>
#include <time.h>
#include <sys/time.h>
#include "clish_exec.h"
#include <unistd.h>
#include <sys/statfs.h>
#include <sys/wait.h>
#include "clish.h"
#include "clish_filesystem.h"
//#include "afx.h"
//#include "eps_version.h"
#include "clish_cli.h"
//#include "cfgmgr.h"
//#include "cfm_message.h"

#define MAX_TIME_LEN 200
#define CLISH_MAXARGS      32
#define MAX_LINE_CHAR    50
#define M_APP_RATIO_BUFSZ   32

#if (0)

extern struct cli g_stcli;

struct cpu_stat {
    uint64_t used;  /* used time slices */
    uint64_t total; /* total time slices */
};
static struct cpu_stat cpu_stats[301];
static uint32_t cpu_stat_cur;

typedef struct app_disk_iter_cbarg
{
    struct cli *cli;
} app_disk_iter_cbarg_t;

/*******************************************************************************
 * Name:   app_show_cpu_summary_info 
 * Purpose: show summary cpu info
 * Input:   cli
 * Output: 
 * Return: N/A
 * Note: N/A
 ******************************************************************************/
static int
app_show_cpu_summary_info(struct cli *cli)
{
  float nLoad1;  /*load avg in 1 min*/
  float nLoad5;  /*load avg in 5 min*/
  float nLoad15;  /*load avg in 15 min*/
  FILE *pFile = NULL;
  char strLine[MAX_LINE_CHAR];

  pFile = fopen("/proc/loadavg", "r");
  if((NULL == pFile) || (feof(pFile)))
  {
    cli_out(cli, "%% Can not open cpuinfo file.");
    return -1;
  }

  /*read the first line*/
  memset(strLine, 0, sizeof(strLine));
  fgets(strLine, MAX_LINE_CHAR, pFile);  
  sscanf(strLine, "%f%f%f", &nLoad1, &nLoad5, &nLoad15);

  fclose(pFile);
  
  cli_out(cli, "Cpu utilization for 1 minute: %.2f; five minutes: %.2f; fifteen minutes: %.2f\n", nLoad1, nLoad5, nLoad15);

  return 0;
}

/*******************************************************************************
 * Name:   app_show_mem_summary_info 
 * Purpose: show summary memory info
 * Input:   cli
 * Output:  nTotal, nFree, nBuffers
 * Return: N/A
 * Note: N/A
 ******************************************************************************/
static int
app_show_mem_summary_info(struct cli *cli, int *total, int *free, int *buf)
{
  FILE *pFile = NULL;
  char strLine[MAX_LINE_CHAR];
  char strName[MAX_LINE_CHAR];  
  int nTotal, nFree, nBuffers; 

  pFile = fopen("/proc/meminfo", "r");
  if((NULL == pFile) || (feof(pFile)))
  {
    cli_out(cli, "%% Can not open meminfo file.");
    return -1;
  }
 
  memset(strLine, 0, sizeof(strLine));
  memset(strName, 0, sizeof(strName));

  /*first line is total memory size*/
  fgets(strLine, MAX_LINE_CHAR, pFile);  
  sscanf(strLine, "%s%d", strName, &nTotal);

  /*second line is free memory size*/
  fgets(strLine, MAX_LINE_CHAR, pFile);
  sscanf(strLine, "%s%d", strName, &nFree);

  /*third line is buffer memory size*/
  fgets(strLine, MAX_LINE_CHAR, pFile);
  sscanf(strLine, "%s%d", strName, &nBuffers);

  fclose(pFile);

  *total = nTotal;
  *free = nFree;
  *buf = nBuffers;
  
  return 0;
}

void update_cpu_stat()
{
    static FILE *filp = NULL;
    static char buf[0x100];
    uint64_t user, nice, system, idle, iowait, irq, softirq, steal;

    if (!filp)
        filp = fopen("/proc/stat", "r");

    if (!filp)
        return;

    rewind(filp);
    fflush(filp);
    fgets(buf, sizeof(buf), filp);
    sscanf(buf, "cpu %llu %llu %llu %llu %llu %llu %llu %llu",
            &user, &nice, &system, &idle, &iowait, &irq, &softirq, &steal);

    cpu_stats[cpu_stat_cur].used = user+nice+system+iowait+irq+softirq+steal;
    cpu_stats[cpu_stat_cur].total = cpu_stats[cpu_stat_cur].used + idle;

    cpu_stat_cur++;
    if (cpu_stat_cur >= 301)
        cpu_stat_cur = 0;

    return;
}

/*******************************************************************************
 * Name:    app_show_disk_part
 * Purpose: show disk part usage ratio
 * Input: 
 *   rdir: dir struct
 *   arg: callback argument
 * Output: 
 * Return: N/A
 * Note: 
 ******************************************************************************/
void
app_show_disk_part(rootdir_t *rdir, void *arg)
{
    app_disk_iter_cbarg_t *parg = (app_disk_iter_cbarg_t *)arg;
    struct cli *cli = NULL;
    struct statfs st;
    u_int8_t szTotalSize[FMT_SCALED_STRSIZE];
    u_int8_t szUsedSize[FMT_SCALED_STRSIZE];
    u_int8_t szFreeSize[FMT_SCALED_STRSIZE];
    u_int8_t szRatio[M_APP_RATIO_BUFSZ];
    u_int32_t used = 0l;
    double dRatio = 0.0;
    int64_t llSize = 0ll;
    
    if (NULL == rdir || NULL == parg)
    {
        return;
    }

    cli = parg->cli;
    if (statfs(rdir->real_name, &st) != 0)
    {
        cli_out(cli, "%% can't access %s\n", rdir->show_name);
        return;
    }

    fmt_scaled((int64_t)st.f_blocks * st.f_bsize, szTotalSize);

    used = st.f_blocks - st.f_bfree;
    llSize = (int64_t)used * st.f_bsize;
    fmt_scaled(llSize, szUsedSize);

    llSize = (int64_t)st.f_bavail * st.f_bsize;
    fmt_scaled(llSize, szFreeSize);

    dRatio = 100.0;
    if (used + st.f_bavail)
    {
        dRatio = (((long long) used) * 100 + (used + st.f_bavail) / 2) 
            / (used + st.f_bavail);
    }
    snprintf(szRatio, M_APP_RATIO_BUFSZ, "%.0f%%", dRatio);

    cli_out(cli, "%-12s%-12s%-12s%-12s%s\n", 
            rdir->show_name, szTotalSize, szUsedSize, szFreeSize, szRatio);
    return;
}

static int execvp_stdio(char *argv[], int in_fd, int out_fd, int err_fd)
{
    int ret;

    ret = fork();
    if (ret != 0)
        return ret;

    if (in_fd != STDIN_FILENO) {
        dup2(in_fd, STDIN_FILENO);
        close(in_fd);
    }

    if (out_fd != STDOUT_FILENO) {
        dup2(out_fd, STDOUT_FILENO);
        close(out_fd);
    }

    if (err_fd != STDERR_FILENO) {
        dup2(err_fd, STDERR_FILENO);
        close(err_fd);
    }

    execvp(argv[0], argv);
    exit(1); /*unreachable*/
}

#endif

/* Output modifier.  */
CLI (clish_modifier_begin,
     clish_modifier_begin_cli,
     "|| begin LINE",
     "Output modifiers",
     "Begin with the line that matches",
     "Regular Expression")
{
    return CLISH_MODIFIER_BEGIN;
}

CLI (clish_modifier_include,
     clish_modifier_include_cli,
     "|| include LINE",
     "Output modifiers",
     "Include lines that match",
     "Regular Expression")
{
    return CLISH_MODIFIER_INCLUDE;
}

CLI (clish_modifier_exclude,
     clish_modifier_exclude_cli,
     "|| exclude LINE",
     "Output modifiers",
     "Exclude lines that match",
     "Regular Expression")
{
    return CLISH_MODIFIER_EXCLUDE;
}

CLI (clish_modifier_grep,
     clish_modifier_grep_cli,
     "|| grep WORD",
     "Output modifiers",
     "Grep output",
     "Regular Expression")
{
    return CLISH_MODIFIER_GREP;
}

CLI (clish_modifier_grep_option,
     clish_modifier_grep_option_cli,
     "|| grep WORD WORD",
     "Output modifiers",
     "Grep output",
     "Grep option",
     "Regular Expression")
{
    return CLISH_MODIFIER_GREP;
}


/* modified by cuixl for bug 17129 , 2011-11-24 */
CLI (clish_overwrite_redirect_to_file,
     clish_overwrite_redirect_to_file_cli,
     "> GFILENAME overwrite",
     "Redirect output",
     "Output file",
     "overwrite old file")
{
     return CLISH_MODIFIER_REDIRECT;
}


/* check redirect file name */
int
clish_check_redirect_name(struct cli *cli, char *pszFilename)
{
  char szFullName[M_FULLPATH_MAX_LEN];

  if (NULL == cli || NULL == pszFilename)
  {
      return CLISH_MODIFIER_FILENAME_ERROR;
  }
  
  if (gen_check_and_get_filename(cli, pszFilename, szFullName, M_FULLPATH_MAX_LEN) != 0)
  {
      cli_out(cli, "%% Invalid redirect file name: %s\n", pszFilename);
      return CLISH_MODIFIER_FILENAME_ERROR;
  }

  if (syscmd_is_directory(szFullName))
  {
      cli_out(cli, "%% Is directory error: %s\n", pszFilename);
      return CLISH_MODIFIER_FILENAME_ERROR;
  }

  return CLISH_MODIFIER_REDIRECT;
}

CLI (clish_redirect_to_file,
     clish_redirect_to_file_cli,
     "> GFILENAME",
     "Redirect output",
     "Output file")
{
    return clish_check_redirect_name(cli, argv[0]);
}
#if (0)  
/*******************************************************************************
 * Name:    show_clk
 * Purpose:   show clock
 * Input:   N/A
 * Output: 
 * Return: N/A
 * Note: N/A
 ******************************************************************************/
CLI(show_clk,
    show_clk_cmd,
    "show clock",
    CLI_SHOW_STR,
    "Display the system clock"
    )
{
    time_t date; 
    char strTime[MAX_TIME_LEN + 1];     

    date = time(NULL);
    if(date == (time_t) - 1)
    {
        cli_out(cli, "%%Unable to get time of day.\n");
        return CLI_ERROR;
    }  

    memset(strTime, 0, sizeof(strTime));
    strftime(strTime, sizeof(strTime), "%T %Z %a %b %d %Y", localtime(&date));
    cli_out(cli, "%s\n", strTime);
    
    return CLI_SUCCESS;
}

CLI(show_memory_summary_total,
    show_memory_summary_total_cmd,
    "show memory summary total",
    CLI_SHOW_STR,
    CLI_SHOW_MEMORY_STR, 
    "Summary of memory statistics",
    "Total"
    )
{   
    int nTotal, nFree, nBuffers; 
    float utilization;


    /* show summary mem info*/
    app_show_mem_summary_info(cli, &nTotal, &nFree, &nBuffers);
    utilization = ((float)nTotal - (float)nFree) / (float)nTotal*100;
    cli_out(cli, "Total memory      : %-8dKB\n", nTotal);
    cli_out(cli, "Used memory       : %-8dKB\n", nTotal-nFree);
    cli_out(cli, "Free memory       : %-8dKB\n", nFree );
    cli_out(cli, "Buffer memory     : %-8dKB\n", nBuffers);

    cli_out(cli, "Memory utilization: %.2f%%\n",utilization);

    return CLI_SUCCESS;
}

CLI(show_process,
    show_process_cmd,
    "show processes",
    CLI_SHOW_STR,
    "Active process statistics"
    )
{
  char *argvo[CLISH_MAXARGS];
  int argco = 0;
  int ret;

  argvo[argco++] = "ps";  /*ps*/
  argvo[argco++] = "ex";  /*all the process*/
  argvo[argco++] = "-o";  /*output format*/
  argvo[argco++] = "pid,priority,stat,stackp,time,tname,comm";
  
  argvo[argco] = NULL;

  /*first show summary cpu info*/
  app_show_cpu_summary_info(cli);
  
  /* execute ps command */
  ret = clish_execvp(argvo);
  if(ret < 0 || get_last_exec_result() != 0)
  {
    cli_out(cli, "%% Can not show process!\n");
    return CLI_ERROR;
  }
  return CLI_SUCCESS;
}

/*******************************************************************************
 * Name:   show_process_memory 
 * Purpose: command for show memory per process
 * Input:   N/A
 * Output: 
 * Return: N/A
 * Note: N/A
 ******************************************************************************/
CLI(show_process_memory,
    show_process_memory_cmd,
    "show processes memory sorted (physical|virtual|core|)",
    CLI_SHOW_STR,
    "Active process statistics",
    "Show memory use per process",
    "Show sorted output based on percentage of utilization",
    "Non-swapped physical memory that a task has used",
    "Virtual memory usage of entire process",
    "Size in physical pages of the core image of the process"
    )
{
  char *argvo[CLISH_MAXARGS];
  int argco = 0;
  int nTotal, nFree, nBuffers; 
  int ret;

  argvo[argco++] = "ps";  /*ps*/
  argvo[argco++] = "ex";  /*all the process*/
  argvo[argco++] = "-o";  /*output format*/
  argvo[argco++] = "pid,tname,rss,vsz,sz,comm";
  argvo[argco++] = "k";
  if((0 == argc) || (!strncmp(argv[0], "physical", strlen("physical"))))
  {
    argvo[argco++] = "-rss";
  }
  else if(!strncmp(argv[0], "virtual", strlen("virtual")))
  {
    argvo[argco++] = "-vsz";
  }
  else if(!strncmp(argv[0], "core", strlen("core")))
  {
    argvo[argco++] = "-sz";
  }  
  argvo[argco] = NULL;  

  /*first show summary mem info*/
  app_show_mem_summary_info(cli, &nTotal, &nFree, &nBuffers);
  cli_out(cli, "Total: %d; Used: %d; Free: %d; Buffers: %d\n", nTotal, (nTotal-nFree), nFree, nBuffers);

  /* execute ps command */
  ret = clish_execvp(argvo);
  if(ret < 0 || get_last_exec_result() != 0)
  {
    cli_out(cli, "%% Can not show process!\n");
    return CLI_ERROR;
  }

  return CLI_SUCCESS;    
}

CLI(show_process_cpu,
    show_process_cpu_cmd,
    "show processes cpu sorted",
    CLI_SHOW_STR,
    "Active process statistics",
    "Show CPU use per process",
    "Show sorted output based on percentage of utilization"
    )
{
    struct cpu_stat *s1, *s2;
    uint32_t u, t;
    uint8_t n, f;
    char *_argv[0x10];
    int _argc;
    int pipe_fd[2], err_fd;
    char buf[0x100];
    int ret;

    s2 = &cpu_stats[(cpu_stat_cur+301-1)%301];
    s1 = &cpu_stats[(cpu_stat_cur+301-6)%301];
    u = (s2->used - s1->used)*100;
    t = s2->total - s1->total;
    if (t == 0)
        t = 1;
    n = u/t;
    f = (u%t)*100/t;
    cli_out(cli, "CPU usage for five seconds: %d.%d%%", n, f);

    s1 = &cpu_stats[(cpu_stat_cur+301-61)%301];
    u = (s2->used - s1->used)*100;
    t = s2->total - s1->total;
    if (t == 0)
        t = 1;
    n = u/t;
    f = (u%t)*100/t;
    cli_out(cli, "; one minute: %d.%d%%", n, f);

    s1 = &cpu_stats[cpu_stat_cur];
    u = (s2->used - s1->used)*100;
    t = s2->total - s1->total;
    if (t == 0)
        t = 1;
    n = u/t;
    f = (u%t)*100/t;
    cli_out(cli, "; five minutes: %d.%d%%\n", n, f);

    _argc = 0;
    _argv[_argc++] = "ps";  /*ps*/
    _argv[_argc++] = "ex";  /*all the process*/
    _argv[_argc++] = "-o";  /*output format*/
    _argv[_argc++] = "pid,time,pcpu,tname,comm";
    _argv[_argc++] = "k";
    _argv[_argc++] = "-pcpu";
    _argv[_argc] = NULL;

    if (pipe(pipe_fd) < 0) {
        return CLI_SUCCESS;
    }

    err_fd = dup(pipe_fd[1]);
    execvp_stdio(_argv, STDIN_FILENO, pipe_fd[1], err_fd);
    close(pipe_fd[1]);
    close(err_fd);
    while (1) {
        ret = read(pipe_fd[0], buf, sizeof(buf)-1);
        if (ret <= 0)
            break;
        buf[ret] = 0;
        cli_out(cli, "%s", buf);
    }
    close(pipe_fd[0]);
    wait(NULL);

    return CLI_SUCCESS;  
}

/*******************************************************************************
 * Name:   show_file_system 
 * Purpose: command for show system
 * Input:   N/A
 * Output: 
 * Return: N/A
 * Note: only show flash and compact flash card
 ******************************************************************************/
CLI(show_file_system,
    show_file_system_cmd,
    "show file system",
    CLI_SHOW_STR,
    "Show filesystem information",
    "List file sytems"
    )
{
    app_disk_iter_cbarg_t cbarg = {.cli = cli};
    
    cli_out(cli, "File Systems:\n");
    cli_out(cli, "%-12s%-12s%-12s%-12s%s\n", "Type", "Size", "Used", "Free", "Use%");
    CLISH_OUT_SPLIT;
    gen_iter_disk_cfg(app_show_disk_part, (void *)&cbarg);
    return CLI_SUCCESS;
}

#define CENTEC_PACKAGE_NAME_SZ  64
#define M_CHSM_CREATE_TIME_BUFSZ       32
/* show all boot image files */
CLI (show_boot_images,
     show_boot_images_cmd,
     "show boot images",
     CLI_SHOW_STR,
     "Show boot parameters",
     "Show all image files."
    )
{
    struct dirent *ent = NULL;
    DIR *dir = NULL;
    char szFullName[M_FULLPATH_MAX_LEN + 1];
    char szCurName[M_FULLPATH_MAX_LEN];
    int ret = 0;
    char *pFileName = NULL;
    char szPkgName[CENTEC_PACKAGE_NAME_SZ];
    char szCreateTime[M_CHSM_CREATE_TIME_BUFSZ];
    u_int32_t nCreateTime = 0;
    
    szFullName[0] = '\0';
    szFullName[M_FULLPATH_MAX_LEN] = '\0';
    if ((ret = readlink(M_CUR_BOOT_IMAGE_LINK_FULLNAME, 
                        szFullName, M_FULLPATH_MAX_LEN)) < 0)
    {
        cli_out(cli, "%% Can't read boot configuration file\n");
        return CLI_ERROR;
    }
    szFullName[ret] = '\0';
    if ((pFileName = strrchr(szFullName, '/')) == NULL)
    {
        pFileName = szFullName;
    }
    else
    {
        pFileName++;
        if ('\0' == pFileName)
        {
            cli_out(cli, "%% Invalid boot configuration file.\n");
            return CLI_ERROR;
        }
    }
    
    /* search dir */
    dir = opendir(M_BOOT_IMAGE_PATH);
    if (NULL == dir)
    {
        cli_out(cli, "%% Can't open boot image directory\n");
        return CLI_ERROR;
    }
    
    cli_out(cli, "System image files list:\n");
    cli_out(cli, "Current boot image version: %s-%s\n", "CtcEX", EPS_VERSION);
    cli_out(cli, "%-2s%-21s%-24s%s\n", "", "Create Time", "Version", "File name");
    CLISH_OUT_SPLIT;
            
    /* find the partial match item */
    while ((ent = readdir(dir)) != NULL)
    {
        /* skip . & .. */
        if (!strcmp(ent->d_name, ".")
                || !strcmp(ent->d_name, ".."))
        {
            continue;
        }

        /* ignore next boot image file */
        if (!strcmp(ent->d_name, pFileName))
        {
            continue;
        }

        snprintf(szCurName, M_FULLPATH_MAX_LEN, "%s/%s",
                     M_BOOT_IMAGE_PATH, ent->d_name);
        /* invaldate image file */
        if (check_image_file(szCurName, NULL, 0, 0) != 0)
        {
            continue;
        }

        get_packagename_from_image(szCurName, szPkgName, CENTEC_PACKAGE_NAME_SZ);
        get_createtime_from_image(szCurName, &nCreateTime);
        format_time_str(szCreateTime, M_CHSM_CREATE_TIME_BUFSZ, 
                        "%Y-%m-%d %H:%M:%S", nCreateTime);
    
        if (!strcmp(ent->d_name, M_CUR_BOOT_IMAGE_LINK_NAME))
        {
            /* next boot image */
            cli_out(cli, "%-2s%-21s%-24s%s\n", "*", 
                    szCreateTime, szPkgName, pFileName);
        }
        else
        {
            /* backup boot image */
            cli_out(cli, "%-2s%-21s%-24s%s\n", "", 
                    szCreateTime, szPkgName, ent->d_name);
        }
    }
    
    closedir(dir);
    return CLI_SUCCESS;
}

CLI (show_startup_config,
     show_startup_config_cmd,
     "show startup-config",
     CLI_SHOW_STR,
     "Contents of startup configuration")
{
  FILE *fp;
  char buf[BUFSIZ];

  /* Open the file. */
  fp = fopen (STARTUP_CONFIG_FILE_PATH, "r");
  if (fp == NULL)
    {
      cli_out (cli, "%% Can't open startup-config\n");
      return CLI_ERROR;
    }

  while (fgets (buf, BUFSIZ, fp))
    cli_out (cli, "%s", buf);

  fclose (fp);

  return CLI_SUCCESS;
}

int clish_show_running_callback(char *filename,char*redundancy)
{
    char buf[BUFSIZ];
    FILE *fp;
    
    /* Open the file. */
    fp = fopen (filename, "r");
    if (fp == NULL)
    {
        cli_out (&g_stcli, "%% Generate running-config failed\n");
        return -1;
    }
    
    while (fgets (buf, BUFSIZ, fp))
    {
        cli_out (&g_stcli, "%s", buf);
    }

    fclose (fp);
    return 0;
}

CLI (show_running_config,
     show_running_config_cmd,
     "show running-config",
     CLI_SHOW_STR,
     "Current operating configuration")
{

    if (cfgmgr_store_running_dst(cfm_clnt, clish_show_running_callback,NULL))
    {
        cli_out (cli, "%% Generate running-config failed\n");
        return CLI_ERROR;
    }


    return CLI_SUCCESS;
}

void
print_host_uptime (struct cli *cli)
{
    struct pal_timeval uptime;
    struct timezone tz;

    time_t diff = 0;
    char	hostname[M_HOSTNAME_MAXSIZE + 1];
    
    if (NULL == cli)
    {
        return;
    }

    /* get system uptime */
    /* modified by jqiu 2013-03-06
     * some platform don't support param -1 in gettimeofday.
     * use another sys call clock_gettime() */
    pal_ctc_clock_gettime(&uptime);
    diff = uptime.tv_sec;
    
    /* get hostname */
    gethostname(hostname, M_HOSTNAME_MAXSIZE);
    
    cli_out(cli, "%s uptime is %ld days, %ld hours, %ld minutes\n",
               hostname, (diff / 86400) % 365, (diff / 3600) % 24, (diff / 60) % 60);
    return;
}

/* Show version.  */
CLI (show_version,
        show_version_cmd,
        "show version",
        CLI_SHOW_STR,
        "Display "EPS_IOS" version")
{
    struct cfm_sys_version_info sysverion;
    
    if (cfm_get_sys_version(cfm_clnt, &sysverion))
    {
        cli_out(cli, "%% Internal error\n");
        return CLI_ERROR;
    }

    cli_out (cli, EPS_IOS" Software, %s, Version %s\n", sysverion.series, EPS_VERSION);
    cli_out (cli, "%s\n", EPS_COPYRIGHT);
    cli_out(cli, "The current running image is %s\n", sysverion.crtimage);
    print_host_uptime(cli);
    cli_out(cli, "Hardware Type is %s\n", sysverion.hdtype);
    cli_out(cli, "Hardware Version is %s\n", sysverion.hdversion);
    cli_out(cli, "SDRAM size  %dM\n", sysverion.sdramsize);
    cli_out(cli, "Flash size   %dM\n", sysverion.flashsize);
    cli_out(cli, "EPLD Version is %d\n", sysverion.epldversion);
    cli_out(cli, "BootRom Version is %s\n", sysverion.btromversion);
    cli_out(cli, "System serial number is %s\n", sysverion.serial);

    return CLI_SUCCESS;
}

CLI (show_users,
     show_users_cmd,
     "show users",
     CLI_SHOW_STR,
     "Display information about terminal lines")
{
    int count = 0;
    struct cfm_sys_user *list_buf;
    int i;
    int pid;

    pid = getppid();
    list_buf = calloc(1, M_MAX_CFM_SESS_NUMBER * sizeof (struct cfm_sys_user));
    if (list_buf == NULL)
    {
        cli_out (cli, " %% Internal error\n");
        return CLI_ERROR;
    }
    cfm_list_sys_users(cfm_clnt, &count, list_buf);

    cli_out (cli, "  %-10s%-21s%-11s\n",
     "Tty", "Username", "Location");

    for (i = 0; i < count; i++)
    {
        if (pid == list_buf[i].pid)
            cli_out (cli, " *");
        else
            cli_out (cli, "  ");
        cli_out (cli, "%-10d%-21s%-11s\n",
         i, list_buf[i].username, list_buf[i].ipaddr);
    }

    free(list_buf);
    return CLI_SUCCESS;
}

/* show current and next boot image */
CLI (show_boot,
     show_boot_cmd,
     "show boot",
     CLI_SHOW_STR,
     "Show boot parameters")
{
    char szPkgName[M_FULLPATH_MAX_LEN];
    char szBuf[M_FULLPATH_MAX_LEN];
    
    cli_out(cli, "The current boot image version is: %s-%s\n", "CtcEX", EPS_VERSION);
    if (check_image_file(M_CUR_BOOT_IMAGE_LINK_FULLNAME, 
                szBuf, M_FULLPATH_MAX_LEN, 0) != 0)
    {
        cli_out(cli, "%% Can't read the next boot image file. %s\n", szBuf);
        return CLI_ERROR;
    }

    get_packagename_from_image(M_CUR_BOOT_IMAGE_LINK_FULLNAME, szPkgName, 
            CENTEC_PACKAGE_NAME_SZ);
    cli_out(cli, "The next time boot image version is: %s\n", szPkgName);
    return CLI_SUCCESS;
}

int
reget_cpu_update(int nTimeout)
{
    afx_timer_t *pTimer;

    if (afx_timer_create(&pTimer, update_cpu_stat, &pTimer) != 0)
    {
        return -1;
    }
    //IMAGENT_DEBUG("Schedule to reget md5 file at %d seconds\n", nTimeout / 1000);
    afx_timer_start(pTimer, nTimeout);
    return 0;
}
#endif


int clish_show_cli_init(struct cli_tree *ctree)
{
    int i = 0;

    /* Output modifier set up.  */
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, 0,
            &clish_modifier_begin_cli);
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, 0,
            &clish_modifier_include_cli);
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, 0,
            &clish_modifier_exclude_cli);
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, CLI_FLAG_HIDDEN,
            &clish_modifier_grep_cli);
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, CLI_FLAG_HIDDEN,
            &clish_modifier_grep_option_cli);
            
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, CLI_FLAG_HIDDEN,
            &clish_overwrite_redirect_to_file_cli);
    cli_install_gen (ctree, MODIFIER_MODE, PRIVILEGE_NORMAL, CLI_FLAG_HIDDEN,
            &clish_redirect_to_file_cli); 
            
    /* Set show flag to "show" and "*s=show" node.  */
    for (i = 0; i < MAX_MODE; i++)
    {

        if (i != EXEC_MODE)
        {
            cli_set_node_flag (ctree, i, "read", CLI_FLAG_SHOW);
            cli_set_node_flag (ctree, i, "show", CLI_FLAG_SHOW);
            cli_set_node_flag (ctree, i, "s", CLI_FLAG_SHOW);
        }
    }
    
    return 0;
}
