 /**
  @file show_sram_table.c
  
  @date 2010-10-20
  
  @version v1.0
 
  The file contains all show sram module
 */
/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include "cli.h"
#include "clish.h"
#include "lcsh_lcmtlk.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "ctclib_show.h"
#include "glb_phy_define.h"
#include "ctclib_show.h"
#include "glb_debug_define.h"
#include "glb_hw_define.h"
#include "sal.h"
#include "lcsh_client.h"
#include "lcsh_debug.h"
#include "lcsh_error.h"
#include "clish.h"
#include "glb_tempfile_define.h"
#include "SRAMEntryMsg.h"
#include "LcmMsg.h"

//#include "ctc_api.h"

/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/

extern int 
diag_show_sram_dsnh( struct cli *cli, diag_sram_entry_req_t* req, 
                               diag_sram_entry_resp_t* resp,int if_list, int if_explain);


/****************************************************************************
*  
* Function
*
*****************************************************************************/
int32
lcsm_lcapi_show_sram_get_stp_status( diag_sram_get_stp_status_req_t* p_req, 
                                     diag_sram_get_stp_status_resp_t *p_resp)
{
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_sram_get_stp_status_req_t* req = NULL;

    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    req = (diag_sram_get_stp_status_req_t *)p_req;
    sal_memcpy(st_msg.msg, req, sizeof(diag_sram_get_stp_status_req_t));
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_STP_STATUS;
    st_msg.msg_len = sizeof(diag_sram_get_stp_status_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message test1 fail, error id is %d", ret);
        return ret;
    }
    sal_memcpy(p_resp, st_rcv.msg, sizeof(diag_sram_get_stp_status_resp_t));

    return CLI_SUCCESS;    
}

int32
lcsm_lcapi_show_sram_table( diag_sram_entry_req_t* p_req, diag_sram_entry_resp_t *p_resp)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_sram_entry_req_t* req = NULL;

    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    req = (diag_sram_entry_req_t *)p_req;
    sal_memcpy(st_msg.msg, req, sizeof(diag_sram_entry_req_t));
    st_msg.msg_type = LCAPI_LCM_LCSH_GET_SRAM_TABLE_MSG;
    st_msg.msg_len = sizeof(diag_sram_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message to read sram fail, error id is %d", ret);
        return ret;
    }
    sal_memcpy(p_resp, st_rcv.msg, sizeof(diag_sram_entry_resp_t));

    return CLI_SUCCESS;    
}

int32
lcsm_lcapi_show_reg_table( diag_reg_entry_req_t* p_req, diag_reg_entry_resp_t *p_resp)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    sal_memcpy(st_msg.msg, p_req, sizeof(diag_reg_entry_req_t));
    st_msg.msg_type = LCAPI_LCM_LCSH_GET_REG_TABLE_MSG;
    st_msg.msg_len = sizeof(diag_reg_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message to read register fail, error id is %d", ret);
        return ret;
    }
    sal_memcpy(p_resp, st_rcv.msg, sizeof(diag_reg_entry_resp_t));

    return CLI_SUCCESS;    
}

int32 
diag_show_return_infor( struct cli *cli, diag_sram_entry_resp_t* resp)	
{
    if ( DIAG_GET_TCAM_INDEX_INVALID == resp->chip_id )
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp->index -1 );
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_channel_shape_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli,  "TOKEN-token. ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_channel_shape_head(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "%-9s" , " cha-shp");
    cli_out(cli, "%-7s" , "TOKEN");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_channel_shape_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , "");
    cli_out(cli, " %-6x", resp->ds_channel_shape.token);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_channel_shape( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_channel_shape_explain(cli);        
    }
    _diag_show_sram_channel_shape_head( cli );
    _diag_show_sram_channel_shape_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_queue_shape_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli,  "COM-TOK-commit token. ");
    cli_out(cli, "PEA-TOK-peak token. ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_queue_shape_head(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "%-13s" , " queue-shape");
    cli_out(cli, "%-8s" , "COM-TOK");
    cli_out(cli, "%-8s" , "PEA-TOK");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_queue_shape_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%12s" , "");
    cli_out(cli, " %-7x", resp->ds_queue_shape.commit_token);
    cli_out(cli, " %-7x", resp->ds_queue_shape.peak_token);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_queue_shape( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_queue_shape_explain(cli);        
    }
    _diag_show_sram_queue_shape_head( cli );
    _diag_show_sram_queue_shape_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}


static void 
_diag_show_sram_link_agg_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli,  "DCI-Dest Chip Id. ");
    cli_out(cli, "DQU-Dest Queue. ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_link_agg_head(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "%-9s" , " linkagg");
    cli_out(cli, "%-4s" , "DCI");
    cli_out(cli, "%-4s" , "DQU");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_link_agg_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , "");
    cli_out(cli, " %-3x", resp->ds_link_agg.dest_chip_id);
    cli_out(cli, " %-3x", resp->ds_link_agg.dest_queue);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_link_agg( struct cli *cli, diag_sram_entry_req_t* req, 
                          diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_link_agg_explain(cli);        
    }
    _diag_show_sram_link_agg_head( cli );
    _diag_show_sram_link_agg_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_link_agg_mem_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli,  "HMD-Hash Mode. ");
    cli_out(cli, "LGMN-Link Agg Mem Num. ");
    cli_out(cli, " \n"); 
}

void 
_diag_show_sram_link_agg_mem_head(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "%-8s" , " lkamem");
    cli_out(cli, "%-4s" , "HMD");
    cli_out(cli, "%-5s" , "LGMN");
    cli_out(cli, " \n"); 
}

void
diag_show_sram_link_agg_mem_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->ds_linkagg_memnum.hash_mode);
    cli_out(cli, " %-3x", resp->ds_linkagg_memnum.link_agg_mem_num);
    cli_out(cli, " \n"); 
}

int 
diag_show_sram_link_agg_mem( struct cli *cli, diag_sram_entry_req_t* req, 
                             diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_link_agg_mem_explain(cli);        
    }
    _diag_show_sram_link_agg_mem_head( cli );
    diag_show_sram_link_agg_mem_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

void 
_diag_show_sram_src_intf_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli,  "LUM-Lookup Mode. ");
    cli_out(cli, "V4E-V4 Mcast Rpf En. ");
    cli_out(cli,  "V6E-V6 Mcast Rpf En. ");
    cli_out(cli, "MLE-Mpls En ");
    cli_out(cli, " \n"); 
    cli_out(cli, "3AE-L3 Acl En ");
    cli_out(cli, "QLE-L3 Qos Lookup En ");
    cli_out(cli, "ARO-L3 Acl Routed Only ");
    cli_out(cli, "3SE-L3 Span En ");
    cli_out(cli, " \n"); 
    cli_out(cli, "3SI-L3 Span Id ");
    cli_out(cli, "RAP-Route All Packets ");
    cli_out(cli, "RMT-Router Mac Type ");
    cli_out(cli, "PBL-Pbr Label ");
    cli_out(cli, " \n"); 
    cli_out(cli, "RML-Router Mac Label ");
    cli_out(cli, "3AL-L3 Acl Label ");
    cli_out(cli, "3QL-L3 Qos Label ");
    cli_out(cli, "EPE-Exception3 En ");
    cli_out(cli, "MLS-Mpls Label Space ");
    cli_out(cli, " \n"); 
    cli_out(cli, "EPE-Exception3 En ");
    cli_out(cli, "3IT-L3 If Type ");
    cli_out(cli, " \n"); 
}

void 
_diag_show_sram_src_intf_head(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "%-8s" , " SRCINF");
    cli_out(cli, "%-4s" , "LUM");
    cli_out(cli, "%-4s" , "V4E");
    cli_out(cli, "%-4s" , "V6E");
    cli_out(cli, "%-4s" , "MLE");
    cli_out(cli, "%-4s" , "3AE");
    cli_out(cli, "%-4s" , "QLE");
    cli_out(cli, "%-4s" , "ARO");
    cli_out(cli, "%-4s" , "3SE");
    cli_out(cli, "%-4s" , "3SI");
    cli_out(cli, "%-4s" , "RAP");
    cli_out(cli, "%-4s" , "RMT");
    cli_out(cli, "%-4s" , "PBL");
    cli_out(cli, "%-4s" , "RML");
    cli_out(cli, "%-4s" , "3AL");
    cli_out(cli, "%-4s" , "3QL");
    cli_out(cli, "%-4s" , "MLS");
    cli_out(cli, "%-4s" , "EPE");
    cli_out(cli, "%-4s" , "3IT");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_src_intf_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->src_interface.lookup_mode);
    cli_out(cli, " %-3x", resp->src_interface.v4_mcast_rpf_en);
    cli_out(cli, " %-3x", resp->src_interface.v6_mcast_rpf_en);
    cli_out(cli, " %-3x", resp->src_interface.mpls_en);
    cli_out(cli, " %-3x", resp->src_interface.l3_acl_en);
    cli_out(cli, " %-3x", resp->src_interface.l3_qos_lookup_en);
    cli_out(cli, " %-3x", resp->src_interface.l3_acl_routed_only);
    cli_out(cli, " %-3x", resp->src_interface.l3_span_en);
    cli_out(cli, " %-3x", resp->src_interface.l3_span_id);
    cli_out(cli, " %-3x", resp->src_interface.route_all_packets);
    cli_out(cli, " %-3x", resp->src_interface.router_mac_type);
    cli_out(cli, " %-3x", resp->src_interface.pbr_label);
    cli_out(cli, " %-3x", resp->src_interface.router_mac_label);
    cli_out(cli, " %-3x", resp->src_interface.l3_acl_label);
    cli_out(cli, " %-3x", resp->src_interface.l3_qos_label);
    cli_out(cli, " %-3x", resp->src_interface.mpls_label_space);
    cli_out(cli, " %-3x", resp->src_interface.exception3_en);
    cli_out(cli, " %-3x", resp->src_interface.l3_if_type);

    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_src_intf( struct cli *cli, diag_sram_entry_req_t* req, 
                          diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_src_intf_explain(cli);        
    }

    _diag_show_sram_src_intf_head( cli );
    _diag_show_sram_src_intf_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dst_intf_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli,  "3ARO-l3_acl_routed_only. ");
    cli_out(cli, "3AE-l3_acl_en. ");
    cli_out(cli,  "3QLE-l3_qos_lookup_en. ");
    cli_out(cli, "MEE-mtu_exception_en ");
    cli_out(cli, "MCE-mtu_check_en ");
    cli_out(cli, "3SE-l3_span_en ");
    cli_out(cli, "3SI-l3_span_id ");
    cli_out(cli, "MST-mac_sa_type ");
    cli_out(cli, "MSA-mac_sa ");
    cli_out(cli, "MTT-mcast_ttl_threshold ");
    cli_out(cli, "3AL-l3_acl_label ");
    cli_out(cli, "3QL-l3_qos_label ");
    cli_out(cli, "MTS-mtu_size ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dst_intf_head(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "%-8s" , " DSTINF");
    cli_out(cli, "%-5s" , "3ARO");
    cli_out(cli, "%-4s" , "3AE");
    cli_out(cli, "%-5s" , "3QLE");
    cli_out(cli, "%-4s" , "MEE");
    cli_out(cli, "%-4s" , "MCE");
    cli_out(cli, "%-4s" , "3SE");
    cli_out(cli, "%-4s" , "3SI");
    cli_out(cli, "%-4s" , "MST");
    cli_out(cli, "%-4s" , "MSA");
    cli_out(cli, "%-4s" , "MTT");
    cli_out(cli, "%-4s" , "3AL");
    cli_out(cli, "%-4s" , "3QL");
    cli_out(cli, "%-4s" , "MTS");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dst_intf_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-4x", resp->ds_dst_if.l3_acl_routed_only);
    cli_out(cli, " %-3x", resp->ds_dst_if.l3_acl_en);
    cli_out(cli, " %-4x", resp->ds_dst_if.l3_qos_lookup_en);
    cli_out(cli, " %-3x", resp->ds_dst_if.mtu_exception_en);
    cli_out(cli, " %-3x", resp->ds_dst_if.mtu_check_en);
    cli_out(cli, " %-3x", resp->ds_dst_if.l3_span_en);
    cli_out(cli, " %-3x", resp->ds_dst_if.l3_span_id);
    cli_out(cli, " %-3x", resp->ds_dst_if.mac_sa_type);
    cli_out(cli, " %-3x", resp->ds_dst_if.mac_sa);
    cli_out(cli, " %-3x", resp->ds_dst_if.mcast_ttl_threshold);
    cli_out(cli, " %-3x", resp->ds_dst_if.l3_acl_label);
    cli_out(cli, " %-3x", resp->ds_dst_if.l3_qos_label);
    cli_out(cli, " %-3x", resp->ds_dst_if.mtu_size);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_dst_intf( struct cli *cli, diag_sram_entry_req_t* req, 
                          diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_dst_intf_explain(cli);        
    }

    _diag_show_sram_dst_intf_head( cli );
    _diag_show_sram_dst_intf_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_chg_shp_explain(struct cli *cli)
{
    cli_out(cli,  "SHE-shape en. ");
    cli_out(cli, "TTS-token thrd shift. ");
    cli_out(cli,  "TKT-token thrd. ");
    cli_out(cli, "TKR-token rate ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_chg_shp_prof_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " CHGSPP");
    cli_out(cli, "%-4s" , "SHE");
    cli_out(cli, "%-4s" , "TTS");
    cli_out(cli, "%-6s" , "TKT");
    cli_out(cli, "%-6s" , "TKR");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_chg_shp_prof_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->ds_csp.shape_en);
    cli_out(cli, " %-3x", resp->ds_csp.token_thrd_shift);
    cli_out(cli, " %-5x", resp->ds_csp.token_thrd);
    cli_out(cli, " %-5x", resp->ds_csp.token_rate);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_chg_shp_prof( struct cli *cli, diag_sram_entry_req_t* req, 
                              diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }

    if ( if_explain )
    {
        _diag_show_sram_chg_shp_explain(cli);        
    }

    _diag_show_sram_chg_shp_prof_head( cli );
    _diag_show_sram_chg_shp_prof_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_queue_shp_prof_explain(struct cli *cli)
{
    cli_out(cli,  "CTR-que commit token rate. ");
    cli_out(cli, "CTT-que commit token thrd. ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "CTTS-que commit token thrd shift. ");
    cli_out(cli, "PIR-que peak token rate. ");
    cli_out(cli, " \n"); 
    cli_out(cli, "PTT-que peak token thrd. ");
    cli_out(cli, "PTTS-que peak token thrd_shift.");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_queue_shp_prof_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " SHPPRF");
    cli_out(cli, "%-6s" , "CTR");
    cli_out(cli, "%-6s" , "CTT");
    cli_out(cli, "%-6s" , "CTTS");
    cli_out(cli, "%-6s" , "PIR");
    cli_out(cli, "%-6s" , "PTT");
    cli_out(cli, "%-6s" , "PTTS");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_queue_shp_prof_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-5x", resp->ds_qsp.que_commit_token_rate);
    cli_out(cli, " %-5x", resp->ds_qsp.que_commit_token_thrd);
    cli_out(cli, " %-5x", resp->ds_qsp.que_commit_token_thrd_shift);
    cli_out(cli, " %-5x", resp->ds_qsp.que_peak_token_rate);
    cli_out(cli, " %-5x", resp->ds_qsp.que_peak_token_thrd);
    cli_out(cli, " %-5x", resp->ds_qsp.que_peak_token_thrd_shift);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_queue_shp_prof( struct cli *cli, diag_sram_entry_req_t* req, 
                                diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        _diag_show_sram_queue_shp_prof_explain(cli);        
    }
    _diag_show_sram_queue_shp_prof_head( cli );
    _diag_show_sram_queue_shp_prof_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_tcam_queue_drop_prof_head_explain(struct cli *cli)
{
    cli_out(cli,  "MIN-wred min thrd.");
    cli_out(cli, "MAX-wred max thrd. ");
    cli_out(cli,  "FAC-factor. ");
    cli_out(cli, "WDM-wred drop mode. ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_queue_drop_prof_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DRPPRF");
    cli_out(cli, "%-5s" , "WDM");
    cli_out(cli, "%-6s" , "MIN0");
    cli_out(cli, "%-6s" , "MIN1");
    cli_out(cli, "%-6s" , "MIN2");
    cli_out(cli, "%-6s" , "MIN3");
    cli_out(cli, "%-6s" , "MAX0");
    cli_out(cli, "%-6s" , "MAX1");
    cli_out(cli, "%-6s" , "MAX2");
    cli_out(cli, "%-6s" , "MAX3");
    cli_out(cli, "%-5s" , "FAC0");
    cli_out(cli, "%-5s" , "FAC1");
    cli_out(cli, "%-5s" , "FAC2");
    cli_out(cli, "%-5s" , "FAC3");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_queue_drop_prof_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-5x", resp->ds_profile.wred_drop_mode);
    cli_out(cli, " %-5x", resp->ds_profile.wred_min_thrd0);
    cli_out(cli, " %-5x", resp->ds_profile.wred_min_thrd1);
    cli_out(cli, " %-5x", resp->ds_profile.wred_min_thrd2);
    cli_out(cli, " %-5x", resp->ds_profile.wred_min_thrd3);
    cli_out(cli, " %-5x", resp->ds_profile.wred_max_thrd0);
    cli_out(cli, " %-5x", resp->ds_profile.wred_max_thrd1);
    cli_out(cli, " %-5x", resp->ds_profile.wred_max_thrd2);
    cli_out(cli, " %-5x", resp->ds_profile.wred_max_thrd3);
    cli_out(cli, " %-5x", resp->ds_profile.factor0);
    cli_out(cli, " %-5x", resp->ds_profile.factor1);
    cli_out(cli, " %-5x", resp->ds_profile.factor2);
    cli_out(cli, " %-5x", resp->ds_profile.factor3);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_queue_drop_prof( struct cli *cli, diag_sram_entry_req_t* req, 
                                 diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        _diag_show_tcam_queue_drop_prof_head_explain(cli);        
    }
    _diag_show_tcam_queue_drop_prof_head( cli );
    _diag_show_tcam_queue_drop_prof_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_tcam_queue_map_head_explain(struct cli *cli)
{
    cli_out(cli,  "CHN-channel id. ");
    cli_out(cli, "GID-grp id. ");
    cli_out(cli,  "PRI-priority id.");
    cli_out(cli, "SHE-que shp en. ");
    cli_out(cli, " \n"); 
    cli_out(cli, "SID-sgmac id. ");
    cli_out(cli, "SVA-sgmac valid.");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_queue_map_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " QUEMAP");
    cli_out(cli, "%-5s" , "CHN");
    cli_out(cli, "%-5s" , "GID");
    cli_out(cli, "%-5s" , "PRI");
    cli_out(cli, "%-5s" , "SHE");
    cli_out(cli, "%-5s" , "SID");
    cli_out(cli, "%-5s" , "SVA");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_queue_map_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-4x", resp->que_map.channel_id);
    cli_out(cli, " %-4x", resp->que_map.grp_id);
    cli_out(cli, " %-4x", resp->que_map.priority_id);
    cli_out(cli, " %-4x", resp->que_map.que_shp_en);
    cli_out(cli, " %-4x", resp->que_map.sgmac_id);
    cli_out(cli, " %-4x", resp->que_map.sgmac_valid);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_queue_map( struct cli *cli, diag_sram_entry_req_t* req, 
                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        _diag_show_tcam_queue_map_head_explain(cli);        
    }
    _diag_show_tcam_queue_map_head( cli );
    _diag_show_tcam_queue_map_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

void 
diag_show_tcam_dsipsa_head_explain(struct cli *cli)
{
    cli_out(cli,  "RC-Rpf Check En, ");
    cli_out(cli,  "MRI-Ipsa More Rpf If, ");
    cli_out(cli, "RIV3-RpfIfId Valid3, ");
    cli_out(cli,  "RIV2-RpfIfId Valid2");
    cli_out(cli, " \n"); 
    cli_out(cli, "RIV1-RpfIfId Valid1, ");
    cli_out(cli, "RIV0-RpfIfId Valid0, ");
    cli_out(cli, "RI3-RpfIfId3, ");
    cli_out(cli,  "RI2-RpfIfId2, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "RI1-RpfIfId1, ");
    cli_out(cli,  "RI0-RpfIfId0, ");
    cli_out(cli, " \n"); 
}

void 
diag_show_tcam_dsipsa_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DSIPSA");
    cli_out(cli, "%-3s" , "RC");
    cli_out(cli, "%-4s" , "MRI");
    cli_out(cli, "%-5s" , "RIV3");
    cli_out(cli, "%-5s" , "RIV2");
    cli_out(cli, "%-5s" , "RIV1");
    cli_out(cli, "%-5s" , "RIV0");
    cli_out(cli, "%-5s" , "RI3");
    cli_out(cli, "%-5s" , "RI2");
    cli_out(cli, "%-5s" , "RI1");
    cli_out(cli, "%-5s" , "RI0");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_dsipsa_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-2x", resp->dsipsa.check_en);
    cli_out(cli, " %-3x", resp->dsipsa.ipsa_more_rpf_if);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid3);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid2);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid1);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid0);
    cli_out(cli, " %-4x", resp->dsipsa.if_id3);
    cli_out(cli, " %-4x", resp->dsipsa.if_id2);
    cli_out(cli, " %-4x", resp->dsipsa.if_id1);
    cli_out(cli, " %-4x", resp->dsipsa.if_id0);
    cli_out(cli, " \n"); 
}

void
diag_show_tcam_ipuc_dsipsa_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-2x", resp->dsipsa.check_en);
    cli_out(cli, " %-3x", resp->dsipsa.ipsa_more_rpf_if);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid3);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid2);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid1);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid0);
    cli_out(cli, " %-4x", resp->dsipsa.if_id3);
    cli_out(cli, " %-4x", resp->dsipsa.if_id2);
    cli_out(cli, " %-4x", resp->dsipsa.if_id1);
    cli_out(cli, " %-4x", resp->dsipsa.if_id0);
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_dssa( struct cli *cli, diag_sram_entry_req_t* req, 
                     diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        diag_show_tcam_dsipsa_head_explain(cli);        
    }

    cli_out(cli,"\n");
    diag_show_tcam_dsipsa_head( cli );

    cli_out(cli,"\n");
    _diag_show_tcam_dsipsa_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}


static void 
_diag_show_tcam_dsmpls_head_explain(struct cli *cli)
{
    cli_out(cli,  "LLP-Llsp Priority, ");
    cli_out(cli,  "LLV-Llsp Valid, ");
    cli_out(cli,  "MC-MPLS sContinue, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "NTM-Next Ttl check Mode, ");
    cli_out(cli,  "OB-Offset Bytes, ");
    cli_out(cli,  "OWP-Over Write Priority, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PT-Pkt type, ");
    cli_out(cli,  "PPE-Priority Path En, ");
    cli_out(cli,  "SCE-Sbit Check En, ");
    cli_out(cli,  "SPM-Stats ptr Mode, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "SBT-sbit, ");
    cli_out(cli,  "TLT-TTL Threshold, ");
    cli_out(cli,  "ULT-Use Label TTL, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "ECP10-Equal Cost Path Num10, ");
    cli_out(cli,  "ECP2-Equal Cost Path Num2, ");
    cli_out(cli,  "TDM-ttl_decrease_mode, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "ULE-use_label_exp, ");
    cli_out(cli,  "OCK-oam_check, ");
    cli_out(cli,  "IVL-is_vc_label, ");
    cli_out(cli,  "ASV-aps_select_valid, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "MFP-MPLS Flow Policer ptr, ");
    cli_out(cli,  "DFP-Ds fwd ptr.");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_dsmpls_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DSMPLS");
    cli_out(cli, "%-4s" , "LLP");
    cli_out(cli, "%-4s" , "LLV");
    cli_out(cli, "%-4s" , "MC");
    cli_out(cli, "%-4s" , "NTM");
    cli_out(cli, "%-4s" , "OB");
    cli_out(cli, "%-4s" , "OWP");
    cli_out(cli, "%-4s" , "PT");
    cli_out(cli, "%-4s" , "PPE");
    cli_out(cli, "%-4s" , "SCE");
    cli_out(cli, "%-4s" , "SPM");
    cli_out(cli, "%-4s" , "SBT");
    cli_out(cli, "%-4s" , "TLT");
    cli_out(cli, "%-4s" , "ULT");
    cli_out(cli, "%-4s" , "ECP10");
    cli_out(cli, "%-4s" , "ECP2");
    cli_out(cli, "%-4s" , "TDM");
    cli_out(cli, "%-4s" , "ULE");
    cli_out(cli, "%-4s" , "OCK");
    cli_out(cli, "%-4s" , "IVL");
    cli_out(cli, "%-4s" , "ASV");
    cli_out(cli, "%-5s" , "MFP");
    cli_out(cli, "%-4s" , "DFP");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_dsmpls_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->mpls.llsp_priority);
    cli_out(cli, " %-3x", resp->mpls.llsp_valid);
    cli_out(cli, " %-3x", resp->mpls.scontinue);
    cli_out(cli, " %-3x", resp->mpls.ttl_check_mode);
    cli_out(cli, " %-3x", resp->mpls.offset_bytes);
    cli_out(cli, " %-3x", resp->mpls.over_write_priority);
    cli_out(cli, " %-3x", resp->mpls.packet_type);
    cli_out(cli, " %-3x", resp->mpls.priority_path_en);
    cli_out(cli, " %-3x", resp->mpls.s_bit_check_en);
    cli_out(cli, " %-3x", resp->mpls.stats_ptr_mode);
    cli_out(cli, " %-3x", resp->mpls.sbit);
    cli_out(cli, " %-3x", resp->mpls.ttl_threshhold);
    cli_out(cli, " %-3x", resp->mpls.use_label_ttl);
    cli_out(cli, " %-3x", resp->mpls.equal_cost_path_num10);
    cli_out(cli, " %-3x", resp->mpls.equal_cost_path_num2);
    cli_out(cli, " %-3x", resp->mpls.ttl_decrease_mode);
    cli_out(cli, " %-3x", resp->mpls.use_label_exp);
    cli_out(cli, " %-3x", resp->mpls.oam_check);
    cli_out(cli, " %-3x", resp->mpls.is_vc_label);
    cli_out(cli, " %-3x", resp->mpls.aps_select_valid);

    cli_out(cli, " %-4x", (resp->mpls.flow_policer_ptr7to0 | resp->mpls.flow_policer_ptr10to8 << 8 
                           | resp->mpls.flow_policer_ptr11 << 12 | resp->mpls.flow_policer_ptr15to12 << 13 ));
    cli_out(cli, " %-5x", resp->mpls.ds_fwd_ptr);
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dsrtmac_head_explain(struct cli *cli)
{
    cli_out(cli,  "mac0T-Type for router MAC0");
    cli_out(cli,  "mac1T-Type for router MAC1");
    cli_out(cli,  "mac2T-Type for router MAC2 ");
    cli_out(cli,  "mac3T-Type for router MAC3\n");
    cli_out(cli,  "mac0B-Lower 8 bits for router MAC0");
    cli_out(cli,  "mac1B-Lower 8 bits for router MAC1 ");
    cli_out(cli,  "mac2B-Lower 8 bits for router MAC2");
    cli_out(cli,  "mac3B-Lower 8 bits for router MAC3 ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dsrtmac_head(struct cli *cli)
{
    cli_out(cli, "%-9s" , " DSRTMAC");
    cli_out(cli, "%-6s" , "mac0T");
    cli_out(cli, "%-6s" , "mac1T");
    cli_out(cli, "%-6s" , "mac2T");
    cli_out(cli, "%-6s" , "mac3T");
    cli_out(cli, "%-6s" , "mac0B");
    cli_out(cli, "%-6s" , "mac1B");
    cli_out(cli, "%-6s" , "mac2B");
    cli_out(cli, "%-6s" , "mac3B");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dsrtmac_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , "");
    cli_out(cli, " %-5x", resp->router_mac.router_mac0_type);
    cli_out(cli, " %-5x", resp->router_mac.router_mac1_type);
    cli_out(cli, " %-5x", resp->router_mac.router_mac2_type);
    cli_out(cli, " %-5x", resp->router_mac.router_mac3_type);
    cli_out(cli, " %-5x", resp->router_mac.router_mac0_byte);
    cli_out(cli, " %-5x", resp->router_mac.router_mac1_byte);
    cli_out(cli, " %-5x", resp->router_mac.router_mac2_byte);
    cli_out(cli, " %-5x", resp->router_mac.router_mac3_byte);
    cli_out(cli, " \n"); 
}

void 
diag_show_tcam_dsipda_head_explain(struct cli *cli)
{
    cli_out(cli,  "ICE-ICMP Check En, ");
    cli_out(cli,  "MR-Mast Rpf Fail Cpu En, ");
    cli_out(cli, "IE-IP DA Exception En , ");
    cli_out(cli,  "RI-RpfIfId,");
    cli_out(cli, " \n"); 
    cli_out(cli,  "TC-TTL Check En, ");
    cli_out(cli, "EC-Equal Cost Path Num,");
    cli_out(cli, "L3I-Layer3 Interface, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PL-Pay Load Select, ");
    cli_out(cli,  "ICE-Isatap Check En, ");
    cli_out(cli,  "ESI-Excep Sub Index, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "BGV-Bidi Pim Group Valid, ");
    cli_out(cli,  "BPG-Bidi Pim Group, ");
    cli_out(cli,  "DP-Deny Pbr, ");
    cli_out(cli,  "VE-Vpls En, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "ECE-Exp3 Ctl En, ");
    cli_out(cli,  "TPT-Tunnel PacketType, ");
    cli_out(cli,  "POT-Tunnel Payload Offset Type, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "TGO-Tunnel Gre Options, ");
    cli_out(cli,  "TPO-Tunnel Payload Offset, ");
    cli_out(cli,  "FP-ds Fwd Ptr ");
    cli_out(cli, " \n"); 
}

void 
diag_show_tcam_dsipda_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DSIPDA");
    cli_out(cli, "%-4s" , "ICE");
    cli_out(cli, "%-3s" , "MR");
    cli_out(cli, "%-3s" , "IE");
    cli_out(cli, "%-3s" , "TC");
    cli_out(cli, "%-3s" , "EC");
    cli_out(cli, "%-4s" , "EC2");
    cli_out(cli, "%-5s" , "RI");
    cli_out(cli, "%-4s" , "L3I");
    cli_out(cli, "%-3s" , "PL");
    cli_out(cli, "%-4s" , "ICE");
    cli_out(cli, "%-4s" , "ESI");
    cli_out(cli, "%-4s" , "BGV");
    cli_out(cli, "%-4s" , "BPG");
    cli_out(cli, "%-4s" , "DP");
    cli_out(cli, "%-4s" , "VE");
    cli_out(cli, "%-4s" , "ECE");
    cli_out(cli, "%-4s" , "TPT");
    cli_out(cli, "%-4s" , "POT");
    cli_out(cli, "%-4s" , "TGO");
    cli_out(cli, "%-4s" , "TPO");

    cli_out(cli, "%-5s" , "FP");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_dsipda_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->dsipda.icmp_check_en);
    cli_out(cli, " %-2x", resp->dsipda.mcast_rpf_fail_cpu_en);
    cli_out(cli, " %-2x", resp->dsipda.ip_da_exception_en);
    cli_out(cli, " %-2x", resp->dsipda.ttl_check_en);
    cli_out(cli, " %-2x", resp->dsipda.equal_cost_path_num);
    cli_out(cli, " %-3x", resp->dsipda.equal_cost_path_num2);
    cli_out(cli, " %-4x", resp->dsipda.vrf_id);
    cli_out(cli, " %-3x", resp->dsipda.l3_if_type);
    cli_out(cli, " %-2x", resp->dsipda.payload_select);
    cli_out(cli, " %-3x", resp->dsipda.isatap_check_en);
    cli_out(cli, " %-3x", resp->dsipda.excep_sub_index);
    cli_out(cli, " %-3x", resp->dsipda.bidi_pim_group_valid);
    cli_out(cli, " %-3x", resp->dsipda.bidi_pim_group);
    cli_out(cli, " %-3x", resp->dsipda.deny_pbr);
    cli_out(cli, " %-3x", resp->dsipda.vpls_en);
    cli_out(cli, " %-3x", resp->dsipda.exp3_ctl_en);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_packet_type);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_payload_offset_type);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_gre_options);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_payload_offset);

    cli_out(cli, " %-5x", resp->dsipda.ds_fwd_ptr);
    cli_out(cli, " \n"); 
}

void
diag_show_tcam_ipuc_dsipda_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->dsipda.icmp_check_en);
    cli_out(cli, " %-2x", resp->dsipda.mcast_rpf_fail_cpu_en);
    cli_out(cli, " %-2x", resp->dsipda.ip_da_exception_en);
    cli_out(cli, " %-2x", resp->dsipda.ttl_check_en);
    cli_out(cli, " %-2x", resp->dsipda.equal_cost_path_num);
    cli_out(cli, " %-3x", resp->dsipda.equal_cost_path_num2);
    cli_out(cli, " %-4x", resp->dsipda.vrf_id);
    cli_out(cli, " %-3x", resp->dsipda.l3_if_type);
    cli_out(cli, " %-2x", resp->dsipda.payload_select);
    cli_out(cli, " %-3x", resp->dsipda.isatap_check_en);
    cli_out(cli, " %-3x", resp->dsipda.excep_sub_index);
    cli_out(cli, " %-3x", resp->dsipda.bidi_pim_group_valid);
    cli_out(cli, " %-3x", resp->dsipda.bidi_pim_group);
    cli_out(cli, " %-3x", resp->dsipda.deny_pbr);
    cli_out(cli, " %-3x", resp->dsipda.vpls_en);
    cli_out(cli, " %-3x", resp->dsipda.exp3_ctl_en);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_packet_type);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_payload_offset_type);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_gre_options);
    cli_out(cli, " %-3x", resp->dsipda.tunnel_payload_offset);
    cli_out(cli, " %-5x", resp->dsipda.ds_fwd_ptr);
    cli_out(cli, " \n"); 
}

static int32
_diag_show_sram_get_stp_status(struct cli* cli, 
                               diag_sram_get_stp_status_req_t* req, 
                               diag_sram_get_stp_status_resp_t *resp)
{
    return lcsm_lcapi_show_sram_get_stp_status(req,resp);
} 

static int32
_diag_show_sram_table(struct cli* cli, diag_sram_entry_req_t* req, diag_sram_entry_resp_t *resp)
{
    return lcsm_lcapi_show_sram_table(req,resp);
} 

static void 
_diag_show_sram_dsmet_head_explain(struct cli *cli)
{
    cli_out(cli," DSMet, ");   
    cli_out(cli, "BMD-aps_brg_mismatch_discard, ");
    cli_out(cli, "BPP-aps_brg_protect_path, ");
    cli_out(cli, "ABE-aps_brg_en, ");
    cli_out(cli, "NHE-nexthop_ext, ");
    cli_out(cli, "PCD-port_check_discard, ");
    cli_out(cli, "LAT-Length Adjust Type, ");
    cli_out(cli, "RB-Remote Bay, ");
    cli_out(cli, "ILA-Is Link Aggregation, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "ELR-End Local Rep, ");
    cli_out(cli, "RC-Replication CTL, ");
    cli_out(cli, "UCID-UcastID, ");
    cli_out(cli, "NME-Next Met Entry ptr.");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dsmet_head(struct cli *cli)
{
    cli_out(cli, "%-7s"," DSMet");   
    cli_out(cli, "%-4s" , "BMD");
    cli_out(cli, "%-4s" , "BPP");
    cli_out(cli, "%-4s" , "ABE");
    cli_out(cli, "%-4s" , "NHE");
    cli_out(cli, "%-4s" , "PCD");
    cli_out(cli, "%-4s" , "LAT");
    cli_out(cli, "%-3s" , "RB");
    cli_out(cli, "%-4s" , "ILA");
    cli_out(cli, "%-4s" , "ELR");
    cli_out(cli, "%-8s" , "RC");
    cli_out(cli, "%-5s" , "UCID");
    cli_out(cli, "%-4s" , "NME");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dsmet_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%6s" , "");

    cli_out(cli, " %-3x", resp->met.aps_brg_mismatch_discard);
    cli_out(cli, " %-3x", resp->met.aps_brg_protect_path);
    cli_out(cli, " %-3x", resp->met.aps_brg_en);
    cli_out(cli, " %-3x", resp->met.nexthop_ext);
    cli_out(cli, " %-3x", resp->met.port_check_discard);
    cli_out(cli, " %-3x", resp->met.length_adjust_type);
    cli_out(cli, " %-2x", resp->met.remote_bay);
    cli_out(cli, " %-3x", resp->met.is_link_aggregation);
    cli_out(cli, " %-3x", resp->met.end_local_rep);
    cli_out(cli, " %-7x", resp->met.replication_ctl);
    cli_out(cli, " %-4x", (resp->met.ucast_id_lower+ ((resp->met.ucast_id_upper<<12) & 0xF000)));
    cli_out(cli, " %-3x", resp->met.next_met_entry_ptr);
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dsfwd_head_explain(struct cli *cli)
{
    cli_out(cli,  " DSFWD, ");
    cli_out(cli,  "SL-SendLocal Phy Port, ");   
    cli_out(cli,  "LA-Length Adjust Type, ");           
    cli_out(cli,  "CP-Critical Packet, ");           
    cli_out(cli, " \n"); 
    cli_out(cli,  "STAP-Stats Ptr, ");         
    cli_out(cli,  "DM-Dest Map, ");     
    cli_out(cli,  "SV-Stats Ptr Valid, ");           
    cli_out(cli,  "NHP-Next Hop Ptr.");
    cli_out(cli, " \n"); 
    cli_out(cli,  "AT-Aps Type.");
    cli_out(cli,  "NHE-Next Hop Ext.");
    cli_out(cli, " \n");          
}
static void 
_diag_show_sram_dsfwd_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " DSFWD");
    cli_out(cli, "%-3s" , "SL");
    cli_out(cli, "%-3s" , "LA");
    cli_out(cli, "%-3s" , "CP");
    cli_out(cli, "%-5s" , "STAP");
    cli_out(cli, "%-7s" , "DM");
    cli_out(cli, "%-3s" , "SV");
    cli_out(cli, "%-6s" , "NHP");
    cli_out(cli, "%-3s" , "AT");
    cli_out(cli, "%-4s" , "NHE");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsfwd_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%6s" , "");
    cli_out(cli, " %-2x", resp->dsfwd.send_local_phy_port);
    cli_out(cli, " %-2x", resp->dsfwd.length_adjust_type);
    cli_out(cli, " %-2x", resp->dsfwd.critical_packet);
    cli_out(cli, " %-4x", (resp->dsfwd.stats_ptr_lower + (resp->dsfwd.stats_ptr_upper <<12)));
    cli_out(cli, " %-6x", resp->dsfwd.dest_map);
    cli_out(cli, " %-2x", resp->dsfwd.stats_valid);
    cli_out(cli, " %-5x", resp->dsfwd.next_hop_ptr);
    cli_out(cli, " %-2x", resp->dsfwd.aps_type);
    cli_out(cli, " %-3x", resp->dsfwd.next_hop_ext);
    cli_out(cli, " \n"); 
}

void 
diag_show_sram_dsnexthop_head_explain(struct cli *cli)
{
    cli_out(cli,  " DSNH, "); 
    cli_out(cli,  "SCF-Stag Cfi, "); 
    cli_out(cli,  "SCS-Stag Cos, "); 
    cli_out(cli,  "CTC-Copy Ctag Cos, "); 
    cli_out(cli,  "SVT-Svlan Tagged, "); 
    cli_out(cli, " \n"); 
    cli_out(cli,  "CVT-Cvlan Tagged, "); 
    cli_out(cli,  "RCC-Replace Ctag Cos, "); 
    cli_out(cli,  "AQE-Service Acl Qos En, "); 
    cli_out(cli, " \n"); 
    cli_out(cli,  "DSC-Derive Stag Cos, "); 
    cli_out(cli,  "TMD-Tagged Mode, "); 
    cli_out(cli,  "L2P-L2 Edit Ptr, "); 
    cli_out(cli,  "BP-By Pass All, ");  
    cli_out(cli, " \n"); 
    cli_out(cli,  "L2T-L2 Rewrite Type, "); 
    cli_out(cli,  "PL-Pay Load Operation, ");  
    cli_out(cli,  "OCV-Output Cvlan Id Valid.");  
    cli_out(cli, " \n"); 
    cli_out(cli,  "MC-Mtu Check En, ");  
    cli_out(cli,  "L3T-L3 Rewrite Type, "); 
    cli_out(cli,  "DVP-Dest Vlan Ptr.");  
    cli_out(cli, " \n"); 
    cli_out(cli,  "OSV-Output Svlan Id Valid.");  
    cli_out(cli,  "SPV-Service Policer Vld.");  
    cli_out(cli,  "L3P-L3 Edit Ptr, "); 
    cli_out(cli, " \n"); 
}
void 
diag_show_sram_dsnexthop_head(struct cli *cli)
{
    cli_out(cli, "%-6s" , " DSNH");
    cli_out(cli, "%-4s" , "SCF");
    cli_out(cli, "%-4s" , "SCS");
    cli_out(cli, "%-4s" , "CTC");
    cli_out(cli, "%-4s" , "SVT");
    cli_out(cli, "%-4s" , "CVT");
    cli_out(cli, "%-4s" , "RCC");
    cli_out(cli, "%-4s" , "DSC");
    cli_out(cli, "%-4s" , "AQE");
    cli_out(cli, "%-4s" , "TMD");
    cli_out(cli, "%-4s" , "L2T");
    cli_out(cli, "%-4s" , "BP");
    cli_out(cli, "%-4s" , "PL");
    cli_out(cli, "%-4s" , "MC");
    cli_out(cli, "%-4s" , "L3T");
    cli_out(cli, "%-4s" , "OCV");
    cli_out(cli, "%-4s" , "OSV");
    cli_out(cli, "%-4s" , "SPV");
    cli_out(cli, "%-5s" , "DVP");
    cli_out(cli, "%-6s" , "L2P");
    cli_out(cli, "%-6s" , "L3P");
    cli_out(cli, " \n"); 
}
void
diag_show_sram_dsnexthop_entry(struct cli *cli, diag_sram_entry_resp_t* resp, uint32 new_l2edit_ptr, uint32 new_l3edit_ptr)
{
    cli_out(cli, "%5s" , "");
    cli_out(cli, " %-3x", resp->dsnh.stag_cfi);
    cli_out(cli, " %-3x", resp->dsnh.stag_cos);
    cli_out(cli, " %-3x", resp->dsnh.copy_ctag_cos);
    cli_out(cli, " %-3x", resp->dsnh.svlan_tagged);
    cli_out(cli, " %-3x", resp->dsnh.cvlan_tagged);
    cli_out(cli, " %-3x", resp->dsnh.replace_ctag_cos);
    cli_out(cli, " %-3x", resp->dsnh.derive_stag_cos);
    cli_out(cli, " %-3x", resp->dsnh.service_acl_qos_en);
    cli_out(cli, " %-3x", resp->dsnh.tagged_mode);
    cli_out(cli, " %-3x", resp->dsnh.l2_rewrite_type);
    cli_out(cli, " %-3x", resp->dsnh.by_pass_all);
    cli_out(cli, " %-3x", resp->dsnh.payload_operation);
    cli_out(cli, " %-3x", resp->dsnh.mtu_check_en);
    cli_out(cli, " %-3x", resp->dsnh.l3_rewrite_type);
    cli_out(cli, " %-3x", resp->dsnh.output_cvlan_id_valid);
    cli_out(cli, " %-3x", resp->dsnh.output_svlan_id_valid);
    cli_out(cli, " %-3x", resp->dsnh.service_policer_vld);
    cli_out(cli, " %-4x", resp->dsnh.dest_vlan_ptr);
/*    cli_out(cli, " %-5x", resp->dsnh.l2edit_ptr); */
/*    cli_out(cli, " %-5x", resp->dsnh.l3edit_ptr); */
    cli_out(cli, " %-5x", new_l2edit_ptr);
    cli_out(cli, " %-5x", new_l3edit_ptr);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_dsmet_from_fwd( struct cli *cli, diag_sram_entry_req_t* req, 
                                diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    uint32 i = 0;
    uint32 count = 5000;
    uint32 copy = 0;
    uint32 next_met_ptr = 0;
    uint32 nh_offset = 0;
    uint32 index = 0xFFFF << 2; /* _sys_humber_nh_dsnh_init_for_brg(); */

    while (count --)
    {
        DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
        if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
        {
            return CLI_SUCCESS;
        }
        if ( if_explain )
        {
            _diag_show_sram_dsmet_head_explain(cli);
            cli_out(cli,"\n");
        }    
        _diag_show_sram_dsmet_head( cli );
        _diag_show_sram_dsmet_entry( cli, resp );
        cli_out(cli,"\n");
        
        next_met_ptr = resp->met.next_met_entry_ptr;
        
        if ( !if_list ) 
        {
            return CLI_SUCCESS;
        }
        
        if (!resp->met.remote_bay)
        {   /*see humber_qmgt_generate_dequeue()*/
            if ((resp->met.replication_ctl >> 26) & 1)
            {
                copy = resp->met.replication_ctl & 0xFFF;
                nh_offset = (resp->met.replication_ctl >> 6) & 0xFFFC0;
            }
            else
            {
                copy = resp->met.replication_ctl & 0x3F;
                nh_offset = (resp->met.replication_ctl >> 6) & 0xFFFFF;
            }
            for (i=0; i <= copy; i++)
            {                
                req->table_type = resp->met.nexthop_ext == TRUE ? DIAG_DS_NEXTHOP8W : DIAG_DS_NEXTHOP;
                
                req->index = nh_offset + i; 
                if (req->index -index >= 0 && req->index - index < 4)
                {
                    req->table_type = resp->met.nexthop_ext == TRUE ? 
                                      DIAG_EPE_NEXT_HOP_INTERNAL8W : DIAG_EPE_NEXT_HOP_INTERNAL4W;
                    
                    req->index = (req->index - index) + i;    
                }
                DIAG_SHOW_IF_ERROR_RETURN(diag_show_sram_dsnh(cli,req, resp, if_list, if_explain));
                
                if_explain = 0;
            }
        }
        
        if (DIAG_SPECIAL_MET_OFFSET == next_met_ptr)
        {
            break;
        }
        req->table_type = DIAG_DS_MET_ENTRY;
        req->index = next_met_ptr; 
        sal_memset(resp,0,sizeof(diag_sram_entry_resp_t));
        cli_out(cli, " \n\n"); 
    }
    return CLI_SUCCESS;
}

int32 
diag_show_sram_dsfwd( struct cli *cli, diag_sram_entry_req_t* req, 
                      diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsfwd_head_explain(cli);
         cli_out(cli,"\n");
    }
    _diag_show_sram_dsfwd_head( cli );
    _diag_show_sram_dsfwd_entry( cli, resp );
    cli_out(cli,"\n");
    if ( if_list)
    {
        if ( !(resp->dsfwd.dest_map & (1<<21)))
        {
            uint32 index = 0xffff<<2; /* _sys_humber_nh_dsnh_init_for_brg(); */
            
            req->table_type = resp->dsfwd.next_hop_ext == TRUE ? DIAG_DS_NEXTHOP8W : DIAG_DS_NEXTHOP;
            
            req->index = resp->dsfwd.next_hop_ptr;
            
            if (req->index -index >= 0 && req->index - index < 4)
            {
                req->table_type = resp->dsfwd.next_hop_ext == TRUE ? 
                                  DIAG_EPE_NEXT_HOP_INTERNAL8W : DIAG_EPE_NEXT_HOP_INTERNAL4W;
                
                req->index = req->index -index;    
            }
            diag_show_sram_dsnh( cli, req, resp, if_list, if_explain);
        }
        else if (resp->dsfwd.dest_map & (1<<21)) 
        {
            req->table_type = DIAG_DS_MET_ENTRY;
            req->index = resp->dsfwd.dest_map & 0xffff;
            req->chip_id = req->chip_id;
            _diag_show_sram_dsmet_from_fwd( cli, req, resp, if_list, if_explain);
        }
    }
    return CLI_SUCCESS;
}

int32 
diag_show_sram_dsda( struct cli *cli, diag_sram_entry_req_t* req, 
                     diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp ))
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        diag_show_tcam_dsipda_head_explain(cli);        
    }
    cli_out(cli, " \n"); 
    diag_show_tcam_dsipda_head( cli );
    cli_out(cli, " \n"); 
    _diag_show_tcam_dsipda_entry( cli, resp );
    cli_out(cli,"\n");
    if ( if_list)
    {
        if ( resp->dsipda.ds_fwd_ptr != 0xfffff)
        {
            req->table_type = DIAG_DS_FWD;
            req->index = resp->dsipda.ds_fwd_ptr;
            diag_show_sram_dsfwd( cli, req, resp, if_list, if_explain);
        }
    }
    return CLI_SUCCESS;
}

static int32 
_diag_show_sram_dsrtmac( struct cli *cli, diag_sram_entry_req_t* req, 
                         diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        _diag_show_sram_dsrtmac_head_explain(cli);        
    }
    _diag_show_sram_dsrtmac_head( cli );
    _diag_show_sram_dsrtmac_entry( cli, resp );
    cli_out(cli,"\n");
    if ( if_list)
    {
        if ( resp->mpls.ds_fwd_ptr != 0xfffff)
        {
            req->table_type = DIAG_DS_FWD;
            req->index = resp->mpls.ds_fwd_ptr;
            diag_show_sram_dsfwd( cli, req, resp, if_list, if_explain);
        }
    }
    return CLI_SUCCESS;
}

static int32 
_diag_show_sram_dsmpls( struct cli *cli, diag_sram_entry_req_t* req, 
                        diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        _diag_show_tcam_dsmpls_head_explain(cli);        
    }
    _diag_show_tcam_dsmpls_head( cli );
    _diag_show_tcam_dsmpls_entry( cli, resp );
    cli_out(cli,"\n");
    if ( if_list)
    {
        if ( resp->mpls.ds_fwd_ptr != 0xfffff)
        {
            req->table_type = DIAG_DS_FWD;
            req->index = resp->mpls.ds_fwd_ptr;
            diag_show_sram_dsfwd( cli, req, resp, if_list, if_explain);
        }
    }
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl3edit_tunnelv4_head_explain(struct cli *cli)
{
    cli_out(cli, " DSL3Edit-tunnelv4, ");   
    cli_out(cli,  "GSI-Gre Sequence Id108, ");
    cli_out(cli,  "GV-Gre Version, ");
    cli_out(cli,  "CDF-Copy Dont Frag, ");
    cli_out(cli,  "DF-Dont Frag, ");
    cli_out(cli,  "IIT-Ip Identific Type, ");
    cli_out(cli,  "TSA-t6to4 Tunnel SA, ");
    cli_out(cli,  "TNL-t6to4 Tunnel, ");
    cli_out(cli,  "IHV-Inner Header Valid, ");
    cli_out(cli,  "VPC-Vpls Port Chk En, ");
    cli_out(cli,  "IST-Is atp Tunnel, ");
    cli_out(cli,  "IH-Inner Heder Type, ");
    cli_out(cli,  "DS-DSCP, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "MCE- MTU Check En, ");
    cli_out(cli,  "DD-Derive Dscp, ");
    cli_out(cli,  "MT-Map TTL, ");
    cli_out(cli,  "USP-UDP SRC Port, ");
    cli_out(cli,  "UDP-UDP DST Port, ");
    cli_out(cli, " \n"); 
}
static void 
_diag_show_sram_dsl3edit_tunnelv4_head(struct cli *cli)
{
    cli_out(cli, "%-10s"," Tunnelv4");   
    cli_out(cli, "%-4s" , "GSI");
    cli_out(cli, "%-4s" , "GV");
    cli_out(cli, "%-4s" , "CDF");
    cli_out(cli, "%-4s" , "DF");
    cli_out(cli, "%-4s" , "IIT");
    cli_out(cli, "%-4s" , "TSA");
    cli_out(cli, "%-4s" , "TNL");
    cli_out(cli, "%-4s" , "IHV");
    cli_out(cli, "%-4s" , "VPC");
    cli_out(cli, "%-4s" , "IST");
    cli_out(cli, "%-3s" , "IH");
    cli_out(cli, "%-3s" , "DS");
    cli_out(cli, "%-4s" , "TTL");
    cli_out(cli, "%-3s" , "DD");
    cli_out(cli, "%-3s" , "MT");
    cli_out(cli, "%-4s" , "USP");
    cli_out(cli, "%-4s" , "UDP");
    cli_out(cli, "%-4s" , "MCE" );
    cli_out(cli, "%-12s" , "IPSA");
    cli_out(cli, "%-12s" , "IPDA");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsl3edit_tunnelv4_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");

    cli_out(cli, " %-3x", resp->tunnelv4.gre_sequence_id108);
    cli_out(cli, " %-3x", resp->tunnelv4.gre_version);
    cli_out(cli, " %-3x", resp->tunnelv4.copy_dont_frag);
    cli_out(cli, " %-3x", resp->tunnelv4.dont_frag);
    cli_out(cli, " %-3x", resp->tunnelv4.ip_identific_type);
    cli_out(cli, " %-3x", resp->tunnelv4.t6to4_tunnel_sa);
    cli_out(cli, " %-3x", resp->tunnelv4.t6to4_tunnel);
    cli_out(cli, " %-3x", resp->tunnelv4.inner_header_valid);
    cli_out(cli, " %-3x", resp->tunnelv4.vpls_port_chk_en);
    cli_out(cli, " %-3x", resp->tunnelv4.is_atp_tunnel);
    cli_out(cli, " %-2x", resp->tunnelv4.inner_header_type);
    cli_out(cli, " %-2x", resp->tunnelv4.dscp);
    cli_out(cli, " %-3x", resp->tunnelv4.ttl);
    cli_out(cli, " %-2x", resp->tunnelv4.derive_dscp);
    cli_out(cli, " %-2x", resp->tunnelv4.map_ttl);
    cli_out(cli, " %-3x", resp->tunnelv4.gre_protocol_udp_src_port);
    cli_out(cli, " %-3x", resp->tunnelv4.gre_key_udp_dest_port);
    cli_out(cli, " %-3x", resp->tunnelv4.mtu_check_en);
    cli_out(cli, " 0x%08x", (resp->tunnelv4.ip_sa));  
    cli_out(cli, " 0x%08x", (resp->tunnelv4.ip_da));    
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_l3edit_tunnelv4( struct cli *cli, diag_sram_entry_req_t* req, 
                                diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl3edit_tunnelv4_head_explain(cli);
    }
    _diag_show_sram_dsl3edit_tunnelv4_head( cli );
    _diag_show_sram_dsl3edit_tunnelv4_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl3edit_tunnelv6_head(struct cli *cli)
{
    cli_out(cli, "%-10s"," Tunnelv6");   

    cli_out(cli, "%-4s" , "VPC");
    cli_out(cli, "%-4s" , "GSI");
    cli_out(cli, "%-4s" , "GV");
    cli_out(cli, "%-4s" , "NFL");
    cli_out(cli, "%-4s" , "GK1");
    cli_out(cli, "%-4s" , "VDP");
    cli_out(cli, "%-4s" , "GK2");

    cli_out(cli, "%-4s" , "TS");
    cli_out(cli, "%-4s" , "GF");
    cli_out(cli, "%-4s" , "GP");
    cli_out(cli, "%-4s" , "PT");
    cli_out(cli, "%-3s" , "DD");
    cli_out(cli, "%-4s" , "ISI");
    cli_out(cli, "%-4s" , "IDI");
    cli_out(cli, " \n"); 
}
static void 
_diag_show_sram_dsl3edit_tunnelv6_head_explain(struct cli *cli)
{
    cli_out(cli," Tunnelv6, ");   

    cli_out(cli, "VPC-vpls_port_chk_en, ");
    cli_out(cli, "GSI-gre_sequence_id108, ");
    cli_out(cli, "GV-gre_version, ");
    cli_out(cli, "NFL-new_flow_label_valid, ");
    cli_out(cli, "GK1-gre_key150, ");
    cli_out(cli, "VDP-vpls_dest_port12to0, ");
    cli_out(cli, "GK2-gre_key3116, ");

    cli_out(cli, "TS-ToS, ");
    cli_out(cli, "GF-Gre Flags, ");
    cli_out(cli, "GP-Gre Protocol, ");
    cli_out(cli, "PT-Ip Protocol Type, ");
    cli_out(cli, "IAT-Is ATP Tunnel, ");
    cli_out(cli, "DD-Derive_Dscp. ");
    cli_out(cli, "ISI-IpSa Index. ");
    cli_out(cli, "IDI-IpDa Index. ");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsl3edit_tunnelv6_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");

    cli_out(cli, " %-3x", resp->tunnelv6.vpls_port_chk_en);
    cli_out(cli, " %-3x", resp->tunnelv6.gre_sequence_id108);
    cli_out(cli, " %-3x", resp->tunnelv6.gre_version);
    cli_out(cli, " %-3x", resp->tunnelv6.new_flow_label_valid);
    cli_out(cli, " %-3x", resp->tunnelv6.gre_key150);
    cli_out(cli, " %-3x", resp->tunnelv6.vpls_dest_port11to0 + (resp->tunnelv6.vpls_dest_port12 << 12));
    cli_out(cli, " %-3x", resp->tunnelv6.gre_key3116);

    cli_out(cli, " %-3x", resp->tunnelv6.tos);
    cli_out(cli, " %-3x", resp->tunnelv6.gre_flags);
    cli_out(cli, " %-3x", resp->tunnelv6.gre_protocol);
    cli_out(cli, " %-3x", resp->tunnelv6.ip_protocol_type);
    cli_out(cli, " %-2x", resp->tunnelv6.derive_dscp);
    cli_out(cli, " %-3x", resp->tunnelv6.ipsa_index);
    cli_out(cli, " %-3x", resp->tunnelv6.ipda_index);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_l3edit_tunnelv6( struct cli *cli, diag_sram_entry_req_t* req, 
                                 diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl3edit_tunnelv6_head_explain(cli);
    }
    _diag_show_sram_dsl3edit_tunnelv6_head( cli );
    _diag_show_sram_dsl3edit_tunnelv6_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl3edit_flex_head(struct cli *cli)
{
    cli_out(cli, "%-6s" , " Flex");
    cli_out(cli, "%-4s" , "PT");
    cli_out(cli, "%-4s" , "RBN");
    cli_out(cli, "%-9s" , "RS0");
    cli_out(cli, "%-9s" , "RS1");
    cli_out(cli, "%-9s" , "RS2");
    cli_out(cli, "%-9s" , "RS3");
    cli_out(cli, " \n"); 
}
static void 
_diag_show_sram_dsl3edit_flex_head_explain(struct cli *cli)
{
    cli_out(cli, " Flex, ");
    cli_out(cli, "PT-Pkt Type, ");
    cli_out(cli, "RBN-Rewrite Byte Num, ");
    cli_out(cli, "RS0-Rewrite String 0, ");
    cli_out(cli, "RS1-Rewrite String 1, ");
    cli_out(cli, "RS2-Rewrite String 2, ");
    cli_out(cli, "RS3-Rewrite String 3. ");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsl3edit_flex_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%5s" , "");
    cli_out(cli, " %-3x", resp->flex.packet_type);
    cli_out(cli, " %-3x", resp->flex.rewrite_byte_num);
    cli_out(cli, " %-8x", resp->flex.rewrite_string0);
    cli_out(cli, " %-8x", resp->flex.rewrite_string1);
    cli_out(cli, " %-8x", resp->flex.rewrite_string2);
    cli_out(cli, " %-8x", resp->flex.rewrite_string3);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_l3edit_flex( struct cli *cli, diag_sram_entry_req_t* req, 
                             diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl3edit_flex_head_explain(cli);
    }
    _diag_show_sram_dsl3edit_flex_head( cli );
    _diag_show_sram_dsl3edit_flex_entry( cli, resp );
    return CLI_SUCCESS;
}

static int32 
_diag_show_sram_dsmet( struct cli *cli, diag_sram_entry_req_t* req, 
                       diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    uint32 i = 0;
    uint32 copy = 0;
    uint32 nh_offset = 0;
    uint32 index = 0xffff<<2; /* _sys_humber_nh_dsnh_init_for_brg(); */

    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsmet_head_explain(cli);
    }    
    _diag_show_sram_dsmet_head( cli );
    _diag_show_sram_dsmet_entry( cli, resp );
    
    if ( !if_list )
    {
        return CLI_SUCCESS;
    }
    
    if (!resp->met.remote_bay)
    {   /*see humber_qmgt_generate_dequeue()*/
        if ((resp->met.replication_ctl >> 26) & 1)
        {
            copy = resp->met.replication_ctl & 0xFFF;
            nh_offset = (resp->met.replication_ctl >> 6) & 0xFFFC0;
        }
        else
        {
            copy = resp->met.replication_ctl & 0x3F;
            nh_offset = (resp->met.replication_ctl >> 6) & 0xFFFFF;
        }
        for (i=0; i < copy; i++)
        {            
            req->table_type = resp->met.nexthop_ext == TRUE ? 
                              DIAG_DS_NEXTHOP8W : DIAG_DS_NEXTHOP;
            
            req->index = nh_offset + i; 
            if (req->index -index >= 0 && req->index - index < 4)
            {
                req->table_type = resp->met.nexthop_ext == TRUE ? 
                                  DIAG_EPE_NEXT_HOP_INTERNAL8W : DIAG_EPE_NEXT_HOP_INTERNAL4W;
                
                req->index = (req->index - index) + i;    
            }
            DIAG_SHOW_IF_ERROR_RETURN(diag_show_sram_dsnh(cli, req, resp, if_list, if_explain));

            if_explain = 0;
        }
    } 
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_src_port_head_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, " DSSrcPort, ");   
    cli_out(cli,  "RE-ReceiVe En, ");
    cli_out(cli,  "AMM-Allow Mcast MACSA, ");
    cli_out(cli,  "BE-Bridge En, ");
    cli_out(cli,  "QD-Qos Domain, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "TE-Default Replace Tag En, ");
    cli_out(cli,  "VSP-Vpls Src Port, ");
    cli_out(cli,  "UBC-Use Btag Cos, ");
    cli_out(cli,  "IFE_Ingress filter En, ");
    cli_out(cli,  "RTD-Route Disable, ");
    cli_out(cli, " \n"); 

    cli_out(cli,  "PCE-port Check En, ");
    cli_out(cli,  "4MK-Force Acl Qos Ipv4 To Mac Key, ");
    cli_out(cli,  "SEE-Port Security Exception En, ");
    cli_out(cli,  "OTE-Aam Tunnel En, ");
    cli_out(cli,  "PTS-Port Security En, ");
    cli_out(cli,  "6MK-Force Acl Qos Ipv6 To Mac Key, ");

    cli_out(cli,  "AE-L2 ACL EN, ");
    cli_out(cli,  "AHP-L2 ACL High priority, ");
    cli_out(cli,  "AL-L2 ACL Lable, ");
    
    cli_out(cli,  "QHP-L2 QOS High priority, ");
    cli_out(cli,  "QL-L2 QOS Lable, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "QE-L2 QOS lookup En, ");
    cli_out(cli,  "OV-Ether Oam Valid, ");
    cli_out(cli,  "LEV-Oam Link Max Md Level, ");
    cli_out(cli,  "LD-Learning Disable, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "MSD-Mac Security Discard, ");
    cli_out(cli,  "PCC-Port Cross Connect, ");
    cli_out(cli,  "PPV-Port Policer Valid, ");
    cli_out(cli,  "SPI-Source Port Isolated, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PVE-Protocol VLAN En, ");
    cli_out(cli,  "QP-QOS Policy, ");
    cli_out(cli,  "CPN-Equal Cos Path Num, ");
    cli_out(cli,  "II-ipg_index , ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "UOT-Use Outer TTL, ");
    cli_out(cli,  "VFP-VLAN Flow Policer Valid, ");
    cli_out(cli,  "VTC-Vlan Tag Ctl, ");
    cli_out(cli,  "VPT-VPLS Port Type,");
    cli_out(cli,  "RTP-Routed Port.");    
    cli_out(cli,  "USC-Use Stag Cos.");    
    cli_out(cli,  "RPTR-Routed Port VlanPtr.");    
    cli_out(cli, " \n"); 
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_src_port_entry_1_line(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%2s" , "");
    cli_out(cli, " %-2x", resp->src_port.receive_en);
    cli_out(cli, " %-3x", resp->src_port.allow_mcast_mac_sa);
    cli_out(cli, " %-3x", resp->src_port.bridge_en);
    cli_out(cli, " %-3x", resp->src_port.qos_domain);
    cli_out(cli, " %-2x", resp->src_port.default_replace_tag_en);
    
    cli_out(cli, " %-4x", resp->src_port.vpls_src_port);
    cli_out(cli, " %-3x", resp->src_port.use_btag_cos);
    cli_out(cli, " %-3x", resp->src_port.ingress_filtering_en);
    cli_out(cli, " %-3x", resp->src_port.route_disable);
    cli_out(cli, " %-3x", resp->src_port.l2_acl_en);
    
    cli_out(cli, " %-3x", resp->src_port.port_check_en);
    cli_out(cli, " %-3x", resp->src_port.force_acl_qos_ipv4_to_mac_key);
    cli_out(cli, " %-3x", resp->src_port.port_security_exception_en);
    cli_out(cli, " %-3x", resp->src_port.oam_tunnel_en);
    cli_out(cli, " %-3x", resp->src_port.port_security_en);
    cli_out(cli, " %-3x", resp->src_port.force_acl_qos_ipv6_to_mac_key);
    
    cli_out(cli, " %-3x", resp->src_port.l2_acl_high_priority);
    cli_out(cli, " %-2x", resp->src_port.l2_acl_label);
   
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_src_port_head_1_line(struct cli *cli)
{
    cli_out(cli, "%-3s"," SP");   
    cli_out(cli, "%-3s" , "RE");
    cli_out(cli, "%-4s" , "AMM");
    cli_out(cli, "%-4s" , "BE");
    cli_out(cli, "%-3s" , "QD");
    cli_out(cli, "%-3s" , "TE");
    
    cli_out(cli, "%-5s" , "VSP");
    cli_out(cli, "%-4s" , "UBS");
    cli_out(cli, "%-4s" , "IFE");
    cli_out(cli, "%-4s" , "RTD");
    cli_out(cli, "%-4s" , "LAE");

    cli_out(cli, "%-4s" , "PCE");
    cli_out(cli, "%-4s" , "4MK");
    cli_out(cli, "%-4s" , "SEE");
    cli_out(cli, "%-4s" , "OTE");
    cli_out(cli, "%-4s" , "PTS");
    cli_out(cli, "%-4s" , "6MK");

    cli_out(cli, "%-4s" , "AHP");
    cli_out(cli, "%-3s" , "AL");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_src_port_entry_2_line(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%2s" , "");

    cli_out(cli, " %-3x", resp->src_port.l2_qos_high_priority);
    cli_out(cli, " %-2x", resp->src_port.l2_qos_label);
    cli_out(cli, " %-2x", resp->src_port.l2_qos_lookup_en);
    cli_out(cli, " %-3x", resp->src_port.ether_oam_valid);
    cli_out(cli, " %-2x", resp->src_port.oam_link_max_md_level);
    cli_out(cli, " %-3x", resp->src_port.learning_disable);
    cli_out(cli, " %-3x", resp->src_port.mac_security_discard);
    cli_out(cli, " %-2x", resp->src_port.port_cross_connect);
    cli_out(cli, " %-2x", resp->src_port.port_policer_valid);
    cli_out(cli, " %-2x", resp->src_port.source_port_isolated);
    cli_out(cli, " %-2x", resp->src_port.protocol_vlan_en);
    cli_out(cli, " %-3x", resp->src_port.qos_policy);
    cli_out(cli, " %-2x", resp->src_port.equal_cos_path_num);
    cli_out(cli, " %-3x", resp->src_port.ipg_index);
    cli_out(cli, " %-3x", resp->src_port.use_outer_ttl);
    cli_out(cli, " %-3x", resp->src_port.vlan_flow_policer_valid);
    cli_out(cli, " %-3x", resp->src_port.vlan_tag_ctl);
    cli_out(cli, " %-3x", resp->src_port.vpls_port_type);
    cli_out(cli, " %-2x", resp->src_port.routed_port);
    cli_out(cli, " %-3x", resp->src_port.use_stag_cos);
    cli_out(cli, " %-4x", resp->src_port.routed_port_vlan_ptr);
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_src_port_head_2_line(struct cli *cli)
{
    cli_out(cli, "%-3s"," ");   
    cli_out(cli, "%-4s" , "QHP");
    cli_out(cli, "%-3s" , "QL");
    cli_out(cli, "%-3s" , "QE");
    cli_out(cli, "%-3s" , "OV");
    cli_out(cli, "%-4s" , "LEV");
    cli_out(cli, "%-4s" , "LD");
    cli_out(cli, "%-4s" , "MSD");
    cli_out(cli, "%-3s" , "PC");
    cli_out(cli, "%-3s" , "PV");
    cli_out(cli, "%-3s" , "PI");
    cli_out(cli, "%-3s" , "VE");
    cli_out(cli, "%-4s" , "QP");
    cli_out(cli, "%-3s" , "PN");
    cli_out(cli, "%-3s" , "II");
    cli_out(cli, "%-4s" , "UOT");
    cli_out(cli, "%-4s" , "VFP");
    cli_out(cli, "%-4s" , "VTC");
    cli_out(cli, "%-4s" , "VPT");
    cli_out(cli, "%-3s" , "RT");    
    cli_out(cli, "%-5s" , "USC");    
    cli_out(cli, "%-5s" , "RPTR");    
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_src_port( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_src_port_head_explain(cli);
    }
    _diag_show_sram_src_port_head_1_line( cli );
    _diag_show_sram_src_port_entry_1_line( cli, resp );
    _diag_show_sram_src_port_head_2_line( cli );
    _diag_show_sram_src_port_entry_2_line( cli, resp );
    return CLI_SUCCESS;
}
static void
_diag_show_sram_dest_port_head_explain(struct cli *cli )
{
    cli_out(cli, " \n"); 
    cli_out(cli, " DstPort, ");   
    cli_out(cli,  "BE-Bridge En, ");
    cli_out(cli,  "DV-Default Vid, ");
    cli_out(cli,  "DPI-Dest Port Isolation Id, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "DET-Dot1q ether Type En, ");
    cli_out(cli,  "EFE-Egress Filter En, ");
    cli_out(cli,  "FM-force Ipv4 to Mac Key, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PMS-Pip Mac Sa, ");
    cli_out(cli,  "LAE-L2 ACL EN, ");
    cli_out(cli,  "LAH-L2 ACL High priority, ");
    cli_out(cli,  "LAL-L2 ACL Lable, ");
    cli_out(cli, " \n");
    cli_out(cli,  "LQH-L2 QOS High priority, ");
    cli_out(cli,  "LQL-L2 QOS Lable, ");
    cli_out(cli,  "PPV-Port Policer Valid, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "RC-Replace Cos, ");
    cli_out(cli,  "RD-Replace DSCP, ");
    cli_out(cli,  "RP-Routed Port, ");
    cli_out(cli,  "SCD-STP Check Disable, ");
    cli_out (cli, " \n"); 
    cli_out(cli,  "TE-Transmit En,");
    cli_out(cli,  "QSD-QoS Domain, ");
    cli_out(cli,  "IIX-Ipg IndeX, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "STI-Svlan Tpid Index,");
    cli_out(cli,  "UDS-Untag Default Svlan, ");
    cli_out(cli,  "VFV- VLAN flow Policer valid, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "VPT- VPLS Port type.");    
    cli_out(cli,  "QLE- L2 Qos Lookup En.");
    cli_out(cli,  "6MK- Force Ipv6 To Mac Key.");
    cli_out(cli, " \n"); 
    cli_out(cli,  "B2M- Bridge L2 Match Disable.");
    cli_out(cli,  "UVI- Untag Default Vlan Id.");
    cli_out(cli,  "PPT- Pbb Port Type.");
    cli_out(cli, " \n"); 
    cli_out(cli,  "MFD- Mcast Flooding Disable.");
    cli_out(cli,  "UFD- Ucast Flooding Disable.");
    cli_out(cli,  "MDL- Md Level.");
    cli_out(cli, " \n"); 
    cli_out(cli,  "EOV- Ether Oam Valid.");
    cli_out(cli, " \n\n"); 
    
}

static void
_diag_show_sram_dest_port_head_1_line(struct cli *cli)
{
    cli_out(cli, "%-9s"," DstPort");   
    cli_out(cli, "%-4s" , "BE");
    cli_out(cli, "%-4s" , "DV");
    cli_out(cli, "%-4s" , "DPI");
    cli_out(cli, "%-4s" , "DET");
    cli_out(cli, "%-4s" , "EFE");
    cli_out(cli, "%-4s" , "FM");
    cli_out(cli, "%-4s" , "PMS");
    cli_out(cli, "%-4s" , "LAE");
    cli_out(cli, "%-4s" , "LAH");
    cli_out(cli, "%-4s" , "LAL");
    cli_out(cli, "%-4s" , "LQH");
    cli_out(cli, "%-4s" , "LQL");
    cli_out(cli, "%-4s" , "PPV");
    cli_out(cli, "%-4s" , "RC");
    cli_out(cli, "%-4s" , "RD");
    cli_out(cli, "%-4s" , "RP");
    cli_out(cli, "%-4s" , "SCD");
    
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dest_port_head_2_line(struct cli *cli)
{    
    cli_out(cli, "%-9s"," ");   
    cli_out(cli, "%-4s" , "TE");
    cli_out(cli, "%-4s" , "QSD");
    cli_out(cli, "%-4s" , "IIX");
    cli_out(cli, "%-4s" , "STI");
    cli_out(cli, "%-4s" , "UDS");
    cli_out(cli, "%-4s" , "VFV");
    cli_out(cli, "%-4s" , "VPT");    
    cli_out(cli, "%-4s" , "QLE");    
    cli_out(cli, "%-4s" , "6MK");    
    cli_out(cli, "%-4s" , "B2M");    
    cli_out(cli, "%-4s" , "UVI");    
    cli_out(cli, "%-4s" , "PPT");    
    cli_out(cli, "%-4s" , "MFD");    
    cli_out(cli, "%-4s" , "UFD");    
    cli_out(cli, "%-4s" , "MDL");    
    cli_out(cli, "%-4s" , "EOV");    
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dest_port_entry_1_line(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , "");
    cli_out(cli, " %-3x", resp->dest_port.bridge_en);
    cli_out(cli, " %-3x", resp->dest_port.default_vlan_id);
    cli_out(cli, " %-3x", resp->dest_port.dest_port_isolation_id);
    cli_out(cli, " %-3x", resp->dest_port.dot1q_en);
    cli_out(cli, " %-3x", resp->dest_port.egress_filter_en);
    cli_out(cli, " %-3x", resp->dest_port.force_ipv4_to_mac_key);
    cli_out(cli, " %-3x", resp->dest_port.pip_mac_sa);
    cli_out(cli, " %-3x", resp->dest_port.l2_acl_en);
    cli_out(cli, " %-3x", resp->dest_port.l2_acl_high_priority);
    cli_out(cli, " %-3x", resp->dest_port.l2_acl_label);
    cli_out(cli, " %-3x", resp->dest_port.l2_qos_high_priority);
    cli_out(cli, " %-3x", resp->dest_port.l2_qos_lable);
    cli_out(cli, " %-3x", resp->dest_port.port_policer_valid);
    cli_out(cli, " %-3x", resp->dest_port.replace_cos);
    cli_out(cli, " %-3x", resp->dest_port.replace_dscp);
    cli_out(cli, " %-3x", resp->dest_port.routed_port);
    cli_out(cli, " %-3x", resp->dest_port.stp_check_disable);
    
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dest_port_entry_2_line(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , "");
    
    cli_out(cli, " %-3x", resp->dest_port.transmit_en);
    cli_out(cli, " %-3x", resp->dest_port.qos_domain);
    cli_out(cli, " %-3x", resp->dest_port.ipg_index);
    cli_out(cli, " %-3x", resp->dest_port.svlan_tpid_index);
    cli_out(cli, " %-3x", resp->dest_port.untag_default_svlan);
    cli_out(cli, " %-3x", resp->dest_port.vlan_flow_policer_valid);
    cli_out(cli, " %-3x", resp->dest_port.vpls_port_type);

    cli_out(cli, " %-3x", resp->dest_port.l2_qos_lookup_en);
    cli_out(cli, " %-3x", resp->dest_port.force_ipv6_to_mac_key);
    cli_out(cli, " %-3x", resp->dest_port.bridge_l2_match_disable);
    cli_out(cli, " %-3x", resp->dest_port.untag_default_vlan_id);
    cli_out(cli, " %-3x", resp->dest_port.pbb_port_type);
    cli_out(cli, " %-3x", resp->dest_port.mcast_flooding_disable);
    cli_out(cli, " %-3x", resp->dest_port.ucast_flooding_disable);
    cli_out(cli, " %-3x", resp->dest_port.md_level);
    cli_out(cli, " %-3x", resp->dest_port.ether_oam_valid);

    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_dest_port( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dest_port_head_explain(cli);
    }
    _diag_show_sram_dest_port_head_1_line( cli );
    _diag_show_sram_dest_port_entry_1_line( cli, resp );
    _diag_show_sram_dest_port_head_2_line( cli );
    _diag_show_sram_dest_port_entry_2_line( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_phy_port_head(struct cli *cli)
{
    cli_out(cli, "%-11s"," DSPhyPort");   
    cli_out(cli, "%-4s" , "RLE");
    cli_out(cli, "%-4s" , "RDT");
    cli_out(cli, "%-4s" , "SCD");
    cli_out(cli, "%-4s" , "OVC");
    cli_out(cli, "%-4s" , "LSE");
    cli_out(cli, "%-4s" , "LSI");
    cli_out(cli, "%-4s" , "PTE");
    cli_out(cli, "%-4s" , "STI");
    cli_out(cli, "%-4s" , "KVT");
    cli_out(cli, "%-4s" , "PPT");
    cli_out(cli, "%-4s" , "PTV");
    cli_out(cli, "%-4s" , "PTP");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_phy_port_head_explain(struct cli *cli )
{
    cli_out(cli, " DSPhyPort, ");   
    cli_out(cli,  "RLE-Random Log En, ");
    cli_out(cli,  "RDT-Random Threshold, ");
    cli_out(cli,  "SCD-Src Discard, ");
    cli_out(cli,  "OVC-Outer Vlan Is Cvlan, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "LSE-L2 Span En, ");
    cli_out(cli,  "LSI-L2 Span Id, ");
    cli_out(cli,  "PTE-Ptp En, ");
    cli_out(cli,  "STI-Svlan Tpid Index, ");
    cli_out(cli,  "KVT-Keep Vlan Tag.");
    cli_out(cli,  "PPT-Pbb Port Type.");
    cli_out(cli,  "PTV-Packet Type Valid.");
    cli_out(cli,  "PTP-Packet Type.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_phy_port_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%10s" , "");
    cli_out(cli, " %-3x", resp->phy_port.random_log_en);
    cli_out(cli, " %-3x", resp->phy_port.random_threshold);
    cli_out(cli, " %-3x", resp->phy_port.src_discard);
    cli_out(cli, " %-3x", resp->phy_port.outer_vlan_is_cvlan);
    cli_out(cli, " %-3x", resp->phy_port.l2_span_en);
    cli_out(cli, " %-3x", resp->phy_port.l2_span_id);
    cli_out(cli, " %-3x", resp->phy_port.ptp_en);
    cli_out(cli, " %-3x", resp->phy_port.svlan_tpid_index);
    cli_out(cli, " %-3x", resp->phy_port.keep_vlan_tag);
    cli_out(cli, " %-3x", resp->phy_port.pbb_port_type);
    cli_out(cli, " %-3x", resp->phy_port.packet_type_valid);
    cli_out(cli, " %-3x", resp->phy_port.packet_type);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_phy_port( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_phy_port_head_explain(cli);
    }
    _diag_show_sram_phy_port_head( cli );
    _diag_show_sram_phy_port_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_proto_vlan_head(struct cli *cli)
{
    cli_out(cli, "%-13s"," DSProtoVLAN");   
    cli_out(cli, "%-4s" , "CEE");
    cli_out(cli, "%-4s" , "DS");
    cli_out(cli, "%-4s" , "PVV");
    cli_out(cli, "%-4s" , "PV");
    cli_out(cli, "%-4s" , "RTE");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_proto_vlan_head_explain(struct cli *cli)
{
    cli_out(cli, " DSProtoVLAN, ");   
    cli_out(cli,  "CEE-CPU Excp En, ");
    cli_out(cli,  "DS-Discard, ");
    cli_out(cli, " \n");
    cli_out(cli,  "PVV-Protocol VLANID Valid, ");
    cli_out(cli,  "PV-Ptl VID, ");
    cli_out(cli,  "RTE-Replace Tag En.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_proto_vlan_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%12s" , "");
    cli_out(cli, " %-3x", resp->protocol_vlan.cpu_exception_en);
    cli_out(cli, " %-3x", resp->protocol_vlan.discard);
    cli_out(cli, " %-3x", resp->protocol_vlan.protocol_vlan_id_valid);
    cli_out(cli, " %-3x", resp->protocol_vlan.protocol_vlan_id);
    cli_out(cli, " %-3x", resp->protocol_vlan.replace_tag_en);
    cli_out(cli, " \n"); 
}
static int32 
_diag_show_sram_proto_vlan( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_proto_vlan_head_explain(cli);
    }
    _diag_show_sram_proto_vlan_head( cli );
    _diag_show_sram_proto_vlan_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_dsmac_head(struct cli *cli)
{
    cli_out(cli, "%-7s"," DSMac");   

    cli_out(cli, "%-4s" , "LS0");
    cli_out(cli, "%-4s" , "LS1");
    cli_out(cli, "%-4s" , "SPP");
    cli_out(cli, "%-4s" , "ESP");
    cli_out(cli, "%-4s" , "ASV");
    cli_out(cli, "%-4s" , "ESI");

    cli_out(cli, "%-4s" , "ECP");
    cli_out(cli, "%-9s" , "FP");
    cli_out(cli, "%-4s" , "UD");
    cli_out(cli, "%-4s" , "LE");
    cli_out(cli, "%-4s" , "MDE");
    cli_out(cli, "%-4s" , "MSE");
    cli_out(cli, "%-4s" , "PPE");
    cli_out(cli, "%-4s" , "PET");
    cli_out(cli, "%-4s" , "MK");
    cli_out(cli, "%-4s" , "SCE");
    cli_out(cli, "%-4s" , "SD");
    cli_out(cli, "%-4s" , "SMD");
    cli_out(cli, "%-4s" , "SML");
    cli_out(cli, "%-5s" , "SP");
    cli_out(cli, "%-4s" , "SCT");
    cli_out(cli, "%-4s" , "MCD");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsmac_explain(struct cli *cli)
{
    cli_out(cli,  "DSMac, ");   

    cli_out(cli,  "LS0-Learn Source0, ");
    cli_out(cli,  "LS1-Learn Source1, ");
    cli_out(cli,  "SPP-Aps Select Protect Path, ");
    cli_out(cli,  "ESP-Esp_key Or Oam, ");
    cli_out(cli,  "ASV-Brg_aps Select Valid, ");
    cli_out(cli,  "ESI-Exception Sub Index, ");

    cli_out(cli, " \n"); 
    cli_out(cli,  "ECP-Equal Cost Path, ");
    cli_out(cli,  "FP-Fwd Ptr, ");
    cli_out(cli,  "UD-Ucast Discard, ");
    cli_out(cli,  "LE-Learn En, ");	
    cli_out(cli, " \n"); 
    cli_out(cli,  "MDE-MacDA excep En, ");
    cli_out(cli,  "MSE-MacSA excep En, ");
    cli_out(cli,  "PPE-Priority Path En, ");
    cli_out(cli,  "PET-Protocol Excep Type, ");
    cli_out(cli,  "MK-Mac Known, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "SCE-Srcport Check En, ");
    cli_out(cli,  "SD-Src disc, ");
    cli_out(cli,  "SMD-Src-Mismatch Disc, ");
    cli_out(cli,  "SML-Src-Mismatch Learn, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "SP-Src-Port, ");
    cli_out(cli,  "SCT-Storm Ctl En, ");
    cli_out(cli,  "MCD-Mcast Discard.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsmac_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%6s" , "");

    cli_out(cli, " %-3x", resp->dsmac.learn_source0);
    cli_out(cli, " %-3x", resp->dsmac.learn_source1);
    cli_out(cli, " %-3x", resp->dsmac.aps_select_protect_path);
    cli_out(cli, " %-3x", resp->dsmac.esp_key_or_oam);
    cli_out(cli, " %-3x", resp->dsmac.brg_aps_select_valid);
    cli_out(cli, " %-3x", resp->dsmac.exception_sub_index);

    cli_out(cli, " %-3x", resp->dsmac.equal_cost_path_num10);
    cli_out(cli, " %-08x", resp->dsmac.fwd_ptr);
    cli_out(cli, " %-3x", resp->dsmac.ucast_discard);
    cli_out(cli, " %-3x", resp->dsmac.learn_en);
    cli_out(cli, " %-3x", resp->dsmac.mac_da_exception_en);
    cli_out(cli, " %-3x", resp->dsmac.mac_sa_exception_en);
    cli_out(cli, " %-3x", resp->dsmac.priority_path_en);
    cli_out(cli, " %-3x", resp->dsmac.proto_exception_en);
    cli_out(cli, " %-3x", resp->dsmac.mac_known);
    cli_out(cli, " %-3x", resp->dsmac.source_port_check_en);
    cli_out(cli, " %-3x", resp->dsmac.src_discard);
    cli_out(cli, " %-3x", resp->dsmac.src_mismatch_discard);
    cli_out(cli, " %-3x", resp->dsmac.src_mismatch_learn_en);
    cli_out(cli, " %-4x", resp->dsmac.global_src_port);
    cli_out(cli, " %-3x", resp->dsmac.storm_ctl_en);
    cli_out(cli, " %-3x", resp->dsmac.mcast_discard);
    cli_out(cli, " \n"); 
}
static int32 
_diag_show_sram_mac( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsmac_explain(cli);
    }
    _diag_show_sram_dsmac_head( cli );
    _diag_show_sram_dsmac_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_aclqos_head(struct cli *cli)
{
    cli_out(cli, "%-10s"," DSACLQOS");   
    cli_out(cli, "%-4s" , "AL");
    cli_out(cli, "%-4s" , "COL");
    cli_out(cli, "%-4s" , "DB");
    cli_out(cli, "%-4s" , "DL");
    cli_out(cli, "%-4s" , "SM");
    cli_out(cli, "%-4s" , "DR");
    cli_out(cli, "%-4s" , "DP");
    cli_out(cli, "%-5s" , "FP");
    cli_out(cli, "%-4s" , "FWP");
    cli_out(cli, "%-4s" , "DRD");
    cli_out(cli, "%-4s" , "PR");
    cli_out(cli, "%-4s" , "PV");
    cli_out(cli, "%-4s" , "QP");
    cli_out(cli, "%-4s" , "RE");
    cli_out(cli, "%-4s" , "RT");
    cli_out(cli, "%-4s" , "SP");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_aclqos_head_explain(struct cli *cli)
{
    cli_out(cli, " DSACLQOS, ");   
    cli_out(cli,  "AL-ACL Logid, ");
    cli_out(cli,  "COL-Color, ");
    cli_out(cli,  "DB-Deny Bridge, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "DL-Deny Learning, ");
    cli_out(cli,  "SM-Stats Mode, ");
    cli_out(cli,  "DR-Deny Route, ");
    cli_out(cli,  "DP-Discard Packet, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "FP-Flowpolicer Ptr, ");
    cli_out(cli,  "FWP-FWD Ptr, ");
    cli_out(cli,  "DRD-Deny Replace Dscp, ");
    cli_out(cli,  "PR-Priority, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PV-Priority valid, ");
    cli_out(cli,  "QP-Qos Policy, ");
    cli_out(cli, " \n");
    cli_out(cli,  "RE-Radom Log En, ");
    cli_out(cli,  "RT-Random Thershold En, ");
    cli_out(cli,  "SP-Stats Ptr.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_aclqos_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");
    cli_out(cli, " %-3x", resp->dsaclqos.acl_log_id);
    cli_out(cli, " %-3x", resp->dsaclqos.color);
    cli_out(cli, " %-3x", resp->dsaclqos.deny_bridge);
    cli_out(cli, " %-3x", resp->dsaclqos.deny_learning);
    cli_out(cli, " %-3x", resp->dsaclqos.stats_mode);
    cli_out(cli, " %-3x", resp->dsaclqos.deny_route);
    cli_out(cli, " %-3x", resp->dsaclqos.discard_packet);
    cli_out(cli, " %-3x", resp->dsaclqos.flow_policer_ptr);
    cli_out(cli, " %-3x", resp->dsaclqos.fwd_ptr);
    cli_out(cli, " %-3x", resp->dsaclqos.deny_replace_dscp);
    cli_out(cli, " %-3x", resp->dsaclqos.deny_replace_cos);
    cli_out(cli, " %-3x", resp->dsaclqos.priority_valid);
    cli_out(cli, " %-3x", resp->dsaclqos.qos_policy);
    cli_out(cli, " %-3x", resp->dsaclqos.random_log_en);
    cli_out(cli, " %-3x", resp->dsaclqos.random_threshold_shift);
    cli_out(cli, " %-3x", resp->dsaclqos.stats_ptr);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_aclqos( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_aclqos_head_explain(cli);
    }
    _diag_show_sram_aclqos_head( cli );
    _diag_show_sram_aclqos_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_usrid_head(struct cli *cli)
{
    cli_out(cli, "%-5s" , " Ds");
    cli_out(cli, "%-5s" , "ASVD");
    cli_out(cli, "%-5s" , "UVP");
    cli_out(cli, "%-4s" , "EXE");
    cli_out(cli, "%-4s" , "BAl");
    cli_out(cli, "%-4s" , "BDE");
    cli_out(cli, "%-4s" , "SCP");
    cli_out(cli, "%-4s" , "FPV");
    cli_out(cli, "%-4s" , "SQS");
    cli_out(cli, "%-4s" , "VPT");
    cli_out(cli, "%-5s" , "BDD");
    cli_out(cli, "%-4s" , "BMA");
    cli_out(cli, "%-4s" , "BD");    
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_usrid_head_explain(struct cli *cli)
{
    cli_out(cli,  " ASVD-Aps Select Valid,");
    cli_out(cli,  " UVP-User Vlan Ptr,");
    cli_out(cli,  " EXE-Exception En,");
    cli_out(cli, " \n");
    cli_out(cli,  " BAl-By Pass All,");
    cli_out(cli,  " BDE-Binding En,");
    cli_out(cli,  " SCP-Src Communicate Port,");
    cli_out(cli,  " FPV-ds Fwd Ptr Valid,");
    cli_out(cli,  " SQS-Src Queue Select,");
    cli_out(cli, " \n");
    cli_out(cli,  " VPT-Vpls Port Type,");
    cli_out(cli,  " BDD-Binding Datam,");
    cli_out(cli,  " BMA-Binding MAc Sa,");
    cli_out(cli,  " BD-Binding Data,");
    cli_out(cli, " \n\n");
}
static void
_diag_show_sram_usrid_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, " %-4d" , resp->usr_id.aps_select_valid);
    cli_out(cli, " %-3d" , resp->usr_id.user_vlan_ptr);
    cli_out(cli, " %-3d" , resp->usr_id.exception_en);
    cli_out(cli, " %-3d" , resp->usr_id.by_pass_all);
    cli_out(cli, " %-3d" , resp->usr_id.binding_en);
    cli_out(cli, " %-3d" , resp->usr_id.src_communicate_port);
    cli_out(cli, " %-3d" , resp->usr_id.ds_fwd_ptr_valid);
    cli_out(cli, " %-3d" , resp->usr_id.src_queue_select);
    cli_out(cli, " %-3d" , resp->usr_id.vpls_port_type);
    cli_out(cli, " %-3d" , resp->usr_id.binding_datam);
    cli_out(cli, " %-3d" , resp->usr_id.binding_mac_sa);
    cli_out(cli, " %.04hx" , resp->usr_id.binding_datah);
    cli_out(cli, " %.08hx" , resp->usr_id.binding_datal);
    cli_out(cli, " \n");
}

static int32 
_diag_show_sram_usrid( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_usrid_head_explain(cli);
    }
    _diag_show_sram_usrid_head( cli );
    _diag_show_sram_usrid_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_stp_state_head(struct cli *cli)
{
    cli_out(cli, "%-10s"," STPstate");   
    cli_out(cli, "%-4s" , "state");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_stp_state_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");
    cli_out(cli, " %-3x", resp->stp_state.stpstate);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_stp_state( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }

    _diag_show_sram_stp_state_head( cli );
    _diag_show_sram_stp_state_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_vlan_status_head(struct cli *cli)
{
    cli_out(cli, "%-12s"," VLANstatus");   
    cli_out(cli, "%-13s" , "VLAN-Valid-h");
    cli_out(cli, "%-13s" , "VLAN-Valid-l");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_vlan_status_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%11s" , "");
    cli_out(cli, " %-12x", resp->vlan_status.vlanid_validh);
    cli_out(cli, " %-12x", resp->vlan_status.vlanid_validl);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_vlan_status( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    _diag_show_sram_vlan_status_head( cli );
    _diag_show_sram_vlan_status_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_policer_head(struct cli *cli)
{
    cli_out(cli, "%-9s"," Policer");   
    cli_out(cli, "%-4s" , "CBM");
    cli_out(cli, "%-4s" , "CDC");
    cli_out(cli, "%-8s" , "CC");
    cli_out(cli, "%-4s" , "OT");
    cli_out(cli, "%-8s" , "PC");
    cli_out(cli, "%-4s" , "PE");
    cli_out(cli, "%-4s" , "PR");
    cli_out(cli, "%-4s" , "STM");
    cli_out(cli, "%-4s" , "UL");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_policer_head_explain(struct cli *cli)
{
    cli_out(cli," Policer, ");   
    cli_out(cli , "CBM-Color Blind Mode, ");
    cli_out(cli , "CDC-Color Drop Code, ");
    cli_out(cli , "CC-Commit Count, ");
    cli_out(cli , "OT-OLd Ts, ");
    cli_out(cli , "PC-Peak Count, ");
    cli_out(cli , "PE-Policer Enable, ");
    cli_out(cli , "PR-Profile, ");
    cli_out(cli , "STM-Sr TCM Mode, ");
    cli_out(cli , "UL-Use Layer3 Length.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_policer_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , "");
    cli_out(cli, " %-3x", resp->policer.color_blind_mode);
    cli_out(cli, " %-3x", resp->policer.color_drop_code);
    cli_out(cli, " %-7x", resp->policer.commit_count_upper + ((resp->policer.commit_count_lower ) &0x0FFF));
    cli_out(cli, " %-3x", resp->policer.old_ts);
    cli_out(cli, " %-7x", resp->policer.peak_count);
    cli_out(cli, " %-3x", resp->policer.stats_en);
    cli_out(cli, " %-3x", resp->policer.profile);
    cli_out(cli, " %-3x", resp->policer.sr_tcm_mode);
    cli_out(cli, " %-3x", resp->policer.use_layer3_length);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_policer( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_policer_head_explain(cli);
    }
    _diag_show_sram_policer_head( cli );
    _diag_show_sram_policer_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl2edit_eth4w_head_explain(struct cli *cli)
{
    cli_out(cli,  " DSL2Edit-eth4w, ");
    cli_out(cli, "DM-Derive Mcast Mac, ");
    cli_out(cli, "OET-Overwrite Ether Type, ");
    cli_out(cli, "TYPE");
    cli_out(cli, " \n"); 
    cli_out(cli, "PT-Packet Type, ");
    cli_out(cli, "OVI-OutPut VLAN ID ");
    cli_out(cli, "OVV-Out Put VLANID Valid, ");
    cli_out(cli, "OCV-Output Cvlanid Valid, ");
    cli_out(cli, "OVV-Output Vlanid s Svlan, ");
    cli_out(cli, "MSV-Mac SA Valid, ");
    cli_out(cli,  "MACDA");    
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dsl2edit_eth4w_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " Eth4w");
    cli_out(cli, "%-3s" , "DM");
    cli_out(cli, "%-4s" , "OET");
    cli_out(cli, "%-5s" , "TYPE");
    cli_out(cli, "%-3s" , "PT");
    cli_out(cli, "%-4s" , "OVI");
    cli_out(cli, "%-4s" , "OVV");
    cli_out(cli, "%-4s" , "OCV");
    cli_out(cli, "%-4s" , "OVV");
    cli_out(cli, "%-4s" , "MSV");
    cli_out(cli, "%-17s" , "MACDA");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dsl2edit_eth4w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%6s" , "");
    cli_out(cli, " %-2x", resp->eth4w.derive_mcast_mac);
    cli_out(cli, " %-3x", resp->eth4w.overwrite_ether_type);    
    cli_out(cli, " %-4x", resp->eth4w.type);
    cli_out(cli, " %-2x", resp->eth4w.packet_type);
    cli_out(cli, " %-3x", resp->eth4w.output_vlan_id);
    cli_out(cli, " %-3x", resp->eth4w.output_vlan_id_valid);
    cli_out(cli, " %-3x", resp->eth4w.output_cvlanid_valid);
    cli_out(cli, " %-3x", resp->eth4w.output_vlanid_is_svlan);
    cli_out(cli, " %-3x", resp->eth4w.mac_sa_valid);
    cli_out(cli, " %04hx.", resp->eth4w.mac_dah);
    cli_out(cli, " %04hx.", resp->eth4w.mac_dal>>16);
    cli_out(cli, " %04hx", resp->eth4w.mac_dal  & 0xffff);
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_l2edit_eth4w( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl2edit_eth4w_head_explain(cli);
    }
    _diag_show_sram_dsl2edit_eth4w_head( cli );
    _diag_show_sram_dsl2edit_eth4w_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl2edit_eth8w_head_explain(struct cli *cli)
{
    cli_out(cli,  "DSL2Edit-eth8w, ");
    cli_out(cli, "DMM-DeriveMcast Mac, ");
    cli_out(cli, "OWT-Overwrite Ether Type, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "PT-Packet Type, ");
    cli_out(cli, "VID-output VLAN ID, ");
    cli_out(cli, "VIDV-output VLAN ID Valid, ");
    cli_out(cli, "MSV-MAC SA Valid, ");
    cli_out(cli, " \n"); 
}
static void 
_diag_show_sram_dsl2edit_eth8w_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " Eth8w");
    cli_out(cli, "%-4s" , "DMM");
    cli_out(cli, "%-4s" , "OWT");
    cli_out(cli, "%-5s" , "Type");
    cli_out(cli, "%-3s" , "PT");
    cli_out(cli, "%-4s" , "VID");
    cli_out(cli, "%-5s" , "VIDV");
    cli_out(cli, "%-4s" , "MSV");
    cli_out(cli, "%-17s" , "MACDA");
    cli_out(cli, "%-17s" , "MACSA");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsl2edit_eth8w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%6s" , "");
    cli_out(cli, " %-3x", resp->eth8w.derive_mcast_mac);
    cli_out(cli, " %-3x", resp->eth8w.overwrite_ether_type);
    cli_out(cli, " %-4x", resp->eth8w.type);
    cli_out(cli, " %-2x", resp->eth8w.packet_type);
    cli_out(cli, " %-3x", resp->eth8w.output_vlan_id_valid);
    cli_out(cli, " %-4x", resp->eth8w.output_cvlan_id_valid);
    cli_out(cli, " %-3x", resp->eth8w.mac_sa_valid);
    cli_out(cli, " %.04hx.", resp->eth8w.mac_dah);
    cli_out(cli, " %.04hx.", resp->eth8w.mac_dal>>16);
    cli_out(cli, " %.04hx", resp->eth8w.mac_dal& 0xffff);
    cli_out(cli, " %.04hx.", resp->eth8w.mac_sah);
    cli_out(cli, " %.04hx.", resp->eth8w.mac_sal>>16);
    cli_out(cli, " %.04hx", resp->eth8w.mac_sal& 0xffff);
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_l2edit_eth8w( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl2edit_eth8w_head_explain(cli);
    }
    _diag_show_sram_dsl2edit_eth8w_head( cli );
    _diag_show_sram_dsl2edit_eth8w_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_strom_ctl_head(struct cli *cli)
{
    cli_out(cli, "%-10s"," StormCTL");   
    cli_out(cli, "%-4s" , "SE");
    cli_out(cli, "%-9s" , "RC");
    cli_out(cli, "%-9s" , "TS");
    cli_out(cli, "%-4s" , "EE");
    cli_out(cli, "%-4s" , "UC");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_strom_ctl_head_explain(struct cli *cli)
{
    cli_out(cli," StormCTL, ");   
    cli_out(cli, "SE-Storm En, ");
    cli_out(cli, "RC-Running Count, ");
    cli_out(cli, "TS-Threshold,");
    cli_out(cli, "EE-Exception En, ");
    cli_out(cli, "UC-Usepacket Count.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_strom_ctl_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");
    cli_out(cli, " %-3x", resp->dsstm_ctl.storm_en);
    cli_out(cli, " %-8x", resp->dsstm_ctl.running_count);
    cli_out(cli, " %-8x", resp->dsstm_ctl.threshold);
    cli_out(cli, " %-3x", resp->dsstm_ctl.exception_en);
    cli_out(cli, " %-3x", resp->dsstm_ctl.use_packet_count);

    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_storm_ctl( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_strom_ctl_head_explain(cli);
    }
    _diag_show_sram_strom_ctl_head( cli );
    _diag_show_sram_strom_ctl_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_aging_head(struct cli *cli )
{
    cli_out(cli, "%-9s" , " dsaging");
    cli_out(cli, "%-9s" , " aging-status");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_aging_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");
    cli_out(cli, " %-8x", resp->dsaging.aging_status);
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_aging( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }

    _diag_show_sram_aging_head( cli );
    _diag_show_sram_aging_entry( cli, resp );
    return CLI_SUCCESS;
}

static void
_diag_show_sram_policer_profile_head(struct cli *cli)
{
    cli_out(cli, "%-12s"," Policerpro");   
    cli_out(cli, "%-5s" , "CR");
    cli_out(cli, "%-4s" , "CT");
    cli_out(cli, "%-4s" , "CTS");
    cli_out(cli, "%-5s" , "PR");
    cli_out(cli, "%-4s" , "PT");
    cli_out(cli, "%-4s" , "PTS");
    cli_out(cli, "%-4s" , "TTS");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_policer_profile_head_explain(struct cli *cli)
{
    cli_out(cli," Policerpro, ");   
    cli_out(cli, "CR-Commit Rate, ");
    cli_out(cli, "CT-Commit Threshold, ");
    cli_out(cli, "CTS-Commit Threshold Shift, ");
    cli_out(cli, "PR-Peak Rate, ");
    cli_out(cli, "PT-Peak Threshold, ");
    cli_out(cli, "PTS-Peak Threshold Shift, ");
    cli_out(cli, "TTS-Ts Tick Shift.");
    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_policer_profile_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%11s" , "");
    cli_out(cli, " %-4x", resp->policer_profile.commit_rate);
    cli_out(cli, " %-3x", resp->policer_profile.commit_threshold);
    cli_out(cli, " %-3x", resp->policer_profile.commit_threshold_shift);
    cli_out(cli, " %-4x", resp->policer_profile.peak_rate);
    cli_out(cli, " %-3x", resp->policer_profile.peak_threshold);
    cli_out(cli, " %-3x", resp->policer_profile.peak_threshold_shift);
    cli_out(cli, " %-3x", resp->policer_profile.ts_tick_shift);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_policer_profile( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_policer_profile_head_explain(cli);
    }
    _diag_show_sram_policer_profile_head( cli );
    _diag_show_sram_policer_profile_entry( cli, resp );
    return CLI_SUCCESS;
}

void
_diag_show_sram_src_vlan_head_explain(struct cli *cli )
{
    cli_out(cli, " \n");     
    cli_out(cli,  "DSSrcVLAN, ");   
    cli_out(cli, "4UT-v4 Ucast Type, ");
    cli_out(cli, "4UE-v4 Ucast En, ");
    cli_out(cli, "4ME-v4 Mcast En, ");
    cli_out(cli, "6UT-v6 Ucast Type, ");
    cli_out(cli, "6UE-v6 Ucast En, ");
    cli_out(cli, "6ME-v6 Mcast En, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "StpID-Stp instance ID ");
    cli_out(cli, "ISE-IGMP Snoop En, ");
    cli_out(cli, "REE-Receive En, ");

    cli_out(cli, "EEO-Egress Oam valid, ");
    cli_out(cli, "EML-egress Md Lev, ");
    cli_out(cli, "ETO-ether_oamv, ");
    cli_out(cli, "LED-learn_dis, ");
    cli_out(cli, "MDL-md_level, ");
    cli_out (cli, " \n");     

    cli_out(cli, "SQS-src_que_select,");
    cli_out(cli, "DET-dhcp_exception_type,");
    cli_out(cli, "AET-arp_exception_type");
    cli_out(cli, "SVD-mac_sec_vlan_dis ");
    cli_out(cli, "BRD-brg_dis,");
    cli_out(cli, " \n");     

    cli_out(cli, "SEE-vlan_sec_exp_en,");
    cli_out(cli, "VCC-vlan_cross_connect,");
    cli_out(cli, "RPD-replace_dscp,");
    cli_out(cli, "TRE-trans_en,");
    cli_out(cli, "PRM-pfm,");

    cli_out(cli, "RDS-route_disable,");
    cli_out(cli, "VRF-Vrf id,");
    cli_out(cli, "IID-if id,");
    cli_out(cli, " \n");     
    cli_out(cli, " \n");     
}

static void
_diag_show_sram_src_vlan_head_1_line(struct cli *cli)
{
    cli_out(cli, "%-11s"," DSSrcVLAN");   

    cli_out(cli, "%-4s" , "4UT");
    cli_out(cli, "%-4s" , "4UE");
    cli_out(cli, "%-4s" , "4ME");
    
    cli_out(cli, "%-4s" , "6UT");
    cli_out(cli, "%-4s" , "6UE");
    cli_out(cli, "%-4s" , "6ME");
    cli_out(cli, "%-6s" , "StpID");
    cli_out(cli, "%-4s" , "ISE");
    cli_out(cli, "%-4s" , "REE");

    cli_out(cli, "%-4s" , "EEO");
    cli_out(cli, "%-4s" , "EML");
    cli_out(cli, "%-4s" , "ETO");
    cli_out(cli, "%-4s" , "LED");
    cli_out(cli, "%-4s" , "MDL");
    
    cli_out(cli, "%-4s" , "SQS");
    cli_out(cli, "%-4s" , "DET");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_src_vlan_head_2_line(struct cli *cli)
{
    cli_out(cli, "%-11s"," ");   
    cli_out(cli, "%-4s" , "AET");
    cli_out(cli, "%-4s" , "SVD");
    cli_out(cli, "%-4s" , "BRD");
    cli_out(cli, "%-4s" , "SEE");
    cli_out(cli, "%-4s" , "VCC");
    cli_out(cli, "%-4s" , "RPD");
    cli_out(cli, "%-4s" , "TRE");
    cli_out(cli, "%-4s" , "PFM");
    cli_out(cli, "%-4s" , "RDS");
    cli_out(cli, "%-4s" , "VRF");
    cli_out(cli, "%-4s" , "IID");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_src_vlan_entry_1_line(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%10s" , "");

    cli_out(cli, " %-3x", resp->ds_vlan.v4_ucast_sa_type);
    cli_out(cli, " %-3x", resp->ds_vlan.v4_ucast_en);
    cli_out(cli, " %-3x", resp->ds_vlan.v4_mcast_en);
    
    cli_out(cli, " %-3x", resp->ds_vlan.v6_ucast_sa_type);
    cli_out(cli, " %-3x", resp->ds_vlan.v6_ucast_en);
    cli_out(cli, " %-3x", resp->ds_vlan.v6_mcast_en);
    cli_out(cli, " %-5x", resp->ds_vlan.stp_id);
    cli_out(cli, " %-3x", resp->ds_vlan.igmp_snoop_en);
    cli_out(cli, " %-3x", resp->ds_vlan.rec_en); 

    cli_out(cli, " %-3x", resp->ds_vlan.e_ether_oamv);
    cli_out(cli, " %-3x", resp->ds_vlan.e_md_level); 
    cli_out(cli, " %-3x", resp->ds_vlan.ether_oamv); 
    cli_out(cli, " %-3x", resp->ds_vlan.learn_dis);
    cli_out(cli, " %-3x", resp->ds_vlan.md_level);

    cli_out(cli, " %-3x", resp->ds_vlan.src_que_select);
    cli_out(cli, " %-3x", resp->ds_vlan.dhcp_exception_type);
        
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_src_vlan_entry_2_line(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%10s" , "");    
    cli_out(cli, " %-3x", resp->ds_vlan.arp_exception_type);
    cli_out(cli, " %-3x", resp->ds_vlan.mac_sec_vlan_dis);
    cli_out(cli, " %-3x", resp->ds_vlan.brg_dis); 
    
    cli_out(cli, " %-3x", resp->ds_vlan.vlan_sec_exp_en);
    cli_out(cli, " %-3x", resp->ds_vlan.vlan_cross_connect);
    cli_out(cli, " %-3x", resp->ds_vlan.replace_dscp);
    cli_out(cli, " %-3x", resp->ds_vlan.trans_en);
    cli_out(cli, " %-3x", resp->ds_vlan.pfm);
    
    cli_out(cli, " %-3x", resp->ds_vlan.route_disable);
    cli_out(cli, " %-3x", resp->ds_vlan.vrf_id);
    cli_out(cli, " %-3x", resp->ds_vlan.if_id);
        
    cli_out(cli, " \n"); 
}

static int32 
_diag_show_sram_src_vlan( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_src_vlan_head_explain(cli);
    }
    _diag_show_sram_src_vlan_head_1_line( cli );
    _diag_show_sram_src_vlan_entry_1_line( cli, resp );
    _diag_show_sram_src_vlan_head_2_line( cli );
    _diag_show_sram_src_vlan_entry_2_line( cli, resp );

    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl3edit_mpls4w_head_explain(struct cli *cli)
{
    cli_out(cli,  " DSL3Edit-mpls4w, ");

    cli_out(cli, "LV1-Label Valid1, ");
    cli_out(cli, "ML1-Mcast Label1, ");

    cli_out(cli, "MEV-Martini Encap Valid, ");
    cli_out(cli, "ML0-Mcast Lable0, ");
    cli_out(cli, "MT0-Map TTL0, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "DE0-Derive_Exp0, ");
    cli_out(cli, "EP0-Exp0, ");
    cli_out(cli, "TTL0-Ttl0, ");
    cli_out(cli, "Lal0-Lable0");
    cli_out(cli, "MT1-MAP TTL1, ");
    cli_out (cli, " \n"); 
    cli_out(cli, "DE1-Derive Exp1,");
    cli_out(cli, "EP1-Exp1, ");
    cli_out(cli, "TTL1-Ttl1, ");
    cli_out(cli, "Lal1-Lable1");
    cli_out (cli, " \n"); 
}
static void 
_diag_show_sram_dsl3edit_mpls4w_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " MPLS4W");

    cli_out(cli, "%-4s" , "LV1");
    cli_out(cli, "%-4s" , "ML1");

    cli_out(cli, "%-4s" , "MEV");
    cli_out(cli, "%-4s" , "ML0");
    cli_out(cli, "%-4s" , "MT0");
    cli_out(cli, "%-4s" , "DE0");
    cli_out(cli, "%-4s" , "EP0");
    cli_out(cli, "%-5s" , "TTL0");
    cli_out(cli, "%-5s" , "Lal0");
    cli_out(cli, "%-4s" , "MT1");
    cli_out(cli, "%-4s" , "DE1");
    cli_out(cli, "%-4s" , "EP1");
    cli_out(cli, "%-5s" , "TTL1");
    cli_out(cli, "%-5s" , "LaL1");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dsl3edit_mpls4w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->mpls4w.label_valid1);
    cli_out(cli, " %-3x", resp->mpls4w.mcast_label1);

    cli_out(cli, " %-3x", resp->mpls4w.martini_encap_valid);
    cli_out(cli, " %-3x", resp->mpls4w.mcast_label0);
    cli_out(cli, " %-3x", resp->mpls4w.map_ttl0);
    cli_out(cli, " %-3x", resp->mpls4w.derive_exp0);
    cli_out(cli, " %-3x", resp->mpls4w.exp0);
    cli_out(cli, " %-4x", resp->mpls4w.ttl0);
    cli_out(cli, " %-4x", resp->mpls4w.label0);
    cli_out(cli, " %-3x", resp->mpls4w.map_ttl1);
    cli_out(cli, " %-3x", resp->mpls4w.derive_exp1);
    cli_out(cli, " %-3x", resp->mpls4w.exp1);
    cli_out(cli, " %-4x", resp->mpls4w.ttl1);
    cli_out(cli, " %-4x", resp->mpls4w.label1);
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_l3edit_mpls4w( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl3edit_mpls4w_head_explain(cli);
    }
    _diag_show_sram_dsl3edit_mpls4w_head( cli );
    _diag_show_sram_dsl3edit_mpls4w_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl3edit_mpls8w_head_explain(struct cli *cli)
{
    cli_out(cli," DSL3Edit-mpls8w, ");

    cli_out(cli, "EXP0-exp0, ");
    cli_out(cli, "DEP0-derive_exp0, ");
    cli_out(cli, "TTL0-ttl0, ");
    cli_out(cli, "MTL0-map_ttl0, ");
    cli_out(cli, "LBV1-label_valid1, ");
    cli_out(cli, "MCL0-mcast_label0, ");

    cli_out(cli, "Lbl0-Lable0, ");
    cli_out(cli, " \n"); 
}
static void 
_diag_show_sram_dsl3edit_mpls8w_head(struct cli *cli)
{
    cli_out(cli, "%-8s"," MPLS8w");
    cli_out(cli, "%-5s" , "EXP0");
    cli_out(cli, "%-5s" , "EXP1");
    cli_out(cli, "%-5s" , "EXP2");
    cli_out(cli, "%-5s" , "EXP3");

    cli_out(cli, "%-5s" , "DEP0");
    cli_out(cli, "%-5s" , "DEP1");
    cli_out(cli, "%-5s" , "DEP2");
    cli_out(cli, "%-5s" , "DEP3");

    cli_out(cli, "%-5s" , "TTL0");
    cli_out(cli, "%-5s" , "TTL1");
    cli_out(cli, "%-5s" , "TTL2");
    cli_out(cli, "%-5s" , "TTL3");

    cli_out(cli, "%-5s" , "MTL0");
    cli_out(cli, "%-5s" , "MTL1");
    cli_out(cli, "%-5s" , "MTL2");
    cli_out(cli, "%-5s" , "MTL3");

    cli_out(cli, "%-5s" , "LBV1");
    cli_out(cli, "%-5s" , "LBV2");
    cli_out(cli, "%-5s" , "LBV3");
    cli_out(cli, "%-5s" , "MCL0");
    cli_out(cli, "%-5s" , "MCL1");
    cli_out(cli, "%-5s" , "MCL2");
    cli_out(cli, "%-5s" , "MCL3");

    cli_out(cli, "%-5s" , "Lbl0");
    cli_out(cli, "%-5s" , "Lbl1");
    cli_out(cli, "%-5s" , "Lbl2");
    cli_out(cli, "%-5s" , "Lbl3");

    cli_out(cli, " \n"); 
}
static void
_diag_show_sram_dsl3edit_mpls8w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-4x", resp->mpls8w.exp0);
    cli_out(cli, " %-4x", resp->mpls8w.exp1);
    cli_out(cli, " %-4x", resp->mpls8w.exp2);
    cli_out(cli, " %-4x", resp->mpls8w.exp3);

    cli_out(cli, " %-4x", resp->mpls8w.derive_exp0);
    cli_out(cli, " %-4x", resp->mpls8w.derive_exp1);
    cli_out(cli, " %-4x", resp->mpls8w.derive_exp2);
    cli_out(cli, " %-4x", resp->mpls8w.derive_exp3);

    cli_out(cli, " %-4x", resp->mpls8w.ttl0);
    cli_out(cli, " %-4x", resp->mpls8w.ttl1);
    cli_out(cli, " %-4x", resp->mpls8w.ttl2);
    cli_out(cli, " %-4x", resp->mpls8w.ttl3);

    cli_out(cli, " %-4x", resp->mpls8w.map_ttl0);
    cli_out(cli, " %-4x", resp->mpls8w.map_ttl1);
    cli_out(cli, " %-4x", resp->mpls8w.map_ttl2);
    cli_out(cli, " %-4x", resp->mpls8w.map_ttl3);

    cli_out(cli, " %-4x", resp->mpls8w.label_valid1);
    cli_out(cli, " %-4x", resp->mpls8w.label_valid2);
    cli_out(cli, " %-4x", resp->mpls8w.label_valid3);
    
    cli_out(cli, " %-4x", resp->mpls8w.mcast_label0);
    cli_out(cli, " %-4x", resp->mpls8w.mcast_label1);
    cli_out(cli, " %-4x", resp->mpls8w.mcast_label2);
    cli_out(cli, " %-4x", resp->mpls8w.mcast_label3);

    cli_out(cli, " %-4x", resp->mpls8w.label0);
    cli_out(cli, " %-4x", resp->mpls8w.label1);
    cli_out(cli, " %-4x", resp->mpls8w.label2);
    cli_out(cli, " %-4x", resp->mpls8w.label3);

    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_l3edit_mpls8w( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl3edit_mpls8w_head_explain(cli);
    }
    _diag_show_sram_dsl3edit_mpls8w_head( cli );
    _diag_show_sram_dsl3edit_mpls8w_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dsl2edit_lookback_head_explain(struct cli *cli)
{
    cli_out(cli, " DSL2Edit-lookback, ");
    cli_out(cli,"LAT-Lb Length Adjust Type, ");
    cli_out(cli,"NHE-Lb Next Hop Ext, ");
    cli_out(cli, " \n"); 

    cli_out(cli,"DM-Mapped Destination, ");
    cli_out(cli,"NHP-Next Hop Ptr.");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dsl2edit_lookback_head(struct cli *cli)
{
    cli_out(cli, "%-10s" , " Lookback");
    cli_out(cli, "%-4s" , "LAT");
    cli_out(cli, "%-4s" , "NHE");

    cli_out(cli, "%-7s" , "DM");
    cli_out(cli, "%-6s" , "NHP");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dsl2edit_lookback_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");
    cli_out(cli, " %-3x", resp->lookback.lb_length_adjust_type);
    cli_out(cli, " %-3x", resp->lookback.lb_next_hop_ext);

    cli_out(cli, " %-6x", resp->lookback.lb_dest_map);
    cli_out(cli, " %-5x", resp->lookback.lb_next_hop_ptr);
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_l2edit_lookback( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dsl2edit_lookback_head_explain(cli);
    }
    _diag_show_sram_dsl2edit_lookback_head( cli );
    _diag_show_sram_dsl2edit_lookback_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_phy_port_ext_head_explain(struct cli *cli)
{
    cli_out(cli,"EUT-egress_user_id_type, ");
    cli_out(cli,"EUE-egress_user_id_en, ");
    cli_out(cli,"SKF-svlan_key_first, ");
    cli_out(cli,"OUI-oam_obey_user_id, ");
    cli_out(cli,"OVS-src_outer_vlan_is_svlan, ");
    cli_out(cli,"DVL-use_default_vlan_lookup, ");
    cli_out(cli,"UIE-user_id_en, ");
    cli_out(cli,"UIT-user_id_type, ");
    cli_out(cli,"UIL-user_id_label, ");
    cli_out(cli,"GSP-global_src_port, ");
    cli_out(cli,"UI4-disable_user_id_ipv4, ");
    cli_out(cli,"UI6-disable_user_id_ipv6, ");
    cli_out(cli,"TMK4-force_user_id_ipv4_to_mac_key, ");
    cli_out(cli,"TMK6-force_user_id_ipv6_to_mac_key, ");
    cli_out(cli,"DVI-default_vlan_id, ");
    cli_out(cli,"DDI-default_dei, ");
    cli_out(cli,"DPP-default_pcp, ");
    cli_out(cli,"E2E-exception2_en, ");
    cli_out(cli,"E2D-exception2_discard, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_phy_port_ext_head(struct cli *cli)
{
    cli_out(cli, "%-14s" , " phy-port-ext");
    cli_out(cli, "%-4s" , "EUT");
    cli_out(cli, "%-4s" , "EUE");
    cli_out(cli, "%-4s" , "SKF");
    cli_out(cli, "%-4s" , "OUI");
    cli_out(cli, "%-4s" , "OVS");
    cli_out(cli, "%-4s" , "DVL");
    cli_out(cli, "%-4s" , "UIE");
    cli_out(cli, "%-4s" , "UIT");
    cli_out(cli, "%-4s" , "UIL");
    cli_out(cli, "%-4s" , "GSP");
    cli_out(cli, "%-4s" , "UI4");
    cli_out(cli, "%-4s" , "UI6");
    cli_out(cli, "%-4s" , "TMK4");
    cli_out(cli, "%-4s" , "TMK6");
    cli_out(cli, "%-4s" , "DVI");
    cli_out(cli, "%-4s" , "DDI");
    cli_out(cli, "%-4s" , "DPP");
    cli_out(cli, "%-4s" , "E2E");
    cli_out(cli, "%-4s" , "E2D");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_phy_port_ext_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%13s" , " ");
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.egress_user_id_type);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.egress_user_id_en);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.svlan_key_first);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.oam_obey_user_id);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.src_outer_vlan_is_svlan);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.use_default_vlan_lookup);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.user_id_en);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.user_id_type);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.user_id_label);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.global_src_port);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.disable_user_id_ipv4);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.disable_user_id_ipv6);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.force_user_id_ipv4_to_mac_key);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.force_user_id_ipv6_to_mac_key);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.default_vlan_id);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.default_dei);
    cli_out(cli, " %-3x", resp->ds_phy_port_ext_t.default_pcp);
    cli_out(cli, " %-4x", resp->ds_phy_port_ext_t.exception2_en);
    cli_out(cli, " %-4x", resp->ds_phy_port_ext_t.exception2_discard);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_phy_port_ext( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_phy_port_ext_head_explain(cli);
    }
    _diag_show_sram_phy_port_ext_head( cli );
    _diag_show_sram_phy_port_ext_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_mpls_ctl_head_explain(struct cli *cli)
{
    cli_out(cli,"LVM-interface_label_valid_mcast, ");
    cli_out(cli,"NLM-num_of_label_mcast, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"STM-label_space_sizetype_mcast, ");
    cli_out(cli,"LBM-label_base_mcast, ");
    cli_out(cli,"ILV-interface_label_valid, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"NL-num_of_label, ");
    cli_out(cli,"LSS-label_space_sizetype, ");
    cli_out(cli,"LB-label_base, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_mpls_ctl_head(struct cli *cli)
{
    cli_out(cli, "%-10s" , " mpls-ctl");
    cli_out(cli, "%-4s" , "LVM");
    cli_out(cli, "%-4s" , "NLM");
    cli_out(cli, "%-4s" , "STM");
    cli_out(cli, "%-4s" , "LBM");
    cli_out(cli, "%-4s" , "ILV");
    cli_out(cli, "%-4s" , "NL");
    cli_out(cli, "%-4s" , "LSS");
    cli_out(cli, "%-4s" , "LB");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_mpls_ctl_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , " ");
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.interface_label_valid_mcast);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.num_of_label_mcast);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.label_space_sizetype_mcast);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.label_base_mcast);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.interface_label_valid);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.num_of_label);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.label_space_sizetype);
    cli_out(cli, " %-3x", resp->ds_mpls_ctl_t.label_base);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_mpls_ctl( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_mpls_ctl_head_explain(cli);
    }
    _diag_show_sram_mpls_ctl_head( cli );
    _diag_show_sram_mpls_ctl_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_aps_bri_tbl_head_explain(struct cli *cli)
{
    cli_out(cli,"PTE-protecting_en, ");
    cli_out(cli,"WDM-working_dest_map, ");
    cli_out(cli,"PDM-protecting_dest_map, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_aps_bri_tbl_head(struct cli *cli)
{
    cli_out(cli, "%-9s" , " app-bri");
    cli_out(cli, "%-4s" , "PTE");
    cli_out(cli, "%-4s" , "WDM");
    cli_out(cli, "%-4s" , "PDM");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_aps_bri_tbl_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , " ");
    cli_out(cli, " %-3x", resp->apsbridgetable_t.protecting_en);
    cli_out(cli, " %-3x", resp->apsbridgetable_t.working_dest_map);
    cli_out(cli, " %-3x", resp->apsbridgetable_t.protecting_dest_map);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_aps_bri_tbl( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_aps_bri_tbl_head_explain(cli);
    }
    _diag_show_sram_aps_bri_tbl_head( cli );
    _diag_show_sram_aps_bri_tbl_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_aps_sel_tbl_head_explain(struct cli *cli)
{
    cli_out(cli,"en0-protecting_en0, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_aps_sel_tbl_head_top(struct cli *cli)
{
    cli_out(cli, "%-5s" , "en0");
    cli_out(cli, "%-5s" , "en1");
    cli_out(cli, "%-5s" , "en2");
    cli_out(cli, "%-5s" , "en3");
    cli_out(cli, "%-5s" , "en4");
    cli_out(cli, "%-5s" , "en5");
    cli_out(cli, "%-5s" , "en6");
    cli_out(cli, "%-5s" , "en7");
    cli_out(cli, "%-5s" , "en8");
    cli_out(cli, "%-5s" , "en9");
    cli_out(cli, "%-5s" , "en10");
    cli_out(cli, "%-5s" , "en11");
    cli_out(cli, "%-5s" , "en12");
    cli_out(cli, "%-5s" , "en13");
    cli_out(cli, "%-5s" , "en14");
    cli_out(cli, "%-5s" , "en15");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_aps_sel_tbl_entry_top(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en0);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en1);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en2);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en3);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en4);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en5);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en6);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en7);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en8);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en9);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en10);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en11);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en12);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en13);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en14);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en15);
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_aps_sel_tbl_head_tail(struct cli *cli)
{
    cli_out(cli, "%-5s" , "en16");
    cli_out(cli, "%-5s" , "en17");
    cli_out(cli, "%-5s" , "en18");
    cli_out(cli, "%-5s" , "en19");
    cli_out(cli, "%-5s" , "en20");
    cli_out(cli, "%-5s" , "en21");
    cli_out(cli, "%-5s" , "en22");
    cli_out(cli, "%-5s" , "en23");
    cli_out(cli, "%-5s" , "en24");
    cli_out(cli, "%-5s" , "en25");
    cli_out(cli, "%-5s" , "en26");
    cli_out(cli, "%-5s" , "en27");
    cli_out(cli, "%-5s" , "en28");
    cli_out(cli, "%-5s" , "en29");
    cli_out(cli, "%-5s" , "en30");
    cli_out(cli, "%-5s" , "en31");
    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_aps_sel_tbl_entry_tail(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en16);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en17);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en18);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en19);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en20);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en21);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en22);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en23);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en24);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en25);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en26);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en27);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en28);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en29);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en30);
    cli_out(cli, " %-4x", resp->apsselecttable_t.protecting_en31);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_aps_sel_tbl( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_aps_sel_tbl_head_explain(cli);
    }
    _diag_show_sram_aps_sel_tbl_head_top( cli );
    _diag_show_sram_aps_sel_tbl_entry_top( cli, resp );
    _diag_show_sram_aps_sel_tbl_head_tail( cli );
    _diag_show_sram_aps_sel_tbl_entry_tail( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_fwd_ext_head_explain(struct cli *cli)
{
    cli_out(cli,"API-aps_group_id, ");
    cli_out(cli,"STP-stats_ptr, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_fwd_ext_head(struct cli *cli)
{
    cli_out(cli, "%-9s" , " fwd-ext");
    cli_out(cli, "%-5s" , "API");
    cli_out(cli, "%-5s" , "STP");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_fwd_ext_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%8s" , " ");
    cli_out(cli, " %-4x", resp->fwdexttable_t.aps_group_id);
    cli_out(cli, " %-4x", resp->fwdexttable_t.stats_ptr);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_fwd_ext( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_fwd_ext_head_explain(cli);
    }
    _diag_show_sram_fwd_ext_head( cli );
    _diag_show_sram_fwd_ext_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_link_agg_grp_head_explain(struct cli *cli)
{
    cli_out(cli,"EN-link_aggregate_group_en, ");
    cli_out(cli,"ID-link_aggregate_group_id, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_link_agg_grp_head(struct cli *cli)
{
    cli_out(cli, "%-14s" , " link-agg-grp");
    cli_out(cli, "%-5s" , "EN");
    cli_out(cli, "%-5s" , "ID");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_link_agg_grp_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%13s" , " ");
    cli_out(cli, " %-4x", resp->ds_link_aggreagation_group_t.link_aggregate_group_en);
    cli_out(cli, " %-4x", resp->ds_link_aggreagation_group_t.link_aggregate_group_id);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_link_agg_grp( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_link_agg_grp_head_explain(cli);
    }
    _diag_show_sram_link_agg_grp_head( cli );
    _diag_show_sram_link_agg_grp_entry( cli, resp );
    return CLI_SUCCESS;
}

void 
diag_show_sram_dsnh_8w_head_explain(struct cli *cli)
{
    cli_out(cli,"2RT-l2_rewrite_type, ");
    cli_out(cli,"SCF-stag_cfi, ");
    cli_out(cli,"SCS-stag_cos, ");
    cli_out(cli,"CCC-copy_ctag_cos, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"SVT-svlan_tagged, ");
    cli_out(cli,"CVT-cvlan_tagged, ");
    cli_out(cli,"MCE-mtu_check_en, ");
    cli_out(cli,"BPA-by_pass_all, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"PLO-payload_operation, ");
    cli_out(cli,"SIV-output_svlan_id_valid, ");
    cli_out(cli,"CIV-output_cvlan_id_valid, ");
    cli_out(cli,"3RT-l3_rewrite_type, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"RPD-replace_dscp, ");
    cli_out(cli,"RCC-replace_ctag_cos, ");
    cli_out(cli,"DSC-derive_stag_cos, ");
    cli_out(cli,"AQE-service_acl_qos_en, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"SPV-service_policer_valid, ");
    cli_out(cli,"TM-tagged_mode, ");
    cli_out(cli,"SVE-output_svlan_id_valid_ext, ");
    cli_out(cli,"CVE-output_cvlan_id_valid_ext, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"SIE-output_svlan_id_ext, ");
    cli_out(cli,"CIE-output_cvlan_id_ext, ");
    cli_out(cli,"VPC-vpls_port_check, ");
    cli_out(cli,"TMC-tunnel_mtu_check, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"SIE-service_id_en, ");
    cli_out(cli,"TUD-tunnel_update_disable, ");
    cli_out(cli,"CP-community_port, ");
    cli_out(cli,"ST-svlan_tpid, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"STE-svlan_tpid_en, ");
    cli_out(cli,"VDP-vpls_dest_port, ");
    cli_out(cli,"SI-service_id, ");
    cli_out(cli,"DVP-dest_vlan_ptr, ");
    cli_out(cli, " \n"); 

    cli_out(cli,"3EP-l3edit_ptr, ");
    cli_out(cli,"2EP-l2edit_ptr, ");

    cli_out(cli, " \n"); 
}

void 
diag_show_sram_dsnh_8w_head(struct cli *cli)
{
    cli_out(cli, "%-9s" , " dsnh-8w");
    cli_out(cli, "%-4s" , "2RT");
    cli_out(cli, "%-4s" , "SCF");
    cli_out(cli, "%-4s" , "SCS");
    cli_out(cli, "%-4s" , "CCC");
    cli_out(cli, "%-4s" , "SVT");
    cli_out(cli, "%-4s" , "CVT");
    cli_out(cli, "%-4s" , "MCE");
    cli_out(cli, "%-4s" , "BPA");
    cli_out(cli, "%-4s" , "PLO");
    cli_out(cli, "%-4s" , "SIV");
    cli_out(cli, "%-4s" , "CIV");
    cli_out(cli, "%-4s" , "3RT");
    cli_out(cli, "%-4s" , "RPD");
    cli_out(cli, "%-4s" , "RCC");
    cli_out(cli, "%-4s" , "DSC");
    cli_out(cli, "%-4s" , "AQE");
    cli_out(cli, "%-4s" , "SPV");

    cli_out(cli, "%-4s" , "TM");
    cli_out(cli, "%-4s" , "SVE");
    cli_out(cli, "%-4s" , "CVE");
    cli_out(cli, "%-4s" , "SIE");
    cli_out(cli, "%-4s" , "CIE");
    
    cli_out(cli, "%-4s" , "VPC");
    cli_out(cli, "%-4s" , "TMC");
    cli_out(cli, "%-4s" , "SIE");
    cli_out(cli, "%-4s" , "TUD");
    cli_out(cli, "%-4s" , "CP");
    
    cli_out(cli, "%-4s" , "ST");
    cli_out(cli, "%-4s" , "STE");
    cli_out(cli, "%-4s" , "VDP");
    cli_out(cli, "%-5s" , "SI");
    cli_out(cli, "%-5s" , "DVP");

    cli_out(cli, "%-6s" , "3EP");
    cli_out(cli, "%-6s" , "2EP");

    cli_out(cli, " \n"); 
}

void
diag_show_sram_dsnh_8w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-8s" , " ");
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.l2_rewrite_type);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.stag_cfi);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.stag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.copy_ctag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.svlan_tagged);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.cvlan_tagged);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.mtu_check_en);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.by_pass_all);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.payload_operation);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.output_svlan_id_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.output_cvlan_id_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.l3_rewrite_type);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.replace_dscp);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.replace_ctag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.derive_stag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.service_acl_qos_en);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.service_policer_valid);

    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.tagged_mode);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.output_svlan_id_valid_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.output_cvlan_id_valid_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.output_svlan_id_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.output_cvlan_id_ext);
    
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.vpls_port_check);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.tunnel_mtu_check);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.service_id_en);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.tunnel_update_disable);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.community_port);
    
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.svlan_tpid);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.svlan_tpid_en);
    cli_out(cli, " %-3x", resp->ds_nexthop8w_t.vpls_dest_port);
    cli_out(cli, " %-4x", resp->ds_nexthop8w_t.service_id);
    cli_out(cli, " %-4x", resp->ds_nexthop8w_t.dest_vlan_ptr);
    cli_out(cli, " %-5x", resp->ds_nexthop8w_t.l3edit_ptr170 
                           |(resp->ds_nexthop8w_t.l3edit_ptr18 << 18) 
                           |(resp->ds_nexthop8w_t.l3edit_ptr19 << 19));
    cli_out(cli, " %-5x", resp->ds_nexthop8w_t.l2edit_ptr12to0 
                           |(resp->ds_nexthop8w_t.l2edit_ptr19to13<<12));

    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_dsnh_8w( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         diag_show_sram_dsnh_8w_head_explain(cli);
    }
    diag_show_sram_dsnh_8w_head( cli );
    diag_show_sram_dsnh_8w_entry( cli, resp );
    return CLI_SUCCESS;
}

void 
diag_show_sram_epe_dsnh_4w_head_explain(struct cli *cli)
{
    cli_out(cli,"BPA-By Pass All, ");
    cli_out(cli,"CCC-Copy Ctag Cos, ");
    cli_out(cli,"CVT-Cvlan Tagged, ");
    cli_out(cli,"DSC-Derive Stag Cos, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"2RT-L2 Rewrite Type, ");
    cli_out(cli,"3RT-L3 Rewrite Type, ");
    cli_out(cli,"MCE-Mtu Check En, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"OCV-Output Cvlan Id Valid, ");
    cli_out(cli,"OSV-Output Svlan Id Valid, ");
    cli_out(cli,"PLO-PayLoad Operation, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"RCC-Replace Ctag Cos, ");
    cli_out(cli,"RPD-RePlace Dscp, ");
    cli_out(cli,"AQE-service Acl Qos En, ");
    cli_out(cli,"SPV-Service Policer Vld, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"SCF-Stag CFi, ");
    cli_out(cli,"SCO-Stag SCOs, ");
    cli_out(cli,"SVT-SVlan Tagged, ");
    cli_out(cli,"TMD-Tagged MoDe, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"DVP-Dest Vlan Ptr, ");    
    cli_out(cli,"2EP-l2edit Ptr, ");
    cli_out(cli,"3EP-L3edit Ptr, ");
    cli_out(cli, " \n"); 
}

void 
diag_show_sram_epe_dsnh_4w_head(struct cli *cli)
{
    cli_out(cli, "%-13s" , " dsnh-int-4w");
    cli_out(cli, "%-4s" , "BPA");
    cli_out(cli, "%-4s" , "CCC");
    cli_out(cli, "%-4s" , "CVT");
    cli_out(cli, "%-4s" , "DSC");
    cli_out(cli, "%-4s" , "2RT");
    cli_out(cli, "%-4s" , "3RT");
    cli_out(cli, "%-4s" , "MCE");
    cli_out(cli, "%-4s" , "OCV");
    cli_out(cli, "%-4s" , "OSV");
    cli_out(cli, "%-4s" , "PLO");
    cli_out(cli, "%-4s" , "RCC");
    cli_out(cli, "%-4s" , "RPD");
    cli_out(cli, "%-4s" , "AQE");
    cli_out(cli, "%-4s" , "SPV");
    cli_out(cli, "%-4s" , "SCF");
    cli_out(cli, "%-4s" , "SCO");
    cli_out(cli, "%-4s" , "SVT");
    cli_out(cli, "%-4s" , "TMD");
    cli_out(cli, "%-5s" , "DVP");

    cli_out(cli, "%-6s" , "2EP");
    cli_out(cli, "%-6s" , "3EP");

    cli_out(cli, " \n"); 
}

void
diag_show_sram_epe_dsnh_4w_entry(struct cli *cli, diag_sram_entry_resp_t* resp, 
                                 uint32 new_l2edit_ptr, uint32 new_l3edit_ptr )
{
    cli_out(cli, "%-12s" , " ");
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.by_pass_all);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.copy_ctag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.cvlan_tagged);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.derive_stag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.l2_rewrite_type);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.l3_rewrite_type);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.mtu_check_en);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.output_cvlan_id_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.output_svlan_id_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.payload_operation);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.replace_ctag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.replace_dscp);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.service_acl_qos_en);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.service_policer_vld);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.stag_cfi);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.stag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.svlan_tagged);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.tagged_mode);
    cli_out(cli, " %-4x", resp->ds_nexthop_interl_4w_t.dest_vlan_ptr);
    
//    cli_out(cli, " %-3x", resp->ds_nexthop_interl_4w_t.l2edit_ptr);
//    cli_out(cli, " %-5x", resp->ds_nexthop_interl_4w_t.l3edit_ptr);
    cli_out(cli, " %-5x", new_l2edit_ptr);
    cli_out(cli, " %-5x", new_l3edit_ptr);
    
    cli_out(cli, " \n"); 
}

#if 0
int32 
diag_show_sram_epe_dsnh_4w( struct cli *cli, diag_sram_entry_req_t* req, 
                            diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));

    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    
    if ( if_explain )
    {
         diag_show_sram_epe_dsnh_4w_head_explain(cli);
    }
    
    diag_show_sram_epe_dsnh_4w_head( cli );
    diag_show_sram_epe_dsnh_4w_entry( cli, resp );
    return CLI_SUCCESS;
}
#endif
void 
diag_show_sram_epe_dsnh_8w_head_explain(struct cli *cli)
{
    cli_out(cli, "BPA-By Pass All, ");
    cli_out(cli, "CPT-Community PorT, ");
    cli_out(cli, "CCC-Copy Ctag Cos, ");
    cli_out(cli, "CVT-CVlan Tagged, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "DSC-Derive Stag Cos, ");
    cli_out(cli, "DVP-Dest Vlan Ptr, ");
    cli_out(cli, "MCE-Mtu Check En, ");
    cli_out(cli, "OCI-Output Cvlan Id ext, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "OCV-Output Cvlan id Valid, ");
    cli_out(cli, "CVE-Output Cvlan id valid Ext, ");
    cli_out(cli, "OSI-Output Svlan Id ext, ");
    cli_out(cli, "OSV-Output Svlan id Valid, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "SVE-Output svlan id Valid Ext, ");
    cli_out(cli, "PLO-PayLoad Operation, ");                     
    cli_out(cli, "RCC-Replace Ctag Cos, ");
    cli_out(cli, "RPD-RePlace Dscp, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "AQE-service Acl Qos En, ");
    cli_out(cli, "SID-Service ID, ");
    cli_out(cli, "SIE-Service Ed En, ");
    cli_out(cli, "SPV-Service Policer Valid, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "SCF-Stag CFi, ");
    cli_out(cli, "SCO-Stag COs, ");
    cli_out(cli, "STG-Svlan TaGged, ");
    cli_out(cli, "STP-Svlan TPid, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "STE-Svlan Tpid En, ");
    cli_out(cli, "TMD-Tagged Mode, ");
    cli_out(cli, "TMC-Tunnel Mtu Check, ");
    cli_out(cli, "TUD-Tunnel Update Disable, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "VDP-Vpls Dest Port, ");
    cli_out(cli, "VPC-Vpls Port Check, ");                     
    cli_out(cli, "2RT-l2 Rewrite Type, ");
    cli_out(cli, "3RT-l3 Rewrite Type, ");
    cli_out(cli, " \n "); 
    cli_out(cli, "2EP-l2Edit Ptr, ");
    cli_out(cli, "3EP-l3Edit Ptr, ");
    cli_out(cli, " \n "); 
}

void 
diag_show_sram_epe_dsnh_8w_head(struct cli *cli)
{
    cli_out(cli, "%-13s" , " dsnh-int-8w");
    cli_out(cli, "%-4s" , "BPA");
    cli_out(cli, "%-4s" , "CPT");
    cli_out(cli, "%-4s" , "CCC");
    cli_out(cli, "%-4s" , "CVT");
    cli_out(cli, "%-4s" , "DSC");
    cli_out(cli, "%-5s" , "DVP");
    cli_out(cli, "%-4s" , "MCE");
    cli_out(cli, "%-4s" , "OCI");
    cli_out(cli, "%-4s" , "OCV");
    cli_out(cli, "%-4s" , "CVE");
    cli_out(cli, "%-4s" , "OSI");
    cli_out(cli, "%-4s" , "OSV");
    cli_out(cli, "%-4s" , "SVE");
    cli_out(cli, "%-4s" , "PLO");

    cli_out(cli, "%-4s" , "RCC");
    cli_out(cli, "%-4s" , "RPD");
    cli_out(cli, "%-4s" , "AQE");
    cli_out(cli, "%-5s" , "SID");
    cli_out(cli, "%-4s" , "SIE");
    cli_out(cli, "%-4s" , "SPV");
    cli_out(cli, "%-4s" , "SCF");
    cli_out(cli, "%-4s" , "SCO");
    cli_out(cli, "%-4s" , "STG");
    cli_out(cli, "%-4s" , "STP");
    cli_out(cli, "%-4s" , "STE");
    cli_out(cli, "%-4s" , "TMD");
    cli_out(cli, "%-4s" , "TMC");
    cli_out(cli, "%-4s" , "TUD");
    cli_out(cli, "%-4s" , "VDP");
    cli_out(cli, "%-4s" , "VPC");

    cli_out(cli, "%-4s" , "2RT");
    cli_out(cli, "%-4s" , "3RT");

    cli_out(cli, "%-6s" , "2EP");
    cli_out(cli, "%-6s" , "3EP");

    cli_out(cli, " \n"); 
}

void
diag_show_sram_epe_dsnh_8w_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-12s" , " ");
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.by_pass_all);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.community_port);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.copy_ctag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.cvlan_tagged);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.derive_stag_cos);
    cli_out(cli, " %-4x", resp->ds_nexthop_interl_8w_t.dest_vlan_ptr);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.mtu_check_en);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.output_cvlan_id_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.output_cvlan_id_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.output_cvlan_id_valid_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.output_svlan_id_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.output_svlan_id_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.output_svlan_id_valid_ext);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.payload_operation);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.replace_ctag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.replace_dscp);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.service_acl_qos_en);
    cli_out(cli, " %-4x", resp->ds_nexthop_interl_8w_t.service_id);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.service_id_en);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.service_policer_valid);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.stag_cfi);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.stag_cos);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.svlan_tagged);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.svlan_tpid);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.svlan_tpid_en);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.tagged_mode);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.tunnel_mtu_check);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.tunnel_update_disable);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.vpls_dest_port);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.vpls_port_check);

    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.l2_rewrite_type);
    cli_out(cli, " %-3x", resp->ds_nexthop_interl_8w_t.l3_rewrite_type);
    cli_out(cli, " %-5x", resp->ds_nexthop_interl_8w_t.l2edit_ptr12to0 
                          | resp->ds_nexthop_interl_8w_t.l2edit_ptr19to13 << 13);

    cli_out(cli, " %-5x", resp->ds_nexthop_interl_8w_t.l3edit_ptr170 
                          | resp->ds_nexthop_interl_8w_t.l3edit_ptr18 << 18
                          | resp->ds_nexthop_interl_8w_t.l3edit_ptr19 << 19);

    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_epe_dsnh_8w( struct cli *cli, diag_sram_entry_req_t* req, 
                                       diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         diag_show_sram_epe_dsnh_8w_head_explain(cli);
    }
    diag_show_sram_epe_dsnh_8w_head( cli );
    diag_show_sram_epe_dsnh_8w_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_vpls_port_head_explain(struct cli *cli)
{
    cli_out(cli,"VPT-vpls_port_type, ");

    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_vpls_port_head(struct cli *cli)
{
    cli_out(cli, "%-11s" , " vpls-port");
    cli_out(cli, "%-4s" , "VPT");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_vpls_port_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-10s" , " ");
    cli_out(cli, " %-3x", resp->ds_vpls_port_t.vpls_port_type);

    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_vpls_port( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_vpls_port_head_explain(cli);
    }
    _diag_show_sram_vpls_port_head( cli );
    _diag_show_sram_vpls_port_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_l3_v6_ip_head_explain(struct cli *cli)
{
    cli_out(cli,"sa31_to0-ip_sa31_to0, ");

    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_l3_v6_ip_head(struct cli *cli)
{
    cli_out(cli, "%-10s" , " l3-v6-sa");
    cli_out(cli, "%-9s" , "127_to96");
    cli_out(cli, "%-9s" , "95_to64");
    cli_out(cli, "%-9s" , "63_to32");
    cli_out(cli, "%-9s" , "31_to0");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_l3_v6_ip_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-9s" , " ");
    cli_out(cli, " %08x", resp->ds_l3_edit_tunnel_v6_ip_t.ip_sa127_to96);
    cli_out(cli, " %08x", resp->ds_l3_edit_tunnel_v6_ip_t.ip_sa95_to64);
    cli_out(cli, " %08x", resp->ds_l3_edit_tunnel_v6_ip_t.ip_sa63_to32);
    cli_out(cli, " %08x", resp->ds_l3_edit_tunnel_v6_ip_t.ip_sa31_to0);

    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_l3_v6_ip( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_l3_v6_ip_head_explain(cli);
    }
    _diag_show_sram_l3_v6_ip_head( cli );
    _diag_show_sram_l3_v6_ip_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_l3_v4_ip_head_explain(struct cli *cli)
{
    cli_out(cli,"IPSA-Ip Sa, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_l3_v4_ip_head(struct cli *cli)
{
    cli_out(cli, "%-10s" , " l3-v4-sa");
    cli_out(cli, "%-9s" , "IPSA");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_l3_v4_ip_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-9s" , " ");
    cli_out(cli, " %08x", resp->ds_l3_edit_tunnel_v4_ip_sa_t.ip_sa);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_l3_v4_ip( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_l3_v4_ip_head_explain(cli);
    }
    _diag_show_sram_l3_v4_ip_head( cli );
    _diag_show_sram_l3_v4_ip_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_dest_phy_port_head_explain(struct cli *cli)
{
    cli_out(cli,"DPORT-global Dest Port, ");
    cli_out(cli,"L2SID-L2 Span ID, ");
    cli_out(cli,"L2SEN-L2 Span EN, ");
    cli_out(cli,"PTYPE-mux Port Type, ");
    cli_out(cli, " \n"); 
    cli_out(cli,"OAM-discard non8023 Oam, ");
    cli_out(cli,"DISCD-Dest Discard, ");
    cli_out(cli,"LOGEN-random Log En, ");
    cli_out(cli,"RHOLD-Random Threshold, ");

    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_dest_phy_port_head(struct cli *cli)
{
    cli_out(cli, "%-15s" , " dest-phy-port");
    cli_out(cli, "%-9s" , "DPORT");
    cli_out(cli, "%-9s" , "L2SID");
    cli_out(cli, "%-9s" , "L2SEN");
    cli_out(cli, "%-9s" , "PTYPE");
    cli_out(cli, "%-9s" , "OAM");
    cli_out(cli, "%-9s" , "DISCD");
    cli_out(cli, "%-9s" , "LOGEN");
    cli_out(cli, "%-9s" , "RHOLD");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_dest_phy_port_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-14s" , " ");
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.global_dest_port);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.l2_span_id);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.l2_span_en);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.mux_port_type);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.discard_non8023_oam);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.dest_discard);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.random_log_en);
    cli_out(cli, " %-8x", resp->ds_dest_phy_port_t.random_threshold);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_dest_phy_port( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_dest_phy_port_head_explain(cli);
        cli_out(cli, " \n"); 
    }
    _diag_show_sram_dest_phy_port_head( cli );
    _diag_show_sram_dest_phy_port_entry( cli, resp );
    return CLI_SUCCESS;
}

static void 
_diag_show_sram_l3_seq_num_head_explain(struct cli *cli)
{
    cli_out(cli,"31to0-seq_num31_to0, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_sram_l3_seq_num_head(struct cli *cli)
{
    cli_out(cli, "%-12s" , " l3-seq-num");
    cli_out(cli, "%-9s" , "31to0");
    cli_out(cli, "%-9s" , "63to32");
    cli_out(cli, "%-9s" , "95to64");
    cli_out(cli, "%-9s" , "127to96");

    cli_out(cli, " \n"); 
}

static void
_diag_show_sram_l3_seq_num_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%-11s" , " ");
    cli_out(cli, " %-8x", resp->ds_l3_edit_sequence_num_t.seq_num31_to0);
    cli_out(cli, " %-8x", resp->ds_l3_edit_sequence_num_t.seq_num63_to32);
    cli_out(cli, " %-8x", resp->ds_l3_edit_sequence_num_t.seq_num95_to64);
    cli_out(cli, " %-8x", resp->ds_l3_edit_sequence_num_t.seq_num127_to96);
    cli_out(cli, " \n"); 
}

int32 
_diag_show_sram_l3_seq_num( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (_diag_show_sram_table(cli, req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
         return CLI_SUCCESS;
    }
    if ( if_explain )
    {
         _diag_show_sram_l3_seq_num_head_explain(cli);
    }
    _diag_show_sram_l3_seq_num_head( cli );
    _diag_show_sram_l3_seq_num_entry( cli, resp );
    return CLI_SUCCESS;
}

void 
diag_show_tcam_ipmc_dsipsa_head_explain(struct cli *cli)
{
    cli_out(cli,  "RC-Rpf Check En, ");
    cli_out(cli,  "MRI-Ipsa More Rpf If, ");
    
    cli_out(cli, "RIV3-RpfIfId Valid3, ");
    cli_out(cli,  "RIV2-RpfIfId Valid2");
    cli_out(cli, " \n"); 
    cli_out(cli, "RIV1-RpfIfId Valid1, ");
    cli_out(cli, "RIV0-RpfIfId Valid0, ");
    cli_out(cli, "RI3-RpfIfId3, ");
    cli_out(cli,  "RI2-RpfIfId2, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "RI1-RpfIfId1, ");
    cli_out(cli,  "RI0-RpfIfId0, ");
    cli_out(cli, " \n"); 
}

void 
diag_show_tcam_ipmc_dsipsa_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DSIPSA");
    cli_out(cli, "%-3s" , "RC");
    cli_out(cli, "%-3s" , "MRI");
    cli_out(cli, "%-5s" , "RIV3");
    cli_out(cli, "%-5s" , "RIV2");
    cli_out(cli, "%-5s" , "RIV1");
    cli_out(cli, "%-5s" , "RIV0");
    cli_out(cli, "%-5s" , "RI3");
    cli_out(cli, "%-5s" , "RI2");
    cli_out(cli, "%-5s" , "RI1");
    cli_out(cli, "%-5s" , "RI0");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_ipmc_dsipsa_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_rpf.check_en);
    
    cli_out(cli, " %-2x", resp->dsipsa.ipsa_more_rpf_if);
    
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid3);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid2);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid1);
    cli_out(cli, " %-4x", resp->dsipsa.if_id_valid0);
    cli_out(cli, " %-4x", resp->dsipsa.if_id3);
    cli_out(cli, " %-4x", resp->dsipsa.if_id2);
    cli_out(cli, " %-4x", resp->dsipsa.if_id1);
    cli_out(cli, " %-4x", resp->dsipsa.if_id0);
    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_ipmc_dssa( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table( req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        diag_show_tcam_ipmc_dsipsa_head_explain(cli);        
        cli_out(cli,"\n");
    }

    diag_show_tcam_ipmc_dsipsa_head( cli );
    _diag_show_tcam_ipmc_dsipsa_entry( cli, resp );
    cli_out(cli,"\n");
    return CLI_SUCCESS;
}

void 
diag_show_tcam_ipmc_dsipda_head_explain(struct cli *cli)
{
    cli_out(cli,  "PG-Bidi Pim Group, ");
    cli_out(cli,  "GV-Bidi Pim Group Valid, ");
    cli_out(cli,  "DP-Deny Pbr, ");
    cli_out(cli,  "PN-Equal Cost Path Num,");
    cli_out(cli, " \n"); 
    cli_out(cli,  "SI-Excep Sub Index, ");    
    cli_out(cli,  "EE-Exp3 Ctl En, ");
    cli_out(cli,  "IE-Icmp Check En, ");
    cli_out(cli,  "DE-Ip Da Exception En, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "AE-Isatap Check En, ");
    cli_out(cli,  "IT-l3 If Type, ");
    
    cli_out(cli,  "CE-mcast rpf fail Cpu En, ");
    cli_out(cli,  "PS-Payload Select,");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PE-Priority path En, ");
    cli_out(cli,  "TE-Ttl Check En, ");
    cli_out(cli,  "TO-Tunnel gre Options, ");
    cli_out(cli,  "PT-Tunnel Packet Type, ");  
    
    cli_out(cli, " \n"); 
    cli_out(cli,  "PO-Tunnel Payload Offset, ");
    cli_out(cli,  "OT-Tunnel Payload Offset Type, ");
    cli_out(cli,  "VE-Vpls En, ");

    cli_out(cli, " \n"); 
    cli_out(cli,  "VI-Vrf Id, ");

    cli_out(cli,  "FP-ds Fwd Ptr ");
    cli_out(cli, " \n"); 
}

void 
diag_show_tcam_ipmc_dsipda_head(struct cli *cli)
{
    cli_out(cli, "%-10s" , " DSIPMCDA");
    cli_out(cli, "%-3s" , "PG");
    cli_out(cli, "%-3s" , "GV");
    cli_out(cli, "%-3s" , "DP");
    cli_out(cli, "%-3s" , "PN");
    cli_out(cli, "%-3s" , "SI");
    cli_out(cli, "%-3s" , "EE");
    cli_out(cli, "%-3s" , "IE");
    cli_out(cli, "%-3s" , "DE");
    cli_out(cli, "%-3s" , "AE");

    cli_out(cli, "%-3s" , "IT");
    cli_out(cli, "%-3s" , "CE");
    cli_out(cli, "%-3s" , "PS");
    cli_out(cli, "%-3s" , "PE");
    cli_out(cli, "%-3s" , "TE");
    cli_out(cli, "%-3s" , "TO");
    
    cli_out(cli, "%-3s" , "PT");
    cli_out(cli, "%-3s" , "PO");
    cli_out(cli, "%-3s" , "OT");
    cli_out(cli, "%-3s" , "VE");
    cli_out(cli, "%-5s" , "VI");

    cli_out(cli, "%-5s" , "FP");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_ipmc_dsipda_entry(struct cli *cli,  diag_sram_entry_resp_t* resp )
{
    cli_out(cli, "%9s" , "");
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.bidi_pim_group);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.bidi_pim_group_valid);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.deny_pbr);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.equal_cost_path_num 
                          + (resp->ds_ipv4_mcast_da.equal_cost_path_num2 << 1));
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.excep_sub_index);
    
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.exp3_ctl_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.icmp_check_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.ip_da_exception_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.isatap_check_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.l3_if_type);
    
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.mcast_rpf_fail_cpu_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.payload_select);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.priority_path_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.ttl_check_en);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.tunnel_gre_options);
    
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.tunnel_packet_type);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.tunnel_payload_offset);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.tunnel_payload_offset_type);
    cli_out(cli, " %-2x", resp->ds_ipv4_mcast_da.vpls_en);
    cli_out(cli, " %-4x", resp->ds_ipv4_mcast_da.vrf_id);
    
    cli_out(cli, " %-4x", resp->ds_ipv4_mcast_da.ds_fwd_ptr);

    cli_out(cli, " \n"); 
}

int32 
diag_show_sram_ipmc_dsda( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    DIAG_SHOW_IF_ERROR_RETURN (lcsm_lcapi_show_sram_table(req, resp));
    if ( CLI_SUCCESS != diag_show_return_infor(cli, resp) )
    {
        return CLI_SUCCESS;
    }
    if ( if_explain )
    {
        diag_show_tcam_ipmc_dsipda_head_explain(cli);        
        cli_out(cli, " \n"); 
    }
    diag_show_tcam_ipmc_dsipda_head( cli );
    _diag_show_tcam_ipmc_dsipda_entry( cli, resp );
    cli_out(cli,"\n");
    if ( if_list)
    {
        if ( resp->dsipda.ds_fwd_ptr != 0xfffff)
        {
            req->table_type = DIAG_DS_FWD;
            req->index = resp->dsipda.ds_fwd_ptr;
            diag_show_sram_dsfwd( cli, req, resp, if_list, if_explain);
        }
    }
    return CLI_SUCCESS;
}
static int32
_diag_get_sram_table( struct cli *cli, char* table_name , 
                 diag_sram_entry_req_t* req, diag_sram_entry_resp_t* resp,int if_list, int if_explain)
{
    if (! sal_strcmp (table_name, "dsnh-interl-4w")) 
    {
        req->table_type = DIAG_EPE_NEXT_HOP_INTERNAL4W;
        diag_show_sram_dsnh(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "dsnh-interl-8w")) 
    {
        req->table_type = DIAG_EPE_NEXT_HOP_INTERNAL8W;
        diag_show_sram_dsnh(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "dest-phy-port")) 
    {
        req->table_type = DIAG_DS_DEST_PHY_PORT;
        _diag_show_sram_dest_phy_port(cli, req, resp, if_list, if_explain); 
    }

    if (! sal_strcmp (table_name, "l3-edit-seq-num")) 
    {
        req->table_type = DIAG_DS_L3_EDIT_SEQUENCE_NUM;
        _diag_show_sram_l3_seq_num(cli, req, resp, if_list, if_explain); 
    }

    if (! sal_strcmp (table_name, "l3-edit-v4-ip")) 
    {
        req->table_type = DIAG_DS_L3_EDIT_TUNNEL_V4_IP_SA;
        _diag_show_sram_l3_v4_ip(cli, req, resp, if_list, if_explain); 
    }

    if (! sal_strcmp (table_name, "l3-edit-v6-ip")) 
    {
        req->table_type = DIAG_DS_L3_EDIT_TUNNEL_V6_IP;
        _diag_show_sram_l3_v6_ip(cli, req, resp, if_list, if_explain); 
    }

    if (! sal_strcmp (table_name, "vpls-port")) 
    {
        req->table_type = DIAG_DS_VPLS_PORT ;
        _diag_show_sram_vpls_port(cli, req, resp, if_list, if_explain); 
    }

    if (! sal_strcmp (table_name, "dsnh8w")) 
    {
        req->table_type = DIAG_DS_NEXTHOP8W;
        diag_show_sram_dsnh(cli, req, resp, if_list, if_explain); 
    }

    if (! sal_strcmp (table_name, "link-agg-grp")) 
    {
        req->table_type = DIAG_DS_LINK_AGGREAGATION_GROUP;
        _diag_show_sram_link_agg_grp(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "fwd-ext")) 
    {
        req->table_type = DIAG_FWDEXTTABLE;
        _diag_show_sram_fwd_ext(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "aps-sel-tbl")) 
    {
        req->table_type = DIAG_APSSELECTTABLE;
        _diag_show_sram_aps_sel_tbl(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "aps-bri")) 
    {
        req->table_type = DIAG_APSBRIDGETABLE;
        _diag_show_sram_aps_bri_tbl(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "mpls-ctl")) 
    {
        req->table_type = DIAG_DS_MPLS_CTL;
        _diag_show_sram_mpls_ctl(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "phy-port-ext")) 
    {
        req->table_type = DIAG_DS_PHY_PORT_EXT;
        _diag_show_sram_phy_port_ext(cli, req, resp, if_list, if_explain); 
    }
    if (! sal_strcmp (table_name, "chl-shp")) 
    {
        req->table_type = DIAG_DS_CHANNEL_SHAPE;
        _diag_show_sram_channel_shape(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "que-shp")) 
    {
        req->table_type = DIAG_DS_QUEUE_SHAPE;
        _diag_show_sram_queue_shape(cli, req, resp, if_list, if_explain);
    }

    if (! sal_strcmp (table_name, "link-agg")) 
    {
        req->table_type = DIAG_DS_LINK_AGGREGATION;
        _diag_show_sram_link_agg(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "link-agg-mem")) 
    {
        req->table_type = DIAG_DS_LINK_AGG_MEMBER_NUM;
        diag_show_sram_link_agg_mem(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "src-intf")) 
    {
        req->table_type = DIAG_DS_SRC_INTERFACE;
        _diag_show_sram_src_intf(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "dst-intf")) 
    {
        req->table_type = DIAG_DS_DEST_INTERFACE;
        _diag_show_sram_dst_intf(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "chg-shp-prf")) 
    {
        req->table_type = DIAG_DS_CHANNEL_SHAPE_PROFILE;
        _diag_show_sram_chg_shp_prof(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "que-shp-prf")) 
    {
        req->table_type = DIAG_DS_QUEUE_SHAPE_PROFILE;
        _diag_show_sram_queue_shp_prof(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "que-dro-prf")) 
    {
        req->table_type = DIAG_DS_QUEUE_DROP_PROFILE;
        _diag_show_sram_queue_drop_prof(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "que-map")) 
    {
        req->table_type = DIAG_DS_QUEUE_MAP;
        _diag_show_sram_queue_map(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp( table_name, "rt-mac"))
    {
        req->table_type = DIAG_DS_ROUTER_MAC;
        _diag_show_sram_dsrtmac(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp( table_name, "mpls"))
    {
        req->table_type = DIAG_DS_MPLS;
        _diag_show_sram_dsmpls(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "ucda")) 
    {
        req->table_type = DIAG_DS_IPV4_UCAST_DA;
        diag_show_sram_dsda(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "ucsa")) 
    {
        req->table_type = DIAG_DS_IPV4_UCAST_SA;
        diag_show_sram_dssa(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "dsfwd")) 
    {
        req->table_type = DIAG_DS_FWD;
        diag_show_sram_dsfwd(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "dsnh")) 
    {
        req->table_type = DIAG_DS_NEXTHOP;
        diag_show_sram_dsnh(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "lookback")) 
    {
       req->table_type = DIAG_DS_L2_EDIT_LOOPBACK;
       diag_show_sram_l2edit_lookback(cli, req, resp, if_list, if_explain);
    }

    else if (! sal_strcmp (table_name, "tunnelv4")) 
    {
        req->table_type = DIAG_DS_L3EDIT_TUNNEL_V4;
        diag_show_sram_l3edit_tunnelv4(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "tunnelv6")) 
    {
        req->table_type = DIAG_DS_L3EDIT_TUNNEL_V6;
        _diag_show_sram_l3edit_tunnelv6(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "flex")) 
    {
        req->table_type = DIAG_DS_L3EDIT_FLEX;
        _diag_show_sram_l3edit_flex(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "dsmet")) 
    {
        req->table_type = DIAG_DS_MET_ENTRY;
        _diag_show_sram_dsmet(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mcsa")) 
    {
        req->table_type = DIAG_DS_IPV4_MCAST_RPF;
        diag_show_sram_dssa(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mcda")) 
    {
        req->table_type = DIAG_DS_IPV4_MCAST_DA;
        diag_show_sram_dsda(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v6ucsa")) 
    {
        req->table_type = DIAG_DS_IPV6_UCAST_SA;
        diag_show_sram_dssa(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v6ucda")) 
    {
        req->table_type = DIAG_DS_IPV6_UCAST_DA;
        diag_show_sram_dsda(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "src-port")) 
    {
        req->table_type = DIAG_DS_SRC_PORT;
        _diag_show_sram_src_port(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "dest-port")) 
    {
        req->table_type = DIAG_DS_DEST_PORT;
        _diag_show_sram_dest_port(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "phy-port")) 
    {
        req->table_type = DIAG_DS_PHY_PORT;
        _diag_show_sram_phy_port(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "proto-vlan")) 
    {
        req->table_type = DIAG_DS_PROTOCOL_VLAN;
        _diag_show_sram_proto_vlan(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "dsmac")) 
    {
        req->table_type = DIAG_DS_MAC;
        _diag_show_sram_mac(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mac-acl")) 
    {
        req->table_type = DIAG_DS_MAC_ACL;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v4acl")) 
    {
        req->table_type = DIAG_DS_IPV4_ACL;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v6acl")) 
    {
        req->table_type = DIAG_DS_IPV6_ACL;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mpls-acl")) 
    {
        req->table_type = DIAG_DS_MPLS_ACL;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mac-qos")) 
    {
        req->table_type = DIAG_DS_MAC_QOS;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v4qos")) 
    {
        req->table_type = DIAG_DS_IPV4_QOS;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v6qos")) 
    {
        req->table_type = DIAG_DS_IPV6_QOS;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mpls-qos")) 
    {
        req->table_type = DIAG_DS_MPLS_QOS;
        _diag_show_sram_aclqos(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v4-ucast-pbr-dual")) 
    {
        req->table_type = DIAG_DS_IPV4_UCAST_PBR_DUAL_DA;
        diag_show_sram_dsda(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "v6-ucast-pbr-dual")) 
    {
        req->table_type = DIAG_DS_IPV6_UCAST_PBR_DUAL_DA;
        diag_show_sram_dsda(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "usrid-v4")) 
    {
        req->table_type = DIAG_DS_USER_ID_IPV4;
        _diag_show_sram_usrid(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "usrid-v6")) 
    {
        req->table_type = DIAG_DS_USER_ID_IPV6;
        _diag_show_sram_usrid(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "usrid-mac")) 
    {
        req->table_type = DIAG_DS_USER_ID_MAC;
        _diag_show_sram_usrid(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "usrid-vlan")) 
    {
        req->table_type = DIAG_DS_USER_ID_VLAN;
        _diag_show_sram_usrid(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "vlan-status")) 
    {
        req->table_type = DIAG_DS_VLAN_STATUS;
        _diag_show_sram_vlan_status(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "policer")) 
    {
        req->table_type = DIAG_DS_POLICER;
        _diag_show_sram_policer(cli, req, resp, if_list, if_explain);
    }    
    else if (! sal_strcmp (table_name, "stp-state")) 
    {
        req->table_type = DIAG_STP_STATE_RAM;
        _diag_show_sram_stp_state(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "eth4w")) 
    {
       req->table_type = DIAG_DS_L2_EDIT_ETH4W;
       diag_show_sram_l2edit_eth4w(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "eth8w")) 
    {
        req->table_type = DIAG_DS_L2_EDIT_ETH8W;
        diag_show_sram_l2edit_eth8w(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "mpls4w")) 
    {
        req->table_type= DIAG_DS_L3EDIT_MPLS4W;
        diag_show_sram_l3edit_mpls4w(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "mpls8w")) 
    {
        req->table_type = DIAG_DS_L3EDIT_MPLS8W;
        diag_show_sram_l3edit_mpls8w(cli, req, resp, if_list, if_explain); 
    }
    else if (! sal_strcmp (table_name, "storm-ctl")) 
    {
        req->table_type = DIAG_DS_STORM_CTL_TABLE;
        _diag_show_sram_storm_ctl(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "dsaging")) 
    {
        req->table_type = DIAG_IPE_AGING_RAM;
        _diag_show_sram_aging(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "policer-profile")) 
    {
        req->table_type = DIAG_DS_POLICER_PROFILE; 
        _diag_show_sram_policer_profile(cli, req, resp, if_list, if_explain);
    }
    else if (! sal_strcmp (table_name, "ds-vlan")) 
    {
        req->table_type = DIAG_DS_VLAN;
        _diag_show_sram_src_vlan(cli, req, resp, if_list, if_explain);
    }
    return CLI_SUCCESS;
}

static int32 
_diag_show_sram_stpstate( struct cli *cli, uint32 chip_id, uint32 port_id, uint32 vlan_id, uint32 is_explain)
{
    uint8 stpstate = 0;
    diag_sram_get_stp_status_req_t req_sram;
    diag_sram_get_stp_status_resp_t resp_sram;
   
    sal_memset(&req_sram, 0 , sizeof(diag_sram_get_stp_status_req_t));
    sal_memset(&resp_sram,0,sizeof(diag_sram_get_stp_status_resp_t));

    req_sram.chip_id= chip_id;
    req_sram.table_type = DIAG_GET_STP_ID;
    req_sram.vlan_id= vlan_id;
    req_sram.port_id = port_id;

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_sram_get_stp_status(cli, &req_sram, &resp_sram));

    stpstate = resp_sram.stp_status;
    
    CLI_OUT_EXPLAIN( cli, "\nport = %d, vlan= %d, stp state is " , port_id, vlan_id);
    if ( 0 == stpstate )
    {
        CLI_OUT_EXPLAIN( cli, "forwarding.");
    }
    else if ( 1 == stpstate )
    {
        CLI_OUT_EXPLAIN( cli, "blocking.");
    }
    else if ( 2 == stpstate )
    {
        CLI_OUT_EXPLAIN( cli, "learning.");
    }
    else if ( 3 == stpstate )
    {
        CLI_OUT_EXPLAIN( cli, "not known.");
    }
    CLI_OUT_EXPLAIN( cli, "\n");

    cli_out( cli, "\nstp-state\n");
    cli_out( cli, "%d\n" , stpstate);
    cli_out(cli, " \n"); 

    return CLI_SUCCESS;
}

static int32 
_diag_show_sram_vlanstatus( struct cli *cli, uint32 chip_id, uint32 port_id, uint32 vlan_id, uint32 is_explain)
{
    uint32 vlan_status = 0;
    uint32 index = 0;
    diag_sram_entry_req_t req_sram;
    diag_sram_entry_resp_t resp_sram;
    uint32 ori_vid = 0;

    sal_memset(&req_sram, 0 , sizeof(diag_sram_entry_req_t));
    sal_memset(&resp_sram,0,sizeof(diag_sram_entry_resp_t));

    /* show vlan_status*/

    sal_memset(&req_sram, 0 , sizeof(diag_sram_entry_req_t));
    sal_memset(&resp_sram,0,sizeof(diag_sram_entry_resp_t));
    
    /* dsvlanStatusIndex = localPhyPort[9:0], vlanid[11:6]*/
    index = ( port_id << 6 ) + (vlan_id >> 6 );
    ori_vid = vlan_id;
    /*CLI_OUT_EXPLAIN( cli, "\nindex = %d\n" , index);*/
    req_sram.chip_id = chip_id;
    req_sram.table_type = DIAG_DS_VLAN_STATUS;
    req_sram.index = index;
    
    DIAG_SHOW_IF_ERROR_RETURN(lcsm_lcapi_show_sram_table(&req_sram, &resp_sram));
    
    vlan_id &= 0x3f;
    
    if ( vlan_id < 32)
    {
        if (resp_sram.vlan_status.vlanid_validl & (1 << vlan_id ))
        {
            vlan_status = 1;
        }
    }
    else
    {
        if (resp_sram.vlan_status.vlanid_validh & (1 <<  (vlan_id  - 32)))
        {
            vlan_status = 1;
        }
    }
    if ( vlan_status )
    {
        CLI_OUT_EXPLAIN( cli, "port %d has been added to vlan %d\n" , port_id, ori_vid);
    }
    else 
    {
        CLI_OUT_EXPLAIN( cli, "port %d has not been added to vlan %d\n" , port_id, ori_vid);
    }  
    
    cli_out( cli, "\nvlan_status\n");
    cli_out( cli, "%d\n" , vlan_status);
    cli_out(cli, " \n"); 
    
    return CLI_SUCCESS;
}

CLI (show_sram_one_table_for_stp_state_vlan_status,
     show_sram_one_table_for_stp_state_vlan_status_cmd,
     "show sram (stp-state |vlan-status)  CHIPID  port PORTNUM vlan VLAN   (explain|)",
     CLI_SHOW_STR,
     "Show SRAM information",
     "Show stp state information",
     "Show vlan status information",
     "Chip ID",
     "Local phy port",
     "Port number",
     "Ds VLAN ",
     "VLAN ID ",
     "Show explain information")
{
    uint32  is_explain = 0;
    uint32 chip_id = 0;
    uint32  port_id = 0;
    uint32 vlan_id = 0;
    
    CLI_GET_INTEGER_RANGE ("Chip id", chip_id, argv[1], 0, 0);
    CLI_GET_INTEGER_RANGE ("Port ID", port_id, argv[2], 0, 51);
    CLI_GET_INTEGER_RANGE ("Vlan ID ", vlan_id, argv[3], 0, 4095);

    if ( argc == 5) 
    {
        is_explain = 1;
    }

    /* show ds_stp_state*/
    if (! sal_strcmp (argv[0], "stp-state")) 
    {
         _diag_show_sram_stpstate( cli, chip_id, port_id, vlan_id, is_explain);
    }

    /* show vlan_status*/
    else if (! sal_strcmp (argv[0], "vlan-status")) 
    {
        _diag_show_sram_vlanstatus( cli, chip_id, port_id, vlan_id, is_explain);
    }

    return CLI_SUCCESS;
}

CLI (show_sram_one_table_for_l2edit,
     show_sram_one_table_for_l2edit_cmd,
     "show sram l2edit (eth4w|eth8w|lookback) CHIPID entry WORD (explain|)",
     CLI_SHOW_STR,
     "Show SRAM information",
     "Show L2edit information",
     "Show eth4w information",
     "Show eth8w information",
     "Show lookback information",
     "Chip ID",
     "Show entry information",
     "Table index",
     "Show explain information")
{
    diag_sram_entry_req_t req;
    diag_sram_entry_resp_t resp;
    uint32 is_explain = 0;

    sal_memset(&req, 0 , sizeof(diag_sram_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_sram_entry_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[1], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[2], 0, 0x0FFFFFFF);

    if ( argc == 4)  
    {
        is_explain = 1;
    }
    DIAG_SHOW_IF_ERROR_RETURN(_diag_get_sram_table( cli, argv[0], &req, &resp ,0,is_explain));

    return CLI_SUCCESS;
}

CLI (show_sram_one_table_for_l3edit,
     show_sram_one_table_for_l3edit_cmd,
     "show sram l3edit (mpls4w|mpls8w|tunnelv4|tunnelv6) CHIPID entry WORD  (explain|)",
     CLI_SHOW_STR,
     "Show SRAM information",
     "Show L3edit information",
     "Show mpls4w information",
     "Show mpls8w information",
     "Show tunnulv4 information",
     "Show tunnelv6 information",
     "Chip ID",
     "Show entry information",
     "Table index",
     "Show explain information")
{
    diag_sram_entry_req_t req;
    diag_sram_entry_resp_t resp;
    uint32 is_explain = 0;

    sal_memset(&req, 0 , sizeof(diag_sram_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_sram_entry_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[1], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[2], 0, 0x0FFFFFFF);

    if ( argc == 4)  
    {
        is_explain = 1;
    }
    DIAG_SHOW_IF_ERROR_RETURN(_diag_get_sram_table( cli, argv[0], &req, &resp ,0,is_explain));

    return CLI_SUCCESS;
}

/* show one sram table */
CLI (show_sram_one_table,
     show_sram_one_table_cmd,
     "show sram (dsnh-interl-4w |dsnh-interl-8w |mpls8w |eth4w |tunnelv6 |tunnelv4 |lookback |l3-edit-seq-num "
     "|l3-edit-v4-ip |l3-edit-v6-ip |vpls-port |dsnh8w |fwd-ext |link-agg-grp |aps-sel-tbl |aps-bri |mpls-ctl "
     "|phy-port-ext |chl-shp |que-shp | link-agg|link-agg-mem|src-intf|dst-intf|chg-shp-prf |que-shp-prf |que-dro-prf " 
     "|que-map |rt-mac|mpls|ucda|ucsa|mcda|mcsa|v6ucda|v6ucsa|dsfwd |dsnh|dsmet |dest-port |src-port |phy-port "
     "|ds-vlan |proto-vlan|dsmac|mac-acl|v4acl|v6acl|mpls-acl|mac-qos|v4qos|v6qos|mpls-qos|v4-ucast-pbr-dual|v6-ucast-pbr-dual|usrid-v4 "
     "|usrid-v6|usrid-mac|usrid-vlan|storm-ctl|dsaging|policer|policer-profile|dest-phy-port)"
     "CHIPID entry WORD (list|)(explain|)",
     CLI_SHOW_STR,
     "Show SRAM information",
     "Show ds internal nexthop 4w ",
     "Show ds internal nexthop 8w ",
     "Show ds l3 edit mpls8w ",
     "Show ds l2 edit eth4w ",
     "Show ds l3 edit tunnel v6 ",
     "Show ds l3 edit tunnel v4 ",
     "Show ds l2 edit lookback",
     "Show ds l3 edit sequence num ",
     "Show ds l3 edit tunnel v4 ip sa ",
     "Show ds l3 edit tunnel v6 ip sa ",
     "Show ds vpls port ",
     "Show ds nexthop 8w ",
     "Show ds forward  ext ",
     "Show ds link aggration group ",
     "Show ds aps select table ",
     "Show ds aps bridge table ",
     "Show ds mpls ctlt ",
     "Show ds Phy Port Ext ",
     "Show ds channel shape ",
     "Show ds queue shape ",
     "Show ds link aggregation ",
     "Show ds link agg member num ",
     "Show ds src interface ",
     "Show ds dst interface ",
     "Show ds change shape profile",
     "Show ds queue shape profile",
     "Show ds queue drop profile",
     "Show ds queue map",
     "Show ds router mac",
     "Show ds mpls ipda",
     "Show ds ipv4 ucast ipda",
     "Show ds ipv4 ucast ipsa",
     "Show ds ipv4 mcast ipda",
     "Show ds ipv4 mcast ipsa",
     "Show ds ipv6 ucast ipda",
     "Show ds ipv6 ucast ipsa",
     "Show dsfwd information",
     "Show dsnexthop information",
     "Show dsmet information",
     "Show dest port information",
     "Show source port  information",
     "Show physical port information",
     "Show ds vlan  information",
     "Show protocol vlan  information",
     "Show ds mac  information",
     "Show ds mac acl information",
     "Show ds ipv4 acl information",
     "Show ds ipv6 acl information",
     "Show ds mpls acl information",
     "Show ds mac qos information",
     "Show ds ipv4 qos information",
     "Show ds ipv6 qos information",
     "Show ds mpls qos information",
     "Show ds ipv4 ucast pbr dual da information",
     "Show ds ipv6 ucast pbr dual da information",
     "Show ds user id ipv4 information",
     "Show ds user id ipv6 information",
     "Show ds user id mac information",
     "Show ds user id vlan information",
     "Show storm control information",     
     "Show ds aging information",
     "Show ds policer information",
     "Show ds policer profile information",
     "Show ds dest phy port",
     "Chip ID",
     "Show entry information",
     "Table index",
     "Show list information",
     "Show explain information")
{
    uint32 is_list = 0;
    uint32 is_explain = 0;

    diag_sram_entry_req_t req;
    diag_sram_entry_resp_t resp;

    sal_memset(&req,0,sizeof(diag_sram_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_sram_entry_resp_t));
    
    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[1], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[2], 0, 0x0FFFFFFF);

    if ( argc == 5) 
    {
        is_list  = 1;
        is_explain = 1;
    }
    else if ( argc == 4) 
    {
        if (sal_strcmp (argv[3], "explain") == 0)
        {
            is_explain = 1;
        }
        else 
        {
            is_list = 1;
        }
    }

    DIAG_SHOW_IF_ERROR_RETURN(_diag_get_sram_table( cli, argv[0], 
                                            &req, &resp, is_list, is_explain ));
    return CLI_SUCCESS;

}

int32
lcsh_sram_cli_init(struct cli_tree *cli_tree)
{
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_sram_one_table_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_sram_one_table_for_stp_state_vlan_status_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_sram_one_table_for_l2edit_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_sram_one_table_for_l3edit_cmd);
    return 0;
}
