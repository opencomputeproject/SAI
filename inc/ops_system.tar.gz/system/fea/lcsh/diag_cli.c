#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>

#include "cli.h"
#include "clish.h"
#include "lcsh_lcmtlk.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "ctclib_show.h"
#include "diag_cli.h"
#include "glb_const.h"
#include "lcsh_client.h"

#define BOARD_MAX_PORT 60

CLI(init_phy,
   init_phy_cmd,
   "init phy PORTS (PORTE|)",
   "Initialize",
   "PHY",
   "Start number of port",
   "End number of port")
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    uint8 port_s, port_e=0;

    read_req.opcode = INIT_PHY;    
    CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, port_s, argv[0], 1, BOARD_MAX_PORT);
    read_req.chip = port_s;
    if(argc >= 2)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, port_e, argv[1], 1, BOARD_MAX_PORT);
        read_req.addr = port_e;
    }
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Initialize PHY fail.\n");
        return CLI_ERROR;
    }
    cli_out(cli, "Initialize PHY Complete!\n");
    return CLI_SUCCESS;
}


CLI(check_qsgmii_status,
   check_qsgmii_status_cmd,
   "check qsgmii QSGMII",
   "Check",
   "Qsgmii",
   "Number")
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    uint32 qsgmii;

    read_req.opcode = CHECK_QSGMII;
    CLI_GET_HEX_UINT32_RANGE(CLI_COUNT_DESC, qsgmii, argv[0], 0, 11);
    read_req.chip = qsgmii;
    
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Qsgmii is down\n");
        return CLI_ERROR;
    }
    cli_out(cli, "Qsgmii is up\n");
    return CLI_SUCCESS;
}

CLI(diag_read_gbvtss8211,
    diag_read_gbvtss8211_cmd,
    "read gbvtss8211 PHY_OFFSET_REG",
    CLI_READ_DESC,
    "PHY VTSS8211 connect to GB",
    CLI_ADDRESS_DESC)
{
    int32 ret = 0; 
    uint32 address = 0;  
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFF);
 
    read_req.opcode = REG_GBVTSS8211_R;
    read_req.addr = address; 
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read GBVTSS8211 fail.\n");
        return CLI_ERROR;
    } 
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x:\t0x%02x\n",  buf[0].addr, buf[0].value);
 
    return CLI_SUCCESS;
}

CLI(diag_write_gbvtss8211,
    diag_write_gbvtss8211_cmd,
    "write gbvtss8211 PHY_OFFSET_REG VALUE",
    CLI_WRITE_DESC,
    "PHY VTSS8211 connect to GB",
    CLI_ADDRESS_DESC,
    "Value")
{
    int32 ret = 0;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE("Value", value, argv[1], 0, 0xFFFF);

    write_req.opcode = REG_GBVTSS8211_W;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write GBVTSS8211 fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}


CLI(diag_read_gephy,
    diag_read_gephy_cmd,
    "read gephy PORTID ADDRESS (<1-64>|)",
    CLI_READ_DESC,
    CLI_GEPHY_DESC,
    CLI_PORT_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint32 ii;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_GEPHY_R;
    read_req.chip = port;
    read_req.addr = address;
    read_req.count = count;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read gephy fail.\n");
        return CLI_ERROR;
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }
    return CLI_SUCCESS;
}

CLI(diag_write_gephy,
    diag_write_gephy_cmd,
    "write gephy PORTID ADDRESS VALUE",
    CLI_WRITE_DESC,
    CLI_GEPHY_DESC,
    CLI_PORT_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_SHORT_VALUE_DESC)
{
    int32 ret = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[2], 0, 0xFFFF);

    write_req.opcode = REG_GEPHY_W;
    write_req.chip = port;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write gephy fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_read_ad9517,
    diag_read_ad9517_cmd,
    "read ad9517 <0-0> REG (direct|indirect) (<1-64>|)",
    CLI_READ_DESC,
    CLI_AD9517_DESC,    
    CLI_AD9517_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_AD9517_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0x232);
    if (0 == sal_strncmp(argv[2], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    if(argc >= 4)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[3], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_AD9517_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read ad9517 fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%08x:\t0x%08x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_ad9517,
    diag_write_ad9517_cmd,
    "write ad9517 <0-0> REG VALUE (direct|indirect)",
    CLI_WRITE_DESC,
    CLI_AD9517_DESC,    
    CLI_AD9517_IDX_DESC,
    CLI_ADDRESS_DESC,    
    CLI_BYTE_VALUE_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value; 
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_AD9517_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0x232);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);
    if (0 == sal_strncmp(argv[3], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    

    write_req.opcode = REG_AD9517_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    write_req.indirect= indirect;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write ad9517 fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_ds3104,
    diag_read_ds3104_cmd,
    "read ds3104 <0-2> REG (direct|indirect) (<1-64>|)",
    CLI_READ_DESC,
    CLI_DS3104_DESC,    
    CLI_DS3104_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_DS3104_IDX_DESC, chip, argv[0], 0, 2);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0x232);
    if (0 == sal_strncmp(argv[2], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    if(argc >= 4)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[3], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_DS3104_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read ds3104 fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%x:\t0x%x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_ds3104,
    diag_write_ds3104_cmd,
    "write ds3104 <0-2> REG VALUE (direct|indirect)",
    CLI_WRITE_DESC,
    CLI_DS3104_DESC,    
    CLI_DS3104_IDX_DESC,
    CLI_ADDRESS_DESC,    
    CLI_BYTE_VALUE_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value; 
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_DS3104_DESC, chip, argv[0], 0, 2);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0x232);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);
    if (0 == sal_strncmp(argv[3], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    

    write_req.opcode = REG_DS3104_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    write_req.indirect= indirect;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write ds3104 fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_l2switch,
    diag_read_l2switch_cmd,
    "read l2switch <0-0> BLOCK SUB REG (direct|indirect) (<1-64>|)",
    CLI_READ_DESC,
    CLI_L2SWITCH_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_L2SWITCH_BLK_DESC,
    CLI_L2SWITCH_SUB_DESC,
    CLI_L2SWITCH_REG_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 block = 0;
    uint32 sub = 0;
    uint32 reg = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, MAX_L2SWITCH_ID_PER_BOARD);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_BLK_DESC, block, argv[1], 0, 0x7);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_SUB_DESC, sub, argv[2], 0, 0xF);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_REG_DESC, reg, argv[3], 0, 0xFF);
    if (0 == sal_strncmp(argv[4], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    if(argc >= 6)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[5], 1, LCAPI_LCM_LCSH_REG_NUM);
    }
    address = ((block&0x7)<<12) | ((sub&0xf)<<8) | (reg&0xff);
    
    read_req.opcode = REG_L2SWITCH_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read l2switch register fail.\n");
        return CLI_ERROR;
    }
    
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%x:\t0x%x\n", buf[i].addr, buf[i].value);
    }

    return CLI_SUCCESS;
}

CLI(diag_write_l2switch,
    diag_write_l2switch_cmd,
    "write l2switch <0-0> BLOCK SUB REG VALUE (direct|indirect)",
    CLI_WRITE_DESC,
    CLI_L2SWITCH_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_L2SWITCH_BLK_DESC,
    CLI_L2SWITCH_SUB_DESC,
    CLI_L2SWITCH_REG_DESC,
    CLI_DWORD_VALUE_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 block = 0;
    uint32 sub = 0;
    uint32 reg = 0;
    uint32 address = 0;
    uint32 value = 0;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, MAX_L2SWITCH_ID_PER_BOARD);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_BLK_DESC, block, argv[1], 0, 0x7);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_SUB_DESC, sub, argv[2], 0, 0xF);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_REG_DESC, reg, argv[3], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_DWORD_VALUE_DESC, value, argv[4], 0, 0xFFFFFFFF);
    if (0 == sal_strncmp(argv[5], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    address = ((block&0x7)<<12) | ((sub&0xf)<<8) | (reg&0xff);

    write_req.opcode = REG_L2SWITCH_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    write_req.indirect= indirect;
    
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write l2switch register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}



CLI(diag_read_l2switch_phy,
    diag_read_l2switch_phy_cmd,
    "read l2switch phy <0-0> PORTID REG (direct|indirect)",
    CLI_READ_DESC,
    CLI_L2SWITCH_DESC,    
    CLI_PHY_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_PORT_IDX_DESC,
    CLI_L2SWITCH_REG_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32  port_id = 0;
    uint32  reg = 0;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE(CLI_L2SWITCH_PORT_DESC, port_id, argv[1], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_REG_DESC, reg, argv[2], 0, 0xFF);
    if (0 == sal_strncmp(argv[3], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    read_req.opcode = REG_L2SWITCH_PHY_R;
    read_req.chip = chip;
    read_req.addr = port_id;
    read_req.addr_1= reg;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read l2switch phy register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "l2switch phy port %d \t0x%x:\t0x%x\n", port_id, reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_l2switch_phy,
    diag_write_l2switch_phy_cmd,
    "write l2switch phy <0-0> PORTID REG VALUE (direct|indirect)",
    CLI_WRITE_DESC,
    CLI_L2SWITCH_DESC,    
    CLI_PHY_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_PORT_IDX_DESC,
    CLI_L2SWITCH_REG_DESC,
    CLI_SHORT_VALUE_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int ret = 0;
    uint32_t chip = 0;
    uint32_t port_id = 0;
    uint32_t reg = 0;
    uint32_t value = 0;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE(CLI_L2SWITCH_PORT_DESC, port_id, argv[1], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_L2SWITCH_REG_DESC, reg, argv[2], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[3], 0, 0xFFFF);
    if (0 == sal_strncmp(argv[4], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    write_req.opcode = REG_L2SWITCH_PHY_W;
    write_req.chip = chip;
    write_req.addr = port_id;
    write_req.addr_1= reg;
    write_req.value = value;
    write_req.indirect= indirect;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write l2switch phy register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_show_l2switch_stats,
    diag_show_l2switch_stats_cmd,
    "show l2switch stats <0-0> (direct|indirect) (PORTID|)",
    CLI_SHOW_DESC,
    CLI_L2SWITCH_DESC,    
    CLI_STATS_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_PORT_IDX_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 port = 0;
    uint8 count = 0;
    uint8 indirect = 0;
    uint32 i = 0;    
    lcapi_lcm_lcsh_msg_t st_rcv;  
    l2switch_stats_t *p_l2switch_stats;
    l2switch_dump_t l2switch_dump;
    char buf[100];
    
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&l2switch_dump, 0, sizeof(l2switch_dump_t));
    
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, 0);
    if (0 == sal_strncmp(argv[1], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_L2SWITCH_PORT_DESC, port, argv[2], 0, 0xFF);
        l2switch_dump.all_port= 0;
    }
    else
    {
        l2switch_dump.all_port= 1;
    }
    
    l2switch_dump.chip = chip;    
    l2switch_dump.port = port;
    l2switch_dump.indirect = indirect;
    
    ret = lcsh_lcm_msg_tx_l2switch_stats(&l2switch_dump, &st_rcv);
    if ( ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "%% Dump l2switch stats fail\n");
        return CLI_ERROR;
    }
    count = (uint8 )(st_rcv.msg[0]);
    p_l2switch_stats = (l2switch_stats_t* )(&(st_rcv.msg[1]));
    cli_out(cli, "NO Rx_packets Rx_bytes   Rx_drop Rx_error Tx_packets Tx_bytes   Tx_drop Tx_error\n");
    cli_out(cli, "-- ---------- ---------- ------- -------- ---------- ---------- ------- --------\n");
    for(i = 0; i < count; i++)
    {
        if((i % 8) == 0)
        {
            cli_out(cli, "-- ---------- ---------- ------- -------- ---------- ---------- ------- --------\n");
        }
        if(argc >= 3)
        {
            cli_out(cli,"%-2d ", port);
        }
        else
        {
            cli_out(cli,"%-2d ", i);
        }
        sprintf(buf,"%-10d",p_l2switch_stats[i].rxPkt);
		cli_out(cli,"%s ",buf);    
		sprintf(buf,"%-10d",p_l2switch_stats[i].rxByte);
		cli_out(cli,"%s ",buf);
		sprintf(buf,"%-7d",p_l2switch_stats[i].rxDrop);
		cli_out(cli,"%s ",buf);
		sprintf(buf,"%-8d",p_l2switch_stats[i].rxErr);
        cli_out(cli,"%s ",buf);
		sprintf(buf,"%-10d",p_l2switch_stats[i].txPkt);
        cli_out(cli,"%s ",buf);
		sprintf(buf,"%-10d",p_l2switch_stats[i].txByte);
        cli_out(cli,"%s ",buf);
		sprintf(buf,"%-7d",p_l2switch_stats[i].txDrop);
        cli_out(cli,"%s ",buf);
		sprintf(buf,"%-8d",p_l2switch_stats[i].txErr);
        cli_out(cli,"%s\n",buf);
    }

    return CLI_SUCCESS;
}

CLI(diag_clear_l2switch_stats,
    diag_clear_l2switch_stats_cmd,
    "clear l2switch stats <0-0> (direct|indirect) (PORTID|)",
    CLI_CLEAR_DESC,
    CLI_L2SWITCH_DESC,    
    CLI_STATS_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_PORT_IDX_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 port = 0;  
    uint8 indirect = 0;
    l2switch_dump_t l2switch_dump;
    lcapi_lcm_lcsh_msg_t st_rcv;  

    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, 0);
    if (0 == sal_strncmp(argv[1], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_L2SWITCH_PORT_DESC, port, argv[2], 0, 0xFF);
        l2switch_dump.all_port= 0;
    }
    else
    {
        l2switch_dump.all_port= 1;
    }
    l2switch_dump.chip = chip;
    
    l2switch_dump.port = port;
    l2switch_dump.indirect = indirect;
    
    ret = lcsh_lcm_msg_tx_clear_l2switch_stats(&l2switch_dump, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "%% Clear fail\n");
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
    
}

CLI(diag_config_l2switch_port,
    diag_config_l2switch_port_cmd,
    "config l2switch <0-0> PORTID (direct|indirect) (enable|disable)",
    CLI_CONFIG_DESC,
    CLI_L2SWITCH_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_PORT_IDX_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_ENABLE_DESC,
    CLI_DISABLE_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 port = 0;  
    uint32 enable = 0; 
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv; 
    write_regs_reg_t write_req;

    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, 0);    
    CLI_GET_INTEGER_RANGE(CLI_L2SWITCH_PORT_DESC, port, argv[1], 0, 0xFF);
    if (0 == sal_strncmp(argv[2], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    if (0 == strncmp (argv[3], "enable", 6))
    {
        enable = 1;
    }
    else
    {
        enable = 0;
    }

    write_req.opcode = REG_CONFIG_L2SWITCH_PORT;
    write_req.chip = chip;
    write_req.addr = port;
    write_req.value= enable;
    write_req.indirect= indirect;
    
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Config l2switch port fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
           
}

CLI(diag_dump_l2switch_key_register,
    diag_dump_l2switch_key_register_cmd,
    "dump l2switch <0-0> PORTID (direct|indirect)",
    CLI_DUMP_DESC,
    CLI_L2SWITCH_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_L2SWITCH_PORT_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32  port_id = 0;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE(CLI_L2SWITCH_PORT_DESC, port_id, argv[1], 0, 0xFF);
    if (0 == sal_strncmp(argv[2], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    read_req.opcode = REG_DUMP_L2SWITCH_REG;
    read_req.chip = chip;
    read_req.addr = port_id;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Dump l2switch key register fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}





CLI(diag_read_xgphy,
    diag_read_xgphy_cmd,
    "read xgphy PORTID DEVICEID ADDRESS (<1-64>|)",
    CLI_READ_DESC,
    CLI_XGPHY_DESC,
    "Index of panel port",
    "Device_id",
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 port = 0;
    uint32 device = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint32 ii;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    CLI_GET_INTEGER_RANGE("Deviceid", device, argv[1], 0, 0x3f);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[2], 0, 0xFFFF);
    address = device * 0x10000 + address;
    if(argc >= 4)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[3], 1, LCAPI_LCM_LCSH_REG_NUM);
    }
    
    read_req.opcode = REG_XGPHY_R;
    read_req.chip = port;
    read_req.addr = address;
    read_req.count = count;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read xgphy fail.\n");
        return CLI_ERROR;
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }
    return CLI_SUCCESS;
}

CLI(diag_write_xgphy,
    diag_write_xgphy_cmd,
    "write xgphy PORTID DEVICE ADDRESS VALUE",
    CLI_WRITE_DESC,
    CLI_XGPHY_DESC,
    CLI_CHIP_IDX_DESC,
    "Device id",
    CLI_ADDRESS_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int32 ret = 0;
    uint32 port = 0;
    uint32 device = 0;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    CLI_GET_INTEGER_RANGE("Deviceid", device, argv[1], 0, 0x3f);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[2], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[3], 0, 0xFFFF);
    address = device * 0x10000 + address;

    write_req.opcode = REG_XGPHY_W;
    write_req.chip = port;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write xgphy fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_read_c45_by_c22,
    diag_read_c45_by_c22_cmd,
    "read c22 BUS PHYADD DEVICEID ADDRESS (<1-64>|)",
    CLI_READ_DESC,
    "Clause 22",
    "Bus",
    "PHY addr",
    "Device_id",
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    int32 bus, phy_addr;
    uint32 device = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint32 ii;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE("Index of bus", bus, argv[0], 0, 255);
    CLI_GET_INTEGER_RANGE("Index of phy addr", phy_addr, argv[1], 0, 255);
    CLI_GET_INTEGER_RANGE("Deviceid", device, argv[2], 0, 0x3f);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[3], 0, 0xFFFF);
    address = device * 0x10000 + address;
    if(argc >= 5)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[4], 1, LCAPI_LCM_LCSH_REG_NUM);
    }
    
    read_req.opcode = REG_C45_BY_C22_R;
    read_req.chip = (bus<<8) + phy_addr;
    read_req.addr = address;
    read_req.count = count;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read phy fail.\n");
        return CLI_ERROR;
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }
    return CLI_SUCCESS;
}

CLI(diag_write_c45_by_c22,
    diag_write_c45_by_c22_cmd,
    "write c22 BUS PHYADD DEVICE ADDRESS VALUE",
    CLI_WRITE_DESC,
    "Clause 22",
    "Bus",
    "Phy addr",
    "Device id",
    CLI_ADDRESS_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int32 ret = 0;
    int32 bus, phy_addr;
    uint32 device = 0;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE("Index of bus", bus, argv[0], 0, 255);
    CLI_GET_INTEGER_RANGE("Index of phy addr", phy_addr, argv[1], 0, 255);
    CLI_GET_INTEGER_RANGE("Deviceid", device, argv[2], 0, 0x3f);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[3], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[4], 0, 0xFFFF);
    address = device * 0x10000 + address;

    write_req.opcode = REG_C45_BY_C22_W;
    write_req.chip = (bus<<8) + phy_addr;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write xgphy fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}


CLI(diag_config_port_speed,
    diag_config_port_speed_cmd,
    "conport speed PORTID SPEED",
    CLI_CONFIG_PORT,
    "port speed",
    CLI_PORT_IDX_DESC,
    "10M | 100M | 1G | 10G | auto")
{
    int32 ret = 0;
    uint32 port = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    lcapi_lcm_lcsh_msg_t st_req;

    conport_t con_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);

    sal_memset(&st_req, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    con_req.port_id = port;
   
    con_req.opcode = CONFIG_SPEED;
    if(!sal_strcmp(argv[1], "10M"))
    {
        con_req.speed = GLB_SPEED_10M;
    }    
    else if(!sal_strcmp(argv[1], "100M"))
    {
        con_req.speed = GLB_SPEED_100M;
    }
    else if(!sal_strcmp(argv[1], "1G"))
    {
        con_req.speed = GLB_SPEED_1G;
    }
    else if(!sal_strcmp(argv[1], "10G"))
    {
        con_req.speed = GLB_SPEED_10G;
    }   
    else if(!sal_strcmp(argv[1], "auto"))
    {
        con_req.speed = GLB_SPEED_AUTO;
    }
    st_req.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    sal_memcpy(st_req.msg, &con_req, sizeof(conport_t));
    st_req.msg_len = sizeof(conport_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    ret = lcsh_clnt_send_msg(&st_req, &st_rcv);
    if (ret)
    {
        cli_out(cli, "Config speed fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_config_port_duplex,
    diag_config_port_duplex_cmd,
    "conport duplex PORTID DUPLEX",
    CLI_CONFIG_PORT,
    "port duplex",
    CLI_PORT_IDX_DESC,
    "auto | half | full")
{
    int32 ret = 0;
    uint32 port = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    lcapi_lcm_lcsh_msg_t st_req;

    conport_t con_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);

    sal_memset(&st_req, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    con_req.port_id = port;

    con_req.opcode = CONFIG_DUPLEX;
    if(!sal_strcmp(argv[1], "auto"))
    {
        con_req.duplex = GLB_DUPLEX_AUTO;
    }    
    else if(!sal_strcmp(argv[1], "half"))
    {
        con_req.duplex = GLB_DUPLEX_HALF;
    }
    else if(!sal_strcmp(argv[1], "full"))
    {
        con_req.duplex = GLB_DUPLEX_FULL;
    }
 
    st_req.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    sal_memcpy(st_req.msg, &con_req, sizeof(conport_t));
    st_req.msg_len = sizeof(conport_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    ret = lcsh_clnt_send_msg(&st_req, &st_rcv);
    if (ret)
    {
        cli_out(cli, "Config duplex fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_config_port_enable,
    diag_config_port_enable_cmd,
    "conport enable PORTID ENABLE",
    CLI_CONFIG_PORT,
    "enable or diable",
    CLI_PORT_IDX_DESC,
    "enable | disable")
{
    int32 ret = 0;
    uint32 port = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    lcapi_lcm_lcsh_msg_t st_req;

    conport_t con_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);

    sal_memset(&st_req, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    con_req.port_id = port;
    con_req.opcode = CONFIG_ENABLE;
    if(!sal_strcmp(argv[1], "enable"))
    {
        con_req.enable = 1;
    }    
    else if(!sal_strcmp(argv[1], "disable"))
    {
        con_req.enable = 0;
    }
 
    st_req.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    sal_memcpy(st_req.msg, &con_req, sizeof(conport_t));
    st_req.msg_len = sizeof(conport_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    ret = lcsh_clnt_send_msg(&st_req, &st_rcv);
    if (ret)
    {
        cli_out(cli, "Config enable fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_config_port_lb,
    diag_config_port_lb_cmd,
    "conport lb PORTID LBACK",
    CLI_CONFIG_PORT,
    "config loopback mode",
    CLI_PORT_IDX_DESC,
    "none | near | far")
{
    int32 ret = 0;
    uint32 port = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    lcapi_lcm_lcsh_msg_t st_req;

    conport_t con_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);

    sal_memset(&st_req, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    con_req.port_id = port;
    con_req.opcode = CONFIG_LB;
    if(!sal_strcmp(argv[1], "none"))
    {
        con_req.loopback = GLB_LB_NONE;
    }    
    else if(!sal_strcmp(argv[1], "near"))
    {
        con_req.loopback = GLB_LB_PHY_NEAR;
    }    
    else if(!sal_strcmp(argv[1], "far"))
    {
        con_req.loopback = GLB_LB_PHY_FAR;
    }

    st_req.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    sal_memcpy(st_req.msg, &con_req, sizeof(conport_t));
    st_req.msg_len = sizeof(conport_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    ret = lcsh_clnt_send_msg(&st_req, &st_rcv);
    if (ret)
    {
        cli_out(cli, "Config loopback mode fail.");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_config_port_media,
    diag_config_port_media_cmd,
    "conport media PORTID MEDIA",
    CLI_CONFIG_PORT,
    "config media type",
    CLI_PORT_IDX_DESC,
    "RJ45 | SFP | AUTO")
{
    int32 ret = 0;
    uint32 port = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    lcapi_lcm_lcsh_msg_t st_req;

    conport_t con_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);

    sal_memset(&st_req, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    con_req.port_id = port;
    con_req.opcode = CONFIG_MEDIA;
    if(!sal_strcmp(argv[1], "RJ45"))
    {
        con_req.media_type = GLB_PORT_TYPE_COPPER;
    }    
    else if(!sal_strcmp(argv[1], "SFP"))
    {
        con_req.media_type = GLB_PORT_TYPE_FIBER;
    }    
    else if(!sal_strcmp(argv[1], "AUTO"))
    {
        con_req.media_type = GLB_PORT_TYPE_AUTO;
    }
    st_req.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    sal_memcpy(st_req.msg, &con_req, sizeof(conport_t));
    st_req.msg_len = sizeof(conport_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    ret = lcsh_clnt_send_msg(&st_req, &st_rcv);
    if (ret)
    {
        cli_out(cli, "Config media fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;
}

CLI(diag_read_xfp,
    diag_read_xfp_cmd,
    "read xfp PORTID ADDRESS (<1-64>|)",
    CLI_READ_DESC,
    CLI_FIBER_DESC,
    CLI_PORT_IDX_DESC,
    "Address 0x0-0xff",
    CLI_COUNT_DESC)
{
    reg_values_t* buf;
    read_regs_reg_t read_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 ii = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 count = 1;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    if (argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }
    read_req.opcode = REG_XFP_R;
    read_req.chip = port;
    read_req.addr = address;
    read_req.count = count;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read xfp fail.\n");
        return CLI_ERROR;
    }
    cli_out(cli, "Read xfp ok\n");
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }


    return CLI_SUCCESS;
}

CLI(diag_read_sfp,
    diag_read_sfp_cmd,
    "read sfp (basic|extend|phy) PORTID ADDRESS (<1-64>|)",
    CLI_READ_DESC,
    CLI_FIBER_DESC,
    "basic register",
    "extend register",
    "phy register",
    CLI_PORT_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    reg_values_t* buf;
    read_regs_reg_t read_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 ii = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 count = 1;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[1], 1, BOARD_MAX_PORT);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[2], 0, 0xFFFF);
    if(argc >= 4)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[3], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    if ((sal_strncmp (argv[0], "basic", 5) == 0))
    {
        address |= 0x100;
    }
    else if ((sal_strncmp (argv[0], "extend", 6) == 0))
    {
        address |= 0x200;
    }
    else if((sal_strncmp (argv[0], "phy", 3) == 0))
    {
        address |= 0x300;
        count = count*2;
    }
    
    read_req.opcode = REG_SFP_R;
    read_req.chip = port;
    read_req.addr = address;
    read_req.count = count;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read sfp fail.\n");
        return CLI_ERROR;
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }
    
    return CLI_SUCCESS;
}

CLI(diag_write_sfp,
    diag_write_sfp_cmd,
    "write sfp (basic|extend|phy) PORTID ADDRESS VALUE",
    CLI_WRITE_DESC,
    CLI_FIBER_DESC,
    "basic register",
    "extend register",
    "phy register",
    CLI_PORT_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_SHORT_VALUE_DESC)
{
    write_regs_reg_t write_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 value;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[1], 1, BOARD_MAX_PORT);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[2], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[3], 0, 0xffff);


    if ((sal_strncmp (argv[0], "basic", 5) == 0))
    {
        address |= 0x100;
    }
    else if ((sal_strncmp (argv[0], "extend", 6) == 0))
    {
        address |= 0x200;
    }
    else if((sal_strncmp (argv[0], "phy", 3) == 0))
    {
        address |= 0x300;
    }
    
    write_req.opcode = REG_SFP_W;
    write_req.chip = port;
    write_req.addr = address;
    write_req.value = value;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write SFP fail.\n");
        return CLI_ERROR;
    }    
    return CLI_SUCCESS;
}

CLI(diag_read_poe_port,
    diag_read_poe_port_cmd,
    "read poe PORTID ADDRESS",
    CLI_READ_DESC,
    CLI_POE_DESC,
    CLI_PORT_IDX_DESC,
    CLI_ADDRESS_DESC)
{
    reg_values_t* buf;
    read_regs_reg_t read_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 count = 0;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, 48);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);

    sal_memset(&read_req, 0, sizeof(read_regs_reg_t));
    /* if poe port, port !=0, else poe sys, port == 0 */
    read_req.opcode = REG_POE_R;
    read_req.chip = port;
    read_req.addr = address;
    read_req.count = 2;
    
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read poe port fail.\n");
        return CLI_ERROR;
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    if(count != 1)
    {
        cli_out(cli, "Read poe system fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);

    cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[0].addr, buf[0].value);

    return CLI_SUCCESS;
}

CLI(diag_write_poe_port,
    diag_write_poe_port_cmd,
    "write poe PORTID ADDRESS VALUE",
    CLI_WRITE_DESC,
    CLI_POE_DESC,
    CLI_PORT_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_SHORT_VALUE_DESC)
{
    write_regs_reg_t write_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 port = 0;
    uint32 address = 0;
    uint32 value;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, 48);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xffff);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[2], 0, 0xffff);

    sal_memset(&write_req, 0, sizeof(write_regs_reg_t));
    /* if poe port, port !=0, else poe sys, port == 0 */    
    write_req.opcode = REG_POE_W;
    write_req.chip = port;
    write_req.addr = address;
    write_req.value = value;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write SFP fail.\n");
        return CLI_ERROR;
    }    
    return CLI_SUCCESS;
}


CLI(diag_read_poe_sys,
    diag_read_poe_sys_cmd,
    "read poe sys ADDRESS",
    CLI_READ_DESC,
    CLI_POE_DESC,
    "system",
    CLI_ADDRESS_DESC)
{
    reg_values_t* buf;
    read_regs_reg_t read_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 address = 0;
    uint32 count = 0;

    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFF);

    sal_memset(&read_req, 0, sizeof(read_regs_reg_t));
    /* if poe port, port !=0, else poe sys, port == 0 */
    read_req.opcode = REG_POE_R;
    read_req.chip = 0;
    read_req.addr = address;
    read_req.count = 2;
    
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read poe system fail.\n");
        return CLI_ERROR;
    }
    
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    if(count != 1)
    {
        cli_out(cli, "Read poe system fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    
    cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[0].addr, buf[0].value);
   
    return CLI_SUCCESS;
}

CLI(diag_write_poe_sys,
    diag_write_poe_sys_cmd,
    "write poe sys ADDRESS VALUE",
    CLI_WRITE_DESC,
    CLI_POE_DESC,
    "system",
    CLI_ADDRESS_DESC,
    CLI_SHORT_VALUE_DESC)
{
    write_regs_reg_t write_req;
    lcapi_lcm_lcsh_msg_t st_rcv;
    int ret = 0;
    uint32 address = 0;
    uint32 value;

    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xffff);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[1], 0, 0xffff);

    sal_memset(&write_req, 0, sizeof(write_regs_reg_t));
    /* if poe port, port !=0, else poe sys, port == 0 */    
    write_req.opcode = REG_POE_W;
    write_req.chip = 0;
    write_req.addr = address;
    write_req.value = value;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write SFP fail.\n");
        return CLI_ERROR;
    }    
    return CLI_SUCCESS;
}

CLI(diag_read_epld,
    diag_read_epld_cmd,
    "read epld <0-0> REG (<1-64>|)",
    CLI_READ_DESC,
    CLI_EPLD_DESC,    
    CLI_EPLD_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_EPLD_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_EPLD_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read EPLD fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%04x:\t0x%02x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_epld,
    diag_write_epld_cmd,
    "write epld <0-0> REG VALUE",
    CLI_WRITE_DESC,
    CLI_EPLD_DESC,    
    CLI_EPLD_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value = 0; 
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_AD9517_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);

    write_req.opcode = REG_EPLD_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write EPLD fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_load_xgphy,
    diag_load_xgphy_cmd,
    "load xgphy PORTID",
    "Load fireware",
    CLI_XGPHY_DESC,
    "Index of panel port")
{
    int32 ret = 0;
    uint32 port = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    read_req.opcode = REG_XGPHY_LOAD;
    read_req.chip = port;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "load xgphy fail\n");
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CLI(diag_read_humber,
    diag_read_humber_cmd,
    "read gb <0-1> ADDRESS (NUM|)",
    CLI_READ_DESC,
    CLI_HUMBER_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ii, ret = 0;
    uint32 chip = 0;
    uint32 address;
    uint8 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE("Max GB ID", chip, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_COUNT_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }
    
    read_req.opcode = REG_HUMBER_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Read humber failed\n");
        return CLI_ERROR;
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }

    return CLI_SUCCESS;
}

CLI(diag_write_humber,
    diag_write_humber_cmd,
    "write gb <0-1> ADDRESS VALUE",
    CLI_WRITE_DESC,
    CLI_HUMBER_DESC,
    CLI_CHIP_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_DWORD_VALUE_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, chip, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[2], 0, 0xFFFFFFFF);

    write_req.opcode = REG_HUMBER_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write humber fail.\n");
        return CLI_ERROR;
    }
    
    return CLI_SUCCESS;

}

CLI(diag_read_sensor,
    diag_read_sensor_cmd,
    "read sensor <0-5> REG LEN",
    CLI_READ_DESC,
    CLI_SENSOR_DESC,    
    CLI_SENSOR_IDX_DESC,
    CLI_SENSOR_REG_DESC,
    CLI_SENSOR_REG_LEN_DESC)
{
    int32 ret = 0;
    uint32 sensor_idx = 0;
    uint32  reg = 0;
    uint32  len;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_SENSOR_IDX_DESC, sensor_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_SENSOR_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_SENSOR_REG_LEN_DESC, len, argv[2], 0, 0xff);
    
    read_req.opcode = REG_SENSOR_R;
    read_req.chip = sensor_idx;
    read_req.addr= reg;
    read_req.count = len;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read sensor register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x:\t0x%02x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_sensor,
    diag_write_sensor_cmd,
    "write sensor <0-5> REG VALUE",
    CLI_WRITE_DESC,
    CLI_SENSOR_DESC,    
    CLI_SENSOR_IDX_DESC,
    CLI_SENSOR_REG_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int ret = 0;
    uint32_t sensor_idx = 0;
    uint32_t reg = 0;
    uint32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_SENSOR_IDX_DESC, sensor_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_SENSOR_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xffff);

    write_req.opcode = REG_SENSOR_W;
    write_req.chip = sensor_idx;
    write_req.addr= reg;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write sensor register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_sensor_temp,
    diag_read_sensor_temp_cmd,
    "read sensor <0-5> type TYPE",
    CLI_READ_DESC,
    CLI_SENSOR_DESC,    
    CLI_SENSOR_IDX_DESC,
    CLI_SENSOR_TYPE_DESC,
    CLI_SENSOR_TYPE_DESC)
{
    int32 ret = 0;
    uint32 sensor_idx = 0;
    uint32  type = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_SENSOR_IDX_DESC, sensor_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_SENSOR_TYPE_DESC, type, argv[1], 0, 0xff);
    
    read_req.opcode = REG_SENSOR_TMP_R;
    read_req.chip = sensor_idx;
    read_req.addr= type;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read sensor register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x:\t%d\n", type, (int8)(buf[0].value));
    
    return CLI_SUCCESS;
}

CLI(diag_write_sensor_temp,
    diag_write_sensor_temp_cmd,
    "write sensor <0-5> type TYPE VALUE",
    CLI_WRITE_DESC,
    CLI_SENSOR_DESC,    
    CLI_SENSOR_IDX_DESC,
    CLI_SENSOR_TYPE_DESC,
    CLI_SENSOR_TYPE_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int ret = 0;
    uint32_t sensor_idx = 0;
    uint32_t type = 0;
    int32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_SENSOR_IDX_DESC, sensor_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_SENSOR_TYPE_DESC, type, argv[1], 0, 0xff);
    CLI_GET_INTEGER(CLI_BYTE_VALUE_DESC, value, argv[2]);

    write_req.opcode = REG_SENSOR_TMP_W;
    write_req.chip = sensor_idx;
    write_req.addr= type;
    write_req.value = (uint32_t)value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write sensor register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_gpio,
    diag_read_gpio_cmd,
    "read gpio <0-4> REG LEN",
    CLI_READ_DESC,
    CLI_GPIO_CHIP_DESC,    
    CLI_GPIO_CHIP_IDX_DESC,
    CLI_GPIO_CHIP_REG_DESC,
    CLI_GPIO_CHIP_REG_LEN_DESC)
{
    int32 ret = 0;
    uint32 gpio_chip_idx = 0;
    uint32  reg = 0;
    uint32  len;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_GPIO_CHIP_IDX_DESC, gpio_chip_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_GPIO_CHIP_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_GPIO_CHIP_REG_LEN_DESC, len, argv[2], 0, 0xff);
    
    read_req.opcode = REG_GPIO_CHIP_R;
    read_req.chip = gpio_chip_idx;
    read_req.addr= reg;
    read_req.count = len;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read gpio chip register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x:\t0x%02x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_gpio,
    diag_write_gpio_cmd,
    "write gpio <0-3> REG VALUE",
    CLI_WRITE_DESC,
    CLI_GPIO_CHIP_DESC,    
    CLI_GPIO_CHIP_IDX_DESC,
    CLI_GPIO_CHIP_REG_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int ret = 0;
    uint32_t gpio_chip_idx = 0;
    uint32_t reg = 0;
    uint32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_GPIO_CHIP_IDX_DESC, gpio_chip_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_GPIO_CHIP_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xffff);

    write_req.opcode = REG_GPIO_CHIP_W;
    write_req.chip = gpio_chip_idx;
    write_req.addr= reg;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write gpio chip register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_mux,
    diag_read_mux_cmd,
    "read mux <0-1> REG LEN",
    CLI_READ_DESC,
    CLI_MUX_CHIP_DESC,    
    CLI_MUX_CHIP_IDX_DESC,
    CLI_MUX_CHIP_REG_DESC,
    CLI_MUX_CHIP_REG_LEN_DESC)
{
    int32 ret = 0;
    uint32 mux_chip_idx = 0;
    uint32  reg = 0;
    uint32  len;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_MUX_CHIP_IDX_DESC, mux_chip_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_MUX_CHIP_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_MUX_CHIP_REG_LEN_DESC, len, argv[2], 0, 0xff);
    
    read_req.opcode = REG_MUX_CHIP_R;
    read_req.chip = mux_chip_idx;
    read_req.addr= reg;
    read_req.count = len;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read mux chip register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x:\t0x%02x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_mux,
    diag_write_mux_cmd,
    "write mux <0-1> REG VALUE",
    CLI_WRITE_DESC,
    CLI_MUX_CHIP_DESC,    
    CLI_MUX_CHIP_IDX_DESC,
    CLI_MUX_CHIP_REG_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int ret = 0;
    uint32_t mux_chip_idx = 0;
    uint32_t reg = 0;
    uint32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_MUX_CHIP_IDX_DESC, mux_chip_idx, argv[0], 0, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_MUX_CHIP_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xffff);

    write_req.opcode = REG_MUX_CHIP_W;
    write_req.chip = mux_chip_idx;
    write_req.addr= reg;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write mux chip register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CLI(diag_read_fan,
    diag_read_fan_cmd,
    "read fan MODULE REG",
    CLI_READ_DESC,
    CLI_FAN_DESC,
    CLI_FAN_IDX_DESC,
    CLI_FAN_REG_DESC)
{
    int32 ret = 0;
    uint32 fan_idx = 0;
    uint32  reg = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_FAN_IDX_DESC, fan_idx, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_FAN_REG_DESC, reg, argv[1], 0, 0xff);
    
    read_req.opcode = REG_FAN_R;
    read_req.chip = fan_idx;
    read_req.addr= reg;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read fan register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x:\t0x%02x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_fan,
    diag_write_fan_cmd,
    "write fan MODULE REG VALUE",
    CLI_WRITE_DESC,
    CLI_FAN_DESC,    
    CLI_FAN_IDX_DESC,
    CLI_FAN_REG_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int ret = 0;
    uint32_t fan_idx = 0;
    uint32_t reg = 0;
    uint32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_FAN_IDX_DESC, fan_idx, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_FAN_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xff);

    write_req.opcode = REG_FAN_W;
    write_req.chip = fan_idx;
    write_req.addr= reg;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write fan register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_power,
    diag_read_power_cmd,
    "read power MODULE REG LEN",
    CLI_READ_DESC,
    CLI_POWER_DESC,
    CLI_POWER_IDX_DESC,
    CLI_POWER_REG_DESC,
    CLI_REG_DATA_LEN)
{
    uint32 i;
    uint32 data_len;
    int32 ret = 0;
    uint32 power_idx = 0;
    uint32  reg = 0;
    uint32 len = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_POWER_IDX_DESC, power_idx, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_POWER_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_REG_DATA_LEN, len, argv[2], 0, 0xff);
    
    read_req.opcode = REG_PSU_R;
    read_req.chip = power_idx;
    read_req.addr= reg;
    read_req.count= len;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read power register fail.\n");
        return CLI_ERROR;
    }

    data_len = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < len; i++)
    {
        cli_out (cli, "\t0x%04x:\t0x%02x\n", buf[i].addr, buf[i].value);
    }
    
    return CLI_SUCCESS;
}

CLI(diag_write_power,
    diag_write_power_cmd,
    "write power MODULE REG VALUE",
    CLI_WRITE_DESC,
    CLI_POWER_DESC,    
    CLI_POWER_IDX_DESC,
    CLI_POWER_REG_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int ret = 0;
    uint32_t power_idx = 0;
    uint32_t reg = 0;
    uint32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_POWER_IDX_DESC, power_idx, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_POWER_REG_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xff);

    write_req.opcode = REG_PSU_W;
    write_req.chip = power_idx;
    write_req.addr= reg;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write power register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}



CLI(diag_read_vsc3308,
    diag_read_vsc3308_cmd,
    "read vsc3308 CHIP_ID REG (<1-64>|)",
    CLI_READ_DESC,
    CLI_VSC3308_DESC,
	CLI_VSC3308_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
	uint32 i = 0;
    uint32 reg = 0;
    uint32 chip = 0;
	uint32 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;

    CLI_GET_HEX_UINT32_RANGE(CLI_VSC3308_DESC, chip, argv[0], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_VSC3308_DESC, reg, argv[1], 0, 0xff);
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }
    
    read_req.opcode = REG_VSC3308_R;
    read_req.chip = chip;
    read_req.addr= reg;
    read_req.count = count;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read VSC3308 register fail.\n");
        return CLI_ERROR;
    }
    
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%04x:\t0x%02x\n", buf[i].addr, buf[i].value);
	}
    
    return CLI_SUCCESS;
}

CLI(diag_write_vsc3308,
    diag_write_vsc3308_cmd,
    "write vsc3308 CHIP_ID REG VALUE",
    CLI_READ_DESC,
    CLI_VSC3308_DESC,
    CLI_VSC3308_IDX_DESC,
    CLI_ADDRESS_DESC,
    "Write data")
{
    int ret = 0;
    uint32_t reg = 0;
    uint32_t chip = 0;
    uint32_t value = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_VSC3308_DESC, chip, argv[0], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_VSC3308_DESC, reg, argv[1], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xff);

    write_req.opcode = REG_VSC3308_W;
    write_req.chip = chip;
    write_req.addr= reg;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Write VSC3308 register fail.\n");
        return CLI_ERROR;
    }
    return RESULT_OK;
}

CLI(diag_config_vsc3308_input_output_pin,
    diag_config_vsc3308_input_output_pin_cmd,
    "config vsc3308 CHIP_ID input INPUT_PIN output OUTPUT_PIN",
    "Configure",
    CLI_VSC3308_DESC,  
    CLI_VSC3308_IDX_DESC,
    "Input",
    "Input Pin <0-7>",
    "Output",
    "Output Pin <0-7>")
{
    int ret = 0;
    uint32 chip = 0;
    uint32 input_pin, output_pin;/* modified by cuixl, from uint8 to uint32*/
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;

    CLI_GET_HEX_UINT32_RANGE(CLI_VSC3308_DESC, chip, argv[0], 0, 0xff);
    CLI_GET_INTEGER_RANGE("Input pin", input_pin, argv[1], 0, 7);
    CLI_GET_INTEGER_RANGE("Output pin", output_pin, argv[2], 0, 7);

    write_req.opcode = REG_VSC3308_CONF;
    write_req.chip = chip;
    write_req.addr = input_pin;
    write_req.addr_1 = output_pin;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Configure VSC3308 register fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_config_phy_clock,
    diag_config_phy_clock_cmd,
    "config phy-clock PORTID CLK_PORT CLK-SEL CLK-FREQ CLK-SQUELCH",
    "Configure",
    "PHY clock",
    CLI_PORT_IDX_DESC,
    "Clock port <0-1>",
    CLI_PHY_CLK_SEL,
    CLI_PHY_CLK_FREQ,
    CLI_PHY_CLK_SQUELCH)
{
    int ret = 0;
    uint32 port = 0;
    uint32 phy_clk_port;
    uint32 phy_clk_sel;
    uint32 phy_clk_freq;
    uint32 phy_clk_squelch;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, port, argv[0], 1, BOARD_MAX_PORT);
    CLI_GET_INTEGER_RANGE("Clock port <0-1>", phy_clk_port, argv[1], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_PHY_CLK_SEL, phy_clk_sel, argv[2], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_PHY_CLK_FREQ, phy_clk_freq, argv[3], 0, 0xff);
    CLI_GET_HEX_UINT32_RANGE(CLI_PHY_CLK_SQUELCH, phy_clk_squelch, argv[4], 0, 0xff);

    write_req.opcode = REG_PHY_CLK_CONF;
    write_req.chip = port;
    write_req.addr = phy_clk_port;
    write_req.value = (phy_clk_sel<<16)|(phy_clk_freq)<<8|phy_clk_squelch;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli, "Configure phy clock fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}


CLI(diag_read_eeprom,
    diag_read_eeprom_cmd,
    "read eeprom <0-1> REG (<1-64>|)",
    CLI_READ_DESC,
    CLI_EEPROM_DESC,    
    CLI_EEPROM_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_EEPROM_DESC, chip, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_EEPROM_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read eeprom fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%04x:\t0x%02x\t(%c)\n", buf[i].addr, buf[i].value, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_eeprom,
    diag_write_eeprom_cmd,
    "write eeprom <0-1> REG VALUE",
    CLI_WRITE_DESC,
    CLI_EEPROM_DESC,    
    CLI_EEPROM_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value; 
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_EEPROM_DESC, chip, argv[0], 0, 1);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);

    write_req.opcode = REG_EEPROM_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write eeprom fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_i2c,
    diag_read_i2c_cmd,
    "read i2c I2C_BUS_IDX ADDR REG REGLEN DATALEN",
    CLI_READ_DESC,
    CLI_I2C_DESC,    
    "Index of i2c bus",
    "Addr of i2c",
    "Register in i2c component",
    "Register length",
    "Read data length")
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 address;/* modified by cuixl, from uint8 to uint32*/
    uint32 reg; 
    uint32 reg_len;/* modified by cuixl, from uint8 to uint32*/
    uint32 data_len;/* modified by cuixl, from uint8 to uint32*/
    /* Added by qicx for bug 21474: 2012-11-27 */
    uint32 i2c_bus_idx;
    lcapi_lcm_lcsh_msg_t st_rcv;/* modified by cuixl, from uint8 to uint32*/
    read_regs_reg_t read_req;
    reg_values_t* buf;

    /* Added by qicx for bug 21474: 2012-11-27 */
    CLI_GET_HEX_UINT32_RANGE("Index of i2c bus", i2c_bus_idx, argv[0], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE("Register", reg, argv[2], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE("Length of the register", reg_len, argv[3], 0, 0xFFFF);
    CLI_GET_INTEGER_RANGE("Length of the data", data_len, argv[4], 1, LCAPI_LCM_LCSH_REG_NUM);

    read_req.opcode = REG_I2C_R;
    read_req.chip = address;
    read_req.addr = reg;
    /* increase one more parameter "i2c_bus_idx(8-bit variable)", use the last 8-bit of "req_msg->addr_1" */
    read_req.addr_1 = (reg_len<<8) | i2c_bus_idx;
    read_req.count = data_len;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read IIC fail\n");
        return CLI_ERROR;
    }

    data_len = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < data_len; i++)
    {
        cli_out (cli, "\t0x%04x:\t0x%02x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_i2c,
    diag_write_i2c_cmd,
    "write i2c I2C_BUS_IDX ADDR REG REGLEN DATA DATALEN",
    CLI_WRITE_DESC,
    CLI_I2C_DESC,    
    "Index of i2c bus",
    "Addr of i2c",
    "Register in i2c component",
    "Register length",
    "Write data",
    "Data length, unit is byte")
{
    int32 ret = 0;
    uint32 address;/* modified by cuixl, from uint8 to uint32*/
    uint32 reg; 
    uint32 reg_len;/* modified by cuixl, from uint8 to uint32*/
    uint32 data_len;/* modified by cuixl, from uint8 to uint32*/
    /* Added by qicx for bug 21474: 2012-11-27 */
    uint32 i2c_bus_idx;/* modified by cuixl, from uint8 to uint32*/
    uint32 value; /* modified by cuixl, from uint8 to uint32*/
    
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;

    /* Added by qicx for bug 21474: 2012-11-27 */
    CLI_GET_HEX_UINT32_RANGE("Index of i2c bus", i2c_bus_idx, argv[0], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE("Register", reg, argv[2], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE("Length of the register", reg_len, argv[3], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE("Value", value, argv[4], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE("Length of the value", data_len, argv[5], 0, 0xFF);

    write_req.opcode = REG_I2C_W;
    write_req.chip = address;
    write_req.addr = reg;
    /* increase one more parameter "i2c_bus_idx(8-bit variable)", use the last 8-bit of "req_msg->addr_1" */
    write_req.addr_1 = (reg_len<<16) | (data_len<<8) | (i2c_bus_idx);
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write i2c fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}


CLI(diag_read_byte_fpga,
    diag_read_byte_fpga_cmd,
    "read byte fpga REG",
    CLI_READ_DESC,
    CLI_BYTE_VALUE_DESC,    
    CLI_FPGA_DESC,
    CLI_ADDRESS_DESC)
{
    int32 ret = 0;
    uint8 width = 1;/*8bit = 1, 16bit = 2, 32bit = 4*/
    uint32  reg = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, reg, argv[0], 0, 0xFFFF);
    
    read_req.opcode = REG_FPGA_R;
    read_req.chip = width;
    read_req.addr= reg;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read byte fpga register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%02x: 0x%02x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_byte_fpga,
    diag_write_byte_fpga_cmd,
    "write byte fpga REG VALUE",
    CLI_WRITE_DESC,
    CLI_BYTE_VALUE_DESC,    
    CLI_FPGA_DESC,
    CLI_ADDRESS_DESC,
    CLI_BYTE_VALUE_DESC)
{
    int32 ret = 0;
    uint8 width = 1;/*8bit = 1, 16bit = 2, 32bit = 4*/
    uint32 address = 0;
    uint32 value; 
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[1], 0, 0xFF);

    write_req.opcode = REG_FPGA_W;
    write_req.chip = width;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write byte fpga fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_short_fpga,
    diag_read_short_fpga_cmd,
    "read short fpga REG",
    CLI_READ_DESC,
    CLI_SHORT_VALUE_DESC,    
    CLI_FPGA_DESC,
    CLI_ADDRESS_DESC)
{
    int32 ret = 0;
    uint8 width = 2;/*8bit = 1, 16bit = 2, 32bit = 4*/
    uint32  reg = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, reg, argv[0], 0, 0xFFFF);
    
    read_req.opcode = REG_FPGA_R;
    read_req.chip = width;
    read_req.addr= reg;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read short fpga register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%04x: 0x%04x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_short_fpga,
    diag_write_short_fpga_cmd,
    "write short fpga REG VALUE",
    CLI_WRITE_DESC,
    CLI_SHORT_VALUE_DESC,    
    CLI_FPGA_DESC,
    CLI_ADDRESS_DESC,
    CLI_SHORT_VALUE_DESC)
{
    int32 ret = 0;
    uint8 width = 2;/*8bit = 1, 16bit = 2, 32bit = 4*/
    uint32 address = 0;
    uint32 value; 
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[1], 0, 0xFFFF);

    write_req.opcode = REG_FPGA_W;
    write_req.chip = width;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write short fpga fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_dword_fpga,
    diag_read_dword_fpga_cmd,
    "read dword fpga REG",
    CLI_READ_DESC,
    CLI_DWORD_VALUE_DESC,    
    CLI_FPGA_DESC,
    CLI_ADDRESS_DESC)
{
    int32 ret = 0;
    uint8 width = 4;/*8bit = 1, 16bit = 2, 32bit = 4*/
    uint32  reg = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, reg, argv[0], 0, 0xFFFFFFFF);
    
    read_req.opcode = REG_FPGA_R;
    read_req.chip = width;
    read_req.addr= reg;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read dword fpga register fail.\n");
        return CLI_ERROR;
    }
    
    buf = (reg_values_t* )(st_rcv.msg);
    cli_out (cli, "0x%08x: 0x%08x\n",  reg, buf[0].value);
    
    return CLI_SUCCESS;
}

CLI(diag_write_dword_fpga,
    diag_write_dword_fpga_cmd,
    "write dword fpga REG VALUE",
    CLI_WRITE_DESC,
    CLI_DWORD_VALUE_DESC,    
    CLI_FPGA_DESC,
    CLI_ADDRESS_DESC,
    CLI_DWORD_VALUE_DESC)
{
    int32 ret = 0;
    uint8 width = 4;/*8bit = 1, 16bit = 2, 32bit = 4*/
    uint32 address = 0;
    uint32 value; 
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_DWORD_VALUE_DESC, value, argv[1], 0, 0xFFFFFFFF);

    write_req.opcode = REG_FPGA_W;
    write_req.chip = width;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write dword fpga fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

#define BIT_SWAP(x) \
 ((uint8)( \
 (((uint8)(x) &  0x1) << 7) | \
 (((uint8)(x) &  0x2) << 5) | \
 (((uint8)(x) &  0x4) << 3) | \
 (((uint8)(x) &  0x8) << 1) | \
 (((uint8)(x) &  0x10) >> 1) | \
 (((uint8)(x) &  0x20) >> 3) | \
 (((uint8)(x) &  0x40) >> 5) | \
 (((uint8)(x) & 0x80) >>7) ))
 

CLI(diag_read_ds21348,
    diag_read_ds21348_cmd,
    "read ds21348 <0-0> REG (direct|indirect)  (<1-64>|)",
    CLI_READ_DESC,
    CLI_DS21348_DESC,    
    CLI_DS21348_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_DS21348_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFF);

    if (0 == sal_strncmp(argv[2], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    if(argc >= 4)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[3], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_DS21348_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read ds21348 fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        buf[i].value = BIT_SWAP(buf[i].value);
        cli_out (cli, "\t0x%02x:\t0x%02x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_ds21348,
    diag_write_ds21348_cmd,
    "write ds21348 <0-0> REG VALUE (direct|indirect)",
    CLI_WRITE_DESC,
    CLI_DS21348_DESC,    
    CLI_DS21348_IDX_DESC,
    CLI_ADDRESS_DESC,    
    CLI_BYTE_VALUE_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value; 
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_DS21348_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);
       
    if (0 == sal_strncmp(argv[3], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    

    write_req.opcode = REG_DS21348_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    write_req.indirect= indirect;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write ds21348 fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_read_ds26503,
    diag_read_ds26503_cmd,
    "read ds26503 <0-0> REG (<1-64>|)",
    CLI_READ_DESC,
    CLI_DS26503_DESC,    
    CLI_DS26503_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_DS26503_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFF);
    
    if(argc >= 3)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[2], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_DS26503_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    read_req.indirect= 0;

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read ds26503 fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%02x:\t0x%02x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_ds26503,
    diag_write_ds26503_cmd,
    "write ds26503 <0-0> REG VALUE",
    CLI_WRITE_DESC,
    CLI_DS26503_DESC,    
    CLI_DS26503_IDX_DESC,
    CLI_ADDRESS_DESC,    
    CLI_BYTE_VALUE_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value; 
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_DS26503_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);
    
    write_req.opcode = REG_DS26503_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    write_req.indirect= 0;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write ds26503 fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

#if 1	/* chani 20130930 */
CLI(diag_read_ad9559,
    diag_read_ad9559_cmd,
    "read ad9559 <0-0> REG (direct|indirect) (<1-64>|)",
    CLI_READ_DESC,
    CLI_AD9559_DESC,    
    CLI_AD9559_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC,
    CLI_COUNT_DESC)
{
    int32 ret = 0;
    uint32 i = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 count = 1;
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_INTEGER_RANGE(CLI_AD9559_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFF);
    if (0 == sal_strncmp(argv[2], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    
    if(argc >= 4)
    {
        CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[3], 1, LCAPI_LCM_LCSH_REG_NUM);
    }

    read_req.opcode = REG_AD9559_R;
    read_req.chip = chip;
    read_req.addr = address;
    read_req.count = count;
    read_req.indirect= indirect;
    
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Read ad9559 fail\n");
        return CLI_ERROR;
    }

    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for (i = 0; i < count; i++)
    {
        cli_out (cli, "\t0x%08x:\t0x%08x\n", buf[i].addr, buf[i].value);
    }

    return CLI_ERROR;
}

CLI(diag_write_ad9559,
    diag_write_ad9559_cmd,
    "write ad9559 <0-0> REG VALUE (direct|indirect)",
    CLI_WRITE_DESC,
    CLI_AD9559_DESC,    
    CLI_AD9559_IDX_DESC,
    CLI_ADDRESS_DESC,    
    CLI_BYTE_VALUE_DESC,
    CLI_ACCESS_DIRECT_DESC,
    CLI_ACCESS_INDIRECT_DESC)
{
    int32 ret = 0;
    uint32 chip = 0;
    uint32 address = 0;
    uint32 value; 
    uint8 indirect = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_INTEGER_RANGE(CLI_AD9559_IDX_DESC, chip, argv[0], 0, 0);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_BYTE_VALUE_DESC, value, argv[2], 0, 0xFF);
    if (0 == sal_strncmp(argv[3], "direct", 6))
    {
        indirect = 0;
    }
    else
    {
        indirect = 1;
    }
    

    write_req.opcode = REG_AD9559_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    write_req.indirect= indirect;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"Write ad9559 fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
#endif /* chani 20130930 */
#define CHIP_ACCESS_OK              0
#define CHIP_READ_FAIL              -1
#define CHIP_WRITE_FAIL             -2
#define CHIP_ACCESS_TIMEOUT             -3
#define CHIP_ACK_ERROR             -4
#define CHIP_VALUE_NOT_EQUAL             -5
#define CHIP_BUS_BUSY             -6


CLI(diag_read_chip_shim,
    diag_read_chip_shim_cmd,
    "read chip shim <1-5> ADDRESS ",
    CLI_READ_DESC,    
    "chip",
    "reg shim",
    CLI_CHIP_IDX_DESC,
    CLI_ADDRESS_DESC)
{
    int32 ii, ret = 0;
    uint32 chip;
    uint32 address;
    uint8 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, chip, argv[0], 1, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    
    
    read_req.opcode = REG_CHIP_SHIM_R;    
    read_req.chip = chip;
    read_req.addr = address;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }
       
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }

    return CLI_SUCCESS;
}

CLI(diag_write_chip_shim,
    diag_write_chip_shim_cmd,
    "write chip shim <1-5> ADDRESS VALUE",
    CLI_WRITE_DESC,
    "chip",
    "reg shim",
    CLI_CHIP_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_DWORD_VALUE_DESC)
{
    int32 ret = 0;
    uint32 chip;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, chip, argv[0], 1, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[2], 0, 0xFFFFFFFF);

    write_req.opcode = REG_CHIP_SHIM_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }
    }
    
    return CLI_SUCCESS;

}

#define FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F              -100
#define FPGA_SUP_RESULTMEM_CFG_RESULT_ACK_F              -101
#define FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_TYPE_F             -102
#define FPGA_SUP_RESULTMEM_CFG_RESULT_ERROR_ACK_F             -103
#define FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_START_F             -104
#define CMD_ERROR             -105

CLI(diag_read_chip_sup,
    diag_read_chip_sup_cmd,
    "read chip sup ADDRESS ",
    CLI_READ_DESC,
    "chip",
    "sup interface",
    CLI_ADDRESS_DESC)
{
    int32 ii, ret = 0;
    uint32 address;
    uint8 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFFFFFF);
    
    
    read_req.opcode = REG_CHIP_SUP_R;
    read_req.addr = address;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_TYPE_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ERROR_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_START_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CMD_ERROR )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }
       
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }

    return CLI_SUCCESS;
}

CLI(diag_write_chip_sup,
    diag_write_chip_sup_cmd,
    "write chip sup ADDRESS VALUE",
    CLI_WRITE_DESC,
    "chip",
    "sup interface",
    CLI_ADDRESS_DESC,
    CLI_DWORD_VALUE_DESC)
{
    int32 ret = 0;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;
    
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[0], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[1], 0, 0xFFFFFFFF);

    write_req.opcode = REG_CHIP_SUP_W;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_TYPE_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ERROR_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_START_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CMD_ERROR )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }
       
    }
    
    return CLI_SUCCESS;

}

CLI(diag_shim_test,
    diag_shim_test_cmd,
    "test shim COUNT",
    "test function",
    "shim interface",
    "test count")
{
    int32 ret = 0;
    uint32 count = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;   

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[0], 1, 0xffffffff);
    
    read_req.opcode = REG_SHIM_TEST;
    read_req.count = count;
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_VALUE_NOT_EQUAL )
        {
            cli_out(cli, "Write value Not equal to read value failed\n");
            return CLI_ERROR;
        }
       
    }
    return CLI_SUCCESS;
}

CLI(diag_sup_test,
    diag_sup_test_cmd,
    "test sup COUNT",
    "test function",
    "sup interface",
    "test count")
{
    int32 ret = 0;
    uint32 count = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;    

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[0], 1, 0xffffffff);
    
    read_req.opcode = REG_SUP_TEST;
    read_req.count = count;
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_VALUE_NOT_EQUAL )
        {
            cli_out(cli, "Write value Not equal to read value failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_TYPE_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ERROR_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_START_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CMD_ERROR )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }
       
    }
    return CLI_SUCCESS;
}

CLI(diag_ctl_fpga_test,
    diag_ctl_fpga_test_cmd,
    "test fpga COUNT",
    "test function",
    "both shim interface and sup interface",
    "test count")
{
    int32 ret = 0;
    uint32 count = 0;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;    

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[0], 1, 0xffffffff);
    read_req.opcode = REG_SHIM_SUP_TEST;
    read_req.count = count;
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_VALUE_NOT_EQUAL )
        {
            cli_out(cli, "Write value Not equal to read value failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_TYPE_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ERROR_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_START_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CMD_ERROR )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }
       
    }
    return CLI_SUCCESS;
}

CLI(diag_ddr_test,
    diag_ddr_test_cmd,
    "test ddr <1-5> COUNT",
    "test function",
    "ddr test",
    CLI_CHIP_IDX_DESC,
    "test count")
{
    int32 ret = 0;
    uint32 count = 0;
    uint32 chip;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;    

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, chip, argv[0], 1, 5);
    CLI_GET_INTEGER_RANGE(CLI_ADDRESS_DESC, count, argv[1], 1, 0xffffffff);
    
    read_req.opcode = REG_DDR_TEST;
    read_req.chip = chip;
    read_req.count = count;
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_VALUE_NOT_EQUAL )
        {
            cli_out(cli, "Write value Not equal to read value failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_TYPE_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_ERROR_ACK_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == FPGA_SUP_RESULTMEM_CFG_RESULT_CMD_START_F )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CMD_ERROR )
        {
            cli_out(cli, "FPGA_SUP_RESULTMEM_CFG_RESULT_EXTENDED_DATA_F\n");
            return CLI_ERROR;
        }
       
    }
    return CLI_SUCCESS;
}

CLI(diag_download_fpga,
    diag_download_fpga_cmd,
    "download fpga <1-2> <1-5> ",
    "download function",
    "download fpga image",
    CLI_BOARD_IDX_DESC,
    CLI_CHIP_IDX_DESC)
{
    int32 ret = 0;
    uint32 chip;
    uint32 fpga_idx;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;    

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    CLI_GET_INTEGER_RANGE(CLI_BOARD_IDX_DESC, chip, argv[0], 1, 2);
    CLI_GET_INTEGER_RANGE(CLI_CHIP_IDX_DESC, fpga_idx, argv[1], 1, 5);

    read_req.opcode = REG_DOWNLOAD_FPGA;
    read_req.chip = chip;
    read_req.addr = fpga_idx;
    read_req.count = 0;
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
     if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"download fpga fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CLI(diag_download_all_fpga,
    diag_download_all_fpga_cmd,
    "download fpga all <1-2>",
    "download function",
    "download fpga image",
    "all chip download",
    CLI_BOARD_IDX_DESC)
{
    int32 ret = 0;
//    uint32 count = 0;
    uint32 chip;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;    

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    CLI_GET_INTEGER_RANGE(CLI_BOARD_IDX_DESC, chip, argv[0], 1, 2);
    
    read_req.opcode = REG_DOWNLOAD_FPGA;
    read_req.chip = chip;
    read_req.count = 1;
    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
     if (ret|| LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        cli_out(cli,"download fpga fail.\n");
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}


CLI(diag_read_ddr,
    diag_read_ddr_cmd,
    "read chip ddr <1-5> ADDRESS ",
    CLI_READ_DESC,    
    "chip",
    "ddr",
    CLI_CHIP_IDX_DESC,
    CLI_ADDRESS_DESC)
{
    int32 ii, ret = 0;
    uint32 chip;
    uint32 address;
    uint8 count = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    read_regs_reg_t read_req;
    reg_values_t* buf;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, chip, argv[0], 1, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    
    
    read_req.opcode = REG_CHIP_DDR_R;    
    read_req.chip = chip;
    read_req.addr = address;

    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    ret = lcsh_lcm_msg_tx_read_regs(&read_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }
       
    }
    count = (st_rcv.msg_len - LCAPI_LCM_LCSH_HEAD_SIZE)/sizeof(reg_values_t);
    buf = (reg_values_t* )(st_rcv.msg);
    for(ii = 0; ii < count; ii++)
    {
        cli_out(cli, "\t0x%08x:\t0x%08x\n", buf[ii].addr, buf[ii].value);
    }

    return CLI_SUCCESS;
}

CLI(diag_write_ddr,
    diag_write_ddr_cmd,
    "write chip ddr <1-5> ADDRESS VALUE",
    CLI_WRITE_DESC,
    "chip",
    "ddr",
    CLI_CHIP_IDX_DESC,
    CLI_ADDRESS_DESC,
    CLI_DWORD_VALUE_DESC)
{
    int32 ret = 0;
    uint32 chip;
    uint32 address = 0;
    uint32 value = 1;
    lcapi_lcm_lcsh_msg_t st_rcv;
    write_regs_reg_t write_req;

    CLI_GET_INTEGER_RANGE(CLI_PORT_IDX_DESC, chip, argv[0], 1, 5);
    CLI_GET_HEX_UINT32_RANGE(CLI_ADDRESS_DESC, address, argv[1], 0, 0xFFFFFFFF);
    CLI_GET_HEX_UINT32_RANGE(CLI_SHORT_VALUE_DESC, value, argv[2], 0, 0xFFFFFFFF);

    write_req.opcode = REG_CHIP_DDR_W;
    write_req.chip = chip;
    write_req.addr = address;
    write_req.value = value;
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    
    ret = lcsh_lcm_msg_tx_write_regs(&write_req, &st_rcv);
    if (ret || LCAPI_LCM_LCSH_OK != st_rcv.errcode)
    {
        if(st_rcv.errcode == CHIP_READ_FAIL )
        {
            cli_out(cli, "Read reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_WRITE_FAIL )
        {
            cli_out(cli, "Write reg failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACCESS_TIMEOUT )
        {
            cli_out(cli, "Timeout failed\n");
            return CLI_ERROR;
        }

        if(st_rcv.errcode == CHIP_ACK_ERROR )
        {
            cli_out(cli, "Ack error failed\n");
            return CLI_ERROR;
        }
    }
    
    return CLI_SUCCESS;

}

CLI(diag_set_time,
    diag_set_time_cmd,
    "clock set datetime HH:MM:SS <1-12> <1-31> <2000-2037>",
    "Manage the system clock",
    "Set the time and date",
    "Datetime set",
    "Current time",
    "Month of the year",
    "Day of the month",
    "Year"
)
{
    char year[10] = {0};
    char month[10] = {0};
    char day[10] = {0};
    char hour[10] = {0};
    char min[10] = {0};
    char sec[10] = {0};
    char strcmd[256] = {0};
    int ret = 0;

    if(strlen(argv[0]) != 8)
    {
        cli_out(cli, "Invalid HH:MM:SS\n");
        return CLI_ERROR;
    }
    if(strlen(argv[1]) != 2)
    {
        cli_out(cli, "Invalid month\n");
        return CLI_ERROR;
    }
    if(strlen(argv[2]) != 2)
    {
        cli_out(cli, "Invalid day\n");
        return CLI_ERROR;
    }
    if(strlen(argv[3]) != 4)
    {
        cli_out(cli, "Invalid year\n");
        return CLI_ERROR;
    }

    sal_strncpy(year,  argv[3], 4);
    year[4] = '\0';
    sal_strncpy(month, argv[1], 2);
    month[2] = '\0';
    sal_strncpy(day,   argv[2], 2);
    day[2] = '\0';
    sal_strncpy(hour,  &argv[0][0], 2);
    hour[2] = '\0';
    sal_strncpy(min,   &argv[0][3], 2);
    min[2] = '\0';
    sal_strncpy(sec,   &argv[0][6], 2);
    sec[2] = '\0';

    sal_memset(strcmd, 0, 256);
    sal_sprintf(strcmd, "date -s %s%s%s%s%s%s", month, day, hour, min, sec, year);
    ret = system(strcmd);
    if(ret)
    {
        cli_out(cli, "set clock to system fail!\n");
        return CLI_ERROR;
    }

    sal_memset(strcmd, 0, 256);
    sal_sprintf(strcmd, "hwclock -w");
    ret = system(strcmd);
    if(ret)
    {
        cli_out(cli, "sync clock to rtc fail!\n");
        return CLI_ERROR;
    }
    
    return CLI_ERROR;
}

CLI(diag_show_time,
    diag_show_time_cmd,
    "show clock",
    "show",
    "clock"
)
{
    system("hwclock -r");

    return CLI_ERROR;
}

int32
diag_lcsh_cli_init(struct cli_tree *cli_tree)
{
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_gbvtss8211_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_gbvtss8211_cmd);
    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_gephy_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_gephy_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_xgphy_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_xgphy_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_ad9517_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_ad9517_cmd);

	cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_ad9559_cmd);   /* chani 20130930 */
	cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_ad9559_cmd);  /* chani 20130930 */
    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_ds3104_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_ds3104_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_l2switch_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_l2switch_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_l2switch_phy_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_l2switch_phy_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_show_l2switch_stats_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_clear_l2switch_stats_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_l2switch_port_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_dump_l2switch_key_register_cmd);
    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_port_speed_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_port_duplex_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_port_enable_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_port_lb_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_port_media_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_epld_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_epld_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_sfp_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_xfp_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_sfp_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_poe_port_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_poe_sys_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_poe_port_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_poe_sys_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_load_xgphy_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_humber_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_humber_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_sensor_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_sensor_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_sensor_temp_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_sensor_temp_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_gpio_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_gpio_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_mux_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_mux_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_fan_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_fan_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_power_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_power_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_vsc3308_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_vsc3308_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_vsc3308_input_output_pin_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_config_phy_clock_cmd);
    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_eeprom_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_eeprom_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_i2c_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_i2c_cmd);
    
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_byte_fpga_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_byte_fpga_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_short_fpga_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_short_fpga_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_dword_fpga_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_dword_fpga_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_ds21348_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_ds21348_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_ds26503_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_ds26503_cmd);


    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_chip_shim_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_chip_shim_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_chip_sup_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_chip_sup_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_shim_test_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_sup_test_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_ctl_fpga_test_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_ddr_test_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_download_fpga_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_download_all_fpga_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_read_ddr_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_write_ddr_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_set_time_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &diag_show_time_cmd);
    return 0;
}
