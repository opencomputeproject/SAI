 /**
  @file show_key_table.c
  
  @date 2010-10-20
  
  @version v1.0

  @Revision     :       R0.01

  @Author       :       liul

  @Date         :       2010-09-25

  @Reason       :       First Create.
 
  The file contains all show tcam module
 */
/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>

#include "cli.h"
#include "clish.h"
#include "lcsh_lcmtlk.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "ctclib_show.h"
#include "glb_phy_define.h"
#include "ctclib_show.h"

#include "glb_debug_define.h"
#include "glb_hw_define.h"
#include "sal.h"
#include "lcsh_client.h"

#include "lcsh_debug.h"
#include "lcsh_error.h"
#include "clish.h"
#include "glb_tempfile_define.h"

#include "SRAMEntryMsg.h"
#include "LcmMsg.h"

/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/
static uint8_t diag_show_lock_for_mac_entries = 0;
static uint8_t diag_show_lock_for_ipuc_entries = 0;
static uint8_t diag_show_lock_for_ipv6uc_entries = 0;
static uint8_t diag_show_lock_for_acl_entries = 0;
static uint8_t diag_show_lock_for_usrid_entries = 0;
static uint8_t diag_show_lock_for_ipmc_entries = 0;
static uint8_t diag_show_lock_for_ipv6mc_entries = 0;

extern void 
diag_show_tcam_dsipda_head_explain(struct cli *cli);
extern void 
diag_show_tcam_ipuc_dsipsa_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp );
extern void 
diag_show_tcam_dsipsa_head(struct cli *cli);
extern void 
diag_show_tcam_ipuc_dsipda_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp );
extern void  
diag_show_tcam_dsipda_head(struct cli *cli);
extern void 
diag_show_tcam_dsipsa_head_explain(struct cli *cli);
extern int32 
diag_show_sram_dsfwd( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32 
diag_show_sram_dssa( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain);
extern int32 
diag_show_sram_dsda( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain);

extern int32 
diag_show_sram_ipmc_dssa( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain);
int32 
diag_show_sram_ipmc_dsda( struct cli *cli, diag_sram_entry_req_t* req, 
                                           diag_sram_entry_resp_t* resp,int if_list, int if_explain);
/****************************************************************************
*  
* Function
*
*****************************************************************************/

int32
_diag_show_one_tcam_mac_entry(struct cli *cli,diag_l2_tcam_entry_t *resp)
{
    cli_out (cli, " %-8d", resp->index);
    cli_out (cli, " %-6x", resp->dsmackeydata.mapped_vlan_id);
    cli_out (cli, " %.04hx.", resp->dsmackeydata.mapped_mac_da_upper );
    cli_out (cli, " %.04hx.", resp->dsmackeydata.mapped_mac_da_lower>>16);
    cli_out (cli, " %.04hx", resp->dsmackeydata.mapped_mac_da_lower& 0xffff );
    cli_out (cli, " \n"); 
    cli_out (cli, " %-8s" ,"mask" );
    cli_out (cli, " %-6x", resp->dsmackeymask.mapped_vlan_id);
    cli_out (cli, " %.04hx.", resp->dsmackeymask.mapped_mac_da_upper );
    cli_out (cli, " %.04hx.", resp->dsmackeymask.mapped_mac_da_lower>>16);
    cli_out (cli, " %.04hx", resp->dsmackeymask.mapped_mac_da_lower & 0xffff );
    cli_out (cli, " \n"); 
    
    return CLI_SUCCESS;

}

static int32
_diag_show_tcam_read_file(struct cli* cli,char* file_name)
{
    FILE* pf = NULL;
    char string[256]="";

    pf = sal_fopen(file_name,"r");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open %s failed.\n",file_name);
        return CLI_ERROR;
    }
    
    if (sal_feof(pf))
    {
        LCSH_LOG_ERR("File is Null");
        return CLI_ERROR;
    }
  
    while (!sal_feof(pf))
    {
        sal_memset(string, 0, sizeof(string));
        sal_fgets(string, 256, pf);        
        cli_out(cli, " %-s" , string);
    }

    sal_fclose(pf);
    return CLI_SUCCESS;
}

/* show ipuc entry entry  explain */
static void 
_diag_show_tcam_ipuc_hash_entry_wr_head_explain()
{
    FILE *pf = NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_HASH_v4,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open IPUC file failed.\n");
        return ;
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     HASH IPUC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "VRF-Key Vrfid, ");
    sal_fprintf(pf,  "IPDA/VRF-Key Mapped Ip/Vrfid, ");
    sal_fprintf(pf, " \n\n"); 
    sal_fprintf(pf, "%-8s" , " Index");
    sal_fprintf(pf, "%-8s" , "VRF");
    sal_fprintf(pf, "%-17s" , "IPDA");
    sal_fprintf(pf, "\n");      

    sal_fclose(pf);

}

static int
_lcsh_lcm_showtcam_acl_entries( diag_acl_tcam_get_req_t* req, diag_acl_tcam_data_t *resp)
{  
    uint32 ret = 0;

    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_acl_tcam_get_req_t*   p_req = NULL;
    diag_acl_tcam_data_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_acl_tcam_get_req_t *)req;
    p_recv = (diag_acl_tcam_data_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_acl_tcam_get_req_t));
    st_msg.msg_len = sizeof(diag_acl_tcam_get_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ACL_ENTRIES;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message test1 fail, error id is %d", ret);
        return ret;
    }

    return ret;
}

/* print information to explain mac head */
static void 
_diag_show_tcam_acl_mac_head_explain(struct cli *cli)
{ 
  cli_out(cli,"\n");
  cli_out(cli,"AL-Acl Lable, "); 
  cli_out(cli,"RP-Routed Packet, "); 
  cli_out(cli,"SCF-Stag Cfi, "); 
  cli_out(cli,"SCO-Stag Cos, "); 
  cli_out(cli,"CCF-Ctag Cfi, "); 
  cli_out(cli,"CCO-Ctag Cos"); 
  cli_out(cli,"\n"); 
  cli_out(cli,"L3T-layer3 type, "); 
  cli_out(cli,"L2T-layer2 type, "); 
  cli_out(cli,"SVID-SVlan ID, "); 
  cli_out(cli,"CVID-CVlan ID"); 
  cli_out(cli,"\n");
}

/* print information to explain ipv4 head */
static void 
_diag_show_tcam_acl_ipv4_head_explain(struct cli *cli)
{  
    cli_out(cli,"\n");
    cli_out(cli,"AL-Acl Lable, "); 
    cli_out(cli,"RP-Routed Packet, "); 
    cli_out(cli,"TCP-is TCP"); 
    cli_out(cli,"UDP-is UDP, "); 
    cli_out(cli,"AP-is Application, "); 
    cli_out(cli,"\n"); 
    cli_out(cli,"ERR-is Header error, "); 
    cli_out(cli,"OPT-ip Options"); 
    cli_out(cli,"DS-is DSCP, ");   
    cli_out(cli,"l4info-l4infoMapped, "); 
    cli_out(cli,"DS - is DSCP, ");   
    cli_out(cli,"\n");
    cli_out(cli,"FI-frag Info"); 
    cli_out(cli,"DP-l4 Dest Port, ");   
    cli_out(cli,"SP-L4 Source Port"); 
    cli_out(cli,"\n");
}

/* print information to explain pbr ipv4 head */
static void 
_diag_show_tcam_pbr_ipv4_head_explain(struct cli *cli)
{  
}

/* print information to explain ipv6 head */
static void 
_diag_show_tcam_acl_mpls_head_explain(struct cli *cli)
{
    cli_out(cli,"\n");
    cli_out(cli,"IPK-is ip key, "); 
    cli_out(cli,"RP-Routed Packet, "); 
    cli_out(cli,"MK-is mpls key, "); 
    cli_out(cli,"LB-is label, "); 
    cli_out(cli,"COS-cos, "); 
    cli_out(cli,"L2T-layer2_type, "); 
    cli_out(cli,"SCFI-stag cfi, "); 
    cli_out(cli,"\n"); 

    cli_out(cli,"SCOS-stag cos, "); 
    cli_out(cli,"CCFI-Ctag Cfi, "); 
    cli_out(cli,"CCOS-Ctag Cos, "); 
    cli_out(cli,"QL-Qos Label, "); 
    cli_out(cli,"L2QL-l2 qos label, "); 
    cli_out(cli,"L3QL-l3 qos label, "); 
    cli_out(cli,"AL-Acl Lable, "); 
    cli_out(cli,"CVI-cvlan_id, "); 
    cli_out(cli,"\n"); 

    cli_out(cli,"SVI-svlan_id, "); 
    cli_out(cli,"TBI-tableid, "); 
    cli_out(cli,"MLx-mpls_labelx, "); 
    cli_out(cli,"MCSA-mac sa, "); 
    cli_out(cli,"MCDA-mac da, "); 
    cli_out(cli,"\n");

}

/* print information to explain ipv6 head */
static void 
_diag_show_tcam_acl_ipv6_head_explain(struct cli *cli)
{
    cli_out(cli,"\n");
    cli_out(cli,"I6FL-IPV6 Flow Lable, "); 
    cli_out(cli,"6H-IPV6 Extension Headers, "); 
    cli_out(cli,"RP-Routed Packet"); 
    cli_out(cli,"\n");
    cli_out(cli,"TCP-is TCP, "); 
    cli_out(cli,"DS-DSCP, "); 
    cli_out(cli,"LI-l4 Info Mapped, "); 
    cli_out(cli,"DP-l4 Dest Port"); 
    cli_out(cli,"\n");
    cli_out(cli,"SP-l4 Source Port, ");   
    cli_out(cli,"AL-Acl Lable, "); 
    cli_out(cli,"ERR-ip Header Error, ");   
    cli_out(cli,"OPT-ip Options"); 
    cli_out(cli,"\n");  
    cli_out(cli,"UDP-is UDP, ");   
    cli_out(cli,"Ap-is Application, "); 
    cli_out(cli,"FI-Frag Info, ");   
    cli_out(cli,"CID-Chip ID"); 
    cli_out(cli,"\n");
}


static int32
_diag_show_tcam_acl_entries_for_show_explain( struct cli *cli, uint32 key_type)
{  
    if (DIAG_ACLQOS_KEY_MAC == key_type )
    {
        _diag_show_tcam_acl_mac_head_explain( cli );
    }
    else if ( DIAG_ACLQOS_KEY_IPV4 == key_type)
    {
        _diag_show_tcam_acl_ipv4_head_explain( cli );
    }
    else if ( DIAG_ACLQOS_KEY_MPLS == key_type)
    {
        _diag_show_tcam_acl_mpls_head_explain( cli );
    }
    else if ( DIAG_ACLQOS_KEY_IPV6 == key_type)
    {
        _diag_show_tcam_acl_ipv6_head_explain( cli );
    }
    else if ( DIAG_PBR_KEY_IPV4 == key_type)
    {
        _diag_show_tcam_pbr_ipv4_head_explain( cli );
    }

    return CLI_SUCCESS;
}

/* print mac table head */
static void 
_diag_show_tcam_acl_mac_head(FILE *pf)
{
    sal_fprintf(pf,"\n");
    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-4s" , "AL");
    sal_fprintf(pf, "%-4s" , "SCF");
    sal_fprintf(pf, "%-4s" , "SCO");
    sal_fprintf(pf, "%-4s" , "CCF");
    sal_fprintf(pf, "%-4s" , "CCO");
    sal_fprintf(pf, "%-4s" , "L3T");
    sal_fprintf(pf, "%-4s" , "L2T");
    sal_fprintf(pf, "%-5s" , "SVID");
    sal_fprintf(pf, "%-5s" , "CVID");
    sal_fprintf(pf, "%-17s" , "MACDA");
    sal_fprintf(pf, "%-17s" , "MACSA");
    sal_fprintf(pf,"\n");
}

/* print ipv4 table head */
static void 
_diag_show_tcam_acl_ipv4_head(FILE *pf)
{
    sal_fprintf(pf, "\n");
    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-3s" , "AL");
    sal_fprintf(pf, "%-3s" , "RP");
    sal_fprintf(pf, "%-4s" , "TCP");
    sal_fprintf(pf, "%-4s" , "UDP");
    sal_fprintf(pf, "%-3s" , "AP");
    sal_fprintf(pf, "%-4s" , "ERR");
    sal_fprintf(pf, "%-4s" , "OPT");
    sal_fprintf(pf, "%-3s" , "DS");
    sal_fprintf(pf, "%-7s" , "l4info");
    sal_fprintf(pf, "%-3s" , "FI");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");
    sal_fprintf(pf, "%-17s" , "MACDA");
    sal_fprintf(pf, "%-17s" , "MACSA");
    sal_fprintf(pf, "%-15s" , "IPDA");
    sal_fprintf(pf, "%-15s" , "IPSA");
    sal_fprintf(pf, "\n");

}

static void 
_diag_show_tcam_acl_mpls_head(FILE* pf)
{

    sal_fprintf(pf,"\n");
    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-4s" , "IPK");
    sal_fprintf(pf, "%-3s" , "RP");
    sal_fprintf(pf, "%-3s" , "MK");
    sal_fprintf(pf, "%-3s" , "LB");

    sal_fprintf(pf, "%-4s" , "COS");
    sal_fprintf(pf, "%-4s" , "L2T");
    sal_fprintf(pf, "%-5s" , "SCFI");
    sal_fprintf(pf, "%-5s" , "SCOS");
    sal_fprintf(pf, "%-5s" , "CCFI");
    sal_fprintf(pf, "%-5s" , "CCOS");

    sal_fprintf(pf, "%-3s" , "QL");
    sal_fprintf(pf, "%-4s" , "L2QL");
    sal_fprintf(pf, "%-4s" , "L3QL");
    sal_fprintf(pf, "%-3s" , "AL");
    sal_fprintf(pf, "%-4s" , "CVI");
    sal_fprintf(pf, "%-4s" , "SVI");
    sal_fprintf(pf, "%-5s" , "TBI");

    sal_fprintf(pf, "%-9s" , "ML3");
    sal_fprintf(pf, "%-9s" , "ML2");
    sal_fprintf(pf, "%-9s" , "ML1");
    sal_fprintf(pf, "%-9s" , "ML0");

    sal_fprintf(pf, "%-13s" , "MCSA");
    sal_fprintf(pf, "%-13s" , "MDSA");

    sal_fprintf(pf,"\n");


}

static void 
_diag_show_tcam_acl_ipv6_head(FILE* pf)
{
    sal_fprintf(pf,"\n");
    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-6s" , "I6FL");
    sal_fprintf(pf, "%-3s" , "6H");
    sal_fprintf(pf, "%-3s" , "RP");
    sal_fprintf(pf, "%-4s" , "TCP");
    sal_fprintf(pf, "%-3s" , "DS");
    sal_fprintf(pf, "%-5s" , "LI");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");
    sal_fprintf(pf, "%-3s" , "AL");
    sal_fprintf(pf, "%-4s" , "ERR");
    sal_fprintf(pf, "%-4s" , "OPT");
    sal_fprintf(pf, "%-4s" , "UDP");
    sal_fprintf(pf, "%-3s" , "AP");
    sal_fprintf(pf, "%-3s" , "FI");
    sal_fprintf(pf, "%-39s" , "Ipv6Da");
    sal_fprintf(pf, "%-39s" , "Ipv6Sa");
    sal_fprintf(pf, "%-10s" , "L4 port");
    sal_fprintf(pf,"\n");

}

/* print ipv4 table head */
static void 
_diag_show_tcam_pbr_ipv4_head(FILE *pf)
{
    sal_fprintf(pf, "\n");
    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-6s" , "Label");
    sal_fprintf(pf, "%-6s" , "DSCP");
    sal_fprintf(pf, "%-12s" , "L4InfoMap");
    sal_fprintf(pf, "%-12s" , "L4DstPort");
    sal_fprintf(pf, "%-12s" , "L4SrcPort");
    sal_fprintf(pf, "%-6s" , "isTCP");
    sal_fprintf(pf, "%-6s" , "isUDP");
    sal_fprintf(pf, "%-10s" , "fragInfo");
    sal_fprintf(pf, "%-8s" , "l4Type");
    sal_fprintf(pf, "%-15s" , "IPSA");
    sal_fprintf(pf, "%-15s" , "IPDA");
    sal_fprintf(pf, "\n");
}


static int32
_diag_show_tcam_acl_entries_for_show_head( struct cli* cli, uint32 key_type)
{  
    FILE *pf = NULL;
        
    pf = sal_fopen(SHOW_TCAM_ACL_INFO_FILE,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open [SHOW_TCAM_ACL_INFO_FILE] failed.\n");
        return CLI_ERROR;
    }
    
    if (DIAG_ACLQOS_KEY_MAC == key_type )
    {
        _diag_show_tcam_acl_mac_head( pf );
    }
    else if ( DIAG_ACLQOS_KEY_IPV4 == key_type)
    {
        _diag_show_tcam_acl_ipv4_head(pf);
    }
    else if ( DIAG_ACLQOS_KEY_MPLS == key_type)
    {
        _diag_show_tcam_acl_mpls_head(pf);
    }
    else if ( DIAG_ACLQOS_KEY_IPV6 == key_type)
    {
        _diag_show_tcam_acl_ipv6_head(pf);
    }
    else if ( DIAG_PBR_KEY_IPV4 == key_type)
    {
        _diag_show_tcam_pbr_ipv4_head(pf);
    }
    else if ( DIAG_PBR_KEY_IPV6 == key_type)
    {
    }

    sal_fclose(pf);
    
    return CLI_SUCCESS;
}

static int32
_diag_show_tcam_acl_entries_for_show_class(struct cli *cli,uint32 key_type,uint32 table_type)
{

    if (DIAG_ACLQOS_KEY_MAC == key_type )
    {
        if (DIAG_ACL_TABLE == table_type)
        {
            cli_out( cli, "Mac ACL\n");
        }
        else
        {
            cli_out( cli, "Mac QOS\n");
        }
    }
    else if ( DIAG_ACLQOS_KEY_IPV4 == key_type)
    {
        if (DIAG_ACL_TABLE == table_type)
        {
            cli_out( cli, "IPV4 ACL\n");
        }
        else
        {
            cli_out( cli, "IPV4 QOS\n");
        }
    }
    else if ( DIAG_ACLQOS_KEY_MPLS == key_type)
    {
        if (DIAG_ACL_TABLE == table_type)
        {
            cli_out( cli, "MPLS ACL\n");
        }
        else
        {
            cli_out( cli, "MPLS QOS\n");
        }
    }
    else if ( DIAG_ACLQOS_KEY_IPV6 == key_type)
    {
        if (DIAG_ACL_TABLE == table_type)
        {
            cli_out( cli, "IPV6 ACL\n");
        }
        else
        {
            cli_out( cli, "IPV6 QOS\n");
        }
    }
    else if ( DIAG_PBR_KEY_IPV4 == key_type)
    {
        if (DIAG_PBR_TABLE == table_type)
        {
            cli_out( cli, "IPV4 PBR\n");
        }
    }

    return CLI_SUCCESS;
}

/*mac or ipv4 or ipv6 port or vlan or linkagg or global*/
CLI (show_tcam_acl_entries,
     show_tcam_acl_entries_cmd,
     "show tcam  (acl|qos|pbr) (mac|ipv4|ipv6|mpls) CHIPID entries",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show ACL TCAM",
     "Show QOS TCAM",
     "Show PBR TCAM",
     "Show mac ACL information",
     "Show ipv4 ACL information",
     "Show ipv6 ACL information",
     "Show mpls ACL information",
     "Chip ID",
     "Show entry information")
{
    diag_acl_tcam_get_req_t req;
    diag_acl_tcam_data_t resp;

    sal_memset(&resp,0,sizeof(diag_acl_tcam_data_t));
    sal_memset(&req, 0 , sizeof(diag_acl_tcam_get_req_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[2], 0, 0);

    if ( 0 == sal_strcmp(argv[0], "acl") ) 
    {
        req.table_type = DIAG_ACL_TABLE;
    }
    else if (0 == sal_strcmp(argv[0], "qos")) 
    {
         req.table_type = DIAG_QOS_TABLE;
    }
    if (0 == sal_strcmp(argv[1], "mac")) 
    {
        req.key_type = DIAG_ACLQOS_KEY_MAC;
    }
    else if (0 == sal_strcmp(argv[1], "ipv4")) 
    {
         req.key_type = DIAG_ACLQOS_KEY_IPV4;
    }
    else if (0 == sal_strcmp(argv[1], "mpls")) 
    {
        req.key_type = DIAG_ACLQOS_KEY_MPLS;
    }
    else 
    {
        req.key_type = DIAG_ACLQOS_KEY_IPV6;
    }

    if ((0 == sal_strcmp(argv[0], "pbr")) &&  (0 == sal_strcmp(argv[1], "ipv4") ) )
    {
        req.table_type = DIAG_PBR_TABLE;
        req.key_type = DIAG_PBR_KEY_IPV4;
    }
    
    if (diag_show_lock_for_acl_entries)
    {
        cli_out(cli, "Other is showing the mac tcam information\n ");
        return CLI_SUCCESS;        
    }
    diag_show_lock_for_acl_entries = 1;
    
    _diag_show_tcam_acl_entries_for_show_head( cli, req.key_type);
    if ( _lcsh_lcm_showtcam_acl_entries(&req, &resp ) < 0)
    {
        diag_show_lock_for_acl_entries = 0;
        return CLI_ERROR;
    }
    _diag_show_tcam_acl_entries_for_show_explain( cli, req.key_type  );
    _diag_show_tcam_acl_entries_for_show_class( cli, req.key_type,req.table_type);

   DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ACL_INFO_FILE)); 
    
    cli_out( cli, "\n" );
    diag_show_lock_for_acl_entries = 0;

    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_showtcam_acl_one_entry( diag_acl_tcam_get_req_t* req, diag_acl_tcam_entry_t* resp )
{   
   uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_acl_tcam_get_req_t*   p_req = NULL;
    diag_acl_tcam_entry_t* p_recv = NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_acl_tcam_get_req_t *)req;
    p_recv = (diag_acl_tcam_entry_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_acl_tcam_get_req_t));
    st_msg.msg_len = sizeof(diag_acl_tcam_get_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_ACL_ENTRY;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message test1 fail, error id is %d", ret);
        return ret;
    }
    sal_memcpy(resp,st_rcv.msg, sizeof(diag_acl_tcam_entry_t));    

    return ret;
}

/* show one acl entry */
CLI (show_tcam_acl_one_entry,
     show_tcam_acl_one_entry_cmd,
     "show tcam  (acl|qos) (mac|ipv4|ipv6|mpls) CHIPID entry WORD",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show ACL TCAM",
     "Show QOS TCAM",
     "Show mac  information",
     "Show ipv4  information",
     "Show ipv6  information",
     "Show mpls  information",
     "Chip ID",
     "Show entry information",
     "Entry ID")
{
    diag_acl_tcam_get_req_t req;
    diag_acl_tcam_entry_t resp;

    sal_memset(&resp,0,sizeof(diag_acl_tcam_entry_t));
    sal_memset(&req, 0 , sizeof(diag_acl_tcam_get_req_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[2], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[3], 0, 0x0FFFFFFF);

    if (0 == sal_strcmp(argv[0], "acl")) 
    {
        req.table_type = DIAG_ACL_TABLE;
    }
    else if (0 ==sal_strcmp(argv[0], "qos")) 
    {
        req.table_type = DIAG_QOS_TABLE;
    }
    
    if (0 ==sal_strcmp(argv[1], "mac")) 
    {
        req.key_type = DIAG_ACLQOS_KEY_MAC;
    }
    else if (0 ==sal_strcmp(argv[1], "ipv4")) 
    {
        req.key_type = DIAG_ACLQOS_KEY_IPV4;
    }
    else if (0 ==sal_strcmp(argv[1], "mpls")) 
    {
        req.key_type = DIAG_ACLQOS_KEY_MPLS;
    }
    else if (0 ==sal_strcmp(argv[1], "ipv6")) 
    {
        req.key_type = DIAG_ACLQOS_KEY_IPV6;
    }

    _diag_show_tcam_acl_entries_for_show_head( cli, req.key_type);

    DIAG_SHOW_IF_ERROR_RETURN( _lcsh_lcm_showtcam_acl_one_entry(&req, &resp));

    if (resp.chip_id ==  DIAG_GET_TCAM_INDEX_INVALID)
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp.index -1 );
        return CLI_SUCCESS;
    }
    if (resp.chip_id == DIAG_GET_TCAM_INDEX_EXCEED )
    {
        cli_out( cli, "%%The index is invalid\n" );
    }

    _diag_show_tcam_acl_entries_for_show_explain( cli, req.key_type  );

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ACL_INFO_FILE)); 
    cli_out(cli,"\n");

    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_showtcam_l2_entries(diag_l2_tcam_entry_req_t* req, diag_l2_tcam_entries_resp_t* resp)
{   
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_l2_tcam_entry_req_t*   p_req = NULL;
    diag_l2_tcam_entries_resp_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l2_tcam_entry_req_t *)req;
    p_recv = (diag_l2_tcam_entries_resp_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l2_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l2_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_MAC_ENTRIES;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);

    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_showtcam_l2_entries], error id is %d", ret);
        return ret;
    }

    return ret;

}

/* show l2 mac head explain */
static void 
_diag_show_tcam_l2_entry_mac_head_explain(struct cli* cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "Index-Index of entry, ");
    cli_out(cli, "VID-Vlan ID , ");
    cli_out(cli,  "MacDA-Mac DA");
    cli_out(cli, " \n");
}

/* show l2 mac head*/
static void 
_diag_show_tcam_l2_entry_mac_head(struct cli* cli)
{
    cli_out(cli, " %-9s%-7s%-16s%-7s", "index","VID","MacDA","");
    cli_out(cli, " \n"); 
}

/* show l2 mac head explain */
static void 
_diag_show_tcam_l2_entry_mac_hash_head_explain(struct cli* cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "Index-Index of entry, ");
    cli_out(cli, "VID-Vlan ID , ");
    cli_out(cli,  "MacDA-Mac DA");
    cli_out(cli, " \n");
}

/* show l2 mac head*/
static void 
_diag_show_tcam_l2_entry_one_mac_hash_head(struct cli* cli)
{
    cli_out(cli, " %-9s%-7s%-16s%-7s", "index","VID","MacDA","");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_one_hash_mac_entry(struct cli* cli,diag_l2_tcam_entry_t* resp)
{
    cli_out(cli, " %-8d", resp->index);
    cli_out(cli, " %-6x", resp->dsmackeyhash.mapped_vlanid);
    cli_out(cli, " %.04hx.", resp->dsmackeyhash.mapped_mach );
    cli_out(cli, " %.04hx.", resp->dsmackeyhash.mapped_macl>>16 & 0xffff);
    cli_out(cli, " %.04hx", resp->dsmackeyhash.mapped_macl & 0xffff);
    cli_out(cli,"\n");
}

/* show l2 mac head*/
static void 
_diag_show_tcam_l2_entry_mac_hash_head()
{
    FILE* pf = NULL;
    
    pf = sal_fopen(SHOW_TCAM_HASH_MAC_INFO_FILE,"w");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open hash mac file failed.\n");
        return;
    }
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     DS_MAC_HASH_KEY0 \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    sal_fprintf(pf, " %-9s%-7s%-16s%-7s", "index","vid","MacDA","");
    sal_fprintf(pf, " \n"); 
    sal_fclose(pf);

}

static void 
_diag_show_tcam_l2_entry_mac_tcam_head()
{
    FILE* pf = NULL;
    
    pf = sal_fopen(SHOW_TCAM_TCAM_MAC_INFO_FILE,"w");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open /filename failed.\n");
        return;
    }
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     TCAM MAC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    sal_fprintf(pf, " %-9s%-7s%-16s%-7s", "index","VID","MacDA","");
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);

}
/* show l2 mac head*/
static void 
_diag_show_tcam_l2_entry_dft_mac_hash_head()
{
    FILE* pf = NULL;
    
    pf = sal_fopen(SHOW_TCAM_DEFAULT_HASH_MAC_INFO_FILE,"w");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open hash mac file failed.\n");
        return;
    }
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                    default DS_MAC_HASH_KEY0 \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    sal_fprintf(pf, " %-9s%-7s%-16s%-7s", "index","vid","MacDA","");
    sal_fprintf(pf, " \n"); 
    sal_fclose(pf);

}

static void 
_diag_show_tcam_l2_entry_dft_mac_tcam_head()
{
    FILE* pf = NULL;
    
    pf = sal_fopen(SHOW_TCAM_DEFAULT_TCAM_MAC_INFO_FILE,"w");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open /filename failed.\n");
        return;
    }
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     default TCAM MAC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    sal_fprintf(pf, " %-9s%-7s%-16s%-7s", "index","VID","MacDA","");
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);

}

/* show all mac  entries */
CLI (show_tcam_mac_entries,
     show_tcam_mac_entries_cmd,
     "show tcam mac CHIPID entries ",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show MacBridge TCAM",
     "Chip ID",
     "Show entry information")
{
    diag_l2_tcam_entry_req_t req;
    diag_l2_tcam_entries_resp_t  resp;
    uint32 ret = 0;
    
    sal_memset(&resp,0,sizeof(diag_l2_tcam_entries_resp_t));
    sal_memset(&req, 0 , sizeof(diag_l2_tcam_entry_req_t));
    
    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);

    if (diag_show_lock_for_mac_entries)
    {
        cli_out(cli, "Other is showing the mac tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_mac_entries = 1;

    _diag_show_tcam_l2_entry_dft_mac_tcam_head();
    _diag_show_tcam_l2_entry_dft_mac_hash_head();
    _diag_show_tcam_l2_entry_mac_tcam_head();
    _diag_show_tcam_l2_entry_mac_hash_head();

    if ((ret = _lcsh_lcm_showtcam_l2_entries(&req, &resp)) < 0)
    {
        diag_show_lock_for_mac_entries = 0;
        cli_out (cli, "Get mac entries failed, rv=%d\n", ret);
        return CLI_ERROR;
    }   

    _diag_show_tcam_l2_entry_mac_head_explain( cli ); 

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_DEFAULT_TCAM_MAC_INFO_FILE));  
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_DEFAULT_HASH_MAC_INFO_FILE));

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_TCAM_MAC_INFO_FILE));  
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_HASH_MAC_INFO_FILE));

    cli_out (cli, " \n"); 
    
    diag_show_lock_for_mac_entries = 0;
        
    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_showtcam_l2_one_entry( diag_l2_tcam_entry_req_t* req, diag_l2_tcam_entry_t* resp )
{      
    uint32 ret = 0;
    diag_l2_tcam_entry_req_t*   p_req = NULL;
    diag_l2_tcam_entry_t* p_recv = NULL;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l2_tcam_entry_req_t *)req;
    p_recv = (diag_l2_tcam_entry_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l2_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l2_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_MAC_ENTRY;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_showtcam_l2_one_entry], error id is %d", ret);
        return ret;
    }

    sal_memcpy(resp,st_rcv.msg, sizeof(diag_l2_tcam_entry_t));    

    return ret;
}

/* show l2 mac entry from tcam*/
void 
diag_show_one_tcam_mac_entry(struct cli* cli,  diag_l2_tcam_entry_t* resp )
{
    cli_out(cli, " %-8d", resp->index);
    cli_out(cli, " %-6x", resp->dsmackeydata.mapped_vlan_id);
    cli_out(cli, " %.04hx.", resp->dsmackeydata.mapped_mac_da_upper );
    cli_out(cli, " %.04hx.", resp->dsmackeydata.mapped_mac_da_lower>>16);
    cli_out(cli, " %.04hx", resp->dsmackeydata.mapped_mac_da_lower& 0xffff );
    cli_out(cli, " \n"); 
    cli_out(cli, " %-8s" ,"mask" );
    cli_out(cli, " %-6x", resp->dsmackeymask.mapped_vlan_id);
    cli_out(cli, " %.04hx.", resp->dsmackeymask.mapped_mac_da_upper );
    cli_out(cli, " %.04hx.", resp->dsmackeymask.mapped_mac_da_lower>>16);
    cli_out(cli, " %.04hx", resp->dsmackeymask.mapped_mac_da_lower & 0xffff );
    cli_out(cli, " \n"); 
}

void 
diag_show_tcam_l2_entry_dsmacda_head_explain(struct cli* cli)
{
    cli_out(cli,  " DSMac, ");   
    cli_out(cli,  "ECP-Equal Cost Path, ");
    cli_out(cli,  "FP-Fwd Ptr, ");
    cli_out(cli,  "UD-Ucast Discard, ");
    cli_out(cli,  "LE-Learn En, ");
    cli_out(cli,  " \n"); 
    cli_out(cli,  "MDE-MacDA excep En, ");
    cli_out(cli,  "MSE-MacSA excep En, ");
    cli_out(cli,  "PPE-Priority Path En, ");
    cli_out(cli,  "PET-Protocol Excep Type, ");
    cli_out(cli,  " \n"); 
    cli_out(cli,  "MK-Mac Known, ");
    cli_out(cli,  "SCE-Srcport Check En, ");
    cli_out(cli,  "SD-Src disc, ");
    cli_out(cli,  "SMD-Src-Mismatch Disc, ");
    cli_out(cli,  " \n"); 
    cli_out(cli,  "SML-Src-Mismatch Learn, ");
    cli_out(cli,  "SP-Src-Port, ");
    cli_out(cli,  "SCT-Storm Ctl En, ");
    cli_out(cli,  "MCD-Mcast Discard.");
    cli_out(cli,  " \n"); 
}

static void 
_diag_show_tcam_l2_entry_dsmacda_head(struct cli* cli)
{
    cli_out(cli, "%-7s" ," DSMac");   
    cli_out(cli, "%-4s" , "ECP");
    cli_out(cli, "%-9s" , "FP");
    cli_out(cli, "%-4s" , "UD");
    cli_out(cli, "%-4s" , "LE");
    cli_out(cli, "%-4s" , "MDE");
    cli_out(cli, "%-4s" , "MSE");
    cli_out(cli, "%-4s" , "PPE");
    cli_out(cli, "%-4s" , "PET");
    cli_out(cli, "%-4s" , "MK");
    cli_out(cli, "%-4s" , "SCE");
    cli_out(cli, "%-4s" , "SD");
    cli_out(cli, "%-4s" , "SMD");
    cli_out(cli, "%-4s" , "SML");
    cli_out(cli, "%-5s" , "SP");
    cli_out(cli, "%-4s" , "SCT");
    cli_out(cli, "%-4s" , "MCD");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_l2_dsmacda_entry(struct cli *cli,diag_l2_tcam_entry_t *resp)
{
    cli_out(cli, "%6s" , "");
    cli_out(cli, " %-3x", resp->dsmacda.equal_cost_path_num10);
    cli_out(cli, " %-08x", resp->dsmacda.fwd_ptr);
    cli_out(cli, " %-3x", resp->dsmacda.ucast_discard);
    cli_out(cli, " %-3x", resp->dsmacda.learn_en);
    cli_out(cli, " %-3x", resp->dsmacda.mac_da_exception_en);
    cli_out(cli, " %-3x", resp->dsmacda.mac_sa_exception_en);
    cli_out(cli, " %-3x", resp->dsmacda.priority_path_en);
    cli_out(cli, " %-3x", resp->dsmacda.proto_exception_en);
    cli_out(cli, " %-3x", resp->dsmacda.mac_known);
    cli_out(cli, " %-3x", resp->dsmacda.source_port_check_en);
    cli_out(cli, " %-3x", resp->dsmacda.src_discard);
    cli_out(cli, " %-3x", resp->dsmacda.src_mismatch_discard);
    cli_out(cli, " %-3x", resp->dsmacda.src_mismatch_learn_en);
    cli_out(cli, " %-4x", resp->dsmacda.global_src_port);
    cli_out(cli, " %-3x", resp->dsmacda.storm_ctl_en);
    cli_out(cli, " %-3x", resp->dsmacda.mcast_discard);
    cli_out(cli, " \n"); 

}

static int32
_lcsh_lcm_showtcam_ipv4_one_entry(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
{      
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entry_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entry_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPUC_ENTRY;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_showtcam_ipv4_one_entry], error id is %d", ret);
        return ret;
    }

    sal_memcpy(resp,st_rcv.msg, sizeof(diag_ipv4_v6_tcam_entry_t));    

    return ret;
}

CLI (show_tcam_mac_one_entry,
     show_tcam_mac_one_entry_cmd,
     "show tcam mac CHIPID entry WORD (default |undefault) (list |) (explain |)",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show MacBridge TCAM",
     "Chip ID",
     "Show entry information",
     "Entry ID",
     "default entry",
     "undefault entry",
     "List sram mac",
     "Show MAC explain")
{
    diag_l2_tcam_entry_req_t req;
    diag_l2_tcam_entry_t resp;
    diag_sram_entry_req_t  sram_req; 
    diag_sram_entry_resp_t  sram_resp;
    uint32 is_list=0;
    uint32 is_explain=0;

    sal_memset(&req, 0 , sizeof(diag_l2_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_l2_tcam_entry_t));
    sal_memset(&sram_req, 0 , sizeof(diag_sram_entry_req_t));
    sal_memset(&sram_resp, 0 , sizeof(diag_sram_entry_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[1], 0, 0x0FFFFFFF);

    if (5 == argc ) 
    {
        is_list  = 1;
        is_explain = 1;
    }
    else if ( 4 == argc) 
    {
        if (0 == sal_strcmp (argv[3], "explain"))
        {
            is_explain = 1;
        }
        else 
        {
            is_list = 1;
        }
    }
    
    if(0 == sal_strcmp(argv[2],"default"))
    {
        req.type = default_type;
    }
    else
    {
        req.type = other_type;        
    }
    
    DIAG_SHOW_IF_ERROR_RETURN( _lcsh_lcm_showtcam_l2_one_entry(&req, &resp ));

    if ( DIAG_GET_TCAM_INDEX_INVALID == resp.chip_id)
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp.index -1 );
        return CLI_SUCCESS;
    }
    if ( DIAG_GET_TCAM_INDEX_EXCEED == resp.chip_id )
    {
        cli_out( cli, "%%The index is invalid \n"  );
    }

    if (diag_mac_type_tcam == resp.type)
    {
        if (is_explain)
        {
            _diag_show_tcam_l2_entry_mac_head_explain(cli);
            cli_out(cli, " \n");
        }
        _diag_show_tcam_l2_entry_mac_head( cli );
        diag_show_one_tcam_mac_entry(cli,&resp); 
    }
    else
    {
        if (is_explain)
        {
            _diag_show_tcam_l2_entry_mac_hash_head_explain(cli);
            cli_out(cli, " \n");
        }
        
        _diag_show_tcam_l2_entry_one_mac_hash_head( cli );
        _diag_show_one_hash_mac_entry(cli,&resp);  
    }
    cli_out(cli,"\n");
    
    if (is_explain)
    {
          diag_show_tcam_l2_entry_dsmacda_head_explain(cli);
          cli_out(cli,  " \n"); 
    }
    _diag_show_tcam_l2_entry_dsmacda_head( cli );
    _diag_show_tcam_l2_dsmacda_entry( cli, &resp );
    cli_out(cli,"\n");

    if (is_list)
    {
        if ( resp.dsmacda.fwd_ptr != 0xffff)
        {
            sram_req.table_type = DIAG_DS_FWD;
            sram_req.index= resp.dsmacda.fwd_ptr;
            sram_req.chip_id = req.chip_id;
            diag_show_sram_dsfwd( cli, &sram_req, &sram_resp, is_list, is_explain);
        } 
    }    

    return CLI_SUCCESS;
}

static int32
_diag_showtcam_ipv4_one_entry(struct cli* cli, diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
{
    resp->index = req->index;
    return _lcsh_lcm_showtcam_ipv4_one_entry (req, resp);
}

/* show ipuc entry entry  explain */
static void 
_diag_show_tcam_ipv4_entry_head_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "Index-Index of entry, ");
    cli_out(cli,  "DP-l4 Dest Port, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "SP-l4 Src Port, ");
    cli_out(cli, "LKM-LKP MODE, ");
    cli_out(cli, "IPSA/VRF-IP SA/VRF, ");
    cli_out(cli,  "IPDA-IP DA, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "L4TP-Layer4 Type, FI-FragInfo ");
    cli_out(cli, " \n");
}
/* show ipuc entry head*/
static void 
_diag_show_tcam_ipv4_entry_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " Index");
    cli_out(cli, "%-5s" , "DP");
    cli_out(cli, "%-5s" , "SP");
    cli_out(cli, "%-5s" , "VRF"); 
    cli_out(cli, "%-5s" , "LKM");
    cli_out(cli, "%-5s" , "L4TP"); 
    cli_out(cli, "%-11s" , "IPSA/VRF");
    cli_out(cli, "%-17s" , "IPDA");
    cli_out(cli, " \n"); 
}

/* show ipuc entry entry  explain */
static void 
_diag_show_tcam_ipuc_entry_wr_head_explain()
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_V4,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open /filename failed.\n");
        return ;
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     TCAM IPUC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    sal_fprintf(pf, " \n");     

    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "DP-l4 Dest Port, ");
    sal_fprintf(pf,  "SP-l4 Src Port, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "VRF-Vrf Id, ");
    sal_fprintf(pf,  "LKM-LKP MODE, ");
    sal_fprintf(pf, "IPSA/VRF-IP SA/VRF, ");
    sal_fprintf(pf,  "IPDA-IP DA");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "L4TP-Layer4 Type, FI-FragInfo");
    sal_fprintf(pf, " \n\n"); 

    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");
    sal_fprintf(pf, "%-5s" , "VRF");
    sal_fprintf(pf, "%-5s" , "LKM");
    sal_fprintf(pf, "%-5s" , "L4TP");   
    sal_fprintf(pf, "%-11s" , "IPSA/VRF");
    sal_fprintf(pf, "%-17s" , "IPDA");
    sal_fprintf(pf, "\n");     

    sal_fclose(pf);

}

/* show ipuc entry entry  explain */
void 
diag_show_tcam_ipv6_entry_wr_head_explain()
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_V4,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open /filename failed.\n");
    }
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "DP-l4 Dest Port, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "SP-l4 Src Port, ");
    sal_fprintf(pf, "IPSA-IP SA , ");
    sal_fprintf(pf,  "IPDA-IP DA");
    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");
    sal_fprintf(pf, "%-5s" , "TID");
    sal_fprintf(pf, "%-39s" , "IPSA");
    sal_fprintf(pf, "%-39s" , "IPDA");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);

}

/* show ipuc entry from tcam*/
static void 
_diag_show_tcam_ipv4_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, " %-5d", resp->index);
    cli_out(cli, " %-4x", resp->keydata.l4_dest_port);
    cli_out(cli, " %-4x", resp->keydata.l4_source_port);
    cli_out(cli, " %-4x", ((resp->keydata.vrf_idh << 4) |(resp->keydata.vrf_idl & 0xf)));    
    cli_out(cli, " %-4x", resp->keydata.lkp_mode);
    cli_out(cli, " %-4x", resp->keydata.layer4_type);   
    cli_out(cli, " %.08x", resp->keydata.ip_sa);

    cli_out(cli, " %-1s", " ");    
    cli_out(cli, " %.02hx.", (resp->keydata.ip_da>>24) & 0xff);
    cli_out(cli, " %.02hx.", (resp->keydata.ip_da>>16) & 0xff);
    cli_out(cli, " %.02hx.", (resp->keydata.ip_da>>8) & 0xff);
    cli_out(cli, " %.02hx", resp->keydata.ip_da & 0xff);

    cli_out(cli, " \n"); 
    cli_out(cli, " %-5s", "mask");
    cli_out(cli, " %-4x", resp->keymask.l4_dest_port);
    cli_out(cli, " %-4x", resp->keymask.l4_source_port);
    cli_out(cli, " %-4x", ((resp->keymask.vrf_idh << 4) |(resp->keymask.vrf_idl & 0xf)));   
    cli_out(cli, " %-4x", resp->keymask.lkp_mode);
    cli_out(cli, " %-4x", resp->keymask.layer4_type); 
    cli_out(cli, " %.08x", resp->keymask.ip_sa);

    cli_out(cli, " %-1s", " ");    
    cli_out(cli, " %.02hx.", (resp->keymask.ip_da>>24) & 0xff);
    cli_out(cli, " %.02hx.", (resp->keymask.ip_da>>16) & 0xff);
    cli_out(cli, " %.02hx.", (resp->keymask.ip_da>>8) & 0xff);
    cli_out(cli, " %.02hx", resp->keymask.ip_da & 0xff);
    cli_out(cli, " \n"); 
 
}

static void 
_diag_show_tcam_ipuc_hash_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " Index");
    cli_out(cli, "%-8s" , "VRF");
    cli_out(cli, "%-17s" , "IPDA");
    cli_out(cli, "\n");      
}

static void 
_diag_show_tcam_ipuc_hash_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "Index-Index of entry, ");
    cli_out(cli,  "VRF-Key Vrfid, ");
    cli_out(cli,  "IPDA-Key Mapped Ip, ");
    cli_out(cli, "\n");      
}

static void 
_diag_show_tcam_ipuc_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, " %-6d", resp->index);
    cli_out(cli, " %-7x", resp->dsip_hashkey_v4.key_vrfid);
    cli_out(cli, " %.02hx.", (resp->dsip_hashkey_v4.key_mapped_ip>>24) & 0xff);
    cli_out(cli, " %.02hx.", (resp->dsip_hashkey_v4.key_mapped_ip>>16) & 0xff);
    cli_out(cli, " %.02hx.", (resp->dsip_hashkey_v4.key_mapped_ip>>8) & 0xff);
    cli_out(cli, " %.02hx", resp->dsip_hashkey_v4.key_mapped_ip & 0xff);
    cli_out(cli, "\n"); 
}

/* show one ipuc entry */
CLI (show_tcam_ipuc_one_entry,
     show_tcam_ipuc_one_entry_cmd,
     "show tcam ipuc CHIPID entry WORD(hash|tcam) (list |) (explain |)",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPv4 Route TCAM",
     "Chip ID",
     "Show entry information",
     "Entry ID",
     "Entry in hash",
     "Entry in tcam",
     "List IMPC SRAM",
     "Show ipv4 explain" )
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    diag_sram_entry_req_t  sram_req; 
    diag_sram_entry_resp_t sram_resp;
    uint32 is_list = 0;
    uint32 is_explain = 0;

    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entry_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[1], 0, 0x0FFFFFFF);

    if ( 5 == argc  ) 
    {
        is_list  = 1;
        is_explain = 1;
    }
    else if ( 4 == argc ) 
    {
        if (0 == sal_strcmp (argv[3], "explain"))
        {
            is_explain = 1;
        }
        else 
        {
            is_list = 1;
        }
    }

    if(0 == sal_strcmp(argv[2],"hash"))
    {
        req.position = sram_type;
    }
    else
    {
        req.position = tcam_type;    
    }
    
    DIAG_SHOW_IF_ERROR_RETURN( _diag_showtcam_ipv4_one_entry(cli, &req, &resp ));
    if ( DIAG_GET_TCAM_INDEX_INVALID == resp.chip_id )
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp.index -1 );
        return CLI_SUCCESS;
    }

    if ( DIAG_GET_TCAM_INDEX_EXCEED == resp.chip_id )
    {
        cli_out( cli, "%%The index is invalid.\n" );
    }

    if (is_explain)
    {
        if ( tcam_type == resp.position)
        {
            _diag_show_tcam_ipv4_entry_head_explain( cli );
        }
        else
        {
            _diag_show_tcam_ipuc_hash_explain(cli);
        }
    }
    sram_req.chip_id = req.chip_id;
    sram_req.index =req.index;
    
    if (tcam_type  == resp.position)
    {
        _diag_show_tcam_ipv4_entry_head( cli );
        _diag_show_tcam_ipv4_entry( cli, &resp );
    }
    else
    {
        _diag_show_tcam_ipuc_hash_head(cli);
        _diag_show_tcam_ipuc_entry( cli, &resp );
    }
    cli_out(cli,"\n");
    
    if ( is_explain )
    {
        diag_show_tcam_dsipda_head_explain(cli);        
    }

    diag_show_tcam_dsipda_head(cli);
    diag_show_tcam_ipuc_dsipda_entry( cli, &resp );
    cli_out(cli,"\n");

    if ( is_explain )
    {
        diag_show_tcam_dsipsa_head_explain(cli);        
    }
    
    diag_show_tcam_dsipsa_head(cli);
    diag_show_tcam_ipuc_dsipsa_entry( cli, &resp );
    cli_out(cli,"\n");

    if (is_list )
    {
        if ( resp.dsipda.ds_fwd_ptr != 0xfffff)
        {
            sram_req.table_type = DIAG_DS_FWD;
            sram_req.index = resp.dsipda.ds_fwd_ptr;
            diag_show_sram_dsfwd( cli, &sram_req, &sram_resp, is_list, is_explain);
        }
        cli_out(cli,"\n");
    }

    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_show_tcam_ipuc_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{    
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entries_resp_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entries_resp_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPUC_ENTRIES;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_show_tcam_ipuc_entries], error id is %d", ret);
        return ret;
    }

    return ret;

}

/* show  ipuc entries */
 CLI (show_tcam_ipuc_entries,
     show_tcam_ipuc_entries_cmd,
     "show tcam ipuc CHIPID entries",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPv4 Route TCAM",
     "Chip ID",
     "Show entry information")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;

    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entries_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);

    if (diag_show_lock_for_ipuc_entries)
    {
        cli_out(cli,"Other is showing the ipuc tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_ipuc_entries = 1;

    _diag_show_tcam_ipuc_entry_wr_head_explain();
    _diag_show_tcam_ipuc_hash_entry_wr_head_explain();
    
    if (_lcsh_lcm_show_tcam_ipuc_entries(&req, &resp) < 0)
    {
        diag_show_lock_for_ipuc_entries = 0;
        return CLI_ERROR;
    }
      
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPUC_FILE_V4));
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPUC_FILE_HASH_v4));
    
    cli_out(cli,"\n");

    diag_show_lock_for_ipuc_entries = 0;
    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_showtcam_ipv6_one_entry(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
{  
   uint32 ret = 0;

    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entry_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entry_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPV6UC_ENTRY;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_showtcam_ipv6_one_entry], error id is %d", ret);
        return ret;
    }

    sal_memcpy(resp,st_rcv.msg, sizeof(diag_ipv4_v6_tcam_entry_t));    

    return ret;

}

/* show ipv6uc head explain */
static void 
_diag_show_tcam_ipv6_entries_head_explain(struct cli *cli)
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_V6,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open ipuc v6 failed.\n");
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     TCAM IPV6UC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "DP-l4 Dest Port, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "SP-l4 Src Port, ");
    sal_fprintf(pf, "IPSA-IP SA , ");
    sal_fprintf(pf, "IPDA-IP DA");
    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");
    sal_fprintf(pf, "%-5s" , "VRF");
    sal_fprintf(pf, "%-39s" , "IPSA");
    sal_fprintf(pf, "%-39s" , "IPDA");
    sal_fprintf(pf, "\n");     

    sal_fclose(pf);

}

/* show ipv6uc head explain */
static void 
_diag_show_tcam_ipv6uc_entry_head_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "Index-Index of entry, ");
    cli_out(cli,  "DP-l4 Dest Port, ");
    cli_out(cli,  "SP-l4 Src Port, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "VRF-VRF id, ");
    cli_out(cli, "IPSA-IP SA, ");
    cli_out(cli,  "IPDA-IP DA");
    cli_out(cli, " \n"); 
}

/* show ipv6uc  head*/
static void 
_diag_show_tcam_ipv6uc_entry_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " Index");
    cli_out(cli, "%-5s" , "DP");
    cli_out(cli, "%-5s" , "SP");
    cli_out(cli, "%-5s" , "VRF");
    cli_out(cli, "%-39s" , "IPSA");
    cli_out(cli, "%-39s" , "IPDA");
    cli_out(cli, " \n"); 
}

/* show ipv6uc entry from tcam*/
static void 
_diag_show_tcam_ipv6uc_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, " %-5d", resp->index);
    cli_out(cli, " %-4x", resp->keydata_v6.l4_dest_port);
    cli_out(cli, " %-4x", resp->keydata_v6.l4_source_port);   
    cli_out(cli, " %-4x", ((resp->keydata_v6.vrf_idh << 4) | (resp->keydata_v6.vrf_idl & 0xf)));  
    cli_out(cli, " %08x.", (resp->keydata_v6.ip_sa4 << 8) + (resp->keydata_v6.ip_sa3>> 24));
    cli_out(cli, "%08x.", (resp->keydata_v6.ip_sa3<<8) + (resp->keydata_v6.ip_sa2));
    cli_out(cli, "%08x.", resp->keydata_v6.ip_sa1);
    cli_out(cli, "%08x", resp->keydata_v6.ip_sa0);    
    cli_out(cli, " %08x.", (resp->keydata_v6.ip_da4 << 8) + (resp->keydata_v6.ip_da3>> 24));
    cli_out(cli, "%08x.", (resp->keydata_v6.ip_da3<<8) + (resp->keydata_v6.ip_da2));
    cli_out(cli, "%08x.", resp->keydata_v6.ip_da1);
    cli_out(cli, "%08x", resp->keydata_v6.ip_da0);  
    cli_out(cli, " \n"); 
    
    cli_out(cli, " %-5s", "mask");
    cli_out(cli, " %-4x", resp->keymask_v6.l4_dest_port);
    cli_out(cli, " %-4x", resp->keymask_v6.l4_source_port);
    cli_out(cli, " %-4x", ((resp->keymask_v6.vrf_idh << 4) | (resp->keymask_v6.vrf_idl & 0xf)));     
    cli_out(cli, " %08x.", (resp->keymask_v6.ip_sa4 << 8) + (resp->keymask_v6.ip_sa3>> 24));  
    cli_out(cli, "%08x.", (resp->keymask_v6.ip_sa3<<8) + (resp->keymask_v6.ip_sa2));
    cli_out(cli, "%08x.", resp->keymask_v6.ip_sa1);
    cli_out(cli, "%08x", resp->keymask_v6.ip_sa0);
    cli_out(cli, " %08x.", (resp->keymask_v6.ip_da4 << 8) + (resp->keymask_v6.ip_da3>> 24));  
    cli_out(cli, "%08x.", (resp->keymask_v6.ip_da3<<8) + (resp->keymask_v6.ip_da2));
    cli_out(cli, "%08x.", resp->keymask_v6.ip_da1);
    cli_out(cli, "%08x", resp->keymask_v6.ip_da0); 
    cli_out(cli, " \n");
}

/* show ipv6uc head explain */
static void 
_diag_show_tcam_ipv6uc_hash_entry_head_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 
    cli_out(cli, "Index-Index of entry, ");
    cli_out(cli,  "VRF-Vrfid, ");  
    cli_out(cli,  "IPDA-key_ipda, ");     
    cli_out(cli, " \n"); 
}

/* show ipv6uc  head*/
static void 
_diag_show_tcam_ipv6uc_hash_entry_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " Index");
    cli_out(cli, "%-5s" , "VRF");
    cli_out(cli, "%-39s" , "IPDA");  
    cli_out(cli, "\n");     
}

/* show ipv6uc entry from tcam*/
static void 
_diag_show_tcam_ipv6uc_hash_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, " %-5d", resp->index);
    cli_out(cli, " %-4x", ((resp->dsip_hashkey_v6.vrfid3 << 9)|(resp->dsip_hashkey_v6.vrfid2<< 6)
        |(resp->dsip_hashkey_v6.vrfid1<< 3)|resp->dsip_hashkey_v6.vrfid0));
    cli_out(cli, " %08x.", resp->dsip_hashkey_v6.key_ipda3);
    cli_out(cli, "%08x.", resp->dsip_hashkey_v6.key_ipda2);
    cli_out(cli, "%08x.", resp->dsip_hashkey_v6.key_ipda1);
    cli_out(cli, "%08x", resp->dsip_hashkey_v6.key_ipda0);   
    cli_out(cli, "\n"); 
}

static void 
_diag_show_tcam_dsipda_v6_head_explain(struct cli *cli)
{
    cli_out(cli,  "ICE-ICMP Check En, ");
    cli_out(cli,  "MR-Mast Rpf Fail Cpu En, ");
    cli_out(cli, "IE-IP DA Exception En , ");
    cli_out(cli,  "RI-RpfIfId,");
    cli_out(cli, " \n"); 
    cli_out(cli,  "TC-TTL Check En, ");
    cli_out(cli, "EC-Equal Cost Path Num,");
    cli_out(cli, "L3I-Layer3 Interface, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "PL-Pay Load Select, ");

    cli_out(cli,  "ICE-Isatap Check En, ");
    cli_out(cli,  "ESI-Excep Sub Index, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "BGV-Bidi Pim Group Valid, ");
    cli_out(cli,  "BPG-Bidi Pim Group, ");
    cli_out(cli,  "DP-Deny Pbr, ");
    cli_out(cli,  "VE-Vpls En, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "ECE-Exp3 Ctl En, ");
    cli_out(cli,  "TPT-Tunnel PacketType, ");
    cli_out(cli,  "POT-Tunnel Payload Offset Type, ");
    cli_out(cli, " \n"); 
    cli_out(cli,  "TGO-Tunnel Gre Options, ");
    cli_out(cli,  "TPO-Tunnel Payload Offset, ");

    cli_out(cli,  "FP-ds Fwd Ptr ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_dsipda_v6_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DSIPDA");
    cli_out(cli, "%-4s" , "ICE");
    cli_out(cli, "%-3s" , "MR");
    cli_out(cli, "%-3s" , "IE");
    cli_out(cli, "%-3s" , "TC");
    cli_out(cli, "%-3s" , "EC");
    cli_out(cli, "%-4s" , "EC2");
    cli_out(cli, "%-5s" , "RI");
    cli_out(cli, "%-4s" , "L3I");
    cli_out(cli, "%-3s" , "PL");

    cli_out(cli, "%-4s" , "ICE");
    cli_out(cli, "%-4s" , "ESI");
    cli_out(cli, "%-4s" , "BGV");
    cli_out(cli, "%-4s" , "BPG");
    cli_out(cli, "%-4s" , "DP");
    cli_out(cli, "%-4s" , "VE");
    cli_out(cli, "%-4s" , "ECE");
    cli_out(cli, "%-4s" , "TPT");
    cli_out(cli, "%-4s" , "POT");
    cli_out(cli, "%-4s" , "TGO");
    cli_out(cli, "%-4s" , "TPO");

    cli_out(cli, "%-5s" , "FP");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_ipv6uc_dsipda_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-3x", resp->dsipda_v6.icmp_check_en);
    cli_out(cli, " %-2x", resp->dsipda_v6.mcast_rpf_fail_cpu_en);
    cli_out(cli, " %-2x", resp->dsipda_v6.ip_da_exception_en);
    cli_out(cli, " %-2x", resp->dsipda_v6.ttl_check_en);
    cli_out(cli, " %-2x", resp->dsipda_v6.equal_cost_path_num);
    cli_out(cli, " %-3x", resp->dsipda_v6.equal_cost_path_num2);
    cli_out(cli, " %-4x", resp->dsipda_v6.vrf_id);
    cli_out(cli, " %-3x", resp->dsipda_v6.l3_if_type);
    cli_out(cli, " %-2x", resp->dsipda_v6.payload_select);

    cli_out(cli, " %-3x", resp->dsipda_v6.isatap_check_en);
    cli_out(cli, " %-3x", resp->dsipda_v6.excep_sub_index);
    cli_out(cli, " %-3x", resp->dsipda_v6.bidi_pim_group_valid);
    cli_out(cli, " %-3x", resp->dsipda_v6.bidi_pim_group);
    cli_out(cli, " %-3x", resp->dsipda_v6.deny_pbr);
    cli_out(cli, " %-3x", resp->dsipda_v6.vpls_en);
    cli_out(cli, " %-3x", resp->dsipda_v6.exp3_ctl_en);
    cli_out(cli, " %-3x", resp->dsipda_v6.tunnel_packet_type);
    cli_out(cli, " %-3x", resp->dsipda_v6.tunnel_payload_offset_type);
    cli_out(cli, " %-3x", resp->dsipda_v6.tunnel_gre_options);
    cli_out(cli, " %-3x", resp->dsipda_v6.tunnel_payload_offset);

    cli_out(cli, " %-5x", resp->dsipda_v6.ds_fwd_ptr);
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_dsipsa_v6_head_explain(struct cli *cli)
{
    cli_out(cli,  "RC-Rpf Check En, ");
    cli_out(cli,  "MRI-Ipsa More Rpf If, ");
    
    cli_out(cli, "RIV3-RpfIfId Valid3, ");
    cli_out(cli,  "RIV2-RpfIfId Valid2");
    cli_out(cli, " \n"); 
    cli_out(cli, "RIV1-RpfIfId Valid1, ");
    cli_out(cli, "RIV0-RpfIfId Valid0, ");
    cli_out(cli, "RI3-RpfIfId3, ");
    cli_out(cli,  "RI2-RpfIfId2, ");
    cli_out(cli, " \n"); 
    cli_out(cli, "RI1-RpfIfId1, ");
    cli_out(cli,  "RI0-RpfIfId0, ");
    cli_out(cli, " \n"); 
}

static void 
_diag_show_tcam_dsipsa_v6_head(struct cli *cli)
{
    cli_out(cli, "%-8s" , " DSIPSA");
    cli_out(cli, "%-3s" , "RC");
    cli_out(cli, "%-3s" , "MRI");
    cli_out(cli, "%-5s" , "RIV3");
    cli_out(cli, "%-5s" , "RIV2");
    cli_out(cli, "%-5s" , "RIV1");
    cli_out(cli, "%-5s" , "RIV0");
    cli_out(cli, "%-5s" , "RI3");
    cli_out(cli, "%-5s" , "RI2");
    cli_out(cli, "%-5s" , "RI1");
    cli_out(cli, "%-5s" , "RI0");
    cli_out(cli, " \n"); 
}

static void
_diag_show_tcam_ipuc_dsipsa_v6_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{
    cli_out(cli, "%7s" , "");
    cli_out(cli, " %-2x", resp->dsipsa_v6.check_en);    
    cli_out(cli, " %-2x", resp->dsipsa_v6.ipsa_more_rpf_if);    
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id_valid3);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id_valid2);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id_valid1);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id_valid0);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id3);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id2);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id1);
    cli_out(cli, " %-4x", resp->dsipsa_v6.if_id0);
    cli_out(cli, " \n");    
}

/* show one ipv6uc entry */
CLI (show_tcam_ipv6uc_one_entry,
     show_tcam_ipv6uc_one_entry_cmd,
     "show tcam ipv6uc CHIPID entry WORD (hash|tcam)(list|) (explain|)",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPv6 Route TCAM",
     "Chip ID",
     "Show entry information",
     "Entry ID",
     "Entry in hash",
     "Entry in tcam",
     "List ipv6 sram",
     "Show ipv6 explain")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    diag_sram_entry_req_t  sram_req; 
    diag_sram_entry_resp_t sram_resp;
    uint32 is_list = 0;
    uint32 is_explain = 0;   
    
    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entry_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[1], 0, 0x0FFFFFFF);

    if ( 5 == argc  ) 
    {
        is_list  = 1;
        is_explain = 1;
    }
    else if ( 4 == argc ) 
    {
        if (0 == sal_strcmp (argv[3], "explain"))
        {
            is_explain = 1;
        }
        else 
        {
            is_list = 1;
        }
    }

    if(0 == sal_strcmp(argv[2],"hash"))
    {
        req.position = sram_type;
    }
    else
    {
        req.position = tcam_type;    
    }
        
    DIAG_SHOW_IF_ERROR_RETURN(_lcsh_lcm_showtcam_ipv6_one_entry(&req, &resp ));
    if ( DIAG_GET_TCAM_INDEX_INVALID == resp.chip_id )
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp.index -1 );
        return CLI_SUCCESS;
    }

    if ( DIAG_GET_TCAM_INDEX_EXCEED == resp.chip_id )
    {
        cli_out( cli, "%%The index is invalid\n" );
    }
    if (is_explain)
    {
        if (tcam_type == resp.position )
        {
            _diag_show_tcam_ipv6uc_entry_head_explain(cli);
        }    
        else
        {
            _diag_show_tcam_ipv6uc_hash_entry_head_explain(cli);
        }
    }

    if (tcam_type  == resp.position )
    {
        _diag_show_tcam_ipv6uc_entry_head( cli );
        _diag_show_tcam_ipv6uc_entry( cli, &resp );
    }
    else
    {
        _diag_show_tcam_ipv6uc_hash_entry_head( cli );
        _diag_show_tcam_ipv6uc_hash_entry( cli, &resp );        
    }

    if ( is_explain )
    {
        _diag_show_tcam_dsipda_v6_head_explain(cli);        
    }

    _diag_show_tcam_dsipda_v6_head(cli);
    _diag_show_tcam_ipv6uc_dsipda_entry( cli, &resp );
    cli_out(cli,"\n");

    if ( is_explain )
    {
        _diag_show_tcam_dsipsa_v6_head_explain(cli);        
    }
    
    _diag_show_tcam_dsipsa_v6_head(cli);
    _diag_show_tcam_ipuc_dsipsa_v6_entry( cli, &resp );
    cli_out(cli,"\n");

    if (is_list )
    {
        if ( resp.dsipda_v6.ds_fwd_ptr != 0xfffff)
        {
            sram_req.chip_id = req.chip_id;
            sram_req.table_type = DIAG_DS_FWD;
            sram_req.index = resp.dsipda_v6.ds_fwd_ptr;
            diag_show_sram_dsfwd( cli, &sram_req, &sram_resp, is_list, is_explain);
        }
        cli_out(cli,"\n");
    }
    
    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_show_tcam_ipv6_entries( diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{
   uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entries_resp_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entries_resp_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPV6UC_ENTRIES;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [chsm_lcm_showtcam_ipv6_entries], error id is %d", ret);
        return ret;
    }   

    return ret;

}

/* show ipv6uc head explain */
static void 
_diag_show_tcam_ipv6_hash_entries_head_explain(struct cli *cli)
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_HASH_v6,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open ipuc v6 failed.\n");
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     HASH IPV6UC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "KID-key_ipda, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "VRD-Vrfid, ");
    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-5s" , "VRF");
    sal_fprintf(pf, "%-39s" , "KID");
    sal_fprintf(pf, "\n");     

    sal_fclose(pf);

}
/* show  ipv6uc entries */
CLI (show_tcam_ipv6uc_entries,
     show_tcam_ipv6uc_entries_cmd,
     "show tcam ipv6uc CHIPID entries",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPv6 Route TCAM",
     "Chip ID",
     "Show entry information")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;

    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entries_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);
    
    if (diag_show_lock_for_ipv6uc_entries)
    {
        cli_out(cli," Others is showing the ipv6 tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_ipv6uc_entries = 1;
    
    _diag_show_tcam_ipv6_entries_head_explain( cli ); 
    _diag_show_tcam_ipv6_hash_entries_head_explain( cli ); 
    if (_lcsh_lcm_show_tcam_ipv6_entries(&req, &resp) < 0)
    {
        diag_show_lock_for_ipv6uc_entries = 0;
        return CLI_ERROR;
    }
    
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPUC_FILE_V6));
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPUC_FILE_HASH_v6));
    cli_out(cli,"\n");

    diag_show_lock_for_ipv6uc_entries = 0;
    
    return CLI_SUCCESS;
}

static int32
_lcsh_lcm_show_tcam_ipmc_one_entry(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
{        
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;
    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entry_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entry_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPMC_ENTRY;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_show_tcam_ipmc_one_entry], error id is %d", ret);
        return ret;
    }

    sal_memcpy(resp,st_rcv.msg, sizeof(diag_ipv4_v6_tcam_entry_t));    

    return ret;

}

/* show ipuc entry entry  explain */
static void 
_diag_show_tcam_ipmc_entry_head_explain(struct cli *cli)
{
    cli_out(cli, " \n"); 

    cli_out(cli,"Index-Index of entry, ");
    cli_out(cli, "DP-DscP, ");
    cli_out(cli, "FI-Frag Info, ");
    cli_out(cli, "IO-Ip Options, ");
    cli_out(cli, "TCP-Is Tcp, ");
    cli_out(cli," \n"); 
    cli_out(cli, "APP-Is Application, ");
    cli_out(cli, "UDP-Is Udp, ");
    cli_out(cli, "TP-Layer4 Type, ");
    cli_out(cli, "LM-Lkp Mode, ");
    cli_out(cli, "PL-Pbr Label, ");
    cli_out(cli," \n"); 
    cli_out(cli, "TID-Table Id, ");
    cli_out(cli, "MAP-l4info Mapped, ");
    cli_out(cli, "DP-l4 Dest Port, ");
    cli_out(cli, "SP-l4 Source Port, ");
    cli_out(cli," \n"); 
    cli_out(cli, "VID-Vrf Id, ");
    cli_out(cli, "IPDA-Ip Da, ");
    cli_out(cli, "IPSA/VRF-Ip Sa/VRF, ");

    cli_out(cli, " \n"); 
}

/* show ipuc entry head*/
static void 
_diag_show_tcam_ipmc_entry_head(struct cli *cli)
{
    cli_out(cli, "%-7s" , " Index");
    cli_out(cli, "%-3s" , "DP");
    cli_out(cli, "%-3s" , "FI");
    cli_out(cli, "%-3s" , "IO");
    cli_out(cli, "%-4s" , "APP");
    cli_out(cli, "%-4s" , "TCP");
    cli_out(cli, "%-4s" , "UDP");
    cli_out(cli, "%-3s" , "TP");
    cli_out(cli, "%-3s" , "LM");
    cli_out(cli, "%-3s" , "PL");
    cli_out(cli, "%-4s" , "TID");
    cli_out(cli, "%-5s" , "MAP");
    cli_out(cli, "%-5s" , "DP");
    cli_out(cli, "%-5s" , "SP");
    cli_out(cli, "%-5s" , "VID");
    cli_out(cli, "%-15s" , "IPDA");
    cli_out(cli, "%-8s" , "IPSA/VRF");
    cli_out(cli, " \n"); 
}

/* show ipuc entry from tcam*/
static void 
_diag_show_tcam_ipmc_entry(struct cli *cli,  diag_ipv4_v6_tcam_entry_t* resp )
{

    cli_out(cli, " %-5d", resp->index);
    cli_out(cli, " %-2x", resp->ipmc_key_da.dscp);
    cli_out(cli, " %-2x", resp->ipmc_key_da.frag_info);
    cli_out(cli, " %-2x", resp->ipmc_key_da.ip_options);
    cli_out(cli, " %-3x", resp->ipmc_key_da.is_application);
    cli_out(cli, " %-3x", resp->ipmc_key_da.is_tcp);
    cli_out(cli, " %-3x", resp->ipmc_key_da.is_udp);
    cli_out(cli, " %-2x", resp->ipmc_key_da.layer4_type);
    cli_out(cli, " %-2x", resp->ipmc_key_da.lkp_mode);
    cli_out(cli, " %-2x", resp->ipmc_key_da.pbr_label);
    cli_out(cli, " %-3x", resp->ipmc_key_da.table_id0 | (resp->ipmc_key_da.table_id1 << 1));
    cli_out(cli, " %-4x", resp->ipmc_key_da.l4info_mapped);
    cli_out(cli, " %-4x", resp->ipmc_key_da.l4_dest_port);
    cli_out(cli, " %-4x", resp->ipmc_key_da.l4_source_port);
    cli_out(cli, " %-4x", resp->ipmc_key_da.vrf_idl | (resp->ipmc_key_da.vrf_idh << 4));
    cli_out(cli, " %02x.", (resp->ipmc_key_da.ip_da >> 24) & 0xff);
    cli_out(cli, " %02x.", (resp->ipmc_key_da.ip_da >> 16) & 0xff);
    cli_out(cli, " %02x.", (resp->ipmc_key_da.ip_da >> 8) & 0xff);
    cli_out(cli, " %02x", (resp->ipmc_key_da.ip_da ) & 0xff);
    cli_out(cli, " %-8x", resp->ipmc_key_da.ip_sa);

    cli_out(cli, " \n"); 
    cli_out(cli, " %-5s", "mask");
    cli_out(cli, " %-2x", resp->ipmc_key_mask.dscp);
    cli_out(cli, " %-2x", resp->ipmc_key_mask.frag_info);
    cli_out(cli, " %-2x", resp->ipmc_key_mask.ip_options);
    cli_out(cli, " %-3x", resp->ipmc_key_mask.is_application);
    cli_out(cli, " %-3x", resp->ipmc_key_mask.is_tcp);
    cli_out(cli, " %-3x", resp->ipmc_key_mask.is_udp);
    cli_out(cli, " %-2x", resp->ipmc_key_mask.layer4_type);
    cli_out(cli, " %-2x", resp->ipmc_key_mask.lkp_mode);
    cli_out(cli, " %-2x", resp->ipmc_key_mask.pbr_label);
    cli_out(cli, " %-3x", resp->ipmc_key_mask.table_id0 | (resp->ipmc_key_mask.table_id1 << 1));
    cli_out(cli, " %-4x", resp->ipmc_key_mask.l4info_mapped);
    cli_out(cli, " %-4x", resp->ipmc_key_mask.l4_dest_port);
    cli_out(cli, " %-4x", resp->ipmc_key_mask.l4_source_port);
    cli_out(cli, " %-4x", resp->ipmc_key_mask.vrf_idl | (resp->ipmc_key_mask.vrf_idh << 4));
    cli_out(cli, " %02x.", (resp->ipmc_key_mask.ip_da >> 24) & 0xff);
    cli_out(cli, " %02x.", (resp->ipmc_key_mask.ip_da >> 16) & 0xff);
    cli_out(cli, " %02x.", (resp->ipmc_key_mask.ip_da >> 8) & 0xff);
    cli_out(cli, " %02x", (resp->ipmc_key_mask.ip_da ) & 0xff);
    cli_out(cli, " %-8x", resp->ipmc_key_mask.ip_sa);

    cli_out(cli, "\n"); 
}

/* show one ipmc entry */
CLI (show_tcam_ipmc_one_entry,
     show_tcam_ipmc_one_entry_cmd,
     "show tcam ipmc CHIPID entry WORD (list |) (explain |)",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPMC TCAM",
     "TCAM ID",
     "Show entry information",
     "Entry ID",
     "List IMPC Sram ",
     "Show IMPC explain")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    diag_sram_entry_req_t  sram_req; 
    diag_sram_entry_resp_t sram_resp;
    uint32 is_list=0;
    uint32 is_explain=0;

    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entry_t));
    sal_memset(&sram_req, 0 , sizeof(diag_sram_entry_req_t));
    sal_memset(&sram_resp,0,sizeof(diag_sram_entry_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);
    CLI_GET_INTEGER_RANGE ("Entry ID", req.index, argv[1], 0, 0x0FFFFFFF);

    if ( 4 == argc ) 
    {
        is_list  = 1;
        is_explain = 1;
    }
    else if ( 3 ==argc) 
    {
        if (0 == sal_strcmp (argv[2], "explain") )
        {
            is_explain = 1;
        }
        else 
        {
            is_list = 1;
        }
    }
     
    DIAG_SHOW_IF_ERROR_RETURN(_lcsh_lcm_show_tcam_ipmc_one_entry(&req, &resp ));
    if ( DIAG_GET_TCAM_INDEX_INVALID == resp.chip_id )
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp.index -1 );
        return CLI_SUCCESS;
    }
    if ( DIAG_GET_TCAM_INDEX_EXCEED == resp.chip_id )
    {
        cli_out( cli, "%%The index is invalid. \n"  );
    }

    sram_req.index = req.index;
    sram_req.chip_id = req.chip_id;
    if (is_explain)
    {
         _diag_show_tcam_ipmc_entry_head_explain( cli );
         cli_out(cli,"\n");
    }
    _diag_show_tcam_ipmc_entry_head( cli );
    _diag_show_tcam_ipmc_entry( cli, &resp );
    cli_out(cli,"\n");
    if (is_list)
    {
        sram_req.table_type = DIAG_DS_IPV4_MCAST_RPF;
        diag_show_sram_ipmc_dssa( cli, &sram_req, &sram_resp, is_list, is_explain); 
        sram_req.table_type = DIAG_DS_IPV4_MCAST_DA;
        diag_show_sram_ipmc_dsda( cli, &sram_req, &sram_resp, is_list,  is_explain);
    } 

    return CLI_SUCCESS;
}

/* show ipuc entry entry  explain */
static void 
_diag_show_tcam_ipmc_entries_head_explain()
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPMC_FILE_V4,"w+");
    if (pf== NULL ) 
    {
        LCSH_LOG_ERR("Open /filename failed.\n");
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     TCAM IPMC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, " \n");     

    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "DP-DscP, ");
    sal_fprintf(pf,  "FI-Frag Info, ");
    sal_fprintf(pf,  "IO-Ip Options, ");
    sal_fprintf(pf,  "TCP-Is Tcp, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "APP-Is Application, ");
    sal_fprintf(pf,  "UDP-Is Udp, ");
    sal_fprintf(pf,  "TP-Layer4 Type, ");
    sal_fprintf(pf,  "LM-Lkp Mode, ");
    sal_fprintf(pf,  "PL-Pbr Label, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "TID-Table Id, ");
    sal_fprintf(pf,  "MAP-l4info Mapped, ");
    sal_fprintf(pf,  "DP-l4 Dest Port, ");
    sal_fprintf(pf,  "SP-l4 Source Port, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "VID-Vrf Id, ");
    sal_fprintf(pf,  "IPDA-Ip Da, ");
    sal_fprintf(pf, "IPSA/VRF-Ip Sa/VRF, ");

    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, "%-6s" , "Index");
    sal_fprintf(pf, "%-3s" , "DP");
    sal_fprintf(pf, "%-3s" , "FI");
    sal_fprintf(pf, "%-3s" , "IO");
    sal_fprintf(pf, "%-4s" , "APP");
    sal_fprintf(pf, "%-4s" , "TCP");
    sal_fprintf(pf, "%-4s" , "UDP");
    sal_fprintf(pf, "%-3s" , "TP");
    sal_fprintf(pf, "%-3s" , "LM");
    sal_fprintf(pf, "%-3s" , "PL");
    sal_fprintf(pf, "%-4s" , "TID");
    sal_fprintf(pf, "%-5s" , "MAP");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");
    sal_fprintf(pf, "%-5s" , "VID");
    sal_fprintf(pf, "%-15s" , "IPDA");
    sal_fprintf(pf, "%-8s" , "IPSA/VRF");
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);
    
}

static int32
_lcsh_lcm_show_tcam_ipmc_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{    
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entries_resp_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entries_resp_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPMC_ENTRIES;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [chsm_lcm_showtcam_ipv4_entries], error id is %d", ret);
        return ret;
    }

    return ret;

}

/* show a set of  ipmc entries */
CLI (show_tcam_ipmc_entries,
     show_tcam_ipmc_entries_cmd,
     "show tcam ipmc CHIPID entries ",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPMC TCAM",
     "TCAM ID",
     "Show entry information")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;

    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entries_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);

    if (diag_show_lock_for_ipmc_entries)
    {
        cli_out(cli,"Other is showing the ipuc tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_ipmc_entries = 1;

    _diag_show_tcam_ipmc_entries_head_explain();
    cli_out(cli,"\n");
    
    if (_lcsh_lcm_show_tcam_ipmc_entries(&req, &resp) < 0)
    {
        diag_show_lock_for_ipmc_entries = 0;
        return CLI_ERROR;
    }

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPMC_FILE_V4));

    cli_out(cli,"\n");

    diag_show_lock_for_ipmc_entries = 0;
    return CLI_SUCCESS;
}
static int32
_lcsh_lcm_showtcam_ipv6mc_one_entry(diag_l3_tcam_entry_req_t* req, diag_ipv6_tcam_entry_t *resp)
{   
   uint32 ret = 0;

    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv6_tcam_entry_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv6_tcam_entry_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPMCV6_ENTRY;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [_lcsh_lcm_showtcam_ipv6mc_one_entry], error id is %d", ret);
        return ret;
    }

    sal_memcpy(resp,st_rcv.msg, sizeof(diag_ipv6_tcam_entry_t));    

    return ret;

}

static void 
_diag_show_tcam_ipv6mc_entries_head_explain(struct cli *cli)
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPMC_FILE_V6,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open ipuc v6 failed.\n");
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     TCAM IPV6MC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "DP-l4 Dest Port, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "SP-l4 Src Port, ");
    sal_fprintf(pf, "IPSA-IP SA , ");
    sal_fprintf(pf,  "IPDA-IP DA");
    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-5s" , "DP");
    sal_fprintf(pf, "%-5s" , "SP");

    sal_fprintf(pf, "%-5s" , "VRFh");
    sal_fprintf(pf, "%-5s" , "VRFl");

    sal_fprintf(pf, "%-5s" , "TID");
    sal_fprintf(pf, "%-17s" , "IPSA");
    sal_fprintf(pf, "%-17s" , "IPDA");
    sal_fprintf(pf, "\n");     

    sal_fclose(pf);

}

/* show ipv6uc head explain */
static void 
_diag_show_tcam_ipv6mc_hash_entries_head_explain(struct cli *cli)
{
    FILE *pf =NULL;

    pf = sal_fopen(SHOW_TCAM_ALL_IPMC_FILE_HASH_v6,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open ipuc v6 failed.\n");
    }

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "-------------------------------------------------------------\n");
    sal_fprintf(pf, "                     HASH IPV6MC \n");
    sal_fprintf(pf, "-------------------------------------------------------------\n");

    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, "Index-Index of entry, ");
    sal_fprintf(pf,  "KID-key_ipda, ");
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf,  "VRD-Vrfid, ");

    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, "%-7s" , " Index");
    sal_fprintf(pf, "%-39s" , "KID");

    sal_fprintf(pf, "%-5s" , "VRD0");
    sal_fprintf(pf, "%-5s" , "VRD1");
    sal_fprintf(pf, "%-5s" , "VRD2");
    sal_fprintf(pf, "%-5s" , "VRD3");

    sal_fprintf(pf, "\n");     

    sal_fclose(pf);

}

/* show one ipmc entry */
CLI (show_tcam_ipv6mc_one_entry,
     show_tcam_ipv6mc_one_entry_cmd,
     "show tcam ipv6mc CHIPID entry WORD (list |) (explain |)",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPV6MC TCAM",
     "TCAM ID",
     "Show entry information",
     "Entry ID",
     "List IMPC Sram ",
     "Show IMPC explain")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv6_tcam_entry_t resp;
    
    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv6_tcam_entry_t));
    
    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);

    if (diag_show_lock_for_ipv6mc_entries)
    {
        cli_out(cli," Others is showing the ipv6 tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_ipv6mc_entries = 1;
    
    _diag_show_tcam_ipv6mc_entries_head_explain( cli ); 
    _diag_show_tcam_ipv6mc_hash_entries_head_explain( cli ); 
    if (_lcsh_lcm_showtcam_ipv6mc_one_entry(&req, &resp) < 0)
    {
        diag_show_lock_for_ipv6mc_entries = 0;
        return CLI_ERROR;
    }

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPMC_FILE_V6));
    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPMC_FILE_HASH_v6));
    cli_out(cli,"\n");

    diag_show_lock_for_ipv6mc_entries = 0;
    
    return CLI_SUCCESS;
}

/*added by chenxw for bug 20481, 2012-09-21.*/

static int32
_lcsh_lcm_show_tcam_ipv6mc_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{    
    uint32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_l3_tcam_entry_req_t*   p_req = NULL;
    diag_ipv4_v6_tcam_entries_resp_t* p_recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_req = (diag_l3_tcam_entry_req_t *)req;
    p_recv = (diag_ipv4_v6_tcam_entries_resp_t *)resp;
    
    sal_memcpy(st_msg.msg, p_req, sizeof(diag_l3_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_l3_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPMCV6_ENTRIES;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message  fail [chsm_lcm_showtcam_ipv6mc_entries], error id is %d", ret);
        return ret;
    }

    return ret;

}

/* show a set of  ipmc entries */
CLI (show_tcam_ipv6mc_entries,
     show_tcam_ipv6mc_entries_cmd,
     "show tcam ipv6mc CHIPID entries ",
     CLI_SHOW_STR,
     CLI_SHOW_TCAM_STR,
     "Show IPV6MC TCAM",
     "TCAM ID",
     "Show entry information")
{
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;

    sal_memset(&req, 0 , sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp,0,sizeof(diag_ipv4_v6_tcam_entries_resp_t));

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[0], 0, 0);

    if (diag_show_lock_for_ipv6mc_entries)
    {
        cli_out(cli,"Other is showing the ipv6mc tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_ipv6mc_entries = 1;

    _diag_show_tcam_ipv6mc_entries_head_explain(cli);
    cli_out(cli,"\n");
    
    if (_lcsh_lcm_show_tcam_ipv6mc_entries(&req, &resp) < 0)
    {
        diag_show_lock_for_ipv6mc_entries = 0;
        return CLI_ERROR;
    }

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_ALL_IPMC_FILE_V6));

    cli_out(cli,"\n");

    diag_show_lock_for_ipv6mc_entries = 0;
    return CLI_SUCCESS;
}

static void 
_diag_show_tcam_usrid_head_explain(struct cli* cli,diag_usrid_tcam_entry_req_t* req)
{
    FILE* pf;
    
    pf = sal_fopen(SHOW_TCAM_USRID_INFO_FILE,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open usr-id file failed.\n");
        return;
    }

    switch( req->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " MacSA-Mac Sa,");

            break;
        case DIAG_USRID_KEY_TYPE_IPV4:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " CVID-Cvlan Id,");
            sal_fprintf(pf,  " SVID-Svlan Id,");
            sal_fprintf(pf,  " 4DP-L4Dest Port,");
            sal_fprintf(pf,  " 4SP-L4Source Port,");
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " IPSA-Ip Sa,");
            sal_fprintf(pf,  " MacSA-Mac Sa,");
            
            break;
        case DIAG_USRID_KEY_TYPE_IPV6:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " CVID-Cvlan Id,");
            sal_fprintf(pf,  " SVID-Svlan Id,");
            sal_fprintf(pf,  " 4DP-L4Dest Port,");
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " 4SP-L4Source Port,");
            sal_fprintf(pf,  " IPv6SA-Ip V6 Sa,");
            sal_fprintf(pf,  " MacSA-Mac Sa,");
            
            break;
        case DIAG_USRID_KEY_TYPE_VLAN:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " MacSA-Mac Sa,");
            sal_fprintf(pf,  " FRS-From Sgmac,");
            sal_fprintf(pf,  " TBL-Table ID,");
            sal_fprintf(pf,  " GSP-Global source port,");
            sal_fprintf(pf,  " SVID-Svlan Id,");
            sal_fprintf(pf,  " CVID-Cvlan Id,");
    
            break;
        default:
            break;
    }
    sal_fprintf(pf,  " ASVD-Aps Select Valid,");
    sal_fprintf(pf,  " UVP-User Vlan Ptr,");
    sal_fprintf(pf,  " EXE-Exception En,");
    sal_fprintf(pf, " \n");
    sal_fprintf(pf,  " BAl-By Pass All,");
    sal_fprintf(pf,  " BDE-Binding En,");
    sal_fprintf(pf,  " SCP-Src Communicate Port,");
    sal_fprintf(pf,  " FPV-ds Fwd Ptr Valid,");
    sal_fprintf(pf,  " SQS-Src Queue Select,");
    sal_fprintf(pf, " \n");
    sal_fprintf(pf,  " VPT-Vpls Port Type,");
    sal_fprintf(pf,  " BDD-Binding Datam,");
    sal_fprintf(pf,  " BMA-Binding MAc Sa,");
    sal_fprintf(pf,  " BD-Binding Data,");
    sal_fprintf(pf, " \n\n");

    sal_fclose(pf);

}

static void 
_diag_show_tcam_usrid_creat_file()
{
    FILE* pf;
    pf = sal_fopen(SHOW_TCAM_USRID_INFO_FILE,"w+");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open usr-id file failed.\n");
        return;
    }
    sal_fclose(pf);
}

static void 
_diag_show_tcam_usrid_explain_head(diag_usrid_tcam_entry_req_t* req)
{
    FILE* pf;
    
    pf = sal_fopen(SHOW_TCAM_USRID_INFO_FILE,"w");
    if (NULL == pf) 
    {
        LCSH_LOG_ERR("Open /filename failed.\n");
        return;
    }

    switch( req->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " MacSA-Mac Sa,");

            break;
        case DIAG_USRID_KEY_TYPE_IPV4:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " CVID-Cvlan Id,");
            sal_fprintf(pf,  " SVID-Svlan Id,");
            sal_fprintf(pf,  " 4DP-L4Dest Port,");
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " 4SP-L4Source Port,");
            sal_fprintf(pf,  " IPSA-Ip Sa,");
            sal_fprintf(pf,  " MacSA-Mac Sa,");
            
            break;
        case DIAG_USRID_KEY_TYPE_IPV6:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " CVID-Cvlan Id,");
            sal_fprintf(pf,  " SVID-Svlan Id,");
            sal_fprintf(pf,  " 4DP-L4Dest Port,");
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " 4SP-L4Source Port,");
            sal_fprintf(pf,  " IPv6SA-Ip V6 Sa,");
            sal_fprintf(pf,  " MacSA-Mac Sa,");
            
            break;
        case DIAG_USRID_KEY_TYPE_VLAN:
            sal_fprintf(pf, " \n");
            sal_fprintf(pf,  " Label-user id label.");
            sal_fprintf(pf,  " MacSA-Mac Sa,");
            sal_fprintf(pf,  " FRS-From Sgmac,");
            sal_fprintf(pf,  " TBL-Table ID,");
            sal_fprintf(pf,  " GSP-Global source port,");
            sal_fprintf(pf,  " SVID-Svlan Id,");
            sal_fprintf(pf,  " CVID-Cvlan Id,");
    
            break;
        default:
            break;
    }
    sal_fprintf(pf,  " ASVD-Aps Select Valid,");
    sal_fprintf(pf,  " UVP-User Vlan Ptr,");
    sal_fprintf(pf,  " EXE-Exception En,");
    sal_fprintf(pf, " \n");
    sal_fprintf(pf,  " BAl-By Pass All,");
    sal_fprintf(pf,  " BDE-Binding En,");
    sal_fprintf(pf,  " SCP-Src Communicate Port,");
    sal_fprintf(pf,  " FPV-ds Fwd Ptr Valid,");
    sal_fprintf(pf,  " SQS-Src Queue Select,");
    sal_fprintf(pf, " \n");
    sal_fprintf(pf,  " VPT-Vpls Port Type,");
    sal_fprintf(pf,  " BDD-Binding Datam,");
    sal_fprintf(pf,  " BMA-Binding MAc Sa,");
    sal_fprintf(pf,  " BD-Binding Data,");
    sal_fprintf(pf, " \n\n");

    sal_fprintf(pf, "%-7s" , " Index");
    switch( req->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, "%-6s" , "Label");
            sal_fprintf(pf, "%-16s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_IPV4:
            sal_fprintf(pf, "%-6s" , "Label");
            sal_fprintf(pf, "%-6s" , "CVID");
            sal_fprintf(pf, "%-6s" , "SVID");
            
            sal_fprintf(pf, "%-5s" , "4DP");
            sal_fprintf(pf, "%-5s" , "4SP");
            sal_fprintf(pf, "%-15s" , "IPSA");
            sal_fprintf(pf, "%-16s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_IPV6:
            sal_fprintf(pf, "%-6s" , "Label");
            sal_fprintf(pf, "%-6s" , "CVID");
            sal_fprintf(pf, "%-6s" , "SVID");
            
            sal_fprintf(pf, "%-5s" , "4DP");
            sal_fprintf(pf, "%-5s" , "4SP");
            sal_fprintf(pf, "%-39s" , "IPv6SA");          
            sal_fprintf(pf, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_VLAN:
            sal_fprintf(pf, "%-5s" , "Label");
            sal_fprintf(pf, "%-5s" , "FRS");
            sal_fprintf(pf, "%-5s" , "TBL");
            sal_fprintf(pf, "%-6s" , "GSP");
            sal_fprintf(pf, "%-6s" , "SVID");
            sal_fprintf(pf, "%-10s" , "CID");
            break;
        default:
            break;
    }
    sal_fprintf(pf, "%-5s" , "Ds");
    sal_fprintf(pf, "%-5s" , "ASVD");
    sal_fprintf(pf, "%-5s" , "UVP");
    sal_fprintf(pf, "%-4s" , "EXE");
    sal_fprintf(pf, "%-4s" , "BAl");
    sal_fprintf(pf, "%-4s" , "BDE");
    sal_fprintf(pf, "%-4s" , "SCP");
    sal_fprintf(pf, "%-4s" , "FPV");
    sal_fprintf(pf, "%-4s" , "SQS");
    sal_fprintf(pf, "%-4s" , "VPT");
    sal_fprintf(pf, "%-6s" , "BDD");
    sal_fprintf(pf, "%-4s" , "BMA");
    sal_fprintf(pf, "%-4s" , "BD");
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);

}
static int32
_lcsh_lcm_show_tcam_usrid(diag_usrid_tcam_entry_req_t* p_req, diag_usrid_tcam_entries_resp_t *p_resp)
{   
    uint32 ret = 0; 

    lcapi_lcm_lcsh_msg_t st_msg;
    lcapi_lcm_lcsh_msg_t st_rcv;

    diag_usrid_tcam_entry_req_t*   req = NULL;
    diag_usrid_tcam_entries_resp_t* recv=NULL;
    
    sal_memset(&st_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_rcv, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    req = (diag_usrid_tcam_entry_req_t *)p_req;

    sal_memcpy(st_msg.msg, req, sizeof(diag_usrid_tcam_entry_req_t));
    st_msg.msg_len = sizeof(diag_usrid_tcam_entry_req_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    st_msg.msg_type = LCAPI_LCM_LCSH_SHOW_TCAM_USRID;
  
    ret = lcsh_clnt_send_msg(&st_msg, &st_rcv);
    if (ret)
    {
        LCSH_LOG_ERR("Lcsh: send message test1 fail, error id is %d", ret);
        return ret;
    }

    recv = (diag_usrid_tcam_entries_resp_t*)st_rcv.msg;
    
    sal_memcpy(p_resp,st_rcv.msg, sizeof(diag_usrid_tcam_entries_resp_t));    

    return ret;
}

CLI (show_usrid_tcam,
     show_one_usrid_tcam_cmd,
     "show tcam usr-id ( vlan | mac | ipv4 | ipv6) CHIPID  entry INDEX (explain|)",
     CLI_SHOW_STR,
     "TCAM information",
     "UserID information",
     "UserID VLAN key",
     "UserID MAC key",
     "UserID IPv4 key",
     "UserID IPv6 key",
     "ChipID",
     "Single entry",
     "Entry index",
     "Explanation")
{
    diag_usrid_tcam_entry_req_t  req;
    diag_usrid_tcam_entries_resp_t resp;

    sal_memset( &req, 0, sizeof(diag_usrid_tcam_entry_req_t));  
    sal_memset( &resp, 0, sizeof(diag_usrid_tcam_entries_resp_t));

    if (0 == sal_strcmp(argv[0], "mac")) 
    {
        req.key_type= DIAG_USRID_KEY_TYPE_MAC;
    }
    else if (0 == sal_strcmp(argv[0], "ipv4")) 
    {
         req.key_type = DIAG_USRID_KEY_TYPE_IPV4;
    }
    else if (0 == sal_strcmp(argv[0], "ipv6")) 
    {
         req.key_type = DIAG_USRID_KEY_TYPE_IPV6;
    }
    else 
    {
        req.key_type = DIAG_USRID_KEY_TYPE_VLAN;
    }

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[1], 0, 0);
    CLI_GET_INTEGER_RANGE ("Index", req.index, argv[2], 0, 0x0FFFFFFF);

    if (argc >3 )
    {
        _diag_show_tcam_usrid_head_explain( cli ,&req);
    }
    else
    {
        _diag_show_tcam_usrid_creat_file();
    }

    DIAG_SHOW_IF_ERROR_RETURN( _lcsh_lcm_show_tcam_usrid(&req, &resp ));

    if ( DIAG_GET_TCAM_INDEX_INVALID == resp.chip_id)
    {
        cli_out( cli, "%%The index can not be more than %d\n" , resp.index-1 );
        return CLI_ERROR;
    }

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_USRID_INFO_FILE)); 
    cli_out (cli, " \n"); 

  return CLI_SUCCESS;
}

/* show usrid head*/
void 
diag_show_tcam_usrid_head(struct cli *cli , 
                       diag_usrid_tcam_entries_resp_t* resp)
{
    cli_out(cli, " \n");

    cli_out(cli, "%-7s" , " Index");
    switch( resp->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            cli_out(cli, "%-6s" , "Label");
            cli_out(cli, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_IPV4:
            cli_out(cli, "%-6s" , "Label");
            cli_out(cli, "%-6s" , "CVID");
            cli_out(cli, "%-6s" , "SVID");
            
            cli_out(cli, "%-5s" , "4DP");
            cli_out(cli, "%-5s" , "4SP");
            cli_out(cli, "%-15s" , "IPSA");
            cli_out(cli, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_IPV6:
            cli_out(cli, "%-6s" , "Label");
            cli_out(cli, "%-6s" , "CVID");
            cli_out(cli, "%-6s" , "SVID");
            
            cli_out(cli, "%-5s" , "4DP");
            cli_out(cli, "%-6s" , "4SP");
            cli_out(cli, "%-39s" , "IPv6SA");          
            cli_out(cli, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_VLAN:
            cli_out(cli, "%-5s" , "Label");
            cli_out(cli, "%-5s" , "FRS");
            cli_out(cli, "%-5s" , "TBL");
            cli_out(cli, "%-6s" , "GSP");
            cli_out(cli, "%-6s" , "SVID");
            cli_out(cli, "%-10s" , "CID");
            break;
        default:
            break;
    }
    cli_out(cli, "%-5s" , "Ds");
    cli_out(cli, "%-5s" , "ASVD");
    cli_out(cli, "%-5s" , "UVP");
    cli_out(cli, "%-4s" , "EXE");
    cli_out(cli, "%-4s" , "BAl");
    cli_out(cli, "%-4s" , "BDE");
    cli_out(cli, "%-4s" , "SCP");
    cli_out(cli, "%-4s" , "FPV");
    cli_out(cli, "%-4s" , "SQS");
    cli_out(cli, "%-4s" , "VPT");
    cli_out(cli, "%-5s" , "BDD");
    cli_out(cli, "%-4s" , "BMA");
    cli_out(cli, "%-4s" , "BD");
    cli_out(cli, " \n"); 
    return ;
}

CLI (show_usrid_tcam_entries,
     show_set_of_usrid_tcam_cmd,
     "show tcam usr-id ( vlan | mac | ipv4 | ipv6 ) CHIPID  entries",
     CLI_SHOW_STR,
     "TCAM information",
     "UserID information",
     "UserID VLAN key",
     "UserID MAC key",
     "UserID IPv4 key",
     "UserID IPv6 key",
     "ChipID",
     "All entries")
{ 
    diag_usrid_tcam_entry_req_t  req;
    diag_usrid_tcam_entries_resp_t resp;

    sal_memset( &req, 0, sizeof(diag_usrid_tcam_entry_req_t));  
    sal_memset( &resp, 0, sizeof(diag_usrid_tcam_entries_resp_t));

    if (0 == sal_strcmp(argv[0], "mac")) 
    {
        req.key_type= DIAG_USRID_KEY_TYPE_MAC;
    }
    else if (0 == sal_strcmp(argv[0], "ipv4")) 
    {
        req.key_type = DIAG_USRID_KEY_TYPE_IPV4;
    }
    else if (0 == sal_strcmp(argv[0], "ipv6"))
    {
        req.key_type = DIAG_USRID_KEY_TYPE_IPV6;
    }
    else 
    {
        req.key_type = DIAG_USRID_KEY_TYPE_VLAN;
    }

    CLI_GET_INTEGER_RANGE ("Chip id", req.chip_id, argv[1], 0, 0);

    /* -1 indicate to get all entries */
    req.index = DIAG_ALL_VLAN_CLASS_ENTRIES_REQ;
    resp.key_type = req.key_type;

    if (diag_show_lock_for_usrid_entries)
    {
        cli_out(cli," Others is showing the ipv6 tcam information\n ");
        return CLI_SUCCESS;
    }
    diag_show_lock_for_usrid_entries = 1;

    _diag_show_tcam_usrid_explain_head(&req);  
    if (_lcsh_lcm_show_tcam_usrid(&req, &resp) < 0)
    {
        diag_show_lock_for_usrid_entries = 0;
        return CLI_ERROR;
    }

    DIAG_SHOW_IF_ERROR_RETURN(_diag_show_tcam_read_file(cli,SHOW_TCAM_USRID_INFO_FILE)); 

    if ( resp.count)
    {
        cli_out(cli, "\n Total entry num is %d\n", ( resp.count));
    } 

    cli_out (cli, " \n"); 
    diag_show_lock_for_usrid_entries = 0;
        
    return CLI_SUCCESS;
}

int32
lcsh_tcam_cli_init(struct cli_tree *cli_tree)
{
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_acl_entries_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_acl_one_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_mac_entries_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_mac_one_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipv6uc_one_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipv6uc_entries_cmd);

    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipmc_one_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipmc_entries_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipv6mc_one_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipv6mc_entries_cmd);   
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_one_usrid_tcam_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_set_of_usrid_tcam_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipuc_one_entry_cmd);
    cli_install_gen(cli_tree, EXEC_MODE, PRIVILEGE_NORMAL, 0, &show_tcam_ipuc_entries_cmd);

    return CLI_SUCCESS;
}

