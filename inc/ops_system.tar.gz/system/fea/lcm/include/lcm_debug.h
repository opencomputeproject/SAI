/****************************************************************************
 * lcm_debug.h      lcm debug header file.
 *
 * Copyright     :(c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      :R0.01.
 * Author        :Xianting Huang
 * Date          :2010-08-16
 * Reason        :First Create.
 ****************************************************************************/
#ifndef __LCM_DEBUG_H__
#define __LCM_DEBUG_H__
/****************************************************************************
*
* Header Files 
*
****************************************************************************/
#include "lcm.h"
#include "lcm_client.h"
#include "genlog.h"
#include "ctclib_debug.h"
#include "lcm_client.h"
#include "LcmMsg.h"

/****************************************************************************
* Micros 
****************************************************************************/
/*encapsulation for log*/

/*encapsulation for debug*/
#define LCM_PRINT_CON(fmt, args...)                      \
{                                                            \
    FILE * fp_console = NULL;                                \
    fp_console = fopen("/dev/console", "w+");                \
    fprintf(fp_console, fmt"\n", ##args);                    \
    fclose(fp_console);                                      \
}
#if 0
#define LCM_LOG_DEBUG(mod, sub, typeenum, fmt, args...)\
    CTCLIB_PRINT (LCM, fmt, ##args); 
#define LCM_LOG_EMERG  LCM_PRINT_CON
#define LCM_LOG_ALERT   LCM_PRINT_CON
#define LCM_LOG_CRIT   LCM_PRINT_CON
#define LCM_LOG_ERR   LCM_PRINT_CON
#define LCM_LOG_WARN   LCM_PRINT_CON
#define LCM_LOG_NOTICE LCM_PRINT_CON
#define LCM_LOG_INFO   LCM_PRINT_CON
#else
#define LCM_LOG_DEBUG(mod, sub, typeenum, fmt, args...)\
    CTCLIB_DEBUG_OUT_INFO(LCM, mod, sub, typeenum, fmt, ##args);
#define LCM_LOG_EMERG(fmt, args...)   log_diag(M_MOD_LCM, E_EMERGENCY, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#define LCM_LOG_ALERT(fmt, args...)   log_diag(M_MOD_LCM, E_ALERT, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#define LCM_LOG_CRIT(fmt, args...)    log_diag(M_MOD_LCM, E_CRITICAL, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#define LCM_LOG_ERR(fmt, args...)     log_diag(M_MOD_LCM, E_ERROR, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#define LCM_LOG_WARN(fmt, args...)    log_diag(M_MOD_LCM, E_WARNING, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#define LCM_LOG_NOTICE(fmt, args...)  log_diag(M_MOD_LCM, E_NOTICE, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#define LCM_LOG_INFO(fmt, args...)    log_diag(M_MOD_LCM, E_INFORMATIONAL, "[%d][%s]"fmt, __LINE__, __FUNCTION__, ##args)
#endif
/*error return*/
#define LCM_IF_ERROR_RETURN(op) \
do { \
    int32 rv; \
    if ((rv = (op)) < 0) \
    {\
        LCM_LOG_ERR("LCM OP failed: rv = %d, %s:%d", rv, __FUNCTION__, __LINE__);\
        return(rv); \
    }\
}while(0)

#define LCM_IF_ERROR_CONTINUE(op) \
{ \
    int32 rv; \
    if ((rv = (op)) < 0) \
    {\
        LCM_LOG_ERR("LCM OP failed: rv = %d", rv);\
        continue; \
    }\
}

/****************************************************************************
* Enums 
****************************************************************************/
/*debug module enum*/
CTCLIB_DEBUG_ENUM(LCM, lcm, chsmtlk, LCM_CHSMTLK_EVENT, LCM_CHSMTLK_SOCK);
CTCLIB_DEBUG_ENUM(LCM, lcm, hagttlk, LCM_HAGTTLK_EVENT, LCM_HAGTTLK_MSG);
CTCLIB_DEBUG_ENUM(LCM, lcm, card, LCM_CARD_EVENT, LCM_CARD_NORMAL);
CTCLIB_DEBUG_ENUM(LCM, lcm, lcmgt, LCM_LCMGT_EVENT, LCM_LCMGT_NORMAL);
CTCLIB_DEBUG_ENUM(LCM, lcm, diag, LCM_DIAG_COLD, LCM_DIAG_BOOTUP, LCM_DIAG_NORMAL);
CTCLIB_DEBUG_ENUM(LCM, lcm, lcsh, LCM_LCSH_MSG);

CTCLIB_DEBUG_ENUM(DRV, drv, bus, DRV_BUS_SPI, DRV_BUS_I2C, DRV_BUS_MDIO);
CTCLIB_DEBUG_ENUM(DRV, drv, clkgen, DRV_CLK_GEN_READ, DRV_CLK_GEN_WRITE, DRV_CLK_GEN_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, phy, DRV_PHY_READ, DRV_PHY_WRITE, DRV_PHY_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, poe, DRV_POE_READ, DRV_POE_WRITE, DRV_POE_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, l2switch, DRV_L2SWITCH_READ, DRV_L2SWITCH_WRITE, DRV_L2SWITCH_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, epld, DRV_EPLD_READ, DRV_EPLD_WRITE, DRV_EPLD_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, fiber, DRV_FIBER_READ, DRV_FIBER_WRITE, DRV_FIBER_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, sensor, DRV_SENSOR_READ, DRV_SENSOR_WRITE, DRV_SENSOR_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, gpio, DRV_GPIO_READ, DRV_GPIO_WRITE, DRV_GPIO_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, mux, DRV_MUX_READ, DRV_MUX_WRITE, DRV_MUX_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, fan, DRV_FAN_READ, DRV_FAN_WRITE, DRV_FAN_NORMAL);
/* added by liuht for bug 24525,2013-10-24 */
CTCLIB_DEBUG_ENUM(DRV, drv, power, DRV_POWER_READ, DRV_POWER_WRITE, DRV_POWER_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, vsc3308, DRV_VSC3308_READ, DRV_VSC3308_WRITE, DRV_VSC3308_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, eeprom, DRV_EEPROM_READ, DRV_EEPROM_WRITE, DRV_EEPROM_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, ds21348, DRV_DS21348_READ, DRV_DS21348_WRITE, DRV_DS21348_NORMAL);
CTCLIB_DEBUG_ENUM(DRV, drv, ad9559, DRV_AD9559_READ, DRV_AD9559_WRITE, DRV_AD9559_NORMAL);


/****************************************************************************
* function declare 
****************************************************************************/
int32
lcm_msg_rx_debug_set (lcm_clnt_t* clnt, LcmMsg_t* msg);
int32
lcm_msg_rx_debugctrl_set (lcm_clnt_t* clnt, LcmMsg_t* msg);
int32 
lcm_debug_module_reg(void);
int32
lcm_debug_init(void);
#endif /*__LCM_DEBUG_H__*/
