/****************************************************************************
* 
*  Centec show forward related MACRO and ENUM, Structure defines file
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : liul
* Date          : 2010-11-19 16:00
* Reason        : First Create.
****************************************************************************/
#ifndef _LCM_SHOW_FORWARD_H_
#define _LCM_SHOW_FORWARD_H_

/******************************************************************
 * include header files
******************************************************************/

#include "ctcutil_pkt.h"

#include "humber_asic_dv.h"
#include "sim_show_forward_print.h"

/******************************************************************
 * defines constants
******************************************************************/

#define  DEBUG_LOGGING_FILE "/tmp/cmodel.log"

#define CPU_PHY_PORT             31
#define LCM_SHOW_FORWARD_MTU                                ( 1500 +64 ) /* 64 bytes for forwarding headers */
#define HELLO_MSG_LEN                                                100    /* used for output packet hello message */

extern uint8 show_forward_debug_cmodel[ MAX_NUM_SHOW_FORWARD_DEBUG_CMODEL ];

#define DEBUG_INFO_SHOW(fp, fmt...) \
do{\
    char buffer[200];\
    sal_snprintf(buffer, sizeof(buffer), fmt);\
    sal_fputs(buffer, fp);\
}while(0)
    
#define DEBUG_WRITE(sptr, cptr, fmt, args...)\
do{\
    sal_sprintf(cptr, fmt, ##args);\
    cptr = sptr + strlen(sptr);\
}while(0)

enum lcm_show_forward_debug_switch_e
{
    LCM_SHOW_FORWARD_MODULE,
    LCM_SHOW_FORWARD_PKT,
    LCM_SHOW_FORWARD_DEBUG
};
typedef enum lcm_show_forward_debug_switch_e lcm_show_forward_debug_switch_t;

 enum lcm_show_forward_debug_out_pkt_e
{
    LCM_SHOW_FORWARD_IPE_PKT,
    LCM_SHOW_FORWARD_FWD_PKT,
    LCM_SHOW_FORWARD_EPE_PKT,
    LCM_SHOW_FORWARD_OAM_PKT,
    LCM_SHOW_FORWARD_MAX_PKT
};
typedef enum lcm_show_forward_debug_out_pkt_e lcm_show_forward_debug_out_pkt_t;

/******************************************************************
     * functions
 ******************************************************************/

extern int32
lcm_msg_tx_chsmshowfowardack(void *arg, ctc_pkt_t *outpkt);
extern int32 
lcm_msg_tx_chsmforwardinfo(void *arg,uint8 *buffer, int length);
extern int32 
lcm_show_forward_set_flags(uint32 type, uint64 flags);
extern int32
lcm_show_forward_process(ctc_pkt_t *input_pkt, void *arg);
extern int32
lcm_show_forward_chsm_epe_process(void* arg,ctc_pkt_t *input_pkt);

#endif /*_LCM_SHOW_FORWARD_H_*/

