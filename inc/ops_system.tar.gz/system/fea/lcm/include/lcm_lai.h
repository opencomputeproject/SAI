
#ifndef __LCM_LAI_H__
#define __LCM_LAI_H__

#include <sys/types.h>
#include <netinet/in.h>
#include "glb_hw_define.h"
#include "glb_const.h"
#include "laiinc.h"

int32 
lcm_lai_rx_laiTmprThreshold(uint32 low, uint32 high, uint32 crit);
int32 
lcm_lai_rx_laiLedSet(int32 led, int32 status);

int32 
lcm_lai_rx_laiOemInfoGet(char* buf);
int32 
lcm_lai_rx_laiOemInfoSet(char* buf);

int32 
lcm_lai_get_FiberInfo(lai_fiber_info_t** fiber, glb_port_t *p_port);

int32
lcm_lai_set_Configbootcmd(char* cmd);

int32  
lcm_lai_Updatebootrom(char* path);

int32  
lcm_lai_UpdateEpld(char* path);
int32 
lcm_lai_set_PortInfoSet(char* info);

int32
lcm_lai_SetStmMode(uint32 mode);

int32
lcm_lai_get_lcRebootInfo(lai_reboot_info_t** reboot_info);

int32 
lcm_lai_ResetRebootInfo();

#endif

