#ifndef __LCM_CARD_H__
#define __LCM_CARD_H__

#include "glb_hw_define.h"
#include "fiber_drv.h"

struct lcm_card_port_s
{
    uint8 chip_idx;
    uint8 mac_idx;
    uint16 logic_port_idx;
    uint16 phy_addr;
};
typedef struct lcm_card_port_s lcm_card_port_t;

struct lcm_card_port_panel_mapping_s
{
    uint8 panel_slot_no;   //panel slot id for this port
    uint8 panel_port_no;   //panel port id for this port
    int8 panel_subport_no;//pannel sub port id for this port
};
typedef struct lcm_card_port_panel_mapping_s lcm_card_port_panel_mapping_t;

struct lcm_card_serdes_info_s
{
    int8 serdes_id;    //serdes id
    uint8 serdes_mode; //serdes mode, example xfi,sgmii,qsgmii,xaui,xlg,
};
typedef struct lcm_card_serdes_info_s lcm_card_serdes_info_t;

struct lcm_card_serdes_ffe_s
{
    int8 serdes_id;
    uint8 trace_len;   /* default trace_len */
    /* 
     * Added by qicx, 2015-05-13
     * If one board's material is fixed, then trace_len2 will not be used, e.g. E580-20Q4Z/48X2Q4Z
     * If one board owns two materials, such as E580-48X6Q, then 'trace_len' for M4, 'trace_len2'
     *   for FR4.
     */
    uint8 trace_len2;
};
typedef struct lcm_card_serdes_ffe_s lcm_card_serdes_ffe_t;

struct lcm_chip_serdes_ffe_s
{
    uint8  serdes_id;                                       /**<[GB.GG] serdes id */
    uint8  mode;                                            /**<[GB.GG] relate to ctc_chip_serdes_ffe_mode_t */
    uint8  board_material;                                  /**<[GB.GG] motherboard material: 0--FR4, 1--M4, 2--M6 */
    uint8  trace_len;                                       /**<[GB.GG] trace length: 0-- (0~4)inch, 1--(4~7)inch, 2--(7~10)inch */
    uint8  c0;                                              /**<[GB.GG] coefficient value */
    uint8  c1;
    uint8  c2;
    uint8  c3;
};
typedef struct lcm_chip_serdes_ffe_s lcm_chip_serdes_ffe_t;

typedef int32 (*card_init_callback_t)(void);
typedef int32 (*lcm_port_get_sum_ffe_cfg_callback_t)(lcm_chip_serdes_ffe_t*);
int32 lcm_init_sw_emu(glb_card_t* p_card);
int32 lcm_init_greatbelt_demo(glb_card_t* p_card);
int32 lcm_init_goldengate_demo(glb_card_t* p_card);
int32 lcm_init_e580_48x2q4z(glb_card_t* p_card);
int32 lcm_init_e580_48x6q(glb_card_t* p_card);
int32 lcm_init_e350_48t4x2q(glb_card_t* p_card);
int32 lcm_init_e580_32x2q(glb_card_t* p_card);
/* added by liuht for e350 48+4, 2013-11-05 */
int32 lcm_init_e350_48t4xg(glb_card_t* p_card);
int32 lcm_init_e350_8t12x(glb_card_t* p_card);
int32 lcm_init_e350_8t4s12x(glb_card_t* p_card);
int32 lcm_init_e350_24t4xg(glb_card_t* p_card);
int32 lcm_init_e350_8ts12x(glb_card_t* p_card);
int32 lcm_init_nid(glb_card_t* p_card);
int32 lcm_init_e350_24x(glb_card_t* p_card);
int32 lcm_init_ptn722(glb_card_t* p_card);
int32 lcm_init_e350_mt_8t12x(glb_card_t* p_card);
int32
lcm_common_save_port_info_file(glb_card_t* p_card);
int32
lcm_common_parse_port_numchg_info(glb_card_t* p_card);
int32
lcm_common_ppt_map_port(glb_card_t* p_card, lcm_card_port_panel_mapping_t* port_panel_mapping);
int32
lcm_parse_switch_cli(glb_card_t* p_card, char *cli_str, uint32 *panel_slot, uint32 *panel_port, char type[32]);
#ifdef BOOTUP_DIAG
int32 lcm_common_parse_bootup_diag(glb_card_t* p_card);
#endif
#endif


