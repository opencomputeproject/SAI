#ifndef __LCM_MGT_H__
#define __LCM_MGT_H__

#include "glb_hw_define.h"

typedef enum
{
    LCM_FIBER_INSERT,
    LCM_FIBER_REMOVE,
}lcm_fiber_notify_event_e;

#ifdef HAVE_STACK
struct lcm_mgt_stack_config
{
    int master;
};
#endif

#define DATAPATH_PROFILE_PATH    "/etc/spec/"
#define GREATBELT_DEMO_MB_DATAPATH_NAME "GreatBelt_Demo_MB.txt"
#define GREATBELT_DEMO_48T8XG_DATAPATH_NAME "GreatBelt_Demo_48T8XG.txt"
#define GREATBELT_DEMO_24SFP8XG_DATAPATH_NAME "GreatBelt_Demo_24SFP8XG.txt"
#define GREATBELT_DEMO_4XG8XG_DATAPATH_NAME "GreatBelt_Demo_4XG8XG.txt"
/*modify by weij, tmp for 48+4, review by qicx*/
#define E350_48T4XG_DATAPATH_NAME  "E350_48T4XG.txt"
/* added by liuht for e350 48+12, 2013-11-05 */
#define E350_48T4X2Q_DATAPATH_NAME  "E350_48T4X2Q.txt"
/* added by liuht for e350-8t12xg, 2013-10-11 */
#define E350_8T12X_DATAPATH_NAME  "E350_8T12XG.txt"
#define E350_8TS12X_DATAPATH_NAME  "E350_8TS12XG.txt"
#define E350_24X_DATAPATH_NAME  "E350_24XG.txt"
#define E350_24X_DATAPATH_NAME2  "E350_24XG2.txt"
#define PTN722_DATAPATH_NAME  "Ptn722.txt"
#define PTN722_1G_DATAPATH_NAME  "Ptn722_1G.txt"
#define NID_DATAPATH_NAME  "ACT_NID.txt"

#define GOLDENDATE_24Q_SFP_DATAPATH_NAME "GoldGate_24q_sfp.txt"
#define GOLDENDATE_24Q_DATAPATH_NAME "GoldGate_24q.txt"
#define E580_48X2Q4Z_DATAPATH_NAME    "E580_48X2Q4Z.txt"
#define E580_48X6Q_DATAPATH_NAME    "E580_48X6Q.txt"
#define E580_32X2Q_DATAPATH_NAME    "E580_32X2Q.txt"

#define E580_48X2Q4Z_100G_DATAPATH_NAME    "E580_48X2Q4Z_100G.txt"
/* Added by liuht for bug27036, 2014-02-27 */
#define REBOOT_INFO_SAVE_PATH  "/mnt/flash/reboot-info/reboot_info.log"
#define REBOOT_INFO_SAVE_PATH_TMP  "/mnt/flash/reboot-info/reboot_info_tmp.log"

#define LCM_POLLING_ENVIRONMENT_TIMER 3000  //scan environment every 3 seconds

#define LCM_MGT_CHK_SLOT(_SLOT)                                                     \
do {                                                                            \
    if (((_SLOT) = lcm_mgt_get_logic_slot()) == GLB_INVALID_SLOT_NO)                    \
    {                                                                           \
        return LCM_E_INVALID_SLOT;                                                              \
    }                                                                           \
}while(0)

typedef int32 (*lcm_mgt_callback_t)(void);

glb_card_t* lcm_mgt_get_card();
int16 lcm_mgt_get_logic_slot();
void lcm_mgt_set_priority_flag(int32 flag);
void lcm_mgt_set_err_reboot_flag(int32 flag);
int32 lcm_mgt_monitor_lc(void);
int32 lcm_mgt_init(void);
int32 lcm_mgt_reset_chipset(void* pv_arg);
int32 lcm_mgt_enable_asic_normal_intr(void* pv_arg);
int32 lcm_mgt_enable_asic_fatal_intr(void* pv_arg);
int32 lcm_mgt_bypass_timers(void* pv_arg);
int32 lcm_mgt_get_bypass_timers();
#ifdef FOAM_SUPPORT /* for bug14682, foam 1588 syncif development, 2011-04-25 */
int32 lcm_mgt_enable_foam_normal_intr(void* pv_arg);
#endif /*FOAM_SUPPORT*/
int32 lcm_mgt_asic_fatal(void* pv_arg);
int32 lcm_reload(void);
int32 lcm_mgt_get_active_sup_slot(void* pv_arg);
int32 lcm_mgt_get_sysmac(void* pv_arg);
int32 lcm_mgt_is_enable_stack();
int32 lcm_mgt_get_stack_member();
int32 lcm_mgt_get_stack_master();
int32 lcm_mgt_get_sup_slot();
int lcm_mgt_get_if_hwaddr (char *ifname, unsigned char *hwaddr,
               int *hwaddr_len);
int32 lcm_mgt_reload(void* pv_arg);
int32 lcm_mgt_get_sw_info(glb_card_t* p_card);
/* Added by liuht for bug27036, 2014-02-27 */
int32 lcm_mgt_mount_reboot_info(glb_card_t* p_card);
int32 lcm_mgt_unmount_reboot_info(glb_card_t* p_card);
/* Added by liuht for bug 27788, 2014-03-24 */
void lcm_mgt_get_current_bootromver(char *bootrom_ver);
int32 lcm_mgt_set_led_flag_to_kernal(int* alarm);
#endif
