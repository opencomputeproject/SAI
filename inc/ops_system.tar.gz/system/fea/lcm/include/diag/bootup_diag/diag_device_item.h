#ifndef __DIAG_BAY_ITEM_H__
#define __DIAG_BAY_ITEM_H__
#ifdef BOOTUP_DIAG
#define DIAG_MAX_FAN_NUM    4
#define DIAG_MAX_SENSOR_NUM 5
#define DIAG_MAX_PSU_NUM    2
#define DIAG_MAX_GPIO_NUM   5
#define DIAG_MAX_MUX_NUM    2

diag_item_ops_t diag_ops_access_phy;
diag_item_ops_t diag_ops_access_l2switch;
diag_item_ops_t diag_ops_access_eeprom0;
diag_item_ops_t diag_ops_access_eeprom1;
diag_item_ops_t diag_ops_access_epld;
/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
#define LCM_DIAG_CONSOLE_PRINT(fmt, args...)                      \
{                                                              \
    FILE * fp_console = NULL;                                  \
    fp_console = fopen("/dev/console", "w+");                  \
    fprintf(fp_console, fmt, ##args);   \
    fclose(fp_console);                                        \
}
#endif
#endif

