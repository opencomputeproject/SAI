#ifndef __DIAG_BAY_ITEM_H__
#define __DIAG_BAY_ITEM_H__
#ifdef BOOTUP_DIAG
void 
diag_bist_run_ddr_sram(uint8 chip_id);

void 
diag_bist_run_qdr_sram(uint8 chip_id);

int32
diag_check_ddr_sram_bist_rlt(uint8 chip_id);

int32
diag_check_qdr_sram_bist_rlt(uint8 chip_id);

void 
diag_bist_run_int_tcam(uint8 chip_id);

void 
diag_bist_run_ext_tcam(uint8 chip_id);

int32 
diag_check_int_tcam_bist_rlt(uint8 chip_id);

int32 
diag_check_ext_tcam_bist_rlt(uint8 chip_id);
#endif
#endif

