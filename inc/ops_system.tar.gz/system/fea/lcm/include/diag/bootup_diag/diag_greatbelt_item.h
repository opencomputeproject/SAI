#ifndef __DIAG_BAY_ITEM_H__
#define __DIAG_BAY_ITEM_H__
#ifdef BOOTUP_DIAG
typedef struct 
{
    uint32 loopmode;
    uint32 type;
}diag_clear_cfg_t;

 diag_item_ops_t diag_ops_ddr_sram_bist;
 diag_item_ops_t diag_ops_qdr_sram_bist;
 diag_item_ops_t diag_ops_int_tcam_bist;
 diag_item_ops_t diag_ops_ext_tcam_bist;
 diag_item_ops_t diag_ops_cpu_to_port;

int32 diag_ucast_cfg(diag_cfg_req_t * req);
int32 diag_del_l2ucast_to_cpu();
int32 diag_del_l2ucast();
#endif
#endif

