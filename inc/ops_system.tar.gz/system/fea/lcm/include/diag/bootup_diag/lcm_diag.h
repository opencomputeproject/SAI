#ifndef __LCM_DIAG_H_
#define __LCM_DIAG_H_
#ifdef BOOTUP_DIAG
#include "ctclib_thread.h"
#include "diag_types.h"

int32 lcm_diag_start_stage1 (glb_card_t* p_card);
int32 lcm_diag_start_stage2 (void);

int32 lcm_diag_start_timer(void* arg);
/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
int32 lcm_diag_rx_packet_polling(diag_operator_t *p_oper);
int32 lcm_diag_stop_timer(void* arg);
int32 diag_send_l2ucast_pkt_bydma(diag_operator_t *p_oper);
int32 lcm_diag_device_cfg(diag_operator_t *p_oper);
int32 lcm_diag_device_decfg(diag_operator_t *p_oper);
int32 lcm_diag_l2ucast_func_chip_cfg(diag_operator_t *p_oper);
int32 lcm_diag_l2ucast_func_chip_decfg(diag_operator_t *p_oper);
int32 _hagt_packet_rx_transmit_to_diag(void* p_skb);
int32 _hagt_check_diag_flag();
/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
int32 lcm_diag_l2ucast_pkt_read(ctclib_thread_t* p_thread);
int32 lcm_diag_l2ucast_func_flag_set(diag_operator_t *p_oper);
int32 lcm_diag_l2ucast_func_flag_unset(diag_operator_t *p_oper);
int32 lcm_diag_start_sdk_init();
int32 lcm_diag_finish_sdk_init(int32 result);
#define LCM_DIAG_CONSOLE_PRINT(fmt, args...)                      \
{                                                              \
    FILE * fp_console = NULL;                                  \
    fp_console = fopen("/dev/console", "w+");                  \
    fprintf(fp_console, fmt, ##args);   \
    fclose(fp_console);                                        \
}
#endif
#endif

