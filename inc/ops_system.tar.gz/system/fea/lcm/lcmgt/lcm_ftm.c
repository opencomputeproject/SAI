/****************************************************************************
 * lcm_ftm.c  :   calculate the key and nexthop information for sdk init
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     :       R0.01
 * Author       :       ychen
 * Date         :       2013-07-22
 * Reason       :       First Create.
 ****************************************************************************/
#ifdef GOLDENGATE

/****************************************************************************
* Header Files
****************************************************************************/
#include "sal_common.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "glb_stm_define.h"
#include "glb_hw_define.h"
#include "glb_macro.h"
#include "glb_eeprom_define.h"
#include "eeprom_api.h"
#include "lcm_mgt.h"
/******************************************************************************
*Defines and Macros
********************************************************************************/
#define LCM_FTM_EMPTY_LINE(C)     ((C) == '\0' ||(C) == '\r' || (C) == '\n' )
#define LCM_FTM_WHITE_SPACE(C)    ((C) == '\t' || (C) == ' ')

#define LCM_FTM_LINE_LEN_MAX                128
#define LCM_FTM_MAX_KEY_LEN                  64
/**************************************************************************
*Globals
****************************************************************************/
uint32 g_stm_mode = GLB_STM_MODE_DEFAULT;

/*========================================================================================
*FUNCTIONS 
==========================================================================================*/
#ifdef _GLB_UML_SYSTEM_
/*******************************************************************************************
 * name            :_lcm_ftm_string_atrim
 * pupose          :trim left and right space
 * input           :p_input---input string
 *                 :
 * output          :p_output--output string
 * return          :N/A
 * note:
*******************************************************************************************/
static int32
_lcm_ftm_string_atrim(char* p_output, const char* p_input)
{
    char* p = NULL;  
  
    GLB_PTR_VALID_CHECK(p_output, LCM_E_INVALID_PTR);
    GLB_PTR_VALID_CHECK(p_input, LCM_E_INVALID_PTR);
  
    /*trim left space*/
    while(*p_input != '\0')
    {
        if(LCM_FTM_WHITE_SPACE(*p_input))
        {
            ++p_input;
        }
        else
        {
            break;
        }
    }  
    sal_strcpy(p_output, p_input);  
    /*trim right space*/
    p = p_output + sal_strlen(p_output) - 1;
  
    while(p >= p_output)
    {
      /*skip empty line*/
        if(LCM_FTM_WHITE_SPACE(*p) || ('\r' == (*p)) || ('\n' == (*p)))
        {
            --p;
        }
        else
        {
            break;
        }
    }
  
    *(++p) = '\0';
  
    return LCM_E_SUCCESS;
}

/*******************************************************************************************
 * name            :_lcm_ftm_read_size_info
 * pupose          : read key size
 * input           :p_line---input string
 *                 :
 * output          :p_para--tcam key size defined in glb_stm_key_size_t or just entry number
 * return          :N/A
 * note:           :
******************************************************************************************/
static int32
_lcm_ftm_read_size_info(const char* p_line, void* p_para)
{
    char*   ch = NULL;
    uint32* p_size = (uint32*)p_para;
    
    GLB_PTR_VALID_CHECK(p_line, LCM_E_INVALID_PTR);
    GLB_PTR_VALID_CHECK(p_para, LCM_E_INVALID_PTR); 
    
    ch = sal_strstr(p_line, "=");
    if(NULL == ch)
    {
        return LCM_E_INVALID_PARAM;
    }
    else
    {
        ch++;
    }
    
    while(sal_isspace(*ch))
    {
      ch++;
    }
  
    sal_sscanf(ch, "%u", p_size);
  
    return LCM_E_SUCCESS;
}
#endif /*_GLB_UML_SYSTEM_*/



/********************************************************************************************
* name            :_stm_alloc_read_profile_mode
* pupose          :get profile mode
* input           :N/A
* output          :p_mode----profile mode defined in stm_profile_mode_t
* return          :NONE
* note:
*******************************************************************************************/
int32 
lcm_ftm_read_profile_mode(uint32* p_mode)
{
    int32 ret = LCM_E_SUCCESS;
#ifndef _GLB_UML_SYSTEM_
    glb_card_t* p_card = NULL;
    eeprom_info_t* p_eeprom_info = NULL;
    uint32 stm_mode = 0;
#endif /*_GLB_UML_SYSTEM_*/
    
    GLB_PTR_VALID_CHECK(p_mode, LCM_E_INVALID_PTR);
    
#ifndef _GLB_UML_SYSTEM_
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("LCM read stm mode: card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("LCM read stm mode: eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    ret = eeprom_get_tcam_profile(&stm_mode, p_eeprom_info);
    if (ret < 0)
    {
        LCM_LOG_ERR("LCM read stm mode: failed to get stm mode, use default mode.");
        stm_mode = 0;
    }

#if 0
    /* modified by liwh for bug 27446, 2014-05-26 
      only default stm mode and l2vpn stm mode is supported */
    if ((GLB_STM_MODE_DEFAULT != stm_mode) && (GLB_STM_MODE_L2VPN != stm_mode))
#else
    /*huangxt for bug 32166*/
    /* Modified by Yan Xing'an, for openflow */
    if ((GLB_STM_MODE_DEFAULT != stm_mode) 
        && (GLB_STM_MODE_ACCESS != stm_mode)
        && (GLB_STM_MODE_IPUCV4 != stm_mode)
        && (GLB_STM_MODE_OF_DEFAULT != stm_mode)
        && (GLB_STM_MODE_OF_HYBRID != stm_mode))
#endif
    {
        stm_mode = GLB_STM_MODE_DEFAULT;
    }

    *p_mode = stm_mode;
#else
    char file_name[LCM_FTM_LINE_LEN_MAX];
    char string[LCM_FTM_LINE_LEN_MAX];
    char line[LCM_FTM_LINE_LEN_MAX];
    FILE* fp = NULL;    

    /*get file path*/
    sal_snprintf(file_name, sizeof(file_name), "%s%s", GLB_STM_PROFILE_PATH, GLB_STM_PROFILE_MODE);

    /*OPEN FILE*/
    fp = sal_fopen(file_name, "r");
    
    if((NULL == fp) || sal_feof(fp))
    {
        return LCM_E_FILE_OPEN;
    }

    /*get profile mode*/
    while(!sal_feof(fp))
    {
        sal_memset(string, 0, sizeof(string));
        sal_fgets(string, LCM_FTM_LINE_LEN_MAX, fp);

        /*comment line*/
        if('#' == string[0])
        {
          continue;
        }
        
        /*trim left and right space*/
        sal_memset(line, 0, sizeof(line));        
        ret = _lcm_ftm_string_atrim(line, string);

        if(LCM_FTM_EMPTY_LINE(line[0]))
        {
          continue;
        }    

        if (!sal_strncmp("[PROFILE_MODE]", line, sal_strlen("[PROFILE_MODE]")))
        {
            ret = _lcm_ftm_read_size_info(line, (void*)p_mode);
            break;
        }
    }

    /*close file*/
    sal_fclose(fp);
    fp = NULL;
#endif /*_GLB_UML_SYSTEM_*/

#ifdef OFPRODUCT
    /* On OSP-OF product phase 1, only OF default mode is supported. */
    *p_mode = GLB_STM_MODE_OF_DEFAULT;
#endif

    g_stm_mode = *p_mode;
    return ret;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_default_profile_info
* pupose          :get default asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:
*******************************************************************************************/
static int32
_lcm_ftm_get_default_profile_info(glb_stm_profile_info_t* p_asic_info)
{    
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);

    /*
    #----------------------global-----------------------
    [GLB_MULT_GRP_NUM] = 12348
    [GLB_NH_TBL_SIZE] = 42048
    [VSI_NUM] = 0
    [ECMP_NUM] = 64
    */   
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 42048;
    p_asic_info->mcast_group_number = 12348;
    p_asic_info->vsi_number = 0;
    p_asic_info->ecmp_number = 64;

    /*#----------------------SPEC-----------------------
    [MAC] = 65536
    [IP_HOST] = 4096
    [IP_LPM] = 8192
    [IPMC] = 8192
    [ACL] = 2048
    [Scl_Flow] = 0
    [Acl_Flow] = 0
    [Oam] = 0
    [Scl] = 5120
    [Tunnel_Decp] = 8200
    [Mpls] = 0
    [Ipfix] = 16384*/
    p_asic_info->profile_specs[GLB_FTM_SPEC_MAC] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_HOST] = 4096;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_LPM] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPMC] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL] = 2048;
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL] = 5120;
    p_asic_info->profile_specs[GLB_FTM_SPEC_TUNNEL] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPFIX] = 16384;
    /*modified by xgu for bug 32033, 2015-3-3*/
    p_asic_info->profile_specs[GLB_FTM_SPEC_L2MC] = 2048;

    /*#------------------ TCAM allocation----------------------
    #{
    [SCL0_160]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL0_320]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL0_640]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 512;
    key_index++;

    /*
    #{
    [SCL1_160]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL1_320]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL1_640]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 512;
    key_index++;

    /*
    #{
    [ACL0_IPE_160]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL0_IPE_320]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 2048
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL0_IPE_640]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 4096
    [ENTRY_SIZE] = 4096
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 2048;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 2048;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 2048;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 4096;
    key_index++;

    
    /*
    #{
    [ACL1_IPE_160]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL1_IPE_320]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 2048
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL1_IPE_640]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 4096
    [ENTRY_SIZE] = 4096
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 2048;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 2048;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 2048;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 4096;
    key_index++;
    
    /*
    #{
    [ACL2_IPE_160]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL2_IPE_320]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL2_IPE_640]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 512;
    key_index++;

    /*
    #{
    [ACL3_IPE_160]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL3_IPE_320]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL3_IPE_640]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 512;
    key_index++;

    /*
    #{
    [ACL0_EPE_160]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL0_EPE_320]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL0_EPE_640]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 512;
    key_index++;

    /*
    #{
    [LPM0_40]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 4096
    #}
    #{
    [LPM0_160]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 8192
    [ENTRY_SIZE] = 4096
    #}*/
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    /*for bug 32063 modified by liuyang 2015-3-13*/
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    /*
    #{
    [LPM1_1]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_2]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 128
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_3]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_4]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 768
    [ENTRY_SIZE] = 128
    #}*/
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 128;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 768;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info_size = key_index;

    /*#-----------------Dynamic TABLE SRAM allocation-----------
    #{
    [LPM_PIPE0]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}*/
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 16384; 
    tbl_index++;

    /*
    #{
    [NEXTHOP]
    [TBL_MEM_ID] = 16
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 49152
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 24576; // TODO: by weij for add profile for epe scl 
    tbl_index++;

    /*#{
    [MET]
    [TBL_MEM_ID] = 17
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}*/
    // TODO: by weij for add profile for epe scl 
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  24576;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 24576; 
    tbl_index++;

    /*#{
    [EDIT]
    [TBL_MEM_ID] = 15
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 15);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[15] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[15] = 16384; 
    tbl_index++;

    /*#{
    [SCL_HASH_KEY]
    [TBL_MEM_ID] = 11
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    [TBL_MEM_ID] = 12
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 11);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 12);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[11] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[12] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[11] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[12] = 8192; 
    tbl_index++;

    /*#{
    [SCL_HASH_AD]
    [TBL_MEM_ID] = 13
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 13);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[13] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[13] = 32768; 
    tbl_index++;

    /*#{
    [FIB0_HASH_KEY]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB0_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8192; 
    tbl_index++;

    /*
    #{
    [DSMAC_AD]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    [TBL_MEM_ID] = 9
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSMAC_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 9);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[9] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16384;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[9] = 16384;
    tbl_index++;

    // TODO: by weij for add profile for epe scl 
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_XCOAM_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 17);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[17] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[17] = 32768;  // TODO: for egress scl. temp code
    tbl_index++;
    
    /*
    #{
    [FIB1_HASH_KEY]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB1_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16384; 
    tbl_index++;

    /*#{
    [DSIP_AD]
    [TBL_MEM_ID] = 10
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSIP_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 10);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[10] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[10] = 16384; 
    tbl_index++;

    /*#{
    [IPFIX_HASH_KEY]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_IPFIX_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 32768; 
    tbl_index++;
    
    /*#{
    [IPFIX_AD]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_IPFIX_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 32768; 
    tbl_index++;
    
    /*#{
    [OAM_APS]
    [TBL_MEM_ID] = 14
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 20480
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_OAM_APS; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 14);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[14] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[14] = 20480; 
    tbl_index++;
    
    p_asic_info->tbl_info_size = tbl_index;      

    return LCM_E_SUCCESS;
}


/*******************************************************************************************
* name            :_lcm_ftm_get_access_profile_info
* pupose          :get ipv4 asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:            enterprise profile
*******************************************************************************************/
static int32
_lcm_ftm_get_access_profile_info(glb_stm_profile_info_t* p_asic_info)
{    
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);

    /*
    #----------------------global-----------------------
    [GLB_MULT_GRP_NUM] = 10236
    [GLB_NH_TBL_SIZE] = 25664
    [VSI_NUM] = 0
    [ECMP_NUM] = 64

    */   
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 25664;
    p_asic_info->mcast_group_number = 10236;
    p_asic_info->vsi_number = 0;
    p_asic_info->ecmp_number = 64;

    /*#----------------------SPEC-----------------------
    [MAC] = 131072
    [IP_HOST] = 1024
    [IP_LPM] = 8192
    [IPMC] = 1024
    [ACL] = 2048
    [Scl_Flow] = 0
    [Acl_Flow] = 0
    [Oam] = 0
    [Scl] = 6144
    [Tunnel_Decp] = 8192
    [Mpls] = 0
    [Ipfix] = 0*/
    p_asic_info->profile_specs[GLB_FTM_SPEC_MAC] = 131072;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_HOST] = 1024;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_LPM] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPMC] = 1024;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL] = 2048;
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL] = 6144;
    p_asic_info->profile_specs[GLB_FTM_SPEC_TUNNEL] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPFIX] = 0;
    /*modified by xgu for bug 32033, 2015-3-3*/
    p_asic_info->profile_specs[GLB_FTM_SPEC_L2MC] = 2048;

    /*#------------------ TCAM allocation----------------------
    #{
    [SCL0_160]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL0_320]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL0_640]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 512;
    key_index++;

    /*
    #{
    [SCL1_160]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL1_320]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL1_640]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 512;
    key_index++;

    /*
    #{
    [ACL0_IPE_160]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL0_IPE_320]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 2048
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL0_IPE_640]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 4096
    [ENTRY_SIZE] = 4096
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 2048;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 2048;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 2048;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 4096;
    key_index++;

    /*
    #{
    [ACL1_IPE_160]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL1_IPE_320]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 2048
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL1_IPE_640]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 4096
    [ENTRY_SIZE] = 4096
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 2048;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 2048;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 2048;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 4096;
    key_index++;
    
    /*
    #{
    [ACL2_IPE_160]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL2_IPE_320]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL2_IPE_640]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 512;
    key_index++;

    /*
    #{
    [ACL3_IPE_160]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL3_IPE_320]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL3_IPE_640]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 512;
    key_index++;

    /*
    #{
    [ACL0_EPE_160]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL0_EPE_320]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL0_EPE_640]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 512;
    key_index++;

    /*
    #{
    [LPM0_40]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 4096
    #}
    #{
    [LPM0_160]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 8192
    [ENTRY_SIZE] = 4096
    #}*/
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 8192;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    /*
    #{
    [LPM1_1]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_2]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 128
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_3]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_4]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 768
    [ENTRY_SIZE] = 128
    #}*/
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 128;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 768;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info_size = key_index;

    /*#-----------------Dynamic TABLE SRAM allocation-----------
    #{
    [LPM_PIPE0]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 16384; 
    tbl_index++;

    /*
    #{
    [NEXTHOP]
    [TBL_MEM_ID] = 16
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 49152
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 49152; 
    tbl_index++;

    /*#{
    [MET]
    [TBL_MEM_ID] = 17
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 17);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[17] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[17] = 32768; 
    tbl_index++;

    /*#{
    [EDIT]
    [TBL_MEM_ID] = 15
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 15);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[15] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[15] = 16384; 
    tbl_index++;

    /*#{
    [SCL_HASH_KEY]
    [TBL_MEM_ID] = 11
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    [TBL_MEM_ID] = 12
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 11);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 12);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[11] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[12] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[11] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[12] = 8192; 
    tbl_index++;

    /*#{
    [SCL_HASH_AD]
    [TBL_MEM_ID] = 13
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 13);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[13] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[13] = 32768; 
    tbl_index++;

    /*#{
    [FIB0_HASH_KEY]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
#}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB0_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8192; 
    tbl_index++;

    /*
    #{
    [DSMAC_AD]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    [TBL_MEM_ID] = 9
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    [TBL_MEM_ID] = 10
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSMAC_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 9);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 10);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[9] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[10] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16384; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[9] = 16384; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[10] = 16384; 
    tbl_index++;
    
    /*
    #{
    [FIB1_HASH_KEY]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB1_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16384; 
    tbl_index++;

    /*#{
    [DSIP_AD]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSIP_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 32768; 
    tbl_index++;

    /*#{
    [OAM_APS]
    [TBL_MEM_ID] = 14
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 20480
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_OAM_APS; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 14);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[14] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[14] = 20480; 
    tbl_index++;
    
    p_asic_info->tbl_info_size = tbl_index;      

    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_ipv4_profile_info
* pupose          :get ipv4 asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:            enterprise profile
*******************************************************************************************/
static int32
_lcm_ftm_get_ipv4_profile_info(glb_stm_profile_info_t* p_asic_info)

{    
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);

    /*
    #----------------------global-----------------------
    [GLB_MULT_GRP_NUM] = 10236
    [GLB_NH_TBL_SIZE] = 42048
    [VSI_NUM] = 0
    [ECMP_NUM] = 64

    */   
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 42048;
    p_asic_info->mcast_group_number = 10236;
    p_asic_info->vsi_number = 0;
    p_asic_info->ecmp_number = 64;

    /*#----------------------SPEC-----------------------
    [MAC] = 32768
    [IP_HOST] = 20480
    [IP_LPM] = 8192
    [IPMC] = 8196
    [ACL] = 2048
    [Scl_Flow] = 0
    [Acl_Flow] = 0
    [Oam] = 0
    [Scl] = 4096
    [Tunnel_Decp] = 8200
    [Mpls] = 0
    [Ipfix] = 16384*/

    p_asic_info->profile_specs[GLB_FTM_SPEC_MAC] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_HOST] = 20480;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_LPM] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPMC] = 8196;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL] = 2048;
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL] = 4096;
    p_asic_info->profile_specs[GLB_FTM_SPEC_TUNNEL] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPFIX] = 16384;
    /*modified by xgu for bug 32033, 2015-3-3*/
    p_asic_info->profile_specs[GLB_FTM_SPEC_L2MC] = 1024;

    /*#------------------ TCAM allocation----------------------
    #{
    [SCL0_160]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL0_320]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL0_640]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 512;
    key_index++;

    /*
    #{
    [SCL1_160]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL1_320]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [SCL1_640]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 512;
    key_index++;

    /*
    #{
    [ACL0_IPE_160]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL0_IPE_320]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 2048
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL0_IPE_640]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 4096
    [ENTRY_SIZE] = 4096
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 2048;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 2048;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 2048;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 4096;
    key_index++;

    
    /*
    #{
    [ACL1_IPE_160]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL1_IPE_320]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 2048
    [ENTRY_SIZE] = 2048
    #}
    #{
    [ACL1_IPE_640]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 4096
    [ENTRY_SIZE] = 4096
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 2048;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 2048;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 2048;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 4096;
    key_index++;
    
    /*
    #{
    [ACL2_IPE_160]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL2_IPE_320]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL2_IPE_640]
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 512;
    key_index++;

    /*
    #{
    [ACL3_IPE_160]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL3_IPE_320]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL3_IPE_640]
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3_IPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 512;
    key_index++;

    /*
    #{
    [ACL0_EPE_160]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL0_EPE_320]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 256
    #}
    #{
    [ACL0_EPE_640]
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 512
    [ENTRY_SIZE] = 512
    #}
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 512;
    key_index++;

    /*
    #{
    [LPM0_40]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 4096
    #}
    #{
    [LPM0_160]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 8192
    [ENTRY_SIZE] = 4096
    #}*/
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 8192;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    /*
    #{
    [LPM1_1]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_2]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 128
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_3]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 256
    [ENTRY_SIZE] = 128
    #}
    #{
    [LPM1_4]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 768
    [ENTRY_SIZE] = 128
    #}*/
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 128;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 768;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info_size = key_index;

    /*#-----------------Dynamic TABLE SRAM allocation-----------
    #{
    [LPM_PIPE0]
    [TBL_MEM_ID] = 6
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 16384; 
    tbl_index++;

    /*
    #{
    [NEXTHOP]
    [TBL_MEM_ID] = 16
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 49152
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 49152; 
    tbl_index++;

    /*#{
    [MET]
    [TBL_MEM_ID] = 17
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 17);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[17] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[17] = 32768; 
    tbl_index++;

    /*#{
    [EDIT]
    [TBL_MEM_ID] = 15
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 15);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[15] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[15] = 16384; 
    tbl_index++;

    /*#{
    [SCL_HASH_KEY]
    [TBL_MEM_ID] = 11
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    [TBL_MEM_ID] = 12
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 11);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 12);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[11] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[12] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[11] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[12] = 8192; 
    tbl_index++;

    /*#{
    [SCL_HASH_AD]
    [TBL_MEM_ID] = 13
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 13);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[13] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[13] = 32768; 
    tbl_index++;

    /*#{
    [FIB0_HASH_KEY]
    [TBL_MEM_ID] = 0
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 1
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 2
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    [TBL_MEM_ID] = 4
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 8192
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB0_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] = 0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8192; 
    tbl_index++;

    /*
    #{
    [DSMAC_AD]
    [TBL_MEM_ID] = 9
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSMAC_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 9);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[9] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[9] = 16384; 
    tbl_index++;
    
    /*
    #{
    [FIB1_HASH_KEY]
    [TBL_MEM_ID] = 5
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB1_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16384; 
    tbl_index++;

    /*#{
    [DSIP_AD]
    [TBL_MEM_ID] = 8
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    [TBL_MEM_ID] = 10
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 16384
    #}*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSIP_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 10);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[10] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16384; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[10] = 16384; 
    tbl_index++;

    /*#{
    [IPFIX_HASH_KEY]
    [TBL_MEM_ID] = 3
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_IPFIX_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 32768; 
    tbl_index++;
    
    /*#{
    [IPFIX_AD]
    [TBL_MEM_ID] = 7
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 32768
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_IPFIX_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 32768; 
    tbl_index++;
    
    /*#{
    [OAM_APS]
    [TBL_MEM_ID] = 14
    [ENTRY_OFFSET] = 0
    [ENTRY_SIZE] = 20480
    #}
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_OAM_APS; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 14);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[14] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[14] = 20480; 
    tbl_index++;
    
    p_asic_info->tbl_info_size = tbl_index;      

    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_vlan_profile_info
* pupose          :get vlan asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:           316x profile
*******************************************************************************************/
static int32
_lcm_ftm_get_vlan_profile_info(glb_stm_profile_info_t* p_asic_info)
{
#if 0
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);
    
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 16384;
    p_asic_info->mcast_group_number = 6656;
    p_asic_info->vsi_number = 1024;
    p_asic_info->ecmp_number = 64;

    /*2. TCAM ALLOCATION*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_FDB;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_MAC_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_VLAN_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;   

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_MCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 512;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 1536;
    key_index++;   

    p_asic_info->key_info_size = key_index;
    
    /*3. Table allocation*/ 
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0); 
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 24*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  8*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE1;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  28*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 2*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE2;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  30*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 2*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  28*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 2*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);   
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE3;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  30*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 2*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);   
    tbl_index++; 

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MPLS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  28*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 4*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1); 
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 18*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FWD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 18*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET;  
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  18*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 5*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;  

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    tbl_index++;

    /*OAM_CHAN, USERID_AD*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] = 24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4); 
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  30*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 2*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_STATS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    tbl_index++;  

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_OAM_MEP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] = 23*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 7*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info_size = tbl_index;      
#endif
    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_l2vpn_profile_info
* pupose          :get l2vpn asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:            SDK L2VPN VPLS
*******************************************************************************************/
static int32
_lcm_ftm_get_l2vpn_profile_info(glb_stm_profile_info_t* p_asic_info)
{
#if 0
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);
    
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 11392;
    p_asic_info->mcast_group_number = 5632;
    p_asic_info->vsi_number = 1024;
    p_asic_info->ecmp_number = 64;

    /*2. TCAM ALLOCATION*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_MAC_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_VLAN_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;   

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 1024;
    key_index++;      

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++;  

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++;   

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL2;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL3;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++; 

    p_asic_info->key_info_size = key_index;
    
    /*3. Table allocation*/ 
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);     
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 24*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    tbl_index++;    

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MPLS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);   
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);      
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  27*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 5*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FWD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  12*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 15*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);     
    tbl_index++;

    /*OAM_MEP, OAM_MA, OAM_MA_NAME*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_OAM_MEP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  9*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 7*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);    
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    tbl_index++;

    /*OAM_CHAN, USERID_AD*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 9*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);   
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] = 8*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 9*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_STATS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    tbl_index++; 

    p_asic_info->tbl_info_size = tbl_index;      
#endif
    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_ipv6_profile_info
* pupose          :get ipv6 asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:           SDK IPV6 LPM
*******************************************************************************************/
static int32
_lcm_ftm_get_ipv6_profile_info(glb_stm_profile_info_t* p_asic_info)
{
#if 0
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);
    
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 24768;
    p_asic_info->mcast_group_number = 5760;
    p_asic_info->vsi_number = 0;
    p_asic_info->ecmp_number = 64;

    /*2. TCAM ALLOCATION*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_ACL0;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 8;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_ACL1;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 8;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_FDB;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_MCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_MCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 384;
    key_index++; 

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;    

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_VLAN_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;      

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_TUNNEL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;    

    p_asic_info->key_info_size = key_index;
    
    /*3. Table allocation*/ 
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);    
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  14*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 10*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 4*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  8*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  4*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE1;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE2;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE3;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;  

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1); 
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 10*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5); 
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  10*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 22*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FWD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  10*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 22*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 14*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    tbl_index++;    

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    tbl_index++;

    /*OAM_CHAN, USERID_AD*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] = 24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_STATS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    tbl_index++; 

    p_asic_info->tbl_info_size = tbl_index;      
#endif
    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_overlay_profile_info
* pupose          :get overlay asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:
*******************************************************************************************/
static int32
_lcm_ftm_get_overlay_profile_info(glb_stm_profile_info_t* p_asic_info)
{    
#if 0
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);
    
    /*1. misc info*/
    p_asic_info->glb_nexthop_number = 22880;
    p_asic_info->mcast_group_number = 6656;
    p_asic_info->vsi_number = 1024;
    p_asic_info->ecmp_number = 64;

    /*2. TCAM ALLOCATION*/
    /*1. for system mac and mac filter (fixed to 64)*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_FDB;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    /*2. for mac based vlan class hash conflict*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_MAC_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    /*3. for vlan mapping, vpws, vpls ac, vpls pw hash conflict*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_VLAN_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;

    /*4. for ipv4 source guard hash conflict*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;

    /*5. for ipv6 source guard hash conflict*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_SCL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;

    /*6. for lpm conflict and ipv4 route with masklen less than 16*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 1;
    p_asic_info->key_info[key_index].max_key_index = 256;
    key_index++;

    /*7. for ipv4 l3 mcast groups*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_MCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 512;
    key_index++;

    /*8. for lpm conflict and ipv6 route with masklen less than 32 or masklen between 65 and 127*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    /*9. for ipv4 l3 mcast groups*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_MCAST;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;

    /*10. for ipv4 PBR*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++; 

    /*11. for ipv4 NAT*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;

    /*12. for ipv6inipv4 auto tunnel and static tunnel hash conflict*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV4_TUNNEL;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 2;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;     

    /*13. for ipv4 mac acl*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 64;
    key_index++;

     /*14. for ipv4 mac acl*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL1;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 4;
    p_asic_info->key_info[key_index].max_key_index = 864;
    key_index++;

    /*15. for ipv6 acl*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_ACL0;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 8;
    p_asic_info->key_info[key_index].max_key_index = 32;
    key_index++;   

    /*16. for ipv6 acl*/
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_IPV6_ACL1;
    p_asic_info->key_info[key_index].key_media = GLB_STM_INT_TCAM;
    p_asic_info->key_info[key_index].key_size = 8;
    p_asic_info->key_info[key_index].max_key_index = 128;
    key_index++;   

    p_asic_info->key_info_size = key_index;
    
    /*3. Table allocation*/ 
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);     
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 24*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  8*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE1;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  8*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE2;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  20*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  8*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE3;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  20*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 12*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MPLS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);      
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 18*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FWD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 18*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  16*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);   
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  18*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 5*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    /*OAM_MEP, OAM_MA, OAM_MA_NAME*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_OAM_MEP;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  23*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 7*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);   
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    tbl_index++;

    /*OAM_CHAN, USERID_AD*/
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] = 24*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] = 30*1024;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 2*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_STATS;    
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16*1024; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    tbl_index++;    

    p_asic_info->tbl_info_size = tbl_index;      
#endif
    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_openflow_default_profile_info
* pupose          :get default asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:
*******************************************************************************************/
static int32
_lcm_ftm_get_openflow_default_profile_info(glb_stm_profile_info_t* p_asic_info)
{    
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);

    /* ----------------------global----------------------- */   
    /* 1. misc info */
    p_asic_info->glb_nexthop_number = 42048;
    p_asic_info->mcast_group_number = 12348;

    /* ----------------------SPEC----------------------- */
    p_asic_info->profile_specs[GLB_FTM_SPEC_MAC] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_HOST] = 4096;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_LPM] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPMC] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL] = 9216; /* unit 160bits key */
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL_FLOW] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL_FLOW] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_OAM] = 0;
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL] = 512;
    p_asic_info->profile_specs[GLB_FTM_SPEC_TUNNEL] = 9000; /* Modifed by weizj for bug 34218 */
    p_asic_info->profile_specs[GLB_FTM_SPEC_MPLS] = 7400;   /* Modifed by weizj for bug 34218 */
    p_asic_info->profile_specs[GLB_FTM_SPEC_VRF] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPFIX] = 0;
    p_asic_info->profile_specs[GLB_FTM_SPEC_L2MC] = 2048;
    p_asic_info->profile_specs[GLB_FTM_SPEC_FID] = 2048;

    /*#------------------ TCAM allocation---------------------- */
    /* 
        scl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 512;
    key_index++;

    /* 
        scl1
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 512;
    key_index++;

    /* 
        ipe_acl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 1024;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 1024;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 8192;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 8192;
    key_index++;
    
    /* 
        epe_acl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 1024;
    key_index++;

    /* 
        LPM0
    */
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    /* 
         LPM1
    */
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 128;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 768;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info_size = key_index;

    /*#-----------------Dynamic TABLE SRAM allocation-----------*/
    /* 
        LPM0
    */
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 16384; 
    tbl_index++;

    /* 
        DsNexthop
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 17);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[17] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[17] = 32768;
    tbl_index++;
    
    /* 
        DsMet
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 49152;
    tbl_index++;

    /* 
        DsEdit
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 14);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 15);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[14] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[15] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[14] = 20480; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[15] = 16384; 
    tbl_index++;

    /* 
        SCL hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 32768; 
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 11);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 12);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 13);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[11] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[12] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[13] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[11] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[12] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[13] = 32768; 
    tbl_index++;

    /* 
        Flow hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FLOW_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8192; 
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FLOW_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 32768; 
    tbl_index++;

    /* 
        Egress Vlan Xlate
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_XCOAM_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16384;
    tbl_index++;

    /* 
        Fib0 hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB0_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 32768; 
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSMAC_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 9);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[9] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[9] = 16384;
    tbl_index++;

    /* 
        Fib1 hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB1_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16384;
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSIP_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 10);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[10] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[10] = 16384; 
    tbl_index++;


    /* No need to alloc */
    /* GLB_STM_TBL_TYPE_IPFIX_AD */
    /* GLB_STM_TBL_TYPE_IPFIX_HASH_KEY */
    /* GLB_STM_TBL_TYPE_OAM_APS */
    /* GLB_STM_TBL_TYPE_FWD */
    /* GLB_STM_TBL_TYPE_OAM_MEP */
    /* GLB_STM_TBL_TYPE_STATS */
    /* GLB_STM_TBL_TYPE_LM */

    p_asic_info->tbl_info_size = tbl_index;      

    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_tap_profile_info
* pupose          :get default asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:
*******************************************************************************************/
static int32
_lcm_ftm_get_tap_profile_info(glb_stm_profile_info_t* p_asic_info)
{    
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);

    /* ----------------------global----------------------- */   
    /* 1. misc info */
    p_asic_info->glb_nexthop_number = 42048;
    p_asic_info->mcast_group_number = 12348;

    /* ----------------------SPEC----------------------- */
    p_asic_info->profile_specs[GLB_FTM_SPEC_MAC] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_HOST] = 4096;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_LPM] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPMC] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL] = 9216; /* unit 160bits key */
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL_FLOW] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL_FLOW] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_OAM] = 0;
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL] = 512;
    p_asic_info->profile_specs[GLB_FTM_SPEC_TUNNEL] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_MPLS] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_VRF] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPFIX] = 0;
    p_asic_info->profile_specs[GLB_FTM_SPEC_L2MC] = 2048;
    p_asic_info->profile_specs[GLB_FTM_SPEC_FID] = 2048;

    /*#------------------ TCAM allocation---------------------- */
    /* 
        scl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 512;
    key_index++;

    /* 
        scl1
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 512;
    key_index++;

    /* 
        ipe_acl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 1024;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 1024;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 8192;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 8192;
    key_index++;
    
    /* 
        epe_acl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 1024;
    key_index++;

    /* 
        LPM0
    */
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    /* 
         LPM1
    */
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 128;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 768;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info_size = key_index;

    /*#-----------------Dynamic TABLE SRAM allocation-----------*/
    /* 
        LPM0
    */
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 16384; 
    tbl_index++;

    /* 
        DsNexthop
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 17);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[17] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[17] = 32768;
    tbl_index++;
    
    /* 
        DsMet
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 49152;
    tbl_index++;

    /* 
        DsEdit
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 14);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 15);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[14] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[15] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[14] = 20480; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[15] = 16384; 
    tbl_index++;

    /* 
        SCL hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 32768; 
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 11);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 12);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 13);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[11] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[12] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[13] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[11] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[12] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[13] = 32768; 
    tbl_index++;

    /* 
        Flow hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FLOW_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8192; 
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FLOW_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 32768; 
    tbl_index++;

    /* 
        Egress Vlan Xlate
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_XCOAM_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16384;
    tbl_index++;

    /* 
        Fib0 hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB0_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 32768; 
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSMAC_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 9);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[9] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[9] = 16384;
    tbl_index++;

    /* 
        Fib1 hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB1_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16384;
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSIP_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 10);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[10] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[10] = 16384; 
    tbl_index++;


    /* No need to alloc */
    /* GLB_STM_TBL_TYPE_IPFIX_AD */
    /* GLB_STM_TBL_TYPE_IPFIX_HASH_KEY */
    /* GLB_STM_TBL_TYPE_OAM_APS */
    /* GLB_STM_TBL_TYPE_FWD */
    /* GLB_STM_TBL_TYPE_OAM_MEP */
    /* GLB_STM_TBL_TYPE_STATS */
    /* GLB_STM_TBL_TYPE_LM */

    p_asic_info->tbl_info_size = tbl_index;      

    return LCM_E_SUCCESS;
}

/*******************************************************************************************
* name            :_lcm_ftm_get_openflow_hybrid_profile_info
* pupose          :get default asci information
* input           :N/A
* output          :p_asic_info----asic information
* return          :NONE
* note:
*******************************************************************************************/
static int32
_lcm_ftm_get_openflow_hybrid_profile_info(glb_stm_profile_info_t* p_asic_info)
{    
    uint16  key_index = 0;  
    uint16  tbl_index = 0; 

    GLB_PTR_VALID_CHECK(p_asic_info, LCM_E_INVALID_PTR);

    /* ----------------------global----------------------- */   
    /* 1. misc info */
    p_asic_info->glb_nexthop_number = 42048;
    p_asic_info->mcast_group_number = 12348;

    /* ----------------------SPEC----------------------- */
    p_asic_info->profile_specs[GLB_FTM_SPEC_MAC] = 16384;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_HOST] = 4096;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPUC_LPM] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPMC] = 8192;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL] = 9216; /* unit 160bits key */
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL_FLOW] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_ACL_FLOW] = 32768;
    p_asic_info->profile_specs[GLB_FTM_SPEC_OAM] = 0;
    p_asic_info->profile_specs[GLB_FTM_SPEC_SCL] = 512;
    p_asic_info->profile_specs[GLB_FTM_SPEC_TUNNEL] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_MPLS] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_VRF] = 8200;
    p_asic_info->profile_specs[GLB_FTM_SPEC_IPFIX] = 0;
    p_asic_info->profile_specs[GLB_FTM_SPEC_L2MC] = 2048;
    p_asic_info->profile_specs[GLB_FTM_SPEC_FID] = 2048;

    /*#------------------ TCAM allocation---------------------- */
    /* 
        scl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL0_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 3);
    p_asic_info->key_info[key_index].tcam_start_offset[3] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[3] = 512;
    key_index++;

    /* 
        scl1
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_160;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;

    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 256;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_SCL1_640;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_640_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 0);
    p_asic_info->key_info[key_index].tcam_start_offset[0] = 512;
    p_asic_info->key_info[key_index].tcam_entry_num[0] = 512;
    key_index++;

    /* 
        ipe_acl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_IPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 1);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 2);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 5);
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 6);
    p_asic_info->key_info[key_index].tcam_start_offset[1] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[2] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[5] = 0;
    p_asic_info->key_info[key_index].tcam_start_offset[6] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[1] = 1024;
    p_asic_info->key_info[key_index].tcam_entry_num[2] = 1024;
    p_asic_info->key_info[key_index].tcam_entry_num[5] = 8192;
    p_asic_info->key_info[key_index].tcam_entry_num[6] = 8192;
    key_index++;
    
    /* 
        epe_acl0
    */
    p_asic_info->key_info[key_index].key_id = GLB_STM_KEY_TYPE_ACL0_EPE_320;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_320_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 4);
    p_asic_info->key_info[key_index].tcam_start_offset[4] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[4] = 1024;
    key_index++;

    /* 
        LPM0
    */
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_UCAST;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 7);
    p_asic_info->key_info[key_index].tcam_start_offset[7] = 4096;
    p_asic_info->key_info[key_index].tcam_entry_num[7] = 4096;
    key_index++;

    /* 
         LPM1
    */
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 0;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_NAT;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 128;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV4_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_80_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 256;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;
    
    p_asic_info->key_info[key_index].key_id =  GLB_STM_KEY_TYPE_IPV6_PBR;
    p_asic_info->key_info[key_index].key_size = GLB_STM_KEY_SIZE_160_BIT;
    GLB_SET_BIT(p_asic_info->key_info[key_index].tcam_bitmap, 8);
    p_asic_info->key_info[key_index].tcam_start_offset[8] = 768;
    p_asic_info->key_info[key_index].tcam_entry_num[8] = 128;
    key_index++;

    p_asic_info->key_info_size = key_index;

    /*#-----------------Dynamic TABLE SRAM allocation-----------*/
    /* 
        LPM0
    */
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_LPM_PIPE0; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 6);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[6] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[6] = 16384; 
    tbl_index++;

    /* 
        DsNexthop
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_NEXTHOP; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 17);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[17] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[17] = 32768;
    tbl_index++;
    
    /* 
        DsMet
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_MET; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 16);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[16] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[16] = 49152;
    tbl_index++;

    /* 
        DsEdit
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_EDIT; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 14);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 15);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[14] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[15] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[14] = 20480; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[15] = 16384; 
    tbl_index++;

    /* 
        SCL hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 2);
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 3);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[2] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[3] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[2] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[3] = 32768; 
    tbl_index++;

    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_SCL_HASH_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 11);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 12);       
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 13);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[11] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[12] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[13] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[11] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[12] = 8192; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[13] = 32768; 
    tbl_index++;

    /* 
        Flow hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FLOW_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 0);
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 4);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[0] =  0;
    p_asic_info->tbl_info[tbl_index].mem_start_offset[4] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[0] = 32768; 
    p_asic_info->tbl_info[tbl_index].mem_entry_num[4] = 8192; 
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FLOW_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 7);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[7] = 0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[7] = 32768; 
    tbl_index++;

    /* 
        Egress Vlan Xlate
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_XCOAM_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 8);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[8] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[8] = 16384;
    tbl_index++;

    /* 
        Fib0 hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB0_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 1);       
    p_asic_info->tbl_info[tbl_index].mem_start_offset[1] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[1] = 32768; 
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSMAC_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 9);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[9] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[9] = 16384;
    tbl_index++;

    /* 
        Fib1 hash key & AD
    */
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_FIB1_HASH_KEY; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 5);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[5] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[5] = 16384;
    tbl_index++;
    
    p_asic_info->tbl_info[tbl_index].tbl_id = GLB_STM_TBL_TYPE_DSIP_AD; 
    GLB_SET_BIT(p_asic_info->tbl_info[tbl_index].mem_bitmap, 10);
    p_asic_info->tbl_info[tbl_index].mem_start_offset[10] =  0;
    p_asic_info->tbl_info[tbl_index].mem_entry_num[10] = 16384; 
    tbl_index++;


    /* No need to alloc */
    /* GLB_STM_TBL_TYPE_IPFIX_AD */
    /* GLB_STM_TBL_TYPE_IPFIX_HASH_KEY */
    /* GLB_STM_TBL_TYPE_OAM_APS */
    /* GLB_STM_TBL_TYPE_FWD */
    /* GLB_STM_TBL_TYPE_OAM_MEP */
    /* GLB_STM_TBL_TYPE_STATS */
    /* GLB_STM_TBL_TYPE_LM */

    p_asic_info->tbl_info_size = tbl_index;      

    return LCM_E_SUCCESS;

}



/******************************************************************************************
 * name            :lcm_ftm_read_memory_profile
 * pupose          :get key information, include key size, key storation, etc
 * input           :tcam_mode---tcam mode                   
 * output          :p_asic_info: stm profile information
 * return          :NONE
 * note:           N/A
******************************************************************************************/
int32 
lcm_ftm_read_memory_profile(uint8 tcam_mode, glb_stm_profile_info_t* p_asic_info)
{   
    switch (tcam_mode)
    {
        case GLB_STM_MODE_DEFAULT:
            _lcm_ftm_get_default_profile_info(p_asic_info);
            break;

        case GLB_STM_MODE_ACCESS:
            _lcm_ftm_get_access_profile_info(p_asic_info);
            break;

        case GLB_STM_MODE_IPUCV4:
            _lcm_ftm_get_ipv4_profile_info(p_asic_info);
            break;

        case GLB_STM_MODE_VLAN:
            _lcm_ftm_get_vlan_profile_info(p_asic_info);
            break;
            
        case GLB_STM_MODE_L2VPN:
            _lcm_ftm_get_l2vpn_profile_info(p_asic_info);
            break;

        case GLB_STM_MODE_IPUCV6:
            _lcm_ftm_get_ipv6_profile_info(p_asic_info);
            break;

        case GLB_STM_MODE_OVERLAY:
            _lcm_ftm_get_overlay_profile_info(p_asic_info);
            break;            

        case GLB_STM_MODE_OF_DEFAULT:
            _lcm_ftm_get_openflow_default_profile_info(p_asic_info);
            break;            

        case GLB_STM_MODE_OF_HYBRID:
            _lcm_ftm_get_openflow_hybrid_profile_info(p_asic_info);
            break;            

        case GLB_STM_MODE_OF_TAP:
            _lcm_ftm_get_tap_profile_info(p_asic_info);
            break;            
    }
        
    return LCM_E_SUCCESS;
}

#endif /* !GOLDENGATE */
