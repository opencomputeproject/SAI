/****************************************************************************
 * lcm_debug.c      Lcm debug source file.
 *
 * Copyright     :(c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      :R0.01.
 * Author        :Xianting Huang
 * Date          :2010-08-16
 * Reason        :First Create.
 ****************************************************************************/
#include "sal_common.h"
#include "glb_hw_define.h"
#include "lcm_client.h"
#include "lcm_mgt.h"
#include "lcm_error.h"
#include "lcm_debug.h"

/*debug list implement*/
CTCLIB_DEBUG_LIST_IMPLEMENT(LCM);
CTCLIB_DEBUG_LIST_IMPLEMENT(DRV);

/*debug handle for each sub mode*/
CTCLIB_DEBUG_IMPLEMENT(LCM, lcm, chsmtlk);
CTCLIB_DEBUG_IMPLEMENT(LCM, lcm, hagttlk);
CTCLIB_DEBUG_IMPLEMENT(LCM, lcm, card);
CTCLIB_DEBUG_IMPLEMENT(LCM, lcm, lcmgt);
CTCLIB_DEBUG_IMPLEMENT(LCM, lcm, diag);
CTCLIB_DEBUG_IMPLEMENT(LCM, lcm, lcsh);

CTCLIB_DEBUG_IMPLEMENT(DRV, drv, bus);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, clkgen);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, phy);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, poe);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, l2switch);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, epld);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, fiber);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, sensor);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, gpio);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, mux);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, fan);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, power);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, vsc3308);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, eeprom);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, ds21348);
CTCLIB_DEBUG_IMPLEMENT(DRV, drv, ad9559);   /* chani 20130930 for DPLL */

/*********************************************************************
 * Name    : lcm_msg_rx_debug_set
 * Purpose : This is function will set the debug control switches for lcm debug
 * Input   : lcm_clnt_t* clnt, LcmMsg_t* msg
 * Output  : N/A
 * Return  : LCM_E_SUCCESS
 * Note    : 2010.8.16 init version
*********************************************************************/
int32
lcm_msg_rx_debug_set (lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    uint32 flag;
    char level[CTCLIB_DEBUG_NAME_LEN] = "";
    char module[CTCLIB_DEBUG_NAME_LEN] = "";
    char submodule[CTCLIB_DEBUG_NAME_LEN] = "";

    /*get the settings from the message*/
    flag = msg->op.chsmDebugReq.flags;
    sal_strncpy(level, (char *)msg->op.chsmDebugReq.level.buf,
        msg->op.chsmDebugReq.level.size);
    sal_strncpy(module, (char *)msg->op.chsmDebugReq.module.buf,
        msg->op.chsmDebugReq.module.size);
    sal_strncpy(submodule, (char *)msg->op.chsmDebugReq.submodule.buf,
        msg->op.chsmDebugReq.submodule.size);

    /*set in local process*/
    if(0 == sal_strcmp(level, "LCM"))
    {
        if(0 != sal_strcmp(submodule, "none"))
        {
            ctclib_debug_clisetting_common(&(CTCLIB_DEBUG_LIST(LCM)), flag, module,  submodule);
        }
        else
        {
            if(msg->op.chsmDebugReq.clearall)
            {
                ctclib_debug_climodoff_common(&(CTCLIB_DEBUG_LIST(LCM)), module);
            }
            else
            {
                ctclib_debug_climodon_common(&(CTCLIB_DEBUG_LIST(LCM)), module);
            }
        }
    }
    else if(0 == sal_strcmp(level, "DRV"))
    {
        if(0 != sal_strcmp(submodule, "none"))
        {
            ctclib_debug_clisetting_common(&(CTCLIB_DEBUG_LIST(DRV)), flag, module,  submodule);
        }
        else
        {
            if(msg->op.chsmDebugReq.clearall)
            {
                ctclib_debug_climodoff_common(&(CTCLIB_DEBUG_LIST(DRV)), module);
            }
            else
            {
                ctclib_debug_climodon_common(&(CTCLIB_DEBUG_LIST(DRV)), module);
            }
        }
    }
    
    return LCM_E_SUCCESS;
}


/*********************************************************************
 * Name    : lcm_msg_rx_debugctrl_set
 * Purpose : This is function will set the debug control switches for lcm debug
 * Input   : lcm_clnt_t* clnt, LcmMsg_t* msg
 * Output  : N/A
 * Return  : LCM_E_SUCCESS
 * Note    : 2010.8.16 init version
*********************************************************************/
int32
lcm_msg_rx_debugctrl_set (lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    uint32 lc_on; 
    uint32 slot_num = 3;// TODO: how to get slot num?
    uint8 line_function_on;

    /*print out line num & function name*/
    line_function_on = msg->op.chsmDebugCtrlReq.linefunon;
    ctclib_debug_line_function_on(line_function_on);

    /*turn on a line card's debug*/
    lc_on = msg->op.chsmDebugCtrlReq.lcon;
    // TODO: how to get slot num?
    //hagt_get_slot_num (&slot_num);

    if (lc_on & (1 << slot_num))
    {
        lc_on = 1;
    }
    else
    {
        lc_on = 0;
    }
    ctclib_debug_linecard_on(lc_on);

    return LCM_E_SUCCESS;
}


/*********************************************************************
 * Name    : lcm_debug_module_reg
 * Purpose : This function will add debug handle to the list
 * Input   : N/A
 * Output  : N/A
 * Return  : LCM_E_SUCCESS
 * Note    : 2010.8.16 init version
*********************************************************************/
int32 
lcm_debug_module_reg(void)
{
    /*init the list*/
    CTCLIB_DEBUG_LIST_INIT(LCM);
    CTCLIB_DEBUG_LIST_INIT(DRV);

    
    /*add sub module's debug handle to listt*/  
    //CTCLIB_DEBUG_MODULE_REG(LCM, lcm, chsmtlk);
    CTCLIB_DEBUG_MODULE_REG(LCM, lcm, hagttlk);
    CTCLIB_DEBUG_MODULE_REG(LCM, lcm, card);
    CTCLIB_DEBUG_MODULE_REG(LCM, lcm, lcmgt);
    CTCLIB_DEBUG_MODULE_REG(LCM, lcm, diag);
    CTCLIB_DEBUG_MODULE_REG(LCM, lcm, lcsh);

    CTCLIB_DEBUG_MODULE_REG(DRV, drv, bus);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, clkgen);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, phy);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, poe);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, l2switch);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, epld);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, fiber);
    //CTCLIB_DEBUG_MODULE_REG(DRV, drv, sensor);
    //CTCLIB_DEBUG_MODULE_REG(DRV, drv, fan);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, eeprom);
    CTCLIB_DEBUG_MODULE_REG(DRV, drv, ds21348);
	CTCLIB_DEBUG_MODULE_REG(DRV, drv, ad9559);      /* chani 20130930 */
    return LCM_E_SUCCESS;
}

/*********************************************************************
 * Name    : lcm_debug_init
 * Purpose : This is a init function for lcm debug module
 * Input   : N/A
 * Output  : N/A
 * Return  : LCM_E_SUCCESS
 * Note    : 2010.8.16 init version
*********************************************************************/
int32
lcm_debug_init(void)
{
    ctclib_debug_init(FALSE);
#if 0    
    CTCLIB_DEBUG_OPEN(LCM, lcm, chsmtlk);
    CTCLIB_DEBUG_OPEN(LCM, lcm, hagttlk);
    CTCLIB_DEBUG_OPEN(LCM, lcm, card);
    CTCLIB_DEBUG_OPEN(LCM, lcm, lcmgt);
    CTCLIB_DEBUG_OPEN(LCM, lcm, lcsh);

    CTCLIB_DEBUG_OPEN(DRV, drv, fiber);
    CTCLIB_DEBUG_OPEN(DRV, drv, phy);
    CTCLIB_DEBUG_OPEN(DRV, drv, sensor);
    CTCLIB_DEBUG_OPEN(DRV, drv, bus);
#endif    
    /*add to the debug lists*/
    lcm_debug_module_reg();

    return LCM_E_SUCCESS;
}

