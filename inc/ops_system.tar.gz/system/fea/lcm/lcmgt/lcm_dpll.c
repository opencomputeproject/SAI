/****************************************************************************
* $Id$
*  line card dpll information
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : lylandris
* Date          : 2011-12-15
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
 * Header Files 
 *
 ****************************************************************************/
#include "sal_common.h"
#include "glb_hw_define.h"
#include "glb_macro.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "ds3104_api.h"
#include "lcapi.h"
#include "lcm_hagttlk.h"

/****************************************************************************
 *  
 * Defines and Macros
 *
 *****************************************************************************/
char *g_lcm_dpll_state_string[] = 
{
    "000 = Unknown",
    "001 = Free-run",
    "010 = Holdover",
    "011 = Unknown",
    "100 = Locked",
    "101 = Prelocked 2",
    "110 = Prelocked",
    "111 = Loss-of-lock",
};

/****************************************************************************
 *  
 * Global and Declaration
 *
 *****************************************************************************/

/****************************************************************************
 *  
 * Function
 *
 *****************************************************************************/

/***************************************************************************************************
 * Name         : lcm_dpll_status_intr 
 * Purpose      : handle interrupt caused by dpll stauts change          
 * Input        : N/A         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
 ***************************************************************************************************/
int32
lcm_dpll_status_intr(void)
{
    lcapi_lcm_get_clock_status_t clock_status;

    /* Modified by liuht for bug 27549, 2014-03-07 */
    ds3104_read(0, 0x09, &clock_status.dpll_state);
    ds3104_read(0, 0x09, &clock_status.dpll_state);
    ds3104_read(0, 0x0a, &clock_status.select_ifindex);
    ds3104_read(0, 0x0a, &clock_status.select_ifindex);
    
    clock_status.dpll_state &= 0x7;
    clock_status.select_ifindex &= 0xF;
    log_sys(M_MOD_LCM, E_NOTICE, "DPLL switch to %s state.\n", g_lcm_dpll_state_string[clock_status.dpll_state]);

    /* modified by yaom for bug 18501 20110306 */  
    if (lcm2hagt_cb[LCM2HAGT_CB_UPDATE_DPLL_STATE])
    {
        LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_DPLL_STATE, &clock_status);
    }
    
    ds3104_write(0, 0x06, 0x80);
    return LCM_E_SUCCESS;
}

