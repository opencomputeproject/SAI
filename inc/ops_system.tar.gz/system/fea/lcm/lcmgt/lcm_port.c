/****************************************************************************
 * lcm_port.c   :    set line card port status
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     :       R0.01
 * Author       :       ychen
 * Date         :       2010-08-16
 * Reason       :       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "lcm_port.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_phy_define.h"
#include "glb_if_define.h"
#include "glb_macro.h"
#include "lcapi.h"
#include "lcm_debug.h"
#include "lcm_mgt.h"
#include "lcm_error.h"
#include "lcm_hagttlk.h"
#include "lcm_client.h"
#include "lcm_card.h"
#include "ctc_pci.h"
#include "phy_api.h"
#include "fiber_api.h"
#include "fpga_api.h"
#include "epld_api.h"
#include "poe_api.h"
#include "l2switch_api.h"
#include "led_api.h"
#include <linux/if.h>
#include "ctc_port.h"


#include "ctc_error.h"
#include "ctclib_memory.h"
#include "ctc_task.h"
#include "ctc_api.h"
#include "ctc_debug.h"
#include "ctc_interrupt.h"

#include "laiinc.h"

/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/
extern int32 lcm_msg_tx_lcFiberAttach(lcm_clnt_t* clnt,    glb_port_t *p_port);
extern int32 lcm_msg_tx_lcFiberDeAttach(lcm_clnt_t* clnt,    glb_port_t *p_port);
extern int32 lcm_msg_tx_lcFiberUpdate(lcm_clnt_t* clnt,    glb_port_t *p_port);
extern int32 lcm_msg_tx_lcChsmPOEport(lcm_clnt_t* clnt, glb_port_t* p_port);
extern int32 lcm_msg_tx_lcChsmPOEsys(lcm_clnt_t* clnt, glb_card_t* p_card);
extern int32 lcm_msg_tx_lcchsm8023APStatus(lcm_clnt_t* clnt, glb_port_t* p_port);
extern int32 ds3104_read(uint32 idx, uint16 addr, uint32  *val);
extern int32 ds3104_write(uint32 idx, uint16 addr, uint32  val);
extern int32 
ds26503_write(uint32 idx, uint8 addr, uint32  val);
#ifndef _LCM_OSP_
extern int32 if_build_port_shortname_by_slot_port (char ifname[IFNAMSIZ], uint16 slot_id, uint16 port_id, uint16 sub_port_id);
extern int32 if_build_port_fullname_by_slot_port (char ifname[GLB_PHY_PORT_FULL_NAME_SZ], uint16 slot_id, uint16 port_id, uint16 sub_port_id);
#endif
/* modified by yaom for 10G remote fault 20140410 */
#define LCM_PORT_DEFAULT_REMOTE_FAULT_INTERVAL 100

#define FIBER_MODULE_SCAN_TIME 2000
#define FIBER_MODULE_SCAN_NUM_ONE_ROUND    4
#define FIBER_MODULE_UPDATE_NUM_ONE_ROUND 4
#define FIBER_MODULE_ACCESS_ERR_NOT_TRY_MAX 3
#define FIBER_MODULE_POWER_ON_STABLE_TIME 1000
#define LCM_SYNCE_DISABLE_SLOT  0xFFFFFFFF
extern void *epld_base;

/* added by qicx for trunk bug26437, PTN bug26201 for GB fiber port intr, 2013-12-18 */
#ifndef _GLB_UML_SYSTEM_
static int32 g_port_timer_cnt = 0;
#endif
/* end of qicx added */
lcm_port_get_sum_ffe_cfg_callback_t lcm_port_get_sum_ffe_cfg_cb;

#ifndef _GLB_UML_SYSTEM_
void lcm_port_remote_fault_timer (void* p_data);
void lcm_port_copper_sfp_init(void* p_data);
void lcm_port_port_status_timer (void* p_data);
void lcm_port_led_cfg(void* p_data);

LCM_DEFINE_TASK_ENCAP(lcm_port_remote_fault_timer)
LCM_DEFINE_TASK_ENCAP(lcm_port_copper_sfp_init)
LCM_DEFINE_TASK_ENCAP(lcm_port_port_status_timer)
LCM_DEFINE_TASK_ENCAP(lcm_port_led_cfg)
#endif
int32
hsrv_msg_notify_link_status(void* arg);

/****************************************************************************
 *  
* Global and Declaration
*
*****************************************************************************/
typedef struct lcm_port_get_phy_type_param_s
{
    uint8 is_combo;
    glb_port_interface_t cfg_media;/*just useful when port is combo*/
    glb_port_interface_t linkup_media; /*just useful when port is combo and cfg media is auto*/
    glb_phy_type_t fiber_type;
    
}lcm_port_get_phy_type_param_t;


/****************************************************************************
*  
* Function
*
*****************************************************************************/
int32
lcm_port_init_ffe_cfg_callback(lcm_port_get_sum_ffe_cfg_callback_t func)
{
    lcm_port_get_sum_ffe_cfg_cb = func;
    return LCM_E_SUCCESS;
}
#ifndef _GLB_UML_SYSTEM_
int32
lcm_get_port_ap_ffe_cfg(uint8 serdes_id, lcm_chip_serdes_ffe_t* ap_ffe)
{
    glb_card_t* p_card = NULL;

    /*28G serdes AP ffe cfg*/
    if(((serdes_id >=40)&&(serdes_id <= 47))
        ||((serdes_id >=88)&&(serdes_id <= 95)))
    {
        ap_ffe->c0 = 0;
        ap_ffe->c1 = 0x3;
        ap_ffe->c2 = 0x2b;
        ap_ffe->c3 = 0x12;
    }
    else /* 15G serdes AP ffe cfg*/
    {
        p_card= lcm_mgt_get_card(); 
        if(p_card->board_material_M4)
        {
            ap_ffe->c0 = 2;
            ap_ffe->c1 = 0x22;
            ap_ffe->c2 = 0xe;
        }
        else
        {
            ap_ffe->c0 = 0x3;
            ap_ffe->c1 = 0x24;
            ap_ffe->c2 = 0x12;
        }        
    }
    return 0;
}

/*bug33637. update ffe */ 
int32
lcm_port_update_ffe(glb_port_t* p_port)
{
    uint8 i;
    uint8 serdes_num, is_DAC=0;
    lcm_chip_serdes_ffe_t serdes_ffe;
    lcapi_hagt_set_ffe_t ap_ffe_cfg;
    lcapi_hagt_set_ffe_t sum_ffe_cfg;
    ctc_chip_serdes_ffe_t ffe_param;

    if((p_port->port_speed_ability & (GLB_SUPPORT_SPEED_40G|GLB_SUPPORT_SPEED_100G)) != 0)
    {        
        serdes_num = 4;
    }
    else
    {
        serdes_num = 1;
    }

    if((p_port->p_fiber != NULL) && (fiber_is_direct_attach_cable(p_port->p_fiber)))
    {
        is_DAC = 1;
    }
    
    if(is_DAC)
    {
        for(i=0; i<serdes_num; i++)
        {
            lcm_get_port_ap_ffe_cfg(p_port->chip_serdes_id+i, &serdes_ffe);
            ap_ffe_cfg.chip = p_port->local_chip_idx;            
            ap_ffe_cfg.serdes = p_port->chip_serdes_id+i;
            ap_ffe_cfg.c0 = serdes_ffe.c0;
            ap_ffe_cfg.c1 = serdes_ffe.c1;
            ap_ffe_cfg.c2 = serdes_ffe.c2;
            ap_ffe_cfg.c3 = serdes_ffe.c3;
            //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_FFE, &ap_ffe_cfg);

           
            ffe_param.serdes_id = ap_ffe_cfg.serdes;
            ffe_param.mode = CTC_CHIP_SERDES_FFE_MODE_3AP;
            ffe_param.coefficient[0] = ap_ffe_cfg.c0;
            ffe_param.coefficient[1] = ap_ffe_cfg.c1;
            ffe_param.coefficient[2] = ap_ffe_cfg.c2;
            ffe_param.coefficient[3] = ap_ffe_cfg.c3;
            ctc_chip_set_property(ap_ffe_cfg.chip, CTC_CHIP_PROP_SERDES_FFE, (void*)&ffe_param);
        }
    }
    else
    {               
        for(i=0; i<serdes_num; i++)
        {
            serdes_ffe.serdes_id = p_port->chip_serdes_id+i;
            lcm_port_get_sum_ffe_cfg_cb(&serdes_ffe);
            sum_ffe_cfg.chip = p_port->local_chip_idx;            
            sum_ffe_cfg.serdes = serdes_ffe.serdes_id;
            sum_ffe_cfg.board_material = serdes_ffe.board_material;
            sum_ffe_cfg.mode = serdes_ffe.mode;
            sum_ffe_cfg.trace_len = serdes_ffe.trace_len;
            sum_ffe_cfg.c0 = serdes_ffe.c0;
            sum_ffe_cfg.c1 = serdes_ffe.c1;
            sum_ffe_cfg.c2 = serdes_ffe.c2;
            sum_ffe_cfg.c3 = serdes_ffe.c3;
           // LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_SUM_FFE, &sum_ffe_cfg);

            ffe_param.serdes_id = sum_ffe_cfg.serdes;
            ffe_param.board_material = sum_ffe_cfg.board_material;
            ffe_param.mode = sum_ffe_cfg.mode;
            ffe_param.trace_len = sum_ffe_cfg.trace_len;
            ffe_param.coefficient[0] = sum_ffe_cfg.c0;
            ffe_param.coefficient[1] = sum_ffe_cfg.c1;
            ffe_param.coefficient[2] = sum_ffe_cfg.c2;
            ffe_param.coefficient[3] = sum_ffe_cfg.c3;
            ctc_chip_set_property(sum_ffe_cfg.chip, CTC_CHIP_PROP_SERDES_FFE, (void*)&ffe_param);
        }
    }
    return 0;
}

/************************************************
 * Bug33195.                                          *
 * For 28G serdes, when use DAC, rx_peak need set to 0.          *
 * for 40G/100G port, need cfg 4 lane, other just 1 lane.           *
 * If not 28G serdes, sdk will return.                *
 ************************************************/
int32
lcm_port_update_rx_peaking(glb_port_t* p_port)
{
    uint8 i, serdes_num, peak_enable=1;
    lcapi_hagt_set_rx_peaking_t rx_peaking_cfg;
    ctc_chip_serdes_peaking_t serdes_peaking;
    
    if((p_port->port_speed_ability & (GLB_SUPPORT_SPEED_40G|GLB_SUPPORT_SPEED_100G)) != 0)
    {        
        serdes_num = 4;
    }
    else
    {
        serdes_num = 1;
    } 
    if((p_port->p_fiber != NULL) && (fiber_is_direct_attach_cable(p_port->p_fiber)))
    {
        peak_enable = 0;
    }
    rx_peaking_cfg.enable = peak_enable;
    rx_peaking_cfg.chip = p_port->local_chip_idx;
    for(i=0; i<serdes_num; i++)
    {
        rx_peaking_cfg.serdes = p_port->chip_serdes_id+i;
        //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_RX_PEAKING, &rx_peaking_cfg);
    
        serdes_peaking.serdes_id = rx_peaking_cfg.serdes;
        serdes_peaking.enable = rx_peaking_cfg.enable;
        ctc_chip_set_property(rx_peaking_cfg.chip, CTC_CHIP_PROP_SERDES_RX_PEAKING, (void*)&serdes_peaking);
        
    }
    return 0;
}
#endif
/***************************************************************************************************
 * Name         : lcm_get_port_by_panel_info 
 * Purpose      : get panel slot and port map to port_id           
 * Input        : panel slot, panel port
 * Output       : port id(start from 1.)             
 * Return       : LCM_E_SUCCESS
 * Note         : 
***************************************************************************************************/
/*Fix bug 14686. jqiu 2011-06-15*/
int32
lcm_get_port_by_panel_info(uint8 panel_slot, uint8 panel_port, uint8 panel_subport, uint8* port_id)
{
    glb_card_t* p_card = NULL;
    uint8 i;
    
    /*get local line card*/
    p_card= lcm_mgt_get_card(); 
    for(i=0; i<p_card->port_num; i++)
    {
        if((p_card->pp_port[i]->panel_slot_no == panel_slot)&&(p_card->pp_port[i]->panel_port_no == panel_port)
            &&(p_card->pp_port[i]->panel_sub_port_no == panel_subport))
        {
            *port_id = i+1;
            return LCM_E_SUCCESS;
        }
    }
    return LCM_E_NOT_FOUND;
}

/***************************************************************************************************
 * Name         : lcm_port_get_port_status 
 * Purpose      : get port status for speed, duplex and media type          
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_notify_port_status (void* pv_arg)
{
    lcapi_lcm_get_port_status_t* p_rcv_port_status = NULL;
    glb_card_t* p_card = NULL;    
    glb_port_t* p_port = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    int32 ifindex = 0;
    lcm_if_phy_state_notify_t notify;
    lcapi_lcm_get_port_status_t port_status;
    lcapi_lcm_get_port_status_t* p_port_status;

    lai_port_info_t lai_port;
    lai_object_id_t oid = 0;

    int32 ret = 0;
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    sal_memset(&port_status, 0, sizeof(port_status));
    p_rcv_port_status = (lcapi_lcm_get_port_status_t*)pv_arg;    
    /*get port index*/
    panel_slot = p_rcv_port_status->slot_no;
    panel_port = p_rcv_port_status->port_no;
    panel_subport = p_rcv_port_status->sub_port_no;

    p_port_status = &port_status;
    
    /*Fix bug 14686. jqiu 2011-06-15*/
    if_build_ethname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__,port_name);
        LCM_PRINT_CON("%s Can't find port idx for %s",__FUNCTION__,port_name);
        return LCM_E_NOT_FOUND;
    }

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

    p_port = p_card->pp_port[port_idx - 1];
    //p_port_status->slot_idx = p_port->panel_slot_no;
    //p_port_status->port_idx = p_port->panel_port_no;
    //p_port_status->subport_idx = p_port->panel_sub_port_no;
    p_port_status->phy_type = GLB_PORT_PHY_TYPE(p_port)|p_port->phy_type; 
    /* modified by yaom for 10G remote fault 20140410 */
    if (GLB_SUPPORT_SPEED_10G != p_port->port_speed_ability)
    {
        p_port_status->enable = p_port->port_status.link_up;
    }
    else
    {
        if (p_port->port_status.link_up && !p_port->remote_fault_status)
        {
            p_port_status->enable = GLB_LINK_UP;
        }
        else
        {
            p_port_status->enable = GLB_LINK_DOWN;
        }
    }
    p_port_status->speed = p_port->port_status.speed;
    p_port_status->duplex = p_port->port_status.duplex;
    p_port_status->flowctrl.send = p_port->port_status.flowctrl.send;
    p_port_status->flowctrl.recv = p_port->port_status.flowctrl.recv;
    /* Modified by liuht to support eee for bug 28298, 2014-05-16 */
    p_port_status->eee_status.status= p_port->port_status.eee_status.status;
    p_port_status->eee_status.wake_error_count = p_port->port_status.eee_status.wake_error_count;
    /* End of liuht modified */
    /* Modified by liuht for bug 29005, 2014-06-17 */
    p_port_status->port_status_change = p_port->port_status.port_status_change;
    /* End of liuht modified */
    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "interface %s Get port %d status: speed %d, duplex %d, flowctrl send %d, recv %d, media type 0x%x, enable %d, eee status 0x%x, wake_error_count %d, port_status_change 0x%x,p_port->port_status.link_up = %d", 
                  port_name, port_idx-1, p_port_status->speed, p_port_status->duplex, 
                  p_port_status->flowctrl.send, p_port_status->flowctrl.recv,
                  p_port_status->phy_type, p_port_status->enable, 
                  p_port_status->eee_status.status, p_port_status->eee_status.wake_error_count,
                  p_port_status->port_status_change, p_port->port_status.link_up);

    /*send port status to switchd*/
    sal_memset(&notify, 0, sizeof(notify));
    ifindex = if_get_ifindex_by_name(port_name);
    if (ifindex < 0)
    {
        LCM_LOG_ERR(" _hsrv_msg_if_set_phy_state rx non-exist interface %s", notify.ifname);
        LCM_PRINT_CON(" _hsrv_msg_if_set_phy_state rx non-exist interface %s", notify.ifname)
    
    }
    notify.ifindex = ifindex;
    notify.speed = p_port_status->speed;
    notify.duplex = p_port_status->duplex;
    notify.link_up = p_port_status->enable;
    notify.flowctrl_send = p_port_status->flowctrl.send;
    notify.flowctrl_recv = p_port_status->flowctrl.recv;
    notify.media = p_port_status->phy_type;
    sal_memcpy(notify.ifname, port_name, 33);

    /* send to switch */
    //ret = hsrv_msg_notify_link_status((void*) &(notify));
        /*add port lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_port_event)
    {
        //LCM_PRINT_CON("############ call on_port_event cb, port is %d %s up %d",
            //p_port->port_idx,port_name, p_port_status->enable);
        oid = (p_card->phy_slot_no<<16) + p_port->port_idx -1 ;
        
        LCM_IF_ERROR_RETURN(ctc_lai_get_port_info(oid, &lai_port));
        if(p_port_status->enable == GLB_LINK_UP)
        {
            p_lai_card_noti->on_port_event(LAI_PORT_EVENT_UP, &lai_port);
        }
        else
        {
            p_lai_card_noti->on_port_event(LAI_PORT_EVENT_DOWN, &lai_port);
        }

    }

    return ret;
}


/***************************************************************************************************
 * Name         : hagt_lcm_set_mac_speed 
 * Purpose      : callback function by lcm, set mac speed
 * Input        : 
 * Output       : N/A              
 * Return       : SUCCESS HAGT_E_NONE
 * Note         : 
***************************************************************************************************/
int32
lcm_set_mac_speed(void* p_arg)
{
    lcapi_hagt_set_mac_speed_t* p_set_mac_en;
    ctc_port_speed_t ctc_port_speed;
        
    if(NULL == p_arg)
    {
        return LCM_E_INVALID_PTR;
    }

    p_set_mac_en = (lcapi_hagt_set_mac_speed_t*)p_arg;
    switch(p_set_mac_en->speed_mode)
    {
        case GLB_SPEED_10M:
            ctc_port_speed = CTC_PORT_SPEED_10M;
            break;
        case GLB_SPEED_100M:
            ctc_port_speed = CTC_PORT_SPEED_100M;
            break;
        case GLB_SPEED_1G:
            ctc_port_speed = CTC_PORT_SPEED_1G;
            break;
        case GLB_SPEED_AUTO:
        /*added by jcao for 10G, don't need to config chip*/    
        case GLB_SPEED_10G:
        case GLB_SPEED_40G:
        case GLB_SPEED_100G:
            return 0;
        default:
            return LCM_E_NOT_FOUND;
    }
    
    return ctc_port_set_speed(p_set_mac_en->gport, ctc_port_speed);
}


/***************************************************************************************************
 * Name         : hagt_lcm_set_mac_flowcntrl
 * Purpose      : callback function by lcm, set mac flowcntrl
 * Input        : 
 * Output       : N/A              
 * Return       : SUCCESS HAGT_E_NONE
 * Note         : 
***************************************************************************************************/
int32
lcm_set_mac_flowcntrl(void* p_arg)
{
    lcapi_hagt_set_mac_flowctrl_t* p_set_mac_en;
    uint16 gportid;
    int32 ret = 0;
    ctc_port_fc_prop_t fc;

    if(NULL == p_arg)
    {
        return LCM_E_INVALID_PTR;
    }

    p_set_mac_en = (lcapi_hagt_set_mac_flowctrl_t*)p_arg;
    gportid = p_set_mac_en->gport;

    /* modified by chenxw for bug 24578, 2013-08-22. */ 
    sal_memset(&fc, 0, sizeof(fc));

    /*unsupport 10 G port*/
    /* flow control receive */
    // TODO:  merge sdk 2.1.13
    fc.gport = gportid;
    fc.cos   = 0;
    fc.enable = p_set_mac_en->flowctrl.recv;
    fc.dir = CTC_INGRESS;
    fc.is_pfc = 0;
    ret += ctc_port_set_flow_ctl_en(&fc);
    
    /* flow control send */
    fc.dir = CTC_EGRESS;
    /* modified by chenxw for bug 24578, 2013-08-22. */ 
    fc.enable = p_set_mac_en->flowctrl.send;
    
    ret += ctc_port_set_flow_ctl_en(&fc);

    return ret;
    
}

#if 0
int32
lcm_if_set_phy_state(glb_phy_state_t* pst_notify)
{
    glb_phy_state_t phy_state;

    sal_memset(&phy_state, 0, sizeof(phy_state));
    phy_state.linkup_media = 0;
    phy_state.speed = pst_notify->speed;
    phy_state.duplex = pst_notify->duplex;
    phy_state.link_up = pst_notify->link_up;
    phy_state.flowctrl.send = pst_notify->flowctrl_send;
    phy_state.flowctrl.recv = pst_notify->flowctrl_recv;

    /* send to switch */
    HSRV2SWITCH_MSG_SEND_NOTIFY(SWITCH_FEI_PHY_NOTIFY, pst_notify, sizeof(fei_if_phy_state_notify_t));
    return 0;
}
#endif 

/*Fix bug 14685. jqiu 2011-06-01. when combo port phy type change, update real information to nsm.*/
/*lcm update fiber information to other module.
  notify_flag: LCM_FIBER_INSERT, LCM_FIBER_REMOVE*/
int32
lcm_notify_fiber_info(glb_port_t* p_port, lcm_fiber_notify_event_e notify_flag)
{
    lcapi_lcm_port_info_t panel_port_info;
    lcm_clnt_t *p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    int32 ret;

    if(!p_port || !p_port->create_done)
    {
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port not create.");
        return LCM_E_SUCCESS;
    }
    if(p_lcm_clnt != NULL)
    {
        if(notify_flag == LCM_FIBER_INSERT)
            lcm_msg_tx_lcFiberAttach(p_lcm_clnt, p_port);
        else
            lcm_msg_tx_lcFiberDeAttach(p_lcm_clnt, p_port);
            
    }
    /*modified by zhuj for bug 13406, 2010-11-19*/
    panel_port_info.port_no = p_port->panel_port_no;
    panel_port_info.sub_port_no= p_port->panel_sub_port_no;
    panel_port_info.slot_no= p_port->panel_slot_no;
    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_LINK_STATUS, &panel_port_info);
    ret = lcm_port_notify_port_status(&panel_port_info);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm update port idx %d status fail.", p_port->port_idx);
        return LCM_E_INIT_FAILED;
    }
    return LCM_E_SUCCESS;
}

glb_phy_type_t lcm_port_get_phy_type(lcm_port_get_phy_type_param_t* param)
{
    glb_phy_type_t phy_type=GLB_PHY_TYPE_UNKNOWN;

    /*For combo port, need to check linkup media*/
    if(param->is_combo)
    {
        if(param->cfg_media == GLB_PORT_TYPE_AUTO)
        {
            if(param->linkup_media == GLB_PORT_TYPE_COPPER)
            {
                phy_type = GLB_PHY_TYPE_1000BASE_T;
            }
            else if(param->linkup_media == GLB_PORT_TYPE_AUTO)
            {
                phy_type = GLB_PHY_TYPE_UNKNOWN;
            }
            else
            {
                phy_type = param->fiber_type;
            }
        }
        else if((param->cfg_media == GLB_PORT_TYPE_COPPER)
                ||(param->cfg_media == GLB_PORT_TYPE_SGMII))
        {
            phy_type = GLB_PHY_TYPE_1000BASE_T;
        }
        else
        {
            phy_type = param->fiber_type;
        }
    }
    else /*for not combo port, copper port is always 1000baseT, fiber port's phy type is same with fiber type*/
    {
        if((param->cfg_media == GLB_PORT_TYPE_COPPER)
            ||(param->cfg_media == GLB_PORT_TYPE_SGMII))
        {
            phy_type = GLB_PHY_TYPE_1000BASE_T;
        }
        else
        {
            phy_type = param->fiber_type;
        }
    }
    return phy_type;
}
#ifndef _GLB_UML_SYSTEM_
/* bug23865. support copper SFP
  port medium depend on 3 param: media, speed, phy/no phy, and fiber type.
  media : copper, fiber, auto
  speed : 10M, 100M, 1G, 10G
  phy/no phy: GB direct to SFP is no phy, GB to phy to SFP is phy.
  fiber : 100Base-X, 1000base-X, serdes copper SFP, sgmii copper SFP
   */
int32 
lcm_port_update_medium(uint32 port_id, glb_port_interface_t media, glb_port_speed_t speed)
{
#ifdef _GGEMU_
    return 0; // TODO: removed by xgu for gg emulation board, 2014-6-3
#else
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    fiber_info_t* p_fiber;
    
    p_card= lcm_mgt_get_card();
    p_port = p_card->pp_port[port_id]; 
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Port %d update medium media %d speed %d fiber %d", 
        port_id, media, speed, (p_port->p_fiber==NULL)?0xff:(((fiber_info_t*)p_port->p_fiber)->fiber_type));
    /* has SFP inserted*/
    if(p_port->p_fiber != NULL)
    {
        p_fiber = (fiber_info_t*)p_port->p_fiber;
        //media auto, mean may be copper or fiber, need process AMS
        if(media == GLB_PORT_TYPE_AUTO)
        {
            //speed must be auto when media is auto
            if(speed != GLB_SPEED_AUTO)
            {
                return LCM_E_INVALID_SPEED;
            }
            // has no phy, GB<->SFP
            if(phy_check_no_phy(port_id))
            {
                // GB port not support media auto when has no phy.
                return LCM_E_INVALID_MEDIA;
            }
            else //has phy, GB<->PHY<->SFP
            {
                //100Base-X SFP
                if((p_fiber->fiber_type == GLB_PHY_TYPE_100BASE_FX)||(p_fiber->fiber_type == GLB_PHY_TYPE_100BASE_LX))
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_AMS_FI_100FX);
                }
                // copper SFP
                else if(p_fiber->fiber_type == GLB_PHY_TYPE_1000BASE_T_SFP)
                {
                    //SGMII Copper SFP
                    if(phy_check_attach_phy(port_id))
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_AMS_FI_PASSTHRU);
                    }
                    //Serdes Copper SFP
                    else
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_AMS_FI_1000BX);
                    }
                }
                //1000BASE-X SFP
                else
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_AMS_FI_1000BX);
                }
            }
        }
        else if(media == GLB_PORT_TYPE_FIBER)
        {
            //GB Fiber not support 10M, 100M. 
            //1000BASE-X and 10GBASE-R dependon port speed ability
            if((speed == GLB_SPEED_10M)
              ||((speed == GLB_SPEED_100M)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_100M)==0))  
              ||((speed == GLB_SPEED_1G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_1G)==0))
              ||((speed == GLB_SPEED_10G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_10G)==0))
              ||((speed == GLB_SPEED_40G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_40G)==0))
              ||((speed == GLB_SPEED_100G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_100G)==0)))
            {
                return LCM_E_INVALID_SPEED;
            }
            // has no phy, GB<->SFP
            if(phy_check_no_phy(port_id))
            {                
                return LCM_E_SUCCESS;
            }
            //has phy, GB<->PHY<->SFP
            else
            {
                if(speed == GLB_SPEED_1G)
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_1000BX);
                }
                else if(speed == GLB_SPEED_100M)
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_FI_100FX);
                }
                else if(speed == GLB_SPEED_AUTO)
                {
                    //100Base-X SFP
                    if((p_fiber->fiber_type == GLB_PHY_TYPE_100BASE_FX)||(p_fiber->fiber_type == GLB_PHY_TYPE_100BASE_LX))
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_FI_100FX);
                    }
                    // copper SFP
                    else if(p_fiber->fiber_type == GLB_PHY_TYPE_1000BASE_T_SFP)
                    {
                        //SGMII Copper SFP
                        if(phy_check_attach_phy(port_id))
                        {
                            phy_cfg_medium(port_id, GLB_MEDIA_PASS_THROUGH);
                        }
                        //Serdes Copper SFP
                        else
                        {
                            phy_cfg_medium(port_id, GLB_MEDIA_1000BX);
                        }
                    }
                    //1000BASE-X SFP
                    else
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_1000BX);
                    }
                }
                else if(speed == GLB_SPEED_10G)
                {
                    if(check_fiber_is_XFP(port_id))
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_XFP);
                    }
                    else
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_SFP_PLUS);
                    }
                }
                else
                {
                    return LCM_E_INVALID_SPEED;
                }
            }
        }
        //media is copper, must has phy
        else if(media == GLB_PORT_TYPE_COPPER)
        {
            phy_cfg_medium(port_id, GLB_MEDIA_RJ45);
            return LCM_E_SUCCESS;
        }
        else if(media == GLB_PORT_TYPE_SGMII)
        {
            phy_cfg_medium(port_id, GLB_MEDIA_PASS_THROUGH);
            return LCM_E_SUCCESS;
        }
        else
        {
            return LCM_E_INVALID_MEDIA;
        }
    }
    else /* No SFP inserted*/ 
    {
        if(media == GLB_PORT_TYPE_AUTO)
        {
            if(speed != GLB_SPEED_AUTO)
            {
                return LCM_E_INVALID_SPEED;
            }
            // has no phy, GB<->SFP
            if(phy_check_no_phy(port_id))
            {
                // GB port not support media auto when has no phy.
                return LCM_E_INVALID_MEDIA;
            }
            else //has phy, GB<->PHY<->SFP, Not SFP, default as 1000BASE-X
            {
                phy_cfg_medium(port_id, GLB_MEDIA_AMS_FI_1000BX);
            }
        }
        else if(media == GLB_PORT_TYPE_FIBER)
        {
            //GB Fiber not support 10M, 100M. 
            //1000BASE-X and 10GBASE-R dependon port speed ability
            if((speed == GLB_SPEED_10M)
              ||((speed == GLB_SPEED_100M)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_100M)==0))  
              ||((speed == GLB_SPEED_1G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_1G)==0))
              ||((speed == GLB_SPEED_10G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_10G)==0))
              ||((speed == GLB_SPEED_40G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_40G)==0))
              ||((speed == GLB_SPEED_100G)&&((p_port->port_speed_ability & GLB_SUPPORT_SPEED_100G)==0)))
            {
                return LCM_E_INVALID_SPEED;
            }
            // has no phy, GB<->SFP
            if(phy_check_no_phy(port_id))
            {
                return LCM_E_SUCCESS;
            }
            //has phy, GB<->PHY<->SFP
            else
            {
                if(speed == GLB_SPEED_1G)
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_1000BX);
                }
                else if(speed == GLB_SPEED_100M)
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_FI_100FX);
                }
                else if(speed == GLB_SPEED_AUTO)
                {
                    phy_cfg_medium(port_id, GLB_MEDIA_1000BX);
                }
                else if(speed == GLB_SPEED_10G)
                {
                    if(check_fiber_is_XFP(port_id))
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_XFP);
                    }
                    else
                    {
                        phy_cfg_medium(port_id, GLB_MEDIA_SFP_PLUS);
                    }
                }
                else
                {
                    return LCM_E_INVALID_SPEED;
                }
            }
        }
        //media is copper
        else if(media == GLB_PORT_TYPE_COPPER)
        {
            phy_cfg_medium(port_id, GLB_MEDIA_RJ45);
            return LCM_E_SUCCESS;
        }
        else if(media == GLB_PORT_TYPE_SGMII)
        {
            phy_cfg_medium(port_id, GLB_MEDIA_PASS_THROUGH);
            return LCM_E_SUCCESS;
        }
        else
        {
            return LCM_E_INVALID_MEDIA;
        }
    }
    return LCM_E_SUCCESS;
#endif
}
#endif

/***************************************************************************************************
 * Name         : lcm_port_set_speed 
 * Purpose      : set port speed           
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_speed(void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    int32 ret=LCM_E_SUCCESS;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;    
    /*get local line card*/
    p_card= lcm_mgt_get_card();   
    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if (lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set port %d  speed %d", port_idx, p_port_status->status);
    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

    p_port = p_card->pp_port[port_idx - 1];
#ifndef _GGEMU_    // TODO:modified by xgu for gg emuation board, 2014-6-2
#ifdef _GLB_UML_SYSTEM_
    if (GLB_SPEED_AUTO == p_port_status->status)
    {
        p_port_status->status = GLB_SPEED_1G;
    }
    p_port->port_status.speed = p_port_status->status;
#else
    ret = lcm_port_update_medium(port_idx - 1, p_port->port_cfg.media, p_port_status->status);
    if_build_port_shortname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
    if(ret != LCM_E_SUCCESS)
    {
        LCM_LOG_ERR("%s port %d update medium error %d when set speed %d media %d.", 
                    port_name, port_idx-1, ret, p_port_status->status, p_port->port_cfg.media);
        return ret;
    }
    phy_cfg_speed(port_idx - 1, p_port_status->status);
    /*When speed change between 40G/100G, FFE need update.*/
#ifdef GOLDENGATE
    lcm_port_update_rx_peaking(p_port);

    /*bug33327, When port speed change between 40G and 100G, ffe need updated.*/
    if((GLB_SPEED_100G == p_port_status->status)||(GLB_SPEED_40G == p_port_status->status))
    {
        lcm_port_update_ffe(p_port);
    }
#endif
#endif /*_GLB_UML_SYSTEM_*/
#else
    if (GLB_SPEED_AUTO == p_port_status->status)
    {
        p_port_status->status = GLB_SPEED_1G;
    }
    p_port->port_status.speed = p_port_status->status;

#endif
    /*store port status*/
    p_port->port_cfg.speed = p_port_status->status;

    return ret;
}
/***************************************************************************************************
 * Name         : lcm_port_set_duplex 
 * Purpose      : set port duplex          
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_duplex (void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;
    /*get local line card*/
    p_card= lcm_mgt_get_card();   
    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  duplex %d", port_idx, p_port_status->status);
    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

    p_port = p_card->pp_port[port_idx - 1];
 // TODO: modified by xgu for gg emulation board, 2014-6-2
#ifndef _GGEMU_
#ifdef _GLB_UML_SYSTEM_
    if (GLB_DUPLEX_AUTO == p_port_status->status)
    {
        p_port_status->status = GLB_DUPLEX_FULL;
    }
    p_port->port_status.duplex = p_port_status->status;
#else
    /*If port is copper, just config phy*/
    if(p_port->port_cfg.media == GLB_PORT_TYPE_COPPER)
    {
        phy_cfg_duplex(port_idx - 1, p_port_status->status);
    }
    else /*If port is fiber, duplex half is not supported.*/
    {
        if(p_port_status->status == GLB_DUPLEX_HALF)
        {
            return LCM_E_INVALID_DUPLEX;
        }
        else
        {
            phy_cfg_duplex(port_idx - 1, p_port_status->status);
        }
    }    
#endif /*_GLB_UML_SYSTEM_*/
#else 
    if (GLB_DUPLEX_AUTO == p_port_status->status)
    {
        p_port_status->status = GLB_DUPLEX_FULL;
    }
    p_port->port_status.duplex = p_port_status->status;
#endif
    /*store port status*/
    p_port->port_cfg.duplex = p_port_status->status;

    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_set_media 
 * Purpose      : set port media          
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/

int32
lcm_port_set_media (void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    glb_port_t* p_port = NULL;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
#ifndef _GLB_UML_SYSTEM_         
#ifndef _GGEMU_ // TODO: removed by xgu for gg emualtion board, 2014-6-2
    lcm_port_get_phy_type_param_t param;
    glb_phy_type_t fiber_type;
    fiber_info_t* p_fiber;
    int32 ret = 0;
#endif
#endif        

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;
          
    /*get local line card*/
    p_card= lcm_mgt_get_card();   
     
    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  media %d", port_idx, p_port_status->status);
    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }
    p_port = p_card->pp_port[port_idx - 1];  
#ifdef _GLB_UML_SYSTEM_                                                                         
   
#else    
#ifndef _GGEMU_ // TODO: removed by xgu for gg emulation board, 2014-6-2
    /*Only combo port support set medium*/
    if(p_port->is_combo)
    {
        ret = lcm_port_update_medium(port_idx-1, p_port_status->status, GLB_SPEED_AUTO);
        if(ret != LCM_E_SUCCESS)
        {
            LCM_LOG_ERR("%s port %d update medium error %d when set media %d speed %d.", 
                port_name, port_idx-1, ret, p_port_status->status, GLB_SPEED_AUTO);
        }

        p_fiber = p_port->p_fiber;
        if(p_fiber != NULL)
        {
            fiber_type = p_fiber->fiber_type;
        }
        else
        {
            fiber_type = GLB_PHY_TYPE_UNKNOWN;
        }
        param.is_combo = p_port->is_combo;
        param.cfg_media = p_port_status->status;
        param.fiber_type = fiber_type;
        if(p_port->port_status.link_up)
        {
            param.linkup_media = p_port->port_status.linkup_media;
        }
        else
        {
            param.linkup_media = GLB_PORT_TYPE_AUTO;
        }
        p_port->phy_type = lcm_port_get_phy_type(&param); 
        ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_LINK_STATUS, &port_idx);
        if(ret < 0)
        {
            LCM_LOG_ERR("Lcm update port idx %d phy type fail.", port_idx);
            return LCM_E_INIT_FAILED;
        }
    }
    else
    {
        return LCM_E_SUCCESS;
    }
#endif
#endif 
               
    /*store port status*/
    p_port->port_cfg.media = p_port_status->status;

    return LCM_E_SUCCESS;
}


/***************************************************************************************************
 * Name         : lcm_port_set_flowctrl
 * Purpose      : set port flow control
 * Input        : pv_arg: port physical information
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_flowctrl(void* pv_arg)
{
    lcapi_lcm_set_flowctrl_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 panel_port, panel_subport, panel_slot, port_idx = 0;  
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_flowctrl_t *)pv_arg;

    /* get local line card */
    p_card = lcm_mgt_get_card();
    
    /* get port index */
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  flowctrl direction %d enable %d", port_idx, p_port_status->direction, p_port_status->enable);
    if(port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

#if 0 // TODO: removed by xgu for gg emulation board, 2014-6-2
#ifdef _GLB_UML_SYSTEM_
    if(p_port_status->direction == GLB_FLOWCTRL_SEND)
    {
        p_card->pp_port[port_idx - 1]->port_status.flowctrl.send = p_port_status->enable;
    }
    else
    {
        p_card->pp_port[port_idx - 1]->port_status.flowctrl.recv = p_port_status->enable;
    }
#else
    phy_cfg_flowctrl(port_idx - 1, p_port_status->direction, p_port_status->enable);
#endif/*_GLB_UML_SYSTEM_*/   

#endif
    if(p_port_status->direction)
    {
        p_card->pp_port[port_idx - 1]->port_cfg.flowctrl.send = p_port_status->enable;
    }
    else
    {
        p_card->pp_port[port_idx - 1]->port_cfg.flowctrl.recv = p_port_status->enable;
    }
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_set_poe_enable
 * Purpose      : set port poe enable or disable
 * Input        : pv_arg: port physical information
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_poe_enable(void* pv_arg)
{
    lcapi_lcm_set_poe_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 panel_port, panel_subport, panel_slot, port_idx = 0;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    int32 ret = 0;

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_poe_status_t *)pv_arg;

    /* get local line card */
    p_card = lcm_mgt_get_card();
    
    /* get port index */
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  poe enable %d", port_idx, p_port_status->status);
    if(port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }
    
#if 1 // TODO: modified by xgu for gg emulation board, 2014-6-2
    return ret;
#else
#ifdef _GLB_UML_SYSTEM_
    return ret;
#else
    ret += poe_port_enable(port_idx - 1, p_port_status->status);
    if(ret)
    {
        LCM_LOG_ERR("Port index %d poe enable cfg driver failed", port_idx);
        return LCM_E_HW_GEN;
    }
#endif/*_GLB_UML_SYSTEM_*/
#endif
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_set_poe_budget
 * Purpose      : set port poe max consumption power
 * Input        : pv_arg: port physical information
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_poe_budget(void* pv_arg)
{
    lcapi_lcm_set_poe_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 panel_port, panel_subport, panel_slot, port_idx = 0;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
//  int32 ret = 0;

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_poe_status_t *)pv_arg;

    /* get local line card */
    p_card = lcm_mgt_get_card();
    
    /* get port index */
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  poe budget %d", port_idx, p_port_status->status);
    if(port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }
#if 0 // Removed by xgu for gg emulation board, 2014-6-2
#ifdef _GLB_UML_SYSTEM_
    return ret;
#else
    ret += poe_set_port_budget(port_idx - 1, p_port_status->status);
    if(ret)
    {
        LCM_LOG_ERR("Port index %d poe budget cfg driver failed", port_idx);
        return LCM_E_HW_GEN;
    }
#endif/*_GLB_UML_SYSTEM_*/
#endif
    return LCM_E_SUCCESS;
}

/* support eee function, modified by liuht for bug 28298, 2014-04-21 */
/***************************************************************************************************
 * Name         : lcm_port_set_eee_capability
 * Purpose      : set port eee capability
 * Input        : pv_arg: port physical information
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_eee_capability(void* pv_arg)
{
    lcapi_lcm_set_eee_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 panel_port, panel_subport, panel_slot, port_idx = 0;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    int32 ret = 0;

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_eee_status_t *)pv_arg;

    /* get local line card */
    p_card = lcm_mgt_get_card();
    
    /* get port index */
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  eee priority %d", port_idx, p_port_status->status);
    if(port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

#ifdef _GLB_UML_SYSTEM_
    return ret;
#else
    ret += phy_cfg_eee_capability(port_idx - 1, p_port_status->status);
    if(ret)
    {
        LCM_LOG_ERR("Port index %d eee priority cfg driver failed", port_idx);
        return LCM_E_HW_GEN;
    }
    else
    {

    }
#endif/*_GLB_UML_SYSTEM_*/

    return LCM_E_SUCCESS;
}
/* end of liuht modified */

/***************************************************************************************************
 * Name         : lcm_port_set_poe_priority
 * Purpose      : set port poe priority
 * Input        : pv_arg: port physical information
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_poe_priority(void* pv_arg)
{
    lcapi_lcm_set_poe_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 panel_port, panel_subport, panel_slot, port_idx = 0;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
  //int32 ret = 0;

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_poe_status_t *)pv_arg;

    /* get local line card */
    p_card = lcm_mgt_get_card();
    
    /* get port index */
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
              "Set port %d  poe priority %d", port_idx, p_port_status->status);
    if(port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

#if 0 // TODO: remvoed by xgu for gg emulation board, 2014-6-2
#ifdef _GLB_UML_SYSTEM_
    return ret;
#else
    ret += poe_set_port_priority(port_idx - 1, p_port_status->status);
    if(ret)
    {
        LCM_LOG_ERR("Port index %d poe priority cfg driver failed", port_idx);
        return LCM_E_HW_GEN;
    }
#endif/*_GLB_UML_SYSTEM_*/
#endif
    return LCM_E_SUCCESS;

}

/***************************************************************************************************
 * Name         : lcm_port_set_8023ap_training 
 * Purpose      : set port 802.3ap  training enable           
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : Bug33278
***************************************************************************************************/
int32
lcm_port_set_8023ap_training(uint8 panel_slot, uint8 panel_port, uint8 panel_subport, uint8 train)
{
    glb_card_t* p_card = NULL;
    uint8 port_idx = 0;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    glb_port_t* p_port = NULL;
#ifndef _GLB_UML_SYSTEM_    
    lcm_clnt_t *clnt = (lcm_clnt_t *)lcm_get_lcm_client();
#endif
    /*get local line card*/
    p_card= lcm_mgt_get_card();   

    /*get port index*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
   
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set port %d  802.3ap training %d ", port_idx, train);

    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }    
    p_port = p_card->pp_port[port_idx - 1];
    p_port->ap_enable = train;
#ifndef _GLB_UML_SYSTEM_      
    /*If disable training, ffe return to sum mode auto, so if DAC, need re-config ap mode*/
    if(!p_port->ap_enable)
    {
        lcm_port_update_ffe(p_port);
    }
  
    /* Notify chsm when set*/
    lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
#endif
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_set_enable 
 * Purpose      : set port mac enable           
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_enable(void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    glb_port_t* p_port = NULL;
#ifdef _GLB_UML_SYSTEM_
    lcapi_lcm_port_info_t panel_port_info;
#endif
//fdef _GLB_UML_SYSTEM_    
    lcapi_hagt_update_stack_port_t port_info;
//ndif
    fiber_info_t* p_fiber;
    uint16 value;
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();   

    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
   
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set port %d  enable %d ", port_idx, p_port_status->status);

    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }    
    p_port = p_card->pp_port[port_idx - 1];
#ifdef _GGEMU_  // TODO: remvoed by xgu for gg emulation board, 2014-6-2
    if (p_port->port_status.link_up == p_port_status->status)
    {
        LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                      "Port %d has been configured enable %d", 
                      port_idx, p_port_status->status);
        return LCM_E_SUCCESS;
    }    
    p_port->port_status.link_up = p_port_status->status;

    if (lcm_mgt_is_enable_stack())  /* Modified by Percy Wang for bug 25588, 2013-11-12 */
    {
        port_info.gport = GLB_TRANS_PORTID_TO_GPORT(p_port->glb_chip_idx, p_port->logic_port_idx);
        port_info.linkup = p_port->port_status.link_up;
        LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_STACK_PORT, &port_info);
    }

#else
#ifdef _GLB_UML_SYSTEM_
    (void)p_fiber;
    (void)value;
    if (p_port->port_status.link_up == p_port_status->status)
    {
        LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                      "Port %d has been configured enable %d", 
                      port_idx, p_port_status->status);
        return LCM_E_SUCCESS;
    }    
    p_port->port_status.link_up = p_port_status->status;

    panel_port_info.port_no = p_port->panel_port_no;
    panel_port_info.sub_port_no = p_port->panel_sub_port_no;
    panel_port_info.slot_no= p_port->panel_slot_no;

    lcm_port_notify_port_status(&panel_port_info);

    if (lcm_mgt_is_enable_stack())  /* Modified by Percy Wang for bug 25588, 2013-11-12 */
    {
        port_info.gport = GLB_TRANS_PORTID_TO_GPORT(p_port->glb_chip_idx, p_port->logic_port_idx);
        port_info.linkup = p_port->port_status.link_up;
        LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_STACK_PORT, &port_info);
    }
#else
    (void)port_info;
    phy_cfg_enable(port_idx - 1, p_port_status->status);

    /* Fix bug30160, qicx, 2014-10-10
     * Software reset is needed when power up port of the following condition.
     * (Only when (1 && 2 && 3) is true)
     * 1, From power down to power up.
     * 2, Configured media is AUTO.
     * 3, Fiber type is 100BASE-X SFP/fiber.
     */
    if (1 == p_port_status->status)
    {
        /* Auto-Media Sense with Cat5 media or 100BASE-FX fiber/SFP media */
        if ((p_port->p_fiber != NULL) && (GLB_PORT_TYPE_AUTO == p_port->port_cfg.media))
        {
            p_fiber = (fiber_info_t*)p_port->p_fiber;
            if(!phy_check_no_phy(port_idx - 1))
            {
                //has phy, GB<->PHY<->SFP
                //100Base-X SFP
                if((p_fiber->fiber_type == GLB_PHY_TYPE_100BASE_FX)||(p_fiber->fiber_type == GLB_PHY_TYPE_100BASE_LX))
                {
                    gephy_reg_read(port_idx - 1, PHY_CTL_REG, &value);
                    value |= 0x8000;
                    gephy_reg_write(port_idx - 1, PHY_CTL_REG, value);
                    sal_udelay(40 * 1000);/* pause after reset */
                }
            }
        }
    }
    /*bug32802, here remove fiber_set_enable() to avoid multi-thread on fiber.*/
#endif /*_GLB_UML_SYSTEM_*/
#endif
    /*store port status*/
    p_port->port_cfg.enable = p_port_status->status;

    return LCM_E_SUCCESS;
}

/* Modified by liuht for bug 28155, 2014-04-17 */
/* Support force master or slave mode */
/***************************************************************************************************
 * Name         : lcm_port_set_master_slave_mode 
 * Purpose      : set port master-slave mode           
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_master_slave_mode(void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    glb_port_t* p_port = NULL;
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();   

    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
   
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set port %d  master-slave mode %d ", port_idx, p_port_status->status);

    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }    
    p_port = p_card->pp_port[port_idx - 1];
#ifdef _GLB_UML_SYSTEM_    
    if (p_port->port_status.master_slave == p_port_status->status)
    {
        LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                      "Port %d has been configured master-slave mode %d", 
                      port_idx, p_port_status->status);
        return LCM_E_SUCCESS;
    }    
    p_port->port_status.master_slave = p_port_status->status;
#else
    phy_cfg_master_slave_mode(port_idx - 1, p_port_status->status);

#endif /*_GLB_UML_SYSTEM_*/

    /*store port status*/
    p_port->port_cfg.master_slave = p_port_status->status;

    return LCM_E_SUCCESS;
}
/* End of liuht modified */

/***************************************************************************************************
 * Name         : lcm_port_set_create_done 
 * Purpose      : set port created done in hsrv/hagt, 
                  if the port is destroyed, parm flag should be 0;     
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
/*modified by xgu for bug 13493, 2011-01-11*/
int32
lcm_port_set_create_done(void* pv_arg)
{
    lcapi_hagt_set_mac_en_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    uint16 gport = 0, portid;
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_hagt_set_mac_en_t*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();   

    /*get port index*/
    gport = p_port_status->gport;  

    for(portid = 0; portid < p_card->port_num; portid++)
    {
        p_port = p_card->pp_port[portid];
        if (p_port && (((p_port->glb_chip_idx << 8) | p_port->logic_port_idx) == gport))
        {
            if (p_port_status->flag)
                p_card->pp_port[portid]->create_done = 1;
            else
                p_card->pp_port[portid]->create_done = 0;
            LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set gport %d  created done %d, portid %d", 
                  gport, p_port_status->flag, portid);
            return LCM_E_SUCCESS;
        }
    }

    LCM_LOG_ERR("Set gport %d  created done %d fail", 
          gport, p_port_status->flag);

    return LCM_E_INVALID_PORT;
}
/***************************************************************************************************
 * Name         : lcm_port_get_port_num 
 * Purpose      : get port num in this local linecard           
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_get_port_num (void* pv_arg)
{
    lcapi_lcm_get_port_num_t* p_ports_num = NULL;
    glb_card_t* p_card = NULL;    

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);    
    p_ports_num = (lcapi_lcm_get_port_num_t*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();   
    p_ports_num->port_num = p_card->port_num;

    return LCM_E_SUCCESS;
}
/***************************************************************************************************
 * Name         : lcm_port_get_port_status 
 * Purpose      : get port status for speed, duplex and media type          
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_get_port_status (void* pv_arg)
{
    lcapi_lcm_get_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;    
    glb_port_t* p_port = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_get_port_status_t*)pv_arg;    
    /*get port index*/
    panel_slot = p_port_status->slot_no;
    panel_port = p_port_status->port_no;
    panel_subport = p_port_status->sub_port_no;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__,port_name);
        return LCM_E_NOT_FOUND;
    }

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }

    p_port = p_card->pp_port[port_idx - 1];
    //p_port_status->slot_idx = p_port->panel_slot_no;
    //p_port_status->port_idx = p_port->panel_port_no;
    //p_port_status->subport_idx = p_port->panel_sub_port_no;
    p_port_status->phy_type = GLB_PORT_PHY_TYPE(p_port)|p_port->phy_type; 
    /* modified by yaom for 10G remote fault 20140410 */
    if (GLB_SUPPORT_SPEED_10G != p_port->port_speed_ability)
    {
        p_port_status->enable = p_port->port_status.link_up;
    }
    else
    {
        if (p_port->port_status.link_up && !p_port->remote_fault_status)
        {
            p_port_status->enable = GLB_LINK_UP;
        }
        else
        {
            p_port_status->enable = GLB_LINK_DOWN;
        }
    }
    p_port_status->speed = p_port->port_status.speed;
    p_port_status->duplex = p_port->port_status.duplex;
    p_port_status->flowctrl.send = p_port->port_status.flowctrl.send;
    p_port_status->flowctrl.recv = p_port->port_status.flowctrl.recv;
    /* Modified by liuht to support eee for bug 28298, 2014-05-16 */
    p_port_status->eee_status.status= p_port->port_status.eee_status.status;
    p_port_status->eee_status.wake_error_count = p_port->port_status.eee_status.wake_error_count;
    /* End of liuht modified */
    /* Modified by liuht for bug 29005, 2014-06-17 */
    p_port_status->port_status_change = p_port->port_status.port_status_change;
    /* End of liuht modified */
    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Get port %d status: speed %d, duplex %d, flowctrl send %d, recv %d, media type 0x%x, enable %d, eee status 0x%x, wake_error_count %d, port_status_change 0x%x", 
                  port_idx-1, p_port_status->speed, p_port_status->duplex, 
                  p_port_status->flowctrl.send, p_port_status->flowctrl.recv,
                  p_port_status->phy_type, p_port_status->enable, 
                  p_port_status->eee_status.status, p_port_status->eee_status.wake_error_count,
                  p_port_status->port_status_change);
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_set_lpbk 
 * Purpose      : set port loopback mode         
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_lpbk(void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ] = {0};
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();   

    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_fullname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set port %d  lp-type %d ", port_idx, p_port_status->status);

    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }    

    p_port = p_card->pp_port[port_idx - 1];
#if _GGEMU_ // TODO: modified by xgu for gg emulation board, 2014-6-2
    if (p_port->lp_type == p_port_status->status)
    {
        LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                      "Port %d has been configured lp-type %d", 
                      port_idx, p_port_status->status);
        return LCM_E_SUCCESS;
    }
    
    p_port->lp_type = p_port_status->status;

#else
#ifdef _GLB_UML_SYSTEM_
    if (p_port->lp_type == p_port_status->status)
    {
        LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                      "Port %d has been configured lp-type %d", 
                      port_idx, p_port_status->status);
        return LCM_E_SUCCESS;
    }
    
    p_port->lp_type = p_port_status->status;
#else
    phy_cfg_loopback(port_idx - 1, p_port_status->status);
#endif /*_GLB_UML_SYSTEM_*/
#endif
    /*store port status*/
    p_port->port_cfg.loopback = p_port_status->status;

    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_set_syncE_enable 
 * Purpose      : set port phy syncE enable           
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_set_syncE_enable(void* pv_arg)
{
    lcapi_lcm_set_port_status_t* p_port_status = NULL;
    glb_card_t* p_card = NULL;
    uint8 port_idx = 0, panel_port, panel_subport, panel_slot;
    char port_name[IFNAMSIZ] = {0};
    
    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_port_status = (lcapi_lcm_set_port_status_t*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();   

    /*get port index*/
    panel_slot = p_port_status->slot_idx;
    panel_port = p_port_status->port_idx;
    panel_subport = p_port_status->subport_idx;
    /*Fix bug 14686. jqiu 2011-06-15*/
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        if_build_port_shortname_by_slot_port(port_name, panel_slot, panel_port, panel_subport);
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, port_name);
        return LCM_E_NOT_FOUND;
    }
    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, 
                  "Set port %d syncE %d ", port_idx, p_port_status->status);

    if (port_idx > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_idx, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }
    #if 0 // Removed by xgu for gg emulation board, 2014-6-2
#ifndef _GLB_UML_SYSTEM_
    if(p_port_status->status)
    {
        phy_cfg_syncE(port_idx - 1, 1);
    }
    else
    {
        phy_cfg_syncE(port_idx - 1, 0);
    }
#endif
#endif
    p_card->pp_port[port_idx - 1]->port_cfg.syncE_enable = p_port_status->status;
    return LCM_E_SUCCESS;
}

/* added by qicx for trunk bug26437, PTN bug26201 for GB fiber port intr, 2013-12-18 */
/***************************************************************************************************
 * Name         : lcm_get_logic_port_array 
 * Purpose      : get logic port array
 * Input        : pv_arg: port physical information         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_get_logic_port_array(void* pv_arg)
{
    uint8 port_id;
    lcapi_lcm_get_logic_port_array_t* p_logic_port_array = NULL;
    glb_card_t* p_card = NULL; 

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    p_logic_port_array = (lcapi_lcm_get_logic_port_array_t*)pv_arg;
    
    /*get local line card*/
    p_card = lcm_mgt_get_card();

    for (port_id = 0; port_id < p_card->port_num; port_id++)
    {
        if (GLB_PORT_TYPE_FIBER != p_card->pp_port[port_id]->port_cfg.media)
        {
            p_logic_port_array->logic_port[port_id] = 0xff;
        }
        else
        {
            p_logic_port_array->logic_port[port_id] = p_card->pp_port[port_id]->logic_port_idx;
        }
    }
    if (port_id < MAX_GB_PORT)
    {
        for (; port_id < MAX_GB_PORT; port_id++)
        {
            /* fill the blanks */
            p_logic_port_array->logic_port[port_id] = 0xff;
        }
    }        
    
    return LCM_E_SUCCESS;
}
/* end of qicx added */

/*bug30363 jqiu add 2014-10-23 for customer request*/
int32
lcm_port_config_phy_test_signal_mode(uint8 panel_slot, uint8 panel_port, uint8 panel_subport, uint8 mode)
{
#ifndef _GLB_UML_SYSTEM_     
    uint8 port_idx, serdes_id;
    glb_card_t* p_card = NULL; 
    char ifname [GLB_PHY_PORT_FULL_NAME_SZ] = {0};

    if_build_port_fullname_by_slot_port(ifname, panel_slot, panel_port, panel_subport);
    if(lcm_get_port_by_panel_info(panel_slot, panel_port, panel_subport, &port_idx)!=LCM_E_SUCCESS)
    {
        /*Modify by weij for support phy port name self-define. bug 31712*/
        LCM_LOG_ERR("%s Can't find port idx for %s",__FUNCTION__, ifname);
        return LCM_E_NOT_FOUND;
    }
    p_card= lcm_mgt_get_card();
    serdes_id = p_card->pp_port[port_idx-1]->chip_serdes_id;
    phy_config_phy_sig_test_mode(port_idx-1, serdes_id, mode);
#endif
    return LCM_E_SUCCESS;
}

#ifndef _GLB_UML_SYSTEM_
/*bug23865. support copper SFP*/
void lcm_port_copper_sfp_init(void* p_data)
{
#ifdef _GGEMU_
    return;// TODO: added by xgu for gg emulation board, 2014-6-2
#endif
    int32 ret = 0;
    uint32 port_id;
    glb_port_t *p_port;
    char port_name[IFNAMSIZ] = {0};
        
    p_port = (glb_port_t *)p_data;
    if (NULL == p_port)
        return;

    port_id = p_port->port_idx - 1;
    
    phy_attach_copper_sfp_phy(port_id);
    /*Bug29809. Combo port don't support SGMII copper SFP. 
      Because for combo port, system need check link status both rj45 and sfp media.
      For rj45+fiber SFP or rj45+Serdes Copper SFP, system just need check original phy;
      For rj45+SGMII Copper SFP, system need check original phy for rj45 and check marvell 
      phy in copper sfp for SGMII Copper SFP. This is confuse the polling logic. In order to 
      simplify the logic, we don't support this usage. So even SGMII Copper SFP insert, treat
      it as Serdes Copper SFP, and it won't work.*/
    if((p_port->is_combo)&&(phy_check_attach_phy(port_id)))
    {
        phy_deattach_copper_sfp_phy(port_id);
        if_build_port_shortname_by_slot_port(port_name, p_port->panel_slot_no, p_port->panel_port_no, p_port->panel_sub_port_no);
        log_sys(M_MOD_LCM, E_WARNING, "Interface %s is combo port, doesn't support SGMII interface copper SFP.", port_name);
    }
    /*When attach copper sfp phy:
      1. attach phy need cfg enable as p_port->port_cfg.enable;
      2. original phy need to cfg enable always; */
    if(phy_check_attach_phy(port_id))
    {
        /*Do item 1 and 2*/
        phy_cfg_enable(port_id, p_port->port_cfg.enable);
        /*Fix bug 30260, 30299, Before sfp insert, mac status depend on los, after copper sfp insert, mac depend on sfp status. 
          Needn't default status, because phy_api.c will copy phy status to next handle status. jqiu 2014-11-19*/
#if 0
        Item 3. Mac need to disable and will update when copper sfp status change. default status of copper sfp is down
        lcapi_hagt_set_mac_en.flag = 0;
        lcapi_hagt_set_mac_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
        ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_EN, &lcapi_hagt_set_mac_en);
#endif        
    }
    else
    {
        /*If no attach phy, roll back fiber enable to cfg value.*/
        fiber_set_enable(port_id, p_port->port_cfg.enable);
    }
    ret = lcm_port_update_medium(port_id, p_port->port_cfg.media, p_port->port_cfg.speed);
    if(ret != LCM_E_SUCCESS)
    {
        LCM_LOG_ERR("port %d update medium error %d when insert sfp speed %d media %d.", 
            port_id, ret, p_port->port_cfg.speed, p_port->port_cfg.media);
    }
    
    return;
}

int32 lcm_port_copper_sfp_remove(glb_port_t *p_port)
{
    int32 ret=0;
    uint32 port_id, attach_flag=0;
    lcapi_hagt_set_mac_en_t lcapi_hagt_set_mac_en;
    
    GLB_PTR_VALID_CHECK(p_port, LCM_E_INVALID_PTR);
    port_id = p_port->port_idx - 1;
    attach_flag = phy_check_attach_phy(port_id);    
    ret = phy_deattach_copper_sfp_phy(port_id);
    /*When remove attach copper sfp phy, need roll back:
      1. fiber tx disable need roll back to original value;
      2. original phy need roll back to original value;
      3. Mac need to disable and will update when original phy status change. default status of original phy is clear to down*/
    if(attach_flag != 0)
    {
        /*Do item 1*/
        fiber_set_enable(port_id, p_port->port_cfg.enable);
        /*Do item 2*/
        phy_cfg_enable(port_id, p_port->port_cfg.enable);
        /*Do item 3*/
        lcapi_hagt_set_mac_en.flag = 0;
        lcapi_hagt_set_mac_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
        //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_EN, &lcapi_hagt_set_mac_en);
        ret = ctc_port_set_mac_en(lcapi_hagt_set_mac_en.gport, lcapi_hagt_set_mac_en.flag);    

    }
    
    return ret;
}

#ifdef PTN_722_BOARD
int32 lcm_port_tod_set_mode_ptn722(void* pv_arg)
{
    int ret = 0;
    lcapi_lcm_set_port_tod_mode_t* p_tod;
    
    p_tod = (lcapi_lcm_set_port_tod_mode_t *)pv_arg;
    if(1 == p_tod->mode) /*tod mode is output*/
    {
        ret = epld_item_write(0, EPLD_PORT_SET_TOD_MOD_PTN722, 0x5);
        return ret;
    }
    if(0 == p_tod->mode) /*tod mode is input*/
    {
        ret = epld_item_write(0, EPLD_PORT_SET_TOD_MOD_PTN722, 0x5);
        return ret;
    }

    return ret;
}

int32 _lcm_epld_slot_sel_ptn722(uint32 slot)
{
    int ret = LCM_E_SUCCESS;
    
    /*
    slot->epld: 0->none, 1->none, 2->"000", 3->"001", 4->"010", 5->"011",
                6->none, 7->none, 8->none, 9->none, 10->"100",
                11->"101", 12->"110", 13->"111", 14->none
    */
    switch(slot)
    {
        case 2:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x00);
            break;
        case 3:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x01);
            break;
        case 4:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x02);
            break;
        case 5:        
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x03);
            break;
        case 10:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x04);
            break;
        case 11:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x05);
            break;
        case 12:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x06);
            break;
        case 13:
            ret += epld_item_write(0, EPLD_SLOT_RCVCLK_SEL_PTN722, 0x07);
            break;
        default:
            break;
    }

    return ret;
}

int32 _lcm_3104_ic_sel_ptn722(uint32 slot, uint32 port)
{
    int ret = LCM_E_SUCCESS;    
    int dpll_ic_mode = 0;

    /*
    slot-port->IC: 0->none, 1->none, 2->IC9, 3->IC9, 4->IC9, 5->IC9,
                6-1->IC1, 6-2->IC2, 7->none, 8->none, 9-1->IC5, 9-2->IC6,
                11->IC9, 12->IC9, 13->IC9, 14->IC4
    */
    switch(slot)
    {
        case 2:
        case 3:
        case 4:
        case 5:
        case 10:
        case 11:
        case 12:
        case 13:
            /* DPLL-IC1-6&IC8, Invalid */
            dpll_ic_mode = 0x00;
            ret += ds3104_write(0, 0x30, dpll_ic_mode);
            /* DPLL-IC9 Valid */
            dpll_ic_mode = 0x01;
            ret += ds3104_write(0, 0x31, dpll_ic_mode);
            break;
        case 6:
            if(1 == port)
            {
                /* DPLL-IC1, Valid */
                dpll_ic_mode = 0x01;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);
                /* DPLL-IC9, Invalid */
                dpll_ic_mode = 0x00;
                ret += ds3104_write(0, 0x31, dpll_ic_mode);     
            }
            else if(2 == port)
            {
                /* DPLL-IC2, Valid */
                dpll_ic_mode = 0x02;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);
                /* DPLL-IC9, Invalid */
                dpll_ic_mode = 0x00;
                ret += ds3104_write(0, 0x31, dpll_ic_mode); 
            }
            break;
        case 9:
            if(1 == port)
            {
                /* DPLL-IC5, Valid */
                dpll_ic_mode = 0x10;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);
                /* DPLL-IC9, Invalid */
                dpll_ic_mode = 0x00;
                ret += ds3104_write(0, 0x31, dpll_ic_mode);     
            }
            else if(2 == port)
            {
                /* DPLL-IC6, Valid */
                dpll_ic_mode = 0x20;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);
                /* DPLL-IC9, Invalid */
                dpll_ic_mode = 0x00;
                ret += ds3104_write(0, 0x31, dpll_ic_mode); 
            }
            break;
        case 14:
            /* DPLL-IC4, Valid */
            dpll_ic_mode = 0x08;
            ret += ds3104_write(0, 0x30, dpll_ic_mode);
            /* DPLL-IC9, Invalid */
            dpll_ic_mode = 0x00;
            ret += ds3104_write(0, 0x31, dpll_ic_mode); 
            break;
        default:
            break;
            
    }

    return ret;
}

int32 _lcm_3104_ic_dis_ptn722(uint32 slot, uint32 port)
{
    int ret = LCM_E_SUCCESS;    
    uint dpll_ic_mode = 0;

    /*
    slot-port->IC: 0->none, 1->none, 2->IC9, 3->IC9, 4->IC9, 5->IC9,
                6-1->IC1, 6-2->IC2, 7->none, 8->none, 9-1->IC5, 9-2->IC6,
                11->IC9, 12->IC9, 13->IC9, 14->IC4
    */
    switch(slot)
    {
        case 2:
        case 3:
        case 4:
        case 5:
        case 10:
        case 11:
        case 12:
        case 13:
            /* DPLL-IC9 Invalid */
            dpll_ic_mode = 0x00;
            ret += ds3104_write(0, 0x31, dpll_ic_mode);
            break;
        case 6:
            if(1 == port)
            {
                ret += ds3104_read(0, 0x30, &dpll_ic_mode);    
                /* DPLL-IC1, Invalid */
                dpll_ic_mode = dpll_ic_mode & 0xFE;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);    
            }
            else if(2 == port)
            {
                ret += ds3104_read(0, 0x30, &dpll_ic_mode);
                /* DPLL-IC2, Invalid */
                dpll_ic_mode = dpll_ic_mode & 0xFD;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);
            }
            break;
        case 9:
            if(1 == port)
            {
                ret += ds3104_read(0, 0x30, &dpll_ic_mode);
                /* DPLL-IC5, Invalid */
                dpll_ic_mode = dpll_ic_mode & 0xEF;
                ret += ds3104_write(0, 0x30, dpll_ic_mode);    
            }
            else if(2 == port)
            {
                ret += ds3104_read(0, 0x30, &dpll_ic_mode);
                /* DPLL-IC6, Invalid */
                dpll_ic_mode = dpll_ic_mode & 0xDF;
                ret += ds3104_write(0, 0x30, dpll_ic_mode); 
            }
            break;
        case 14:
            ret += ds3104_read(0, 0x30, &dpll_ic_mode);
            /* DPLL-IC4, Invalid */
            dpll_ic_mode = dpll_ic_mode & 0xF7;
            ret += ds3104_write(0, 0x30, dpll_ic_mode); 
            break;
        default:
            break;
            
    }

    return ret;
}

int32 _lcm_ptn722_port_map(lcapi_lcm_port_select_slot_clock_t* p_slot)
{
    glb_card_t* p_card;

        
    switch(p_slot->port_idx)
    {
        case 1:
        case 2:
        case 3:
        case 4:
            p_slot->slot = 2;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;
            
        case 5:
        case 6:
        case 7:
        case 8:
            p_slot->slot = 3;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;    

        case 9:
        case 10:
        case 11:
        case 12:
            p_slot->slot = 4;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;

        case 13:
        case 14:
        case 15:
        case 16:
            p_slot->slot = 11;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;

        case 17:
        case 18:
        case 19:
        case 20:
            p_slot->slot = 12;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;

        case 21:
        case 22:
        case 23:
        case 24:
            p_slot->slot = 13;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;

        case 25:
        case 26:
        case 27:
        case 28:
            p_slot->slot = 14;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;
            
        case 29:
        case 30:
            break;
            
        case 31:
        case 32:
            break;

        case 33:
            /* eth-0-33 can be switch to slot7/8 by set epld 0x2b. */
            p_slot->slot = 9;
            p_slot->port_idx = 2;
            break;
        case 36:
            p_slot->slot = 9;
            p_slot->port_idx = 1;

            break;
            
        case 34:
            p_slot->slot = 6;
            p_slot->port_idx = 1;
            break;
            
        case 35:
            p_slot->slot = 6;
            p_slot->port_idx = 2;
            break;

        case 38:
            /*get local line card*/
            p_card = lcm_mgt_get_card();
            if(DATAPATH_MODE_1G == p_card->datapath_mode)
            {
                p_slot->slot = 5;
                p_slot->port_idx = p_slot->port_idx % 4;
            }
            else if(DATAPATH_MODE_10G == p_card->datapath_mode)
            {
                p_slot->slot = 10;
                p_slot->port_idx = 1;
            }
            break;
            
        case 37:
        case 39:
        case 40:
            p_slot->slot = 5;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;
            
        case 41:
        case 42:
        case 43:
        case 44:
            p_slot->slot = 10;
            p_slot->port_idx = p_slot->port_idx % 4;
            break;

        default:
            return LCM_E_INVALID_PORT;
    }

    /* If the current port_idx value is 0, that means the actual port_idx is 4.
       Because p_slot->port_idx = p_slot->port_idx % 4. */
    if(0 == p_slot->port_idx)
    {
        p_slot->port_idx = 4;
    }

    return LCM_E_SUCCESS;
}

int32 lcm_port_ptn722_select_slot_clock(void* pv_arg)
{
    int ret = LCM_E_SUCCESS;
    lcapi_lcm_port_select_slot_clock_t* p_slot;  
    p_slot = (lcapi_lcm_port_select_slot_clock_t *)pv_arg;
    if(LCM_SYNCE_DISABLE_SLOT == p_slot->slot)
    {
        /* close all IC in ds3104 */
        ret += ds3104_write(0, 0x30, 0);
        ret += ds3104_write(0, 0x31, 0);
        return ret;
    }
    _lcm_ptn722_port_map(p_slot);
   
    /* config epld */
    ret += _lcm_epld_slot_sel_ptn722(p_slot->slot);
    
    if(1 == p_slot->mode)
    {
        /* sel ic */
        ret += _lcm_3104_ic_sel_ptn722(p_slot->slot, p_slot->port_idx);
        return ret;
    }
    if(0 == p_slot->mode)
    {
        /* dis ic */
        /* There is a bug when read ds3104 reg, so we close all IC to avoid it. */
        /* ret += _lcm_3104_ic_dis_ptn722(p_slot->slot, p_slot->port_idx);*/
        /* close all IC in ds3104 */     

        ret += ds3104_write(0, 0x30, 0);
        ret += ds3104_write(0, 0x31, 0);  
        return ret;
    }

    return LCM_E_SUCCESS;
}

int32 lcm_clock_recovery_select(void* pv_arg)
{
    uint32 dpll_ic_mode;
    lcapi_lcm_set_clock_recovery_select_t* p_recovery_select;
    p_recovery_select = (lcapi_lcm_set_clock_recovery_select_t*)pv_arg;
    
    if(0 == p_recovery_select->clock_recovery_select) /*clock recovery by syncE*/
    {
        dpll_ic_mode = 0x0;
        ds3104_write(0, 0x30, dpll_ic_mode);

        dpll_ic_mode = 0x0;
        ds3104_write(0, 0x31, dpll_ic_mode);
    }
    if(1 == p_recovery_select->clock_recovery_select) /*clock recovery by bits*/
    {
        dpll_ic_mode = 0x80;
        ds3104_write(0, 0x30, dpll_ic_mode);

        dpll_ic_mode = 0;
        ds3104_write(0, 0x31, dpll_ic_mode);
    }

    return LCM_E_SUCCESS;  
}

#endif

#ifdef GB_DEMO_BOARD
int32 lcm_port_tod_set_mode(void* pv_arg)
{
    int ret = 0;
    lcapi_lcm_set_port_tod_mode_t* p_tod;
    
    p_tod = (lcapi_lcm_set_port_tod_mode_t *)pv_arg;
    if(1 == p_tod->mode) /*tod mode is output*/
    {
        ret = epld_item_write(0, EPLD_PORT_SET_TOD_MOD, 0x3);
        return ret;
    }
    if(0 == p_tod->mode) /*tod mode is input*/
    {
        ret = epld_item_write(0, EPLD_PORT_SET_TOD_MOD, 0x0);
        return ret;
    }
    return ret;
}

int32 lcm_10g_port_dpll_ic_set_mode(void* pv_arg)
{
    uint32 dpll_ic_mode;
    lcapi_lcm_set_10g_port_dpll_ic_mode_t* p_dpll_ic12_mode;

    p_dpll_ic12_mode = ( lcapi_lcm_set_10g_port_dpll_ic_mode_t*)pv_arg;
    if(1 == p_dpll_ic12_mode->mode) /*DPLL IC1,IC2 should no shutdown*/
    {
        ds3104_read(0, 0x030, &dpll_ic_mode);
        dpll_ic_mode = (dpll_ic_mode | 0x03);
        ds3104_write(0, 0x30, dpll_ic_mode);
    }
    if(0 == p_dpll_ic12_mode->mode)/*DPLL IC1,IC2 should shutdown*/
    {
        ds3104_read(0, 0x030, &dpll_ic_mode);
        dpll_ic_mode = (dpll_ic_mode & 0xFC);
        ds3104_write(0, 0x30, dpll_ic_mode);
    }

     return LCM_E_SUCCESS;    
}

int32 lcm_clock_recovery_select(void* pv_arg)
{
    uint32 dpll_ic_mode;
    lcapi_lcm_set_clock_recovery_select_t* p_recovery_select;
    p_recovery_select = (lcapi_lcm_set_clock_recovery_select_t*)pv_arg;
    
    if(0 == p_recovery_select->clock_recovery_select) /*clock recovery by syncE*/
    {
        dpll_ic_mode = 0x3f;
        ds3104_write(0, 0x30, dpll_ic_mode);

        dpll_ic_mode = 0;
        ds3104_write(0, 0x31, dpll_ic_mode);
    }
    if(1 == p_recovery_select->clock_recovery_select) /*clock recovery by bits1*/
    {
        dpll_ic_mode = 0x80;
        ds3104_write(0, 0x30, dpll_ic_mode);

        dpll_ic_mode = 0;
        ds3104_write(0, 0x31, dpll_ic_mode);
    }
    if(2 == p_recovery_select->clock_recovery_select) /*clock recovery by bits2*/
    {
        dpll_ic_mode = 0;
        ds3104_write(0, 0x30, dpll_ic_mode);

        dpll_ic_mode = 1;
        ds3104_write(0, 0x31, dpll_ic_mode);
    }

    return LCM_E_SUCCESS;  
}

#endif

int32 lcm_port_tod_set_out_put_mode(void* pv_arg)
{
    lcapi_lcm_set_port_tod_out_put_mode_t* p_mode;
    int ret = LCM_E_SUCCESS;
    p_mode = (lcapi_lcm_set_port_tod_out_put_mode_t *)pv_arg;
    #ifdef GB_DEMO_BOARD
    if(1 == p_mode->mode) /*tod mode is bps*/
    {
        ret += ds3104_write(1, 0x8, 0x48);
        ret += ds3104_write(2, 0x8, 0x48);
        return ret;
    }
    if(0 == p_mode->mode) /*tod mode is hz*/
    {
        ret += ds3104_write(1, 0x8, 0x88);
        ret += ds3104_write(2, 0x8, 0x88);
        return ret;
    }
    #endif
    #ifdef PTN_722_BOARD
    if(1 == p_mode->mode) /*tod mode is bps*/
    {
        ds26503_write(0, 0x8, 0x48);
        return ret;
    }
    if(0 == p_mode->mode) /*tod mode is hz*/
    {
        ds26503_write(0, 0x8, 0x88);
        return ret;
    }
    #endif

    return ret; 
}

int32 lcm_port_create_fiber(glb_port_t* p_port)
{
    CTC_TASK_GET_MASTER
    fiber_info_t* p_fiber;
    glb_phy_type_t fiber_type;
    int32 ret;
    uint32 port_id;
    uint8 pannel_subport;
    lcm_port_get_phy_type_param_t param;

    lai_fiber_info_t lai_fiber;
    lai_object_id_t oid = 0;
    glb_card_t* p_card = NULL; 

    p_card= lcm_mgt_get_card();
     
    if(NULL == p_port || NULL == p_card)
    {
        return LCM_E_INVALID_PARAM;
    }
    
    

    pannel_subport = p_port->panel_sub_port_no;
    port_id = p_port->port_idx - 1;
    
    p_fiber = LCM_CALLOC(CTCLIB_MEM_LCM_MODULE, sizeof(fiber_info_t));
    if(NULL == p_fiber)
    {
        LCM_LOG_ALERT("Fiber port: Out of memory");
        return LCM_E_NO_MEMORY;
    }
    /*Modify by jqiu for bug 15855. 2011-08-25*/
    ret = fiber_get_chip_info(port_id, p_fiber);
    /*Bug18147. If access fail, return, wait next time scan and access.*/
    if(ret < 0)
    {        
        p_port->fiber_access_err_cnt++;
        if(p_port->fiber_access_err_cnt <= FIBER_MODULE_ACCESS_ERR_NOT_TRY_MAX)
        {
            LCM_LOG_WARN("Fiber port: access fail.");
            LCM_FREE(CTCLIB_MEM_LCM_MODULE, p_fiber);        
            return LCM_E_SUCCESS;
        }
        else /*If continue error to max times, not try.*/
        {            
            LCM_LOG_WARN("Fiber port: access fail, creat unknown type.");
        }
    }
    if(p_fiber->channel_num == 1)
    {
        p_fiber->channel_idx = FIBER_CURRENT_VALUE1;
    }
    else if(p_fiber->channel_num > 1)
    {
        if(pannel_subport)
        {
            p_fiber->channel_idx = pannel_subport-1;
        }
        else
        {
            p_fiber->channel_idx = FIBER_VAL_TYPE_MAX2;
        }
    }

    p_port->fiber_access_err_cnt = 0;
    fiber_type = p_fiber->fiber_type;
    param.is_combo = p_port->is_combo;
    param.cfg_media = p_port->port_cfg.media;
    param.fiber_type = fiber_type;
    param.linkup_media = p_port->port_status.linkup_media;
    p_port->phy_type = lcm_port_get_phy_type(&param);    
    p_port->p_fiber = p_fiber;

    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Port %d insert fiber type %d", port_id, fiber_type);
    if(fiber_type == GLB_PHY_TYPE_1000BASE_T_SFP)
    {
        /*bug33648, jqiu 2015-06-02. for copper sfp insert, los status always change to 0.*/
        phy_save_los_info(port_id, 0);
        /*When copper SFP insert, must set fiber enable, then can access internal phy. If internal need managed, will 
          attach new phy, and keep fiber enable until remove, if internal phy needn't be managed, will roll back fiber 
          enable in lcm_port_copper_sfp_init.*/
        ret = fiber_set_enable(port_id, 1);
        /*If current port is disable, after set fiber enable, need wait a while for SFP power on to access Copper SFP phy*/
        if(p_port->port_cfg.enable == 0)
        {
            /* sleep 500ms for sfp ready */
            usleep(500000);
        }
        lcm_port_copper_sfp_init((void *)p_port);
    }
    else
    {
        /*bug32802, here remove this because lcm_fiber_port_status_timer can do it.*/
        /*if(p_port->port_cfg.enable == 0)
        {
            fiber_set_enable(port_id, 0);
        }*/
        ret = lcm_port_update_medium(port_id, p_port->port_cfg.media, p_port->port_cfg.speed);
    }
    /*bug33195. 28G serdes need change rx peaking for DAC or Optical.*/
#ifdef GOLDENGATE
    if(fiber_is_direct_attach_cable(p_fiber))
    {
        /*bug33195. When DAC insert, rx_peaking adjust, this only used for 28G serdes.*/           
        lcm_port_update_rx_peaking(p_port);
        /*bug33637. When DAC insert, use AP FFE*/
        lcm_port_update_ffe(p_port);
    }
#endif
    lcm_notify_fiber_info(p_port, LCM_FIBER_INSERT);


    /*add fiber lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_fiber_event)
    {
        sal_memset(&lai_fiber, 0, sizeof(lai_fiber));
        oid = (p_port->port_idx - 1) + (p_card->phy_slot_no << 16);
        ctc_lai_get_fiber_info(oid, &lai_fiber);
        
        p_lai_card_noti->on_fiber_event(LAI_FIBER_EVENT_ADD, &lai_fiber);
    }
        
    return LCM_E_SUCCESS;
}

int32 lcm_port_destroy_fiber(glb_port_t* p_port)
{
    int32 ret;
    uint32 port_id;
    glb_phy_type_t fiber_type;
    lcm_port_get_phy_type_param_t param;
    uint8 need_update=0;

    lai_fiber_info_t lai_fiber;
    lai_object_id_t oid = 0;
    glb_card_t* p_card = NULL; 

    p_card= lcm_mgt_get_card();
    
    if(NULL == p_port || NULL == p_card)
    {
        return LCM_E_INVALID_PARAM;
    }
    
    port_id = p_port->port_idx - 1;
    fiber_type = ((fiber_info_t*)(p_port->p_fiber))->fiber_type;
    param.is_combo = p_port->is_combo;
    param.cfg_media = p_port->port_cfg.media;
    param.fiber_type = GLB_PHY_TYPE_UNKNOWN; /*after destroy fiber, it is unknown*/
    param.linkup_media = p_port->port_status.linkup_media;
    p_port->phy_type = lcm_port_get_phy_type(&param);
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Port %d remove fiber type %d", port_id, fiber_type);

    if(fiber_is_direct_attach_cable((fiber_info_t*)(p_port->p_fiber)))
    {
        need_update = 1;        
    }    
    
    if(p_port->p_fiber)
    {
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, p_port->p_fiber);
    }
    p_port->p_fiber = NULL;    
    lcm_port_copper_sfp_remove(p_port);
    ret = lcm_port_update_medium(port_id, p_port->port_cfg.media, p_port->port_cfg.speed);
    if(ret != LCM_E_SUCCESS)
    {
        LCM_LOG_ERR("port %d update medium error %d when remove sfp speed %d media %d.", 
            port_id, ret, p_port->port_cfg.speed, p_port->port_cfg.media);
    }
#ifdef GOLDENGATE
    if(need_update)
    {
        /*bug33195. When DAC remove, rx_peaking adjust, this only used for 28G serdes.*/           
        lcm_port_update_rx_peaking(p_port);
        /*bug33637. When DAC remove, return to SUM FFE*/
        lcm_port_update_ffe(p_port);
    }
#endif
    lcm_notify_fiber_info(p_port, LCM_FIBER_REMOVE);

    /*add fiber lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_fiber_event)
    {
        sal_memset(&lai_fiber, 0, sizeof(lai_fiber));
        oid = (p_port->port_idx - 1) + (p_card->phy_slot_no << 16);
        ctc_lai_get_fiber_info(oid, &lai_fiber);
        
        p_lai_card_noti->on_fiber_event(LAI_FIBER_EVENT_DELETE, &lai_fiber);
    }

    return LCM_E_SUCCESS;
}
/************************************************************************
 Fiber scan task:
 *** For fiber insert event: 
 ******Fiber must be in present for FIBER_MODULE_SCAN_TIME rounds, then believe it is present;
 ******Every round only scan FIBER_MODULE_SCAN_NUM_ONE_ROUND fiber insert event;
 *** For fiber remove event:
 ******Every round scan all of fiber remove event;
 *** For fiber DDM info update:
 ******Every round only update FIBER_MODULE_UPDATE_NUM_ONE_ROUND fiber DDM info;
 *************************************************************************/
//int32 lcm_fiber_port_status_timer(thread_t* p_arg)
int32 lcm_fiber_port_status_timer()
{
    //CTC_TASK_GET_MASTER
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    int32 port_id, ret = 0;
    uint8 present_status;
    uint8 fiber_scan_number=0;
    uint8 fiber_update_number=0, fiber_update_port_id_old;
    static uint8 fiber_update_port_id;
    lcm_clnt_t *p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();

    //CTC_TASK_ADD_TIME_MSEC(lcm_fiber_port_status_timer, NULL, FIBER_MODULE_SCAN_TIME);

    if(lcm_mgt_get_bypass_timers())
        return LCM_E_SUCCESS;

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    fiber_update_port_id_old = fiber_update_port_id;
    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];
        /*modified by xgu for bug 13493, 2011-01-11*/        
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d not create.", port_id+1);
            continue;
        }
        /*bug32802, move all fiber operation in this thread.*/
        /*1. process present event*/
        ret = fiber_get_present(port_id, &present_status);
        /*Fix bug 14685. jqiu 2011-05-23. if return error, this port doesn't support fiber.*/
        if(ret == RESULT_ERROR)
        {
            continue;
        }
        if((present_status==FIBER_PRESENT) &&(NULL == p_port->p_fiber))
        {
            /*Bug17183. In one round, scan MAX fiber module*/
            if(fiber_scan_number < FIBER_MODULE_SCAN_NUM_ONE_ROUND)
            {
                LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d create sfp.", port_id+1);
                lcm_port_create_fiber(p_port);
                fiber_scan_number++;
            }
        }
        else if((present_status != FIBER_PRESENT) && (NULL != p_port->p_fiber))
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d destroy sfp.", port_id+1);
            lcm_port_destroy_fiber(p_port);
        }
        
        /*3. process tx_disable event*/
        /*if SFP is Copper SFP, and attach new phy, not set tx_disable, keep it tx enable always.*/
        if(phy_check_attach_phy(port_id))
        {
            //Do nothing
        }
        else
        {
            fiber_set_enable(port_id, p_port->port_cfg.enable);
        }
        

        /*4. process DDM event*/
        /*Bug17183. In one round, update MAX fiber module*/
        if(fiber_update_number >= FIBER_MODULE_UPDATE_NUM_ONE_ROUND)
            continue;
        /*Bug17183. In one round, store last update port id.*/
        if(port_id < fiber_update_port_id_old)
            continue;
        fiber_update_port_id = port_id+1;
        if(p_port->p_fiber)
        {
            /*If fiber doesn't support DDM, continue*/
            if(check_fiber_support_ddm(p_port->p_fiber) == 0)
                continue;
            fiber_update_number++;
            ret = fiber_update_state(port_id, p_port->p_fiber);
            if((ret == 0)&&(p_lcm_clnt != NULL))
            {
                lcm_msg_tx_lcFiberUpdate(p_lcm_clnt, p_port);
            }
            else
            {
                LCM_LOG_ERR("UPDATE DDM   fail.");
            }
        }  
    }
    if(fiber_update_port_id >= p_card->port_num)
    {
        fiber_update_port_id = 0;
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_port_get_port_range(glb_card_t* p_card, int32 phy_intr_stat, int32* start, int32* end)
{
    int32 phy_int_bit_no;
    
    *start = 1;
    *end = p_card->port_num;
    
    if(NULL == p_card->p_port_range)
    {
        return LCM_E_SUCCESS;   
    }

    for(phy_int_bit_no = 0; phy_int_bit_no < p_card->phy_int_bit_num; phy_int_bit_no++)
    {
        if(p_card->p_port_range[phy_int_bit_no].port_end < p_card->p_port_range[phy_int_bit_no].port_start)
        {
            continue;
        }
        if(phy_intr_stat & (0x1<<phy_int_bit_no))
        {
            continue;
        }
        else
        {
            *start = p_card->p_port_range[phy_int_bit_no].port_start;
            *end = p_card->p_port_range[phy_int_bit_no].port_end;
            /*modified by jqiu for optimize, when found 1 port range, just return to process.*/
            return LCM_E_SUCCESS;
        }
    }
    
    return LCM_E_SUCCESS;
}

/* Added by liuht for bug 34540, 2015-09-09 */
static int32
_lcm_port_mgt_led_mode(glb_port_t* p_port)
{
    mac_led_api_para_t port_led;

    if(GLB_PORT_LED_MODE_CHANGE_SFP_TWO_LED == p_port->port_led_mode_change)
    {
        if(p_port->port_status.link_up)
        {
            if(p_port->port_cfg.media == GLB_PORT_TYPE_COPPER)
            {
                if(p_port->port_status.speed == GLB_SPEED_1G)
                {
                    port_led.mode = LED_MODE_2_OFF_RXLNKBIACT;
                }
                else
                {
                    port_led.mode = LED_MODE_2_RXLNKBIACT_OFF;
                }
            }
            else
            {
                if(p_port->port_status.speed == GLB_SPEED_10G)
                {
                    port_led.mode = LED_MODE_2_OFF_RXLNKBIACT;
                }
                else
                {
                    port_led.mode = LED_MODE_2_RXLNKBIACT_OFF;
                }
            }
        }
        else
        {
            port_led.mode = LED_MODE_2_FORCE_OFF;
        }
    }
    else if(GLB_PORT_LED_MODE_CHANGE_QSFP_ONE_LED == p_port->port_led_mode_change)
    {
        if(p_port->port_status.link_up)
        {
            port_led.mode = LED_MODE_1_RXLNK_BIACT;
        }
        else
        {
            port_led.mode = LED_MODE_1_FORCE_OFF;
        }
    }
    else if(GLB_PORT_LED_MODE_CHANGE_QSFP_TWO_LED == p_port->port_led_mode_change)
    {
        if(p_port->port_status.link_up)
        {
            if((p_port->port_status.speed == GLB_SPEED_40G) || ((p_port->port_status.speed == GLB_SPEED_100G)))
            {
                port_led.mode = LED_MODE_2_OFF_RXLNKBIACT;
            }
            else
            {
                port_led.mode = LED_MODE_2_RXLNKBIACT_OFF;
            }
        }
        else
        {
            port_led.mode = LED_MODE_2_FORCE_OFF;
        }
    }

    if(GLB_PORT_LED_MODE_CHANGE_UNSUPPORT != p_port->port_led_mode_change)
    {
        port_led.port_id = (p_port->glb_chip_idx<<8) | p_port->port_led_mac;
        port_led.lchip   = p_port->local_chip_idx;
        port_led.ctl_id  = p_port->ctl_id;

        if(led_cfg_port_mode(&port_led))
        {
            LCM_LOG_ERR("Lcm set mac %d led mode %d fail.", port_led.port_id, port_led.mode);
        }
        else
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set mac %d led mode %d.", port_led.port_id, port_led.mode);
        }
    }
    
    return 0;
}
int32
_lcm_port_link_change_process(uint8 port_idx, glb_phy_state_t* phy_val, phy_state_change_t* phy_change)
{
    int32 ret = 0;
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    lcm_port_get_phy_type_param_t param;
    lcapi_hagt_set_mac_en_t lcapi_hagt_set_mac_en;
    lcapi_hagt_set_mac_speed_t lcapi_hagt_set_mac_speed;
    lcapi_hagt_set_mac_flowctrl_t lcapi_hagt_set_mac_flowctrl;
    lcapi_hagt_set_mac_eee_t lcapi_hagt_set_mac_eee;
    lcapi_hagt_update_stack_port_t port_info;
    lcapi_hagt_set_force_tx_en_t lcapi_hagt_set_force_tx_en;
    /* modified by yaom for 10G remote fault 20140410 */
    bool is_error = FALSE;
    lcapi_lcm_get_remote_fault_status_t remote_fault_status;
    lcapi_lcm_port_info_t panel_port_info;
#ifdef GOLDENGATE
    lcm_clnt_t *clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    lcapi_hagt_set_3ap_training_t train_cfg;
#endif

    sal_memset(&lcapi_hagt_set_mac_en, 0, sizeof(lcapi_hagt_set_mac_en));

    p_card= lcm_mgt_get_card();
    p_port = p_card->pp_port[port_idx - 1];
    
    /*Link change or speed/duplex change(this may happen when too many port status change) fix bug 14722*/            
    if((-1 != phy_change->action)||(1 == phy_change->speed_change)
        ||(1==phy_change->duplex_change)||(1==phy_change->media_change)
        ||(1 == phy_change->flowctrl_change) ||(1 == phy_change->master_slave_change)
        ||(1 == phy_change->eee_status_change))
    {
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d link change action %d speed %d duplex %d media %d flowctrl %d mode %d eee status %d", 
            port_idx, phy_change->action, phy_change->speed_change, phy_change->duplex_change, phy_change->media_change, 
            phy_change->flowctrl_change, phy_change->master_slave_change, phy_change->eee_status_change);
        if(p_port->p_fiber)
        {
            param.fiber_type = ((fiber_info_t *)(p_port->p_fiber))->fiber_type;
        }
        else
        {
            param.fiber_type = GLB_PHY_TYPE_UNKNOWN;
        }
        param.is_combo = p_port->is_combo;
        param.cfg_media = p_port->port_cfg.media;
        param.linkup_media = phy_val->linkup_media;
        p_port->phy_type = lcm_port_get_phy_type(&param);
        p_port->port_status.link_up = phy_val->link_up;
        /* Modified by liuht for bug 28155, 2014-04-17 */
        /* Support force master or slave mode */
        p_port->master_slave = phy_val->master_slave;
        /* End of liuht modified */

        p_port->port_status.speed = phy_val->speed;
        p_port->port_status.duplex = phy_val->duplex;
        p_port->port_status.flowctrl.send = phy_val->flowctrl.send;
        p_port->port_status.flowctrl.recv = phy_val->flowctrl.recv;
        p_port->port_status.linkup_media = phy_val->linkup_media;  
        /* Modified by liuht to support eee for bug 28298, 2014-05-16 */
        p_port->port_status.eee_status.status= phy_val->eee_status.status;
        p_port->port_status.eee_status.wake_error_count= phy_val->eee_status.wake_error_count;
        /* End of liuht modified */
        /* Modified by liuht for bug 29005, 2014-06-17 */
        if(-1 != phy_change->action)
        {
            phy_change->link_change = 1;
        }
        else
        {
            phy_change->link_change = 0;
        }
        p_port->port_status.port_status_change = GLB_PORT_STATUS_CHANGE(phy_change);
        /* End of liuht modified */
#ifdef GOLDENGATE
        /*bug33278 support 802.3AP. when training ok, link change to down cause DAC train state go to dis(init state).*/
        if((phy_val->link_up == 0)&&(p_port->dac_train_flag == CTC_PORT_3AP_TRAINING_DONE))
        {
            train_cfg.gport = ((p_port->glb_chip_idx<<8) | p_port->logic_port_idx);
            train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_DIS;
            //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);

            {
            uint32 cfg_flag;
            cfg_flag = train_cfg.cfg_flag;
            ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
            }
    
            
            /* Notify chsm when status update*/
            lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC disable training for link change", port_idx);
            p_port->dac_train_flag = CTC_PORT_3AP_TRAINING_DIS;
        }   
#endif
    }
    else
    {
        /*No change*/
        return 0;
    }

    _lcm_port_mgt_led_mode(p_port);

    /*If this port has no phy and has no attach phy, needn't config mac enable, just need cfg flowctrl*/
    if(phy_check_no_phy(port_idx-1) && !phy_check_attach_phy(port_idx-1))
    {
        /* modified by yaom for 10G remote fault 20140410 */
        if (GLB_SUPPORT_SPEED_10G != p_port->port_speed_ability)
        {
            /*Only do flow control update when port is up.*/
            if((p_port->port_status.link_up)&&(1 == phy_change->flowctrl_change))
            {
                sal_memcpy(&lcapi_hagt_set_mac_flowctrl.flowctrl, &phy_val->flowctrl, sizeof(glb_port_flowctrl_t));
                lcapi_hagt_set_mac_flowctrl.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;

                //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_FLOWCNTRL, &lcapi_hagt_set_mac_flowctrl);
                ret = lcm_set_mac_flowcntrl(&lcapi_hagt_set_mac_flowctrl);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d mac flow control send %d receive %d fail.", 
                                lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send,
                                phy_val->flowctrl.recv);
                    return 0;
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set gport %d mac flow control send %d receive %d.",
                            lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send,phy_val->flowctrl.recv);
                }
            }
        }
        else
        {
            #if 0 /* mac enable is done in PHY enable */
            /* MAC of 10G should be always enabled as long as not shutdown */
            if (!p_port->mac_enable)
            {
                lcapi_hagt_set_mac_en.flag = GLB_LINK_UP;
                lcapi_hagt_set_mac_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
                ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_EN, &lcapi_hagt_set_mac_en);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d mac en flag %d fail.", 
                                lcapi_hagt_set_mac_en.gport, phy_val->link_up);
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac en flag %d.", 
                                lcapi_hagt_set_mac_en.gport, phy_val->link_up); 
                }                
                p_port->force_tx_status = FALSE;
                p_port->mac_enable = TRUE;
            }
            #endif

            /* update remote fault status */
            remote_fault_status.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
            remote_fault_status.is_error = &is_error;
           // ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_GET_REMOTE_FAULT_STATUS, &remote_fault_status);
            if(ret < 0)
            {
                LCM_LOG_ERR("Lcm get 10G port %d remote fault fail.", remote_fault_status.gport);
            }
            p_port->remote_fault_status = (uint8)is_error;

            /* need to set force tx when in remote fault state or down state, so MAC can flush pkts. Otherwise, unset force_tx */
            if (!p_port->port_status.link_up || p_port->remote_fault_status)
            {
                /* mac will be disabled and enabled in force_tx set API */
                lcapi_hagt_set_force_tx_en.flag = TRUE;
            }
            else
            {
                lcapi_hagt_set_force_tx_en.flag = FALSE;
            }

            /* avoid unnesessary mac disable/enable in force_tx setting */
            if (lcapi_hagt_set_force_tx_en.flag != p_port->force_tx_status)
            {
                lcapi_hagt_set_force_tx_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
               // ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_FORCE_TX_EN, &lcapi_hagt_set_force_tx_en);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d force tx flag %d fail.", 
                                lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set gport %d force tx flag %d.", 
                                lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                }
                p_port->force_tx_status = lcapi_hagt_set_force_tx_en.flag;
            }
            
            /* set flow ctrl when link up && no remote fault */
            /*Only do flow control update when port is up.*/
            if(p_port->port_status.link_up && !p_port->remote_fault_status &&(1 == phy_change->flowctrl_change))
            {
                sal_memcpy(&lcapi_hagt_set_mac_flowctrl.flowctrl, &phy_val->flowctrl, sizeof(glb_port_flowctrl_t));
                lcapi_hagt_set_mac_flowctrl.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;

                //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_FLOWCNTRL, &lcapi_hagt_set_mac_flowctrl);
                ret = lcm_set_mac_flowcntrl(&lcapi_hagt_set_mac_flowctrl);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d mac flow control send %d receive %d fail.", 
                                lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send,
                                phy_val->flowctrl.recv);
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set gport %d mac flow control send %d receive %d.",
                            lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send,phy_val->flowctrl.recv);
                }
            }
        }
    }
    else
    {
        /* Modified by liuht to support eee for bug 28298, 2014-05-16 */
        lcapi_hagt_set_mac_eee.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
        lcapi_hagt_set_mac_eee.eee_capability = phy_val->eee_status.status& 0xff;
        if(1 == phy_change->eee_status_change)
        {
            if((phy_val->eee_status.status >> 16) & lcapi_hagt_set_mac_eee.eee_capability)
            {
                lcapi_hagt_set_mac_eee.eee_capability = 1;
            }
            else
            {
                lcapi_hagt_set_mac_eee.eee_capability = 0;
            }
            
           // ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_EEE_CAPABILITY, &lcapi_hagt_set_mac_eee);
            if(ret < 0)
            {
                LCM_LOG_ERR("Lcm set gport %d mac eee capability %d fail.", 
                    lcapi_hagt_set_mac_eee.gport, lcapi_hagt_set_mac_eee.eee_capability);
                return 0;
            }
            else
            {
                LCM_LOG_ERR("Lcm set gport %d mac eee capability %d.", 
                    lcapi_hagt_set_mac_eee.gport, lcapi_hagt_set_mac_eee.eee_capability);
            }
        }
        /* End of liuht modified */

        if (GLB_SUPPORT_SPEED_10G != p_port->port_speed_ability)
        {
            lcapi_hagt_set_mac_en.flag = phy_val->link_up;
            lcapi_hagt_set_mac_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
            if(p_port->port_status.link_up)
            {
                if (-1 != phy_change->action)
                {
                    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_EN, &lcapi_hagt_set_mac_en);
                    ret = ctc_port_set_mac_en(lcapi_hagt_set_mac_en.gport, lcapi_hagt_set_mac_en.flag);    
                    
                    if(ret < 0)
                    {
                        LCM_LOG_ERR("Lcm set gport %d mac en flag %d fail.", 
                                    lcapi_hagt_set_mac_en.gport, phy_val->link_up);
                        return 0;
                    }
                    else
                    {
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac en flag %d.", 
                                    lcapi_hagt_set_mac_en.gport, phy_val->link_up); 
                    }                
                }

                lcapi_hagt_set_mac_speed.speed_mode = phy_val->speed;
                lcapi_hagt_set_mac_speed.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;

                /* Modified by liuht for bug 29005, 2014-06-17 */
                if((-1 != phy_change->action)||(1 == phy_change->speed_change)
                    ||(1==phy_change->duplex_change)||(1==phy_change->media_change)
                    ||(1 == phy_change->flowctrl_change))
                {
                    /*Bug 30260, 30299. For 10G port, sdk not support to cfg speed. jqiu 2014-11-18*/
                    if((p_port->port_speed_ability & GLB_SUPPORT_SPEED_10G) == 0)
                    {
                        //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_SPEED, &lcapi_hagt_set_mac_speed);
                        ret = lcm_set_mac_speed(&lcapi_hagt_set_mac_speed);
                        if(ret < 0)
                        {
                            LCM_LOG_ERR("Lcm set gport %d mac speed %d fail.", 
                                        lcapi_hagt_set_mac_speed.gport, phy_val->speed);
                            return 0;
                        }
                        else
                        {
                            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac speed %d.", 
                                            lcapi_hagt_set_mac_en.gport, phy_val->speed); 
                        }
                    }
                }
                /* End of liuht modified */

                sal_memcpy(&lcapi_hagt_set_mac_flowctrl.flowctrl, &phy_val->flowctrl, sizeof(glb_port_flowctrl_t));
                lcapi_hagt_set_mac_flowctrl.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;

                if(1 == phy_change->flowctrl_change)
                {
                    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_FLOWCNTRL, &lcapi_hagt_set_mac_flowctrl);
                    ret = lcm_set_mac_flowcntrl(&lcapi_hagt_set_mac_flowctrl);
                    if(ret < 0)
                    {
                        LCM_LOG_ERR("Lcm set gport %d mac flow control send %d receive %d fail.", 
                                    lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send,
                                    phy_val->flowctrl.recv);
                        return 0;
                    }
                    else
                    {
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac flow control send %d receive %d.", 
                                    lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send, phy_val->flowctrl.recv);
                    }
                }
            }
            else
            {
                //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_EN, &lcapi_hagt_set_mac_en);
                ret = ctc_port_set_mac_en(lcapi_hagt_set_mac_en.gport, lcapi_hagt_set_mac_en.flag);    
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d mac en flag %d fail.", 
                                lcapi_hagt_set_mac_en.gport, phy_val->link_up);
                    return 0;
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac en flag %d.",
                                lcapi_hagt_set_mac_en.gport, phy_val->link_up);
                }
            }
        }
        else
        {
            #if 0 /* mac enable is done in PHY enable */
            /* MAC of 10G should be always enabled as long as not shutdown */
            if (!p_port->mac_enable)
            {
                lcapi_hagt_set_mac_en.flag = GLB_LINK_UP;
                lcapi_hagt_set_mac_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
                ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_EN, &lcapi_hagt_set_mac_en);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d mac en flag %d fail.", 
                                lcapi_hagt_set_mac_en.gport, phy_val->link_up);
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac en flag %d.", 
                                lcapi_hagt_set_mac_en.gport, phy_val->link_up); 
                }                
                p_port->force_tx_status = FALSE;
            }
            #endif

            /* update remote fault status */
            remote_fault_status.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
            remote_fault_status.is_error = &is_error;
          //  ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_GET_REMOTE_FAULT_STATUS, &remote_fault_status);
            if(ret < 0)
            {
                LCM_LOG_ERR("Lcm get 10G port %d remote fault fail.", remote_fault_status.gport);
            }
            p_port->remote_fault_status = (uint8)is_error;

            /* need to set force tx when in remote fault state or down state, so MAC can flush pkts. Otherwise, unset force_tx */
            if (!p_port->port_status.link_up || p_port->remote_fault_status)
            {
                /* mac will be disabled and enabled in force_tx set API */
                lcapi_hagt_set_force_tx_en.flag = TRUE;
            }
            else
            {
                lcapi_hagt_set_force_tx_en.flag = FALSE;
            }

            /* avoid unnesessary mac disable/enable in force_tx setting */
            if (lcapi_hagt_set_force_tx_en.flag != p_port->force_tx_status)
            {
                lcapi_hagt_set_force_tx_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
               // ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_FORCE_TX_EN, &lcapi_hagt_set_force_tx_en);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d force tx flag %d fail.", 
                                lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set gport %d force tx flag %d.", 
                                  lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                }
                p_port->force_tx_status = lcapi_hagt_set_force_tx_en.flag;
            }
            
            /* set flow ctrl when link up && no remote fault */
            /*Only do flow control update when port is up.*/
            if(p_port->port_status.link_up && !p_port->remote_fault_status)
            {
                lcapi_hagt_set_mac_speed.speed_mode = phy_val->speed;
                lcapi_hagt_set_mac_speed.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
                //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_SPEED, &lcapi_hagt_set_mac_speed);
                ret = lcm_set_mac_speed(&lcapi_hagt_set_mac_speed);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm set gport %d mac speed %d fail.", 
                                lcapi_hagt_set_mac_speed.gport, phy_val->speed);
                }
                else
                {
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac speed %d.", 
                                  lcapi_hagt_set_mac_en.gport, phy_val->speed); 
                }

                if(1 == phy_change->flowctrl_change)
                {
                    sal_memcpy(&lcapi_hagt_set_mac_flowctrl.flowctrl, &phy_val->flowctrl, sizeof(glb_port_flowctrl_t));
                    lcapi_hagt_set_mac_flowctrl.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
                    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_MAC_FLOWCNTRL, &lcapi_hagt_set_mac_flowctrl);
                    ret = lcm_set_mac_flowcntrl(&lcapi_hagt_set_mac_flowctrl);
                    if(ret < 0)
                    {
                        LCM_LOG_ERR("Lcm set gport %d mac flow control send %d receive %d fail.", 
                                    lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send,
                                    phy_val->flowctrl.recv);
                    }
                    else
                    {
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,"Lcm set gport %d mac flow control send %d receive %d.", 
                                    lcapi_hagt_set_mac_flowctrl.gport, phy_val->flowctrl.send, phy_val->flowctrl.recv);
                    }
                }
            }
        }
    }
    
    /* Update new link status. */
    panel_port_info.port_no = p_port->panel_port_no;
    panel_port_info.sub_port_no = p_port->panel_sub_port_no;
    panel_port_info.slot_no= p_port->panel_slot_no;
    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_LINK_STATUS, &panel_port_info);
    ret = lcm_port_notify_port_status(&panel_port_info);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm update port idx %d status fail.", port_idx);
        return 0;
    }

    /* Modified by Percy Wang for bug 25588, 2013-11-12 */
    if (lcm_mgt_is_enable_stack() && (-1 != phy_change->action))
    {
        port_info.gport = GLB_TRANS_PORTID_TO_GPORT(p_port->glb_chip_idx, p_port->logic_port_idx);
        port_info.linkup = p_port->port_status.link_up;
        LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_STACK_PORT, &port_info);
    }
    
    return 0;
}
/***************************************************/
/*              DAC training function                    */
/*Only 10G/40G/100G port support this function.          */
/*Only DAC need this training process.                   */
/* Enable->Init->done->check done return--Y-->OK         */
/*   ^______________N______|                             */
/* Bug33278, support 802.3AP                             */ 
/***************************************************/
int32
_lcm_port_3AP_training_process(uint8 port_idx)
{
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;    
    lcapi_hagt_set_3ap_training_t train_cfg;
    lcm_clnt_t *clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    int32 ret = 0;
    
    p_card= lcm_mgt_get_card();
    p_port = p_card->pp_port[port_idx - 1];

    if(!(p_port->ap_enable))
    {
        /*If now port change to disable 802.3AP, and port is in 802.3AP status, need to disable it.*/
        if(p_port->dac_train_flag != CTC_PORT_3AP_TRAINING_DIS)
        {
            train_cfg.gport = ((p_port->glb_chip_idx<<8) | p_port->logic_port_idx);
            train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_DIS;
            //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);

            {
            uint32 cfg_flag;
            cfg_flag = train_cfg.cfg_flag;
            ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
            }

            p_port->dac_train_flag = CTC_PORT_3AP_TRAINING_DIS;
            /* Notify chsm when status update*/
            lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC disable training for not enable", port_idx);
        }
        return LCM_E_SUCCESS;
    }
    
    /*For 10G/40G/100G port insert DAC, start training */
    if((p_port->port_speed_ability & (GLB_SUPPORT_SPEED_10G|GLB_SUPPORT_SPEED_40G|GLB_SUPPORT_SPEED_100G)) != 0)
    {
        train_cfg.gport = ((p_port->glb_chip_idx<<8) | p_port->logic_port_idx);
        if(p_port->p_fiber)
        {
            if(fiber_is_direct_attach_cable((fiber_info_t*)(p_port->p_fiber)))
            {
                if(p_port->dac_train_flag == CTC_PORT_3AP_TRAINING_DIS)
                {
                    train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_EN;
                    //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);

                    {
                    uint32 cfg_flag;
                    cfg_flag = train_cfg.cfg_flag;
                    ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                    }

                    train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_INIT;
                    //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);

                    {
                    uint32 cfg_flag;
                    cfg_flag = train_cfg.cfg_flag;
                    ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                    }   
                    
                    p_port->dac_train_flag = CTC_PORT_3AP_TRAINING_INIT;
                    /* Notify chsm when status update*/
                    lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC start training", port_idx);
                }
                else if(p_port->dac_train_flag == CTC_PORT_3AP_TRAINING_INIT)
                {
                    train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_DONE;
                    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);

        
                    {
                    uint32 cfg_flag;
                    cfg_flag = train_cfg.cfg_flag;
                    ret = ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                    }
                    
                    //if((ret == CTC_E_INVALID_EXP_VALUE)||(ret == CTC_E_TRAININT_FAIL))
                    if(ret == CTC_E_INVALID_EXP_VALUE)
                    {
                        train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_EN;
                        //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);


                        {
                        uint32 cfg_flag;
                        cfg_flag = train_cfg.cfg_flag;
                        ret = ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                        }
                        
                        
                        train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_INIT;
                        //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);


                         {
                         uint32 cfg_flag;
                         cfg_flag = train_cfg.cfg_flag;
                         ret = ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                         }
                        
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC training fail, re-train", port_idx);
                    }
                    else if(ret == CTC_E_TRAININT_FAIL)
                    {
                        train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_INIT;
                        //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);


                        {
                        uint32 cfg_flag;
                        cfg_flag = train_cfg.cfg_flag;
                        ret = ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                        }
                        
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC training fail, re-train", port_idx);
                    }
                    else if(ret == CTC_E_NONE)
                    {
                        p_port->dac_train_flag = CTC_PORT_3AP_TRAINING_DONE;
                        log_sys(M_MOD_LCM, E_WARNING,"port %d DAC training success", port_idx);
                        //LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC training success", port_idx);
                        /* Notify chsm when status update*/
                        lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
                    }
                    else
                    {
                        log_sys(M_MOD_LCM, E_WARNING,"port %d DAC training return %d", port_idx, ret);
                    }
                }
            }
            else
            {
                if(p_port->dac_train_flag != CTC_PORT_3AP_TRAINING_DIS)
                {
                    train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_DIS;
                    //LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);


                    {
                    uint32 cfg_flag;
                    cfg_flag = train_cfg.cfg_flag;
                    ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                    }

                    p_port->dac_train_flag = CTC_PORT_3AP_TRAINING_DIS;
                    /* Notify chsm when status update*/
                    lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
                    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC disable training for optical", port_idx);
                }
            }
        }
        else
        {
            if(p_port->dac_train_flag != CTC_PORT_3AP_TRAINING_DIS)
            {
                train_cfg.cfg_flag = CTC_PORT_3AP_TRAINING_DIS;
               // LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_3AP_TRAINING, &train_cfg);


                {
                uint32 cfg_flag;
                cfg_flag = train_cfg.cfg_flag;
                ret = ctc_port_set_property(train_cfg.gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);
                }
               
                p_port->dac_train_flag = CTC_PORT_3AP_TRAINING_DIS;
                /* Notify chsm when status update*/
                lcm_msg_tx_lcchsm8023APStatus(clnt, p_port);
                LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "port %d DAC disable training for no DAC", port_idx);
            }
        }
    }    
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_status_intr 
 * Purpose      : handle interrupt caused by port stauts change          
 * Input        : N/A         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_port_status_intr (void)
{
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    glb_phy_state_t phy_val;    
    phy_state_change_t phy_change;
    uint8 port_idx;
    int32 ret;
    int32 phy_intr_stat = 0xff;
    int32 start_port = 0;
    int32 end_port = 0;
    
    
    /*get local line card*/
    p_card= lcm_mgt_get_card();
    if(NULL == p_card)
    {
        LCM_LOG_ERR("Pointer to card is invalid.");
        return LCM_E_INVALID_PTR;
    }

    ret = hw_get_ctc_hw_int(&phy_intr_stat);
    if(ret < 0)
    {
        LCM_LOG_ERR("Get the phy interrupt status failed.");
        return ret;
    }
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port phy intr status %x\n", phy_intr_stat);
    _lcm_port_get_port_range(p_card, phy_intr_stat, &start_port, &end_port);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Get port range, from %d to %d\n", start_port, end_port);
    for(port_idx = start_port; port_idx <= end_port; port_idx++)
    {
        p_port = p_card->pp_port[port_idx - 1];

        /*modified by xgu for bug 13493, 2011-01-11*/        
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d not create.", port_idx);
            continue;
        }
        
        memset(&phy_val,0,sizeof(glb_phy_state_t));
        memset(&phy_change,0,sizeof(phy_state_change_t));

        if(phy_get_link_interrupt(port_idx - 1, &phy_val, &phy_change))
        {
            /*get interrupt status Error*/
            continue;
        }           
        _lcm_port_link_change_process(port_idx, &phy_val, &phy_change);
    }

    if(p_card->phy_interrupt_mode == GLB_PHY_INTERRUPT_MODE_FPGA)
    {
        fpga_cfg_phy_interrupt_mask(0);
    }

    else if(p_card->phy_interrupt_mode == GLB_PHY_INTERRUPT_MODE_EPLD)
    {
        /* add 'is_gbdemo' flag for some features that gbdemo board owns only, added by qicx, 2013-07-08 */
        /* fix bug 24090, cr7223, qicx, 2013-08-15 */
        epld_cfg_phy_interrupt_mask(0, p_card->is_gbdemo);
    }

    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_port_status_timer 
 * Purpose      : update port status for speed, duplex and media type          
 * Input        : N/A         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
void
lcm_port_port_status_timer (void* p_data)
{
    CTC_TASK_GET_MASTER
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    glb_phy_state_t phy_val;
    phy_state_change_t phy_change;
    uint8 port_idx;

    /* modify default port timer interval from 3s to 1s, qicx, 2013-12-18 */
    CTC_TASK_ADD_TIME_MSEC(lcm_port_port_status_timer, NULL, 1000);

    if(lcm_mgt_get_bypass_timers())
        return;
    
    g_port_timer_cnt++;
    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    for(port_idx = 1; port_idx <= p_card->port_num; port_idx++)
    {
        p_port = p_card->pp_port[port_idx - 1];
        /*modified by xgu for bug 13493, 2011-01-11*/        
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d not create.", port_idx);
            continue;
        }
#ifdef GOLDENGATE
        /*Bug33278, support 802.3AP. add polling for 40/100G port DAC training */
        _lcm_port_3AP_training_process(port_idx);
#endif
        /* added by qicx for trunk bug26437, PTN bug26201 for GB fiber port intr, 2013-12-18 */
        /* For port without phy(Interrupt by GB mac), timer interval is 1s;
           for port with phy, timer interval is 3s */
        if (0 != g_port_timer_cnt % 3)
        {
            if (!phy_check_no_phy(port_idx-1))
            {
                continue;
            }
        }
        /* end of qicx added */
        
        memset(&phy_val,0,sizeof(glb_phy_state_t));
        memset(&phy_change,0,sizeof(phy_state_change_t));

        if(phy_get_link_poll(port_idx - 1, &phy_val, &phy_change))
        {
            /*Poll Error*/
            continue;
        }
        _lcm_port_link_change_process(port_idx, &phy_val, &phy_change);
    }

    /*Add for manage l2switch port status.*/
    l2switch_mgt_port_status(0);
    return;
}

/* modified by yaom for 10G remote fault 20140410 */
/***************************************************************************************************
 * Name         : lcm_port_remote_fault_timer 
 * Purpose      : update port status for speed, duplex and media type          
 * Input        : N/A         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
void
lcm_port_remote_fault_timer (void* p_data)
{
    CTC_TASK_GET_MASTER
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    uint8 port_idx;
    int32 ret;
    lcapi_hagt_set_force_tx_en_t lcapi_hagt_set_force_tx_en;
    bool is_error = FALSE;
    bool old_error;
    lcapi_lcm_get_remote_fault_status_t remote_fault_status;
    lcapi_lcm_port_info_t panel_port_info;

    CTC_TASK_ADD_TIME_MSEC(lcm_port_remote_fault_timer, NULL, LCM_PORT_DEFAULT_REMOTE_FAULT_INTERVAL);

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    for(port_idx = 1; port_idx <= p_card->port_num; port_idx++)
    {
        p_port = p_card->pp_port[port_idx - 1];
        if(!p_port || !p_port->create_done || (GLB_SUPPORT_SPEED_10G != p_port->port_speed_ability))
        {
            continue;
        }
        /* get panel port info */
        panel_port_info.port_no = p_port->panel_port_no;
        panel_port_info.sub_port_no = p_port->panel_sub_port_no;
        panel_port_info.slot_no= p_port->panel_slot_no;
        
        remote_fault_status.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
        remote_fault_status.is_error = &is_error;
       // ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_GET_REMOTE_FAULT_STATUS, &remote_fault_status);
        if(ret < 0)
        {
            LCM_LOG_ERR("Lcm get 10G port %d remote fault fail.", remote_fault_status.gport);
            continue;
        }
        
        /* update remote fault status for port */
        old_error = p_port->remote_fault_status;
        p_port->remote_fault_status = (uint8)is_error;

        /* no need to check remote fault when link is down */
        if (!p_port->port_status.link_up)
        {
            continue;
        }
        
        /* remote fault state */
        if (is_error)
        {
            if (!old_error)
            {
                /* need to set force tx when in remote fault state, so MAC can flush pkts. Otherwise, unset force_tx */
                /* avoid unnesessary mac disable/enable in force_tx setting */
                if (!p_port->force_tx_status)
                {
                    lcapi_hagt_set_force_tx_en.flag = TRUE;
                    lcapi_hagt_set_force_tx_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
                   // ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_FORCE_TX_EN, &lcapi_hagt_set_force_tx_en);
                    if(ret < 0)
                    {
                        LCM_LOG_ERR("Lcm set gport %d force tx flag %d fail.", 
                                    lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                    }
                    else
                    {
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set gport %d force tx flag %d.", 
                                    lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                    }
                    p_port->force_tx_status = lcapi_hagt_set_force_tx_en.flag;
                }

                /* update link status */
                //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_LINK_STATUS, &panel_port_info);
                ret = lcm_port_notify_port_status(&panel_port_info);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm update port idx %d status fail.", port_idx);
                    continue;
                }

                #ifdef _GLB_MODO_REMOTE_FAULT_
                lcm_notify_remote_fault (port_idx - 1, is_error, TRUE);
                #endif
            }
        }
        else
        {
            if (old_error)
            {
                if (p_port->force_tx_status)
                {
                    lcapi_hagt_set_force_tx_en.flag = FALSE;
                    lcapi_hagt_set_force_tx_en.gport = (p_port->glb_chip_idx<<8) | p_port->logic_port_idx;
                    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_FORCE_TX_EN, &lcapi_hagt_set_force_tx_en);
                    if(ret < 0)
                    {
                        LCM_LOG_ERR("Lcm set gport %d force tx flag %d fail.", 
                                    lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                    }
                    else
                    {
                        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm set gport %d force tx flag %d.", 
                                    lcapi_hagt_set_force_tx_en.gport, lcapi_hagt_set_force_tx_en.flag);
                    }
                    p_port->force_tx_status = lcapi_hagt_set_force_tx_en.flag;
                }

                /* need to update remote fault status before update link status */
                //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_UPDATE_LINK_STATUS, &panel_port_info);
                ret = lcm_port_notify_port_status(&panel_port_info);
                if(ret < 0)
                {
                    LCM_LOG_ERR("Lcm update port idx %d status fail.", port_idx);
                    continue;
                }
                
                #ifdef _GLB_MODO_REMOTE_FAULT_
                lcm_notify_remote_fault (port_idx - 1, is_error, TRUE);
                #endif
            }
        }
    }

    return;
}

int32
lcm_poe_status_intr(void)
{
    /* LC_CHSM_GET_POE_PORT_NUM_MAX must bigger than p_card->port_num */
    #define LCM_POE_INTR_PORT_NUM_MAX 100
    lcm_clnt_t *clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    int32 port_id, ret = 0;
    glb_poe_port_stat_info_t port_info[LCM_POE_INTR_PORT_NUM_MAX];
    glb_poe_port_stat_change_t port_change[LCM_POE_INTR_PORT_NUM_MAX];
    glb_poe_sys_stat_info_t sys_info;
    glb_poe_sys_stat_change_t sys_change;
    //poe_port_intr_valid_t valid;
    int32 port_num;

    /*get local line card*/
    p_card= lcm_mgt_get_card();
    if(NULL == p_card)
    {
        LCM_LOG_ERR("Pointer to card is invalid.");
        return LCM_E_INVALID_PTR;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "LCM POE interrupt.\n");
    
    if(NULL == clnt)
    {
        LCM_LOG_ERR("LCM lcm_poe_status_intr: get lcm client failed.");
        return LCM_E_INIT_FAILED;
    }

    ret += poe_clear_intr();
    /* first: trigger POE soft clac */
    sal_memset(port_info, 0,sizeof(glb_poe_port_stat_info_t)*LCM_POE_INTR_PORT_NUM_MAX);
    sal_memset(port_change, 0,sizeof(glb_poe_port_stat_change_t)*LCM_POE_INTR_PORT_NUM_MAX);
    sal_memset(&sys_info, 0,sizeof(glb_poe_sys_stat_info_t));
    sal_memset(&sys_change, 0,sizeof(glb_poe_sys_stat_change_t));
    port_num = 0;
    //ret += poe_sys_pm_soft_calc(port_info, port_change, &sys_info, &sys_change, &port_num);
    
    if(port_num > p_card->port_num)
    {
        LCM_LOG_ERR("LCM lcm_poe_status_intr: port num not match, failed.");
        return LCM_E_INVALID_PARAM;
    }
    //sal_task_sleep(3000);
    /* update poe each port status */
    for(port_id = 0; port_id < port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];       
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d not create.", port_id+1);
            continue;
        }

        if(p_port->poe_support)
        {
            //valid = POE_PORT_INTR_INVALID;
            /* if the chip which the port belonged to has no intr, needn't to update port status */
            //ret += poe_get_port_intr(port_id, &valid);
            //if(valid == POE_PORT_INTR_INVALID)
            //{
            //    continue;
            //}
            
            //sal_memset(&port_change, 0, sizeof(glb_poe_port_stat_change_t));
            //sal_memset(&port_info, 0, sizeof(glb_poe_port_stat_info_t));
            //ret += poe_get_port_status(port_id, &port_info, &port_change);
            if(1 == port_change[port_id].admin_change || 1 == port_change[port_id].aver_consump_change || 1 == port_change[port_id].budget_change ||
                1 == port_change[port_id].class_change || 1 == port_change[port_id].cur_consump_change || 1 == port_change[port_id].oper_change ||
                1 == port_change[port_id].peak_consump_change || 1 == port_change[port_id].priority_change)
            {
                p_port->poe_port_status.admin = port_info[port_id].admin;
                p_port->poe_port_status.aver_consump = port_info[port_id].aver_consump;
                p_port->poe_port_status.budget = port_info[port_id].budget;
                p_port->poe_port_status.class = port_info[port_id].class;
                p_port->poe_port_status.cur_consump = port_info[port_id].cur_consump;
                p_port->poe_port_status.oper = port_info[port_id].oper;
                p_port->poe_port_status.peak_consump = port_info[port_id].peak_consump;
                p_port->poe_port_status.priority = port_info[port_id].priority;
                
                ret += lcm_msg_tx_lcChsmPOEport(clnt, p_port);
                
                LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm POE timer port %d,admin %d,aver_consump %d, \
                    budget %d,class %d,cur_consump %d,oper %d,peak_consump %d,priority %d.\n.", port_id+1, port_info[port_id].admin,
                    port_info[port_id].aver_consump,port_info[port_id].budget,port_info[port_id].class,port_info[port_id].cur_consump,
                    port_info[port_id].oper, port_info[port_id].peak_consump, port_info[port_id].priority);        
            }
        }
    }

    /* update POE system status */
    //sal_memset(&sys_info, 0, sizeof(glb_poe_sys_stat_info_t));
    //sal_memset(&sys_change, 0, sizeof(glb_poe_sys_stat_change_t));
    //ret += poe_get_sys_status(&sys_info, &sys_change);
    if(p_card->poe_port_num)
    {
        if(1 == sys_change.aver_consump_change || 1 == sys_change.aver_volt_change || 1 == sys_change.budget_change ||
            1 == sys_change.budget_reserved_change || 1 == sys_change.budget_warn_threshold_change ||
            1 == sys_change.budget_warn_threshold_change || 1 == sys_change.cur_consump_change || 1 == sys_change.cur_volt_change ||
            1 == sys_change.legacy_cap_change || 1 == sys_change.peak_consump_change || 1 == sys_change.peak_volt_change ||
            1 == sys_change.pm_change)
        {
            p_card->poe_sys_status.aver_consump = sys_info.aver_consump;
            p_card->poe_sys_status.aver_volt = sys_info.aver_volt;
            p_card->poe_sys_status.budget = sys_info.budget;
            p_card->poe_sys_status.budget_reserved = sys_info.budget_reserved;
            p_card->poe_sys_status.budget_warn_threshold = sys_info.budget_warn_threshold;
            p_card->poe_sys_status.cur_consump = sys_info.cur_consump;
            p_card->poe_sys_status.cur_volt = sys_info.cur_volt;
            p_card->poe_sys_status.legacy_cap = sys_info.legacy_cap;
            p_card->poe_sys_status.peak_consump = sys_info.peak_consump;
            p_card->poe_sys_status.peak_volt = sys_info.peak_volt;
            p_card->poe_sys_status.pm = sys_info.pm;
            
            ret += lcm_msg_tx_lcChsmPOEsys(clnt, p_card);
            LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT,"Lcm POE timer sys,aver_consump %d,aver_volt %d,budget%d,\
                budget_reserved %d%%,budget_warn_threshold %d%%,cur_consump %d,cur_volt %d,legacy_cap %d,peak_consump %d,peak_volt %d,pm %d.\n",
                sys_info.aver_consump, sys_info.aver_volt, sys_info.budget, sys_info.budget_reserved, sys_info.budget_warn_threshold,
                sys_info.cur_consump, sys_info.cur_volt, sys_info.legacy_cap,sys_info.peak_consump, sys_info.peak_volt,sys_info.pm);
        }
    }

    if(p_card->poe_interrupt_mode == GLB_PHY_INTERRUPT_MODE_EPLD)
    {
        epld_cfg_poe_interrupt_mask(0);
    }

    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }

    return LCM_E_SUCCESS;
}

#endif /*_GLB_UML_SYSTEM_*/

/* added by qicx for trunk bug26437, PTN bug26201 for GB fiber port intr, 2013-12-18 */
int32
lcm_port_poll_all_ports(void* pv_arg)
{
#ifdef _GGEMU_
// TODO: removed by xgu for gg emualtion board; 2014-6-2
return 0;
#endif
#ifndef _GLB_UML_SYSTEM_
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    glb_phy_state_t phy_val;
    phy_state_change_t phy_change;
    uint8 port_idx;

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    for(port_idx = 1; port_idx <= p_card->port_num; port_idx++)
    {
        p_port = p_card->pp_port[port_idx - 1];

        /*modified by xgu for bug 13493, 2011-01-11*/        
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d not create.", port_idx);
            continue;
        }
        
        memset(&phy_val,0,sizeof(glb_phy_state_t));
        memset(&phy_change,0,sizeof(phy_state_change_t));

        if(phy_get_link_poll(port_idx - 1, &phy_val, &phy_change))
        {
            /*Poll Error*/
            continue;
        }
        _lcm_port_link_change_process(port_idx, &phy_val, &phy_change);
    }
#endif   
    return LCM_E_SUCCESS;
}
/* end of qicx added */

int32
lcm_port_poll_port_status(void* pv_arg)
{
#ifdef _GGEMU_
return 0;
#endif
#ifndef _GLB_UML_SYSTEM_
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    glb_phy_state_t phy_val;
    phy_state_change_t phy_change;
    uint8 port_idx;
    uint16 *gport;

    gport = (uint16*)pv_arg;

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    for(port_idx = 1; port_idx <= p_card->port_num; port_idx++)
    {
        p_port = p_card->pp_port[port_idx - 1];

        /*modified by xgu for bug 13493, 2011-01-11*/        
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm port %d not create.", port_idx);
            continue;
        }

        if(*gport == p_port->logic_port_idx)
        {
            memset(&phy_val,0,sizeof(glb_phy_state_t));
            memset(&phy_change,0,sizeof(phy_state_change_t));

#ifdef GOLDENGATE

extern int32 sys_goldengate_port_get_mac_link_up(uint16 gport, uint32* p_is_up);
extern void _sys_goldengate_port_recover_process(uint16 gport, uint8 dfe_rst);
            
            /*Bug33773.  For 100G port, when recv linkdown interrupt, 
            first recover it, if keep down, then treat it as real down.*/
            
            uint32 is_up;
            
            if(GLB_SPEED_100G == p_port->port_cfg.speed)
            {
                sys_goldengate_port_get_mac_link_up(*gport, &is_up);
                if(is_up==0)
                {
                  _sys_goldengate_port_recover_process(*gport, 0);
                  /*wait 150us, make sure port is recover and link up again.*/
                  sal_udelay(150);
                }
            }
#endif            
            if(phy_get_link_poll(port_idx - 1, &phy_val, &phy_change))
            {
                break;
            }            
            _lcm_port_link_change_process(port_idx, &phy_val, &phy_change);
            break;
        }
    }

#endif   
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_port_led_cfg 
 * Purpose      : management port led          
 * Input        : N/A         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
void
lcm_port_led_cfg(void* p_data)
{
#ifndef _GLB_UML_SYSTEM_
    CTC_TASK_GET_MASTER

    CTC_TASK_ADD_TIME_MSEC(lcm_port_led_cfg, NULL, 5000);
    led_mgt_port_led();
#endif
    return;
}

