/****************************************************************************
 * lcm_mgt.c   :    linecard manager core functions
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     :       R0.01
 * Author       :       Zhuj
 * Date         :       2010-08-11
 * Reason       :       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal_common.h"
#include "glb_hw_define.h"
#include "glb_if_define.h"
#include "glb_tempfile_define.h"
#include "laiinc.h"
#include "lcapi.h"
#include "lcm_specific.h"
#include "lcm_mgt.h"
#include "lcm_client.h"
#include "lcm_error.h"
#include "lcm_card.h"
#include "lcm_port.h"
#include "lcm_dpll.h"
#include "lcm_debug.h"
#include "lcm_srv.h"
#include "epld_api.h"
#include "ctc_pci.h"
#include "phy_api.h"
#include "fiber_api.h"
#include "poe_api.h"
#include "fpga_api.h"
#include "sensor_api.h"
#include "ctc_api.h"
#include "lcm_hagttlk.h"
#include "lcm_log.h"
#include "ctclib_sys_cmd.h"
#include "glb_distribute_system_define.h"
#include "eeprom_api.h"
#include "fan_api.h"
#include "gpio_api.h"
#include "power_api.h"
#ifdef BOOTUP_DIAG
#include "lcm_diag.h"
#endif
//#include <linux/if.h>
#include <sys/reboot.h>
#include "kernel_monitor.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
extern int32 lcm_ftm_read_profile_mode(uint32* p_mode);

#define LCM_LOW_PRIO_QUEUE_DEPTH_MAX  8
#define LCM_LOW_PRIO_QUEUE_TIMEOUT  1000     /* ms */
#define LCM_LOW_PRIO_TASK_INTERVAL  1000      /* ms */
struct lcm_low_prio_task_s
{
    sal_task_t* p_task;
    sal_async_queue_t*  p_queue;
};
typedef struct lcm_low_prio_task_s lcm_low_prio_task_t;

#define POE_CARD_STATUS_TIME 6000
#define POE_PORT_SYS_CFG_TIME 1000


/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
static glb_card_t g_card;
static int32 g_err_reboot_flag;
static int32 g_priority_flag;
static lcm_low_prio_task_t g_lcm_low_prio_task;
static int32 g_bypass_timers;
lcm_mgt_callback_t lcm_mgt_poe_present_callback_func;
lcm_mgt_callback_t lcm_mgt_poe_absent_callback_func;
int g_active_sup_slot = 1; /*wangw_debug, temp 1*/
#ifndef _GLB_UML_SYSTEM_
static uint8 g_reboot_times = 0;
#endif

#ifdef HAVE_STACK
struct lcm_mgt_stack_config g_lcm_stack = {0};
#endif
extern int32 lcm_msg_tx_lcAsicFatal(lcm_clnt_t* clnt, uint8 type, uint8* buf, uint16 size);
extern int32 lcm_msg_tx_lcchsmPoeCardUpdate(lcm_clnt_t* clnt,uint8 poe_psu_stat);
extern int32 lcm_msg_tx_lcchsmReset(lcm_clnt_t* clnt);
#ifndef _GLB_UML_SYSTEM_
extern int32 lcm_msg_tx_lcchsmGetPoeStatusAck(void);
#endif

#ifndef _GLB_UML_SYSTEM_
void lcm_manage_environment_timer(void* p_data);
void lcm_poe_port_sys_cfg_timer(void *p_data);

LCM_DEFINE_TASK_ENCAP(lcm_manage_environment_timer)
LCM_DEFINE_TASK_ENCAP(lcm_poe_port_sys_cfg_timer)
#endif

void lcm_mgt_wakeup_low_priority_task (void* p_data);
LCM_DEFINE_TASK_ENCAP(lcm_mgt_wakeup_low_priority_task)

void lcm_mgt_ctc_dpll_intr(void* p_data);
void lcm_mgt_ctc_hw_intr(void* p_data);
void lcm_mgt_ctc_reset_intr(void* p_data);
void lcm_mgt_ctc_power_intr(void* p_data);
void lcm_mgt_ctc_poe_intr(void* p_data);

LCM_DEFINE_TASK_ENCAP(lcm_mgt_ctc_dpll_intr)
LCM_DEFINE_TASK_ENCAP(lcm_mgt_ctc_hw_intr)
LCM_DEFINE_TASK_ENCAP(lcm_mgt_ctc_reset_intr)
LCM_DEFINE_TASK_ENCAP(lcm_mgt_ctc_power_intr)
LCM_DEFINE_TASK_ENCAP(lcm_mgt_ctc_poe_intr)

/****************************************************************************
*
* Function
*
*****************************************************************************/
#ifndef _GLB_UML_SYSTEM_
poe_port_deal_item_cb poe_port_deal_item_cb_tbl[POE_PORT_DEAL_ITEM_MAX]=
{
    [POE_PORT_DEAL_ITEM_ENABLE] = poe_port_enable_item,
};

poe_sys_deal_item_cb poe_sys_deal_item_cb_tbl[POE_SYS_DEAL_ITEM_MAX]=
{
    [POE_SYS_DEAL_ITEM_PM] = poe_set_sys_pm_item,
    [POE_SYS_DEAL_ITEM_LEGACY] = poe_set_sys_legacy_cap_item,
};
#endif

int32
lcm_mgt_get_active_sup_slot(void* pv_arg)
{
    lcapi_lcm_get_active_sup_slot_t *msg;

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);
    msg = (lcapi_lcm_get_active_sup_slot_t *)pv_arg;

    if(lcm_mgt_is_enable_stack())
    {
        msg->slot = lcm_mgt_get_stack_master();
    }
    else
    {
        msg->slot = g_active_sup_slot;
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_shutdown_all_ports(glb_card_t* p_card)
{
#ifdef _GLB_UML_SYSTEM_
    return LCM_E_SUCCESS;
#else
    int32 ret = 0;
    uint32 port_id ;

    for (port_id = 0;port_id < p_card->port_num; port_id++)
        {
            ret += phy_cfg_enable(port_id, 0);
            /*Fix bug 17269. when reboot, cause link partner link flap. jqiu 2011-12-31*/
            fiber_set_enable(port_id, 0);
        }
    return ret;
#endif
}

static int32
_lcm_disable_poe(glb_card_t* p_card)
{
#ifdef _GLB_UML_SYSTEM_
        return LCM_E_SUCCESS;
#else
        int32 ret = 0;
        uint32 port_id ;

        for (port_id = 0;port_id < p_card->port_num; port_id++)
            {
                ret += poe_port_enable(port_id, POE_DISABLE);
            }
        return ret;
#endif
}

int32
lcm_mgt_get_sw_info(glb_card_t* p_card)
{
    FILE *fp;
    char buf[256];

    if (p_card == NULL)
    {
        return LCM_E_SUCCESS;
    }
    
    memset(p_card->sw_ver, 0, sizeof(p_card->sw_ver));
    fp = sal_fopen(GLB_BOARD_INFO_FILE, "r");
    if(NULL == fp)
    {
        return LCM_E_FILE_OPEN;
    }

    while(fgets(buf, 256, fp) != NULL)
    {
        uint8 tmp[256];

        if(!sal_strncmp(buf, GLB_SW_VERSION_STRING, 6))
        {
            sal_sscanf(buf, "%s %s", tmp, p_card->sw_ver);
        }
        
     }

    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name        : _lcm_mgt_init_hw_info
 * Purpose     : initialize hw information
 * Input       : card infomation
 * Output      : N/A
 * Return      : SUCCESS
 * Note        :
*****************************************************************************/
static int32
_lcm_mgt_init_hw_info(glb_card_t* p_card)
{
#ifdef _GLB_UML_SYSTEM_
    return LCM_E_SUCCESS;
#endif
#if 1
    FILE *fp;
    uint32 val;
    char buf[256];

    p_card->tmpr_cfg.low = DEFAULT_LOW_TMPR;
    p_card->tmpr_cfg.high = DEFAULT_HIGH_TMPR;
    p_card->tmpr_cfg.crit = DEFAULT_CRIT_TMPR;
    p_card->tmpr_cfg.chip_low_alarm = GG_CHIP_TMPR_LOW_ALARM;
    p_card->tmpr_cfg.chip_low = GG_CHIP_TMPR_LOW;
    p_card->tmpr_cfg.chip_high = GG_CHIP_TMPR_HIGH;
    p_card->tmpr_cfg.chip_alarm = GG_CHIP_TMPR_ALARM;
    p_card->tmpr_cfg.chip_crit = GG_CHIP_TMPR_CRITICAL;

    /* HW information is in file /tmp/ctcos_board_info, now parse it */

    fp = sal_fopen(GLB_BOARD_INFO_FILE, "r");
    if(NULL == fp)
    {
        p_card->board_type.type = 0xff;
        p_card->board_type.series = GLB_SERIES_MAX;
        p_card->epld_ver = 0;
        p_card->fpga_ver = 0;
        return LCM_E_FILE_OPEN;
    }

    while(fgets(buf, 256, fp) != NULL)
    {
        uint8 tmp[256];

        if(!sal_strncmp(buf, GLB_PRODUCT_SERIES_STRING, 14))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->board_type.series = (uint8)val;
        }
        else if(!sal_strncmp(buf, GLB_BOARD_TYPE_STRING, 10))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->board_type.type = (uint8)val;
        }
#ifndef _CTC_NID_
        else if(!sal_strncmp(buf, GLB_HW_VERSION_STRING, 6))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->hw_ver = (uint8)val;
        }
        else if(!sal_strncmp(buf, GLB_HW_FLASH_SIZE, 10))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->flash_size = val;
        }
        else if(!sal_strncmp(buf, GLB_HW_DRAM_SIZE, 10))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->dram_size = val;
        }
#endif
        else if(!sal_strncmp(buf, GLB_EPLD_VERSION_STRING, 8))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->epld_ver = (uint8)val;
        }
        else if(!sal_strncmp(buf, GLB_EPLD_DATE_STRING, 9))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->epld_date = val;
        }
#ifndef _CTC_NID_
        else if(!sal_strncmp(buf, GLB_EPLD_TIME_STRING, 9))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            p_card->epld_time = (uint16)val;
        }
#endif
        else if(!sal_strncmp(buf, GLB_SW_VERSION_STRING, 6))
        {
            sal_sscanf(buf, "%s %s", tmp, p_card->sw_ver);
        }
        else if(!sal_strncmp(buf, GLB_SERIES_NUM, 8))
        {
            sal_sscanf(buf, "%s %s", tmp, p_card->serial_no);
        }
        else if(!sal_strncmp(buf, GLB_BOOTROM_VER, 7))
        {
            sal_sscanf(buf, "%s %s", tmp, p_card->bootrom_ver);
        }
        else if(!sal_strncmp(buf, GLB_SYS_MAC, 6))
        {
            uint32 tmp2[6];
            int  i;
            sal_sscanf(buf, "%s %02X:%02X:%02X:%02X:%02X:%02X", tmp, &tmp2[0], &tmp2[1], &tmp2[2], &tmp2[3], &tmp2[4], &tmp2[5]);
            for(i = 0; i < 6; i++)
            {
                p_card->sysmac[i] = (uint8)tmp2[i];
            }
            p_card->sysmac[GLB_ETH_ADDR_LEN] = '\0';
        }
    

     }

    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL,
                  "Get board series %x, type %x, hw version %x",
                  p_card->board_type.series, p_card->board_type.type, p_card->hw_ver);

    sal_fclose(fp);
#else
    //p_card->board_type.type = GLB_BOARD_E580_24Q;
    p_card->board_type.type = GLB_BOARD_E580_48X2Q4Z;
    p_card->board_type.series = GLB_SERIES_E580;
    p_card->epld_ver = 0x1;

#endif

    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_mgt_ctc_hw_intr
 * Purpose      : manage ctc hw interrupt events
 * Input        :
 * Output       : N/A
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
void
lcm_mgt_ctc_hw_intr(void* p_data)
{
#ifdef _GLB_UML_SYSTEM_
    return;
#else
    CTC_TASK_GET_MASTER
    int32 ctc_hw_fd = get_ctc_hw_fd();

    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "handle ctc hw interrupt events.");

    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_hw_intr, NULL, ctc_hw_fd);

    lcm_port_status_intr();

    return;
#endif    
}

void
lcm_mgt_ctc_reset_intr(void* p_data)
{
#ifdef _GLB_UML_SYSTEM_
    return;
#else
    CTC_TASK_GET_MASTER
    int32 ctc_reset_fd = get_ctc_reset_fd();
    lcm_clnt_t *p_lcm_clnt;
    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "handle reset interrupt events.");

    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_reset_intr, NULL, ctc_reset_fd);

    /* notify CHSM of reset operation */
    p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    lcm_msg_tx_lcchsmReset(p_lcm_clnt);

    return;
#endif
}

/* Modified by liuht for bug 27657, 2014-03-25 */
#ifndef _GLB_UML_SYSTEM_
static int power_intr_flag = 0;
#endif
int32
lcm_mgt_handle_power_intr()
{
#ifdef _GLB_UML_SYSTEM_
    return LCM_E_SUCCESS;
#else
    time_t timep;
    struct stat stat_buf;
    FILE *fp_console = NULL;
    FILE *fp_pts = NULL;
    FILE *fp_log = NULL;	
    int i = 0;
    char buf[32];
	
    time(&timep);
    strncpy(buf,ctime(&timep),24);
    buf[24] = '\0';
    /* sync log to syslog */
    if(power_intr_flag == 0)
    {
        fp_log = sal_fopen("/mnt/flash/cold/power.log",  "a+");
        sal_fprintf(fp_log, "%s The power supply of device has been broken down, please check!\n", buf);
        sal_fclose(fp_log);
        power_intr_flag = 1;
    }
    /* Print log to console */
    fp_console = sal_fopen("/dev/console",  "a+");
    sal_fprintf(fp_console, "PSU Down!\n");
    sal_fclose(fp_console);

    /* Print log to all tty */
    for(i = 0; i < 8; i++)
    {
        sal_sprintf(buf, "/dev/pts/%d", i);
        buf[10] = '\0';
        if (stat(buf, &stat_buf) == 0)
        {
            fp_pts = sal_fopen(buf,  "a+"); 
            if(fp_pts)
            {
                sal_fprintf(fp_pts, "The power supply of device has been broken down, please check!\n");
                sal_fclose(fp_pts);
            }
        }
    }

    // TODO: send msg to upper level
    return LCM_E_SUCCESS;
#endif
}

/* Modified by liuht for bug 27657, 2014-03-25 */
void
lcm_mgt_ctc_power_intr(void* p_data)
{
#ifdef _GLB_UML_SYSTEM_
    return;
#else
    CTC_TASK_GET_MASTER
    int32 ctc_power_fd = get_ctc_power_fd();
    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "handle power interrupt events.");

    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_power_intr, NULL, ctc_power_fd);

    lcm_mgt_handle_power_intr();

    return;
#endif
}


/***************************************************************************************************
 * Name         : lcm_mgt_ctc_dpll_intr
 * Purpose      : manage ctc dpll interrupt events
 * Input        :
 * Output       : N/A
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
void
lcm_mgt_ctc_dpll_intr(void* p_data)
{
#ifdef _GLB_UML_SYSTEM_
    return;
#else
    CTC_TASK_GET_MASTER
    int32 ctc_dpll_fd = get_ctc_dpll_fd();

    if (ctc_dpll_fd < 0)
    {
        LCM_LOG_ERR("lcm_mgt_ctc_dpll_intr : get dpll fd failed.");
    }

    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "handle ctc dpll interrupt events.");

    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_dpll_intr, NULL, ctc_dpll_fd);

    lcm_dpll_status_intr();

    epld_cfg_dpll_interrupt_mask(0);

    return;
#endif
}

void
lcm_mgt_ctc_poe_intr(void* p_data)
{
#ifdef _GLB_UML_SYSTEM_
    return;
#else
    CTC_TASK_GET_MASTER
    int32 ctc_poe_fd = get_ctc_poe_fd();

    if(ctc_poe_fd < 0)
    {
        LCM_LOG_ERR("lcm_mgt_ctc_poe_intr : get poe fd failed.");
    }

    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "handle ctc poe interrupt events.");

    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_poe_intr, NULL, ctc_poe_fd);

    lcm_poe_status_intr();

    return;
#endif
}


static void 
lcm_mac_addr_add(uint8* mac, uint32 cnt)
{
    uint32_t value;
    uint32_t val_high, val_low;

    val_high = (mac[0]<<16)+(mac[1]<<8)+mac[2];
    val_low = (mac[3]<<16)+(mac[4]<<8)+mac[5];
    value = val_low + cnt;
    val_low = value & 0xffffff;
    if(value > 0xffffff)
    {
        val_high = val_high+1;
    }
    mac[0] = (val_high >> 16) & 0xff;
    mac[1] = (val_high >> 8) & 0xff;
    mac[2] = val_high & 0xff;
    mac[3] = (val_low >> 16) & 0xff;
    mac[4] = (val_low >> 8) & 0xff;
    mac[5] = val_low & 0xff;
}



static int32
lcm_port_get_mac(uint8*mac, uint32 pannel_port_no)
{
    sal_memcpy(mac, g_card.sysmac, GLB_ETH_ADDR_LEN);
    lcm_mac_addr_add(mac, pannel_port_no);

    return LCM_E_SUCCESS;    
}


/*****************************************************************************
 * Name        : lcm_mgt_init_lc
 * Purpose     : initialize linecard
 * Input       : pointer of global card info
 * Output      : N/A
 * Return      : SUCCESS
 * Note        : only used on chassis system
*****************************************************************************/
static int32
_lcm_mgt_init_lc(glb_card_t* p_card)
{
    int i;
    uint8 mac[GLB_ETH_ADDR_LEN];
#ifdef _GLB_UML_SYSTEM_
    int32 fd = -1;
    int ret;
#endif
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm managment init linecard begin.");
#ifdef _GLB_DISTRIBUTE_SYSTEM_
#ifdef _GLB_UML_SYSTEM_
    LCM_IF_ERROR_RETURN(lcm_init_sw_emu(p_card));
#else // !_GLB_UML_SYSTEM_

#endif // _GLB_UML_SYSTEM_ end
#else // !_GLB_DISTRIBUTE_SYSTEM_
#ifdef _GLB_UML_SYSTEM_
    LCM_IF_ERROR_RETURN(lcm_init_sw_emu(p_card));
#else // !_GLB_UML_SYSTEM_    
    if(GLB_SERIES_GREATBELT_DEMO == p_card->board_type.series)
    {
        switch (p_card->board_type.type)
        {
            case GLB_BOARD_GREATBELT_DEMO:
                LCM_IF_ERROR_RETURN(lcm_init_greatbelt_demo(p_card));
                break;
            default:
                LCM_LOG_USER(E_WARNING,LCM_4_UNSUPPORT_BOARD_SERIES_TYPE,p_card->board_type.series,p_card->board_type.type);
                LCM_LOG_WARN("Unsupport board series %d type %d",p_card->board_type.series,p_card->board_type.type);
                return LCM_E_INVALID_BOARD;
        }
    }
    else if(GLB_SERIES_E350 == p_card->board_type.series)
    {
        switch (p_card->board_type.type)
        {
            /* Modify by liuht for now don't support E350-48T4X2Q for bug25659, 2013-11-28 */
            /* Modified by liuht to distinguish e350-48t4xg and e350-48t12xg, 2013-11-05 */
            case GLB_BOARD_E350_48T4X2Q:
#if 0				
                LCM_IF_ERROR_RETURN(lcm_init_e350_48t4x2q(p_card));
                break;
#endif		
            case GLB_BOARD_E350_48T4XG:
                LCM_IF_ERROR_RETURN(lcm_init_e350_48t4xg(p_card));
                break;

            /* Added by liuht to support 24T4X board, 2013-11-18 */
           // case GLB_BOARD_E350_24T4XG:
               // LCM_IF_ERROR_RETURN(lcm_init_e350_24t4xg(p_card));
               // break;
            /* Added by liuht for bug27056, 2014-01-24 */
            /* To distinguish phicomm board and centec board for 8T12X */
            case GLB_BOARD_E350_8T12XG:
            case GLB_BOARD_E350_PHICOMM_8T12XG:
                LCM_IF_ERROR_RETURN(lcm_init_e350_8t12x(p_card));
                break;
            //case GLB_BOARD_E350_MT_8T12XG:
            //case GLB_BOARD_E350_MTRJ_8T12XG:
               // LCM_IF_ERROR_RETURN(lcm_init_e350_mt_8t12x(p_card));
               // break;
            //case GLB_BOARD_E350_8TS12X:
               // LCM_IF_ERROR_RETURN(lcm_init_e350_8ts12x(p_card));
               // break;
            /* Added by liuht to support e350-8t4s12x for bug 29099, 2014-06-23 */
           // case GLB_BOARD_E350_8T4S12XG:
                //LCM_IF_ERROR_RETURN(lcm_init_e350_8t4s12x(p_card));
                //break;
            /* end of liuht added */
            //case GLB_BOARD_E350_24X:
              //  LCM_IF_ERROR_RETURN(lcm_init_e350_24x(p_card));
              //  break;

            default:
                LCM_LOG_USER(E_WARNING,LCM_4_UNSUPPORT_BOARD_SERIES_TYPE,p_card->board_type.series,p_card->board_type.type);
                LCM_LOG_WARN("Unsupport board series %d type %d",p_card->board_type.series,p_card->board_type.type);
                return LCM_E_INVALID_BOARD;
        }
    }
    else if(GLB_SERIES_E580 == p_card->board_type.series)
    {
        switch(p_card->board_type.type)
        {
            case GLB_BOARD_E580_24Q:
                LCM_IF_ERROR_RETURN(lcm_init_goldengate_demo(p_card));  
                break;
            case GLB_BOARD_E580_48X2Q4Z:
                LCM_IF_ERROR_RETURN(lcm_init_e580_48x2q4z(p_card));
                break;
            case GLB_BOARD_E580_48X6Q:
                LCM_IF_ERROR_RETURN(lcm_init_e580_48x6q(p_card));
                break;
            case GLB_BOARD_E580_32X2Q:
            case GLB_BOARD_E580_32X:
                LCM_IF_ERROR_RETURN(lcm_init_e580_32x2q(p_card));
                break;
        }
    }    
    else
    {
        LCM_LOG_USER(E_WARNING,LCM_4_UNSUPPORT_BOARD_SERIES_TYPE,p_card->board_type.series,p_card->board_type.type);
        LCM_LOG_WARN("Unsupport board series %d type %d",p_card->board_type.series,p_card->board_type.type);
        return LCM_E_INVALID_BOARD;
    }
#ifdef BOOTUP_DIAG
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm bootup diag stage1 begin.");
    if(0 != lcm_diag_start_stage1(p_card))
    {
        LCM_LOG_WARN("Lcm bootup diag stage1 fail.");
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm bootup diag stage1 end.");
#endif	
#endif // _GLB_UML_SYSTEM_ end
#endif // _GLB_DISTRIBUTE_SYSTEM_ end
/*add port mac to port data*/
#ifdef _GLB_UML_SYSTEM_
    fd = sal_open("/dev/urandom", O_RDONLY);
    if(fd < 0)
    {
        g_card.sysmac[0] = 0x00;
        g_card.sysmac[1] = 0x00;
        g_card.sysmac[2] = 0x0a;
        g_card.sysmac[3] = 0x00;
        g_card.sysmac[4] = 0x00;
        g_card.sysmac[5] = 0x00;
    }
    ret = sal_read(fd, g_card.sysmac, 6);
    if(ret < 0)
    {
        g_card.sysmac[0] = 0x00;
        g_card.sysmac[1] = 0x00;
        g_card.sysmac[2] = 0x0a;
        g_card.sysmac[3] = 0x00;
        g_card.sysmac[4] = 0x00;
        g_card.sysmac[5] = 0x00;
    }
    else
    {
        g_card.sysmac[0] &= 0xfe;
        g_card.sysmac[5] = 0x0;
    }
    sal_close(fd);
#endif
    
    for(i=0;i<g_card.port_num;i++)
    {
        lcm_port_get_mac(mac, g_card.pp_port[i]->panel_port_no);
        sal_memcpy(g_card.pp_port[i]->mac,mac, GLB_ETH_ADDR_LEN); 
    }
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm managment init linecard end.");

    return LCM_E_SUCCESS;
}

/* Added by liuht for bug27036, 2014-02-27 */
/***************************************************************************************************
 * Name         : lcm_mgt_mount_reboot_info 
 * Purpose      : mount reboot information to line card         
 * Input          : p_card
 * Output        : N/A              
 * Return        : LCM_E_SUCCESS
 * Note           : N/A
***************************************************************************************************/
int32
lcm_mgt_mount_reboot_info(glb_card_t* p_card)
{
#ifndef _GLB_UML_SYSTEM_
    uint8 i = 0;
    uint8 count = 0;
    char buf[256];
    char time1[16],time2[16];
    FILE *fp = NULL; 
    if(p_card->support_reboot_info)
    {
        if(0 == p_card->reboot_times)
        {
            return LCM_E_INVALID_PARAM;
        }
        g_reboot_times = p_card->reboot_times;
        count = p_card->reboot_times;	
    
        fp = sal_fopen(REBOOT_INFO_SAVE_PATH, "a+");
        if(NULL == fp)
        {
            return LCM_E_FILE_OPEN;
        }
        if(p_card->reboot_times > REBOOT_TIMES_MAX)
        {
            p_card->reboot_times = REBOOT_TIMES_MAX;
        }
        p_card->reboot_info = (reboot_info_t *)sal_malloc(sizeof(reboot_info_t)*p_card->reboot_times);
        if(NULL == p_card->reboot_info)
        {
            return LCM_E_NO_MEMORY;
        }
        sal_fseek(fp, 0, SEEK_SET);
        while(fgets(buf, 256, fp))
        {
            if((count > 0) && (count <= REBOOT_TIMES_MAX))
            {
                sal_sscanf(buf, "%s %s %s", p_card->reboot_info[i].reboot_type, time1, time2);
                sal_sprintf(p_card->reboot_info[i].reboot_time, "%s %s", time1, time2);	
                i++;
            }
            count--;		
        }
        sal_fclose(fp);
    }
#endif
    return LCM_E_SUCCESS;
}

int32
lcm_mgt_unmount_reboot_info(glb_card_t* p_card)
{
#ifndef _GLB_UML_SYSTEM_
    if(p_card->support_reboot_info)
    {
        p_card->reboot_times = g_reboot_times;
        /* Modified by liuht for bug 27925, 2014-03-31 */
        //if(p_card->reboot_info)
        {
           // sal_free(p_card->reboot_info);
        }
        //p_card->reboot_info = NULL;
    }
#endif
    return LCM_E_SUCCESS;
}


/* Added by liuht for bug27036, 2014-02-27 */
/***************************************************************************************************
 * Name         : lcm_mgt_get_reboot_info_reboot_time 
 * Purpose      : get reboot time           
 * Input          : reboot_time
 * Output        : N/A              
 * Return        : LCM_E_SUCCESS
 * Note           : N/A
***************************************************************************************************/
int32
lcm_mgt_get_reboot_info_reboot_time(char *reboot_time)
{
#ifndef _GLB_UML_SYSTEM_
    char year[5], month[3], day[3],hour[3],minute[3], second[3];

    time_t timep;
    struct tm *p;

    time(&timep);
    p=localtime(&timep);

    sal_sprintf(year, "%d", (1900 + p->tm_year));	
    if(1+p->tm_mon >= 10)
    {  
        sal_sprintf(month, "%d", (1+p->tm_mon));		
    }
    else
    {   
        sal_sprintf(month, "%c%d", '0',(1+p->tm_mon));		
    }
    if(p->tm_mday >= 10)
    { 
        sal_sprintf(day, "%d", p->tm_mday);    			
    }
    else
    {
        sal_sprintf(day, "%c%d", '0', p->tm_mday);    		
    }
    if(p->tm_hour >= 10)
    { 
        sal_sprintf(hour, "%d", p->tm_hour);    		
    }
    else
    {  
        sal_sprintf(hour, "%c%d", '0', p->tm_hour);    	
    }
    if(p->tm_min >= 10)
    {  
        sal_sprintf(minute, "%d", p->tm_min);    		
    }
    else
    {  
        sal_sprintf(minute, "%c%d", '0', p->tm_min);    		
    }
    if(p->tm_sec>= 10)
    {  
        sal_sprintf(second, "%d", p->tm_sec);    		
    }
    else
    {  
        sal_sprintf(second, "%c%d", '0', p->tm_sec);    		
    }	
    sal_sprintf(reboot_time, "%s-%s-%s %s:%s:%s", 
		year, 
		month, 
		day, 
		hour, 
		minute,
		second);
#endif	
    return LCM_E_SUCCESS ;
}

/* Added by liuht for bug27036, 2014-02-27 */
/***************************************************************************************************
 * Name         : lcm_mgt_get_reboot_info 
 * Purpose      : get reboot information           
 * Input          : reboot_info
 * Output        : N/A              
 * Return        : LCM_E_SUCCESS
 * Note           : N/A
***************************************************************************************************/
int32
 lcm_mgt_get_reboot_info(reboot_info_t *reboot_info)
{
#ifndef _GLB_UML_SYSTEM_
    int reboot_flag = 0;
    char reboot_time[32];	

    lcm_mgt_get_reboot_info_reboot_time(reboot_time);
    sal_strncpy(reboot_info->reboot_time, reboot_time, 32);

    reboot_flag = epld_check_power_reboot();
    if(reboot_flag)
    {
        sal_strncpy(reboot_info->reboot_type, "POWER", 5);
        reboot_info->reboot_type[5] = '\0'; 
    }
    else
    {
        reboot_flag = epld_check_manual_reboot();
        if(reboot_flag)
        {
            sal_strncpy(reboot_info->reboot_type, "MANUAL", 6);
            reboot_info->reboot_type[6] = '\0'; 			
        }
        else
        {
            sal_strncpy(reboot_info->reboot_type, "OTHER", 5);
            reboot_info->reboot_type[5] = '\0'; 	
        }
    }
    epld_reset_reboot_flags();
#endif
    return LCM_E_SUCCESS;
}

/* Added by liuht for bug27036, 2014-02-27 */
/***************************************************************************************************
 * Name         : lcm_mgt_save_reboot_info 
 * Purpose      : save reboot information           
 * Input          : p_card reboot_info
 * Output        : N/A              
 * Return        : LCM_E_FILE_OPEN | LCM_E_NO_MEMORY | LCM_E_SUCCESS
 * Note           : N/A
***************************************************************************************************/
int32
 lcm_mgt_save_reboot_info(glb_card_t* p_card, reboot_info_t *reboot_info)
{
#ifndef _GLB_UML_SYSTEM_
    /* Modified by liuht for bug 27925, 2014-03-31 */
    FILE *fp = NULL;
    FILE *fp_tmp = NULL;
    char buf[256];
    long int count = 0;

    fp = sal_fopen(REBOOT_INFO_SAVE_PATH, "a+");
    if(NULL == fp)
    {
        return LCM_E_FILE_OPEN;
    }
	
    sal_fprintf(fp ,"%-15s %-25s\n",
        reboot_info->reboot_type, 
        reboot_info->reboot_time);
    sal_fflush(fp);
    sal_fseek(fp, 0, SEEK_SET);
    while(sal_fgets(buf, 256, fp))
    {
        count++;
    }
	
    if(count > 200)
    {
        fp_tmp = sal_fopen(REBOOT_INFO_SAVE_PATH_TMP, "a+");
        if(NULL == fp_tmp)
        {
            return LCM_E_FILE_OPEN;
        }
        sal_fseek(fp, 0, SEEK_SET);
        while(count > 200)
        {
            sal_fgets(buf, 256, fp);
            count--;
        }
        while(sal_fgets(buf, 256, fp))
        {
            sal_fputs(buf, fp_tmp);
        }
        sal_fclose(fp);
        sal_fclose(fp_tmp);
        sal_unlink(REBOOT_INFO_SAVE_PATH);
        sal_rename(REBOOT_INFO_SAVE_PATH_TMP, REBOOT_INFO_SAVE_PATH);
    }
    else
    {
        sal_fclose(fp);
    }
    p_card->reboot_times = (uint8)count;
#endif
    return LCM_E_SUCCESS;
}

/* Added by liuht for bug27036, 2014-02-27 */
/***************************************************************************************************
 * Name         : lcm_mgt_reboot_info 
 * Purpose      : management reboot information           
 * Input          : p_card
 * Output        : N/A              
 * Return        : ret
 * Note           : N/A
***************************************************************************************************/
int32
_lcm_mgt_reboot_info(glb_card_t* p_card)
{
#ifndef _GLB_UML_SYSTEM_
    int ret = 0;
    reboot_info_t reboot_info;
    if(p_card->support_reboot_info)
    {
        ret = lcm_mgt_get_reboot_info(&reboot_info);
        if(ret < 0)
        {
            p_card->reboot_times = 0;
            LCM_LOG_USER(E_ERROR,LCM_4_GET_REBOOT_INFO, "Get");
            LCM_LOG_ERR("Get reboot infomation fail.");
            return LCM_E_SUCCESS;
        }
        ret = lcm_mgt_save_reboot_info(p_card, &reboot_info);
        if(ret < 0)	
        {
            p_card->reboot_times= 0;
            LCM_LOG_USER(E_ERROR,LCM_4_GET_REBOOT_INFO, "Save");
            LCM_LOG_ERR("Save reboot infomation fail.");
            return LCM_E_SUCCESS;
        }
    }
#endif
    return LCM_E_SUCCESS;
}

void
lcm_mgt_wakeup_low_priority_task (void* p_data)
{
    CTC_TASK_GET_MASTER
    int ret = 0;

    CTC_TASK_ADD_TIME_MSEC(lcm_mgt_wakeup_low_priority_task, NULL, LCM_LOW_PRIO_TASK_INTERVAL);

    ret = sal_async_queue_put(g_lcm_low_prio_task.p_queue, NULL);
    if(ret)
    {
        LCM_LOG_CRIT("Low priority task queue write fail, error code is %d.", ret);
    }

    return;
}

#ifndef _GLB_UML_SYSTEM_
/*Lcm get all sensor temperature and store, if reach critical, shutdown power.*/
int32
lcm_manage_tmpr_status()
{
    glb_card_t* p_card = NULL; 
    int16 board_temp, board_temp_max=0;    
    uint32 chip_temp = 0;
    uint8 i, sensor_id=0, position=SENSOR_CPU, shutdown_flag=0;
    
    p_card= lcm_mgt_get_card();
    /*1. Get real-time temperature value, and select the max temp value.*/
    for(i=0; i<p_card->sensor_num; i++)
    {
        if(RESULT_OK == sensor_dev_get_temp(i, CURRENT_TEMP, &board_temp))
        {
            p_card->tmpr_status[i].tmpr_val = board_temp;
            sensor_dev_get_position(i, &position);
            p_card->tmpr_status[i].pos = position;
            if(board_temp_max<board_temp)
            {
                board_temp_max = board_temp;
                sensor_id = i;
            }
        }
    }
    for(i=0; i<p_card->chip_sensor_num; i++)
    {
        if(CTC_E_NONE == ctc_get_chip_sensor(i, CTC_CHIP_SENSOR_TEMP, &chip_temp))
        {
            p_card->tmpr_status[p_card->sensor_num+i].tmpr_val = chip_temp;
            p_card->tmpr_status[p_card->sensor_num+i].pos = SENSOR_CHIP0+i;
        }
    }
    /*2. check if chip tmpr reach critical*/
    for(i=0; i<p_card->chip_sensor_num; i++)
    {
        if(p_card->tmpr_status[p_card->sensor_num+i].tmpr_val >= GG_CHIP_TMPR_CRITICAL)
        {
            shutdown_flag = 1;
        }
    }
    /*3. use sensor critical function to shutdown power.*/
    if(shutdown_flag)
    {
        sensor_dev_set_temp(sensor_id, CRIT_TEMP, board_temp_max-GG_CHIP_TMPR_CRITICAL_HYST);
    }
    return LCM_E_SUCCESS;    
}

int32
lcm_adjust_fan_speed()
{
    glb_card_t* p_card = NULL;     
    int32 chip_tmpr=0, board_tmpr=0;
    uint8 i, cfg_speed_level, orig_speed_level;
    uint8 speed_rate;

    p_card= lcm_mgt_get_card();
    /*1 get highest temperature*/
    for(i=0; i<(p_card->chip_sensor_num+p_card->sensor_num); i++)
    {        
        if((p_card->tmpr_status[i].pos == SENSOR_CHIP0)
            ||(p_card->tmpr_status[i].pos == SENSOR_CHIP1))
        {
            if(chip_tmpr < p_card->tmpr_status[i].tmpr_val)
            {
                chip_tmpr = p_card->tmpr_status[i].tmpr_val;
            }
        }
        else
        {
            if(board_tmpr < p_card->tmpr_status[i].tmpr_val)
            {
                board_tmpr = p_card->tmpr_status[i].tmpr_val;
            }
        }        
    }
    /*2 judge temperature and get new speed level*/
    fan_get_speed_level(0, &orig_speed_level);
    /*2.1 support chip sensor, adjust fan speed depend on chip sensor*/
    if(p_card->chip_sensor_num > 0)
    {
        if(chip_tmpr >= GG_CHIP_TMPR_ALARM)
        {
            cfg_speed_level = FAN_SPEED_FULL;
        }
        else if(chip_tmpr >= (GG_CHIP_TMPR_ALARM-GG_CHIP_TMPR_HYST))
        {
            if(orig_speed_level == FAN_SPEED_FULL)
            {
                cfg_speed_level = FAN_SPEED_FULL;
            }
            else
            {
                cfg_speed_level = FAN_SPEED_HIGH;
            }
        }
        else if(chip_tmpr >= GG_CHIP_TMPR_HIGH)
        {
            cfg_speed_level = FAN_SPEED_HIGH;
        }
        else if(chip_tmpr >= (GG_CHIP_TMPR_HIGH-GG_CHIP_TMPR_HYST))
        {
            if(orig_speed_level == FAN_SPEED_HIGH)
            {
                cfg_speed_level = FAN_SPEED_HIGH;
            }
            else
            {
                cfg_speed_level = FAN_SPEED_LOW;
            }
        }
        else if(chip_tmpr >= GG_CHIP_TMPR_LOW)
        {
            cfg_speed_level = FAN_SPEED_LOW;
        }
        else if(chip_tmpr >= (GG_CHIP_TMPR_LOW-GG_CHIP_TMPR_HYST))
        {
            if(orig_speed_level == FAN_SPEED_LOW)
            {
                cfg_speed_level = FAN_SPEED_LOW;
            }
            else
            {
                cfg_speed_level = FAN_SPEED_BOTTOM;
            }
        }
        else
        {
            cfg_speed_level = FAN_SPEED_BOTTOM;
        }
    }
    else/*2.2 not support chip sensor, adjust fan speed depend on board sensor*/
    {
        if(board_tmpr >= BOARD_TMPR_FULL)
        {
            cfg_speed_level = FAN_SPEED_FULL;
        }
        else if(board_tmpr >= (BOARD_TMPR_FULL-BOARD_TMPR_HYST))
        {
            if(orig_speed_level == FAN_SPEED_FULL)
            {
                cfg_speed_level = FAN_SPEED_FULL;
            }
            else
            {
                cfg_speed_level = FAN_SPEED_HIGH;
            }
        }
        else if(board_tmpr >= BOARD_TMPR_HIGH)
        {
            cfg_speed_level = FAN_SPEED_HIGH;
        }
        else if(board_tmpr >= (BOARD_TMPR_HIGH-BOARD_TMPR_HYST))
        {
            if(orig_speed_level == FAN_SPEED_HIGH)
            {
                cfg_speed_level = FAN_SPEED_HIGH;
            }
            else
            {
                cfg_speed_level = FAN_SPEED_LOW;
            }
        }
        else if(board_tmpr >= BOARD_TMPR_LOW)
        {
            cfg_speed_level = FAN_SPEED_LOW;
        }
        else if(board_tmpr >= (BOARD_TMPR_LOW-BOARD_TMPR_HYST))
        {
            if(orig_speed_level == FAN_SPEED_LOW)
            {
                cfg_speed_level = FAN_SPEED_LOW;
            }
            else
            {
                cfg_speed_level = BOARD_TMPR_LOW;
            }
        }
        else
        {
            cfg_speed_level = FAN_SPEED_BOTTOM;
        }
    }
    /*3. set new speed and store it.*/
    for(i=0; i<p_card->fan_module_num; i++)
    {
        fan_config_speed_level(i, cfg_speed_level);
        p_card->fan_status[i].speed_level = cfg_speed_level;
        fan_get_speed_rate_by_level(i, cfg_speed_level, &speed_rate);
        p_card->fan_status[i].speed_rate = speed_rate;
    }
    return LCM_E_SUCCESS;
}

int32
lcm_manage_fan_status()
{
    glb_card_t* p_card = NULL; 
    uint8 i, value, present, status, fan_num,speed_adjust;

    p_card= lcm_mgt_get_card();
    /*1. get real-time fan present status */
    for(i=0; i<p_card->fan_module_num; i++)
    {
        if(RESULT_OK != fan_get_present(i, &value))
        {
            value = 0;
        }
        if(value == 0)
        {
             present = FAN_ABSENT;
        }
        else if(FAN_ABSENT == p_card->fan_status[i].present)
        {
            present = FAN_INIT;
        }
        else
        {
            present = FAN_PRESENT;
        }
        if(present == FAN_PRESENT)
        {
            /*Fan insert, status change from absent to present, re-init fan, and get fan basic info.*/
            if(p_card->fan_status[i].present == FAN_INIT)
            {
                fan_dev_reinit(i);
            }
            p_card->fan_status[i].present = present;
            fan_get_speed_adjust(i, &speed_adjust);
            p_card->fan_status[i].speed_adjust = speed_adjust;
            fan_get_num(i, &fan_num);
            p_card->fan_status[i].num = fan_num;
        }
        p_card->fan_status[i].present = present;
    }
    
    /*2. get real-time fan status */
    for(i=0; i<p_card->fan_module_num; i++)
    {
        if(p_card->fan_status[i].present != FAN_PRESENT)
        {
            continue;
        }        
        fan_get_status(i, &status, &fan_num);
        p_card->fan_status[i].status = status;        
    }
    /*3. adjust fan speed depend on temperature*/
    lcm_adjust_fan_speed();
    
    return LCM_E_SUCCESS;
}

int32
lcm_manage_psu_status()
{    
    int32 ret;
    glb_card_t* p_card = NULL; 
    psu_status_t psu_status;
    uint8 i;
    
    p_card = lcm_mgt_get_card();
    for (i = 0; i < p_card->psu_module_num; i++)
    {
        ret = psu_get_status(i, &psu_status);
        if (ret < 0)
        {
            LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                           "Get line card psu %d status fail", i);
            continue;
        }
        sal_memcpy(&(p_card->psu_status[i]), &psu_status, sizeof(psu_status_t));
        LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                           "line card psu %d psuType %d psuPg %d psu_absent %d psu_alert %d",
                           i,psu_status.psu_type,psu_status.psu_work_status, psu_status.psu_absent, psu_status.psu_alert);
    }
    return LCM_E_SUCCESS;
}
/*Fix bug 32404, support manage environment. include sensor, fan, psu.*/
void
lcm_manage_environment_timer(void* p_data)
{
    static int hw_ready = 0;
    lai_psu_info_t lai_psu;
    lai_thermal_info_t lai_thermal;
    lai_fan_info_t lai_fan;
    
    lai_object_id_t oid = 0;
    
    int i=0, j=0;

    //LCM_PRINT_CON("lcm_manage_environment_timer cb");
    
    CTC_TASK_GET_MASTER

    CTC_TASK_ADD_TIME_MSEC(lcm_manage_environment_timer, NULL, LCM_POLLING_ENVIRONMENT_TIMER);
    /*2. manage temperature. get real-time chip and PCB temperature.*/
    lcm_manage_tmpr_status();
    /*3. manage fan status and adjust speed. */
    lcm_manage_fan_status();
    /*4. manage psu status*/
    lcm_manage_psu_status();


    /*add fan lai cb*/
    /*because fan is found after hw init a while, so add it alwayse here*/
    if(p_lai_card_noti && p_lai_card_noti->on_fan_event)
    {
        for(i = 0; i<g_card.fan_module_num; i++)
        {
            for(j=0; j<g_card.fan_status[i].num; j++)
            {
                oid = (g_card.phy_slot_no << 16) + (i<<8) + j;
                
                ctc_lai_get_fan_info(oid, &lai_fan);
                
                p_lai_card_noti->on_fan_event(LAI_FAN_EVENT_ADD, &lai_fan);
            }
        }
    }

    if(hw_ready)
    {
        return;
    }
    /*add psu lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_psu_event)
    {
        for(i = 0; i<g_card.psu_module_num; i++)
        {
            oid = (g_card.phy_slot_no << 16) + i;
            LCM_PRINT_CON("############ call on_psu_event cb");
            
            ctc_lai_get_psu_info(oid, &lai_psu);
            
            p_lai_card_noti->on_psu_event(LAI_PSU_EVENT_ADD, &lai_psu);
        }
    }

    /*add thermal lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_thermal_event)
    {
        for(i = 0; i<g_card.sensor_num; i++)
        {
            oid = (g_card.phy_slot_no << 16) + i;
            LCM_PRINT_CON("############ call on_thermal_event cb");
            
            ctc_lai_get_thermal_info(oid, &lai_thermal);
            
            p_lai_card_noti->on_thermal_event(LAI_THERMAL_EVENT_ADD, &lai_thermal);
        }

    }

    g_card.card_state = BOARD_READY;
    hw_ready = 1;
    
    return;
}


int32 lcm_poe_card_status_timer(void)
{
    glb_card_t* p_card = NULL;
    int32 ret = 0;
    uint8 poe_psu_status = POE_PSU_FAIL;
    //static thread_t *poe_thread_read_high = NULL;
    static int32 present_timer_cnt = 0, absent_timer_cnt = 0;
    //static int32 ctc_poe_fd = -1;
    lcm_clnt_t *p_lcm_clnt;
    static poe_daughter_card_work_mode_t poe_card_mode = POE_DAUGHTER_CARD_USER_MODE;

    if(lcm_mgt_get_bypass_timers())
        return LCM_E_SUCCESS;
    /*get local line card*/
    p_card= lcm_mgt_get_card();
    ret += poe_get_psu_status(&poe_psu_status);
    if(POE_PSU_GOOD == poe_psu_status)
    {
        /* PoE PSU status from absent to present*/
        /* PoE PSU is always present and poe daughter card mode change */
        if(present_timer_cnt == 0 ||
            (poe_card_mode != p_card->poe_card_mode && present_timer_cnt == 1))
        {
            if(present_timer_cnt == 0)
            {
                absent_timer_cnt = 0;
                present_timer_cnt = 1;
            }
            if(poe_card_mode != p_card->poe_card_mode)
            {
                poe_card_mode = p_card->poe_card_mode;
            }

            ret += lcm_mgt_poe_present_callback_func();
            #if 0
            ctc_poe_fd = get_ctc_poe_fd();
            if(ctc_poe_fd < 0)
            {
                LCM_LOG_ERR("lcm_poe_card_status_timer : get poe fd failed.");
                return RESULT_ERROR;
            }
            poe_thread_read_high = CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_poe_intr, NULL, ctc_poe_fd);
            if(p_card->poe_interrupt_mode == GLB_POE_INTERRUPT_MODE_EPLD)
            {
                epld_cfg_poe_interrupt_mask(0);
            }
            #endif
            /* notify CHSM of PoE info */
            p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();
            lcm_msg_tx_lcchsmPoeCardUpdate(p_lcm_clnt, poe_psu_status);
        }
        else
        {
            //poe_thread_read_high = CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_poe_intr, NULL, ctc_poe_fd);
        }
    }
    else
    {
        /* PoE PSU status from present to absent */
        if(absent_timer_cnt == 0)
        {
            absent_timer_cnt = 1;
            present_timer_cnt = 0;
            ret += lcm_mgt_poe_absent_callback_func();
            #if 0
            if(poe_thread_read_high != NULL)
            {
                //ctclib_thread_cancel(poe_thread_read_high);
                poe_thread_read_high = NULL;
            }
            ctc_poe_fd = -1;
            #endif
            /* notify CHSM of PoE info */
            p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();
            lcm_msg_tx_lcchsmPoeCardUpdate(p_lcm_clnt, poe_psu_status);
        }
    }

    return ret;
}

void lcm_poe_port_sys_cfg_timer(void *p_data)
{
    CTC_TASK_GET_MASTER
    glb_card_t* p_card = NULL;
    uint8 poe_psu_status = POE_PSU_FAIL;
    int32 ret = 0;
    int32 port_idx;
    int32 poe_port_phase_end_cnt = 0;
    int32 poe_sys_phase_end_cnt = 0;
    struct stat stat_buf;
    char sys_cmd[256]={0};
    FILE *fp;

    CTC_TASK_ADD_TIME_MSEC(lcm_poe_port_sys_cfg_timer, NULL, POE_PORT_SYS_CFG_TIME);
    ret += poe_get_psu_status(&poe_psu_status);
    if(POE_PSU_GOOD == poe_psu_status)
    {
        for(port_idx = 0; port_idx < p_card->port_num; port_idx++)
        {
            ret = poe_port_deal_item_cb_tbl[POE_PORT_DEAL_ITEM_ENABLE](port_idx);
            if(ret != POE_DEAL_ITEM_END)
            {
                poe_port_phase_end_cnt++;
            }
        }

        ret = poe_sys_deal_item_cb_tbl[POE_SYS_DEAL_ITEM_PM]();
        if(ret != POE_DEAL_ITEM_END)
        {
            poe_sys_phase_end_cnt++;
        }
        ret = poe_sys_deal_item_cb_tbl[POE_SYS_DEAL_ITEM_LEGACY]();
        if(ret != POE_DEAL_ITEM_END)
        {
            poe_sys_phase_end_cnt++;
        }
    }

    //if 0 exist, else -1
    ret = sal_stat(GLB_POE_PORT_CFG_DONE_NAME,&stat_buf);
    if(poe_port_phase_end_cnt)
    {
        /* during deal, rm the tmp done file*/
        if(!ret)
        {
            sal_sprintf(sys_cmd,"rm %s",GLB_POE_PORT_CFG_DONE_NAME);
            ctclib_reconstruct_system_cmd_chld_clone(ctclib_reconstruct_system_cmd_exec_str, (void*)sys_cmd);
        }
    }
    else
    {
        /* deal end, create the tmp done file*/
        if(ret)
        {
            if((fp = sal_fopen(GLB_POE_PORT_CFG_DONE_NAME,"w+"))!=NULL)
            {
                sal_fclose(fp);
            }
        }
    }

    //if 0 exist, else -1
    ret = sal_stat(GLB_POE_SYS_CFG_DONE_NAME, &stat_buf);
    if(poe_sys_phase_end_cnt)
    {
        /* during deal, rm the tmp done file*/
        if(!ret)
        {
            sal_sprintf(sys_cmd,"rm %s",GLB_POE_SYS_CFG_DONE_NAME);
            ctclib_reconstruct_system_cmd_chld_clone(ctclib_reconstruct_system_cmd_exec_str, (void*)sys_cmd);
        }
    }
    else
    {
        /* deal end, create the tmp done file*/
        if(ret)
        {
            if((fp = sal_fopen(GLB_POE_SYS_CFG_DONE_NAME,"w+"))!=NULL)
            {
                sal_fclose(fp);
            }
        }
    }

    return;
}

int32
lcm_poe_daughter_card_mode(uint32 mode)
{
    glb_card_t* p_card = NULL;

    p_card= lcm_mgt_get_card();
    if(NULL == p_card)
    {
        return LCM_E_INVALID_PTR;
    }

    p_card->poe_card_mode = mode;

    return LCM_E_SUCCESS;
}

#endif

/*****************************************************************************
 * Name        : lcm_mgt_monitor_lc
 * Purpose     : run the threads(timer or event) for monitoring the linecard
 * Input       : N/A
 * Output      : N/A
 * Return      : If success
 * Note        : Should be called after the line card actually
               : init done function(lcm_card_init_cb).
*****************************************************************************/
int32
lcm_mgt_monitor_lc(void)
{
    CTC_TASK_GET_MASTER

    LCM_PRINT_CON("lcm_mgt_monitor_lc init");
#ifndef _GLB_UML_SYSTEM_
#ifndef _GGEMU_ // TODO: removed by xgu for gg emulation board, 2014-6-3
#ifndef _GLB_DISTRIBUTE_SYSTEM_
    int32 ctc_hw_fd = get_ctc_hw_fd();
    int32 ctc_dpll_fd = -1;
    int32 ctc_reset_fd = get_ctc_reset_fd();
	/* Modified by liuht for bug 27657, 2014-03-25 */
    int32 ctc_power_fd = get_ctc_power_fd();	
#if 0
    int32 ctc_dpll_fd = get_ctc_dpll_fd();
#endif
#endif
#endif

    glb_card_t* p_card = NULL;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm mgt monitor lc : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    if ((GLB_SERIES_GREATBELT_DEMO == p_card->board_type.series)
        || (GLB_SERIES_PTN722 == p_card->board_type.series))
    {
#if 0 // TODO: removed by weij for compile,  2014-12-19
        ctc_dpll_fd = get_ctc_dpll_fd();
#endif
    }
#endif

#ifdef _GLB_DISTRIBUTE_SYSTEM_
    #ifdef _GLB_UML_SYSTEM_

    #else // !_GLB_UML_SYSTEM_

    #endif // _GLB_UML_SYSTEM_ end
#else // !_GLB_DISTRIBUTE_SYSTEM_
    CTC_TASK_ADD_TIME_MSEC(lcm_mgt_wakeup_low_priority_task, NULL, LCM_LOW_PRIO_TASK_INTERVAL);
#ifndef _GGEMU_ // TODO: removed by xgu for gg emulation board, 2014-6-3
    #ifdef _GLB_UML_SYSTEM_

    #else // !_GLB_UML_SYSTEM_
    /* modify default port timer interval from 3s to 1s, qicx, 2013-12-18 */
    CTC_TASK_ADD_TIME_MSEC(lcm_port_port_status_timer, NULL, 1000);
    /* modified by yaom for 10G remote fault 20140410 */
    CTC_TASK_ADD_TIME_MSEC(lcm_port_remote_fault_timer, NULL, 1000);
    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_hw_intr, NULL, ctc_hw_fd);
    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_reset_intr, NULL, ctc_reset_fd);
    /* Modified by liuht for bug 27657, 2014-03-25 */
    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_power_intr, NULL, ctc_power_fd);
    //ctclib_thread_add_timer_msec(p_master, lcm_fiber_port_status_timer, NULL, 1000);
    /* if any port split, this timer management port led */
    if(p_card->split_flag)
    {
        CTC_TASK_ADD_TIME_MSEC(lcm_port_led_cfg, NULL, 5000);
    }
    CTC_TASK_ADD_TIME_MSEC(lcm_manage_environment_timer, NULL, LCM_POLLING_ENVIRONMENT_TIMER);

    #if 0

    /* modified by yaom for 10G remote fault detection 20120926 */
    CTC_TASK_ADD_TIME_MSEC(lcm_port_remote_fault_timer, NULL, 1000);

    CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_dpll_intr, NULL, ctc_dpll_fd);

    if(p_card->poe_port_num)
    {
        CTC_TASK_ADD_TIME_MSEC(lcm_poe_port_sys_cfg_timer, NULL, 1000);
    }
    #endif
    if ((GLB_SERIES_GREATBELT_DEMO == p_card->board_type.series)
        || (GLB_SERIES_PTN722 == p_card->board_type.series))
    {
        CTC_TASK_ADD_READ_HIGH(lcm_mgt_ctc_dpll_intr, NULL, ctc_dpll_fd);
    }
    
    /*Should clear interrupt mask after ctc_hw interrupt init*/
    if(p_card->phy_interrupt_mode == GLB_PHY_INTERRUPT_MODE_FPGA)
    {
        fpga_cfg_phy_interrupt_mask(0);
    }
    else if(p_card->phy_interrupt_mode == GLB_PHY_INTERRUPT_MODE_EPLD)
    {
        /* add 'is_gbdemo' flag for some features that gbdemo board owns only, added by qicx, 2013-07-08 */
        /* fix bug 24090, cr7223, qicx, 2013-08-15 */
        epld_cfg_phy_interrupt_mask(0, p_card->is_gbdemo);
    }

    #endif // _GLB_UML_SYSTEM_ end
#endif
#endif // _GLB_DISTRIBUTE_SYSTEM_ end

        LCM_PRINT_CON("lcm_mgt_monitor_lc end");
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name        : _lcm_mgt_monitor_low_priority_task
 * Purpose     : run the threads for monitoring linecard low priority tasks
 * Input       : N/A
 * Output      : N/A
 * Return      : N/A
 * Note        : Must not use ctclib_thread related functions
*****************************************************************************/
static void
_lcm_mgt_monitor_low_priority_task(void* p_arg)
{
    int ret;
    uint32 queue_param = 0;
#ifndef _GLB_UML_SYSTEM_
    glb_card_t* p_card = NULL;
    static int32 cnt=0;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("card is NULL.");
        return;
    }
#endif

    while(1)
    {
        ret = sal_async_queue_get(g_lcm_low_prio_task.p_queue,
                                    LCM_LOW_PRIO_QUEUE_TIMEOUT, (void **)&queue_param);
        if (ETIMEDOUT == ret)
        {
            continue;
        }

        if (0 != ret)
        {
            LCM_LOG_CRIT("Low priority task queue read fail, error code is %d.", ret);
            continue;
        }
        #ifndef _GLB_UML_SYSTEM_
        if(p_card->poe_port_num)
        {
            if((cnt++)%6 == 0)
            {
                /* poe chip init or poe mode changes need take a long time */
                lcm_poe_card_status_timer();
            }
            lcm_msg_tx_lcchsmGetPoeStatusAck();
        }
        lcm_fiber_port_status_timer();
        gpio_scan_real_time_value();
        #endif
    }

    return;
}

glb_card_t*
lcm_mgt_get_card()
{
    return &g_card;
}

int16
lcm_mgt_get_logic_slot()
{
    return g_card.logic_slot_no;
}

void
lcm_mgt_set_err_reboot_flag(int32 flag)
{
    g_err_reboot_flag = flag;
}

int32
lcm_mgt_get_err_reboot_flag(void)
{
    return g_err_reboot_flag;
}

void
lcm_mgt_set_priority_flag(int32 flag)
{
    g_priority_flag = flag;
}

int32
lcm_mgt_get_priority_flag(void)
{
    return g_priority_flag;
}

int32
lcm_mgt_enable_asic_normal_intr(void* pv_arg)
{
#ifdef _GLB_UML_SYSTEM_
    return LCM_E_SUCCESS;
#endif
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm enabel asic normal interrupt.");
    return hw_asic_en_normal_int();
}

int32
lcm_mgt_enable_asic_fatal_intr(void* pv_arg)
{
#ifdef _GLB_UML_SYSTEM_
    return LCM_E_SUCCESS;
#endif
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm enabel asic fatal interrupt.");
    return hw_asic_en_fatal_int();
}

#ifdef FOAM_SUPPORT /* for bug14682, foam 1588 syncif development, 2011-04-25 */
int32
lcm_mgt_enable_foam_normal_intr(void* pv_arg)
{
#ifdef _GLB_UML_SYSTEM_
    return LCM_E_SUCCESS;
#endif
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm enabel foam normal interrupt.");
    return hw_foam_en_normal_int();
}
#endif /*FOAM_SUPPORT*/

/*****************************************************************************
 * Name        : lcm_mgt_asic_fatal
 * Purpose     : handle asic fatal interrupt
 * Input       : lcapi_lcm_asic_abnormal_t
 * Output      : N/A
 * Return      : N/A
 * Note        : N/A
*****************************************************************************/
int32
lcm_mgt_asic_fatal(void* pv_arg)
{
    lcapi_lcm_asic_abnormal_t* asic_fatal;
    lcm_clnt_t *p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();

    if(NULL == pv_arg)
    {
        LCM_LOG_ERR("handle asic fatal interrupt: invalid pointer.");
        return LCM_E_INVALID_PTR;
    }

    asic_fatal = (lcapi_lcm_asic_abnormal_t* )pv_arg;
    if(p_lcm_clnt != NULL)
    {
        lcm_msg_tx_lcAsicFatal(p_lcm_clnt, asic_fatal->fatal_type,
                                asic_fatal->buf, asic_fatal->size);
    }

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name        : lcm_mgt_bypass_timers
 * Purpose     : enable/disable the bypass timers
 * Input       : enable flag
 * Output      : N/A
 * Return      : N/A
 * Note        : N/A
*****************************************************************************/
int32
lcm_mgt_bypass_timers(void* pv_arg)
{
    g_bypass_timers = *(int32 *)pv_arg;

    return 0;
}

/*****************************************************************************
 * Name        : lcm_mgt_get_bypass_timers
 * Purpose     : get the bypass timers flag
 * Input       : N/A
 * Output      : N/A
 * Return      : N/A
 * Note        : N/A
*****************************************************************************/
int32
lcm_mgt_get_bypass_timers()
{
    return g_bypass_timers;
}
/*****************************************************************************
 * Name         : lcm_reload()
 * Purpose      : The function reload line card
 * Input        : N/A
 * Output       : N/A
 * Return       : ErrCode
 * Note         : The ports' PHY must be disabled during line card reloading
*****************************************************************************/
int32
lcm_reload(void)
{
    int32 ret = 0;
    glb_card_t* p_card = NULL;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm reload : card is NULL.");
        return LCM_E_INVALID_PTR;
    }

    ret = _lcm_shutdown_all_ports(p_card);
    if(p_card->poe_port_num)
    {
        ret += _lcm_disable_poe(p_card);
    }
#ifndef _GLB_UML_SYSTEM_
    /*Bug18151. When reboot, also let watchdog reboot. remove this disable watchdog code.*/
//    ctc_disable_watchdog();
#else
    system("halt -f");
#endif
#ifdef _GLB_DISTRIBUTE_SYSTEM_
    reboot(RB_AUTOBOOT);
#else
    if (lcm_mgt_is_enable_stack() 
        && lcm_mgt_get_stack_master() != lcm_mgt_get_stack_member())
    {
        reboot(RB_AUTOBOOT);
    }
#endif
    return ret;
}

    int32 
lcm_InitSdk(uint32 profile_type);

/*****************************************************************************
 * Name        : int32 lcm_mgt_init
 * Purpose     : intialize the linecard manager
 * Input       : N/A
 * Output      : N/A
 * Return      : If success
 * Note        : N/A
*****************************************************************************/
int32
lcm_mgt_init(void)
{
    uint32 profile_type = 0;
    lai_card_info_t lai_card;
    lai_port_info_t lai_port;
    lcapi_lcm_set_port_status_t portstatus;
    lai_object_id_t oid = 0;
    int i = 0;

    
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm managment init begin.");

    sal_memset(&g_card, 0, sizeof(glb_card_t));
    g_card.card_state = BOARD_FIRST_CREATED;
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "################lcm_mgt_init 0.");
    LCM_IF_ERROR_RETURN(lcm_debug_init());
    LCM_IF_ERROR_RETURN(_lcm_mgt_init_hw_info(&g_card));
    LCM_IF_ERROR_RETURN(_lcm_mgt_init_lc(&g_card));
#ifndef _GLB_UML_SYSTEM_	
    /* Added by liuht for bug27036, 2014-02-27 */	
    LCM_IF_ERROR_RETURN(_lcm_mgt_reboot_info(&g_card));	
#endif
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "################lcm_mgt_init 1.");
    if (0 == sal_async_queue_create(&g_lcm_low_prio_task.p_queue,
                                    LCM_LOW_PRIO_QUEUE_DEPTH_MAX))
    {
        /* modified by kcao for bug 13571, 2010-11-22 : reduce thread stack memory */
        if (0 != sal_task_create(&g_lcm_low_prio_task.p_task,
                                "lcm_monitor",
                                256*1024, SAL_TASK_PRIO_DEF+10, _lcm_mgt_monitor_low_priority_task, NULL))
        {
            LCM_LOG_CRIT("Create lcm low priority monitoring thread fail.");
        }
    }
    else
    {
        LCM_LOG_CRIT("Create lcm low priority task queue fail.");
    }

    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "################lcm_mgt_init 2.");
    LCM_IF_ERROR_RETURN(lcm_clnt_start());
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "################lcm_mgt_init 3.");
    LCM_IF_ERROR_RETURN(lcm_srv_start());
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "################lcm_mgt_init 4.");
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm managment init end.");
    
    /*Here, profile type should be got from local card epprom for pizzax, 
      and should be got by subscribe CHASSIS Table, so later initsdk should be moved 
      to wait_chassis_version_check_and_get_profile_type call*/
#ifndef _GLB_UML_SYSTEM_
    //lcm_ftm_read_profile_mode(&profile_type);
    profile_type = 0;
#else
    profile_type = 0;
#endif
    lcm_InitSdk(profile_type);


    /*set card status ready*/
    
    /*New OSP system decouple chsm and lcm, init sdk here derectly*/
    /*add card lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_card_event)
    {
        LCM_PRINT_CON("############ call on_card_event cb");
        oid = g_card.phy_slot_no;
        LCM_IF_ERROR_RETURN(ctc_lai_get_card_info(oid, &lai_card));
        
        p_lai_card_noti->on_card_event(LAI_CARD_EVENT_ADD, &lai_card);
    }

    /*add port lai cb*/
    if(p_lai_card_noti && p_lai_card_noti->on_port_event)
    {
        LCM_PRINT_CON("############ call on_port_event cb, port num is %d", g_card.port_num);
        for(i = 0; i<g_card.port_num; i++)
        {
            oid = (g_card.phy_slot_no<<16) + i;
            
            LCM_IF_ERROR_RETURN(ctc_lai_get_port_info(oid, &lai_port));

            portstatus.slot_idx = lai_port.slot_id;
            portstatus.port_idx = lai_port.pannel_port_id;
            portstatus.subport_idx = lai_port.pannel_sub_port_id;
            portstatus.status = 1;
            LCM_IF_ERROR_RETURN(lcm_port_set_enable(&portstatus)); 
            
            
            p_lai_card_noti->on_port_event(LAI_PORT_EVENT_ADD, &lai_port);
        }
    }
    return LCM_E_SUCCESS;
}

int32
lcm_mgt_poe_present_callback(lcm_mgt_callback_t func)
{
    lcm_mgt_poe_present_callback_func = func;
    return LCM_E_SUCCESS;
}

int32
lcm_mgt_poe_absent_callback(lcm_mgt_callback_t func)
{
    lcm_mgt_poe_absent_callback_func = func;
    return LCM_E_SUCCESS;
}

int32
lcm_mgt_get_virt_sysmac(uint8 sys_mac[6])
{
    int32 fd = -1;
    int32 ret = -1;

    fd = sal_open("/dev/urandom", O_RDONLY);
    if(fd < 0)
    {
        sys_mac[0] = 0x00;
        sys_mac[1] = 0x00;
        sys_mac[2] = 0x0a;
        sys_mac[3] = 0x00;
        sys_mac[4] = 0x00;
        sys_mac[5] = 0x00;
        return 0;
    }
    ret = sal_read(fd, sys_mac, GLB_ETH_ADDR_LEN);
    if(ret < 0)
    {
        sys_mac[0] = 0x00;
        sys_mac[1] = 0x00;
        sys_mac[2] = 0x0a;
        sys_mac[3] = 0x00;
        sys_mac[4] = 0x00;
        sys_mac[5] = 0x00;
    }
    else
    {
        sys_mac[0] &= 0xfe;
        sys_mac[5] = 0x0;
    }
    sal_close(fd);

    return 0;
}

int32
lcm_mgt_get_sysmac(void* pv_arg)
{
    lcapi_lcm_get_sysmac_t *msg;
    glb_card_t* p_card = NULL;
    uint8 buf[GLB_ETH_ADDR_LEN + 1];
#ifndef _GLB_UML_SYSTEM_    
  // TODO: Modified by xgu for gg emulation board, gg emulation also use random mac. 2014-5-28   eeprom_info_t *p_eeprom_info = NULL;
#ifndef _GGEMU_
    eeprom_info_t *p_eeprom_info = NULL;
#endif
#endif

    GLB_PTR_VALID_CHECK(pv_arg, LCM_E_INVALID_PTR);

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm send init SDK ack : card is NULL.");
        return LCM_E_INVALID_PTR;
    }

#ifndef _GLB_UML_SYSTEM_
#ifndef _GGEMU_ // TODO: Modified by xgu for gg emulation board, gg emulation also use random mac. 2014-5-28
     p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_SYS_MAC]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm send init SDK ack : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }

    /* sysmac has been saveed in p_card */
    //eeprom_get_system_mac(buf , p_eeprom_info);
    //sal_strncpy(buf, p_card->sysmac, GLB_ETH_ADDR_LEN);
    sal_memcpy(buf, p_card->sysmac, GLB_ETH_ADDR_LEN);
    
#else
    lcm_mgt_get_virt_sysmac(buf);
#endif    
#endif

    msg = (lcapi_lcm_get_sysmac_t *)pv_arg;
    memcpy(msg->sysmac, buf, GLB_ETH_ADDR_LEN);
    return LCM_E_SUCCESS;
}

int32
lcm_mgt_is_enable_stack()
{
    static int enable = -1;
    struct stat stat_buf;

    if (enable != -1)
    {
        return enable;
    }

    enable = !stat(GLB_STACK_ENABLE_FILE, &stat_buf);
    return enable;
}

int32
lcm_mgt_get_stack_member()
{
    FILE *fp;
    char buf[BUFSIZ];
    static int slot = -1;

    if (slot != -1)
    {
        return slot;
    }

    slot = 1;
    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        fgets (buf, BUFSIZ, fp);
        slot = atoi(buf);
        sal_fclose(fp);
    }    

    return slot;
}

int32
lcm_mgt_get_stack_master()
{
    FILE *fp;
    char buf[BUFSIZ];
    static int slot = -1;

    if (slot != -1)
    {
        return slot;
    }

    slot = 1;
    fp = sal_fopen(GLB_STACK_MASTER_SLOT_FILE, "r");
    if (fp)
    {
        fgets (buf, BUFSIZ, fp);
        slot = atoi(buf);
        sal_fclose(fp);
    }    

    return slot;
}

int32
lcm_mgt_get_sup_slot()
{
#ifdef HAVE_STACK
    return lcm_mgt_get_stack_master();
#else
    return 0;
#endif
}

int
lcm_mgt_ioctl (int request, caddr_t buffer)
{
  int sock;
  int ret = 0;
  int err = 0;

  sock = socket (AF_INET, SOCK_DGRAM, 0);
  if (sock < 0)
    {
      perror ("socket");
      exit (1);
    }

  ret = ioctl (sock, request, buffer);
  if (ret < 0)
    {
      err = errno;
    }
  close (sock);
  
  if (ret < 0) 
    {
      errno = err;
      return ret;
    }
  return 0;
}

int
lcm_mgt_get_if_hwaddr (char *ifname, unsigned char *hwaddr,
               int *hwaddr_len)
{
  int ret;
  struct ifreq ifreq;
  int i;

  strncpy (ifreq.ifr_name, ifname, IFNAMSIZ);
  GLB_UNAME_TO_KNAME(ifreq.ifr_name);
  ifreq.ifr_addr.sa_family = AF_INET;

  /* Fetch Hardware address if available. */
  ret = lcm_mgt_ioctl (SIOCGIFHWADDR, (caddr_t) &ifreq);
  if (ret < 0)
    *hwaddr_len = 0;
  else
    {
      memcpy (hwaddr, ifreq.ifr_hwaddr.sa_data, 6);

      for (i = 0; i < 6; i++)
	if (hwaddr[i] != 0)
	  break;

      if (i == 6)
	*hwaddr_len = 0;
      else
	*hwaddr_len = 6;
    }
  return 0;
}

int32
lcm_mgt_reload(void* pv_arg)
{
    return lcm_reload();
}

/* Added by liuht for bug 27788, 2014-03-24 */
void
lcm_mgt_get_current_bootromver(char *bootrom_ver)
{
    char ary_tmp[256];
    char *chr_p = NULL;
    FILE * fd_proc;
    char cur_tmp[256] = {'\0'};
    
    fd_proc = sal_fopen("/proc/cmdline", "r");
    if(!fd_proc)
    {
        sal_strncpy(bootrom_ver, "UNKNOWN", MAX_BOOTROM_VER_LEN);
        return ;
    }
    sal_fgets(ary_tmp, 256, fd_proc);

    chr_p = sal_strstr(ary_tmp, "U-Boot ");

    if(chr_p != NULL)
    {
        chr_p += sal_strlen("U-Boot ");
        sal_strncpy(cur_tmp, chr_p, 256);
        chr_p = cur_tmp;
        if((chr_p = strchr(chr_p, ' ')) != NULL)
            *chr_p = '\0';

        sal_strncpy(bootrom_ver, cur_tmp, MAX_BOOTROM_VER_LEN);
    }
    else
    {
        sal_strncpy(bootrom_ver, "UNKNOWN", MAX_BOOTROM_VER_LEN);
    }

    sal_fclose(fd_proc);
}

/* Modified by liuht for bug 26911, 2014-03-27 */
int32
lcm_mgt_set_led_flag_to_kernal(int* alarm)
{
#ifndef _GLB_UML_SYSTEM_ 
    int ret = 0;
    int32 ctc_sys_led_fd = get_ctc_sys_led_fd();
	
    LCM_LOG_DEBUG(lcm, lcmgt, LCM_LCMGT_NORMAL, "Lcm managment set sys led flag to kernal.");
	
    if(-1 != ctc_sys_led_fd)
    {
        ret = ioctl(ctc_sys_led_fd, CTC_LED_RDWR, alarm);
		if(ret)
		{
		    LCM_LOG_ERR("Lcm set sys led flag to kernel fail.");
		}
    }
#endif    
    return LCM_E_SUCCESS;
}

