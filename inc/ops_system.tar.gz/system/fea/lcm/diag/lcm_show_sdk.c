// TODO: Commented by xgu for compile 20121120//
#if 0
 /**
  @file lcm_show_sdk.c
  
  @date 2010-12-01
  
  @version v1.0
 
  The file contains show sdk database functions
 */
/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "ctclib_show.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "lcapi_lcm_lcsh_msg.h"
#include "drv_io.h"
#include "drv_cfg.h"
#include "drv_humber.h"
#include "drv_tbl_reg.h"
#include "diag_tblstr.h"
#include "ctc_api.h"
#include "sys_humber_ipuc.h"
#include "sys_humber_l2_fdb.h"
#include "drv_foam_enum.h"
#include "drv_foam_tbl_reg.h"
#include "sys_humber_opf.h"
#include "sys_humber_queue_enq.h"

/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/
extern int32
sys_humber_nh_display_current_global_sram_info();
extern int32
sys_humber_nh_dump_all(uint32 nh_type, bool detail);
extern int32
sys_humber_nh_dump_mcast(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_brguc(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_ipuc(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_mpls(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_ecmp(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_iloop(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_rspan(uint32 nhid, bool detail);
extern int32
sys_humber_nh_dump_downmep(uint32 nhid, bool detail);
extern int32
sys_humber_show_alloc_info(void);
extern int32 
sys_humber_opf_print_alloc_info(sys_humber_opf_t *opf);
extern sys_l2_master_t* pl2_master;
extern sys_ipuc_master_t* p_ipuc_master;
/*Added by xgu for support opf dump in humber system*/
struct lcm_dump_opf_arg_entry
{
    enum sys_humber_opf_type   arg_num;
    const char           *arg_name;
};
/* this data structure is related with enum sys_humber_opf_type */
struct lcm_dump_opf_arg_entry lcm_dump_opf_arg_list[] = 
{
    {OPF_USRID_VLAN_KEY, "usrid-vlan-key"},
    {OPF_USRID_MAC_KEY, "usrid-mac-key"},
    {OPF_USRID_IPV4_KEY, "usrid-ipv4-key"},
    {OPF_USRID_IPV6_KEY, "usrid-ipv6-key"},
    {LOCAL_MET_DSFWD_SRAM, "local met dsfwd"},
    {LOCAL_NEXTHOP_SRAM, "local next-hop"},
    {L2EDIT_SRAM, "l2edit sram"},
    {L3EDIT_SRAM, "l3edit sram"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {FDB_SRAM_MAC_FL_KEY, "fdb-mac-filtering-key"},
#endif
    {FDB_SRAM_HASH_COLLISION_KEY, "fdb-hash-collision-key"},
    {NHID_INTERNAL, "nhid-internal"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {OPF_ACL_LABEL, "opf-acl-label"},
#endif
    {OPF_ACL_PBR_LABEL, "opf-pbr-label"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {OPF_QOS_LABEL, "opf-qos-label"},
#endif
    {ACL_MAC_MPLS_IPV4_KEY, "acl-mac-mpls-ipv4-key"},
    {ACL_IPV6_KEY, "acl-ipv6-key"},
    {ACL_PBR_IPV4_KEY, "pbr-ipv4-key"},
    {ACL_PBR_IPV6_KEY, "pbr-ipv6-key"},
    {QOS_MAC_MPLS_IPV4_KEY, "qos-mac-mpls-ipv4-key"},
    {QOS_IPV6_KEY, "qos-ipv6-key"},  
    {OPF_QOS_FLOW_POLICER, "opf-qos-flow-policer"},
    {OPF_QOS_FLOW_POLICER_WITH_STATS, "opf-qos-flow-policer-with-stats"},
    {OPF_QOS_POLICER_PROFILE, "opf-qos-policer-profile"},
    {FWD_STATS_SRAM, "fwd-stats-sram"},
    {OPF_QUEUE_DROP_PROFILE, "opf-queue-drop-profile"},
    {OPF_QUEUE_SHAPE_PROFILE, "opf-queue-shape-profile"},
    {OPF_GROUP_SHAPE_PROFILE, "opf-group-shape-profile"},
    {OPF_QUEUE_GROUP, "opf-queue-group"},
    {OPF_SERVICE_QUEUE, "opf-service-queue"},
#if 0 /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
    {OPF_QUEUE_INTERNAL_PORT, "opf-queue-internal-port"},
#endif
    {OPF_OAM_TCAM_KEY, "opf-oam-tcam-key"},
    {OPF_OAM_MEP_RMEP, "opf-oam-mep-rmep"},
    {OPF_OAM_MA, "opf-oam-ma"},
    {OPF_OAM_MA_NAME, "opf-oam-ma-name"},
    {OPF_IPV4_UC_BLOCK, "opf-ipucv4-block"},
    {OPF_IPV6_UC_BLOCK, "opf-ipucv6-block"},
    {OPF_IPV4_MC_BLOCK, "opf-ipmcv4-block"},
    {OPF_IPV6_MC_BLOCK, "opf-ipmcv6-block"},
    {ACL_PBR_IPV4_KEY_HEAD, "acl-pbr-ipv4-head"},
    {ACL_PBR_IPV4_KEY_TAIL, "acl-pbr-ipv4-tail"},
    {ACL_PBR_IPV6_KEY_HEAD, "acl-pbr-ipv6-head"},
    {ACL_PBR_IPV6_KEY_TAIL, "acl-pbr-ipv6-tail"},
    {OPF_FOAM_MEP, "opf-foam-mep"},
    {OPF_FOAM_MA, "opf-foam-ma-name"},
    {OPF_FOAM_MA_NAME, "opf-foam-ma-name"},
    /*SYSTEM Modified by xgu for bug 16061, 2011-08-29*/
    {OPF_USERID_VLAN_DEFAULT_KEY, "usrid-vlan-default-key"},
    {MAX_OPF_TBL_NUM, "all"},
};

/****************************************************************************
*  
* Function
*
*****************************************************************************/
#ifdef _GLB_SEOUL_CODE_RELEASE_
/*add by chenyuqiang for source code release */
bool diag_foam_getstr_byid(uint8 id_type, uint32 id, char* str)
{
    return TRUE;
}

bool diag_foam_getid_bystr(uint8 id_type, char* str, uint32* id)
{
    return TRUE;
}

#endif



/*****************************************************************************
 * Name         : lcm_dump_sdk_nexthop(lcapi_show_req_t* req)
 * Purpose      : The function dump sdk nexthop database and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_dump_sdk_nexthop(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;
    bool detail = FALSE;
    uint32 sub_type = 0;
    uint32 nhid = 0;
    
    switch (req->param[0])
    {
    case LCAPI_SHOW_SDK_NEXTHOP_GLB_OFFSET:
        ret = sys_humber_nh_display_current_global_sram_info();
        break;

    case LCAPI_SHOW_SDK_NEXTHOP_ALL:
        sub_type = req->param[1];
        detail = req->param[2];
        switch (sub_type)
        {
            case LCAPI_SHOW_SDK_NH_TYPE_MCAST:
            case LCAPI_SHOW_SDK_NH_TYPE_BRGUC:
            case LCAPI_SHOW_SDK_NH_TYPE_IPUC:
            case LCAPI_SHOW_SDK_NH_TYPE_MPLS:
            case LCAPI_SHOW_SDK_NH_TYPE_ECMP:
            case LCAPI_SHOW_SDK_NH_TYPE_ILOOP:
            case LCAPI_SHOW_SDK_NH_TYPE_RSPAN:
            case LCAPI_SHOW_SDK_NH_TYPE_DOWNMEP:
            case LCAPI_SHOW_SDK_NH_TYPE_MAX:
                sys_humber_nh_dump_all(sub_type, detail);
            break;
            
        default:
            break;
        }
        break;

    case LCAPI_SHOW_SDK_NEXTHOP_PRIV_OFFSET_POOL:
        sub_type = req->param[1];
        break;

    case LCAPI_SHOW_SDK_NEXTHOP_BY_NHID:
        sub_type = req->param[1];
        detail = req->param[2];
        nhid = req->param[3];
        switch (sub_type)
        {
        case LCAPI_SHOW_SDK_NH_TYPE_MCAST:
            sys_humber_nh_dump_mcast(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_BRGUC:
            sys_humber_nh_dump_brguc(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_IPUC:
            sys_humber_nh_dump_ipuc(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_MPLS:
            sys_humber_nh_dump_mpls(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_ECMP:
            sys_humber_nh_dump_ecmp(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_ILOOP:
            sys_humber_nh_dump_iloop(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_RSPAN:
            sys_humber_nh_dump_rspan(nhid, detail);
            break;
            
        case LCAPI_SHOW_SDK_NH_TYPE_DOWNMEP:
            sys_humber_nh_dump_downmep(nhid, detail);
            break;
            
        default:
            break;
        }
        break;

    default:
        break;
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : lcm_dump_sdk_alloc(lcapi_show_req_t* req)
 * Purpose      : The function dump sdk alloc database and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_dump_sdk_alloc(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;
    
    switch (req->param[0])
    {
    case LCAPI_SHOW_SDK_ALLOC_INFO:
        ret = sys_humber_show_alloc_info();
        break;

    default:
        break;
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}

int32 
lcm_dump_sdk_master(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    sys_l2_master_t* p_l2 = pl2_master;
    sys_ipuc_master_t* p_l3 = p_ipuc_master;

    CTCLIB_DUMP_OUT("L2 master\n");
    CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
    CTCLIB_DUMP_OUT("max_fid_value      : %-8d\n", p_l2->max_fid_value);
    CTCLIB_DUMP_OUT("hash_bit_num       : %-8d\n", p_l2->hash_bit_num);
    CTCLIB_DUMP_OUT("offset_pool_num    : %-8d\n", p_l2->offset_pool_num);
    CTCLIB_DUMP_OUT("sw_hash_tbl_size   : %-8d\n", p_l2->sw_hash_tbl_size);
    CTCLIB_DUMP_OUT("hash_base          : %-8d\n", p_l2->hash_base);
    CTCLIB_DUMP_OUT("tcam_base          : %-8d\n", p_l2->tcam_base);
    CTCLIB_DUMP_OUT("max_sram_size      : %-8d\n", p_l2->max_sram_size);
    CTCLIB_DUMP_OUT("asic_hash_size     : %-8d\n", p_l2->asic_hash_size);
    CTCLIB_DUMP_OUT("do_hash_count      : %-8d\n", p_l2->do_hash_count);

    CTCLIB_DUMP_OUT("\n");
    CTCLIB_DUMP_OUT("L3 master                     %-8s %-8s\n", "IPv4", "IPv6");
    CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
    CTCLIB_DUMP_OUT("cpu_rpf            : %-8d\n", p_l3->cpu_rpf);
    CTCLIB_DUMP_OUT("is_ipucsa_allocated: %-8d  %-8d\n", p_l3->is_ipucsa_allocated[CTC_IP_VER_4], p_l3->is_ipucsa_allocated[CTC_IP_VER_6]);    
    CTCLIB_DUMP_OUT("sa_table_id        :          %-8d %-8d\n", p_l3->sa_table_id[CTC_IP_VER_4], p_l3->sa_table_id[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("da_table_id        :          %-8d %-8d\n", p_l3->da_table_id[CTC_IP_VER_4], p_l3->da_table_id[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("key_table_id       :          %-8d %-8d\n", p_l3->key_table_id[CTC_IP_VER_4], p_l3->key_table_id[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("hashkey_table_id   :          %-8d %-8d\n", p_l3->hashkey_table_id[CTC_IP_VER_4], p_l3->hashkey_table_id[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("hashkey_type       :          %-8d %-8d\n", p_l3->hashkey_type[CTC_IP_VER_4], p_l3->hashkey_type[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("hash_base          :          %-8d %-8d\n", p_l3->hash_base[CTC_IP_VER_4], p_l3->hash_base[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("tcam_base          :          %-8d %-8d\n", p_l3->tcam_base[CTC_IP_VER_4], p_l3->tcam_base[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("max_vrfid          :          %-8d %-8d\n", p_l3->max_vrfid[CTC_IP_VER_4], p_l3->max_vrfid[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("max_mask_len       :          %-8d %-8d\n", p_l3->max_mask_len[CTC_IP_VER_4], p_l3->max_mask_len[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("info_size          :          %-8d %-8d\n", p_l3->info_size[CTC_IP_VER_4], p_l3->info_size[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("version_en         :          %-8d %-8d\n", p_l3->version_en[CTC_IP_VER_4], p_l3->version_en[CTC_IP_VER_6]);
    CTCLIB_DUMP_OUT("asic_hash_en       :          %-8d %-8d\n", p_l3->asic_hash_en[CTC_IP_VER_4], p_l3->asic_hash_en[CTC_IP_VER_6]);
    
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

#ifdef FOAM_SUPPORT /* Added by kcao 2011-05-13 */
int32 
lcm_dump_foam_show_reg(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 reg_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    char* reg_name = NULL;
    foam_registers_t* reg_ptr = NULL;
    foam_fields_t* fld_ptr = NULL;
    uint32 reg_idx = 0;
    uint32 fld_idx = 0;
    uint32 first_flag = TRUE;
    char regname[LCAPI_SHOW_BUF_SIZE] = {0};
    
    all = req->param[1];
    detail = req->param[2];
    
    if (!all)
    {
        reg_name = req->buf;
        if((ret = diag_foam_getid_bystr(REGISTER_ID, reg_name, &reg_id)) == 0)
        {
            CTCLIB_DUMP_OUT("%% Not found %s\n", reg_name);
            return LCM_E_SUCCESS;
        }
    }   

    for (reg_idx = 0; reg_idx < FOAM_MAX_REG_NUM; reg_idx++)
    {
        diag_foam_getstr_byid(REGISTER_ID, reg_idx, regname);
        reg_ptr = DRV_FOAM_REG_GET_INFOPTR(reg_idx);
        if (all || (reg_idx == reg_id))
        {
            if (detail || first_flag)
            {
                CTCLIB_DUMP_OUT("%-5s %-10s %-6s %-6s %-6s %-20s\n", 
                    "RegID", "Address", "Number", "DataSZ", "Fields", "Name");
                CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
                first_flag = FALSE;
            }
            CTCLIB_DUMP_OUT("%-5d 0x%08x %-6d %-6d %-6d %-20s\n",
                reg_idx, reg_ptr->hw_data_base, reg_ptr->max_index_num, reg_ptr->entry_size, 
                reg_ptr->num_fields, regname);

            if (detail)
            {
                CTCLIB_DUMP_OUT("%-5s %-5s %-6s %-4s %-4s %-30s\n", "RegID", "FldID", "Length", "Word", "Bit", "Name");
                for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
                {
                    fld_ptr = &(reg_ptr->ptr_fields[fld_idx]);
                    CTCLIB_DUMP_OUT("%-5d %-5d %-6d %-4d %-4d %-30s\n", reg_idx, fld_ptr->field_id, fld_ptr->len, 
                        fld_ptr->word_offset, fld_ptr->bit_offset, fld_ptr->field_name);
                }
                CTCLIB_DUMP_OUT("\n");
            }
        }
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

int32 
lcm_dump_foam_read_reg(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    char* reg_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 reg_id = 0;
    uint32 value = 0;
    uint32 num = 0;
    int32 ret = 0;
    foam_registers_t* reg_ptr = NULL;
    foam_fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 addr = 0;
    
    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    chip = current_external_chip_id;
    start_index = req->param[2];
    num = req->param[3];
    reg_name = req->buf;

    if((ret = diag_foam_getid_bystr(REGISTER_ID, reg_name, &reg_id)) == 0)
    {
        CTCLIB_DUMP_OUT("%% Not found %s\n", reg_name);
        return LCM_E_SUCCESS;
    }

    reg_ptr = DRV_FOAM_REG_GET_INFOPTR(reg_id);

    for (i = 0; i < num; i++)
    {
        index = start_index + i;
        if (index >= reg_ptr->max_index_num)
        {
            CTCLIB_DUMP_OUT("%% Index %d out-of-range %d\n", index, reg_ptr->max_index_num);
            break;
        }
        ret = drv_io_api[chip].drv_sram_reg_read(chip, reg_id, index, entry_data_buf);
        if (ret < 0)
        {
            CTCLIB_DUMP_OUT("%% Read index %d failed %d\n", index, ret);
            break;
        }
        
        addr  = reg_ptr->hw_data_base + index * reg_ptr->entry_size;
        CTCLIB_DUMP_OUT("%-6s %-10s %-10s Index(%d) Address(0x%08x)\n", "Field", "Value", "Name", index, addr);
        CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
        for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(reg_ptr->ptr_fields[fld_idx]);
            drv_foam_reg_field_get(reg_id, fld_ptr->field_id, entry_data_buf, &value);
            CTCLIB_DUMP_OUT("%-6d 0x%08x %-10s\n", fld_ptr->field_id, value, fld_ptr->field_name);
        }
        CTCLIB_DUMP_OUT("\n");
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS; 
}

int32 
lcm_dump_foam_show_tbl(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 tbl_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    char* tbl_name = NULL;
    foam_tables_t* tbl_ptr = NULL;
    foam_fields_t* fld_ptr = NULL;
    uint32 tbl_idx = 0;
    uint32 fld_idx = 0;
    uint32 first_flag = TRUE;
    char tblname[LCAPI_SHOW_BUF_SIZE] = {0};
    
    all = req->param[1];
    detail = req->param[2];

    if (!all)
    {
        tbl_name = req->buf;
        if((ret = diag_foam_getid_bystr(TABLE_ID, tbl_name, &tbl_id)) == 0)
        {
            CTCLIB_DUMP_OUT("%% Not found %s\n", tbl_name);
            return LCM_E_SUCCESS;
        }
    }   

    for (tbl_idx = 0; tbl_idx < FOAM_MAX_TBL_NUM; tbl_idx++)
    {
        diag_foam_getstr_byid(TABLE_ID, tbl_idx, tblname);
        tbl_ptr = DRV_FOAM_TBL_GET_INFOPTR(tbl_idx);
        if (all || (tbl_idx == tbl_id))
        {
            if (detail || first_flag)
            {
                CTCLIB_DUMP_OUT("%-5s %-10s %-10s %-6s %-6s %-6s %-6s %-20s\n", 
                    "TblID", "Address", "MaskAddr", "Number", "KeySZ", "DataSZ", "Fields", "Name");
                CTCLIB_DUMP_OUT("--------------------------------------------------------------------------------\n");
                first_flag = FALSE;
            }
    
            CTCLIB_DUMP_OUT("%-5d 0x%08x 0x%08x %-6d %-6d %-6d %-6d %-20s\n",
                tbl_idx, tbl_ptr->hw_data_base, tbl_ptr->hw_mask_base, tbl_ptr->max_index_num, 
                tbl_ptr->key_size, tbl_ptr->entry_size, tbl_ptr->num_fields, tblname);

            if (detail)
            {
                CTCLIB_DUMP_OUT("%-5s %-5s %-6s %-4s %-4s %-30s\n", "TblID", "FldID", "Length", "Word", "Bit", "Name");
                for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
                {
                    fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
                    CTCLIB_DUMP_OUT("%-5d %-5d %-6d %-4d %-4d %-30s\n", tbl_idx, fld_ptr->field_id, 
                        fld_ptr->len, fld_ptr->word_offset, fld_ptr->bit_offset, fld_ptr->field_name);
                }
                CTCLIB_DUMP_OUT("\n");
            } 
        }
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

int32 
lcm_dump_foam_read_tbl(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    uint32 entry_mask_buf[MAX_ENTRY_WORD];
    tbl_entry_t entry;
    char* tbl_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 tbl_id = 0;
    uint32 value = 0;
    uint32 mask = 0;
    uint32 num = 0;
    int32 ret = 0;
    foam_tables_t* tbl_ptr = NULL;
    foam_fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 addr = 0;
    
    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    sal_memset(entry_mask_buf, 0, sizeof(entry_mask_buf));    
    entry.data_entry = entry_data_buf;
    entry.mask_entry = entry_mask_buf;
    
    chip = current_external_chip_id;
    start_index = req->param[2];
    num = req->param[3];
    tbl_name = req->buf;

    if((ret = diag_foam_getid_bystr(TABLE_ID, tbl_name, &tbl_id)) == 0)
    {
        CTCLIB_DUMP_OUT("%% Not found %s\n", tbl_name);
        return LCM_E_SUCCESS;
    }

    tbl_ptr = DRV_FOAM_TBL_GET_INFOPTR(tbl_id);

    for (i = 0; i < num; i++)
    {
        index = start_index + i;
        if (index >= tbl_ptr->max_index_num)
        {
            CTCLIB_DUMP_OUT("%% Index %d out-of-range %d\n", index, tbl_ptr->max_index_num);
            break;
        }

        if ((tbl_id == DS_POLICER) || (tbl_id == DS_FORWARDING_STATS))
        {
            uint32 cmd;
            uint32 data_entry[MAX_ENTRY_WORD] = {0};
            cmd = DRV_IOR(IOC_TABLE, tbl_id, DRV_ENTRY_FLAG);
            ret = drv_tbl_ioctl(chip, index, cmd, data_entry);
		    drv_sram_tbl_ds_to_entry(tbl_id, data_entry, entry.data_entry);
        }
        else
        {
            if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
            {
                ret = drv_io_api[chip].drv_sram_tbl_read(chip, tbl_id, index, entry.data_entry);
            }
            else
            {
                ret = drv_io_api[chip].drv_tcam_tbl_read(chip, tbl_id, index, &entry);
            }
        }
        if (ret < 0)
        {
            CTCLIB_DUMP_OUT("%% Read index %d failed %d\n", index, ret);
            break;
        }
 
        if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
        {
            addr  = tbl_ptr->hw_data_base + index * tbl_ptr->entry_size;
            CTCLIB_DUMP_OUT("%-6s %-10s %-10s %-10s Index(%d) Address(0x%08x)\n", "Field", "Value", "Mask", "Name", index, addr);
        }
        else
        {
            CTCLIB_DUMP_OUT("%-6s %-10s %-10s %-10s Index(%d)\n", "Field", "Value", "Mask", "Name", index);
        }
        
        CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
            drv_foam_tbl_field_get(tbl_id, fld_ptr->field_id, entry.data_entry, &value);
            if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
            {
                CTCLIB_DUMP_OUT("%-6d 0x%08x %-10s %-10s\n", fld_ptr->field_id, value, "", fld_ptr->field_name);
            }
            else
            {
                drv_foam_tbl_field_get(tbl_id, fld_ptr->field_id, entry.mask_entry, &mask);
                CTCLIB_DUMP_OUT("%-6d 0x%08x 0x%08x %-10s\n", fld_ptr->field_id, value, mask, fld_ptr->field_name);
            }
        }
        CTCLIB_DUMP_OUT("\n");
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

int32 
lcm_dump_foam_write_reg_or_tbl(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    char* reg_name = NULL;
    uint8 chip = 0;
    int32 index = 0;
    uint32 reg_tbl_id = 0;
    uint32 value = 0;
    uint32 cmd = 0;
    int32 ret = 0;
    foam_registers_t* reg_ptr = NULL;
    foam_tables_t* tbl_ptr = NULL;
    foam_fields_t* fld_ptr = NULL;
    int32 fld_id = 0;
    int32 fld_idx = 0;
    int32 fld_ok = FALSE;
    uint32 max_index_num = 0;
    uint32 reg_or_tbl = (LCAPI_CHIP_ACCESS_W_REG == req->param[0]) ? REGISTER_ID : TABLE_ID;
    
    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    chip = current_external_chip_id;
    index = req->param[2];
    fld_id = req->param[3];
    value = req->param[4];
    reg_name = req->buf;
    
    if((ret = diag_foam_getid_bystr(reg_or_tbl, reg_name, &reg_tbl_id)) == 0)
    {
        CTCLIB_DUMP_OUT("%% Not found %s\n", reg_name);
        return LCM_E_SUCCESS;
    }

    if (REGISTER_ID == reg_or_tbl)
    {
        reg_ptr = DRV_FOAM_REG_GET_INFOPTR(reg_tbl_id);
        for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(reg_ptr->ptr_fields[fld_idx]);
            if (fld_ptr->field_id == fld_id)
            {
                fld_ok = TRUE;
                break;
            }
        }    
        max_index_num = reg_ptr->max_index_num;
    }
    else
    {
        tbl_ptr = DRV_FOAM_TBL_GET_INFOPTR(reg_tbl_id);
        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
            if (fld_ptr->field_id == fld_id)
            {
                fld_ok = TRUE;
                break;
            }
        }    
        max_index_num = tbl_ptr->max_index_num;
    }

    if (!fld_ok)
    {
        CTCLIB_DUMP_OUT("%% %s has no field %d\n", reg_name, fld_id);
        return LCM_E_SUCCESS; 
    }
    if (index >= max_index_num)
    {
        CTCLIB_DUMP_OUT("%% Index %d out-of-range %d\n", index, max_index_num);
        return LCM_E_SUCCESS; 
    }

    if (REGISTER_ID == reg_or_tbl)
    {
        cmd = DRV_IOW(IOC_REG, reg_tbl_id, fld_id);
        ret = drv_reg_ioctl(chip, index, cmd, &value);
    }
    else
    {
        cmd = DRV_IOW(IOC_TABLE, reg_tbl_id, fld_id);
        ret = drv_tbl_ioctl(chip, index, cmd, &value);
    }
    if (ret < 0)
    {
        CTCLIB_DUMP_OUT("%% Write %s index %d failed %d\n", (REGISTER_ID == reg_or_tbl)? "tbl":"reg", index, ret);
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS; 
}
#endif /* !FOAM_SUPPORT */

int32 
lcm_dump_chip_show_reg(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 reg_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    char* reg_name = NULL;
    registers_t* reg_ptr = NULL;
    fields_t* fld_ptr = NULL;
    uint32 reg_idx = 0;
    uint32 fld_idx = 0;
    uint32 first_flag = TRUE;
    char regname[LCAPI_SHOW_BUF_SIZE] = {0};
    
    all = req->param[1];
    detail = req->param[2];

    if (!all)
    {
        reg_name = req->buf;
        if((ret = diag_getid_bystr(REGISTER_ID, reg_name, &reg_id)) == 0)
        {
            CTCLIB_DUMP_OUT("%% Not found %s\n", reg_name);
            return LCM_E_SUCCESS;
        }
    }   

    for (reg_idx = 0; reg_idx < MAX_REG_NUM; reg_idx++)
    {
        diag_getstr_byid(REGISTER_ID, reg_idx, regname);
        reg_ptr = DRV_REG_GET_INFOPTR(reg_idx);
        if (all || (reg_idx == reg_id))
        {
            if (detail || first_flag)
            {
                CTCLIB_DUMP_OUT("%-5s %-10s %-6s %-6s %-6s %-20s\n", 
                    "RegID", "Address", "Number", "DataSZ", "Fields", "Name");
                CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
                first_flag = FALSE;
            }
            CTCLIB_DUMP_OUT("%-5d 0x%08x %-6d %-6d %-6d %-20s\n",
                reg_idx, reg_ptr->hw_data_base, reg_ptr->max_index_num, reg_ptr->entry_size, 
                reg_ptr->num_fields, regname);

            if (detail)
            {
                CTCLIB_DUMP_OUT("%-5s %-5s %-6s %-4s %-4s %-30s\n", "RegID", "FldID", "Length", "Word", "Bit", "Name");
                for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
                {
                    fld_ptr = &(reg_ptr->ptr_fields[fld_idx]);
                    CTCLIB_DUMP_OUT("%-5d %-5d %-6d %-4d %-4d %-30s\n", reg_idx, fld_idx, fld_ptr->len, 
                        fld_ptr->word_offset, fld_ptr->bit_offset, fld_ptr->field_name);
                }
                CTCLIB_DUMP_OUT("\n");
            }
        }
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

int32 
lcm_dump_chip_read_reg(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    char* reg_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 reg_id = 0;
    uint32 value = 0;
    uint32 num = 0;
    int32 ret = 0;
    registers_t* reg_ptr = NULL;
    fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 addr = 0;
    uint8 chip_num = 0;
    
    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    chip = req->param[1];
    start_index = req->param[2];
    num = req->param[3];
    reg_name = req->buf;

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        CTCLIB_DUMP_OUT("%% Chip %d out-of-range\n", chip);
        return LCM_E_SUCCESS;
    }

    if((ret = diag_getid_bystr(REGISTER_ID, reg_name, &reg_id)) == 0)
    {
        CTCLIB_DUMP_OUT("%% Not found %s\n", reg_name);
        return LCM_E_SUCCESS;
    }

    reg_ptr = DRV_REG_GET_INFOPTR(reg_id);

    for (i = 0; i < num; i++)
    {
        index = start_index + i;
        if (index >= reg_ptr->max_index_num)
        {
            CTCLIB_DUMP_OUT("%% Index %d out-of-range %d\n", index, reg_ptr->max_index_num);
            break;
        }
        ret = drv_io_api[chip].drv_sram_reg_read(chip, reg_id, index, entry_data_buf);
        if (ret < 0)
        {
            CTCLIB_DUMP_OUT("%% Read index %d failed %d\n", index, ret);
            break;
        }
        
        addr  = reg_ptr->hw_data_base + index * reg_ptr->entry_size;
        CTCLIB_DUMP_OUT("%-6s %-10s %-10s Index(%d) Address(0x%08x)\n", "Field", "Value", "Name", index, addr);
        CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
        for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(reg_ptr->ptr_fields[fld_idx]);
            drv_reg_field_get(reg_id, fld_idx, entry_data_buf, &value);
            CTCLIB_DUMP_OUT("%-6d 0x%08x %-10s\n", fld_idx, value, fld_ptr->field_name);
        }
        CTCLIB_DUMP_OUT("\n");
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS; 
}

int32 
lcm_dump_chip_show_tbl(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 tbl_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    char* tbl_name = NULL;
    tables_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    uint32 tbl_idx = 0;
    uint32 fld_idx = 0;
    uint32 first_flag = TRUE;
    char tblname[LCAPI_SHOW_BUF_SIZE] = {0};
    
    all = req->param[1];
    detail = req->param[2];

    if (!all)
    {
        tbl_name = req->buf;
        if((ret = diag_getid_bystr(TABLE_ID, tbl_name, &tbl_id)) == 0)
        {
            CTCLIB_DUMP_OUT("%% Not found %s\n", tbl_name);
            return LCM_E_SUCCESS;
        }
    }   

    for (tbl_idx = 0; tbl_idx < MAX_TBL_NUM; tbl_idx++)
    {
        diag_getstr_byid(TABLE_ID, tbl_idx, tblname);
        tbl_ptr = DRV_TBL_GET_INFOPTR(tbl_idx);
        if (all || (tbl_idx == tbl_id))
        {
            if (detail || first_flag)
            {
                CTCLIB_DUMP_OUT("%-5s %-10s %-10s %-6s %-6s %-6s %-6s %-20s\n", 
                    "TblID", "Address", "MaskAddr", "Number", "KeySZ", "DataSZ", "Fields", "Name");
                CTCLIB_DUMP_OUT("--------------------------------------------------------------------------------\n");
                first_flag = FALSE;
            }
    
            CTCLIB_DUMP_OUT("%-5d 0x%08x 0x%08x %-6d %-6d %-6d %-6d %-20s\n",
                tbl_idx, tbl_ptr->hw_data_base, tbl_ptr->hw_mask_base, tbl_ptr->max_index_num, 
                tbl_ptr->key_size, tbl_ptr->entry_size, tbl_ptr->num_fields, tblname);

            if (detail)
            {
                CTCLIB_DUMP_OUT("%-5s %-5s %-6s %-4s %-4s %-30s\n", "TblID", "FldID", "Length", "Word", "Bit", "Name");
                for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
                {
                    fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
                    CTCLIB_DUMP_OUT("%-5d %-5d %-6d %-4d %-4d %-30s\n", tbl_idx, fld_idx, 
                        fld_ptr->len, fld_ptr->word_offset, fld_ptr->bit_offset, fld_ptr->field_name);
                }
                CTCLIB_DUMP_OUT("\n");
            } 
        }
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

int32 
lcm_dump_chip_read_tbl(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    uint32 entry_mask_buf[MAX_ENTRY_WORD];
    tbl_entry_t entry;
    char* tbl_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 tbl_id = 0;
    uint32 value = 0;
    uint32 mask = 0;
    uint32 num = 0;
    int32 ret = 0;
    tables_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 addr = 0;
    uint8 chip_num = 0;
    
    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    sal_memset(entry_mask_buf, 0, sizeof(entry_mask_buf));    
    entry.data_entry = entry_data_buf;
    entry.mask_entry = entry_mask_buf;
    
    chip = req->param[1];
    start_index = req->param[2];
    num = req->param[3];
    tbl_name = req->buf;

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        CTCLIB_DUMP_OUT("%% Chip %d out-of-range\n", chip);
        return LCM_E_SUCCESS;
    }
    
    if((ret = diag_getid_bystr(TABLE_ID, tbl_name, &tbl_id)) == 0)
    {
        CTCLIB_DUMP_OUT("%% Not found %s\n", tbl_name);
        return LCM_E_SUCCESS;
    }

    tbl_ptr = DRV_TBL_GET_INFOPTR(tbl_id);

    for (i = 0; i < num; i++)
    {
        index = start_index + i;
        if (index >= tbl_ptr->max_index_num)
        {
            CTCLIB_DUMP_OUT("%% Index %d out-of-range %d\n", index, tbl_ptr->max_index_num);
            break;
        }

        if ((tbl_id == DS_POLICER) || (tbl_id == DS_FORWARDING_STATS))
        {
            uint32 cmd;
            uint32 data_entry[MAX_ENTRY_WORD] = {0};
            cmd = DRV_IOR(IOC_TABLE, tbl_id, DRV_ENTRY_FLAG);
            ret = drv_tbl_ioctl(chip, index, cmd, data_entry);
		    drv_sram_tbl_ds_to_entry(tbl_id, data_entry, entry.data_entry);
        }
        else
        {
            if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
            {
                ret = drv_io_api[chip].drv_sram_tbl_read(chip, tbl_id, index, entry.data_entry);
            }
            else
            {
                ret = drv_io_api[chip].drv_tcam_tbl_read(chip, tbl_id, index, &entry);
            }
        }
        if (ret < 0)
        {
            CTCLIB_DUMP_OUT("%% Read index %d failed %d\n", index, ret);
            break;
        }
 
        if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
        {
            addr  = tbl_ptr->hw_data_base + index * tbl_ptr->entry_size;
            CTCLIB_DUMP_OUT("%-6s %-10s %-10s %-10s Index(%d) Address(0x%08x)\n", "Field", "Value", "Mask", "Name", index, addr);
        }
        else
        {
            CTCLIB_DUMP_OUT("%-6s %-10s %-10s %-10s Index(%d)\n", "Field", "Value", "Mask", "Name", index);
        }
        
        CTCLIB_DUMP_OUT("----------------------------------------------------------------------\n");
        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
            drv_tbl_field_get(tbl_id, fld_idx, entry.data_entry, &value);
            if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
            {
                CTCLIB_DUMP_OUT("%-6d 0x%08x %-10s %-10s\n", fld_idx, value, "", fld_ptr->field_name);
            }
            else
            {
                drv_tbl_field_get(tbl_id, fld_idx, entry.mask_entry, &mask);
                CTCLIB_DUMP_OUT("%-6d 0x%08x 0x%08x %-10s\n", fld_idx, value, mask, fld_ptr->field_name);
            }
        }
        CTCLIB_DUMP_OUT("\n");
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS;
}

int32 
lcm_dump_chip_write_reg_or_tbl(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    char* reg_name = NULL;
    uint8 chip = 0;
    int32 index = 0;
    uint32 reg_tbl_id = 0;
    uint32 value = 0;
    uint32 cmd = 0;
    int32 ret = 0;
    registers_t* reg_ptr = NULL;
    tables_t* tbl_ptr = NULL;
    int32 fld_id = 0;
    int32 fld_ok = FALSE;
    uint32 max_index_num = 0;
    uint32 reg_or_tbl = (LCAPI_CHIP_ACCESS_W_REG == req->param[0]) ? REGISTER_ID : TABLE_ID;
    uint8 chip_num = 0;
    
    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    chip = req->param[1];
    index = req->param[2];
    fld_id = req->param[3];
    value = req->param[4];
    reg_name = req->buf;
    
    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        CTCLIB_DUMP_OUT("%% Chip %d out-of-range\n", chip);
        return LCM_E_SUCCESS;
    }
    
    if((ret = diag_getid_bystr(reg_or_tbl, reg_name, &reg_tbl_id)) == 0)
    {
        CTCLIB_DUMP_OUT("%% Not found %s\n", reg_name);
        return LCM_E_SUCCESS;
    }

    if (REGISTER_ID == reg_or_tbl)
    {
        reg_ptr = DRV_REG_GET_INFOPTR(reg_tbl_id);
        if (fld_id < reg_ptr->num_fields)
        {
            fld_ok = TRUE;
        }
        max_index_num = reg_ptr->max_index_num;
    }
    else
    {
        tbl_ptr = DRV_TBL_GET_INFOPTR(reg_tbl_id);
        if (fld_id < tbl_ptr->num_fields)
        {
            fld_ok = TRUE;
        }
        max_index_num = tbl_ptr->max_index_num;
    }

    if (!fld_ok)
    {
        CTCLIB_DUMP_OUT("%% %s has no field %d\n", reg_name, fld_id);
        return LCM_E_SUCCESS; 
    }
    if (index >= max_index_num)
    {
        CTCLIB_DUMP_OUT("%% Index %d out-of-range %d\n", index, max_index_num);
        return LCM_E_SUCCESS; 
    }

    if (REGISTER_ID == reg_or_tbl)
    {
        cmd = DRV_IOW(IOC_REG, reg_tbl_id, fld_id);
        ret = drv_reg_ioctl(chip, index, cmd, &value);
    }
    else
    {
        cmd = DRV_IOW(IOC_TABLE, reg_tbl_id, fld_id);
        ret = drv_tbl_ioctl(chip, index, cmd, &value);
    }
    if (ret < 0)
    {
        CTCLIB_DUMP_OUT("%% Write %s index %d failed %d\n", (REGISTER_ID == reg_or_tbl)? "tbl":"reg", index, ret);
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return LCM_E_SUCCESS; 
}

#ifdef FOAM_SUPPORT  /* Added by kcao 2011-05-13 */
/*****************************************************************************
 * Name         : lcm_dump_foam(lcapi_show_req_t* req)
 * Purpose      : The function dump foam sdk alloc database and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_dump_foam(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;
    
    switch (req->param[0])
    {
    case LCAPI_CHIP_ACCESS_S_REG:
        ret = lcm_dump_foam_show_reg(req);
        break;

    case LCAPI_CHIP_ACCESS_R_REG:
        ret = lcm_dump_foam_read_reg(req);
        break;
    
    case LCAPI_CHIP_ACCESS_S_TBL:
        ret = lcm_dump_foam_show_tbl(req);
        break;

    case LCAPI_CHIP_ACCESS_R_TBL:
        ret = lcm_dump_foam_read_tbl(req);
        break;

    case LCAPI_CHIP_ACCESS_W_REG:
    case LCAPI_CHIP_ACCESS_W_TBL:
        ret = lcm_dump_foam_write_reg_or_tbl(req);
        break;
        
    default:
        break;
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}

static int32
_lcm_dump_foam_chan(ctc_foam_chan_key_t* p_chan)
{
    CTCLIB_DUMP_OUT( "oam_type:         %d \n", p_chan->oam_type);
    switch (p_chan->oam_type)
    {
    case FOAM_OAM_TYPE_ETH_OAM:
        CTCLIB_DUMP_OUT( "vid:              %d \n", p_chan->key.ethoam.vid);
        CTCLIB_DUMP_OUT( "gport:            %d \n", p_chan->key.ethoam.gport);
        break;
    case FOAM_OAM_TYPE_MPLS_SECTION:
        CTCLIB_DUMP_OUT( "l3if_id:          %d \n", p_chan->key.l3if_id);
        break;
    case FOAM_OAM_TYPE_MPLS_LABEL:
        CTCLIB_DUMP_OUT( "label:            %d \n", p_chan->key.label);
        break;
    case FOAM_OAM_TYPE_BFD:
        CTCLIB_DUMP_OUT( "discriminator:    %d \n", p_chan->key.bfd);
        break;
    default:
        break;
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_dump_foam_rmep_ds(ctc_foam_ds_mep_t* p_mep)
{
    ctc_foam_ds_eth_rmep_t* p_eth_ds_rmep = NULL;

    CTCLIB_DUMP_OUT( "########## Remote MEP DS ########## \n");
            
    switch (p_mep->oam_type)
    {
    case FOAM_OAM_TYPE_ETH_OAM:
    case FOAM_OAM_TYPE_MPLS_SECTION:
    case FOAM_OAM_TYPE_MPLS_LABEL:
        p_eth_ds_rmep = &p_mep->ds.eth_rmep;
        CTCLIB_DUMP_OUT( "mep_index:        %d \n", p_eth_ds_rmep->mep_index);
        CTCLIB_DUMP_OUT( "last_port_status: %d \n", p_eth_ds_rmep->last_port_status);
        CTCLIB_DUMP_OUT( "last_intf_status: %d \n", p_eth_ds_rmep->last_intf_status);
        CTCLIB_DUMP_OUT( "last_rdi:         %d \n", p_eth_ds_rmep->last_rdi);
        CTCLIB_DUMP_OUT( "first_pkt_rx:     %d \n", p_eth_ds_rmep->first_pkt_rx);
        CTCLIB_DUMP_OUT( "d_loc:            %d \n", p_eth_ds_rmep->d_loc);
        CTCLIB_DUMP_OUT( "d_unexp_period:   %d \n", p_eth_ds_rmep->d_unexp_period);
        CTCLIB_DUMP_OUT( "seq_fail_count:   %d \n", p_eth_ds_rmep->seq_fail_count);
        CTCLIB_DUMP_OUT( "mac_sa:           %02X:%02X:%02X:%02X:%02X:%02X \n", 
            p_eth_ds_rmep->mac_sa[0], p_eth_ds_rmep->mac_sa[1], p_eth_ds_rmep->mac_sa[2],
            p_eth_ds_rmep->mac_sa[3], p_eth_ds_rmep->mac_sa[4], p_eth_ds_rmep->mac_sa[5]);
        break;
    case FOAM_OAM_TYPE_BFD:
        break;
    default:
        break;
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_dump_foam_lmep_ds(ctc_foam_ds_mep_t* p_mep)
{
    ctc_foam_ds_eth_lmep_t* p_eth_ds_lmep = NULL;

    CTCLIB_DUMP_OUT( "########## Local MEP DS ########## \n");
            
    switch (p_mep->oam_type)
    {
    case FOAM_OAM_TYPE_ETH_OAM:
    case FOAM_OAM_TYPE_MPLS_SECTION:
    case FOAM_OAM_TYPE_MPLS_LABEL:
        p_eth_ds_lmep = &p_mep->ds.eth_lmep;
        CTCLIB_DUMP_OUT( "rmep_last_rdi:    %d \n", p_eth_ds_lmep->rmep_last_rdi);
        CTCLIB_DUMP_OUT( "present_rdi:      %d \n", p_eth_ds_lmep->present_rdi);
        CTCLIB_DUMP_OUT( "d_unexp_mep:      %d \n", p_eth_ds_lmep->d_unexp_mep);
        CTCLIB_DUMP_OUT( "d_mismerge:       %d \n", p_eth_ds_lmep->d_mismerge);
        CTCLIB_DUMP_OUT( "d_meg_lvl:        %d \n", p_eth_ds_lmep->d_meg_lvl);
        break;
    case FOAM_OAM_TYPE_BFD:
        break;
    default:
        break;
    }
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : lcm_dump_foam_mep(lcapi_show_req_t* req)
 * Purpose      : The function dump foam mep database and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_dump_foam_mep(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    ctc_foam_ds_mep_t ctc_ds_mep;
    ctc_foam_ds_mep_t* p_mep = &ctc_ds_mep;
    ctc_foam_db_lmep_t* p_db_lmep = NULL;
    ctc_foam_db_rmep_t* p_db_rmep = NULL;    
    int32 ret = 0;
    
    sal_memset(&ctc_ds_mep, 0, sizeof(ctc_ds_mep));
    ret = ctc_foam_oam_get_mep(req->param[0], p_mep);
    if (ret < 0)
    {
        CTCLIB_DUMP_OUT("%% dump mep failed, ret %d\n", ret);
    }
    else
    {
    
        CTCLIB_DUMP_OUT( "is_rmep: %d \n", p_mep->is_rmep);
        CTCLIB_DUMP_OUT( "oam_type: %d \n", p_mep->oam_type);

        if (p_mep->is_rmep)
        {
            p_db_rmep = &p_mep->db.rmep;
            CTCLIB_DUMP_OUT( "########## Remote MEP DB ########## \n");
            _lcm_dump_foam_chan(&p_db_rmep->chan);
            CTCLIB_DUMP_OUT( "rmep_id:          %d \n", p_db_rmep->rmep_id);
            CTCLIB_DUMP_OUT( "rmep_index:       %d \n", p_db_rmep->rmep_index);
            CTCLIB_DUMP_OUT( "mep_index:        %d \n", p_db_rmep->mep_index);
            CTCLIB_DUMP_OUT( "seq_num_en:       %d \n", p_db_rmep->seq_num_en);
            CTCLIB_DUMP_OUT( "active:           %d \n", p_db_rmep->active);
            CTCLIB_DUMP_OUT( "\n");
            _lcm_dump_foam_rmep_ds(p_mep);
        }
        else
        {
            p_db_lmep = &p_mep->db.lmep;
            CTCLIB_DUMP_OUT( "########## Local MEP DB ########## \n");
            _lcm_dump_foam_chan(&p_db_lmep->chan);
            CTCLIB_DUMP_OUT( "mep_id:           %d \n", p_db_lmep->mep_id);
            CTCLIB_DUMP_OUT( "ma_index:         %d \n", p_db_lmep->ma_index);
            CTCLIB_DUMP_OUT( "mep_index:        %d \n", p_db_lmep->mep_index);
            CTCLIB_DUMP_OUT( "key_index:        %d \n", p_db_lmep->key_index); 
            CTCLIB_DUMP_OUT( "gport:          0x%x \n", p_db_lmep->gport);
            CTCLIB_DUMP_OUT( "nh_id:            %d \n", p_db_lmep->nh_id);
            CTCLIB_DUMP_OUT( "aps_group_id:     %d \n", p_db_lmep->aps_group_id);       
            CTCLIB_DUMP_OUT( "level:            %d \n", p_db_lmep->level);
            CTCLIB_DUMP_OUT( "ccm_interval:     %d \n", p_db_lmep->ccm_interval);
            CTCLIB_DUMP_OUT( "ccm_enable:       %d \n", p_db_lmep->ccm_enable);
            CTCLIB_DUMP_OUT( "dm_enable:        %d \n", p_db_lmep->dm_enable);
            CTCLIB_DUMP_OUT( "aps_enable:       %d \n", p_db_lmep->aps_enable);
            CTCLIB_DUMP_OUT( "seq_num_en:       %d \n", p_db_lmep->seq_num_en);
            CTCLIB_DUMP_OUT( "active:           %d \n", p_db_lmep->active);
            CTCLIB_DUMP_OUT( "defect_priority:  %d \n", p_db_lmep->defect_priority);
            CTCLIB_DUMP_OUT( "is_up_mep:        %d \n", p_db_lmep->is_up_mep);
            CTCLIB_DUMP_OUT( "is_p2p:           %d \n", p_db_lmep->is_p2p);
            CTCLIB_DUMP_OUT( "is_untag:         %d \n", p_db_lmep->is_untag);
            CTCLIB_DUMP_OUT( "is_unrov:         %d \n", p_db_lmep->is_unrov);
            CTCLIB_DUMP_OUT( "is_aps:           %d \n", p_db_lmep->is_aps);
            CTCLIB_DUMP_OUT( "ttl:              %d \n", p_db_lmep->ttl);
            CTCLIB_DUMP_OUT( "rmep_cnt:         %d \n", p_db_lmep->rmep_cnt);
            CTCLIB_DUMP_OUT( "\n");
            _lcm_dump_foam_lmep_ds(p_mep);
        }
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}
#endif /* !FOAM_SUPPORT */

/*****************************************************************************
 * Name         : lcm_dump_chip(lcapi_show_req_t* req)
 * Purpose      : The function dump sdk alloc database and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_dump_chip(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;
    
    switch (req->param[0])
    {
    case LCAPI_CHIP_ACCESS_S_REG:
        ret = lcm_dump_chip_show_reg(req);
        break;

    case LCAPI_CHIP_ACCESS_R_REG:
        ret = lcm_dump_chip_read_reg(req);
        break;
    
    case LCAPI_CHIP_ACCESS_S_TBL:
        ret = lcm_dump_chip_show_tbl(req);
        break;

    case LCAPI_CHIP_ACCESS_R_TBL:
        ret = lcm_dump_chip_read_tbl(req);
        break;

    case LCAPI_CHIP_ACCESS_W_REG:
    case LCAPI_CHIP_ACCESS_W_TBL:
        ret = lcm_dump_chip_write_reg_or_tbl(req);
        break;
        
    default:
        break;
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}

/*SYSTEM_MODIFIED by sunw for bug 14736, 2011-4-13*/
int32 
lcm_dump_sdk_show_mem_info(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
	mem_show_bucket_used_count();
#endif /* _GLB_ENABLE_DBGSHOW_ */

        return LCM_E_SUCCESS;
}

int32 
lcm_dump_sdk_show_mem_by_type(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 mem_type = req->param[1];
    bool detail = req->param[2];
    if (mem_type == MEM_TYPE_MAX)
    {
        for (mem_type = MEM_SYSTEM_MODULE; mem_type < MEM_TYPE_MAX; mem_type++)
        {
            mem_mgr_check_mtype(mem_type , detail );
        }
    }
    else
    {
        mem_mgr_check_mtype(mem_type , detail );
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}


/*****************************************************************************
 * Name         : lcm_dump_sdk_mem(lcapi_show_req_t* req)
 * Purpose      : The function dump sdk memory information and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_dump_sdk_mem(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;
    
    switch (req->param[0])
    {
    case LCAPI_SHOW_SDK_MEM_INFO:
        ret = lcm_dump_sdk_show_mem_info(req);
        break;
    case LCAPI_SHOW_SDK_MEM_BY_TYPE:
	    ret = lcm_dump_sdk_show_mem_by_type(req);
        break;
  
    default:
        break;
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}


/*****************************************************************************
 * Name         : lcm_dump_sdk_mem(lcapi_show_req_t* req)
 * Purpose      : The function dump sdk memory information and send them up to lcsh
 * Input        : lcapi_show_req_t* req, request data
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
static const char* _lcm_dump_get_opf_str(enum sys_humber_opf_type type)
{
        enum sys_humber_opf_type tmp_type;
        for(tmp_type = 0; tmp_type < MAX_OPF_TBL_NUM; tmp_type++)
        {
            if (type == lcm_dump_opf_arg_list[tmp_type].arg_num)
            {
                return lcm_dump_opf_arg_list[tmp_type].arg_name;
            }
        }
        return "Unknown opf";
}
int32 
lcm_dump_sdk_opf(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    sys_humber_opf_t opf;
    kal_memset(&opf,0,sizeof(sys_humber_opf_t));

    opf.pool_type = req->param[0];
    opf.pool_index = req->param[1];
    if(req->param[2])
    {
        enum sys_humber_opf_type tmp_type;
        for(tmp_type = 0; tmp_type < MAX_OPF_TBL_NUM; tmp_type++)
        {
            CTC_DEBUG_OUT_DUMP("\n\n\n====================================\n");
            CTC_DEBUG_OUT_DUMP("Print opf alloc information:%s, index :%d \n",
                _lcm_dump_get_opf_str(tmp_type),opf.pool_index);
            CTC_DEBUG_OUT_DUMP("-----------------------------------\n");
            opf.pool_type = tmp_type;
            sys_humber_opf_print_alloc_info(&opf);
        }
    }
    else
    {
            CTC_DEBUG_OUT_DUMP("\n\n\n====================================\n");
            CTC_DEBUG_OUT_DUMP("Print opf alloc information:%s, index :%d \n",
            _lcm_dump_get_opf_str(opf.pool_type),opf.pool_index);
        CTC_DEBUG_OUT_DUMP("-----------------------------------\n");
        sys_humber_opf_print_alloc_info(&opf);
    }
    
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}

int32
lcm_dump_sdk_get_queue_shape_id(uint16 queue_id)
{
    int32 queue_shape_id = -1;
    uint32 field = 0;
    uint32 cmd = 0;
    uint32 ret = 0;
    
    /* write profile id to asic */
    switch (queue_id % 4)
    {
        case 0:
            field = DS_QUEUE_SHAPE_PROFILE_ID_QUE_SHP_PROF_ID0;
            break;

        case 1:
            field = DS_QUEUE_SHAPE_PROFILE_ID_QUE_SHP_PROF_ID1;
            break;

        case 2:
            field = DS_QUEUE_SHAPE_PROFILE_ID_QUE_SHP_PROF_ID2;
            break;

        default:
            field = DS_QUEUE_SHAPE_PROFILE_ID_QUE_SHP_PROF_ID3;
            break;
    }

    cmd = DRV_IOR(IOC_TABLE, DS_QUEUE_SHAPE_PROFILE_ID, field);
    ret = drv_tbl_ioctl(0, (uint32)queue_id/4, cmd, &queue_shape_id);

    return queue_shape_id;
}

int32 
lcm_dump_sdk_show_queue_info(lcapi_show_req_t* req)
{
    ctc_queue_type_t type = 0;
    uint16 id = 0;
    uint8 offset = 0;
    uint16 queue_id = 0;
    int32 queue_shape_id = -1;

    type = CTC_QUEUE_TYPE_SERVICE_INGRESS;
    type = CTC_QUEUE_TYPE_NETWORK_EGRESS;
    type = CTC_QUEUE_TYPE_SERVICE_EGRESS;
    
    type = CTC_QUEUE_TYPE_ILOOP;
    id = SYS_ILOOP_CHANNEL_ID;
    offset = 0;
    sys_humber_queue_get_queue_id(type, id, offset, &queue_id);
    queue_shape_id = lcm_dump_sdk_get_queue_shape_id(queue_id);
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("CTC_QUEUE_TYPE_ILOOP\n");
    CTC_DEBUG_OUT_DUMP("%-6s %-6s %-6s %-6s %-8s\n", "Type", "ID", "Offset", "Queue", "ShapeID");
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("%-6d %-6d %-6d %-6d %-8d\n", type, id, offset, queue_id, queue_shape_id);
    CTC_DEBUG_OUT_DUMP("\n");
    
    type = CTC_QUEUE_TYPE_NORMAL_CPU;
    id = SYS_CPU_CHANNEL_ID;
    offset = 0;
    sys_humber_queue_get_queue_id(type, id, offset, &queue_id);
    queue_shape_id = lcm_dump_sdk_get_queue_shape_id(queue_id);
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("CTC_QUEUE_TYPE_NORMAL_CPU\n");
    CTC_DEBUG_OUT_DUMP("%-6s %-6s %-6s %-6s %-8s\n", "Type", "ID", "Offset", "Queue", "ShapeID");
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("%-6d %-6d %-6d %-6d %-8d\n", type, id, offset, queue_id, queue_shape_id);
    CTC_DEBUG_OUT_DUMP("\n");
    
    type = CTC_QUEUE_TYPE_OAM;
    id = SYS_OAM_CHANNEL_ID;
    offset = 0;
    sys_humber_queue_get_queue_id(type, id, offset, &queue_id);
    queue_shape_id = lcm_dump_sdk_get_queue_shape_id(queue_id);
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("CTC_QUEUE_TYPE_OAM\n");
    CTC_DEBUG_OUT_DUMP("%-6s %-6s %-6s %-6s %-8s\n", "Type", "ID", "Offset", "Queue", "ShapeID");
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("%-6d %-6d %-6d %-6d %-8d\n", type, id, offset, queue_id, queue_shape_id);
    CTC_DEBUG_OUT_DUMP("\n");
    
    type = CTC_QUEUE_TYPE_ELOOP;
    id = SYS_ELOOP_CHANNEL_ID;
    offset = 0;
    sys_humber_queue_get_queue_id(type, id, offset, &queue_id);
    queue_shape_id = lcm_dump_sdk_get_queue_shape_id(queue_id);
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("CTC_QUEUE_TYPE_ELOOP\n");
    CTC_DEBUG_OUT_DUMP("%-6s %-6s %-6s %-6s %-8s\n", "Type", "ID", "Offset", "Queue", "ShapeID");
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("%-6d %-6d %-6d %-6d %-8d\n", type, id, offset, queue_id, queue_shape_id);
    CTC_DEBUG_OUT_DUMP("\n");
    
    type = CTC_QUEUE_TYPE_EXCP_CPU;
    offset = 0;
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    CTC_DEBUG_OUT_DUMP("CTC_QUEUE_TYPE_EXCP_CPU\n");
    CTC_DEBUG_OUT_DUMP("%-6s %-6s %-6s %-6s %-8s\n", "Type", "ID", "Offset", "Queue", "ShapeID");
    CTC_DEBUG_OUT_DUMP("------------------------------------\n");
    for (id = 0; id < MAX_CTC_EXCEPTION; id++)
    {
        sys_humber_queue_get_queue_id(type, id, offset, &queue_id);
        queue_shape_id = lcm_dump_sdk_get_queue_shape_id(queue_id);
        CTC_DEBUG_OUT_DUMP("%-6d %-6d %-6d %-6d %-8d\n", type, id, offset, queue_id, queue_shape_id);
    }
    CTC_DEBUG_OUT_DUMP("\n");
    
    type = CTC_QUEUE_TYPE_FABRIC;    
    type = CTC_QUEUE_TYPE_INTERNAL_PORT;
    type = CTC_QUEUE_TYPE_SGMAC_PORT_TO_CPU;
    type = CTC_QUEUE_TYPE_SGMAC_CPU_TO_CPU;

    return LCM_E_SUCCESS;
}

int32 
lcm_dump_sdk_queue(lcapi_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    lcm_dump_sdk_show_queue_info(req);
#endif /* _GLB_ENABLE_DBGSHOW_ */

    return LCM_E_SUCCESS;
}
#endif
