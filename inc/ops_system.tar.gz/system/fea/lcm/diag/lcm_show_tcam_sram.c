 /**
  @file show_sram_table.c
  
  @date 2010-10-20
  
  @version v1.0
 
  The file contains all show sram module
 */
/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "lcm_mgt.h"
#include "lcm_debug.h"
#include "lcm_srv.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_opf.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_chip.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_ftm.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_ipuc.h"
// TODO: Commented by xgu for compile, 20121120   #include "ctc_avl_tree.h"
// TODO: Commented by xgu for compile, 20121120   #include "ctc_hash.h"
// TODO: Commented by xgu for compile, 20121120   #include <drv_io.h> 
#include "lcapi_lcm_lcsh_msg.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_l2_fdb.h"
// TODO: Commented by xgu for compile, 20121120   #include "ctc_api.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_ipuc_db.h"
// TODO: Commented by xgu for compile, 20121120   #include "ctc_humber_chip.h"
#include "lcm_error.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_aclqos_label.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_nexthop_api.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_ipmc.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_ipmc_db.h"
// TODO: Commented by xgu for compile, 20121120   #include "sys_humber_l2_fdb.h"
/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/
extern lcm_srv_cb_t lcm_lcsh_srv_cb_tbl[];
// TODO: Commented by xgu for compile, 20121120   
#if 0
extern struct sys_humber_opf_master_s *p_opf_master;
extern sys_ipuc_master_t* p_ipuc_master;
extern sys_ipuc_db_master_t* p_ipuc_db_master;
extern ctc_hash_t* p_aclqos_label_hash;
extern sys_l2_master_t* pl2_master;
extern sys_ipmc_db_master_t *p_ipmc_db_master;
/****************************************************************************
*  
* struct
*
*****************************************************************************/
struct diag_l2_mac_specify_entry_s
{
    uint32 index;
    sys_l2_node_t* p_l2_node;
};
typedef struct diag_l2_mac_specify_entry_s diag_l2_mac_specify_entry_t;
#endif

/****************************************************************************
*  
* Function
*
*****************************************************************************/
/******************************************************************************
 * Name         : _lcm_usrid_key(FILE *pf,diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_usrid_key(FILE *pf,diag_usrid_tcam_entries_resp_t* resp)
{
    switch( resp->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.mac.key.user_id_label);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.mac.key.mac_sa_upper);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.mac.key.mac_sa_lower >>16);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.mac.key.mac_sa_lower & 0xffff);
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.mac.mask.user_id_label);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.mac.mask.mac_sa_upper);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.mac.mask.mac_sa_lower >>16);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.mac.mask.mac_sa_lower & 0xffff);
            break;

        case DIAG_USRID_KEY_TYPE_IPV4:
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.key.user_id_label);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.key.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.key.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.key.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.key.l4source_port);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.key.ip_sa>>24) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.key.ip_sa>>16) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.key.ip_sa>>8) & 0xff);
            sal_fprintf(pf, " %.02hx", resp->tcam_entry.ipv4.key.ip_sa & 0xff);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv4.key.mac_sa_upper);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv4.key.mac_sa_lower >>16);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.ipv4.key.mac_sa_lower & 0xffff);
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.mask.user_id_label);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.mask.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.mask.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.mask.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.mask.l4source_port);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.mask.ip_sa>>24) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.mask.ip_sa>>16) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.mask.ip_sa>>8) & 0xff);
            sal_fprintf(pf, " %.02hx", resp->tcam_entry.ipv4.mask.ip_sa & 0xff);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv4.mask.mac_sa_upper);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv4.mask.mac_sa_lower >>16);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.ipv4.mask.mac_sa_lower & 0xffff);
            break;

        case DIAG_USRID_KEY_TYPE_IPV6:

            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.key.user_id_label);               
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.key.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.key.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.key.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.key.l4source_port);
            sal_fprintf(pf, " %.08x.", ((resp->tcam_entry.ipv6.key.ip_sa103_to72 >>24))
                                                | ((resp->tcam_entry.ipv6.key.ip_sa127_to104)<<8) );
            sal_fprintf(pf, " %.08x.", (resp->tcam_entry.ipv6.key.ip_sa71_to64 )
                                                | ((resp->tcam_entry.ipv6.key.ip_sa103_to72 )<<8)); 
            sal_fprintf(pf, " %.08x.", resp->tcam_entry.ipv6.key.ip_sa63_to32 );
            sal_fprintf(pf, " %.08x", resp->tcam_entry.ipv6.key.ip_sa31_to0 );
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv6.key.mac_sa_upper);
            sal_fprintf (pf, " %.04hx.", resp->tcam_entry.ipv6.key.mac_sa_lower >>16);
            sal_fprintf (pf, " %.04hx", resp->tcam_entry.ipv6.key.mac_sa_lower & 0xffff);

            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.mask.user_id_label);               
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.mask.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.mask.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.mask.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.mask.l4source_port);
            sal_fprintf(pf, " %.08x.", ((resp->tcam_entry.ipv6.mask.ip_sa103_to72 >>24) & 0xff)
                                                | ((resp->tcam_entry.ipv6.mask.ip_sa127_to104)<<8));
            sal_fprintf(pf, " %.08x.", (resp->tcam_entry.ipv6.mask.ip_sa71_to64 &0xff)
                                                | ((resp->tcam_entry.ipv6.mask.ip_sa103_to72 & 0xffffff)<<8));
            sal_fprintf(pf, " %.08x.", resp->tcam_entry.ipv6.mask.ip_sa63_to32 );
            sal_fprintf(pf, " %.08x", resp->tcam_entry.ipv6.mask.ip_sa31_to0 );
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv6.mask.mac_sa_upper);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv6.mask.mac_sa_lower >>16);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.ipv6.mask.mac_sa_lower & 0xffff);
            break;

        case DIAG_USRID_KEY_TYPE_VLAN:
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.key.user_id_label);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.key.from_sgmac);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.key.table_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.key.global_src_port);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.key.svlan_id);
            sal_fprintf(pf, " %-9x" , resp->tcam_entry.vlan.key.customer_id);
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.mask.user_id_label);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.mask.from_sgmac);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.mask.table_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.mask.global_src_port);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.mask.svlan_id);
            sal_fprintf(pf, " %-9x" , resp->tcam_entry.vlan.mask.customer_id);
            break;

        default:
            sal_fprintf(pf, "The invalid usrid key type .");
            break;
    }
}


/******************************************************************************
 * Name         : _lcm_usrid_key_head(FILE *pf,diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_usrid_key_head(FILE* pf,diag_usrid_tcam_entries_resp_t* resp)
{
    sal_fprintf(pf, "%-7s" , " Index");
    switch( resp->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, "%-6s" , "Label");
            sal_fprintf(pf, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_IPV4:
            sal_fprintf(pf, "%-6s" , "Label");
            sal_fprintf(pf, "%-6s" , "CVID");
            sal_fprintf(pf, "%-6s" , "SVID");
            
            sal_fprintf(pf, "%-5s" , "4DP");
            sal_fprintf(pf, "%-5s" , "4SP");
            sal_fprintf(pf, "%-15s" , "IPSA");
            sal_fprintf(pf, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_IPV6:
            sal_fprintf(pf, "%-6s" , "Label");
            sal_fprintf(pf, "%-6s" , "CVID");
            sal_fprintf(pf, "%-6s" , "SVID");
            
            sal_fprintf(pf, "%-5s" , "4DP");
            sal_fprintf(pf, "%-5s" , "4SP");
            sal_fprintf(pf, "%-39s" , "IPv6SA");          
            sal_fprintf(pf, "%-17s" , "MacSA");
            break;
        case DIAG_USRID_KEY_TYPE_VLAN:
            sal_fprintf(pf, "%-5s" , "Label");
            sal_fprintf(pf, "%-5s" , "FRS");
            sal_fprintf(pf, "%-5s" , "TBL");
            sal_fprintf(pf, "%-6s" , "GSP");
            sal_fprintf(pf, "%-6s" , "SVID");
            sal_fprintf(pf, "%-10s" , "CID");
            break;
        default:
            sal_fprintf(pf, "The invalude usrid key type.");
            break;
    }
    return ;
}

/******************************************************************************
 * Name         : _lcm_usrid_ds_head(FILE *pf,diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_usrid_ds_head(FILE* pf,diag_usrid_tcam_entries_resp_t* resp)
{
    sal_fprintf(pf, "%-5s" , " Ds");
    sal_fprintf(pf, "%-5s" , "ASVD");
    sal_fprintf(pf, "%-5s" , "UVP");
    sal_fprintf(pf, "%-4s" , "EXE");
    sal_fprintf(pf, "%-4s" , "BAl");
    sal_fprintf(pf, "%-4s" , "BDE");
    sal_fprintf(pf, "%-4s" , "SCP");
    sal_fprintf(pf, "%-4s" , "FPV");
    sal_fprintf(pf, "%-4s" , "SQS");
    sal_fprintf(pf, "%-4s" , "VPT");
    sal_fprintf(pf, "%-5s" , "BDD");
    sal_fprintf(pf, "%-4s" , "BMA");
    sal_fprintf(pf, "%-4s" , "BD");    
    sal_fprintf(pf, " \n"); 
   
    return ;
}

/******************************************************************************
 * Name         : _lcm_usrid_ds(FILE *pf,diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_usrid_ds(FILE *pf,diag_usrid_tcam_entries_resp_t* resp)
{
    switch( resp->key_type)
   {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.mac.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.vpls_port_type);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04hx" , resp->tcam_entry.mac.ds.binding_datah);
            sal_fprintf(pf, " %.08hx" , resp->tcam_entry.mac.ds.binding_datal);
            break;

        case DIAG_USRID_KEY_TYPE_IPV4:   
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.vpls_port_type);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04hx" , resp->tcam_entry.ipv4.ds.binding_datah);
            sal_fprintf(pf, " %.08hx" , resp->tcam_entry.ipv4.ds.binding_datal);
            break;

        case DIAG_USRID_KEY_TYPE_IPV6:               
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.vpls_port_type);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04hx" , resp->tcam_entry.ipv6.ds.binding_datah);
            sal_fprintf(pf, " %.08hx" , resp->tcam_entry.ipv6.ds.binding_datal);
            break;

        case DIAG_USRID_KEY_TYPE_VLAN:                   
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.vpls_port_type);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04hx" , resp->tcam_entry.vlan.ds.binding_datah);
            sal_fprintf(pf, " %.08hx" , resp->tcam_entry.vlan.ds.binding_datal);
            break;

        default:
            sal_fprintf(pf,  "The invalude usrid key type.");
            break;
        }
}


/******************************************************************************
 * Name         : lcm_wr_file_usrid(diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : this function get a set of entries  form tcam 
 * Input        : diag_usrid_tcam_entries_resp_t* resp- para point 
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
 int32
lcm_wr_file_usrid(diag_usrid_tcam_entries_resp_t* resp)
{
    FILE *pf = NULL;
    
    pf = sal_fopen(SHOW_TCAM_USRID_INFO_FILE,"a+");
    if (NULL == pf) 
    {
        LCM_LOG_ERR("Open /filename failed.\n");
        return LCM_E_FILE_OPEN;
    }

    _lcm_usrid_key_head(pf,resp);

    sal_fprintf(pf, " \n"); 
    sal_fprintf( pf," %-5d", resp->tcam_entry.index& 0xffff);

    _lcm_usrid_key(pf,resp);

    sal_fprintf(pf, " \n");

    _lcm_usrid_ds_head(pf,resp);

    sal_fprintf(pf, "%-4s" , "");

    _lcm_usrid_ds(pf,resp);
    
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);

    return LCM_E_SUCCESS;
}


/******************************************************************************
 * Name         : _lcm_wr_acl_entry_mac(FILE *pf,  diag_acl_tcam_entry_t* resp)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_acl_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_wr_acl_entry_mac(FILE *pf,  diag_acl_tcam_entry_t* resp)
{
    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-3x", resp->mac_key.acl_labell | (resp->mac_key.acl_labelh<<4));
    sal_fprintf(pf, " %-3x", resp->mac_key.stag_cfi);
    sal_fprintf(pf, " %-3x", resp->mac_key.stag_cos);
    sal_fprintf(pf, " %-3x", resp->mac_key.ctag_cfi);
    sal_fprintf(pf, " %-3x", resp->mac_key.ctag_cos);
    sal_fprintf(pf, " %-3x", resp->mac_key.layer3_type);
    sal_fprintf(pf, " %-3x", resp->mac_key.layer2_type);
    sal_fprintf(pf, " %-4x", resp->mac_key.svlan_id);
    sal_fprintf(pf, " %-4x", (resp->mac_key.cvlan_id4to0 | resp->mac_key.cvlan_id11to5 << 5));

    sal_fprintf(pf, " %.04hx.", (resp->mac_key.mac_dah & 0xffff ));
    sal_fprintf(pf, " %.04hx.", ((resp->mac_key.mac_dal >>16) & 0xffff));
    sal_fprintf(pf, " %.04hx", resp->mac_key.mac_dal  & 0xffff);

    sal_fprintf(pf, " %.04hx.", (resp->mac_key.mac_sah &  0xffff));
    sal_fprintf(pf, " %.04hx.", ((resp->mac_key.mac_sal >>16) & 0xffff));
    sal_fprintf(pf, " %.04hx", resp->mac_key.mac_sal  & 0xffff);
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-5s", "mask");
    
    sal_fprintf(pf, " %-3x", resp->mac_mask.acl_labell | (resp->mac_mask.acl_labelh<<4));
    sal_fprintf(pf, " %-3x", resp->mac_mask.stag_cfi);
    sal_fprintf(pf, " %-3x", resp->mac_mask.stag_cos);
    sal_fprintf(pf, " %-3x", resp->mac_mask.ctag_cfi);
    sal_fprintf(pf, " %-3x", resp->mac_mask.ctag_cos);
    sal_fprintf(pf, " %-3x", resp->mac_mask.layer3_type);
    sal_fprintf(pf, " %-3x", resp->mac_mask.layer2_type);
    sal_fprintf(pf, " %-4x", resp->mac_mask.svlan_id);
    sal_fprintf(pf, " %-4x", (resp->mac_mask.cvlan_id4to0 | resp->mac_mask.cvlan_id11to5 << 5));
    
    sal_fprintf(pf, " %.04hx.", (resp->mac_mask.mac_dah & 0xffff));
    sal_fprintf(pf, " %.04hx.", ((resp->mac_mask.mac_dal >>16) & 0xffff));
    sal_fprintf(pf, " %.04hx", resp->mac_mask.mac_dal  & 0xffff);

    sal_fprintf(pf, " %.04hx.", (resp->mac_mask.mac_sah & 0xffff));
    sal_fprintf(pf, " %.04hx.", ((resp->mac_mask.mac_sal >>16) & 0xffff));
    sal_fprintf(pf, " %.04hx", resp->mac_mask.mac_sal  & 0xffff);
    sal_fprintf(pf, "\n"); 
}


/******************************************************************************
 * Name         : _lcm_wr_acl_entry_ipv4(FILE *pf,  diag_acl_tcam_entry_t* resp )
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_acl_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_wr_acl_entry_ipv4(FILE *pf,  diag_acl_tcam_entry_t* resp )
{
    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-2x", resp->ipv4_key.acl_label_lower | (resp->ipv4_key.acl_label_upper << 4));
    sal_fprintf(pf, " %-2x", resp->ipv4_key.routed_packet);
    sal_fprintf(pf, " %-3x", resp->ipv4_key.is_tcp);
    sal_fprintf(pf, " %-3x", resp->ipv4_key.is_udp);
    sal_fprintf(pf, " %-2x", resp->ipv4_key.is_application);
    sal_fprintf(pf, " %-3x", resp->ipv4_key.ip_header_error);
    sal_fprintf(pf, " %-3x", resp->ipv4_key.ip_options);
    sal_fprintf(pf, " %-2x", resp->ipv4_key.dscp);
    sal_fprintf(pf, " %-6x", resp->ipv4_key.l4info_mapped);
    sal_fprintf(pf, " %-2x", resp->ipv4_key.frag_info);
    sal_fprintf(pf, " %-4x", resp->ipv4_key.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->ipv4_key.l4_source_port);
    
    sal_fprintf(pf, " %.04hx.", resp->ipv4_key.macda_upper & 0xffff );
    sal_fprintf(pf, " %.04hx.", (resp->ipv4_key.macda_lower >>16) & 0xffff);
    sal_fprintf(pf, " %.04hx", resp->ipv4_key.macda_lower  & 0xffff);
    
    sal_fprintf(pf, " %.04hx.", resp->ipv4_key.mac_sa_upper & 0xffff);
    sal_fprintf(pf, " %.04hx.", (resp->ipv4_key.mac_sa_lower >>16) & 0xffff);
    sal_fprintf(pf, " %.04hx", resp->ipv4_key.mac_sa_lower  & 0xffff);
    
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_key.ip_da>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_key.ip_da>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_key.ip_da>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->ipv4_key.ip_da & 0xff);
    
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_key.ip_sa>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_key.ip_sa>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_key.ip_sa>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->ipv4_key.ip_sa & 0xff);
    
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-5s", "mask");
    
    sal_fprintf(pf, " %-2x", resp->ipv4_mask.acl_label_lower | (resp->ipv4_mask.acl_label_upper << 4));
    sal_fprintf(pf, " %-2x", resp->ipv4_mask.routed_packet);
    sal_fprintf(pf, " %-3x", resp->ipv4_mask.is_tcp);
    sal_fprintf(pf, " %-3x", resp->ipv4_mask.is_udp);
    sal_fprintf(pf, " %-2x", resp->ipv4_mask.is_application);
    sal_fprintf(pf, " %-3x", resp->ipv4_mask.ip_header_error);
    sal_fprintf(pf, " %-3x", resp->ipv4_mask.ip_options);
    sal_fprintf(pf, " %-2x", resp->ipv4_mask.dscp);
    sal_fprintf(pf, " %-6x", resp->ipv4_mask.l4info_mapped);
    sal_fprintf(pf, " %-2x", resp->ipv4_mask.frag_info);
    sal_fprintf(pf, " %-4x", resp->ipv4_mask.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->ipv4_mask.l4_source_port);
    
    sal_fprintf(pf, " %.04hx.", resp->ipv4_mask.macda_upper & 0xffff);
    sal_fprintf(pf, " %.04hx.", (resp->ipv4_mask.macda_lower >>16) & 0xffff);
    sal_fprintf(pf, " %.04hx", resp->ipv4_mask.macda_lower  & 0xffff);
    
    sal_fprintf(pf, " %.04hx.", resp->ipv4_mask.mac_sa_upper & 0xffff);
    sal_fprintf(pf, " %.04hx.", (resp->ipv4_mask.mac_sa_lower >>16) & 0xffff);
    sal_fprintf(pf, " %.04hx", resp->ipv4_mask.mac_sa_lower  & 0xffff);
    
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_mask.ip_da>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_mask.ip_da>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_mask.ip_da>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->ipv4_mask.ip_da & 0xff);
    
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_mask.ip_sa>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_mask.ip_sa>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->ipv4_mask.ip_sa>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->ipv4_mask.ip_sa & 0xff);
    sal_fprintf(pf, "\n"); 
}

/******************************************************************************
 * Name         : _lcm_wr_acl_entry_mpls(FILE *pf,  diag_acl_tcam_entry_t* resp )
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_acl_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_wr_acl_entry_mpls(FILE *pf,  diag_acl_tcam_entry_t* resp )
{
    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-3x", resp->mpls_key.is_ip_key);
    sal_fprintf(pf, " %-2x", resp->mpls_key.route_pkt);
    sal_fprintf(pf, " %-2x", resp->mpls_key.is_mpls_key);
    sal_fprintf(pf, " %-2x", resp->mpls_key.is_label);

    sal_fprintf(pf, " %-3x", resp->mpls_key.cos);
    sal_fprintf(pf, " %-3x", resp->mpls_key.layer2_type);
    sal_fprintf(pf, " %-4x", resp->mpls_key.stag_cfi);

    sal_fprintf(pf, " %-4x", resp->mpls_key.stag_cos);
    sal_fprintf(pf, " %-4x", resp->mpls_key.ctag_cfi);
    sal_fprintf(pf, " %-4x", resp->mpls_key.ctag_cos);

    sal_fprintf(pf, " %-2x", resp->mpls_key.qos_label);
    sal_fprintf(pf, " %-3x", resp->mpls_key.l2_qos_label);
    sal_fprintf(pf, " %-3x", resp->mpls_key.l3_qos_label);
    sal_fprintf(pf, " %-2x", (resp->mpls_key.acl_label_upper << 4 | resp->mpls_key.acl_label_upper));
    sal_fprintf(pf, " %-3x", resp->mpls_key.cvlan_id);
    sal_fprintf(pf, " %-3x", resp->mpls_key.svlan_id);
    sal_fprintf(pf, " %-4x", (resp->mpls_key.tableid3 <<12
                                |resp->mpls_key.tableid2 << 8
                                | resp->mpls_key.tableid1<< 4 
                                | resp->mpls_key.tableid0));


    sal_fprintf(pf, " %08x", (resp->mpls_key.mpls_label331to28 << 28 | resp->mpls_key.mpls_label327to0));
    sal_fprintf(pf, " %08x", resp->mpls_key.mpls_label2);
    sal_fprintf(pf, " %08x", resp->mpls_key.mpls_label1);
    sal_fprintf(pf, " %08x", resp->mpls_key.mpls_label0);

    sal_fprintf(pf, " %.04hx.", resp->mpls_key.mac_sa_upper& 0xffff);
    sal_fprintf(pf, " %.04hx.", (resp->mpls_key.mac_sa_lower>>16) & 0xffff);
    sal_fprintf(pf, " %.04hx", resp->mpls_key.mac_sa_lower& 0xffff);


    sal_fprintf(pf, " %.04hx.", resp->mpls_key.macda_upper & 0xffff);
    sal_fprintf(pf, " %.04hx.", (resp->mpls_key.macda_lower >>16) & 0xffff);
    sal_fprintf(pf, " %.04hx", resp->mpls_key.macda_lower & 0xffff);

    sal_fprintf(pf,"\n");
}
/******************************************************************************
 * Name         : _lcm_wr_acl_entry_ipv6(FILE *pf,  diag_acl_tcam_entry_t* resp )
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_acl_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_wr_acl_entry_ipv6(FILE *pf,  diag_acl_tcam_entry_t* resp )
{
    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-5x", resp->ipv6_key.ipv6_flow_label);
    sal_fprintf(pf, " %-2x", resp->ipv6_key.ipv6_extension_headers);
    sal_fprintf(pf, " %-2x", resp->ipv6_key.routed_packet);
    sal_fprintf(pf, " %-3x", resp->ipv6_key.is_tcp);
    sal_fprintf(pf, " %-2x", resp->ipv6_key.dscp);
    sal_fprintf(pf, " %-4x", resp->ipv6_key.l4info_mapped);
    sal_fprintf(pf, " %-4x", resp->ipv6_key.l4_destport);
    sal_fprintf(pf, " %-4x", resp->ipv6_key.l4_destport);
    sal_fprintf(pf, " %-2x", (resp->ipv6_key.acl_label_lower 
                                        | (resp->ipv6_key.acl_label_middle << 4) 
                                        | (resp->ipv6_key.acl_label_upper << 6)));
    sal_fprintf(pf, " %-3x", resp->ipv6_key.ip_head_error);
    sal_fprintf(pf, " %-3x", resp->ipv6_key.ip_options);
    sal_fprintf(pf, " %-3x", resp->ipv6_key.is_udp);
    sal_fprintf(pf, " %-2x", resp->ipv6_key.is_application);
    sal_fprintf(pf, " %-2x", resp->ipv6_key.frag_info);
    
    sal_fprintf(pf, " %.08x.", (((resp->ipv6_key.ip_da103to72>>24)& 0xff) |  (resp->ipv6_key.ip_da127to104 << 8)));
    sal_fprintf(pf, " %.08x.", ((resp->ipv6_key.ip_da71to64 & 0xff) | (resp->ipv6_key.ip_da103to72 << 8)));
    sal_fprintf(pf, " %.08x.", resp->ipv6_key.ip_da63to32 );
    sal_fprintf(pf, " %.08x", resp->ipv6_key.ip_da31to0 );
    
    sal_fprintf(pf, " %.08x.", (((resp->ipv6_key.ip_sa103to72>>24)& 0xff) 
                                        |  ((resp->ipv6_key.ip_sa127to104 << 8)&0xffffff00)));
    sal_fprintf(pf, " %.08x.", ((resp->ipv6_key.ip_sa71to64 & 0xffffff00) | (resp->ipv6_key.ip_sa103to72 << 8)));
    sal_fprintf(pf, " %.08x.", resp->ipv6_key.ip_sa63to32 );
    sal_fprintf(pf, " %.08x", resp->ipv6_key.ip_sa31to0 );
    
    sal_fprintf(pf, " %-4x", (resp->ipv6_key.l4destport_or_l4info5to0 | (resp->ipv6_key.l4destport_or_l4info15to6 <<6)));
    sal_fprintf(pf, " %-4x", (resp->ipv6_key.l4_source_port3to0 | (resp->ipv6_key.l4_source_port11to4 <<4) 
                                            | (resp->ipv6_key.l4_source_port15to12 <<12)));
    sal_fprintf(pf, " \n"); 

    sal_fprintf(pf, " %-5s", "mask");
    sal_fprintf(pf, " %-5x", resp->ipv6_mask.ipv6_flow_label);
    sal_fprintf(pf, " %-2x", resp->ipv6_mask.ipv6_extension_headers);
    sal_fprintf(pf, " %-2x", resp->ipv6_mask.routed_packet);
    sal_fprintf(pf, " %-3x", resp->ipv6_mask.is_tcp);
    sal_fprintf(pf, " %-2x", resp->ipv6_mask.dscp);
    sal_fprintf(pf, " %-4x", resp->ipv6_mask.l4info_mapped);
    sal_fprintf(pf, " %-4x", resp->ipv6_mask.l4_destport);
    sal_fprintf(pf, " %-4x", resp->ipv6_mask.l4_destport);
    sal_fprintf(pf, " %-2x", (resp->ipv6_mask.acl_label_lower 
                                        | (resp->ipv6_mask.acl_label_middle << 4) 
                                        | (resp->ipv6_mask.acl_label_upper << 6)));
    sal_fprintf(pf, " %-3x", resp->ipv6_mask.ip_head_error);
    sal_fprintf(pf, " %-3x", resp->ipv6_mask.ip_options);
    sal_fprintf(pf, " %-3x", resp->ipv6_mask.is_udp);
    sal_fprintf(pf, " %-2x", resp->ipv6_mask.is_application);
    sal_fprintf(pf, " %-2x", resp->ipv6_mask.frag_info);
    
    sal_fprintf(pf, " %.08x.", (((resp->ipv6_mask.ip_da103to72>>24)& 0xff) |  (resp->ipv6_mask.ip_da127to104 << 8)));
    sal_fprintf(pf, " %.08x.", ((resp->ipv6_mask.ip_da71to64 & 0xff) | (resp->ipv6_mask.ip_da103to72 << 8)));
    sal_fprintf(pf, " %.08x.", resp->ipv6_mask.ip_da63to32 );
    sal_fprintf(pf, " %.08x", resp->ipv6_mask.ip_da31to0 );
    
    sal_fprintf(pf, " %.08x.", (((resp->ipv6_mask.ip_sa103to72>>24)& 0xff) |  ((resp->ipv6_mask.ip_sa127to104 << 8)&0xffffff00)));
    sal_fprintf(pf, " %.08x.", ((resp->ipv6_mask.ip_sa71to64 & 0xff) | (resp->ipv6_mask.ip_sa103to72 << 8)));
    sal_fprintf(pf, " %.08x.", resp->ipv6_mask.ip_sa63to32 );
    sal_fprintf(pf, " %.08x", resp->ipv6_mask.ip_sa31to0 );
    
    sal_fprintf(pf, " %-4x", (resp->ipv6_mask.l4destport_or_l4info5to0 | (resp->ipv6_mask.l4destport_or_l4info15to6 <<6)));
    sal_fprintf(pf, " %-4x", (resp->ipv6_mask.l4_source_port3to0 
                                            | (resp->ipv6_mask.l4_source_port11to4 <<4) 
                                            | (resp->ipv6_mask.l4_source_port15to12 <<12)));
    sal_fprintf(pf,"\n");
}

/******************************************************************************
 * Name         : _lcm_wr_pbr_entry_ipv4(FILE *pf,  diag_acl_tcam_entry_t* resp )
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_acl_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void 
_lcm_wr_pbr_entry_ipv4(FILE *pf,  diag_acl_tcam_entry_t* resp )
{
    sal_fprintf(pf, " %-7d", resp->index);
    sal_fprintf(pf, " %-6d", resp->pbr_ipv4_key.pbr_label);
    sal_fprintf(pf, " %-6x", resp->pbr_ipv4_key.dscp);
    sal_fprintf(pf, " %-12x", resp->pbr_ipv4_key.l4info_mapped);
    sal_fprintf(pf, " %-12x", resp->pbr_ipv4_key.l4_dest_port);
    sal_fprintf(pf, " %-6x", resp->pbr_ipv4_key.l4_source_port);
    sal_fprintf(pf, " %-6x", resp->pbr_ipv4_key.is_tcp);
    sal_fprintf(pf, " %-6x", resp->pbr_ipv4_key.is_udp);
    sal_fprintf(pf, " %-10x", resp->pbr_ipv4_key.frag_info);
    sal_fprintf(pf, " %-8x", resp->pbr_ipv4_key.layer4_type);
    sal_fprintf(pf, " %-15x", resp->pbr_ipv4_key.ip_sa);
    sal_fprintf(pf, " %-15x", resp->pbr_ipv4_key.ip_da);

    sal_fprintf(pf,"\n");
}


/******************************************************************************
 * Name         : _lcm_acl_or_qos_wr_file(diag_acl_tcam_get_req_t* req,diag_acl_tcam_entry_t* resp)
 * Purpose      : this function write  entries  to tcam 
 * Input        : diag_acl_tcam_get_req_t* req
                     diag_acl_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_acl_or_qos_wr_file(diag_acl_tcam_get_req_t* req,diag_acl_tcam_entry_t* resp)
{
    FILE* pf = NULL;
    diag_acl_tcam_entry_t* res = NULL;
    
    res = (diag_acl_tcam_entry_t *)resp;
    
    pf = sal_fopen(SHOW_TCAM_ACL_INFO_FILE,"a+");
    if (NULL == pf) 
    {
        LCM_LOG_ERR("Open [SHOW_TCAM_ACL_INFO_FILE] failed.\n");
        return LCM_E_FILE_OPEN;
    }
    
    switch(req->key_type)
    {
        case DIAG_ACLQOS_KEY_MAC:
            _lcm_wr_acl_entry_mac( pf, (diag_acl_tcam_entry_t*)resp);
            break;
        case DIAG_ACLQOS_KEY_IPV4:
            _lcm_wr_acl_entry_ipv4( pf, (diag_acl_tcam_entry_t*)resp);
            break;
        case DIAG_ACLQOS_KEY_MPLS:
             _lcm_wr_acl_entry_mpls( pf, (diag_acl_tcam_entry_t*)resp);
             break;
        case DIAG_ACLQOS_KEY_IPV6:
             _lcm_wr_acl_entry_ipv6( pf, (diag_acl_tcam_entry_t*)resp);
             break;
        case DIAG_PBR_KEY_IPV4:
             _lcm_wr_pbr_entry_ipv4( pf, (diag_acl_tcam_entry_t*)resp);
             break;
        default:  
             break;
    }
    sal_fclose(pf);
    
    return LCM_E_SUCCESS;
}


/******************************************************************************
 * Name         : _lcm_all_dft_mac_wr_file_tcam(FILE *pf,diag_l2_tcam_entry_t *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
 int32
lcm_all_dft_mac_wr_file_tcam(FILE *pf,diag_l2_tcam_entry_t *res)
{
    diag_l2_tcam_entry_t *resp = (diag_l2_tcam_entry_t *)res;
     
    sal_fprintf(pf, " %-8d", resp->index);
    sal_fprintf(pf, " %-6x", resp->dsmackeydata.mapped_vlan_id);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeydata.mapped_mac_da_upper );
    sal_fprintf(pf, " %.04hx.", resp->dsmackeydata.mapped_mac_da_lower>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeydata.mapped_mac_da_lower& 0xffff );
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-8s" ,"mask" );
    sal_fprintf(pf, " %-6x", resp->dsmackeymask.mapped_vlan_id);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeymask.mapped_mac_da_upper );
    sal_fprintf(pf, " %.04hx.", resp->dsmackeymask.mapped_mac_da_lower>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeymask.mapped_mac_da_lower & 0xffff );
    sal_fprintf(pf, " \n"); 
    
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_all_mac_wr_file_tcam(FILE *pf,diag_l2_tcam_entry_t *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_all_mac_wr_file_tcam(FILE *pf,diag_l2_tcam_entry_t *res)
{
    diag_l2_tcam_entry_t *resp = (diag_l2_tcam_entry_t *)res;
     
    sal_fprintf(pf, " %-8d", resp->index);
    sal_fprintf(pf, " %-6x", resp->dsmackeydata.mapped_vlan_id);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeydata.mapped_mac_da_upper );
    sal_fprintf(pf, " %.04hx.", resp->dsmackeydata.mapped_mac_da_lower>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeydata.mapped_mac_da_lower& 0xffff );
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-8s" ,"mask" );
    sal_fprintf(pf, " %-6x", resp->dsmackeymask.mapped_vlan_id);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeymask.mapped_mac_da_upper );
    sal_fprintf(pf, " %.04hx.", resp->dsmackeymask.mapped_mac_da_lower>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeymask.mapped_mac_da_lower & 0xffff );
    sal_fprintf(pf, " \n"); 
    
    return LCM_E_SUCCESS;
}



/******************************************************************************
 * Name         : _lcm_all_ipuc_wr_file_v4(void *res,FILE *pf)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_all_ipuc_wr_file_v4(void *res,FILE *pf)
{
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *)res;

    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-4x", resp->keydata.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->keydata.l4_source_port);    
    sal_fprintf(pf, " %-4x", (resp->keydata.vrf_idl & 0x0f)|(resp->keydata.vrf_idh <<4));
    sal_fprintf(pf, " %-4x", resp->keydata.lkp_mode);    
    sal_fprintf(pf, " %-4x", resp->keydata.layer4_type);
    sal_fprintf(pf, " %08x", (resp->keydata.ip_sa));

    sal_fprintf(pf, " %-1s", " ");    
    sal_fprintf(pf, " %.02hx.", (resp->keydata.ip_da>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->keydata.ip_da>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->keydata.ip_da>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->keydata.ip_da & 0xff);

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-5s", "mask");
    sal_fprintf(pf, " %-4x", resp->keymask.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->keymask.l4_source_port);
    sal_fprintf(pf, " %-4x", (resp->keymask.vrf_idl & 0x0f)|(resp->keymask.vrf_idh <<4));
    sal_fprintf(pf, " %-4x", resp->keymask.lkp_mode);
    sal_fprintf(pf, " %-4x", resp->keymask.layer4_type);   
    sal_fprintf(pf, " %08x", (resp->keymask.ip_sa));

    sal_fprintf(pf, " %-1s", " ");    
    sal_fprintf(pf, " %.02hx.", (resp->keymask.ip_da>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->keymask.ip_da>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->keymask.ip_da>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->keymask.ip_da & 0xff);
    sal_fprintf(pf, "\n"); 
    return LCM_E_SUCCESS;
}
/******************************************************************************
 * Name         : _lcm_all_ipuc_wr_file_v6(void *res,FILE *pf)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     void* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_all_ipuc_wr_file_v6(void *res,FILE *pf)
{
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *)res;

    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-4x", resp->keydata_v6.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->keydata_v6.l4_source_port);
    sal_fprintf(pf, " %-4x", (resp->keydata_v6.vrf_idl & 0x0f)+(resp->keydata_v6.vrf_idh <<4));
    sal_fprintf(pf, " %08x.", (resp->keydata_v6.ip_sa4 << 8) + (resp->keydata_v6.ip_sa3>> 24));
    sal_fprintf(pf, "%08x.", (resp->keydata_v6.ip_sa3<<8) + (resp->keydata_v6.ip_sa2));
    sal_fprintf(pf, "%08x.", resp->keydata_v6.ip_sa1);
    sal_fprintf(pf, "%08x", resp->keydata_v6.ip_sa0);    
    sal_fprintf(pf, " %08x.", (resp->keydata_v6.ip_da4 << 8) + (resp->keydata_v6.ip_da3>> 24));
    sal_fprintf(pf, "%08x.", (resp->keydata_v6.ip_da3<<8) + (resp->keydata_v6.ip_da2));
    sal_fprintf(pf, "%08x.", resp->keydata_v6.ip_da1);
    sal_fprintf(pf, "%08x", resp->keydata_v6.ip_da0); 
    sal_fprintf(pf, " \n"); 
    
    sal_fprintf(pf, " %-5s", "mask");
    sal_fprintf(pf, " %-4x", resp->keymask_v6.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->keymask_v6.l4_source_port);
    sal_fprintf(pf, " %-4x", (resp->keymask_v6.vrf_idl & 0x0f)+(resp->keydata_v6.vrf_idh <<4));
    sal_fprintf(pf, " %08x.", (resp->keymask_v6.ip_sa4 << 8) + (resp->keymask_v6.ip_sa3>> 24));  
    sal_fprintf(pf, "%08x.", (resp->keymask_v6.ip_sa3<<8) + (resp->keymask_v6.ip_sa2));
    sal_fprintf(pf, "%08x.", resp->keymask_v6.ip_sa1);
    sal_fprintf(pf, "%08x", resp->keymask_v6.ip_sa0);
    sal_fprintf(pf, " %08x.", (resp->keymask_v6.ip_da4 << 8) + (resp->keymask_v6.ip_da3>> 24));  
    sal_fprintf(pf, "%08x.", (resp->keymask_v6.ip_da3<<8) + (resp->keymask_v6.ip_da2));
    sal_fprintf(pf, "%08x.", resp->keymask_v6.ip_da1);
    sal_fprintf(pf, "%08x", resp->keymask_v6.ip_da0); 
    sal_fprintf(pf, "\n"); 
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_all_ipuc_wr_file_hash_v4(void *res,FILE *pf)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     void* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_all_ipuc_wr_file_hash_v4(void *res,FILE *pf)
{
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *)res;

    sal_fprintf(pf, " %-6d", resp->index);
    sal_fprintf(pf, " %-7x", resp->dsip_hashkey_v4.key_vrfid);
    sal_fprintf(pf, " %.02hx.", (resp->dsip_hashkey_v4.key_mapped_ip>>24) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->dsip_hashkey_v4.key_mapped_ip>>16) & 0xff);
    sal_fprintf(pf, " %.02hx.", (resp->dsip_hashkey_v4.key_mapped_ip>>8) & 0xff);
    sal_fprintf(pf, " %.02hx", resp->dsip_hashkey_v4.key_mapped_ip & 0xff);
    sal_fprintf(pf, "\n"); 
    return LCM_E_SUCCESS;
}
/******************************************************************************
 * Name         : _lcm_all_ipuc_wr_file_hash_v6(void *res,FILE *pf)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     void* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_all_ipuc_wr_file_hash_v6(void *res,FILE *pf)
{
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *)res;

    sal_fprintf(pf, "\n"); 
    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-4x", ((resp->dsip_hashkey_v6.vrfid3 << 9)|(resp->dsip_hashkey_v6.vrfid2<< 6)
        |(resp->dsip_hashkey_v6.vrfid1<< 3)|resp->dsip_hashkey_v6.vrfid0));
    sal_fprintf(pf, "%08x.", resp->dsip_hashkey_v6.key_ipda3);
    sal_fprintf(pf, "%08x.", resp->dsip_hashkey_v6.key_ipda2);
    sal_fprintf(pf, "%08x.", resp->dsip_hashkey_v6.key_ipda1);
    sal_fprintf(pf, "%08x", resp->dsip_hashkey_v6.key_ipda0);    
    sal_fprintf(pf, "\n"); 
    return LCM_E_SUCCESS;
}
/******************************************************************************
 * Name         : _lcm_all_ipuc_wr_file(uint8 ver,void *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : uint8 ver - ip version
                     void* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_all_ipuc_wr_file(uint8 ver,void *res)
{
    FILE *pf = NULL;
    
    if (DIAG_IP_VER_4 == ver)
    {
        pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_V4,"a+");
        if (NULL == pf ) 
        {
            return LCM_E_FILE_OPEN;
        }
        
        _lcm_all_ipuc_wr_file_v4(res,pf);    
    }
    else
    {
        pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_V6,"a+");
        if (NULL == pf ) 
        {
            return LCM_E_FILE_OPEN;
        }
        
        _lcm_all_ipuc_wr_file_v6(res,pf);    
    }
    sal_fclose(pf);
    return LCM_E_SUCCESS;
}
/******************************************************************************
 * Name         : _lcm_all_ipuc_wr_hash_file(uint8 ver,void *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : uint8 ver - ip version
                     void* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_all_ipuc_wr_hash_file(uint8 ver,void *res)
{
    FILE *pf = NULL;

    if (DIAG_IP_VER_4 == ver)
    {
        pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_HASH_v4,"a");
        if (NULL == pf) 
        {
            return LCM_E_FILE_OPEN;
        }
        _lcm_all_ipuc_wr_file_hash_v4(res,pf);    
    }
    else
    {
        pf = sal_fopen(SHOW_TCAM_ALL_IPUC_FILE_HASH_v6,"a");
        if (NULL == pf) 
        {
            return LCM_E_FILE_OPEN;
        }
        _lcm_all_ipuc_wr_file_hash_v6(res,pf);    
    }

    sal_fclose(pf);
    return LCM_E_SUCCESS;
    
}
/******************************************************************************
 * Name         : _lcm_all_dft_mac_wr_file_hash(FILE *pf,diag_l2_tcam_entry_t *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file pointer
                     diag_l2_tcam_entry_t* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_all_dft_mac_wr_file_hash(FILE *pf,diag_l2_tcam_entry_t *res)
{
    diag_l2_tcam_entry_t *resp = (diag_l2_tcam_entry_t *)res;
     
    sal_fprintf(pf, " %-8d", resp->index);
    sal_fprintf(pf, " %-6x", resp->dsmackeyhash.mapped_vlanid);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeyhash.mapped_mach);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeyhash.mapped_macl>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeyhash.mapped_macl& 0xffff );
    sal_fprintf(pf, " \n"); 
    
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_all_mac_wr_file_hash(FILE *pf,diag_l2_tcam_entry_t *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file pointer
                     diag_l2_tcam_entry_t* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_all_mac_wr_file_hash(FILE *pf,diag_l2_tcam_entry_t *res)
{
    diag_l2_tcam_entry_t *resp = (diag_l2_tcam_entry_t *)res;
     
    sal_fprintf(pf, " %-8d", resp->index);
    sal_fprintf(pf, " %-6x", resp->dsmackeyhash.mapped_vlanid);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeyhash.mapped_mach);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeyhash.mapped_macl>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeyhash.mapped_macl& 0xffff );
    sal_fprintf(pf, " \n"); 
    
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name        :_lcm_lcsh_wr_l2_one_entry(diag_l2_tcam_entry_t*resp)
 * Purpose     : The function dump a TCAM entry
 * Input       : 
 *                 
 * Output       : 
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
int32
lcm_lcsh_wr_l2_one_entry(diag_l2_tcam_entry_t*resp)
{
    FILE *pf = NULL;
    
    pf = sal_fopen(SHOW_TCAM_ONE_MAC_INFO_FILE,"w+");
    if (NULL == pf) 
    {
        LCM_LOG_ERR("Open [SHOW_TCAM_ONE_MAC_INFO_FILE] failed.\n");
        return LCM_E_FILE_OPEN;
    }

    sal_fprintf(pf, " %-8d", resp->index);
    sal_fprintf(pf, " %-6x", resp->dsmackeydata.mapped_vlan_id);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeydata.mapped_mac_da_upper );
    sal_fprintf(pf, " %.04hx.", resp->dsmackeydata.mapped_mac_da_lower>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeydata.mapped_mac_da_lower& 0xffff );
    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-8s" ,"mask" );
    sal_fprintf(pf, " %-6x", resp->dsmackeymask.mapped_vlan_id);
    sal_fprintf(pf, " %.04hx.", resp->dsmackeymask.mapped_mac_da_upper );
    sal_fprintf(pf, " %.04hx.", resp->dsmackeymask.mapped_mac_da_lower>>16);
    sal_fprintf(pf, " %.04hx", resp->dsmackeymask.mapped_mac_da_lower & 0xffff );
    sal_fprintf(pf, " \n"); 

    sal_fclose(pf);
    
    return LCM_E_SUCCESS;
}



/******************************************************************************
 * Name         :_lcm_userid_entries_wr_file(diag_usrid_tcam_entry_req_t* req, diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : this function write  entry to  file 
 * Input        :  resp- para point 
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_userid_entries_wr_file(diag_usrid_tcam_entry_req_t* req, diag_usrid_tcam_entries_resp_t* resp)
{
    FILE *pf = NULL;

    pf = sal_fopen(SHOW_TCAM_USRID_INFO_FILE,"a+");
    if (NULL == pf) 
    {
        LCM_LOG_ERR("Open usrid file failed.\n");
        return LCM_E_FILE_OPEN;
    }

   sal_fprintf(pf, " %-5d", resp->tcam_entry.index& 0xffff);

    switch( req->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.mac.key.user_id_label);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.mac.key.mac_sa_upper & 0xffff);
            sal_fprintf(pf, " %.04hx.", (resp->tcam_entry.mac.key.mac_sa_lower >>16) & 0xffff);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.mac.key.mac_sa_lower & 0xffff);
            sal_fprintf(pf, " %-3s", "");
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.mac.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.src_queue_select); 
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.vpls_port_type);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.mac.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.mac.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04hx" , resp->tcam_entry.mac.ds.binding_datah);
            sal_fprintf(pf, " %.08hx" , resp->tcam_entry.mac.ds.binding_datal);
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.mac.mask.user_id_label);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.mac.mask.mac_sa_upper & 0xffff);
            sal_fprintf(pf, " %.04hx.", (resp->tcam_entry.mac.mask.mac_sa_lower >>16) & 0xffff);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.mac.mask.mac_sa_lower & 0xffff);
            break;

        case DIAG_USRID_KEY_TYPE_IPV4:
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.key.user_id_label);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.key.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.key.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.key.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.key.l4source_port);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.key.ip_sa>>24) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.key.ip_sa>>16) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.key.ip_sa>>8) & 0xff);
            sal_fprintf(pf, " %.02hx", resp->tcam_entry.ipv4.key.ip_sa & 0xff);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv4.key.mac_sa_upper & 0xffff);
            sal_fprintf(pf, " %.04hx.", (resp->tcam_entry.ipv4.key.mac_sa_lower >>16) & 0xffff);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.ipv4.key.mac_sa_lower & 0xffff);
            sal_fprintf(pf, " %-3s", "");
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.vpls_port_type);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv4.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04hx" , resp->tcam_entry.ipv4.ds.binding_datah);
            sal_fprintf(pf, " %.08hx" , resp->tcam_entry.ipv4.ds.binding_datal);
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.mask.user_id_label);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.mask.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv4.mask.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.mask.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv4.mask.l4source_port);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.mask.ip_sa>>24) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.mask.ip_sa>>16) & 0xff);
            sal_fprintf(pf, " %.02hx.", (resp->tcam_entry.ipv4.mask.ip_sa>>8) & 0xff);
            sal_fprintf(pf, " %.02hx", resp->tcam_entry.ipv4.mask.ip_sa & 0xff);
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv4.mask.mac_sa_upper & 0xffff);
            sal_fprintf(pf, " %.04hx.", (resp->tcam_entry.ipv4.mask.mac_sa_lower >>16) & 0xffff);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.ipv4.mask.mac_sa_lower & 0xffff);
            break;

        case DIAG_USRID_KEY_TYPE_IPV6:
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.key.user_id_label);               
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.key.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.key.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.key.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.key.l4source_port);

            /*ip source address data*/
            sal_fprintf(pf, " %.08x", resp->tcam_entry.ipv6.key.ip_sa31_to0 );
            sal_fprintf(pf, " %.08x.", resp->tcam_entry.ipv6.key.ip_sa63_to32 );
            sal_fprintf(pf, " %.08x.", (resp->tcam_entry.ipv6.key.ip_sa71_to64 )
                                                | ((resp->tcam_entry.ipv6.key.ip_sa103_to72 )<<8)); 
            sal_fprintf(pf, " %.08x.", ((resp->tcam_entry.ipv6.key.ip_sa103_to72 >>24))
                                                | ((resp->tcam_entry.ipv6.key.ip_sa127_to104)<<8) );

            /*mac source address data*/
            sal_fprintf(pf, " %.04hx.", resp->tcam_entry.ipv6.key.mac_sa_upper & 0xffff);
            sal_fprintf(pf, " %.04hx.", (resp->tcam_entry.ipv6.key.mac_sa_lower >>16) & 0xffff);
            sal_fprintf(pf, " %.04hx", resp->tcam_entry.ipv6.key.mac_sa_lower & 0xffff);
            
            sal_fprintf (pf, " %-4s", "");
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.vpls_port_type);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.ipv6.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04x" , resp->tcam_entry.ipv6.ds.binding_datah);
            sal_fprintf(pf, " %.08x" , resp->tcam_entry.ipv6.ds.binding_datal);
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.mask.user_id_label);               
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.mask.cvlan_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.ipv6.mask.svlan_id);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.mask.l4dest_port);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.ipv6.mask.l4source_port);

            /*ip source address mask*/
            sal_fprintf(pf, " %.08x", resp->tcam_entry.ipv6.mask.ip_sa31_to0 );  
            sal_fprintf(pf, " %.08x.", resp->tcam_entry.ipv6.mask.ip_sa63_to32 );
            sal_fprintf(pf, " %.08x.", (resp->tcam_entry.ipv6.mask.ip_sa71_to64 &0xff)
                                                | ((resp->tcam_entry.ipv6.mask.ip_sa103_to72 & 0xffffff)<<8));
            sal_fprintf(pf, " %.08x.", ((resp->tcam_entry.ipv6.mask.ip_sa103_to72 >>24) & 0xff)
                                                | ((resp->tcam_entry.ipv6.mask.ip_sa127_to104)<<8));

            /*mac source address mask*/
            sal_fprintf(pf, " %.04x.", resp->tcam_entry.ipv6.mask.mac_sa_upper & 0xffff);
            sal_fprintf(pf, " %.04x.", (resp->tcam_entry.ipv6.mask.mac_sa_lower >>16) & 0xffff);
            sal_fprintf(pf, " %.04x", resp->tcam_entry.ipv6.mask.mac_sa_lower & 0xffff);
            break;

        case DIAG_USRID_KEY_TYPE_VLAN:
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.key.user_id_label);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.key.from_sgmac);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.key.table_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.key.global_src_port);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.key.svlan_id);
            sal_fprintf(pf, " %-9x" , resp->tcam_entry.vlan.key.customer_id);
            sal_fprintf(pf, " %-4s", "");
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.ds.aps_select_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.user_vlan_ptr);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.exception_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.by_pass_all);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.binding_en);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.src_communicate_port);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.ds_fwd_ptr_valid);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.src_queue_select);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.vpls_port_type);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.ds.binding_datam);
            sal_fprintf(pf, " %-3x" , resp->tcam_entry.vlan.ds.binding_mac_sa);
            sal_fprintf(pf, " %.04x" , resp->tcam_entry.vlan.ds.binding_datah);
            sal_fprintf(pf, " %.08x" , resp->tcam_entry.vlan.ds.binding_datal);         
            sal_fprintf(pf, " \n"); 
            sal_fprintf(pf, " %-5s" ,"mask" );
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.mask.user_id_label);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.mask.from_sgmac);
            sal_fprintf(pf, " %-4x" , resp->tcam_entry.vlan.mask.table_id);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.mask.global_src_port);
            sal_fprintf(pf, " %-5x" , resp->tcam_entry.vlan.mask.svlan_id);
            sal_fprintf(pf, " %-9x" , resp->tcam_entry.vlan.mask.customer_id);
            break;

        default:
            sal_fprintf(pf, "The invalude usrid key type ");
            break;
    }
    sal_fprintf(pf,"\n");
    sal_fclose(pf);

    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         :_diag_usrid_get_one_usrid_mac_entry( diag_usrid_tcam_entry_req_t* req, 
                                         diag_usrid_tcam_entries_resp_t* resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_usrid_mac_entry( diag_usrid_tcam_entry_req_t* req, 
                                         diag_usrid_tcam_entries_resp_t* resp )
{
// TODO: Commented by xgu for compile, 20121120   
#if 0
    uint32  cmd = 0;
    uint32  table_size = 0;
    tbl_entry_t  usrid_key;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_USER_ID_MAC_KEY,&table_size));

    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }
    
    usrid_key.data_entry = (uint32*)&resp->tcam_entry.mac.key;
    usrid_key.mask_entry = (uint32*)&resp->tcam_entry.mac.mask;

    cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_MAC_KEY, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &usrid_key));
    
    cmd = DRV_IOR( IOC_TABLE, DS_USER_ID_MAC, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->tcam_entry.mac.ds));

    resp->tcam_entry.index= req->index;
    resp->chip_id = req->chip_id;
    resp->key_type = req->key_type;
#endif
    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         :_lcm_get_one_usrid_ipv4_entry( diag_usrid_tcam_entry_req_t* req,
                                                                            diag_usrid_tcam_entries_resp_t* resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_usrid_ipv4_entry( diag_usrid_tcam_entry_req_t* req,
                                                                            diag_usrid_tcam_entries_resp_t* resp )
{
// TODO: Commented by xgu for compile, 20121120   
#if 0
    uint32  cmd = 0;
    uint32  table_size = 0;
    tbl_entry_t  usrid_key;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_USER_ID_IPV4_KEY,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }
    
    usrid_key.data_entry = (uint32*)&resp->tcam_entry.ipv4.key;
    usrid_key.mask_entry = (uint32*)&resp->tcam_entry.ipv4.mask;

    cmd = DRV_IOR( IOC_TABLE, DS_USER_ID_IPV4_KEY, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &usrid_key));
    
    cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV4, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd,
                                                &resp->tcam_entry.ipv4.ds));

    resp->chip_id = req->chip_id;
    resp->key_type = req->key_type;
    resp->tcam_entry.index= req->index;
	#endif
    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         :_lcm_get_one_usrid_ipv6_entry( diag_usrid_tcam_entry_req_t* req, 
                                                                            diag_usrid_tcam_entries_resp_t* resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_usrid_ipv6_entry( diag_usrid_tcam_entry_req_t* req, 
                                                                            diag_usrid_tcam_entries_resp_t* resp )
{
// TODO: Commented by xgu for compile, 20121120   
#if 0
    uint32  cmd = 0;
    uint32  table_size = 0;
    tbl_entry_t  usrid_key;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_USER_ID_IPV6_KEY,&table_size));

    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }

    usrid_key.data_entry = (uint32*)&resp->tcam_entry.ipv6.key;
    usrid_key.mask_entry = (uint32*)&resp->tcam_entry.ipv6.mask;

    cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV6_KEY, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &usrid_key));
    
    cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV6, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, 
                                     cmd, &resp->tcam_entry.ipv6.ds));

    resp->tcam_entry.index= req->index;
    resp->chip_id = req->chip_id;
    resp->key_type = req->key_type;
	#endif
    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         :_lcm_get_one_usrid_vlan_entry( diag_usrid_tcam_entry_req_t* req, 
                                                                                diag_usrid_tcam_entries_resp_t* resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_usrid_vlan_entry( diag_usrid_tcam_entry_req_t* req, 
                                                                                diag_usrid_tcam_entries_resp_t* resp )
{
// TODO: Commented by xgu for compile, 20121120   
#if 0
    uint32  cmd = 0;
    tbl_entry_t  usrid_key;
    uint32  table_size = 0;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_USER_ID_VLAN_KEY,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }

    usrid_key.data_entry = (uint32*)&resp->tcam_entry.vlan.key;
    usrid_key.mask_entry = (uint32*)&resp->tcam_entry.vlan.mask;
    
    cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_VLAN_KEY, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, 
                               req->index, cmd, &usrid_key));
    
    cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_VLAN, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, 
                                  cmd, &resp->tcam_entry.vlan.ds));

    resp->index = req->index;
    resp->chip_id = req->chip_id;
    resp->key_type = req->key_type;
#endif        
    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         :_lcm_get_one_usrid_entry( diag_usrid_tcam_entry_req_t* req, 
                                     diag_usrid_tcam_entries_resp_t* resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_usrid_entry( diag_usrid_tcam_entry_req_t* req, 
                                     diag_usrid_tcam_entries_resp_t* resp )
{
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );

    if ( DIAG_USRID_KEY_TYPE_MAC == req->key_type )  
    {
        LCM_IF_ERROR_RETURN( _lcm_get_one_usrid_mac_entry(req, resp));
    }
    else if ( DIAG_USRID_KEY_TYPE_IPV4 == req->key_type )  
    {
        LCM_IF_ERROR_RETURN( _lcm_get_one_usrid_ipv4_entry(req, resp));
    }
    if ( DIAG_USRID_KEY_TYPE_IPV6 == req->key_type )  
    {
        LCM_IF_ERROR_RETURN( _lcm_get_one_usrid_ipv6_entry(req, resp));
    }
    if ( DIAG_USRID_KEY_TYPE_VLAN == req->key_type )  
    {
        LCM_IF_ERROR_RETURN( _lcm_get_one_usrid_vlan_entry(req, resp));
    }

    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         :_lcm_get_userid_entries(diag_usrid_tcam_entry_req_t* req, 
                                                              diag_usrid_tcam_entries_resp_t* resp,
                                                              uint32 index)
 * Purpose      : 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
#if 0// TODO: Commented by xgu for compile, 20121120   
static int32 
_lcm_get_userid_entries(diag_usrid_tcam_entry_req_t* req, 
                                                              diag_usrid_tcam_entries_resp_t* resp,
                                                              uint32 index)
{
    uint32 cmd = 0;
    tbl_entry_t  userid_key;

    switch(req->key_type)
    {
        case DIAG_USRID_KEY_TYPE_MAC:
            
            userid_key.data_entry = (uint32*)(&resp->tcam_entry.mac.key);
            userid_key.mask_entry =(uint32*)(&resp->tcam_entry.mac.mask);

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_MAC_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&userid_key));

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_MAC, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, 
                                                                        cmd, &resp->tcam_entry.mac.ds));
            break;
        case DIAG_USRID_KEY_TYPE_IPV4:
            
            userid_key.data_entry = (uint32*)(&resp->tcam_entry.ipv4.key);
            userid_key.mask_entry =(uint32*)(&resp->tcam_entry.ipv4.mask);

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV4_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&userid_key));

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV4, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, 
                                                                        cmd, &resp->tcam_entry.ipv4.ds));
            break;

        case DIAG_USRID_KEY_TYPE_IPV6:
            
            userid_key.data_entry = (uint32*)(&resp->tcam_entry.ipv6.key);
            userid_key.mask_entry =(uint32*)(&resp->tcam_entry.ipv6.mask);

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV6_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&userid_key));

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_IPV6, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, 
                                                                        cmd, &resp->tcam_entry.ipv6.ds));
            break;

        case DIAG_USRID_KEY_TYPE_VLAN:
            
            userid_key.data_entry = (uint32*)(&resp->tcam_entry.vlan.key);
            userid_key.mask_entry =(uint32*)(&resp->tcam_entry.vlan.mask);

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_VLAN_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&userid_key));

            cmd = DRV_IOR(IOC_TABLE, DS_USER_ID_VLAN, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, 
                                                                        cmd, &resp->tcam_entry.vlan.ds));
            break;
        default:
            return LCM_E_SUCCESS;
    }
    
    lcm_userid_entries_wr_file(req,resp);
    return LCM_E_SUCCESS;

}

/******************************************************************************
 * Name         :_lcm_get_usrid_entries_by_opf(diag_usrid_tcam_entry_req_t* req, 
                                                                         diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_usrid_entries_by_opf(diag_usrid_tcam_entry_req_t* req, 
                                                                         diag_usrid_tcam_entries_resp_t* resp)
{
    uint8 type_index = 0;
    uint8 pool_index = 0;
    uint32 start_offset = 0;
    uint32 max_size = 0;
    uint32 end_offset = 0;
    uint32 index = 0;
    sys_humber_opf_entry_t *entry = NULL;
    
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);
    
    type_index = req->pool_type;
    pool_index = req->chip_id;
    resp->count = 0;
    
    if (type_index >= DIAG_MAX_OPF_TBL_NUM)
    {
        LCM_LOG_ERR( "invalid type index : %d\n", type_index);
        return LCM_E_INVALID_PARAM;
    }

    start_offset  = p_opf_master->start_offset_a[type_index][pool_index];
    max_size     =  p_opf_master->max_size_a[type_index][pool_index];
    end_offset   = start_offset + max_size;

    index = start_offset;
    entry = p_opf_master->ppp_opf_pre[type_index][pool_index];
    
    if (NULL == entry)
    {
        LCM_LOG_ERR( 
                        "type_index=%d pool_index=%d This pool is not initialized!\n", type_index, pool_index);

        return LCM_E_NOT_INIT;        
    }    
    
    while (entry)
    {
        for (; index < entry->offset; index++)
        {
            resp->tcam_entry.index = index;
            _lcm_get_userid_entries(req,resp,index);
            resp->count++;
        }
        index = index + entry->size;
        entry =(sys_humber_opf_entry_t *) entry->next;
    }    
    
    while (index <end_offset )
    {
        resp->tcam_entry.index = index;
        _lcm_get_userid_entries(req,resp,index);

        index ++;
        resp->count++;
    }
    return     LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_get_usrid_mac_entries(diag_usrid_tcam_entry_req_t* req, 
                                                            diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : this function get a set of entries  form tcam 
 * Input        : diag_usrid_tcam_entry_req_t* req-request para point 
 * Output       : diag_usrid_tcam_entries_resp_t *resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32 
_lcm_get_usrid_mac_entries(diag_usrid_tcam_entry_req_t* req, 
                                                            diag_usrid_tcam_entries_resp_t* resp)
{

    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );
    
    _lcm_get_usrid_entries_by_opf(req,resp);

    return LCM_E_SUCCESS;
}
/******************************************************************************
 * Name         : _lcm_get_usrid_ipv4_entries(diag_usrid_tcam_entry_req_t* req,
                                diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : this function get a set of entries  form tcam 
 * Input        : diag_usrid_tcam_entry_req_t* req-request para point 
 * Output       : diag_usrid_tcam_entries_resp_t *resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32 
_lcm_get_usrid_ipv4_entries(diag_usrid_tcam_entry_req_t* req,
                                diag_usrid_tcam_entries_resp_t* resp)
{
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );
        
    _lcm_get_usrid_entries_by_opf(req,resp);
      
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_get_usrid_ipv6_entries(diag_usrid_tcam_entry_req_t* req,
                                diag_usrid_tcam_entries_resp_t* resp)
 * Purpose      : this function get a set of entries  form tcam 
 * Input        : diag_usrid_tcam_entry_req_t* req-request para point 
 * Output       : diag_usrid_tcam_entries_resp_t *resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32 
_lcm_get_usrid_ipv6_entries(diag_usrid_tcam_entry_req_t* req,
                                diag_usrid_tcam_entries_resp_t* resp)
{    
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );
            
    _lcm_get_usrid_entries_by_opf(req,resp);
    
    return LCM_E_SUCCESS;

}

/******************************************************************************
 * Name         : _lcm_get_usrid_vlan_entries
 * Purpose      : this function get a set of entries  form tcam 
 * Input        : diag_usrid_tcam_entry_req_t* req-request para point 
 * Output       : diag_usrid_tcam_entries_resp_t *resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32 
_lcm_get_usrid_vlan_entries(diag_usrid_tcam_entry_req_t* req,
                                diag_usrid_tcam_entries_resp_t* resp)
{ 
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );
        
    _lcm_get_usrid_entries_by_opf(req,resp);
  
    return LCM_E_SUCCESS;

}

#endif


/******************************************************************************
 * Name         :_lcm_get_set_of_usrid_entries( diag_usrid_tcam_entry_req_t* req,
                                                                diag_usrid_tcam_entries_resp_t* resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_set_of_usrid_entries( diag_usrid_tcam_entry_req_t* req,
                                                                diag_usrid_tcam_entries_resp_t* resp )
{
// TODO: Commented by xgu for compile, 20121120   
#if 0
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );

    if ( DIAG_USRID_KEY_TYPE_MAC == req->key_type )  
    {
        req->pool_type = OPF_USRID_MAC_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_usrid_mac_entries(req, resp));
    }
    else if ( DIAG_USRID_KEY_TYPE_IPV4 == req->key_type )  
    {
        req->pool_type = OPF_USRID_IPV4_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_usrid_ipv4_entries(req, resp));
    }
    else if ( DIAG_USRID_KEY_TYPE_IPV6 == req->key_type )  
    {
        req->pool_type = OPF_USRID_IPV6_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_usrid_ipv6_entries(req, resp));
    }
    else if ( DIAG_USRID_KEY_TYPE_VLAN == req->key_type )  
    {
        req->pool_type = OPF_USRID_VLAN_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_usrid_vlan_entries(req, resp));
    }
	#endif
    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         : _lcm_get_usrid_entry
 * Purpose      : this function get a set of entries  form tcam 
 * Input        : diag_usrid_tcam_entry_req_t* req-request para point 
 * Output       : diag_usrid_tcam_entries_resp_t *resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32 
lcm_get_usrid_entry(diag_usrid_tcam_entry_req_t* req, 
                                       diag_usrid_tcam_entries_resp_t* resp)
{
    /* req->index =-1, indicate cli want to get all entries*/
    if ( req->index >= 0)
    {
        return _lcm_get_one_usrid_entry( req, resp);
    }
    else 
    {
        return _lcm_get_set_of_usrid_entries(req, resp);
    }
}
// TODO: Commented by xgu for compile, 20121120   
#if 0

/******************************************************************************
 * Name         : _lcm_aclqos_get_entry_type_by_offset(void *backet_data, void *user_data)
 * Purpose      : brief distinguish ACL/QOS MAC/IPv4/MPLS key 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_aclqos_get_entry_type_by_offset(void *backet_data, void *user_data)
{
    sys_aclqos_label_t *p_label;
    ctc_aclqos_label_type_t label_type, plable_type;
    uint8 lchip;
    uint32 offset;
    sys_aclqos_label_index_t* p_index;
    ctc_list_pointer_t *p_list;
    ctc_list_pointer_node_t *iter, *iter_sub;
    sys_aclqos_entry_t *iter_entry;
    sys_aclqos_sub_entry_info_t *iter_sub_entry;
    int8 key_type;
    
    p_label = (sys_aclqos_label_t *)backet_data;
    label_type = ((int32*)user_data)[0];
    lchip = ((int32*)user_data)[1];
    offset = ((int32*)user_data)[2];

    if((p_label->type == SYS_PORT_ACL_LABEL) || (p_label->type == SYS_VLAN_ACL_LABEL))
    {
        plable_type = CTC_ACL_LABEL;
    }
    else if((p_label->type == SYS_PORT_QOS_LABEL) || (p_label->type == SYS_VLAN_QOS_LABEL))
    {
        plable_type = CTC_QOS_LABEL;
    }
    else
    {
        plable_type = CTC_SERVICE_LABEL;
    }

    if(label_type == plable_type)
    {
        p_index = p_label->p_index[lchip];
        LCM_PTR_VALID_CHECK(p_index);
        
        for(key_type=0; key_type<CTC_ACLQOS_IPV6_KEY; key_type++)
        {
            /* lookup goes from tail to head */
            p_list = &p_index->entry_list[key_type];
            
            CTC_LIST_POINTER_LOOP_R(iter, p_list)   /* iterate each latter entry */
            {
                iter_entry = _ctc_container_of(iter, sys_aclqos_entry_t, head);
                
                CTC_LIST_POINTER_LOOP_R(iter_sub, &iter_entry->info_list) /* interate each sub entry in latter entries */
                {
                    iter_sub_entry = _ctc_container_of(iter_sub, sys_aclqos_sub_entry_info_t, head);
                    
                    if(iter_sub_entry->offset == offset)
                    {
                        ((int32*)user_data)[3] = key_type;
                        
                        return -1;  /*ctc_hash_traverse no need to check rest label*/
                    }
                }

            }
        }
    }
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_aclqos_get_entry_type(ctc_aclqos_label_type_t label_type, uint8 lchip, uint32 offset)
 * Purpose      : brief distinguish ACL/QOS MAC/IPv4/MPLS key 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/

static diag_aclqos_key_type_t 
_lcm_aclqos_get_entry_type(ctc_aclqos_label_type_t label_type, uint8 lchip, uint32 offset)
{
// TODO: Commented by xgu for compile, 20121120   
    int32 entry_info[4];
    int32 ret;
    uint8 lchip_num;

    if(label_type >= CTC_SERVICE_LABEL)
    {
        /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
        return DIAG_ACLQOS_KEY_MAX;
    }

    lchip_num = sys_humber_get_local_chip_num();
    if(lchip >= lchip_num)
    {
        /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/
        return DIAG_ACLQOS_KEY_MAX;
    }
    
    entry_info[0] = label_type;
    entry_info[1] = lchip;
    entry_info[2] = offset;
    entry_info[3] = 0;      /*This is used to save result*/
    
    ret = ctc_hash_traverse(p_aclqos_label_hash, _lcm_aclqos_get_entry_type_by_offset, entry_info);

    if(LCM_E_SUCCESS == ret)
    {
        return MAX_CTC_ACLQOS_KEY;
    }
    else
    {
        return entry_info[3];
    }    
}


/******************************************************************************
 * Name         : _lcm_get_acl_or_qos_entries(diag_acl_tcam_get_req_t* req, 
                                                                        diag_acl_tcam_entry_t* resp,
                                                                        uint32 index)
 * Purpose      : get entries from tcam
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32 
_lcm_get_acl_or_qos_entries(diag_acl_tcam_get_req_t* req, 
                                                                        diag_acl_tcam_entry_t* resp,
                                                                        uint32 index)
{
    uint32 cmd = 0;
    tbl_entry_t  key;

    switch(req->key_type)
    {
        case DIAG_ACLQOS_KEY_MAC:
            
            key.data_entry = (uint32*)(&resp->mac_key);
            key.mask_entry =(uint32*)(&resp->mac_mask);

            cmd = DRV_IOR(IOC_TABLE, DS_ACL_MAC_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&key));

            break;
        case DIAG_ACLQOS_KEY_IPV4:
            
            key.data_entry = (uint32*)(&resp->ipv4_key);
            key.mask_entry =(uint32*)(&resp->ipv4_mask);

            cmd = DRV_IOR(IOC_TABLE, DS_ACL_IPV4_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&key));

            break;

        case DIAG_ACLQOS_KEY_MPLS:
            
            key.data_entry = (uint32*)(&resp->mpls_key);
            key.mask_entry =(uint32*)(&resp->mpls_mask);

            cmd = DRV_IOR(IOC_TABLE, DS_ACL_MPLS_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&key));
            break;

        case DIAG_ACLQOS_KEY_IPV6:
            
            key.data_entry = (uint32*)(&resp->ipv6_key);
            key.mask_entry =(uint32*)(&resp->ipv6_mask);

            cmd = DRV_IOR(IOC_TABLE, DS_ACL_IPV6_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&key));
            break;

        case DIAG_PBR_KEY_IPV4:
            
            key.data_entry = (uint32*)(&resp->pbr_ipv4_key);
            key.mask_entry =(uint32*)(&resp->pbr_ipv4_mask);

            cmd = DRV_IOR(IOC_TABLE, DS_IPV4_PBR_DUALDA_KEY, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, index, cmd, (uint32 *)&key));
            break;

        default:

            LCM_LOG_ERR( "invalid type  : %d\n", req->key_type);

            return LCM_E_INVALID_PARAM;
    }

    lcm_acl_or_qos_wr_file(req,resp);
    return LCM_E_SUCCESS;

}


/*****************************************************************************
 * Name        :_lcm_get_acl_or_qos_entries_by_opf(diag_acl_tcam_get_req_t* req,
                                                                                diag_acl_tcam_entry_t* resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point	
 * Output       : 
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32
_lcm_get_acl_or_qos_entries_by_opf(diag_acl_tcam_get_req_t* req,diag_acl_tcam_entry_t* resp)
{

    uint32 type_index = 0;
    uint32 pool_index = 0;
    uint32 start_offset = 0;
    uint32 max_size = 0;
    uint32 end_offset = 0;
    uint32 index = 0;
    diag_aclqos_key_type_t acl_qos_key_type ;
    sys_humber_opf_entry_t *entry = NULL;

    pool_index = req->chip_id;
    type_index = req->pool_type;

    if (type_index >= MAX_OPF_TBL_NUM)
    {
        LCM_LOG_ERR( "invalid type index : %d\n", type_index);
        return LCM_E_INVALID_PARAM;
    }

    start_offset  = p_opf_master->start_offset_a[type_index][pool_index];
    max_size     =  p_opf_master->max_size_a[type_index][pool_index];
    end_offset   = start_offset + max_size;

    index = start_offset;
    entry = p_opf_master->ppp_opf_pre[type_index][pool_index];

    if (NULL == entry)
    {
        LCM_LOG_ERR("type_index=%d pool_index=%d This pool is not initialized!\n", type_index, pool_index);

        return LCM_E_NOT_INIT;        
    }    

    while (entry)
    {
        for ( ; index < entry->offset ; index++)
        {
            if(ACL_PBR_IPV4_KEY == req->pool_type)
            {
                acl_qos_key_type = DIAG_PBR_KEY_IPV4;
            }
            else if (ACL_IPV6_KEY != req->pool_type)
            {
                acl_qos_key_type = _lcm_aclqos_get_entry_type(req->table_type,req->chip_id,index);
                if (acl_qos_key_type != req->key_type)
                {
                    continue;
                }
            }
            resp->index = index;
            _lcm_get_acl_or_qos_entries(req,resp,index);
        }

        index = index + entry->size;
        entry =(sys_humber_opf_entry_t *) entry->next;
    }    

    while (index <end_offset )
    {
        if (ACL_PBR_IPV4_KEY == req->pool_type)
        {
            acl_qos_key_type = DIAG_PBR_KEY_IPV4;
        }
        else if (ACL_IPV6_KEY != req->pool_type)
        {
            acl_qos_key_type = _lcm_aclqos_get_entry_type(req->table_type, req->chip_id, index);
            if (acl_qos_key_type != resp->key_type)
            {
                continue;
            }
        }
        resp->index = index;
        _lcm_get_acl_or_qos_entries(req,resp,index);
        index ++;
    }
    return     LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name        :_lcm_get_acl_entries( diag_acl_tcam_get_req_t* req, 
                                                                     diag_acl_tcam_data_t *resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point	
 * Output       : 
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32 
_lcm_get_acl_entries( diag_acl_tcam_get_req_t* req, diag_acl_tcam_data_t *resp)
{
    /* MAC */    
    if (DIAG_ACLQOS_KEY_MAC == req->key_type)
    {
        req->pool_type = ACL_MAC_MPLS_IPV4_KEY;
    }/*IPV4*/
    else if (DIAG_ACLQOS_KEY_IPV4 == req->key_type)
    {
        req->pool_type = ACL_MAC_MPLS_IPV4_KEY;        
    }
    else if (DIAG_ACLQOS_KEY_IPV6 == req->key_type)
    {
        req->pool_type = ACL_IPV6_KEY;
    }
    else if (DIAG_ACLQOS_KEY_MPLS == req->key_type)
    {
        req->pool_type = ACL_MAC_MPLS_IPV4_KEY;
    }

    _lcm_get_acl_or_qos_entries_by_opf(req, &resp->diag_acl_tcam_entry);
        
    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name        :_lcm_get_qos_entries( diag_acl_tcam_get_req_t* req, 
                                                                        diag_acl_tcam_data_t *resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point	
 * Output       : 
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32 
_lcm_get_qos_entries( diag_acl_tcam_get_req_t* req, diag_acl_tcam_data_t *resp)
{
    /* MAC */    
    if (DIAG_ACLQOS_KEY_MAC == req->key_type)
    {
        req->pool_type = QOS_MAC_MPLS_IPV4_KEY;
    }/*IPV4*/
    else if (DIAG_ACLQOS_KEY_IPV4 == req->key_type)
    {
        req->pool_type = QOS_MAC_MPLS_IPV4_KEY;
    }
    else if (DIAG_ACLQOS_KEY_MPLS == req->key_type)
    {
        req->pool_type = QOS_MAC_MPLS_IPV4_KEY;
    }
    else
    {
        req->pool_type = QOS_IPV6_KEY;
    }

    _lcm_get_acl_or_qos_entries_by_opf(req, &resp->diag_acl_tcam_entry);

    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name        :_lcm_get_pbr_entries( diag_acl_tcam_get_req_t* req, 
                                                                        diag_acl_tcam_data_t *resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point	
 * Output       : 
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32 
_lcm_get_pbr_entries( diag_acl_tcam_get_req_t* req, diag_acl_tcam_data_t *resp)
{
    req->pool_type = ACL_PBR_IPV4_KEY;

    _lcm_get_acl_or_qos_entries_by_opf(req, &resp->diag_acl_tcam_entry);

    return LCM_E_SUCCESS;
}
#endif


/*****************************************************************************
 * Name        :lcm_get_all_acl_or_qos_entries(diag_acl_tcam_get_req_t* req,
                                                                            diag_acl_tcam_data_t *resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point
 * Output       : ctc_acl_tcam_usage_t
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
int32 
lcm_get_all_acl_or_qos_entries(diag_acl_tcam_get_req_t* req,diag_acl_tcam_data_t *resp)
{
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    if (DIAG_ACL_TABLE == req->table_type)
    {
  // TODO: Commented by xgu for compile, 20121120         LCM_IF_ERROR_RETURN(_lcm_get_acl_entries(req, resp ));
    }
    else if (DIAG_QOS_TABLE == req->table_type)
    {
 // TODO: Commented by xgu for compile, 20121120          LCM_IF_ERROR_RETURN(_lcm_get_qos_entries(req, resp ));
    }
    else if (DIAG_PBR_TABLE == req->table_type)
    {
 // TODO: Commented by xgu for compile, 20121120          LCM_IF_ERROR_RETURN(_lcm_get_pbr_entries(req, resp ));
    }
    return LCM_E_SUCCESS;
};

#if 0 // TODO: Commented by xgu for compile, 20121120   

/******************************************************************************
 * Name         :_lcm_get_one_acl_or_qos_mac_entry(diag_acl_tcam_get_req_t* req, 
                                                                                        diag_acl_tcam_entry_t* resp)
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_acl_or_qos_mac_entry(diag_acl_tcam_get_req_t* req, 
                                                                                        diag_acl_tcam_entry_t* resp)
{
    uint32  cmd = 0;
    uint32  table_size = 0;
    tbl_entry_t aclqos_key;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(req->table_id,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }
    
    aclqos_key.data_entry = (uint32 *)(&resp->mac_key);
    aclqos_key.mask_entry = (uint32 *)(&resp->mac_mask);

    cmd = DRV_IOR( IOC_TABLE, req->table_id, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &aclqos_key));

    lcm_acl_or_qos_wr_file(req,resp);
    
    return LCM_E_SUCCESS;
};


/******************************************************************************
 * Name         :_lcm_get_one_acl_or_qos_ipv4_entry(diag_acl_tcam_get_req_t* req, 
                                                                                        diag_acl_tcam_entry_t* resp)
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_acl_or_qos_ipv4_entry(diag_acl_tcam_get_req_t* req, 
                                                                                        diag_acl_tcam_entry_t* resp)
{
    uint32  cmd = 0;
    uint32  table_size = 0;
    tbl_entry_t aclqos_key;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(req->table_id,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }

    aclqos_key.data_entry = (uint32 *)(&resp->ipv4_key);
    aclqos_key.mask_entry = (uint32 *)(&resp->ipv4_mask);

    cmd = DRV_IOR(IOC_TABLE, req->table_id, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &aclqos_key));

    lcm_acl_or_qos_wr_file(req,resp);
    
    return LCM_E_SUCCESS;
};

/******************************************************************************
 * Name         :_lcm_get_one_acl_or_qos_ipv6_entry(diag_acl_tcam_get_req_t* req, 
                                                                                        diag_acl_tcam_entry_t* resp)
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_one_acl_or_qos_ipv6_entry(diag_acl_tcam_get_req_t* req, 
                                                                                        diag_acl_tcam_entry_t* resp)
{
    uint32  cmd = 0;
    uint32  table_size = 0;
    tbl_entry_t aclqos_key;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(req->table_id,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }
    
    aclqos_key.data_entry = (uint32 *)(&resp->ipv6_key);
    aclqos_key.mask_entry = (uint32 *)(&resp->ipv6_mask);

    cmd = DRV_IOR( IOC_TABLE, req->table_id, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &aclqos_key));

    lcm_acl_or_qos_wr_file(req,resp);
    
    return LCM_E_SUCCESS;
};

/*****************************************************************************
 * Name        :_lcm_get_one_acl_entry(diag_acl_tcam_get_req_t* req, 
                                                                        diag_acl_tcam_entry_t* resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point	
 * Output       : ctc_acl_tcam_usage_t
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32 
_lcm_get_one_acl_entry(diag_acl_tcam_get_req_t* req, 
                                                                        diag_acl_tcam_entry_t* resp)
{
    if (DIAG_ACLQOS_KEY_MAC == req->key_type )
    {
        req->table_id = DS_ACL_MAC_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_one_acl_or_qos_mac_entry(req, resp));
    }
    else if (DIAG_ACLQOS_KEY_IPV4 == req->key_type  )
    {
        req->table_id = DS_ACL_IPV4_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_one_acl_or_qos_ipv4_entry(req, resp));
    }
    else 
    {
        req->table_id = DS_ACL_IPV6_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_one_acl_or_qos_ipv6_entry(req, resp));
    }
    
    return LCM_E_SUCCESS;
};

/*****************************************************************************
 * Name        :_lcm_get_one_qos_entry(diag_acl_tcam_get_req_t* req, 
                                                                          diag_acl_tcam_entry_t* resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point
 * Output       : ctc_acl_tcam_usage_t
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32 
_lcm_get_one_qos_entry(diag_acl_tcam_get_req_t* req, 
                                                                          diag_acl_tcam_entry_t* resp)
{
    if (DIAG_ACLQOS_KEY_MAC == req->key_type )
    {
        req->table_id = DS_QOS_MAC_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_one_acl_or_qos_mac_entry(req, resp));
    }
    else if (DIAG_ACLQOS_KEY_IPV4 == req->key_type  )
    {
        req->table_id = DS_QOS_MAC_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_one_acl_or_qos_ipv4_entry(req, resp));
    }
    else 
    {
        req->table_id = DS_QOS_IPV6_KEY;
        LCM_IF_ERROR_RETURN( _lcm_get_one_acl_or_qos_ipv6_entry(req, resp));
    }
    
    return LCM_E_SUCCESS;
};
#endif
/*****************************************************************************
 * Name        :_lcm_get_one_acl_or_qos_entry(diag_acl_tcam_get_req_t* req,
                                                                                diag_acl_tcam_entry_t *resp)
 * Purpose     : The function dump a set of TCAM entries
 * Input       : req - request para point 
 *                  resp - back para point	
 * Output       : ctc_acl_tcam_usage_t
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
int32 
lcm_get_one_acl_or_qos_entry(diag_acl_tcam_get_req_t* req,
                                                                                diag_acl_tcam_entry_t *resp)
{
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    if (DIAG_ACL_TABLE == req->table_type)
    {
// TODO: Commented by xgu for compile, 20121120           LCM_IF_ERROR_RETURN(_lcm_get_one_acl_entry(req, resp ));
    }
    else
    {
 // TODO: Commented by xgu for compile, 20121120          LCM_IF_ERROR_RETURN(_lcm_get_one_qos_entry(req, resp ));
    }
    return LCM_E_SUCCESS;
};
#if 0 // TODO: Commented by xgu for compile, 20121120   

/******************************************************************************
 * Name         :_lcm_get_fdb_dflt_entry(diag_l2_fdb_entry_t * pl2_fdb_entry)
 * Purpose      : this function get a entry form tcam 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void
_lcm_get_fdb_dflt_entry(diag_l2_fdb_entry_t * pl2_fdb_entry)
{

    uint16  index = 0;
    uint32 cmd = 0;
    int32 ret = 0;
    diag_ds_mac_t macda;
    tbl_entry_t  tcam_key;
    diag_l2_tcam_entry_t resp;
    sys_l2_fdb_vlan_node_t* fid_node = NULL;
    sys_l2_node_t  *p_l2_node = NULL;
    FILE* pf1 = NULL;
    FILE* pf2= NULL;

    kal_memset(&macda,0,sizeof(diag_ds_mac_t));
    kal_memset(&tcam_key,0,sizeof(tbl_entry_t));
    kal_memset(&resp,0,sizeof(diag_l2_tcam_entry_t));

    tcam_key.data_entry = (uint32 *)&resp.dsmackeydata;
    tcam_key.mask_entry = (uint32 *)&resp.dsmackeymask;

    pf1 = sal_fopen(SHOW_TCAM_DEFAULT_TCAM_MAC_INFO_FILE,"a+");
    pf2 = sal_fopen(SHOW_TCAM_DEFAULT_HASH_MAC_INFO_FILE,"a+");
    if (NULL == pf1 ||NULL == pf2) 
    {
        SYS_FDB_DBG_INFO("Open fdb dft file failed.\n");
        return ;
    }
     
    for (index = 0; index <= pl2_master->max_fid_value; index++)
    {
        /*modified by liul for bug 16746, 2011-10-27*/
        fid_node = _sys_humber_l2_fdb_fid_entry_lkup_from_hash_table(index, 0, 0);
        p_l2_node = fid_node?fid_node->fdb_dft_node:NULL;
        if (NULL == p_l2_node)
        {
            continue;
        }

        if (!CTC_FLAG_ISSET(p_l2_node->flag, SYS_L2_NODE_FLAG_IS_ASIC_HASH))
        {
            cmd = DRV_IOR(IOC_TABLE, DS_MAC, DRV_ENTRY_FLAG);
            ret = drv_tbl_ioctl(0, p_l2_node->index, cmd, &macda); 

            cmd = DRV_IOR(IOC_TABLE, DS_MAC_KEY, DRV_ENTRY_FLAG);
            drv_tbl_ioctl(0, p_l2_node->index - pl2_master->tcam_base, cmd, &tcam_key); 
            resp.index = p_l2_node->index;
            lcm_all_dft_mac_wr_file_tcam(pf1,&resp);    
        }
        else
        {
            ds_mac_hash_key0_t mac_hash_key;
            index = p_l2_node->index - pl2_master->hash_base;
            kal_memset(&mac_hash_key,0,sizeof(mac_hash_key));

            cmd = DRV_IOR(IOC_TABLE, DS_MAC, DRV_ENTRY_FLAG);
            ret = drv_tbl_ioctl(0,  p_l2_node->index, cmd, &macda);

            cmd = DRV_IOR(IOC_TABLE, DS_MAC_HASH_KEY0, DRV_ENTRY_FLAG);
            drv_tbl_ioctl(0, index, cmd, &mac_hash_key);
            resp.index = p_l2_node->index;
            lcm_all_dft_mac_wr_file_hash(pf2,&resp);    
        }

        pl2_fdb_entry->default_count++;
        pl2_fdb_entry->static_count++;  
        pl2_fdb_entry->total_count++;

    }
    sal_fclose(pf1);
    sal_fclose(pf2);
}

static int32
_lcm_show_all_fdb_status(sys_l2_node_t* p_fdb_node, diag_l2_fdb_entry_t *pl2_fdb_entry)
{
    tbl_entry_t  tcam_key;
    diag_l2_tcam_entry_t resp;
    uint32 cmd = 0;

    FILE* pf1 = NULL;
    FILE* pf2 = NULL;

    kal_memset(&tcam_key,0,sizeof(tbl_entry_t));
    kal_memset(&resp,0,sizeof(diag_l2_tcam_entry_t));

    tcam_key.data_entry = (uint32 *)&resp.dsmackeydata;
    tcam_key.mask_entry = (uint32 *)&resp.dsmackeymask;

    pf1 = sal_fopen(SHOW_TCAM_TCAM_MAC_INFO_FILE,"a+");
    pf2 = sal_fopen(SHOW_TCAM_HASH_MAC_INFO_FILE,"a+");

    if (NULL == pf1 ||NULL == pf2) 
    {
        SYS_FDB_DBG_INFO("Open fdb file failed.\n");
        return LCM_E_INVALID_PTR;
    }

    if (NULL == p_fdb_node)
    {
        return LCM_E_INVALID_PTR;
    }

    cmd = DRV_IOR(IOC_TABLE, DS_MAC, DRV_ENTRY_FLAG);
    drv_tbl_ioctl(0, p_fdb_node->index, cmd, &resp.dsmacda);

    if (!CTC_FLAG_ISSET(p_fdb_node->flag, SYS_L2_NODE_FLAG_IS_ASIC_HASH))
    {
        cmd = DRV_IOR(IOC_TABLE, DS_MAC_KEY, DRV_ENTRY_FLAG);
        drv_tbl_ioctl(0, p_fdb_node->index- pl2_master->tcam_base, cmd, &tcam_key);

        resp.index = p_fdb_node->index;
        lcm_all_mac_wr_file_tcam(pf1,&resp);    
    }        
    else
    {
        ds_mac_hash_key0_t mac_hash_key;
        int index = p_fdb_node->index - pl2_master->hash_base;
        kal_memset(&mac_hash_key,0,sizeof(mac_hash_key));

        cmd = DRV_IOR(IOC_TABLE, DS_MAC_HASH_KEY0, DRV_ENTRY_FLAG);
        drv_tbl_ioctl(0, index, cmd, &mac_hash_key);

        resp.index = p_fdb_node->index;
        sal_memcpy(&resp.dsmackeyhash,&mac_hash_key,sizeof(ds_mac_hash_key0_t));

        lcm_all_mac_wr_file_hash(pf2,&resp);    
    }

    sal_fclose(pf1);
    sal_fclose(pf2);
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         :_lcm_get_all_fdb_entry(diag_l2_tcam_entry_req_t* req,diag_l2_fdb_entry_t* pl2_fdb_entry)
 * Purpose      : this function get a entry form tcam 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static void
_lcm_get_all_fdb_entry(diag_l2_tcam_entry_req_t* req,diag_l2_fdb_entry_t* pl2_fdb_entry)
{

    ctc_hash_traverse(pl2_master->fdb_hash,
                               (hash_traversal_fn) _lcm_show_all_fdb_status,
                               &pl2_fdb_entry);

}
#endif

/******************************************************************************
 * Name         :lcm_get_all_l2_fdb(diag_l2_tcam_entry_req_t* req)
 * Purpose      : this function get a entry form tcam 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_get_all_l2_fdb(diag_l2_tcam_entry_req_t* req)
{
#if 0 // TODO: Commented by xgu for compile, 20121120   
    diag_l2_fdb_entry_t l2_fdb_entry;
    diag_l2_fdb_entry_t entry;
    FILE* pf =NULL;
    
    kal_memset(&l2_fdb_entry,0,sizeof(diag_l2_fdb_entry_t));
    kal_memset(&entry,0,sizeof(diag_l2_fdb_entry_t));

    _lcm_get_all_fdb_entry(req,&l2_fdb_entry);
    _lcm_get_fdb_dflt_entry(&l2_fdb_entry);    

    l2_fdb_entry.total_count += pl2_master->fdb_hash->count;
    l2_fdb_entry.total_count +=1 ; /*System default entry*/

    pf = sal_fopen(SHOW_TCAM_HASH_MAC_INFO_FILE,"a+");
    if(NULL == pf) 
    {
        SYS_FDB_DBG_INFO("Open tcam hash file failed.\n");
        return LCM_E_FILE_OPEN;
    }
    
    kal_fprintf(pf, "\n");
    kal_fprintf(pf, "-------------------------------------------------------------\n");
    kal_fprintf(pf, "\n");

    kal_fprintf(pf,"%-20s:%4u \n", "Mac table size", pl2_master->max_sram_size );
    kal_fprintf(pf,"%-20s:%4u \n", "hash table size", pl2_master->asic_hash_size );
    kal_fprintf(pf,"%-20s:%4u \n", "Total count", l2_fdb_entry.total_count );
    kal_fprintf(pf,"%-20s:%4u \n", "Do asic hash count", pl2_master->do_hash_count);
    kal_fprintf(pf,"%-20s:%4u \n", "Static count", l2_fdb_entry.static_count);
    kal_fprintf(pf,"%-20s:%4u \n", "Default entry count",l2_fdb_entry.default_count);
    kal_fprintf(pf,"%-20s:%4u \n", "System default entry count",1);     

    sal_fclose(pf);
#endif
    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_msg_rx_l2_get_all_entries(diag_l2_tcam_entry_req_t* req,  diag_l2_tcam_entries_resp_t*resp)
 * Purpose      : The function get a set of entries and send them up to nsm
 * Input        : diag_l2_tcam_entry_req_t* req,request para
 * Output       : diag_l2_tcam_entries_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_msg_rx_l2_get_all_entries(diag_l2_tcam_entry_req_t* req,  diag_l2_tcam_entries_resp_t*resp)
{
    
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );

    lcm_get_all_l2_fdb(req);
    resp->diag_l2_tcam_entry.chip_id = req->chip_id;
 
    return LCM_E_SUCCESS;
};
#if 0 // TODO: Commented by xgu for compile, 20121120   

/******************************************************************************
 * Name         :_lcm_get_l2_dft_fdb_by_index(diag_l2_tcam_entry_req_t* req,diag_l2_tcam_entry_t* para)
 * Purpose      : this function get a entry form tcam 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_l2_dft_fdb_by_index(diag_l2_tcam_entry_req_t* req,diag_l2_tcam_entry_t* para)
{
    uint32 cmd=0;
    uint32 index = 0;
    uint32 table_size = 0;
    tbl_entry_t  tcam_key;
    sys_l2_fdb_vlan_node_t* fid_node = NULL;
    sys_l2_node_t* p_l2_node = NULL;
    diag_l2_tcam_entry_t* resp = NULL;

    resp = (diag_l2_tcam_entry_t *)para;
    kal_memset(&tcam_key,0,sizeof(tbl_entry_t));

    tcam_key.data_entry = (uint32 *)&resp->dsmackeydata;
    tcam_key.mask_entry = (uint32 *)&resp->dsmackeymask;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_MAC,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = 0xff;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }

    SYS_L2_FDB_INIT_CHECK();
        
    for (index = 0; index <= pl2_master->max_fid_value; index++)
    {
        /*modified by liul for bug 16746, 2011-10-27*/
        fid_node = _sys_humber_l2_fdb_fid_entry_lkup_from_hash_table(index, 0, 0);
        p_l2_node = fid_node?fid_node->fdb_dft_node:NULL;
        if (NULL == p_l2_node)
        {
            continue;
        }

        if (p_l2_node->index == req->index)
        {
            break;            
        }
    }

    if (index > pl2_master->max_fid_value)
    {
        return LCM_E_SUCCESS;
    }

    cmd = DRV_IOR(IOC_TABLE, DS_MAC, DRV_ENTRY_FLAG);
    drv_tbl_ioctl(req->chip_id, p_l2_node->index, cmd, &resp->dsmacda);

    if (!CTC_FLAG_ISSET(p_l2_node->flag, SYS_L2_NODE_FLAG_IS_ASIC_HASH))
    {
        cmd = DRV_IOR(IOC_TABLE, DS_MAC_KEY, DRV_ENTRY_FLAG);
        drv_tbl_ioctl(req->chip_id, p_l2_node->index- pl2_master->tcam_base, cmd, &tcam_key);
        resp->index = p_l2_node->index;
        resp->type = tcam_type;
    }
    else
    {
        ds_mac_hash_key0_t mac_hash_key;
        kal_memset(&mac_hash_key,0,sizeof(mac_hash_key));

        cmd = DRV_IOR(IOC_TABLE, DS_MAC_HASH_KEY0, DRV_ENTRY_FLAG);
        drv_tbl_ioctl(req->chip_id, p_l2_node->index - pl2_master->hash_base, cmd, &mac_hash_key);
   
        resp->index = p_l2_node->index;
        resp->type = sram_type;
        sal_memcpy(&resp->dsmackeyhash,&mac_hash_key,sizeof(ds_mac_hash_key0_t));
    }
    return LCM_E_SUCCESS;        
  
}

static int32
_lcm_show_one_fdb_status(sys_l2_node_t* p_fdb_node, diag_l2_mac_specify_entry_t *p_specify_entry)
{

    if (NULL == p_fdb_node)
    {
        return CTC_E_INVALID_PTR;
    }

    if (p_specify_entry->index == p_fdb_node->index)
    {
        p_specify_entry->p_l2_node = p_fdb_node;

        return CTC_E_ENTRY_EXIST;
    }

    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         :_lcm_get_l2_fdb_by_index(diag_l2_tcam_entry_req_t* req,diag_l2_tcam_entry_t* para)
 * Purpose      : this function get a entry form tcam 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_get_l2_fdb_by_index(diag_l2_tcam_entry_req_t* req,diag_l2_tcam_entry_t* para)
{
    uint32 cmd=0;
    tbl_entry_t  tcam_key;
    sys_l2_node_t* p_l2_node = NULL;
    diag_l2_tcam_entry_t* resp = NULL;
    uint32 table_size = 0;
    diag_l2_mac_specify_entry_t l2_specify_entry;
    int32 retval = 0;
    
    resp = (diag_l2_tcam_entry_t *)para;
    kal_memset(&tcam_key,0,sizeof(tbl_entry_t));
    kal_memset(&l2_specify_entry,0,sizeof(diag_l2_mac_specify_entry_t));

    tcam_key.data_entry = (uint32 *)&resp->dsmackeydata;
    tcam_key.mask_entry = (uint32 *)&resp->dsmackeymask;

    l2_specify_entry.index = req->index;
    
    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_MAC,&table_size));

    if ( req->index >= table_size )
    {
        resp->chip_id = 0xff;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }

    SYS_L2_FDB_INIT_CHECK();
   
    retval = ctc_hash_traverse(pl2_master->fdb_hash,
                               (hash_traversal_fn) _lcm_show_one_fdb_status,
                               &l2_specify_entry);

    if( CTC_E_ENTRY_EXIST == retval)
    {
        p_l2_node = l2_specify_entry.p_l2_node;
    }
    else
    {
        return LCM_E_NOT_FOUND;
    }

    if (NULL == p_l2_node)
    {
        CTC_ERROR_RETURN_WITH_UNLOCK(CTC_E_ENTRY_NOT_EXIST, pl2_master->l2_mutex);
    }

    cmd = DRV_IOR(IOC_TABLE, DS_MAC, DRV_ENTRY_FLAG);
    drv_tbl_ioctl(req->chip_id, p_l2_node->index, cmd, &resp->dsmacda);

    if (!CTC_FLAG_ISSET(p_l2_node->flag, SYS_L2_NODE_FLAG_IS_ASIC_HASH))
    {
        cmd = DRV_IOR(IOC_TABLE, DS_MAC_KEY, DRV_ENTRY_FLAG);
        drv_tbl_ioctl(req->chip_id, p_l2_node->index- pl2_master->tcam_base, cmd, &tcam_key);
        resp->index = p_l2_node->index;
        resp->type = tcam_type;
    }
    else
    {
        ds_mac_hash_key0_t mac_hash_key;
        kal_memset(&mac_hash_key,0,sizeof(mac_hash_key));

        cmd = DRV_IOR(IOC_TABLE, DS_MAC_HASH_KEY0, DRV_ENTRY_FLAG);
        drv_tbl_ioctl(req->chip_id, p_l2_node->index - pl2_master->hash_base, cmd, &mac_hash_key);
   
        resp->index = p_l2_node->index;
        resp->type = sram_type;
        sal_memcpy(&resp->dsmackeyhash,&mac_hash_key,sizeof(ds_mac_hash_key0_t));
    }

    return LCM_E_SUCCESS;        
  
}

#endif

/*****************************************************************************
 * Name         : _lcm_get_one_l2_entry(diag_l2_tcam_entry_req_t* req,  diag_l2_tcam_entry_t* resp)
 * Purpose      : The function a entry form tcam
 * Input        : req,request para
 * Output       :resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_get_one_l2_entry(diag_l2_tcam_entry_req_t* req,  diag_l2_tcam_entry_t* resp)
{
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );
#if 0 // TODO: Commented by xgu for compile, 20121120   
    if (default_type == req->type)
    {
        _lcm_get_l2_dft_fdb_by_index(req,resp);
    }
    else
    {
        _lcm_get_l2_fdb_by_index(req,resp);
    }

    lcm_lcsh_wr_l2_one_entry(resp);
	#endif
    return LCM_E_SUCCESS; 
}

/*****************************************************************************
 * Name         : lcm_get_one_ipuc_entry( diag_ipv4_v6_tcam_entry_t* data)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32
lcm_get_one_ipuc_entry( diag_ipv4_v6_tcam_entry_t* data)
{
// TODO: Commented by xgu for compile, 20121120   
#if 0
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *) data;
    sys_nh_offset_array_t fwd_offset;
    tbl_entry_t  ip_key;
    uint32 cmd = 0;
    uint32 index = 0;
    uint32 nh_id = 1 ; /*SYS_HUMBER_NH_RESOLVED_NHID_FOR_DROP ? */
    uint32 table_size = 0;

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(p_ipuc_master->da_table_id[resp->ip_ver],&table_size));
    if ( resp->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR("The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(p_ipuc_master->sa_table_id[resp->ip_ver],&table_size));
    if ( resp->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        LCM_LOG_ERR("The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }

     //dsipda
    LCM_IF_ERROR_RETURN(sys_humber_nh_get_dsfwd_offset(nh_id, fwd_offset));

    if (CTC_IP_VER_4  == resp->ip_ver )
    {
        resp->dsipda.ds_fwd_ptr = fwd_offset[0] & 0xfffff ;

        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->da_table_id[resp->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, resp->index, cmd, &resp->dsipda));

        //dsipsa
        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->sa_table_id[resp->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, resp->index, cmd, &resp->dsipsa));
    }
    else
    {
        resp->dsipda_v6.ds_fwd_ptr = fwd_offset[0] & 0xfffff ;

        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->da_table_id[resp->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, resp->index, cmd, &resp->dsipda_v6));

        //dsipsa
        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->sa_table_id[resp->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, resp->index, cmd, &resp->dsipsa_v6));
    }

    if (sram_type == resp->position)
    {
        index = resp->index - p_ipuc_master->hash_base[resp->ip_ver];
        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->hashkey_table_id[resp->ip_ver], DRV_ENTRY_FLAG);
        
        if (CTC_IP_VER_4  == resp->ip_ver )
        {
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, index, cmd, &resp->dsip_hashkey_v4));
        }
        else
        {
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, index, cmd, &resp->dsip_hashkey_v6));
        }
    }    
    else
    {
        index = resp->index - p_ipuc_master->tcam_base[resp->ip_ver];
        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->key_table_id[resp->ip_ver], DRV_ENTRY_FLAG);
            
        if (CTC_IP_VER_4  == resp->ip_ver )
        {
            ip_key.data_entry = (uint32 *)(&resp->keydata);
            ip_key.mask_entry = (uint32 *)(&resp->keymask);
        }
        else
        {
            ip_key.data_entry = (uint32 *)(&resp->keydata_v6);
            ip_key.mask_entry = (uint32 *)(&resp->keymask_v6);            
        }
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(resp->chip_id, index, cmd, &ip_key));
  }
#endif
    return LCM_E_SUCCESS;
}

#if 0// TODO: Commented by xgu for compile, 20121120   
/*****************************************************************************
 * Name         : _lcm_get_ipuc_entries_by_hash(sys_ipuc_info_t* p_ipuc_data, void* data)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_get_ipuc_entries_by_hash(sys_ipuc_info_t* p_ipuc_data, void* data)
{
    uint32 index = 0;
    uint32 cmd = 0;    
    tbl_entry_t  ip_key;
    ds_ipv4_ucast_da_t dsipda;
    ds_ipv4_ucast_sa_t dsipsa;
    diag_ipv4_v6_tcam_entry_t resp;
    
    sal_memset(&dsipda, 0, sizeof(ds_ipv4_ucast_da_t));
    sal_memset(&dsipsa, 0, sizeof(ds_ipv4_ucast_da_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entry_t));

    if (p_ipuc_data->in_sram)
    {
        index = p_ipuc_data->key_offset - p_ipuc_master->hash_base[p_ipuc_data->ip_ver];
        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->hashkey_table_id[p_ipuc_data->ip_ver], DRV_ENTRY_FLAG);
        resp.index = p_ipuc_data->key_offset;
        if (DIAG_IP_VER_4 == p_ipuc_data->ip_ver)
        {
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, index, cmd, &resp.dsip_hashkey_v4));
        }
        else
        {
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, index, cmd, &resp.dsip_hashkey_v6));
        }
        
        lcm_all_ipuc_wr_hash_file(p_ipuc_data->ip_ver,(void *)&resp);
    }
    else 
    {
        index = p_ipuc_data->key_offset - p_ipuc_master->tcam_base[p_ipuc_data->ip_ver];
        resp.index = p_ipuc_data->key_offset;
            
        if ( DIAG_IP_VER_4 == p_ipuc_data->ip_ver)
        {
            ip_key.data_entry = (uint32 *)(&resp.keydata);
            ip_key.mask_entry = (uint32 *)(&resp.keymask);
        }
        else
        {
            ip_key.data_entry = (uint32 *)(&resp.keydata_v6);
            ip_key.mask_entry = (uint32 *)(&resp.keymask_v6);            
        }
        
        cmd = DRV_IOR(IOC_TABLE,p_ipuc_master->da_table_id[p_ipuc_data->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, p_ipuc_data->key_offset, cmd, &dsipda));

        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->sa_table_id[p_ipuc_data->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, p_ipuc_data->key_offset, cmd, &dsipsa));

        cmd = DRV_IOR(IOC_TABLE, p_ipuc_master->key_table_id[p_ipuc_data->ip_ver], DRV_ENTRY_FLAG);
        LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, index, cmd, &ip_key));
        lcm_all_ipuc_wr_file(p_ipuc_data->ip_ver,(void *)&resp);    
  }
    return LCM_E_SUCCESS;
}
#endif
/*****************************************************************************
 * Name         : _lcm_get_ipuc_entries(uint8 ip_ver)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_get_ipuc_entries(uint8 ip_ver)
{
// TODO: Commented by xgu for compile, 20121120       ctc_hash_traverse(p_ipuc_db_master->ipuc_hash[ip_ver], (hash_traversal_fn)_lcm_get_ipuc_entries_by_hash, NULL);

    return LCM_E_SUCCESS;    
}

/*****************************************************************************
 * Name         : lcm_ipuc_v4_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
 * Purpose      : The function get a set of entries   and send them up to lcsh
 * Input        : diag_l3_tcam_entry_req_t* req,request para
 * Output       : diag_ipv4_v6_tcam_entries_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_ipuc_v4_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    diag_ip_ver_t ip_ver = DIAG_IP_VER_4;
    _lcm_get_ipuc_entries(ip_ver);
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : lcm_ipuc_v6_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_ipuc_v6_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    diag_ip_ver_t ip_ver=DIAG_IP_VER_6;
    _lcm_get_ipuc_entries(ip_ver);
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_all_ipmc_wr_file_v4(void *res,FILE *pf)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_all_ipmc_wr_file_v4(void *res,FILE *pf)
{
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *)res;

    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_da.dscp);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_da.frag_info);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_da.ip_options);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_da.is_application);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_da.is_tcp);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_da.is_udp);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_da.layer4_type);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_da.lkp_mode);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_da.pbr_label);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_da.table_id0 | (resp->ipmc_key_da.table_id1 << 1));
    sal_fprintf(pf, " %-4x", resp->ipmc_key_da.l4info_mapped);
    sal_fprintf(pf, " %-4x", resp->ipmc_key_da.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->ipmc_key_da.l4_source_port);
    sal_fprintf(pf, " %-4x", resp->ipmc_key_da.vrf_idl | (resp->ipmc_key_da.vrf_idh << 4));
    sal_fprintf(pf, " %02x.", (resp->ipmc_key_da.ip_da >> 24) & 0xff);
    sal_fprintf(pf, " %02x.", (resp->ipmc_key_da.ip_da >> 16) & 0xff);
    sal_fprintf(pf, " %02x.", (resp->ipmc_key_da.ip_da >> 8) & 0xff);
    sal_fprintf(pf, " %02x", (resp->ipmc_key_da.ip_da ) & 0xff);
    sal_fprintf(pf, " %-8x", resp->ipmc_key_da.ip_sa);

    sal_fprintf(pf, " \n"); 
    sal_fprintf(pf, " %-5s", "mask");
    sal_fprintf(pf, " %-2x", resp->ipmc_key_mask.dscp);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_mask.frag_info);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_mask.ip_options);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_mask.is_application);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_mask.is_tcp);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_mask.is_udp);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_mask.layer4_type);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_mask.lkp_mode);
    sal_fprintf(pf, " %-2x", resp->ipmc_key_mask.pbr_label);
    sal_fprintf(pf, " %-3x", resp->ipmc_key_mask.table_id0 | (resp->ipmc_key_mask.table_id1 << 1));
    sal_fprintf(pf, " %-4x", resp->ipmc_key_mask.l4info_mapped);
    sal_fprintf(pf, " %-4x", resp->ipmc_key_mask.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->ipmc_key_mask.l4_source_port);
    sal_fprintf(pf, " %-4x", resp->ipmc_key_mask.vrf_idl | (resp->ipmc_key_mask.vrf_idh << 4));
    sal_fprintf(pf, " %02x.", (resp->ipmc_key_mask.ip_da >> 24) & 0xff);
    sal_fprintf(pf, " %02x.", (resp->ipmc_key_mask.ip_da >> 16) & 0xff);
    sal_fprintf(pf, " %02x.", (resp->ipmc_key_mask.ip_da >> 8) & 0xff);
    sal_fprintf(pf, " %02x", (resp->ipmc_key_mask.ip_da ) & 0xff);
    sal_fprintf(pf, " %-8x", resp->ipmc_key_mask.ip_sa);

    sal_fprintf(pf, "\n"); 
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_all_ipmc_wr_file_v6(void *res,FILE *pf)
 * Purpose      : this function write  entries  to tcam 
 * Input        : FILE *pf - file point
                     diag_l2_tcam_entry_t* resp-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/

static int32
_lcm_all_ipmc_wr_file_v6(void *res,FILE *pf)
{
    diag_ipv4_v6_tcam_entry_t *resp = (diag_ipv4_v6_tcam_entry_t *)res;

    sal_fprintf(pf, " %-5d", resp->index);
    sal_fprintf(pf, " %-4x", resp->keydata_v6.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->keydata_v6.l4_source_port);
    sal_fprintf(pf, " %-4x", (resp->keydata_v6.vrf_idl & 0x0f)+(resp->keydata_v6.vrf_idh <<4));
    sal_fprintf(pf, " %08x.", (resp->keydata_v6.ip_sa4 << 8) + (resp->keydata_v6.ip_sa3>> 24));
    sal_fprintf(pf, "%08x.", (resp->keydata_v6.ip_sa3<<8) + (resp->keydata_v6.ip_sa2));
    sal_fprintf(pf, "%08x.", resp->keydata_v6.ip_sa1);
    sal_fprintf(pf, "%08x", resp->keydata_v6.ip_sa0);    
    sal_fprintf(pf, " %08x.", (resp->keydata_v6.ip_da4 << 8) + (resp->keydata_v6.ip_da3>> 24));
    sal_fprintf(pf, "%08x.", (resp->keydata_v6.ip_da3<<8) + (resp->keydata_v6.ip_da2));
    sal_fprintf(pf, "%08x.", resp->keydata_v6.ip_da1);
    sal_fprintf(pf, "%08x", resp->keydata_v6.ip_da0); 
    sal_fprintf(pf, " \n"); 
    
    sal_fprintf(pf, " %-5s", "mask");
    sal_fprintf(pf, " %-4x", resp->keymask_v6.l4_dest_port);
    sal_fprintf(pf, " %-4x", resp->keymask_v6.l4_source_port);
    sal_fprintf(pf, " %-4x", (resp->keymask_v6.vrf_idl & 0x0f)+(resp->keydata_v6.vrf_idh <<4));
    sal_fprintf(pf, " %08x.", (resp->keymask_v6.ip_sa4 << 8) + (resp->keymask_v6.ip_sa3>> 24));  
    sal_fprintf(pf, "%08x.", (resp->keymask_v6.ip_sa3<<8) + (resp->keymask_v6.ip_sa2));
    sal_fprintf(pf, "%08x.", resp->keymask_v6.ip_sa1);
    sal_fprintf(pf, "%08x", resp->keymask_v6.ip_sa0);
    sal_fprintf(pf, " %08x.", (resp->keymask_v6.ip_da4 << 8) + (resp->keymask_v6.ip_da3>> 24));  
    sal_fprintf(pf, "%08x.", (resp->keymask_v6.ip_da3<<8) + (resp->keymask_v6.ip_da2));
    sal_fprintf(pf, "%08x.", resp->keymask_v6.ip_da1);
    sal_fprintf(pf, "%08x", resp->keymask_v6.ip_da0); 
    sal_fprintf(pf, "\n"); 
    return LCM_E_SUCCESS;
}

/******************************************************************************
 * Name         : _lcm_all_ipmc_wr_file(uint8 ver,void *res)
 * Purpose      : this function write  entries  to tcam 
 * Input        : uint8 ver - ip version
                     void* res-
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_all_ipmc_wr_file(uint8 ver,void *res)
{
    FILE *pf = NULL;
    
    if (DIAG_IP_VER_4 == ver)
    {
        pf = sal_fopen(SHOW_TCAM_ALL_IPMC_FILE_V4,"a+");
        if (NULL == pf ) 
        {
            return LCM_E_FILE_OPEN;
        }
        
        _lcm_all_ipmc_wr_file_v4(res,pf);    
    }
    else
    {
        pf = sal_fopen(SHOW_TCAM_ALL_IPMC_FILE_V6,"a+");
        if (NULL == pf ) 
        {
            return LCM_E_FILE_OPEN;
        }

        /*modify by chenxw for bug 20481, 2012-09-21.*/
        _lcm_all_ipmc_wr_file_v6(res,pf);    
    }
    sal_fclose(pf);
    return LCM_E_SUCCESS;
}

#if 0 // TODO: Commented by xgu for compile, 20121120   
/*****************************************************************************
 * Name         : _lcm_get_ipuc_entries_by_hash(sys_ipuc_info_t* p_ipuc_data, void* data)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_get_ipmc_entries_by_hash(sys_ipmc_group_node_t* p_group_node, void* data)
{
    uint32 index = 0;
    uint32 cmd = 0;    
    uint32 da_tbl_id = 0;
    uint32 sa_tbl_id = 0;
    uint32 key_tbl_id = 0;
    tbl_entry_t  ip_key;
    diag_ds_ipv4_mcast_da_t ds_ipv4_mcast_da;
    diag_ds_ipv4_mcast_rpf_t ds_ipv4_mcast_rpf;
    diag_ipv4_v6_tcam_entry_t resp;

    sal_memset(&ds_ipv4_mcast_da, 0, sizeof(diag_ds_ipv4_mcast_da_t));
    sal_memset(&ds_ipv4_mcast_rpf, 0, sizeof(diag_ds_ipv4_mcast_rpf_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entry_t));

    index = p_group_node->index;
    resp.index = index;
        
    if ( DIAG_IP_VER_4 == p_group_node->ip_version)
    {
        da_tbl_id = DS_IPV4_MCAST_DA;
        sa_tbl_id = DS_IPV4_MCAST_RPF;
        key_tbl_id = DS_IPV4_MCAST_ROUTE_KEY;
        ip_key.data_entry = (uint32 *)(&resp.ipmc_key_da);
        ip_key.mask_entry = (uint32 *)(&resp.ipmc_key_mask);
    }
    else
    {
        /*do ipmc v6*/
       da_tbl_id = DS_IPV6_MCAST_DA;
       sa_tbl_id = DS_IPV6_MCAST_RPF;
       key_tbl_id = DS_IPV6_MCAST_ROUTE_KEY;        
       ip_key.data_entry = (uint32 *)(&resp.keydata_v6);
       ip_key.mask_entry = (uint32 *)(&resp.keymask_v6);  
    }
    
    cmd = DRV_IOR(IOC_TABLE,da_tbl_id, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, index, cmd, &ds_ipv4_mcast_da));

    cmd = DRV_IOR(IOC_TABLE,sa_tbl_id, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, index, cmd, &ds_ipv4_mcast_rpf));

    cmd = DRV_IOR(IOC_TABLE, key_tbl_id, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(0, index, cmd, &ip_key));
    
    lcm_all_ipmc_wr_file(p_group_node->ip_version,(void *)&resp);    
    
    return LCM_E_SUCCESS;
}
#endif
/*****************************************************************************
 * Name         : _lcm_get_ipuc_entries(uint8 ip_ver)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_get_ipmc_entries(uint8 ip_ver)
{
// TODO: Commented by xgu for compile, 20121120       ctc_hash_traverse(p_ipmc_db_master->ipmc_hash[ip_ver], (hash_traversal_fn)_lcm_get_ipmc_entries_by_hash, NULL);

    return LCM_E_SUCCESS;    
}

/*****************************************************************************
 * Name         : lcm_ipuc_v4_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
 * Purpose      : The function get a set of entries   and send them up to lcsh
 * Input        : diag_l3_tcam_entry_req_t* req,request para
 * Output       : diag_ipv4_v6_tcam_entries_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_ipmc_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
{
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    diag_ip_ver_t ip_ver = DIAG_IP_VER_4;
    _lcm_get_ipmc_entries(ip_ver);
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : lcm_ipuc_v6_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
 * Purpose      : The function get a set of entries   and send them up to lcsh
 * Input        : diag_l3_tcam_entry_req_t* req,request para
 * Output       : diag_ipv4_v6_tcam_entries_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_ipmc_v6_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp)
{
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    diag_ip_ver_t ip_ver = DIAG_IP_VER_6;
    _lcm_get_ipmc_entries(ip_ver);
    return LCM_E_SUCCESS;
}


/******************************************************************************
 * Name         :lcm_get_one_ipmc_entry( diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp )
 * Purpose      : this function get a entry form tcam 
 * Input        :  req-request para point 
 * Output       : resp-out para point 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
int32
lcm_get_one_ipmc_entry( diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp )
{
#if 0// TODO: Commented by xgu for compile, 20121120   

    uint32  cmd = 0;
    tbl_entry_t  ipkey;
    uint32  table_size = 0;

    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV4_MCAST_ROUTE_KEY,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV4_MCAST_DA,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }
    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV4_MCAST_RPF,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }
    
    ipkey.data_entry = (uint32*)&resp->ipmc_key_da;
    ipkey.mask_entry = (uint32*)&resp->ipmc_key_mask;

    cmd = DRV_IOR(IOC_TABLE, DS_IPV4_MCAST_ROUTE_KEY, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &ipkey));
    
    cmd = DRV_IOR(IOC_TABLE, DS_IPV4_MCAST_DA, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_ipv4_mcast_da_t));
    
    cmd = DRV_IOR(IOC_TABLE, DS_IPV4_MCAST_RPF, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_ipv4_mcast_rpf_t));
   
    resp->index = req->index;
#endif
    return LCM_E_SUCCESS;
};

/*****************************************************************************
 * Name         : lcm_get_one_ipuc_v6_entry(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
 * Purpose      : The function get a entry  and send them up to nsm
 * Input        :  req,request para
 * Output       : resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
int32 
lcm_get_one_ipuc_v6_entry(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp)
{
#if 0// TODO: Commented by xgu for compile, 20121120   

    tbl_entry_t     ipv6_key;
    uint32         cmd = 0;
    uint32  table_size = 0;

    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV6_UCAST_DA,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV6_UCAST_SA,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }
    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV6_UCAST_ROUTE_KEY,&table_size));
    if ( req->index >= table_size )
    {
        resp->chip_id = DIAG_GET_TCAM_INDEX_INVALID;
        resp->index = table_size;
        return LCM_E_INVALID_PARAM;
    }

    ipv6_key.data_entry = (uint32 *)(&resp->keydata_v6);
    ipv6_key.mask_entry = (uint32 *)(&resp->keymask_v6);
    
    /* 1) DsIpDa */
    cmd = DRV_IOR(IOC_TABLE, DS_IPV6_UCAST_DA, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsipda_v6));
    
    /* 2) DsIpSa */
    cmd = DRV_IOR(IOC_TABLE, DS_IPV6_UCAST_SA, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsipsa_v6));
    
    /* 3) DsIpv4RouteKey */
    cmd = DRV_IOR(IOC_TABLE, DS_IPV6_UCAST_ROUTE_KEY, DRV_ENTRY_FLAG);
    LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &ipv6_key));
    resp->index = req->index;
#endif
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : lcm_get_stp_status(diag_sram_get_stp_status_req_t* req, diag_sram_get_stp_status_resp_t *resp)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_get_stp_status(diag_sram_get_stp_status_req_t* req, diag_sram_get_stp_status_resp_t *resp)
{
#if 0// TODO: Commented by xgu for compile, 20121120   

    uint32 ret = 0;
    uint8 gchip_id= 0;
    
    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    ctc_humber_get_gchip_id(req->chip_id, &gchip_id);
    req->gport= (gchip_id <<8 | req->port_id);

    switch(req->table_type)
    {
        case DIAG_GET_STP_ID:
            ret = ctc_stp_get_vlan_stpid(req->vlan_id, &resp->stp_id);
            if (ret < 0)
            {
               LCM_LOG_ERR("get stpid error \n");
               return LCM_E_INVALID_PARAM;
            }

            req->stp_id = resp->stp_id;
            ret = ctc_stp_get_state(req->gport,req->stp_id,&resp->stp_status);
            if (ret < 0)
            {
               LCM_LOG_ERR("get stp status error \n");
               return LCM_E_INVALID_PARAM;
            }

        default:  
            LCM_LOG_ERR("table type is not surported .\n");
            break;
    }
        #endif
    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : lcm_get_register_table(diag_reg_entry_req_t* req, diag_reg_entry_resp_t *resp)
 * Purpose      : The function get a entry  and send them up to lcsh
 * Input        : diag_reg_entry_req_t* req,request para
 * Output       : diag_reg_entry_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
int32 
lcm_get_register_table(diag_reg_entry_req_t* req, diag_reg_entry_resp_t *resp)
{
#if 0// TODO: Commented by xgu for compile, 20121120   

    uint32 cmd = 0;
    
    LCM_PTR_VALID_CHECK( req );
    LCM_PTR_VALID_CHECK( resp );    
    switch(req->reg_type)
    {
        case DIAG_IPE_DS_VLAN_CTL:
            cmd = DRV_IOR(IOC_REG, 1376/*IPE_DS_VLAN_CTL*/, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_reg_ioctl(req->chip_id, 0, cmd, &resp->dsvlan_ctl));
            break;
        case DIAG_EPE_NEXT_HOP_CTL:
            cmd = DRV_IOR(IOC_REG, 156/*EPE_NEXT_HOP_CTL*/, DRV_ENTRY_FLAG);
            LCM_IF_ERROR_RETURN(drv_reg_ioctl(req->chip_id, 0, cmd, &resp->epe_next_hop_ctl));
            break;
        default:
            LCM_LOG_ERR("table type is not surported .\n") ;
            break;
    }
    resp->reg_type = req->reg_type;
	#endif
    return LCM_E_SUCCESS;
}
