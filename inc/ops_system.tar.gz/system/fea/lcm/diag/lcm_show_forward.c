// TODO: Commented by xgu for compile 20121120//
#if 0
/****************************************************************************
 *lcm_show_forward.c     Provides debug command for cmodel
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       liul
 * Date:         2010-11-19.
 * Reason:       First Create.
 ****************************************************************************/


 /******************************************************************
       * include header files
  ******************************************************************/
#include "lcm_error.h"
#include "lcm_debug.h"
#include "lcm_show_forward.h"
#include "humber_chip_info.h"
#include "lcm_mgt.h"
#include "sim_engine.h"
/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/
uint8 show_forward_pkt_out[LCM_SHOW_FORWARD_MAX_PKT];
#define IS_SHOW_FORWARD_PKT_OUT(var) (show_forward_pkt_out[var] == 1)

/****************************************************************************
*  
* Function
*
*****************************************************************************/

/****************************************************************************
 * Name        : _lcm_show_forward_open_file
 * Purpose     : open logging file
 * Input        : fp : the pointer of open file .
 * Output       : N/A   .
 * Return       : LCM_E_XX
 * Note         : N/A
 *****************************************************************************/
static int32
_lcm_show_forward_open_file(FILE **fp)
{
    FILE *pst_f = NULL;
    
    pst_f = sal_fopen(DEBUG_LOGGING_FILE, "a+");
    if (NULL == pst_f)
    {
        LCM_LOG_ERR("lcm show forward open file failed:%s", strerror(errno));
        return LCM_E_FILE_OPEN;
    }

    *fp = pst_f;
    return LCM_E_SUCCESS;
}

/****************************************************************************
 * Name        : _lcm_show_forward_close_file
 * Purpose     : close file 
 * Input        : fp:the pointer of close file .
 * Output      :  N/A.
 * Return       : LCM_E_XX
 * Note         :  N/A
 *****************************************************************************/
static int32
_lcm_show_forward_close_file(FILE *fp)
{
    sal_fflush(fp);
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

/****************************************************************************
 * Name        : lcm_show_forward_print_message
 * Purpose     : print msg
 * Input        : msg:print msg
 * Output      : N/A   .
 * Return       : LCM_E_XX
 * Note         : N/A
 *****************************************************************************/
int32
lcm_show_forward_print_message(char *pc_hello_msg)
{
    FILE *fp = NULL;
  
    /*open file*/
    if (_lcm_show_forward_open_file(&fp) < 0)
    {
        return LCM_E_SUCCESS;
    }

    /*output the hello message first*/
    DEBUG_INFO_SHOW (fp, pc_hello_msg);   

    LCM_IF_ERROR_RETURN(_lcm_show_forward_close_file(fp));
  
    return LCM_E_SUCCESS;
}
/****************************************************************************
 * Name        :  lcm_show_forward_print_data_in_hex
 * Purpose     : pirnt data in hex
 * Input        : module_id :module id. dst:pkt pointer
 *                  length :msg length. hello_msg : msg pointer
 * Output      : N/A   .
 * Return       : LCM_E_XX
 * Note         : N/A
 *****************************************************************************/
int32
lcm_show_forward_print_data_in_hex(uint8 module_id, uint8 *dst, int32 length, char *pc_hello_msg)
{
    int count = 0;
    char *pbuf = NULL;
    char *pstr = NULL;
    int32 len = length + 300;/* if no add extra len(here 300).will cause crash.why ? */
    FILE *fp = NULL;

    if (!IS_SHOW_FORWARD_PKT_OUT(module_id))
    {
        return LCM_E_SUCCESS;
    }

    /*open file*/
    if (_lcm_show_forward_open_file(&fp) < 0)
    {
        return LCM_E_SUCCESS;
    }

    /*calloc memory*/
    pbuf = sal_malloc(len);
    if (NULL == pbuf)
    {
        LCM_LOG_ERR("Can not allocate memory");
        return LCM_E_SUCCESS;
    }    
    sal_memset(pbuf, 0, len);
    pstr = pbuf;

    /*output the hello message first*/
    DEBUG_INFO_SHOW (fp, pc_hello_msg);   
    
    /*put the information in the buffer*/
    for (count = 0; count < length; count++)
    {
        if (count != 0 && !(count%16 )) 
        {
            DEBUG_WRITE(pbuf, pstr, "\n"); 
            DEBUG_INFO_SHOW(fp, pbuf);           
            sal_memset(pbuf, 0, len);
            pstr = pbuf;
        }
        DEBUG_WRITE(pbuf, pstr, "%02x ", *(dst+count));         
    }   

    DEBUG_WRITE(pbuf, pstr, "\n"); 
    DEBUG_INFO_SHOW(fp, pbuf);

    sal_free(pbuf); /*sometimes may cause lcm crash, also happen in hagt do ipe and epe function,?????*/  
    LCM_IF_ERROR_RETURN(_lcm_show_forward_close_file(fp));
  
    return LCM_E_SUCCESS;
}

/****************************************************************************
 * Name        : _lcm_show_forward_send_log_file
 * Purpose     : send log file to chsm
 * Input        : arg:.
 * Output      : N/A.
 * Return       : LCM_E_XX
 * Note         : N/A
 *****************************************************************************/
static int32
_lcm_show_forward_send_log_file(void* pv_arg)
{
    FILE *fp = NULL;  
    int32 len = LCM_BUF_SZ - 300;/*300 bytes reserved*/
    uint8 *pc_msg_buf = NULL;    
    int32 count = 0;
    int32 flag = 0; 
    int32 ret = 0;

    pc_msg_buf = sal_malloc(len);
    if (NULL == pc_msg_buf)
    {
        LCM_LOG_ERR( "Can not allocate memory");
        return LCM_E_SUCCESS;
    }

    fp = sal_fopen(DEBUG_LOGGING_FILE, "rb");
    if (fp == NULL)
    {
        sal_free(pc_msg_buf);
        return LCM_E_SUCCESS;
    }

    while ((count = sal_fread(pc_msg_buf, sizeof(uint8), len, fp)) > 0)
    {
        ret = lcm_msg_tx_chsmforwardinfo(pv_arg,pc_msg_buf, (count*sizeof(uint8)));
        if (ret < 0)
        {
            LCM_LOG_ERR( "Send msg failed!");
        }
        flag = 1;
    }

    /*to check whether read failed*/    
    if (!flag)
    {
        LCM_LOG_ERR( "read failed, count=%d", count);
    }

    /*free memory and close file*/
    sal_fclose (fp);
    sal_free(pc_msg_buf);

    /*delete file*/
    remove(DEBUG_LOGGING_FILE);
    
    return LCM_E_SUCCESS;
}

/****************************************************************************
 * Name        :  _lcm_show_forward_outpkt2qpkt
 * Purpose     : translate the outpkt to inpkt
 * Input        : outpkt:out packet.
 * Output      : inpkt : in packet.
 * Return       : LCM_E_XX
 * Note         : N/A
 *****************************************************************************/
static int32 
_lcm_show_forward_outpkt2qpkt(out_pkt_t *pst_outpkt, qpkt_t *pst_inpkt)
{
    pst_inpkt->chip_id = pst_outpkt->chip_id;
    pst_inpkt->chan_id = pst_outpkt->chan_id;
    pst_inpkt->pkt = pst_outpkt->pkt;
    pst_inpkt->pkt_id = pst_outpkt->pkt_id;
    pst_inpkt->pkt_len = pst_outpkt->pkt_len;
    pst_inpkt->exception = pst_outpkt->exception;
    pst_inpkt->local_phy_port = pst_outpkt->local_phy_port;
    pst_inpkt->from_fabric = pst_outpkt->from_fabric;

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name     :   _lcm_show_forward_outpkt2oampkt
 * Purpose  :  translate the out_pkt_t type outpkt to oam_pkt_t type inpkt
 * Input     :   outpkt pointer.
 * Output   :  inpkt pointer.
 * Return   :   LCM_E_XX
 * Note     :   N/A.
****************************************************************************/
static int32 
_lcm_show_forward_outpkt2oampkt(out_pkt_t *pst_outpkt, oam_pkt_t *pst_inpkt)
{
    pst_inpkt->chip_id = pst_outpkt->chip_id;
    pst_inpkt->chan_id = pst_outpkt->chan_id;
    pst_inpkt->pkt = pst_outpkt->pkt;
    pst_inpkt->pkt_id = pst_outpkt->pkt_id;
    pst_inpkt->pkt_len = pst_outpkt->pkt_len;

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name     : _lcm_show_forward_outpkt2epkt
 * Purpose :  translate the out_pkt_t type outpkt to epkt_t type inpkt
 * Input    :  outpkt pointer.
 * Output  :  inpkt pointer.
 * Return   :  LCM_E_XX
 * Note     :  N/A.
****************************************************************************/
static int32 
_lcm_show_forward_outpkt2epkt(out_pkt_t *pst_outpkt, epkt_t *pst_inpkt)
{
    pst_inpkt->chip_id = pst_outpkt->chip_id;
    pst_inpkt->chan_id = pst_outpkt->chan_id;
    pst_inpkt->pkt = pst_outpkt->pkt;
    pst_inpkt->pkt_id = pst_outpkt->pkt_id;
    pst_inpkt->pkt_len = pst_outpkt->pkt_len;

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name     : _lcm_show_forward_outpkt2epkt
 * Purpose :  translate the out_pkt_t type outpkt to epkt_t type inpkt
 * Input    :  outpkt pointer.
 * Output  :  inpkt pointer.
 * Return   :  LCM_E_XX
 * Note     :  N/A.
****************************************************************************/
static int32 
_lcm_show_forward_outpkt2ctcpkt(out_pkt_t *pst_outpkt, ctc_pkt_t *pst_inpkt)
{
    pst_inpkt->pkt_id = pst_outpkt->pkt_id;
    pst_inpkt->pkt = pst_outpkt->pkt;
    pst_inpkt->pkt_info= NULL;
    pst_inpkt->pkt_len = pst_outpkt->pkt_len;
    pst_inpkt->chan_id= pst_outpkt->chan_id;
    pst_inpkt->chip_id = pst_outpkt->chip_id;
    pst_inpkt->has_hdr= 0;

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name     :  lcm_show_forward_set_flags
 * Purpose :  set flags  
 * Input     :  module : module id     
 * Output   :  flags: set flags   
 * Return   :  LCM_E_XX
 * Note     :   N/A.
****************************************************************************/
int32 
lcm_show_forward_set_flags(uint32 type, uint64 flags)
{
    int32 bit_index = 0;
    uint8 bit_value = 0;

    if ( LCM_SHOW_FORWARD_MODULE == type)   
    {
        for (bit_index = 0; bit_index<  MAX_NUM_SHOW_FORWARD_DEBUG_CMODEL; bit_index++)
        {
            bit_value = (( flags >> bit_index) & 0x1 );
            show_forward_debug_cmodel[bit_index] = bit_value;
        }
    }
    else if (LCM_SHOW_FORWARD_PKT == type)
    {
        for (bit_index = 0; bit_index< LCM_SHOW_FORWARD_MAX_PKT; bit_index++)
        {
            bit_value = (( flags >> bit_index) & 0x1 );
            show_forward_pkt_out[bit_index] = bit_value;
        }
    }
    else if ( LCM_SHOW_FORWARD_DEBUG == type)
    {
        cmodel_debug_on = flags; 
    }

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name         : lcm_show_forward_process(ctc_pkt_t *input_pkt, void *arg)
 * Purpose  :    do ipe process
 * Input        :  input_pkt:input packet     
 * Output       : N/A    
 * Return       :  LCM_E_XX
 * Note         :  N/A.
****************************************************************************/
int32
lcm_show_forward_process(ctc_pkt_t *pst_input_pkt, void *pv_arg)
{
    ipkt_t cpkt;
    epkt_t  epkt;
    oam_pkt_t oam_pkt;
    qpkt_t qpkt_ipe;     
    
    ctc_pkt_t lpbpkt;          /*pkt send to do lookback process*/

    glb_card_t *p_card = NULL;
    char hello_msg[HELLO_MSG_LEN] = {0}; /*used for output packet hello message*/
    int32 slot_num = 0;
    int32 ret = LCM_E_SUCCESS;

    list_head_t  ipe_out_pkt_head;
    list_head_t  epe_out_pkt_head;
    list_head_t  oam_out_pkt_head;
    list_head_t  fwd_out_pkt_head;

    list_head_t  *pos_ipe = NULL;
    list_head_t  *pos_fwd = NULL;
    list_head_t  *pos_oam = NULL;
    list_head_t  *pos_epe = NULL;

    out_pkt_t   *ipe_out_pkt = NULL;
    out_pkt_t   *epe_out_pkt = NULL;
    out_pkt_t   *fwd_out_pkt = NULL;
    out_pkt_t   *oam_out_pkt = NULL;

    /* reset pakcet informations */
    sal_memset(&qpkt_ipe, 0, sizeof(qpkt_t));
    sal_memset(&cpkt, 0, sizeof(ipkt_t));
    sal_memset(&epkt, 0, sizeof(epkt_t));
    sal_memset(&oam_pkt, 0, sizeof(oam_pkt_t));
    sal_memset(&lpbpkt, 0, sizeof(ctc_pkt_t));

    INIT_LIST_HEAD(&fwd_out_pkt_head);
    INIT_LIST_HEAD(&ipe_out_pkt_head);
    INIT_LIST_HEAD(&epe_out_pkt_head);
    INIT_LIST_HEAD(&oam_out_pkt_head);

    cmodel_debug_on = TRUE;
    p_card = lcm_mgt_get_card();
    if (p_card)
    {
        slot_num = p_card->phy_slot_no;        
    }

    cpkt.chan_id = pst_input_pkt->chan_id;
//    cpkt.chip_id = dev_get_local_chip_no_by_glb_chip_no(input_pkt->chip_id);
    cpkt.chip_id = 0;
    cpkt.pkt_id = pst_input_pkt->pkt_id;
    cpkt.pkt_len = pst_input_pkt->pkt_len;
//    cpkt.pkt = pst_input_pkt->pkt;  

    cpkt.pkt = sal_malloc(LCM_SHOW_FORWARD_MTU);
    if (NULL == cpkt.pkt)
    {
        return LCM_E_NO_MEMORY;
    }
    sal_memset(cpkt.pkt, 0, LCM_SHOW_FORWARD_MTU);
    sal_memcpy(cpkt.pkt, pst_input_pkt->pkt, pst_input_pkt->pkt_len);

    /*linecard message*/   
    sal_snprintf(hello_msg, sizeof(hello_msg), "\n==================IPE LC SLOT : %d=====================\n", slot_num);
    lcm_show_forward_print_message(hello_msg);  

    /*packet message*/    
    sal_snprintf(hello_msg, sizeof(hello_msg), "\n[ IPE ] packet is from: chip =%d(%d), channel=%d, pkt_len=%d\n",slot_num, 
                                                                                cpkt.chip_id, cpkt.chan_id, cpkt.pkt_len);   
    lcm_show_forward_print_data_in_hex(LCM_SHOW_FORWARD_IPE_PKT, (uint8*)cpkt.pkt, cpkt.pkt_len, hello_msg);
    
    if (HUMBER_CPU_CHAN_ID != cpkt.chan_id || HUMBER_CPU_OAM_CHAN_ID != cpkt.chan_id 
        ||HUMBER_E_LOOPBACK_CHAN_ID != cpkt.chan_id ||
         !(cpkt.chan_id > HUMBER_FABRIC_MIN_CHAN_ID && cpkt.chan_id < HUMBER_FABRIC_MAX_CHAN_ID))
    {
        ret = humber_dv_do_ipe(&cpkt, &ipe_out_pkt_head);
        if (LCM_E_SUCCESS != ret)
        {
            LCM_LOG_ERR( "LC%d: dv_do_ipe error = %d!", slot_num, ret);
            goto FREE_MEM_RSC;
        }
    }
    else
    {        
        ipe_out_pkt = sal_malloc(sizeof(out_pkt_t));
        if (NULL == ipe_out_pkt)
        {
            LCM_LOG_ERR("no memory");
            goto FREE_MEM_RSC;
        }
        sal_memset(ipe_out_pkt, 0, sizeof(out_pkt_t));

        ipe_out_pkt->exception = sal_malloc(HUMBER_EXCEPTION_LEN);
        if (NULL == ipe_out_pkt->exception)
        {
            LCM_LOG_ERR("no memory");
            goto FREE_MEM_RSC;
        }
        sal_memset(ipe_out_pkt->exception, 0, HUMBER_EXCEPTION_LEN);

        ipe_out_pkt->pkt_len     = cpkt.pkt_len + HUMBER_HEADER_LEN;
        ipe_out_pkt->chan_id    = cpkt.chan_id;
        ipe_out_pkt->chip_id     = cpkt.chip_id;
        ipe_out_pkt->pkt_id      = cpkt.pkt_id;
        ipe_out_pkt->dest_queue     = SIM_FWD_Q;
        ipe_out_pkt->local_phy_port = HUMBER_CPU_RESOURCE_GROUPID;
        ipe_out_pkt->pkt            = cpkt.pkt;
        list_add_tail(&ipe_out_pkt->head, &ipe_out_pkt_head);
    }   
    /* FWD handle */
    list_for_each(pos_ipe, &ipe_out_pkt_head)
    {
        ipe_out_pkt = list_entry(pos_ipe, out_pkt_t, head);
        if (NULL == ipe_out_pkt->pkt)
        {
            lcm_show_forward_print_message("packet hard discard!\n");
            goto FREE_MEM_RSC;
        }

        ret = _lcm_show_forward_outpkt2qpkt(ipe_out_pkt, &qpkt_ipe);
        ipe_out_pkt->pkt = NULL;
        ipe_out_pkt->exception = NULL;

        if ( LCM_E_SUCCESS != ret)
        {
            lcm_show_forward_print_message("sim_outpkt2qpkt error!\n");
            goto FREE_MEM_RSC;
        }

        /*packet message*/    
        sal_snprintf(hello_msg, sizeof(hello_msg), "\n[ QMGT] packet is from: chip =%d(%d), channel=%d, pkt_len=%d\n",slot_num, 
                                                                                qpkt_ipe.chip_id, qpkt_ipe.chan_id, qpkt_ipe.pkt_len);   
        lcm_show_forward_print_data_in_hex(LCM_SHOW_FORWARD_FWD_PKT, (uint8*)qpkt_ipe.pkt, qpkt_ipe.pkt_len, hello_msg);

        ret = humber_dv_do_fwd(&qpkt_ipe, &fwd_out_pkt_head, NULL);
        if ( LCM_E_SUCCESS != ret)
        {
            sal_snprintf(hello_msg, sizeof(hello_msg), "dv_do_fwd error = %d!\n", (int32)ret);
            lcm_show_forward_print_message(hello_msg);           
            goto FREE_MEM_RSC;
        }
        /* EPE handle */
        list_for_each(pos_fwd, &fwd_out_pkt_head)
        {
            fwd_out_pkt = list_entry(pos_fwd, out_pkt_t, head);
            
            _lcm_show_forward_outpkt2ctcpkt(fwd_out_pkt,&lpbpkt);
            
            switch ( fwd_out_pkt->chan_id )
            {
                case HUMBER_I_LOOPBACK_CHAN_ID:
                    lcm_show_forward_process(&lpbpkt,pv_arg);
                    
                    break;
                case HUMBER_CPU_CHAN_ID:           
                    /*not support now,only print pkt info*/
//                    lcm_show_forward_process(&lpbpkt,pv_arg);
                    sal_snprintf(hello_msg, sizeof(hello_msg), "\n[ QMGT] packet is send to CPU: chip =%d(%d), channel=%d, pkt_len=%d\n",
                                                                        slot_num, qpkt_ipe.chip_id, qpkt_ipe.chan_id, qpkt_ipe.pkt_len);   
                    
                    lcm_show_forward_print_data_in_hex(LCM_SHOW_FORWARD_FWD_PKT, (uint8*)qpkt_ipe.pkt, 
                                                                                        qpkt_ipe.pkt_len, hello_msg);
                 
                    break;
                case HUMBER_CPU_OAM_CHAN_ID:
                    /*not support now,only print pkt info*/
//                    lcm_show_forward_process(&lpbpkt,pv_arg);
                    sal_snprintf(hello_msg, sizeof(hello_msg), "\n[ QMGT] packet is send to OAM: chip =%d(%d), channel=%d, pkt_len=%d\n",
                                                                         slot_num, qpkt_ipe.chip_id, qpkt_ipe.chan_id, qpkt_ipe.pkt_len);   
                    
                    lcm_show_forward_print_data_in_hex(LCM_SHOW_FORWARD_FWD_PKT, (uint8*)qpkt_ipe.pkt, 
                                                                                        qpkt_ipe.pkt_len, hello_msg);
                    break;

                default:
                    break;
            }

            switch ( fwd_out_pkt->dest_queue )
            {
                case SIM_NETTX_Q:
                    lcm_msg_tx_chsmshowfowardack(pv_arg, &lpbpkt);
                    break;
                    
                case SIM_EPE_Q:
                    _lcm_show_forward_outpkt2epkt(fwd_out_pkt, &epkt);

                    fwd_out_pkt->pkt = NULL;
                    fwd_out_pkt->exception = NULL;

                    ret = humber_dv_do_epe(&epkt, &epe_out_pkt_head);
                    if (LCM_E_SUCCESS != ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("dv_do_epe error, ret = %d!\n", (int32)ret);
                        goto FREE_MEM_RSC;
                    }

                    /*do Eloop or print packet message*/   
                    list_for_each(pos_epe, &epe_out_pkt_head)
                    {
                        epe_out_pkt = list_entry(pos_epe, out_pkt_t, head);

                        if (HUMBER_E_LOOPBACK_CHAN_ID == epe_out_pkt->chan_id)
                        {
                            _lcm_show_forward_outpkt2ctcpkt(epe_out_pkt,&lpbpkt);
                            lcm_show_forward_process(&lpbpkt,pv_arg);
                        }

                        snprintf(hello_msg, sizeof(hello_msg), "\n[ EPE ]  packet is to: chip =%d, channel=%d, pkt_len=%d\n",
                        epe_out_pkt->chip_id, epe_out_pkt->chan_id, epe_out_pkt->pkt_len); 
                        lcm_show_forward_print_data_in_hex(LCM_SHOW_FORWARD_EPE_PKT, (uint8*)epe_out_pkt->pkt, 
                                                                        epe_out_pkt->pkt_len, hello_msg);
                    }

                    break;
                case SIM_OAM_Q:
                    _lcm_show_forward_outpkt2oampkt(fwd_out_pkt, &oam_pkt);

                    fwd_out_pkt->pkt = NULL;
                    fwd_out_pkt->exception = NULL;
                    ret = humber_dv_do_oam(&oam_pkt, &oam_out_pkt_head);

                    if(LCM_E_SUCCESS != ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("OAM humber_dv_do_oam error! ret = %d\n", ret);
                        goto FREE_MEM_RSC;
                    }

                    list_for_each(pos_oam, &oam_out_pkt_head)
                    {
                        oam_out_pkt = list_entry(pos_oam, out_pkt_t, head);
                        if (SIM_NETTX_Q == oam_out_pkt->dest_queue)
                        {
                            CMODEL_DEBUG_OUT_INFO("OAM humber_dv_do_oam send packet to cpu!\n");
                            if (LCM_E_SUCCESS != ret)
                            {
                                CMODEL_DEBUG_OUT_INFO("sim_output_packet error, ret = %d!\n", (int32)ret);
                                goto FREE_MEM_RSC;
                            }
                        }
                        else if (SIM_FWD_Q == oam_out_pkt->dest_queue)
                        {
                            CMODEL_DEBUG_OUT_INFO("OAM engine send the packet to fwd!\n");
                            continue;
                        }
                        if (LCM_E_SUCCESS != ret)
                        {
                            CMODEL_DEBUG_OUT_INFO("OAM engine send outpkt to queue error ! ret = %d\n", ret);
                            goto FREE_MEM_RSC;
                        }

                        /*print packet message*/   
                        snprintf(hello_msg, sizeof(hello_msg), "\n[ OAM ] packet is to: chip =%d, channel=%d, pkt_len=%d\n",
                        oam_out_pkt->chip_id, oam_out_pkt->chan_id, oam_out_pkt->pkt_len); 
                        lcm_show_forward_print_data_in_hex(LCM_SHOW_FORWARD_OAM_PKT, (uint8*)oam_out_pkt->pkt, 
                        oam_out_pkt->pkt_len, hello_msg);
                    }

                    break;
                default:

                    break;
            }
        }
    }
FREE_MEM_RSC:
    list_for_each(pos_ipe,  &ipe_out_pkt_head)
    {
        ipe_out_pkt = list_entry(pos_ipe, out_pkt_t, head);
        if (NULL != ipe_out_pkt)
        {
            if (ipe_out_pkt->pkt)
            {
                sal_free(ipe_out_pkt->pkt);
            }
            if (ipe_out_pkt->exception)
            {
                sal_free(ipe_out_pkt->exception);
            }
        }
    }

    list_for_each(pos_fwd,  &fwd_out_pkt_head)
    {
        fwd_out_pkt = list_entry(pos_fwd, out_pkt_t, head);
        if (NULL != fwd_out_pkt)
        {
            if (fwd_out_pkt->pkt)
            {
                sal_free(fwd_out_pkt->pkt);
            }
            if (fwd_out_pkt->exception)
            {
                sal_free(fwd_out_pkt->exception);
            }
        }
    }

    list_for_each(pos_epe,  &epe_out_pkt_head)
    {
        epe_out_pkt = list_entry(pos_epe, out_pkt_t, head);
        if (NULL != epe_out_pkt)
        {
            if (epe_out_pkt->pkt)
            {
                sal_free(epe_out_pkt->pkt);
            }
            if (epe_out_pkt->exception)
            {
                sal_free(epe_out_pkt->exception);
            }
        }
    }

    list_for_each(pos_oam,  &oam_out_pkt_head)
    {
        oam_out_pkt = list_entry(pos_oam, out_pkt_t, head);
        if (NULL != oam_out_pkt)
        {
            if (oam_out_pkt->pkt)
            {
                sal_free(oam_out_pkt->pkt);
            }
            if (oam_out_pkt->exception)
            {
                sal_free(oam_out_pkt->exception);
            }
        }
    }

    list_del_all_and_free(&ipe_out_pkt_head);
    list_del_all_and_free(&fwd_out_pkt_head);
    list_del_all_and_free(&epe_out_pkt_head);
    list_del_all_and_free(&oam_out_pkt_head);

    /*send logging file to chsm*/
    LCM_IF_ERROR_RETURN(_lcm_show_forward_send_log_file(pv_arg));
    
    return LCM_E_SUCCESS;
}
#endif
