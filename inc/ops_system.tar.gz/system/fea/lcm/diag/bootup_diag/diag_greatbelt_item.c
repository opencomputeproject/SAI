#ifdef BOOTUP_DIAG
#include "glb_hw_define.h"
#include "diag_types.h"
#include "diag_item_prepare_cb.h"
#include "diag_item_run_cb.h"
#include "diag_item_report_cb.h"
#include "diag_item_finish_cb.h"
#include "lcm.h"
#include "lcm_diag.h"
#include "lcapi.h"
#include "lcm_mgt.h"
#include "ctclib_thread.h"

#include "diag_pkt_drv.h"
#include "diag_chip.h"
#include "diag_greatbelt_item.h"
#include "diag_util.h"
#include "ctc_api.h"
#include "drv_error.h"
#include "genlog.h"

/***************************************************************************
*
 *
* Defines and Macros
*
****************************************************************************
*/

#define DIAG_VLAN_BASE              100     /*vid = diag_vlan_base + port*/
#define DMA_TO_CPU_CHAN_ID          63

struct diag_ucast_s
{
    mac_addr_t macda;
    uint8 dest_vlan;                             /*less than diag_vlan_base*/
    uint8 dest_port;
    uint8 port_list[MAX_PORT_NUM_PER_CHIP];      /*if the array elemet indexed by port number is 1,start snake test */
    uint16 vlan_list[MAX_PORT_NUM_PER_CHIP];     /*bind with fdb*/
    uint8 port_num;
    uint8 end_vlan_to_cpu;
};
typedef struct diag_ucast_s diag_ucast_t;

diag_ucast_t g_diag_ucast_info;

/***************************************************************************
*
 *
* Function
*
****************************************************************************
*/

/* Modified by liuht for bug26853, 2013-01-20 */
/* get global port id */
static int32 get_gport_id(uint16 mac_id, uint16 *gport)
{
    glb_card_t* p_card = NULL;
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "device decfg : card is NULL.\n");
        LCM_DIAG_CONSOLE_PRINT("device decfg : card is NULL.\n");
        return -1;
    }
    *gport = (p_card->phy_slot_no << 8) | (mac_id);
    return 0;
}

static int32
_diag_vlan_init(uint16 vid)
{
    CTC_ERROR_RETURN(ctc_vlan_create_vlan(vid));
    BOOTUP_DIAG_DEBUG("_diag_vlan_init vid =%d.\n",vid);
    return DRV_E_NONE;
}

static int32
_diag_vlan_deinit(uint16 vid)
{
    CTC_ERROR_RETURN(ctc_vlan_destroy_vlan(vid));
    BOOTUP_DIAG_DEBUG("ctc_vlan_destroy_vlan vid =%d.\n",vid);
    return DRV_E_NONE;
}

static int32
_diag_add_l2ucast_to_port(uint16 vid, uint16 dest_port) {
    ctc_l2_addr_t l2_addr;
    uint8 i = 0;
    int32 ret = 0;

    BOOTUP_DIAG_DEBUG("_diag_add_l2ucast_to_port vid =%d,dest_port = %d.\n",vid,dest_port);
    sal_memset(&l2_addr, 0, sizeof(l2_addr));

    l2_addr.fid = vid;
    l2_addr.gport = dest_port;
    l2_addr.flag |= CTC_L2_FLAG_IS_STATIC;

    for(i=0; i<CTC_ETH_ADDR_LEN; i++)
    {
        l2_addr.mac[i] = g_diag_ucast_info.macda[i];
    }
    /* Modified by liuht for bug26853, 2013-01-20 */
    ret = ctc_l2_add_fdb(&l2_addr);
    if(ret)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "vid %d gport %d l2 add fdb fail : %d!\n", vid , dest_port, ret);
        LCM_DIAG_CONSOLE_PRINT("vid %d gport %d l2 add fdb fail : %d!\n", vid , dest_port, ret);
    }

    return ret;
}

static int32
_diag_del_l2ucast(uint16 vid, uint16 dest_port)
{
    ctc_l2_addr_t l2_addr;
    uint8 i = 0;
    int32 ret = 0;

    BOOTUP_DIAG_DEBUG("_diag_del_l2ucast vid =%d,port = %d.\n",vid,dest_port);
    sal_memset(&l2_addr, 0, sizeof(l2_addr));	

    l2_addr.fid = vid;
	
    /*delete used fdb in ucast test*/
    for(i=0; i<CTC_ETH_ADDR_LEN; i++)
    {
       l2_addr.mac[i] = g_diag_ucast_info.macda[i];
    }
    /* Modified by liuht for bug26853, 2013-01-20 */	
    ret = ctc_l2_remove_fdb(&l2_addr);
    if(ret)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "vid %d gport %d l2 remove fdb fail!: %d\n", vid , dest_port, ret);
	 LCM_DIAG_CONSOLE_PRINT("vid %d gport %d l2 remove fdb fail!: %d\n", vid , dest_port, ret);
    }
    
    return DRV_E_NONE;
}

/* Modified by liuht for bug26853, 2013-01-20 */
/* Replace mac id with global id */
int32
diag_start_l2ucast_to_cpu(diag_ucast_t ucast)
{
    uint32 port = 0;
    uint16 gport = 0;
    uint32 first_port = 0xFFFFFFFF;
    uint32 last_port = 0xFFFFFFFF;
    uint32 pre_port = 0xFFFFFFFF;
    int32 ret = 0;

    sal_memset(&g_diag_ucast_info, 0, sizeof(ucast));
    sal_memcpy(&g_diag_ucast_info, &ucast, sizeof(ucast));
    for(port=0; port<MAX_PORT_NUM_PER_CHIP; port++)
    {
        if(1 == ucast.port_list[port])
        {
             
            get_gport_id(port, &gport);
            /* set mac enable */
            ret = ctc_port_set_mac_en(gport, TRUE);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "ctc port set gport %d enable fail! : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("ctc port set gport %d enable fail! : %d\n", gport, ret);
            }
            /* init vlan */
            ret = _diag_vlan_init(DIAG_VLAN_BASE + port);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "vlan %d create fail : %d\n", (DIAG_VLAN_BASE + port), ret);
                LCM_DIAG_CONSOLE_PRINT("vlan %d create fail : %d\n", (DIAG_VLAN_BASE + port), ret);
            }
            /* set default vlan */
            ret = ctc_port_set_default_vlan(gport, DIAG_VLAN_BASE+ port);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "gport %d set default vlan %d fail : %d\n", gport, (DIAG_VLAN_BASE + port), ret);
                LCM_DIAG_CONSOLE_PRINT("gport %d set default vlan %d fail : %d\n", gport, (DIAG_VLAN_BASE + port), ret);
            }
            /* set dot1q type */
            ret = ctc_port_set_dot1q_type(gport, CTC_DOT1Q_TYPE_NONE);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "gport %d set dot1q type none fail : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("gport %d set dot1q type none  fail : %d\n", gport, ret);
            } 
            /*add fdb*/
            if(0xFFFFFFFF == first_port)
            {
                first_port = port;
                pre_port = port;
            }
            else
            {
                CTC_ERROR_RETURN(_diag_add_l2ucast_to_port(DIAG_VLAN_BASE+pre_port, gport));
                g_diag_ucast_info.vlan_list[port] = DIAG_VLAN_BASE+pre_port;
                pre_port = port;
            }
        }
        else
        {
            continue;
        }
    }

    if(MAX_PORT_NUM_PER_CHIP == port)
    {
        last_port = pre_port;
        get_gport_id(DMA_TO_CPU_CHAN_ID, &gport);
        CTC_ERROR_RETURN(_diag_add_l2ucast_to_port(DIAG_VLAN_BASE+pre_port,gport));	
        g_diag_ucast_info.end_vlan_to_cpu = DIAG_VLAN_BASE+pre_port;
    }
    
    return DRV_E_NONE;
}

/* Modified by liuht for bug26853, 2013-01-20 */
/* Replace mac id with global id */
/*delete l2ucast config*/
int32
diag_del_l2ucast_to_cpu()
{
    int32 ret = 0;
    uint32 port = 0;
    uint16 gport = 0;	
    uint32 first_port = 1;	
    glb_card_t* p_card = NULL;
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "diag delete l2ucast to cpu : card is NULL.\n");
        LCM_DIAG_CONSOLE_PRINT("diag delete l2ucast to cpu : card is NULL.\n");
        return -1;
    }	
    for(port=0; port<MAX_PORT_NUM_PER_CHIP; port++)
    {
        if(1 == g_diag_ucast_info.port_list[port])
        {
            get_gport_id(port, &gport);
            /* clear port mac counters */				
            ret = ctc_stats_clear_mac_stats(gport, CTC_STATS_MAC_STATS_RX);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "clear gport %d mac rx stats fail : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("clear gport %d mac rx stats fail : %d\n", gport, ret);
            }	
            ret = ctc_stats_clear_mac_stats(gport, CTC_STATS_MAC_STATS_TX);	
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "clear gport %d mac tx stats fail : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("clear gport %d mac tx stats fail : %d\n", gport, ret);
            }	
            /*deinit port mac*/
            ret = ctc_port_set_mac_en(gport, FALSE);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "set gport %d mac disable fail : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("set gport %d mac disable fail : %d\n", gport, ret);
            }	
            
            /*deinit port and vlan*/
            ret = ctc_port_set_default_vlan(gport, 1);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "set gport %d default vlan 1 fail : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("set gport %d default vlan 1 fail : %d\n", gport, ret);
            }	
            ret = _diag_vlan_deinit(DIAG_VLAN_BASE + port);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "destroy vlan %d fail : %d\n", (DIAG_VLAN_BASE + port), ret);
                LCM_DIAG_CONSOLE_PRINT("destroy vlan %d fail : %d\n", (DIAG_VLAN_BASE + port), ret);
            }	
            ret = ctc_port_set_dot1q_type(gport, CTC_DOT1Q_TYPE_BOTH);
            if(ret)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "set gport %d dot1q type both fail! : %d\n", gport, ret);
                LCM_DIAG_CONSOLE_PRINT("set gport %d dot1q type both fail! : %d \n", gport, ret);
            }	

            if(1 == first_port)
            {
                first_port = 0;
                continue;	
            }			
            _diag_del_l2ucast(g_diag_ucast_info.vlan_list[port], gport);			
        }
    }	
    _diag_del_l2ucast(g_diag_ucast_info.end_vlan_to_cpu, DMA_TO_CPU_CHAN_ID);		
    sal_memset(&g_diag_ucast_info, 0, sizeof(g_diag_ucast_info));

    return DRV_E_NONE;
}

int32 diag_ucast_cfg (diag_cfg_req_t * req)
{
    diag_ucast_t ucast;
    uint8 i = 0,mac_id;
    
    sal_memset(&ucast, 0, sizeof(ucast));
    
    ucast.macda[5] = 1;

    ucast.port_num = req->port_nums;

    for(i=0; i<ucast.port_num; i++)
    {
        if(req->p_port_info[i].port_exist)
        {
            mac_id = req->p_port_info[i].mac_id;
            ucast.port_list[mac_id] = 1;
        }
        
    }
    CTC_ERROR_RETURN(diag_start_l2ucast_to_cpu(ucast));

    return DRV_E_NONE;
}

#define UINT64_TO_STR(data, str)                                    \
do{                                                                 \
    sal_memset(str, 0x00, 32);                    \
    sal_snprintf(str, 32, "%llu", data);          \
}while(0)

void mac_stats_dump(uint16 port,ctc_stats_mac_rec_t * rx,ctc_stats_mac_snd_t *tx,diag_operator_t *p_oper)
{
    char str[32];

    sal_fprintf(p_oper->log_fp,"++++dump port %d mac stats++++\n", port);        
      
    UINT64_TO_STR(rx->good_ucast_pkts     ,str); 
    sal_fprintf(p_oper->log_fp  , "rx->good_ucast_pkts       = %s  \n",str);

    UINT64_TO_STR(rx->good_ucast_bytes,str); 
    sal_fprintf(p_oper->log_fp  , "rx->good_ucast_bytes       = %s  \n",str);	
        
    UINT64_TO_STR(rx->good_mcast_pkts     ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_mcast_pkts       = %s  \n",str);

    UINT64_TO_STR(rx->good_mcast_bytes,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_mcast_bytes       = %s  \n",str);	
    
    UINT64_TO_STR(rx->good_bcast_pkts      ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_bcast_pkts       = %s  \n",str);

    UINT64_TO_STR(rx->good_bcast_bytes,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_bcast_bytes       = %s  \n",str);	
    
    UINT64_TO_STR(rx->good_pause_pkts      ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_pause_pkts       = %s  \n",str);
    
    UINT64_TO_STR(rx->good_control_pkts    ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_control_pkts     = %s  \n",str);
    
    UINT64_TO_STR(rx->jabber_pkts          ,str);    
    sal_fprintf(p_oper->log_fp  , "rx->jabber_pkts           = %s  \n",str);
    
    UINT64_TO_STR(rx->collision_pkts       ,str);
    sal_fprintf(p_oper->log_fp  , "rx->collision_pkts        = %s  \n",str);
    
    UINT64_TO_STR(rx->fcs_error_pkts       ,str);
    sal_fprintf(p_oper->log_fp  , "rx->fcs_error_pkts        = %s  \n",str);
    
    UINT64_TO_STR(rx->alignment_error_pkts , str);
    sal_fprintf(p_oper->log_fp  , "rx->alignment_error_pkts  = %s  \n",str);
    
    UINT64_TO_STR(rx->mac_overrun_pkts     ,str);
    sal_fprintf(p_oper->log_fp  , "rx->mac_overrun_pkts      = %s  \n",str);
    
    UINT64_TO_STR(rx->good_oversize_pkts   ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_oversize_pkts    = %s  \n",str);
    
    UINT64_TO_STR(rx->good_undersize_pkts  ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_undersize_pkts   = %s  \n",str);
    
    UINT64_TO_STR(rx->gmac_good_oam_pkts   ,str);
    sal_fprintf(p_oper->log_fp  , "rx->gmac_good_oam_pkts    = %s  \n",str);
    
    UINT64_TO_STR(rx->good_63_pkts         ,str);    
    sal_fprintf(p_oper->log_fp  , "rx->good_63_pkts          = %s  \n",str);
    
    UINT64_TO_STR(rx->bad_63_pkts          ,str);
    sal_fprintf(p_oper->log_fp  , "rx->bad_63_pkts           = %s  \n",str);
    
    UINT64_TO_STR(rx->good_1519_pkts       ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_1519_pkts        = %s  \n",str);
    
    UINT64_TO_STR(rx->bad_1519_pkts        ,str);
    sal_fprintf(p_oper->log_fp  , "rx->bad_1519_pkts         = %s  \n",str);
    
    UINT64_TO_STR(rx->good_jumbo_pkts      ,str);
    sal_fprintf(p_oper->log_fp  , "rx->good_jumbo_pkts       = %s  \n",str);
    
    UINT64_TO_STR(rx->bad_jumbo_pkts       ,str);
    sal_fprintf(p_oper->log_fp  , "rx->bad_jumbo_pkts        = %s  \n",str);
    
    UINT64_TO_STR(rx->pkts_64              ,str);
    sal_fprintf(p_oper->log_fp  , "rx->pkts_64               = %s  \n",str);
    
    UINT64_TO_STR(rx->pkts_65_to_127       ,str);
    sal_fprintf(p_oper->log_fp  , "rx->pkts_65_to_127        = %s  \n",str);
    
    UINT64_TO_STR(rx->pkts_128_to_255      ,str);
    sal_fprintf(p_oper->log_fp  , "rx->pkts_128_to_255       = %s  \n",str);
    
    UINT64_TO_STR(rx->pkts_256_to_511      ,str);
    sal_fprintf(p_oper->log_fp  , "rx->pkts_256_to_511       = %s  \n",str);
    
    UINT64_TO_STR(rx->pkts_512_to_1023     ,str);
    sal_fprintf(p_oper->log_fp  , "rx->pkts_512_to_1023      = %s  \n",str);
    
    UINT64_TO_STR(rx->pkts_1024_to_1518    ,str);
    sal_fprintf(p_oper->log_fp  , "rx->pkts_1024_to_1518     = %s  \n",str);

    UINT64_TO_STR(tx->good_ucast_pkts      ,str);    
    sal_fprintf(p_oper->log_fp  , "tx->good_ucast_pkts       = %s  \n",str);

    UINT64_TO_STR(tx->good_ucast_bytes,str);    
    sal_fprintf(p_oper->log_fp  , "tx->good_ucast_bytes       = %s  \n",str);	
    
    UINT64_TO_STR(tx->good_mcast_pkts      ,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_mcast_pkts       = %s  \n",str);

    UINT64_TO_STR(tx->good_mcast_bytes,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_mcast_bytes       = %s  \n",str);	
    
    UINT64_TO_STR(tx->good_bcast_pkts      ,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_bcast_pkts       = %s  \n",str);

    UINT64_TO_STR(tx->good_bcast_bytes,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_bcast_bytes       = %s  \n",str);	
    
    UINT64_TO_STR(tx->good_pause_pkts      ,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_pause_pkts       = %s  \n",str);
    
    UINT64_TO_STR(tx->good_control_pkts    ,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_control_pkts     = %s  \n",str);
    
    UINT64_TO_STR(tx->good_oam_pkts        ,str);
    sal_fprintf(p_oper->log_fp  , "tx->good_oam_pkts         = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_63              ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_63               = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_64              ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_64               = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_65_to_127       ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_65_to_127        = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_128_to_255      ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_128_to_255       = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_256_to_511      ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_256_to_511       = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_512_to_1023     ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_512_to_1023      = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_1024_to_1518    ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_1024_to_1518     = %s  \n",str);
    
    UINT64_TO_STR(tx->pkts_1519            ,str);
    sal_fprintf(p_oper->log_fp  , "tx->pkts_1519             = %s  \n",str);
    
    UINT64_TO_STR(tx->jumbo_pkts           ,str);
    sal_fprintf(p_oper->log_fp  , "tx->jumbo_pkts            = %s  \n",str);
    
    UINT64_TO_STR(tx->mac_underrun_pkts    ,str);
    sal_fprintf(p_oper->log_fp  , "tx->mac_underrun_pkts     = %s  \n",str);
    
    UINT64_TO_STR(tx->fcs_error_pkts       ,str);
    sal_fprintf(p_oper->log_fp  , "tx->fcs_error_pkts        = %s  \n",str);

    sal_fprintf(p_oper->log_fp,"----dump port %d mac stats----\n", port);
}

/* Modified by liuht for bug26853, 2013-01-20 */
/* Replace mac id with global id */
int32 check_chip_allmac_crc(diag_operator_t *p_oper)
{
    uint16 port = 0;
    uint16 gport = 0;
    uint16 mac_id = 0xffff;
    int32 ret = 0;
    ctc_mac_stats_t mac_rx_stats, mac_tx_stats;
    glb_card_t* p_card = NULL;
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "check chip allmac crc : card is NULL.\n");
        LCM_DIAG_CONSOLE_PRINT("check chip allmac crc : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "check chip allmac crc : card is NULL.\n");
        return -1;
    }	

    sal_memset(&mac_rx_stats, 0, sizeof(ctc_mac_stats_t));
    sal_memset(&mac_tx_stats, 0, sizeof(ctc_mac_stats_t));
    for(port= 0; port< p_card->port_num; port++)
    {
        mac_id = p_card->pp_port[port]->mac_idx;
        get_gport_id(mac_id, &gport);
        mac_rx_stats.stats_mode = CTC_STATS_MODE_DETAIL;
        ret += ctc_stats_get_mac_stats(gport, CTC_STATS_MAC_STATS_RX, &mac_rx_stats);
	 if(ret)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "ctc_stats_get_mac_stats gport %d fail\n", gport);
            sal_fprintf(p_oper->log_fp,"ctc_stats_get_mac_stats gport %d fail\n", gport);
            LCM_DIAG_CONSOLE_PRINT("ctc_stats_get_mac_stats gport %d fail\n", gport);
        }
	 mac_tx_stats.stats_mode = CTC_STATS_MODE_DETAIL;	
        ret += ctc_stats_get_mac_stats(gport, CTC_STATS_MAC_STATS_TX, &mac_tx_stats);	
	 if(ret)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "ctc_stats_get_mac_stats gport %d fail : %d\n", gport, ret);
            sal_fprintf(p_oper->log_fp,"ctc_stats_get_mac_stats gport %d fail : %d\n", gport, ret);
            LCM_DIAG_CONSOLE_PRINT("ctc_stats_get_mac_stats gport %d fail : %d\n", gport, ret);
        }
	 mac_stats_dump(port,&mac_rx_stats.u.stats_detail.stats.rx_stats,&mac_rx_stats.u.stats_detail.stats.tx_stats,p_oper);		
	 if((mac_rx_stats.u.stats_detail.stats.rx_stats.good_undersize_pkts != 0) || (mac_rx_stats.u.stats_detail.stats.rx_stats.good_oversize_pkts != 0) ||
          (mac_rx_stats.u.stats_detail.stats.rx_stats.jabber_pkts != 0) || (mac_rx_stats.u.stats_detail.stats.rx_stats.collision_pkts != 0) ||
          (mac_rx_stats.u.stats_detail.stats.rx_stats.fcs_error_pkts != 0) || (mac_rx_stats.u.stats_detail.stats.rx_stats.alignment_error_pkts != 0) ||
          (mac_rx_stats.u.stats_detail.stats.tx_stats.fcs_error_pkts != 0) || (mac_rx_stats.u.stats_detail.stats.tx_stats.mac_underrun_pkts != 0))
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "check_chip_allmac_crc gport:%d ,get crc error %d\n", gport, ret);
            sal_fprintf(p_oper->log_fp,"check_chip_allmac_crc gport:%d ,get crc error %d\n", gport, ret);
            LCM_DIAG_CONSOLE_PRINT("check_chip_allmac_crc gport:%d ,get crc error %d\n", gport, ret);
        }
    }
    return ret;
}

int32 
diag_item_prepare_l2ucast_func (diag_operator_t *p_oper)
{
    int32 ret =0;
    BOOTUP_DIAG_DEBUG("lcm diag prepare l2ucast func \n");   
    ret += diag_item_prepare_common(p_oper);
    ret += lcm_diag_device_cfg(p_oper);
    ret += lcm_diag_l2ucast_func_chip_cfg(p_oper);
    ret += lcm_diag_l2ucast_func_flag_set(p_oper);
    sleep(1);
    return ret;  
}

int32 
diag_item_run_l2ucast_func(diag_operator_t *p_oper)
{
    BOOTUP_DIAG_DEBUG("lcm diag run l2ucast func \n"); 
    diag_item_async_run_common(p_oper); 
      
    lcm_diag_start_timer(p_oper);
    	
    diag_send_l2ucast_pkt_bydma(p_oper);	
    lcm_diag_rx_packet_polling(p_oper);	
    BOOTUP_DIAG_DEBUG("lcm diag run l2ucast func end \n");  
    return DIAG_WAIT;
}


int32 
diag_item_report_l2ucast_func(diag_operator_t *p_oper)
{
    int32 ret;
    int32 result = 0;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);

    glb_card_t* p_card = NULL;
    BOOTUP_DIAG_DEBUG("lcm diag report l2ucast func \n"); 
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "Report l2ucast func : card is NULL.\n");
        LCM_DIAG_CONSOLE_PRINT("Report l2ucast func : card is NULL.\n");	
        sal_fprintf(p_oper->log_fp, "Report l2ucast func : card is NULL.\n");
        return -1;
    }

    sal_fprintf(p_oper->log_fp, "check_chip_allmac_crc.\n");	
    check_chip_allmac_crc(p_oper);	    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    result = p_item->rslt->chip_result[0];
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "l2ucst function test fail!\n");	
    LCM_DIAG_CONSOLE_PRINT("l2ucst function test fail!\n");		
    sal_fprintf(p_oper->log_fp, "l2ucst function test fail!\n");
    return ret;
}

int32 
diag_item_finish_l2ucast_func(diag_operator_t *p_oper)
{
    BOOTUP_DIAG_DEBUG("lcm diag finish l2ucast func \n"); 
    diag_item_finish_common(p_oper);
    lcm_diag_device_decfg(p_oper);
    lcm_diag_l2ucast_func_chip_decfg(p_oper);	
    lcm_diag_l2ucast_func_flag_unset(p_oper);	
    return 0;
}

diag_item_ops_t diag_ops_l2ucast_func = 
{
    .prepare = diag_item_prepare_l2ucast_func,
    .run = diag_item_run_l2ucast_func,
    .report = diag_item_report_l2ucast_func,
    .finish = diag_item_finish_l2ucast_func
};
#endif

