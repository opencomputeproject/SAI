#ifdef BOOTUP_DIAG
#include "sal_common.h"
#include "humber_api.h"
#include "diag_chip.h"


int32 sram_data[4];
int32 tcam_data[4];
int32 tcam_mask[4];

static char* EXT_TCAM_MASK[]=
{ 
   
    "00000000000000000000000000000000", 
#if 0        
    "00000000000000000000000000000000",     
    "00000000000000000000000000000000",
    "00000000000000000000000000000000",    
    "00000000000000000000000000000000",
    "00000000000000000000000000000000",
    "00000000000000000000000000000000",
    "00000000000000000000000000000000",   
    "0000000000000000000000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000",
    "0000000000000000000000000000000000000000000000000000000000000000",   
#endif    
};
static char* INT_TCAM_MASK[]=
{
    "ffffffffffffffffffffffffffffffff",
#if 0        
    "ffffffffffffffffffffffffffffffff",
    "ffffffffffffffffffffffffffffffff",
    "ffffffffffffffffffffffffffffffff",
#endif    
};

static char* INT_TCAM_KEY[]=
{
    "0000000000000000000000000000000a	0	0	0",
#if 0        
    "00000000000011111111111111111111	0	0	1",	
	"00000000000022222222222222222222	0	0	2",
	"00000000000033333333333333333333	0	0	3",    
#endif
};

static char* EXT_TCAM_KEY[]=
{  
	"0000000000000000000000000000000a	0	0	0",  
#if 0        
	"00000000000011111111111111111111	0	0	1",	
	"00000000000022222222222222222222	0	0	2",
	"00000000000033333333333333333333	0	0	3",
	"00000000000010201020102010201020	0	0	3fc",
	"00000000000010211021102110211021	0	0	3fd",
	"00000000000010221022102210221022	0	0	3fe",
	"00000000000010231023102310231023	0	0	3ff",	
	"0000000000004096409640964096409600000000000040974097409740974097	1	0	4000",
    "0000000000004098409840984098409800000000000040994099409940994099	1	0	4002",
    "0000000000005116511651165116511600000000000051175117511751175117	1	0	43fc",
    "0000000000005118511851185118511800000000000051195119511951195119	1	0	43fe", 
#endif    
};

void 
diagnostic_run_ddr_bist(uint32 chip_id)
{

    

    uint32 entry;

    uint32 ddrControl, ddrBistCtrl, ddrBistExpRam, ddrBistReqRam;

    uint32 ddrBistRltRam;

    uint32 ramAccessValid, ramAccessRead, ramAccessLoad,ramAddress,rltCompValid,readDataValid;

    uint32 ramData8,ramData32;

    uint32 bistEn, stopOnError, bistEntry;

    uint32 offset,value;

    uint32 addr[6], data[6];

    uint32 i,startAddr;

    

    uint8 PIDDR_ENTRY=0;

    ddrControl = DDR_CONTROL_ADDR;

    ddrBistCtrl = DDR_BISTCTRL_ADDR;

    ddrBistReqRam = DDR_BISTREQRAM_ADDR;

    ddrBistExpRam = DDR_BISTEXPRAM_ADDR;

    ddrBistRltRam = DDR_BISTRLTRAM_ADDR;

 

    /*save sram entry 0 data */

    startAddr = DDR_SRAM_BASE;

    for(i=0; i<4; i++)

    {
        
        asic_reg_read(chip_id,  startAddr+4*i, (uint32 *)&(sram_data[i]));

    } 

    

    //jcao genlei qdrbist.config set value 0x20001511

    asic_reg_write(chip_id, ddrControl, 0x20001511);

        

    addr[0] = 0x00000000 ;

    

    data[0] = 0xffffffff;

    

        

    /*write bist*/

    for(entry=0; entry<PIDDR_ENTRY+1; entry++)

    {            

        if(entry < PIDDR_ENTRY)

        {

            value = 0xffffffff-(1<<entry);

            ramData8 = value & 0xf;

            ramData32 = value;

            ramAddress = 1<<entry;

        }

        else

        {

            ramData8 = data[entry-PIDDR_ENTRY]&0xf;

            ramData32 = data[entry-PIDDR_ENTRY];

            ramAddress = addr[entry-PIDDR_ENTRY];

        }

        /*config request*/

        ramAccessValid = 1;

        ramAccessLoad = 1;

        offset = ddrBistReqRam + entry*16;

        value = (ramAccessValid<<30) + (ramAccessLoad<<28) + (ramAddress<<8) + ramData8;

 

        

       

        asic_reg_write(chip_id, offset, (uint32)(value));

        

        asic_reg_write(chip_id, offset+4, (uint32)(ramData32));

        

        asic_reg_write(chip_id, offset+8, (uint32)(ramData8));

        

        asic_reg_write(chip_id, offset+12, (uint32)(ramData32));

    

        /*config expect*/

        rltCompValid = 1;

        offset = ddrBistExpRam+entry*16;

        value = rltCompValid<<30;

        

        

        asic_reg_write(chip_id, offset, (uint32)(value));

        

        asic_reg_write(chip_id, offset+4, 0);

        

        asic_reg_write(chip_id, offset+8, 0);

        

        asic_reg_write(chip_id, offset+12, 0);

    }

    /*nop 1 when write to read*/

    entry = PIDDR_ENTRY+1;

    ramAccessValid = 1;

    ramAccessLoad = 0;

    offset = ddrBistReqRam + entry*16;

    value = (ramAccessValid<<30) + (ramAccessLoad<<28) + 0;

        /*config request*/

    

    asic_reg_write(chip_id, offset, (uint32)(value));

    asic_reg_write(chip_id, offset+4, 0);    

    asic_reg_write(chip_id, offset+8, 0);   

    asic_reg_write(chip_id, offset+12, 0);

    

        /*config expect*/

    rltCompValid = 0;

    offset = ddrBistExpRam+entry*16;

    value = rltCompValid<<30;

    

    asic_reg_write(chip_id, offset, (uint32)(value));

    asic_reg_write(chip_id, offset+4, 0);    

    asic_reg_write(chip_id, offset+8, 0);   

    asic_reg_write(chip_id, offset+12, 0);

    

    

    /*read bist*/

    for(entry=PIDDR_ENTRY+1+1; entry<PIDDR_ENTRY*2+2+1; entry++)

    {

        if(entry < PIDDR_ENTRY*2+1+1)

        {

            ramAddress = 1<<(entry-PIDDR_ENTRY-1-1);

            value = 0xffffffff-(1<<(entry-PIDDR_ENTRY-1-1));

            ramData8 = value & 0xf;

            ramData32 = value;

        }

        else

        {

            ramAddress = addr[entry-PIDDR_ENTRY*2-1-1];

            ramData8 = data[entry-PIDDR_ENTRY*2-1-1]&0xf;

            ramData32 = data[entry-PIDDR_ENTRY*2-1-1];

        }

        /*config request*/

        ramAccessValid = 1;

        ramAccessRead = 1;

        ramAccessLoad = 1;

        offset = ddrBistReqRam+entry*16;

        value = (ramAccessValid<<30)+(ramAccessRead<<29)+(ramAccessLoad<<28)

            +(ramAddress<<8);

        

        asic_reg_write(chip_id, offset, (value));

        asic_reg_write(chip_id, offset+4, 0);    

        asic_reg_write(chip_id, offset+8, 0);   

        asic_reg_write(chip_id, offset+12, 0);

            

 

        /*config expect*/

        rltCompValid = 1;

        readDataValid = 1;        

        offset = ddrBistExpRam+entry*16;

        value = (rltCompValid<<30)+(readDataValid<<29)+ramData8;

        

        asic_reg_write(chip_id, offset, (value));

        asic_reg_write(chip_id, offset+4, (uint32)(ramData32));    

        asic_reg_write(chip_id, offset+8, (uint32)(ramData8));   

        asic_reg_write(chip_id, offset+12, (uint32)(ramData32));

        

    }

 

    /*nop 2 when read to write*/

    for(entry=PIDDR_ENTRY*2+2+1; entry<PIDDR_ENTRY*2+2+3; entry++)

    {

        ramAccessValid = 1;

        ramAccessLoad = 0;

        offset = ddrBistReqRam + entry*16;

        value = (ramAccessValid<<30) + (ramAccessLoad<<28) + 0;

            /*config request*/

        

        asic_reg_write(chip_id, offset, (value));

        asic_reg_write(chip_id, offset+4, 0);    

        asic_reg_write(chip_id, offset+8, 0);   

        asic_reg_write(chip_id, offset+12, 0);

                    

 

            /*config expect*/

        rltCompValid = 0;

        offset = ddrBistExpRam+entry*16;

        value = rltCompValid<<30;

        

        asic_reg_write(chip_id, offset, (value));

        asic_reg_write(chip_id, offset+4, 0);    

        asic_reg_write(chip_id, offset+8, 0);   

        asic_reg_write(chip_id, offset+12, 0);

        

    }

    /*enable bist*/

    bistEn = 1;

    stopOnError = 1;

    bistEntry = PIDDR_ENTRY*2+1*2+3-1;

    value = (bistEn<<13)+(6<<8)+(stopOnError<<7)+bistEntry;    

    

    asic_reg_write(chip_id, ddrBistCtrl, (value));

 

}

 

void 
diagnostic_run_qdr_bist(uint32 chip_id)
{
    uint32 entry;

    uint32 qdrControl, qdrBistCtrl, qdrBistExpRam, qdrBistReqRam;

    uint32 ramAccessValid, ramAccessRead, ramAccessWrite;

    uint32 ramReadAddress,ramWriteAddress,rltCompValid,readDataValid;

    uint32 ramData8, ramData32;

    uint32 bistEn, stopOnError, bistEntry;

    uint32 offset,value;

    uint32 addr[6], data[6];

    uint32 i,startAddr;

    

    uint8 PBQDR_ENTRY=0;

    

    

    qdrControl = QDR_CONTROL_ADDR;

    qdrBistCtrl = QDR_BISTCTRL_ADDR;

    qdrBistReqRam = QDR_BISTREQRAM_ADDR;

    qdrBistExpRam = QDR_BISTEXPRAM_ADDR;

 

    /*save sram entry 0 data */

    startAddr = QDR_SRAM_BASE;

    for(i=0; i<4; i++)

    {

        asic_reg_read(chip_id,  startAddr+4*i, (uint32 *)&(sram_data[i]));

    } 

 

    addr[0] = 0x00000000 ;

   

    data[0] = 0xffffffff;

 

 

    /*write bist*/

    for(entry=0; entry<PBQDR_ENTRY+1; entry++)

    {            

        if(entry < PBQDR_ENTRY)

        {

            value = 0xffffffff-(1<<entry);

            ramData8 = value & 0xf;

            ramData32 = value;

            ramWriteAddress = 1<<entry;

        }

        else

        {

            ramData8 = data[entry-PBQDR_ENTRY]&0xf;

            ramData32 = data[entry-PBQDR_ENTRY];

            ramWriteAddress = addr[entry-PBQDR_ENTRY];

        }

 

        /*config request*/

        ramAccessValid = 1;

        ramAccessWrite = 1;

        offset = qdrBistReqRam + entry*16;

        

        value = (ramAccessValid<<30)+(ramAccessWrite<<28)+ramData8;

        asic_reg_write(chip_id, offset, (uint32)(value));

        asic_reg_write(chip_id, offset + 4, (uint32)(ramData32));

        value = (ramWriteAddress<<8) + ramData8;

        asic_reg_write(chip_id, offset + 8, (uint32)(value));

        asic_reg_write(chip_id, offset + 12, (uint32)(ramData32));

           

        

        

        /*config expect*/

        rltCompValid = 1;

        offset = qdrBistExpRam+entry*16;

        value = rltCompValid<<30;        

        asic_reg_write(chip_id, offset, (uint32)(value));

        asic_reg_write(chip_id, offset + 4 , 0);

        asic_reg_write(chip_id, offset + 8 , 0);

        asic_reg_write(chip_id, offset + 12 , 0);

           

    }

    

    for(entry=PBQDR_ENTRY+1; entry<PBQDR_ENTRY*2+2; entry++)

    {

        if(entry < PBQDR_ENTRY*2+1)

        {

            ramReadAddress = 1<<(entry-PBQDR_ENTRY-1);

            value = 0xffffffff-(1<<(entry-PBQDR_ENTRY-1));

            ramData8 = value & 0xf;

            ramData32 = value;

        }

        else

        {

            ramReadAddress = addr[entry-PBQDR_ENTRY*2-1];

            ramData8 = data[entry-PBQDR_ENTRY*2-1]&0xf;

            ramData32 = data[entry-PBQDR_ENTRY*2-1];

        }

        /*config request*/

        ramAccessValid = 1;

        ramAccessRead = 1;

        offset = qdrBistReqRam+entry*16;

        value = (ramAccessValid<<30)+(ramAccessRead<<29)+(ramReadAddress<<8);

        asic_reg_write(chip_id, offset, (uint32)(value));

        asic_reg_write(chip_id, offset + 4 , 0);

        asic_reg_write(chip_id, offset + 8 , 0);

        asic_reg_write(chip_id, offset + 12 , 0);

                              

        /*config expect*/

        rltCompValid = 1;

        readDataValid = 1;

        offset = qdrBistExpRam+entry*16; 

        value = (rltCompValid<<30)+(readDataValid<<29)+(ramData8);

        asic_reg_write(chip_id, offset, (uint32)(value));

        asic_reg_write(chip_id, offset + 4 , (uint32)(ramData32));

        asic_reg_write(chip_id, offset + 8 , (uint32)(ramData8));

        asic_reg_write(chip_id, offset + 12 , (uint32)(ramData32));

        

    }

 

    /*enable bist*/

    bistEn = 1;

    stopOnError = 1;

    bistEntry = PBQDR_ENTRY*2+1*2-1;

    value = (bistEn<<13)+(6<<8)+(stopOnError<<7)+bistEntry;

 

    asic_reg_write(chip_id, qdrBistCtrl, (uint32)(value));

 

} 

void 
diagnostic_run_ext_tcam_bist(uint32 chip_id)
{

    int32  data_length = 0,mask_length = 0;

    uint8  skey[256],smask[256], key_size = 0, is_ext_tcam =1;

    uint32 entries, enumber = 0, real_key[32],real_mask[32], eindex[2], key_cmd;

    uint32 bist_ctl_enum, bist_request_ram_enum, bist_expect_ram_enum,bist_result_ram_enum;

    uint32 bist_access,bist_write_data,bist_write_mask;

    uint32 tcam_expect_laytency;

    tcam_bist_control_union_t bist_c_control;

    tcam_bist_req_ram_union_t bist_c_request;

    tcam_bist_result_ram_union_t bist_c_result;
    uint32 i,line;    
    uint32 tcamSetup;

    /*clear all the reg and ram of tcam bist*/
    sal_memset(&bist_c_control, 0, sizeof(tcam_bist_control_union_t));
    sal_memset (&bist_c_request, 0, sizeof(tcam_bist_req_ram_union_t));
    sal_memset (&bist_c_result, 0, sizeof(tcam_bist_result_ram_union_t));


    bist_ctl_enum = EXT_TCAM_BISTCTRL_ADDR;
    bist_request_ram_enum = EXT_TCAM_BISTREQRAM_ADDR;
    bist_expect_ram_enum = EXT_TCAM_BISTEXPRAM_ADDR;
    bist_result_ram_enum = EXT_TCAM_BISTRLTRAM_ADDR;

    bist_access = EXT_TCAM_ACCESS_ADDR;
    bist_write_data = EXT_TCAM_WRITEDATA_ADDR;
    bist_write_mask = EXT_TCAM_WRITEMASK_ADDR;

 

    tcamSetup = EXT_TCAM_CTRL_SETUP;
    asic_reg_write(chip_id, tcamSetup, 0x11000431); 
    asic_reg_write(chip_id, tcamSetup + 4, 0x8d000000);

    /*init external TCAM controller*/
    {

        //1. the BSR0 of LTR0 should be 0xffff

        //write bay 0 tcam reg 0x200 0xffff

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);
        asic_reg_write(chip_id, bist_write_data + 8, 0xffff);

        asic_reg_write(chip_id, bist_access, 0x84000200);

        //2. the PSR0 of LTR0 should be 0x5
        //write bay 0 tcam reg 0x202 0x5
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x5);
        
        asic_reg_write(chip_id, bist_access, 0x84000202); 

        //3. the KCR 80 bit 0x3
        //write bay 0 tcam reg 0x206 0x3
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);   
        asic_reg_write(chip_id, bist_write_data + 8, 0x3);

        asic_reg_write(chip_id, bist_access, 0x84000206); 

        //1. the BSR0 of LTR1 should be 0xffff(block4 enable)
        //write bay 0 tcam reg 0x210 0xffff
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0xffff);

        asic_reg_write(chip_id, bist_access, 0x84000210); 

        //2. the PSR0 of LTR1 (block 4 port1)
        //write bay 0 tcam reg 0x212 0x100
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x100);
        asic_reg_write(chip_id, bist_access, 0x84000212); 

        //3. the KCR 160 bit 0xf
        //write bay 0 tcam reg 0x216 0xf
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);
        asic_reg_write(chip_id, bist_write_data + 8, 0xf);

        asic_reg_write(chip_id, bist_access, 0x84000216); 

        //#4. the BCR4(emulation don't write BCR and BMR)
        //#write bay 0 tcam reg 0x404 0x3
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x3);
        asic_reg_write(chip_id, bist_access, 0x84000404); 

        //#5. the BCR0
        //#write bay 0 tcam reg 0x400 0x1
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x1);

        asic_reg_write(chip_id, bist_access, 0x84000400); 

        //#6. the block 4 BMR
        //#write bay 0 tcam reg 0x840 0x0
        //#write bay 0 tcam reg 0x841 0x0
        //#write bay 0 tcam reg 0x842 0x0
        //#write bay 0 tcam reg 0x843 0x0
        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);
        
        asic_reg_write(chip_id, bist_access, 0x84000840); 


        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);
        
        asic_reg_write(chip_id, bist_access, 0x84000841); 

 

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);

        asic_reg_write(chip_id, bist_access, 0x84000842); 

 

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);
        
        asic_reg_write(chip_id, bist_access, 0x84000843); 

 
        //#7. the block 0 BMR
        //#write bay 0 tcam reg 0x800 0x0
        //#write bay 0 tcam reg 0x801 0x0
        //#write bay 0 tcam reg 0x802 0x0
        //#write bay 0 tcam reg 0x803 0x0

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);
        asic_reg_write(chip_id, bist_access, 0x84000800); 

 

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);

        asic_reg_write(chip_id, bist_access, 0x84000801); 

 

        

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);

        asic_reg_write(chip_id, bist_access, 0x84000802); 

 

        asic_reg_write(chip_id, bist_write_data, 0);
        asic_reg_write(chip_id, bist_write_data + 4, 0);  
        asic_reg_write(chip_id, bist_write_data + 8, 0x0);
        
        asic_reg_write(chip_id, bist_access, 0x84000803); 
     
    }

    

    tcam_expect_laytency = 0x25;

    

    bist_c_control.bistControl.expectLatency = tcam_expect_laytency;

    
     for (entries = 0; entries < 64 ; entries++)
     {

           for(i = 0;i < 8;i++)
           {

                asic_reg_write(chip_id, bist_request_ram_enum+entries*32+i*4, (uint32)(bist_c_request.result_ram[i]));

           }

    

           for(i = 0;i < 2;i++)
           {
                asic_reg_write(chip_id, bist_expect_ram_enum+entries*8+i*4, (uint32)(bist_c_request.result_ram[i]));
           }            



           for(i = 0;i < 2;i++)
           {
                asic_reg_write(chip_id, bist_result_ram_enum+entries*8+i*4, (uint32)(bist_c_request.result_ram[i]));
           }

     }

 

    /*save tcam entry 0 data and mask*/

    diag_ext_tcam_read(chip_id, tcam_data, tcam_mask, 0, 0);       

    entries = 0;//start form entries 0

    for(line = 0; line <sizeof(EXT_TCAM_MASK)/sizeof(EXT_TCAM_MASK[0]); line++)       

    {

        uint8 offset = 0;        

 

        sal_memset(skey, 0, sizeof(skey));

        sal_memset(smask, 0, sizeof(smask));

        sal_sscanf(EXT_TCAM_KEY[line], "%s %x %x %x", skey, &key_cmd, &eindex[0], &eindex[1]);

        sal_sscanf(EXT_TCAM_MASK[line], "%s", smask);

        

 

        sal_memset(real_key, 0, 128);

        sal_memset(real_mask, 0, 128);

        stringtochar((char*)skey, (uint8 *)real_key, &data_length);

        stringtochar((char*)smask, (uint8 *)real_mask, &mask_length);

        

        swap_32(real_key, data_length/4, HOST_2_NETWORK);

        swap_32(real_mask, mask_length/4, HOST_2_NETWORK);

        

        switch (data_length)
        {

            case 128:

                enumber = 4;

                key_size = 3;

                break;

 

            case 64:

                enumber = 2;

                key_size = 2;

                break;

 

            case 32:

                enumber = 1;

                key_size = 1;

                break;

 

            case 16:

                enumber = 1;

                key_size = 0;

                if (!is_ext_tcam)

                {

                    sal_memcpy(&real_key[4], &real_key[0], 16);

                    sal_memset(&real_key[0], 0, 16);

                }

                break;

 

            default:

                sal_printf("\nLength <%d> error or string_to_char return error!\n",data_length);

                return;

        }

 

        /* write data and mask to TCAM */
        if(key_size == 0)
        {

            //write data to tcam           
            asic_reg_write(chip_id, bist_write_data, (uint32)(real_key[1]) & 0xFFFF);            
            asic_reg_write(chip_id, bist_write_data + 4, (uint32)(real_key[2]));           
            asic_reg_write(chip_id, bist_write_data + 8, (uint32)(real_key[3]));

            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 

             //write mask tcam
            asic_reg_write(chip_id, bist_write_mask, (uint32)(real_mask[1]) & 0xFFFF);            
            asic_reg_write(chip_id, bist_write_mask + 4, (uint32)(real_mask[2]));           
            asic_reg_write(chip_id, bist_write_mask + 8, (uint32)(real_mask[3]));
            
            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 
                  

        }
        else if(key_size == 1)
        {
            //write data to tcam
            asic_reg_write(chip_id, bist_write_data, (uint32)(real_key[1]) & 0xFFFF);            
            asic_reg_write(chip_id, bist_write_data + 4, (uint32)(real_key[2]));           
            asic_reg_write(chip_id, bist_write_data + 8, (uint32)(real_key[3]));
            
            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 

             //write mask tcam
            asic_reg_write(chip_id, bist_write_mask, (uint32)(real_mask[1]) & 0xFFFF);            
            asic_reg_write(chip_id, bist_write_mask + 4, (uint32)(real_mask[2]));           
            asic_reg_write(chip_id, bist_write_mask + 8, (uint32)(real_mask[3]));
            
            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 

            //write data to tcam
            asic_reg_write(chip_id, bist_write_data, (uint32)(real_key[5]) & 0xFFFF);            
            asic_reg_write(chip_id, bist_write_data + 4, (uint32)(real_key[6]));           
            asic_reg_write(chip_id, bist_write_data + 8, (uint32)(real_key[7]));
            
            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1] + 1)); 

             //write mask tcam
            asic_reg_write(chip_id, bist_write_mask, (uint32)(real_mask[5]) & 0xFFFF);            
            asic_reg_write(chip_id, bist_write_mask + 4, (uint32)(real_mask[6]));           
            asic_reg_write(chip_id, bist_write_mask + 8, (uint32)(real_mask[7]));

            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1] + 1)); 

        }
        

        for (offset = 0 ; offset < enumber; offset++)
        {

            /* write request ram */

            sal_memset(&bist_c_request, 0, sizeof(tcam_bist_req_ram_union_t));

            

            bist_c_request.bistRequest.key31To0 = real_key[offset * 8 + 3];

            bist_c_request.bistRequest.key63To32 = real_key[offset * 8 + 2];

            bist_c_request.bistRequest.key79To64 = real_key[offset * 8 + 1] & 0xFFFF;

 

            bist_c_request.bistRequest.key111To80 = real_key[offset * 8 + 7];

            bist_c_request.bistRequest.key143To112 = real_key[offset * 8 + 6];

            bist_c_request.bistRequest.key159To144 = real_key[offset * 8 + 5] & 0xFFFF;

            

            

            bist_c_request.bistRequest.key_valid = TRUE;

            bist_c_request.bistRequest.keyCmd = key_cmd;  /* for ext tcam, it is the LTR register number */

            bist_c_request.bistRequest.keySize = key_size;

 

            if (entries < 64)
            {

                for(i = 0;i < 8;i++)

                    {

                    asic_reg_write(chip_id, bist_request_ram_enum+entries*32+i*4, (uint32)(bist_c_request.result_ram[i]));

                    }

            }

 

            /* write expect RAM */

            sal_memset (&bist_c_result, 0, sizeof(tcam_bist_result_ram_union_t));

            bist_c_result.bistResult.resultCompareValid= 1; /* result compare valid */

            if (offset == (enumber - 1))

            {

                bist_c_result.bistResult.indexValid = TRUE;

            }

            else

            {

                /* if the lookup keysize is 320 bits, only the second EXCEPT ram's index valid should be set! */

                bist_c_result.bistResult.indexValid = FALSE;

            }

 

           

            if(bist_c_result.bistResult.indexValid)

            {

                bist_c_result.bistResult.indexAclCompEn= FALSE;

                bist_c_result.bistResult.indexQosCompEn= TRUE;

                bist_c_result.bistResult.indexAcl= 0;

                bist_c_result.bistResult.indexQos= eindex[1];

            }

            else

            {

                bist_c_result.bistResult.indexAclCompEn= FALSE;

                bist_c_result.bistResult.indexQosCompEn= FALSE;

                bist_c_result.bistResult.indexAcl= 0;

                bist_c_result.bistResult.indexQos= 0;

            }

 

            if (entries < 64)
            {                

                for(i = 0;i < 2;i++)

                    {

                    asic_reg_write(chip_id, bist_expect_ram_enum+entries*8+i*4, (uint32)(bist_c_result.result_ram[i]));

                    }

            }

 

            entries++;

        }

    }

 

    /* write bist control */

    bist_c_control.bistControl.cfgBistEn= TRUE;

    bist_c_control.bistControl.cfgBistOnce= 0;

    bist_c_control.bistControl.cfgBistEntries= (entries >64) ? 63 : (entries -1) ;

    bist_c_control.bistControl.cfgStopOnError = 1;

    bist_c_control.bistControl.expectLatency = tcam_expect_laytency & 0x7F;    

 
    asic_reg_write(chip_id, bist_ctl_enum+4, (uint32)(bist_c_control.bist_control[1]));

    asic_reg_write(chip_id, bist_ctl_enum, (uint32)(bist_c_control.bist_control[0]));

    

}

 

void 

diagnostic_run_int_tcam_bist(uint32 chip_id)

{        
    int32  data_length = 0,mask_length = 0;

    uint8  skey[256],smask[256], key_size = 0, is_ext_tcam =0;

    uint32 entries, enumber = 0, real_key[32],real_mask[32], eindex[2], key_cmd;

    uint32 bist_ctl_enum, bist_request_ram_enum, bist_expect_ram_enum,bist_result_ram_enum;

    uint32 bist_access,bist_write_data,bist_write_mask;

    uint32 tcam_expect_laytency;

    tcam_bist_control_union_t bist_c_control;

    tcam_bist_req_ram_union_t bist_c_request;

    tcam_bist_result_ram_union_t bist_c_result;

    uint32 i,line;

    uint32 key_size_cfg,key_type_cfg;


    /*clear all the reg and ram of tcam bist*/

    sal_memset(&bist_c_control, 0, sizeof(tcam_bist_control_union_t));

    sal_memset (&bist_c_request, 0, sizeof(tcam_bist_req_ram_union_t));

    sal_memset (&bist_c_result, 0, sizeof(tcam_bist_result_ram_union_t));
    

    bist_ctl_enum = INT_TCAM_BISTCTRL_ADDR;

    bist_request_ram_enum = INT_TCAM_BISTREQRAM_ADDR;

    bist_expect_ram_enum = INT_TCAM_BISTEXPRAM_ADDR;

    bist_result_ram_enum = INT_TCAM_BISTRLTRAM_ADDR;

    

    bist_access = INT_TCAM_ACCESS_ADDR;

    bist_write_data = INT_TCAM_WRITEDATA_ADDR;

    bist_write_mask = INT_TCAM_WRITEMASK_ADDR;

 

    /*init internal TCAM controller*/

    tcam_expect_laytency = 0x0;

 

    

    bist_c_control.bistControl.expectLatency = tcam_expect_laytency;

    asic_reg_write(chip_id, bist_ctl_enum, (uint32)(bist_c_control.bist_control[0]));

    asic_reg_write(chip_id, bist_ctl_enum+4, (uint32)(bist_c_control.bist_control[1]));
 

    {

        key_size_cfg = INT_TCAM_KEYSIZECFG_ADDR;

        key_type_cfg = INT_TCAM_KEYTYPECFG_ADDR;

        asic_reg_write(chip_id, key_size_cfg, 0xffffffff);

        asic_reg_write(chip_id, key_size_cfg + 4, 0xffffffff);

        asic_reg_write(chip_id, key_size_cfg + 8, 0xffffffff);

 

        asic_reg_write(chip_id, key_type_cfg, 0xffffffff);

    }

 

         for (entries = 0; entries < 64 ; entries++)

         {

                   for(i = 0;i < 8;i++)

                   {

            asic_reg_write(chip_id, bist_request_ram_enum+entries*32+i*4, (uint32)(bist_c_request.result_ram[i]));

                   }

        

                   for(i = 0;i < 2;i++)

                   {

            asic_reg_write(chip_id, bist_expect_ram_enum+entries*8+i*4, (uint32)(bist_c_request.result_ram[i]));

                   }            

 

                   for(i = 0;i < 2;i++)

                   {

            asic_reg_write(chip_id, bist_result_ram_enum+entries*8+i*4, (uint32)(bist_c_request.result_ram[i]));

                   }

 

         }

 

    /*save tcam entry 0 data and mask*/

    diag_int_tcam_read(chip_id, tcam_data, tcam_mask, 0, 0);
   
    entries = 0;//start form entries 0

    for(line = 0; line <sizeof(INT_TCAM_MASK)/sizeof(INT_TCAM_MASK[0]); line++)       

    {

        uint8 offset = 0;       

 

        sal_memset(skey, 0, sizeof(skey));

        sal_memset(smask, 0, sizeof(smask));

        sal_sscanf(INT_TCAM_KEY[line], "%s %x %x %x", skey, &key_cmd, &eindex[0], &eindex[1]);

        sal_sscanf(INT_TCAM_MASK[line], "%s", smask);

        sal_memset(real_key, 0, 128);

        sal_memset(real_mask, 0, 128);

        stringtochar((char*)skey, (uint8 *)real_key, &data_length);

        stringtochar((char*)smask, (uint8 *)real_mask, &mask_length);

        

        swap_32(real_key, data_length/4, HOST_2_NETWORK);

        swap_32(real_mask, mask_length/4, HOST_2_NETWORK);

        switch (data_length)

        {

            case 128:

                enumber = 4;

                key_size = 3;

                break;

 

            case 64:

                enumber = 2;

                key_size = 2;

                break;

 

            case 32:

                enumber = 1;

                key_size = 1;

                break;

 

            case 16:

                enumber = 1;

                key_size = 0;

                if (!is_ext_tcam)

                {

                    sal_memcpy(&real_key[4], &real_key[0], 16);

                    sal_memset(&real_key[0], 0, 16);

 

                    sal_memcpy(&real_mask[4], &real_mask[0], 16);

                    sal_memset(&real_mask[0], 0, 16);

                }

                break;

 

            default:

                sal_printf("\nLength <%d> error or string_to_char return error!\n",data_length);

                return;

        }


        /* write data and mask to TCAM */

        if(key_size == 0)

        {           

             //write mask tcam

            asic_reg_write(chip_id, bist_write_mask, (uint32)(real_mask[5]) & 0xFFFF);            

            asic_reg_write(chip_id, bist_write_mask + 4, (uint32)(real_mask[6]));           

            asic_reg_write(chip_id, bist_write_mask + 8, (uint32)(real_mask[7]));

            

            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 

 

            //write data to tcam

            asic_reg_write(chip_id, bist_write_data, (uint32)(real_key[5]) & 0xFFFF);            

            asic_reg_write(chip_id, bist_write_data + 4, (uint32)(real_key[6]));           

            asic_reg_write(chip_id, bist_write_data + 8, (uint32)(real_key[7]));

            

            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 

        }

        else if(key_size == 1)

        {

            //write data to tcam

            asic_reg_write(chip_id, bist_write_data, (uint32)(real_key[5]) & 0xFFFF);            

            asic_reg_write(chip_id, bist_write_data + 4, (uint32)(real_key[6]));           

            asic_reg_write(chip_id, bist_write_data + 8, (uint32)(real_key[7]));

            

             //write mask tcam

            asic_reg_write(chip_id, bist_write_mask, (uint32)(real_mask[5]) & 0xFFFF);            

            asic_reg_write(chip_id, bist_write_mask + 4, (uint32)(real_mask[6]));           

            asic_reg_write(chip_id, bist_write_mask + 8, (uint32)(real_mask[7]));

            

            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1])); 

 

            //write data to tcam

            asic_reg_write(chip_id, bist_write_data, (uint32)(real_key[1]) & 0xFFFF);            

            asic_reg_write(chip_id, bist_write_data + 4, (uint32)(real_key[2]));           

            asic_reg_write(chip_id, bist_write_data + 8, (uint32)(real_key[3]));

            

 

             //write mask tcam

            asic_reg_write(chip_id, bist_write_mask, (uint32)(real_mask[1]) & 0xFFFF);            

            asic_reg_write(chip_id, bist_write_mask + 4, (uint32)(real_mask[2]));           

            asic_reg_write(chip_id, bist_write_mask + 8, (uint32)(real_mask[3]));

            

            asic_reg_write(chip_id, bist_access, (0x85000000 + eindex[1] + 1)); 

        }


        for (offset = 0 ; offset < enumber; offset++)

        {

            /* write request ram */

            sal_memset (&bist_c_request, 0, sizeof(tcam_bist_req_ram_union_t));

            

            bist_c_request.bistRequest.key31To0 = real_key[offset * 8 + 7];

            bist_c_request.bistRequest.key63To32 = real_key[offset * 8 + 6];

            bist_c_request.bistRequest.key79To64 = real_key[offset * 8 + 5] & 0xFFFF;

 

            bist_c_request.bistRequest.key111To80 = real_key[offset * 8 + 3];

            bist_c_request.bistRequest.key143To112 = real_key[offset * 8 + 2];

            bist_c_request.bistRequest.key159To144 = real_key[offset * 8 + 1] & 0xFFFF;

            

            

            bist_c_request.bistRequest.key_valid = TRUE;

            bist_c_request.bistRequest.keyCmd = key_cmd;  /* for ext tcam, it is the LTR register number */

            bist_c_request.bistRequest.keySize = key_size;

 

            if (entries < 64)

            {                

                for(i = 0;i < 8;i++)

                    {

                    asic_reg_write(chip_id,bist_request_ram_enum+entries*32+i*4, (uint32)(bist_c_request.result_ram[i]
));

                    }

            }

 

            /* write expect RAM */

            sal_memset (&bist_c_result, 0, sizeof(tcam_bist_result_ram_union_t));

            bist_c_result.bistResult.resultCompareValid= 1; /* result compare valid */

            if (offset == (enumber - 1))

            {

                bist_c_result.bistResult.indexValid = TRUE;

            }

            else

            {

                /* if the lookup keysize is 320 bits, only the second EXCEPT ram's index valid should be set! */

                bist_c_result.bistResult.indexValid = FALSE;

            }

 

            if( (1 == (key_cmd & 0x1)) && bist_c_result.bistResult.indexValid)

            {

                bist_c_result.bistResult.indexAclCompEn= TRUE;

                bist_c_result.bistResult.indexQosCompEn= TRUE;

                bist_c_result.bistResult.indexAcl= eindex[0];

                bist_c_result.bistResult.indexQos= eindex[1];

            }

            else if(bist_c_result.bistResult.indexValid)

            {

                bist_c_result.bistResult.indexAclCompEn= FALSE;

                bist_c_result.bistResult.indexQosCompEn= TRUE;

                bist_c_result.bistResult.indexAcl= 0;

                bist_c_result.bistResult.indexQos= eindex[1];

            }

            else

            {

                bist_c_result.bistResult.indexAclCompEn= FALSE;

                bist_c_result.bistResult.indexQosCompEn= FALSE;

                bist_c_result.bistResult.indexAcl= 0;

                bist_c_result.bistResult.indexQos= 0;

            }

 

            if (entries < 64)

            {                

                for(i = 0;i < 2;i++)

                    {

                    asic_reg_write(chip_id, bist_expect_ram_enum+entries*8+i*4, (uint32)(bist_c_result.result_ram[i]));

                    }

            }

 

            entries++;

        }

    }

 

    /* write bist control */

    bist_c_control.bistControl.cfgBistEn= TRUE;

    bist_c_control.bistControl.cfgBistOnce= 0;

    bist_c_control.bistControl.cfgBistEntries= (entries >64) ? 63 : (entries -1) ;

    bist_c_control.bistControl.cfgStopOnError = 1;

    bist_c_control.bistControl.expectLatency = tcam_expect_laytency & 0x7F;

 

    asic_reg_write(chip_id, bist_ctl_enum, (uint32)(bist_c_control.bist_control[0]));

    asic_reg_write(chip_id, bist_ctl_enum+4, (uint32)(bist_c_control.bist_control[1])); 

  

}
 

int32 diagnostic_check_ddr_bist_rlt(uint32 chip_id)

{

    uint32 ddrBistCtrl,ddrControl, value,mismatchCount;//, offset, i, entry;

    int32 ret;

    uint32 i,startAddr;

    

    ddrBistCtrl = DDR_BISTCTRL_ADDR;

    ddrControl = DDR_CONTROL_ADDR;   
  

    ret = asic_reg_read(chip_id, ddrBistCtrl, (uint32 *)&(value));

    if(ret < 0)

    {

        return -1;

    }

    mismatchCount = value & 0xffff0000;

 

    ret = asic_reg_write(chip_id, ddrBistCtrl, 0);

 

    //recover the ddrcontrol default value

    asic_reg_write(chip_id, ddrControl, 0x20005511);//jcao default value 0x20005511

    if(mismatchCount != 0)

    {

        return -1;

    }

    
    /*recover sram entry 0 data */
    
    startAddr = DDR_SRAM_BASE;

    for(i=0; i<4; i++)

    {
        
      asic_reg_write(chip_id,  startAddr+4*i, sram_data[i]);          
    } 

    return 0;  

}

 

int32 diagnostic_check_qdr_bist_rlt(uint32 chip_id)
{
    uint32 qdrBistCtrl,qdrControl, value,mismatchCount;//, offset, i, entry;
    int32 ret;
    uint32 i,startAddr;
    qdrBistCtrl = QDR_BISTCTRL_ADDR;
    qdrControl = QDR_CONTROL_ADDR;
    
    ret = asic_reg_read(chip_id, qdrBistCtrl, (uint32 *)&(value));
    if(ret < 0)
    {
        return -1;
    }
    mismatchCount = value & 0xffff0000;
    ret = asic_reg_write(chip_id, qdrBistCtrl, 0x0000063f);
    //recover the ddrcontrol default value

    //ctckal_usrctrl_write_bay(humber_id, fpga_id, qdrControl, 0x20000511);//jcao default value 0x20000511

    if(mismatchCount != 0)
    {
        return -1;
    }
    /*recover sram entry 0 data */
    startAddr = QDR_SRAM_BASE;
    for(i=0; i<4; i++)
    {
       asic_reg_write(chip_id, startAddr+4*i, sram_data[i]);    
    } 

    return 0;

}

 

int32 diagnostic_check_ext_tcam_bist_rlt(uint32 chip_id)
{
    uint32 tcamBistCtrl,mismatchCount;//, offset, i, entry;
    int32 ret;   
    tcam_bist_control_union_t bist_c_control;
    tcamBistCtrl = EXT_TCAM_BISTCTRL_ADDR;
    
    ret = asic_reg_read(chip_id, tcamBistCtrl, (uint32 *)&(bist_c_control.bist_control[0]));
    ret = asic_reg_read(chip_id, tcamBistCtrl + 4, (uint32 *)&(bist_c_control.bist_control[1]));

    if(ret < 0)
    {
    return -1;
    }

    mismatchCount = (bist_c_control.bist_control[0]) & 0xffff0000;
    bist_c_control.bistControl.cfgBistEn= 0; 
    
    asic_reg_write(chip_id, tcamBistCtrl, (uint32)(bist_c_control.bist_control[0]));
    asic_reg_write(chip_id, tcamBistCtrl+4, (uint32)(bist_c_control.bist_control[1]));

    if(mismatchCount != 0)
    {
    return -1;
    }

    /*recover tcam entry 0 data and mask*/
    diag_ext_tcam_write(chip_id, tcam_data, tcam_mask, 0, 0);
    return 0;  
}

 

int32 diagnostic_check_int_tcam_bist_rlt(uint32 chip_id)
{    
    uint32 tcamBistCtrl,mismatchCount;//, offset, i, entry;
    int32 ret; 
    tcam_bist_control_union_t bist_c_control;  
    tcamBistCtrl = INT_TCAM_BISTCTRL_ADDR;  

    ret = asic_reg_read(chip_id, tcamBistCtrl, (uint32 *)&(bist_c_control.bist_control[0]));
    ret = asic_reg_read(chip_id, tcamBistCtrl + 4, (uint32 *)&(bist_c_control.bist_control[1]));

    if(ret < 0)
    {
        return -1;
    }

    mismatchCount = (bist_c_control.bist_control[0]) & 0xffff0000;
    bist_c_control.bistControl.cfgBistEn= 0;   

    asic_reg_write(chip_id, tcamBistCtrl, (uint32)(bist_c_control.bist_control[0]));
    asic_reg_write(chip_id, tcamBistCtrl+4, (uint32)(bist_c_control.bist_control[1]));
    
    if(mismatchCount != 0)
    {
        return -1;
    }

     /*recover tcam entry 0 data and mask*/
    diag_int_tcam_write(chip_id, tcam_data, tcam_mask, 0, 0);
       return 0;  

}


void 
diag_bist_run_ddr_sram(uint8 chip_id)
{
    diagnostic_run_ddr_bist(chip_id);   
    return ;
}

void 
diag_bist_run_qdr_sram(uint8 chip_id)
{
    diagnostic_run_qdr_bist(chip_id);    
    return ;
}

int32
diag_check_ddr_sram_bist_rlt(uint8 chip_id)
{
    int32 ret, result=0;

    ret = diagnostic_check_ddr_bist_rlt(chip_id);
    if (ret < 0)
    {
        result = result | (1<<0);
    }
    return result;
}

int32
diag_check_qdr_sram_bist_rlt(uint8 chip_id)
{
    int32 ret, result=0;

    ret = diagnostic_check_qdr_bist_rlt(chip_id);
    if (ret < 0)
    {
        result = result | (1<<1);
    }
   
    return result;
}

void 
diag_bist_run_int_tcam(uint8 chip_id)
{
    diagnostic_run_int_tcam_bist(chip_id);
    return ;
}

void 
diag_bist_run_ext_tcam(uint8 chip_id)
{
    diagnostic_run_ext_tcam_bist(chip_id);
    return ;
}

int32 
diag_check_int_tcam_bist_rlt(uint8 chip_id)
{
    int32 ret, result=0;

    ret = diagnostic_check_int_tcam_bist_rlt(chip_id);
    if (ret < 0)
    {
        result = result | (1<<1);
    }
   
    return result;
}

int32 
diag_check_ext_tcam_bist_rlt(uint8 chip_id)
{
    int32 ret, result=0;

    ret = diagnostic_check_ext_tcam_bist_rlt(chip_id);
    if (ret < 0)
    {
        result = result | (1<<0);
    }
   
    return result;
}
#endif


