#ifdef BOOTUP_DIAG
#include "glb_hw_define.h"
#include "diag_types.h"
#include "diag_item_prepare_cb.h"
#include "diag_item_run_cb.h"
#include "diag_item_report_cb.h"
#include "diag_item_finish_cb.h"
#include "lcm.h"
#include "lcm_diag.h"
#include "lcm_mgt.h"

#include "diag_pkt_drv.h"
#include "diag_chip.h"
#include "phy_api.h"
#include "ctc_i2c.h"
#include "i2c_cpm.h"
#include "l2switch_api.h"
#include "epld_api.h"
#include "eeprom_api.h"
#include "fan_api.h"
#include "sensor_api.h"
#include "power_api.h"
#include "gpio_api.h"
#include "mux_api.h"
#include "diag_device_item.h"


int32
diag_item_report_phy_test(diag_operator_t *p_oper)
{
    int32 ret;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "PHY diag fail\n");	
    LCM_DIAG_CONSOLE_PRINT("PHY diag fail\n");	
    sal_fprintf(p_oper->log_fp, "PHY diag fail\n");
#endif    
    return ret;
}

int32
diag_item_report_sdk_init_test(diag_operator_t *p_oper)
{
    int32 ret;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "SDK diag fail\n");	
    LCM_DIAG_CONSOLE_PRINT("SDK diag fail\n");	
    sal_fprintf(p_oper->log_fp, "SDK diag fail\n");
#endif    
    return ret;
}


int32
diag_item_report_l2switch_test(diag_operator_t *p_oper)
{
    int32 ret;
#ifndef _GLB_UML_SYSTEM_    
    int32 result = 0;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    /*result: bit[30:30] 0-pass,1-fail; bit[29:28] chip id; bit[27:0] error port; */
    result = p_item->rslt->chip_result[0];
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "Access l2switch %d fail!\n", (result>>28)&0x3);		
    LCM_DIAG_CONSOLE_PRINT("Access l2switch %d fail!\n", (result>>28)&0x3);	
    sal_fprintf(p_oper->log_fp, "Access l2switch %d fail!\n", (result>>28)&0x3);
    if(result & 0x0fffffff)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "Access l2switch port fail! bit map 0x%x\n", (result & 0x0fffffff));
        LCM_DIAG_CONSOLE_PRINT("Access l2switch port fail! bit map 0x%x\n", (result & 0x0fffffff));		
        sal_fprintf(p_oper->log_fp, "Access l2switch port fail! bit map 0x%x\n", (result & 0x0fffffff));		
    }

#endif    
    return ret;
}

int32
diag_item_report_eeprom0_test(diag_operator_t *p_oper)
{
    int32 ret;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM0 diag fail!\n");	
    LCM_DIAG_CONSOLE_PRINT("EEPROM0 diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "EEPROM0 diag fail!\n");
#endif    
    return ret;
}

/* Added by liuht to test rtc for bug24982, 2013-12-21 */
int32
diag_item_report_rtc_test(diag_operator_t *p_oper)
{
    int32 ret;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "RTC diag fail!\n");    	
    LCM_DIAG_CONSOLE_PRINT("RTC diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "RTC diag fail!\n");
#endif    
    return ret;
}

int32
diag_item_report_eeprom1_test(diag_operator_t *p_oper)
{
    int32 ret;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM1 diag fail!\n");    	
    LCM_DIAG_CONSOLE_PRINT("EEPROM1 diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "EEPROM1 diag fail!\n");
#endif    
    return ret;
}


int32
diag_item_report_epld_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_ 
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EPLD diag fail!\n");    	
    LCM_DIAG_CONSOLE_PRINT("EPLD diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "EPLD diag fail!\n");
#endif    
    return ret;
}

int32
diag_item_report_fan_test(diag_operator_t *p_oper)
{
    int32 ret;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "FAN diag fail!\n");
    LCM_DIAG_CONSOLE_PRINT("FAN diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "FAN diag fail!\n");
    return ret;
}

int32
diag_item_report_sensor_test(diag_operator_t *p_oper)
{
    int32 ret;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "SENSOR diag fail!\n");
    LCM_DIAG_CONSOLE_PRINT("SENSOR diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "SENSOR diag fail!\n");
    return ret;
}

int32
diag_item_report_psu_test(diag_operator_t *p_oper)
{
    int32 ret;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "POWER diag fail!\n");	
    LCM_DIAG_CONSOLE_PRINT("POWER diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "POWER diag fail!\n");
    return ret;
}

int32
diag_item_report_gpio_test(diag_operator_t *p_oper)
{
    int32 ret;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "GPIO diag fail!\n");	
    LCM_DIAG_CONSOLE_PRINT("GPIO diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "GPIO diag fail!\n");
    return ret;
}

int32
diag_item_report_mux_test(diag_operator_t *p_oper)
{
    int32 ret;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    ret = diag_item_report_common(p_oper);
    if(ret == DIAG_PASS)
    {
        return ret;
    }
    
    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "MUX diag fail!\n");	
    LCM_DIAG_CONSOLE_PRINT("MUX diag fail!\n");	
    sal_fprintf(p_oper->log_fp, "MUX diag fail!\n");
    return ret;
}

int32
diag_item_run_phy_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    int32 result=0;
    phy_diag_result_t diag_result;
    
    diag_item_run_common(p_oper);

    sal_memset(&diag_result, 0, sizeof(phy_diag_result_t));
    result = phy_diagnostic_test(&diag_result);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }

    if(diag_result.access_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "PHY diag access fail!\n");	
        LCM_DIAG_CONSOLE_PRINT("PHY diag access fail!\n");	
        sal_fprintf(p_oper->log_fp, "PHY diag access fail!\n");
    }
    else if(diag_result.down)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "PHY diag port %d link down\n", diag_result.port_id);
        LCM_DIAG_CONSOLE_PRINT("PHY diag port %d link down\n", diag_result.port_id);	
        sal_fprintf(p_oper->log_fp, "PHY diag port %d link down\n", diag_result.port_id);
    }
    
#endif
    return ret;
}

int32
diag_item_run_sdk_init_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_run_common(p_oper);
#endif
    return ret;
}

int32
diag_item_run_l2switch_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_   
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    uint32 result=0;
    diag_item_run_common(p_oper);
    result = l2switch_diagnostic_test();    
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
#endif
    return ret;
}


int32
diag_item_run_eeprom0_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    uint32 result=0;
    eeprom_diag_result_t diag_result;
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    diag_item_run_common(p_oper);
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM0 diag : card is NULL.\n"); 
        LCM_DIAG_CONSOLE_PRINT("EEPROM0 diag : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "EEPROM0 diag : card is NULL.\n");
        p_item->rslt->chip_result[0] = -1;
        return DIAG_FAIL;
    }    
 
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST]);
    if(NULL == p_eeprom_info)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM0 diag : eeprom info is NULL.\n"); 
        LCM_DIAG_CONSOLE_PRINT("EEPROM0 diag : eeprom info is NULL.\n");
        sal_fprintf(p_oper->log_fp, "EEPROM0 diag : eeprom info is NULL.\n");
        p_item->rslt->chip_result[0] = -1;
        return DIAG_FAIL;
    }

    sal_memset(&diag_result, 0, sizeof(eeprom_diag_result_t));
    result = eeprom_bootup_diag_test(p_eeprom_info, &diag_result); 
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
    if(diag_result.rd_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM0 diag read fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EEPROM0 diag read fail!\n");
        sal_fprintf(p_oper->log_fp, "EEPROM0 diag read fail!\n");
    }

    if(diag_result.wr_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM0 diag write fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EEPROM0 diag write fail!\n");
        sal_fprintf(p_oper->log_fp, "EEPROM0 diag write fail!\n");
    }

    if(diag_result.cmp_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM0 diag cmp fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EEPROM0 diag cmp fail!\n");
        sal_fprintf(p_oper->log_fp, "EEPROM0 diag cmp fail!\n");
    } 
#endif
    return ret;
}

/* Added by liuht to test rtc for bug24982, 2013-12-21 */
int32
diag_item_run_rtc_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    uint32 result=0;
    uint8 value_8 = 0;	
    glb_card_t *p_card = NULL;
    
    diag_item_run_common(p_oper);
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "RTC diag : card is NULL.\n"); 
        LCM_DIAG_CONSOLE_PRINT("RTC diag : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "RTC diag : card is NULL.\n");
        p_item->rslt->chip_result[0] = -1;
        return DIAG_FAIL;
    } 

    if((p_card->board_type.series == GLB_SERIES_E350) && (p_card->board_type.type == GLB_BOARD_E350_48T4XG))
    {
        result = raw_i2c_read(0, 0x68, 0, 1, &value_8, 1);
    }
    else
    {
        result = raw_i2c_read(0, 0x32, 0, 1, &value_8, 1);
    }
    if(result < 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
#endif
    return ret;
}

int32
diag_item_run_eeprom1_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_    
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    uint32 result=0;
    eeprom_diag_result_t diag_result;
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    diag_item_run_common(p_oper);
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM1 diag : card is NULL.\n"); 
        LCM_DIAG_CONSOLE_PRINT("EEPROM1 diag : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "EEPROM1 diag : card is NULL.\n");
        p_item->rslt->chip_result[0] = -1;
        return DIAG_FAIL;
    }    
 
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_1_MANU_TEST]);
    if(NULL == p_eeprom_info)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM1 diag : eeprom info is NULL.\n"); 
        LCM_DIAG_CONSOLE_PRINT("EEPROM1 diag : eeprom info is NULL.\n");
        sal_fprintf(p_oper->log_fp, "EEPROM1 diag : eeprom info is NULL.\n");
        p_item->rslt->chip_result[0] = -1;
        return DIAG_FAIL;
    }
    
    sal_memset(&diag_result, 0, sizeof(eeprom_diag_result_t));
    result = eeprom_bootup_diag_test(p_eeprom_info, &diag_result); 
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
    if(diag_result.rd_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM1 diag read fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EEPROM1 diag read fail!\n");
        sal_fprintf(p_oper->log_fp, "EEPROM1 diag read fail!\n");
    }

    if(diag_result.wr_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM1 diag write fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EEPROM1 diag write fail!\n");
        sal_fprintf(p_oper->log_fp, "EEPROM1 diag write fail!\n");
    }

    if(diag_result.cmp_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EEPROM1 diag cmp fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EEPROM1 diag cmp fail!\n");
        sal_fprintf(p_oper->log_fp, "EEPROM1 diag cmp fail!\n");
    } 
#endif
    return ret;
}

int32
diag_item_run_epld_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
#ifndef _GLB_UML_SYSTEM_   
    epld_diag_result_t diag_result;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    int32 result=0;

    diag_item_run_common(p_oper);

    sal_memset(&diag_result, 0, sizeof(epld_diag_result_t));
    result = epld_bootup_diag_test(EPLD_TEST, &diag_result);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;       
        ret = result;
    }

    if(diag_result.rd_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EPLD diag read fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EPLD diag read fail!\n");
        sal_fprintf(p_oper->log_fp, "EPLD diag read fail!\n");
    }

    if(diag_result.wr_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EPLD diag write fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EPLD diag write fail!\n");
        sal_fprintf(p_oper->log_fp, "EPLD diag write fail!\n");
    }

    if(diag_result.cmp_fail)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "EPLD diag cmp fail!\n");    
        LCM_DIAG_CONSOLE_PRINT("EPLD diag cmp fail!\n");
        sal_fprintf(p_oper->log_fp, "EPLD diag cmp fail!\n");
    }    
#endif
    return ret;
}

int32
diag_item_run_fan_test(diag_operator_t *p_oper)
{
    uint8 i;
    uint32 e350_48t_mapping[3] = {2,1,3};
    uint32 e350_8t_mapping[3] = {1,2,3};	
    int32 ret = DIAG_PASS;
    int32 result=0;
    uint8 fan_module_num = 0;
    fan_diag_result_t diag_result[DIAG_MAX_FAN_NUM];
    glb_card_t *p_card = NULL;
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);

    diag_item_run_common(p_oper);

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "FAN diag : card is NULL.\n");  
        LCM_DIAG_CONSOLE_PRINT("FAN diag : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "FAN diag : card is NULL.\n");
        p_item->rslt->chip_result[0] = -1;
        return DIAG_FAIL;
    } 
    fan_module_num = p_card->fan_module_num;
    sal_memset(diag_result, 0, sizeof(fan_diag_result_t)*DIAG_MAX_FAN_NUM);
    result = fan_diagnostic_test(fan_module_num, diag_result);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }

    for(i = 0; i < fan_module_num; i++)
    {
        if(diag_result[i].access_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "FAN module %d access fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("FAN module %d access fail!\n", i);
            sal_fprintf(p_oper->log_fp, "FAN module %d access fail!\n", i);
        }
        else if(diag_result[i].absent)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "FAN module %d absent!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("FAN module %d absent!\n", i);
            sal_fprintf(p_oper->log_fp, "FAN module %d absent!\n", i);
        }
        else if(diag_result[i].status_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "FAN module %d status %d fail!\n", i, diag_result[i].status_fail);  
            LCM_DIAG_CONSOLE_PRINT("FAN module %d status %d fail!\n", i, diag_result[i].status_fail);
            sal_fprintf(p_oper->log_fp, "FAN module %d status %d fail!\n", i, diag_result[i].status_fail);
        }
    }
    
    return ret;
}

int32 
diag_item_run_sensor_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
    uint8 i;
    int32 result=0;    
    uint8 sensor_num = 0;
    sensor_diag_result_t diag_result[DIAG_MAX_SENSOR_NUM];
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);

    diag_item_run_common(p_oper);
    
    sal_memset(diag_result, 0, sizeof(sensor_diag_result_t)*DIAG_MAX_SENSOR_NUM);
    result = sensor_diagnostic_test(&sensor_num, diag_result);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
    
    for(i = 0; i < sensor_num; i++)
    {
        if(diag_result[i].access_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "SENSOR %d access fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("SENSOR %d access fail!\n", i);
            sal_fprintf(p_oper->log_fp, "SENSOR %d access fail!\n", i);
        }
        else if(diag_result[i].temp_alarm)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "SENSOR %d temp alarm!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("SENSOR %d temp alarm!\n", i);
            sal_fprintf(p_oper->log_fp, "SENSOR %d temp alarm!\n", i);
        }
    }
    
    return ret;
}

int32
diag_item_run_psu_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
    uint8 i;
    int32 result=0;    
    uint8 psu_num = 0;
    psu_diag_result_t diag_result[DIAG_MAX_PSU_NUM];
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    diag_item_run_common(p_oper);
    
    sal_memset(diag_result, 0, sizeof(psu_diag_result_t)*DIAG_MAX_PSU_NUM);
    result = psu_diagnostic_test(&psu_num, diag_result);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
    
    for(i = 0; i < psu_num; i++)
    {
        if(diag_result[i].access_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "POWER %d access fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("POWER %d access fail!\n", i);
            sal_fprintf(p_oper->log_fp, "POWER %d access fail!\n", i);
        }
        else if(diag_result[i].absent)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "POWER %d absent!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("POWER %d absent!\n", i);
            sal_fprintf(p_oper->log_fp, "POWER %d absent!\n", i);
        }
        else
        {
            if(diag_result[i].status_fail)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "POWER %d work status fail!\n", i);  
                LCM_DIAG_CONSOLE_PRINT("POWER %d work status fail!\n", i);
                sal_fprintf(p_oper->log_fp, "POWER %d work status fail!\n", i);
            }
            if(diag_result[i].alert)
            {
                log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "POWER %d alert!\n", i);  
                LCM_DIAG_CONSOLE_PRINT("POWER %d alert!\n", i);
                sal_fprintf(p_oper->log_fp, "POWER %d alert!\n", i);
            }
        }
    }
    
    return ret;
}

int32
diag_item_run_gpio_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
    uint8 i;
    int32 result=0;    
    uint8 gpio_num = 0;
    gpio_diag_result_t diag_result[DIAG_MAX_GPIO_NUM];
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    diag_item_run_common(p_oper);
    
    sal_memset(diag_result, 0, sizeof(gpio_diag_result_t)*DIAG_MAX_GPIO_NUM);
    result = gpio_diagnostic_test(0x18, diag_result, &gpio_num);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
    
    for(i = 0; i < gpio_num; i++)
    {
        if(diag_result[i].rd_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "GPIO %d read fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("GPIO %d read fail!\n", i);
            sal_fprintf(p_oper->log_fp, "GPIO %d read fail!\n", i);
        }
        if(diag_result[i].wr_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "GPIO %d write fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("GPIO %d write fail!\n", i);
            sal_fprintf(p_oper->log_fp, "GPIO %d write fail!\n", i);
        }
        if(diag_result[i].cmp_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "GPIO %d cmp fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("GPIO %d cmp fail!\n", i);
            sal_fprintf(p_oper->log_fp, "GPIO %d cmp fail!\n", i);
        }
    }
    
    return ret;
}

int32
diag_item_run_mux_test(diag_operator_t *p_oper)
{
    int32 ret = DIAG_PASS;
    uint8 i;
    int32 result=0;    
    uint8 mux_num = 0;
    mux_diag_result_t diag_result[DIAG_MAX_MUX_NUM];
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);
    
    diag_item_run_common(p_oper);
    
    sal_memset(diag_result, 0, sizeof(mux_diag_result_t)*DIAG_MAX_MUX_NUM);
    result = mux_diagnostic_test(0x1, diag_result, &mux_num);
    if(result != 0)
    {
        p_item->rslt->chip_result[0] = result;
        ret = DIAG_FAIL;
    }
    
    for(i = 0; i < mux_num; i++)
    {
        if(diag_result[i].rd_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "MUX %d read fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("MUX %d read fail!\n", i);
            sal_fprintf(p_oper->log_fp, "MUX %d read fail!\n", i);
        }
        if(diag_result[i].wr_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "MUX %d write fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("MUX %d write fail!\n", i);
            sal_fprintf(p_oper->log_fp, "MUX %d write fail!\n", i);
        }
        if(diag_result[i].cmp_fail)
        {
            log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "MUX %d cmp fail!\n", i);  
            LCM_DIAG_CONSOLE_PRINT("MUX %d cmp fail!\n", i);
            sal_fprintf(p_oper->log_fp, "MUX %d cmp fail!\n", i);
        }
    }
    
    return ret;
}

/***************************************************/

diag_item_ops_t diag_ops_phy_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_phy_test,
    .report = diag_item_report_phy_test,
    .finish = diag_item_finish_common
};

/* Added by liuht to test sdk init for bug24982, 2013-12-21 */
diag_item_ops_t diag_ops_sdk_init_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_sdk_init_test,
    .report = diag_item_report_sdk_init_test,
    .finish = diag_item_finish_common
};


diag_item_ops_t diag_ops_l2switch_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_l2switch_test,
    .report = diag_item_report_l2switch_test,
    .finish = diag_item_finish_common
};


diag_item_ops_t diag_ops_eeprom0_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_eeprom0_test,
    .report = diag_item_report_eeprom0_test,
    .finish = diag_item_finish_common
};

/* Added by liuht to test rtc for bug24982, 2013-12-21 */
diag_item_ops_t diag_ops_rtc_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_rtc_test,
    .report = diag_item_report_rtc_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_eeprom1_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_eeprom1_test,
    .report = diag_item_report_eeprom1_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_epld_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_epld_test,
    .report = diag_item_report_epld_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_sensor_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_sensor_test,
    .report = diag_item_report_sensor_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_fan_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_fan_test,
    .report = diag_item_report_fan_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_psu_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_psu_test,
    .report = diag_item_report_psu_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_gpio_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_gpio_test,
    .report = diag_item_report_gpio_test,
    .finish = diag_item_finish_common
};

diag_item_ops_t diag_ops_mux_test = 
{
    .prepare = diag_item_prepare_common,
    .run = diag_item_run_mux_test,
    .report = diag_item_report_mux_test,
    .finish = diag_item_finish_common
};

#endif



