#ifdef BOOTUP_DIAG
#include "lcm.h"
#include "LcmMsg.h"
#include "glb_hw_define.h"
#include "glb_phy_define.h"
#include "glb_tempfile_define.h"
#include "lcm_client.h"
#include "genlog.h"
#include "ctclib_thread.h"
#include "diag_types.h"
#include "diag_item.h"
#include "diag_item_ops.h"
#include "diag_operator.h"

#include "diag_pkt_drv.h"
#include "diag_item_run_cb.h"
#include "diag_item_prepare_cb.h"
#include "diag_greatbelt_item.h"
#include "diag_device_item.h"
#include "phy_api.h"
#include "lcm_error.h"
#include "lcapi.h"
#include "glb_macro.h"
#include "lcm_mgt.h"
#include "lcm_debug.h"
#include "lcm_diag.h"
#include "ctc_pci.h"
#include "ctc_api.h"
#include<time.h>

#define DIAG_STR_BOOTUP_DIAG  "Bootup diagnostic"

diag_cfg_req_t req;
diag_port_info_t *g_p_port_info = NULL;
diag_operator_t g_diag_bootup_oper ;
diag_result_t *g_diag_lc_rslt_array=NULL;
/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
static uint8 g_l2ucast_success_flag = 0;
static uint8 g_l2ucast_diag_flag = 0;

extern  diag_item_ops_t diag_ops_phy_test;
extern  diag_item_ops_t diag_ops_l2switch_test;
extern  diag_item_ops_t diag_ops_eeprom0_test;
/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
extern  diag_item_ops_t diag_ops_rtc_test;
extern  diag_item_ops_t diag_ops_sdk_init_test;
extern  diag_item_ops_t diag_ops_eeprom1_test;
extern  diag_item_ops_t diag_ops_epld_test;
extern  diag_item_ops_t diag_ops_l2ucast_func;
extern  diag_item_ops_t diag_ops_fan_test;
extern  diag_item_ops_t diag_ops_sensor_test;
extern  diag_item_ops_t diag_ops_psu_test;
extern  diag_item_ops_t diag_ops_gpio_test;
extern  diag_item_ops_t diag_ops_mux_test;

extern int32 lcm_msg_tx_lcChsmInitSdkAck(lcm_clnt_t *clnt, int32 ret);
extern int32 lcm_msg_tx_lcBootupDiagResult(lcm_clnt_t *clnt, diag_operator_t *p_oper);

diag_item_t g_diag_ptn722_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   /* Modified by liuht for bug26836, 2014-01-26 */
   //{3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },  
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
   {4, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },     
};
/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
diag_item_t g_diag_e350_48t_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   /* Modified by liuht for bug26628, 2014--1-26 */
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },
   {4, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_FAN_TEST, E_DIAG_RUN_SELF,&diag_ops_fan_test, NULL},
   {5, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
   {6, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PSU_TEST, E_DIAG_RUN_SELF,&diag_ops_psu_test, NULL},   
   {7, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },   
   {8, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PHY_TEST, E_DIAG_RUN_OTHER,&diag_ops_phy_test, NULL },   
   {9, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_L2_UCAST_FUNC, E_DIAG_RUN_OTHER,&diag_ops_l2ucast_func, NULL},
};

diag_item_t g_diag_e350_8t12x_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   /* Modified by liuht for bug26628, 2014--1-26 */
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },  
   //{5, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_FAN_TEST, E_DIAG_RUN_SELF,&diag_ops_fan_test, NULL},
   {4, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
  //{7, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PSU_TEST, E_DIAG_RUN_SELF,&diag_ops_psu_test, NULL},   
   {5, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },     
   {6, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PHY_TEST, E_DIAG_RUN_OTHER,&diag_ops_phy_test, NULL },   
   {7, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_L2_UCAST_FUNC, E_DIAG_RUN_OTHER,&diag_ops_l2ucast_func, NULL},
};

/* added by liuht for e350-8t4s12x bug 29099, 2014-06-23 */
diag_item_t g_diag_e350_8t4s12x_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   /* Modified by liuht for bug26628, 2014--1-26 */
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },  
   //{5, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_FAN_TEST, E_DIAG_RUN_SELF,&diag_ops_fan_test, NULL},
   {4, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
  //{7, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PSU_TEST, E_DIAG_RUN_SELF,&diag_ops_psu_test, NULL},   
   {5, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },     
   {6, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PHY_TEST, E_DIAG_RUN_OTHER,&diag_ops_phy_test, NULL },   
   {7, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_L2_UCAST_FUNC, E_DIAG_RUN_OTHER,&diag_ops_l2ucast_func, NULL},
};
/* end of liuht added */

diag_item_t g_diag_e350_24x_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   /* Modified by liuht for bug26628, 2014--1-26 */
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },  
   //{5, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_FAN_TEST, E_DIAG_RUN_SELF,&diag_ops_fan_test, NULL},
   {4, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
  //{7, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PSU_TEST, E_DIAG_RUN_SELF,&diag_ops_psu_test, NULL},   
   {5, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },     
   //{6, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PHY_TEST, E_DIAG_RUN_OTHER,&diag_ops_phy_test, NULL },   
   //{7, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_L2_UCAST_FUNC, E_DIAG_RUN_OTHER,&diag_ops_l2ucast_func, NULL},
};

diag_item_t g_diag_e580_20q4z_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },  
   {4, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_FAN_TEST, E_DIAG_RUN_SELF,&diag_ops_fan_test, NULL},
   {5, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
   {6, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PSU_TEST, E_DIAG_RUN_SELF,&diag_ops_psu_test, NULL},  
   {7, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_GPIO_TEST, E_DIAG_RUN_SELF,&diag_ops_gpio_test, NULL},   
   {8, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_MUX_TEST, E_DIAG_RUN_SELF,&diag_ops_mux_test, NULL},   
   {9, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },     
};

diag_item_t g_diag_e580_48x2q4z_bootup_items[] = 
{    
   {1, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EPLD_TEST, E_DIAG_RUN_SELF,&diag_ops_epld_test, NULL },
   {2, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_EEPROM0_TEST, E_DIAG_RUN_SELF,&diag_ops_eeprom0_test, NULL },
   {3, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_RTC_TEST, E_DIAG_RUN_SELF,&diag_ops_rtc_test, NULL },  
   {4, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_FAN_TEST, E_DIAG_RUN_SELF,&diag_ops_fan_test, NULL},
   {5, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SENSOR_TEST, E_DIAG_RUN_SELF,&diag_ops_sensor_test, NULL},
   {6, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_PSU_TEST, E_DIAG_RUN_SELF,&diag_ops_psu_test, NULL},  
   {7, E_DIAG_LEVEL_COMPLETE,  E_DIAG_ATTR_DISRUPT, ITEM_STR_GPIO_TEST, E_DIAG_RUN_SELF,&diag_ops_gpio_test, NULL},   
   {8, E_DIAG_LEVEL_MINIMAL,  E_DIAG_ATTR_DISRUPT, ITEM_STR_SDK_INIT_TEST, E_DIAG_RUN_SDK_INIT,&diag_ops_sdk_init_test, NULL },
};

/*item timeout and finish*/
int32
diag_item_async_timeout(thread_t* p_arg)
{    
    GLB_PTR_VALID_CHECK(p_arg, LCM_E_INVALID_PTR);
    diag_operator_t *p_oper = (diag_operator_t*)p_arg->arg;
    GLB_PTR_VALID_CHECK(p_oper, LCM_E_INVALID_PTR);
    diag_item_t *p_item = &(p_oper->p_items[p_oper->current]);   

    log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "Lcm diag item async timeout\n");
    LCM_DIAG_CONSOLE_PRINT("Lcm diag item async timeout\n");
    sal_fprintf(p_oper->log_fp,"Lcm diag item async timeout\n");

    if(g_diag_stop_pkt_check_timer != NULL)
        g_diag_stop_pkt_check_timer(p_oper);	
    p_item->rslt->result = DIAG_FAIL;	
    p_item->ops->report(p_oper);  
    p_item->ops->finish(p_oper);   	
    diag_oper_run_item_enhance(p_oper);
    
    return 0;
}

int32
lcm_diag_start_timer(void* arg)
{    
    thread_master_t* p_master = NULL;
    p_master = (thread_master_t* )lc_get_thread_master();
    if(!p_master)
    {
        return LCM_E_INVALID_PTR;
    }
    ctclib_thread_add_timer_msec(p_master, diag_item_async_timeout, arg, 9000);
    return 0;
}

/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
int32
lcm_diag_rx_packet_polling(diag_operator_t *p_oper)
{    
    int i = 0;
    for(i = 0; i<8; i++)
    {
        if(1 == g_l2ucast_success_flag)
        {
            diag_item_async_finish(p_oper);
            break;
        }
        sleep(1);
    }
    return 0;
}


int32
lcm_diag_stop_timer(void* arg)
{   
    thread_master_t* p_master = NULL;
    p_master = (thread_master_t* )lc_get_thread_master();
    if(!p_master)
    {
        return LCM_E_INVALID_PTR;
    }   
    BOOTUP_DIAG_DEBUG("Lcm diag stop timer.\n");
    ctclib_thread_cancel_timer(p_master,arg);
    return 0;
}

/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
int32
_hagt_packet_rx_transmit_to_diag(void* skb)
{
    uint8 check_bytes[] = {0x01, 0x23, 0x45, 0x67, 0x89, 0x98, 0x76, 0x54, 0x32, 0x10};
    uint8 check_bytes_num; 
    ctc_pkt_rx_t* p_skb = (ctc_pkt_rx_t*)skb;

    for(check_bytes_num = 0; check_bytes_num < 10; check_bytes_num++)
    {
        if(p_skb->pkt_buf[0].data[32+16+check_bytes_num] != check_bytes[check_bytes_num])
        {
            g_l2ucast_success_flag = 0;
            return 0;
        }
    }
    g_l2ucast_success_flag = 1;
    return 0;
}

int32
_hagt_check_diag_flag()
{
    if(1 == g_l2ucast_diag_flag)
        return 1;
    else
        return 0;
}

/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
int32
diag_send_l2ucast_pkt_bydma(diag_operator_t *p_oper)
{
    uint8 pkt_buf[CTC_PKT_MTU] = {
        0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x08, 0x00, 0x45, 0x00,
        0x01, 0x23, 0x45, 0x67, 0x89, 0x98, 0x76, 0x54, 0x32, 0x10, 0x40, 0x00, 0x22, 0xf5, 0xc7, 0xc7,
        0xc7, 0x01, 0xc8, 0x01, 0x01, 0x01, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa,
        0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa,
        0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa
    };
    ctc_pkt_tx_t pkt_tx;
    ctc_pkt_tx_t* p_pkt_tx = &pkt_tx;
    ctc_pkt_info_t* p_tx_info = &(p_pkt_tx->tx_info);
    ctc_pkt_skb_t* p_skb = &(p_pkt_tx->skb);
    int32 ret = 0;

    sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
    pkt_tx.mode = CTC_PKT_MODE_DMA;

    /* must be evaluated field */
    p_tx_info->oper_type = CTC_PKT_OPER_NORMAL;
    p_tx_info->is_critical = TRUE;

    /* get dest_gport info */
    p_tx_info->dest_gport = _diag_get_diag_run_info();

    p_tx_info->flags |= CTC_PKT_FLAG_NH_OFFSET_BYPASS;

    p_skb->head = p_skb->buf;
    p_skb->end = p_skb->buf + CTC_PKT_MTU;
    p_skb->data = p_skb->buf + CTC_PKT_HDR_ROOM;
    p_skb->tail = p_skb->data+100;
    p_skb->len = 100;

    sal_memcpy(p_skb->data, pkt_buf, 80);
    ret = ctc_packet_tx(p_pkt_tx);
    if (ret < 0)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "Send packet by dma fail\n");
        LCM_DIAG_CONSOLE_PRINT("Send packet by dma fail\n");
        sal_fprintf(p_oper->log_fp,"Send packet by dma fail\n");
        return LCM_E_INIT_FAILED;
    }

    return LCM_E_SUCCESS;
}

int32 lcm_finish_all_diag_items_cb (diag_operator_t *p_oper)
{
    int32 ret =0; 
    glb_card_t* p_card;
    lcm_clnt_t* clnt;
    lcm_clnt_t* p_lcm_clnt;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv chsm init sdk : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    

    clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    if(NULL == clnt)
    {
        LCM_LOG_ERR("LCM lcm_finish_all_diag_items_cb: get lcm client failed.");
        return LCM_E_INIT_FAILED;
    }
      
    p_lcm_clnt = (lcm_clnt_t *)lcm_get_lcm_client();  
    if(NULL == p_lcm_clnt)
    {
        LCM_LOG_ERR("LCM lcm_finish_all_diag_items_cb: get lcm client failed.");
        return LCM_E_INIT_FAILED;
    }

#ifndef _GLB_UML_SYSTEM_
    /*modified by jcao for bug 16077, 2011-08-29*/
#ifdef BRINGUP_IMAGE    
    return 0;
#endif
    /* Open humber normal interrupt */
    if(hw_asic_register_normal_int() < 0)
    {
        LCM_LOG_ERR("Lcm open asic normal interrupt failed.");
        ret = LCM_E_IOCTL;
        return ret;
    }
    
    /* Open humber fatal interrupt */
    if(hw_asic_register_fatal_int() < 0)
    {
        LCM_LOG_ERR("Lcm open asic fatal interrupt failed.");
        ret = LCM_E_IOCTL;
        return ret;
    }
#endif /*!_GLB_UML_SYSTEM_*/
   
    lcm_mgt_monitor_lc();
    lcm_msg_tx_lcChsmInitSdkAck(clnt, ret);
    ret = lcm_msg_tx_lcBootupDiagResult(p_lcm_clnt,p_oper);
    if (ret < 0)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "lcm tx bootup diag result fail.");
        LCM_DIAG_CONSOLE_PRINT("lcm tx bootup diag result fail.");
        return ret; 
    }
    return ret;   
           
}

/* Modified by liuht for bug 24982, 2014-03-19 */
int32 
lcm_diag_tx_bootup_diag_result(lcm_clnt_t *clnt)
{
    int ret = 0;
    diag_operator_t *p_oper = &g_diag_bootup_oper;

    ret = lcm_msg_tx_lcBootupDiagResult(clnt,p_oper);
    if (ret < 0)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "lcm tx bootup diag result fail.");
        LCM_DIAG_CONSOLE_PRINT("lcm tx bootup diag result fail.");
    }
    return ret;
}

/* Modified by liuht to support bootup diag for bug24982, 2013-12-19 */
int32
lcm_diag_device_cfg(diag_operator_t *p_oper)
{
    int32 ret = 0;
    glb_lb_phy_t loopback ;  //0:LB_NONE   1:LB_PHY_FAR     2:LB_PHY_NEAR	
    uint32 port;
    uint8 check_phy_loopback_count = 0;
    uint8 check_phy_loopback_fail_flag = 0;
    glb_card_t* p_card = NULL;
    BOOTUP_DIAG_DEBUG("lcm diag device cfg\n");   
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "device cfg : card is NULL.\n");
        LCM_DIAG_CONSOLE_PRINT("device cfg : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "device cfg : card is NULL.\n");
        return -1;
    }
    phy_cfg_all_enable(1);  
    sleep(2);

    loopback = GLB_LB_PHY_NEAR_DIAG;
    phy_cfg_all_loopback(loopback);        
    sleep(3);

    /* modified by liuht for bug 26641, 2014-0422 */
    /* check for 5 times */
    while(1)
    {
        for(port = 0; port < p_card->port_num; port++)
        {
            ret = phy_check_link_status(port);
            ret = phy_check_link_status(port);
            if(ret == 0)
            {
                check_phy_loopback_fail_flag = 1;
                check_phy_loopback_count++;
                sleep(1);
                break;
            }
        }
        if((check_phy_loopback_fail_flag == 0) || (check_phy_loopback_count >= 5))
        { 
            break;
        }
        else
        { 
            check_phy_loopback_fail_flag = 0;
        }
    }

    for(port = 0; port < p_card->port_num; port++)
    {
        ret = phy_check_link_status(port);
        ret = phy_check_link_status(port);
        if(ret == 1)
        {
            sal_fprintf(p_oper->log_fp, "Port %d  link up\n",port);
        }
        else if(ret == 0)
        {
            sal_fprintf(p_oper->log_fp, "Port %d  link down\n",port);
        }
        
    }
    BOOTUP_DIAG_DEBUG("lcm diag device cfg end ret=%d\n",ret);   
    return ret;
}

/* Modified by liuht for bug26853, 2013-01-20 */
int32
lcm_diag_device_decfg(diag_operator_t *p_oper)
{
    glb_lb_phy_t loopback ;  //0:LB_NONE   1:LB_PHY_FAR     2:LB_PHY_NEAR	
    int32 ret = 0;
    uint32 port;
    glb_card_t* p_card = NULL;
    BOOTUP_DIAG_DEBUG("lcm diag device decfg\n");   
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        log_sys(M_MOD_BOOTUP_DIAG, E_WARNING, "device decfg : card is NULL.\n");
        LCM_DIAG_CONSOLE_PRINT("device decfg : card is NULL.\n");
        sal_fprintf(p_oper->log_fp, "device decfg : card is NULL.\n");
        return -1;
    }
    loopback = GLB_LB_NONE;
    phy_cfg_all_loopback(loopback);    
    sleep(1);
    phy_cfg_all_enable(0);          
    sleep(1);

    for(port = 0; port < p_card->port_num; port++)
    {
        ret = phy_check_link_status(port);
        ret = phy_check_link_status(port);
    }

    BOOTUP_DIAG_DEBUG("lcm diag device decfg end ret=%d\n",ret); 
    return ret;
}

int32
lcm_diag_l2ucast_func_chip_cfg(diag_operator_t *p_oper)
{
    int32 ret =0;         
    ret = diag_ucast_cfg(&req);
    /*Fix bug19615. Add delay for xg mac be ready to send packet.*/
    sleep(1);
    BOOTUP_DIAG_DEBUG("Lcm l2ucast cfg min_mac_id =%d ,ret =%d.\n",req.min_mac_id, ret);
    return ret;
}

int32
lcm_diag_l2ucast_func_chip_decfg(diag_operator_t *p_oper)
{
    diag_del_l2ucast_to_cpu();
    return 0;
}

int32
lcm_diag_l2ucast_func_flag_set(diag_operator_t *p_oper)
{
    g_l2ucast_diag_flag = 1;
    return 0;
}

int32
lcm_diag_l2ucast_func_flag_unset(diag_operator_t *p_oper)
{
    g_l2ucast_diag_flag = 0;
    return 0;
}

#ifndef _GLB_DISTRIBUTE_SYSTEM_

/* Added by liuht for bug26536, 2013-12-26 */
/* Start ptn722 bootup diag */
static int32 
_lcm_diag_start_ptn722_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag ptn722 \n");   

    p_oper->p_items = g_diag_ptn722_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_ptn722_bootup_items)/sizeof(g_diag_ptn722_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}

static int32 
_lcm_diag_start_e350_48t_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag e350 48t\n");       
    
    p_oper->p_items = g_diag_e350_48t_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_e350_48t_bootup_items)/sizeof(g_diag_e350_48t_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}

static int32 
_lcm_diag_start_e350_8t12x_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag e350 8t\n");       
    
    p_oper->p_items = g_diag_e350_8t12x_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_e350_8t12x_bootup_items)/sizeof(g_diag_e350_8t12x_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}

/* added by liuht for e350-8t4s12x bug 29099, 2014-06-23 */
static int32 
_lcm_diag_start_e350_8t4s12x_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag e350 8t\n");       
    
    p_oper->p_items = g_diag_e350_8t4s12x_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_e350_8t4s12x_bootup_items)/sizeof(g_diag_e350_8t4s12x_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}
/* end of liuht added */

static int32 
_lcm_diag_start_e350_24x_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag e350 24x\n");       
    
    p_oper->p_items = g_diag_e350_24x_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_e350_24x_bootup_items)/sizeof(g_diag_e350_24x_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}

static int32 
_lcm_diag_start_gb_demon_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag gb demon\n");       
    
    p_oper->p_items = NULL;
    p_oper->max_item_num = 0;
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}

static int32 
_lcm_diag_start_e580_20Q4Z_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag e580 20Q4Z\n");       
    
    p_oper->p_items = g_diag_e580_20q4z_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_e580_20q4z_bootup_items)/sizeof(g_diag_e580_20q4z_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}

static int32 
_lcm_diag_start_e580_48x2q4z_bootup_diag (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    int32 ret = 0;
    int32 i = 0;
    BOOTUP_DIAG_DEBUG("Lcm bootup diag e580 48X2Q4Z\n");       
    
    p_oper->p_items = g_diag_e580_48x2q4z_bootup_items;
    p_oper->max_item_num = sizeof(g_diag_e580_48x2q4z_bootup_items)/sizeof(g_diag_e580_48x2q4z_bootup_items[0]);
    g_diag_lc_rslt_array = (diag_result_t*)sal_calloc(sizeof(diag_result_t)*p_oper->max_item_num); 
    if (!g_diag_lc_rslt_array)
    {
        return -1;
    }
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        p_oper->p_items[i].rslt = &g_diag_lc_rslt_array[i];
        p_oper->p_items[i].rslt->result = DIAG_UNTEST;
    }
   
    ret = diag_oper_run_diagnostic(p_oper, TRUE);
    return ret;
}
#endif

int32 
lcm_diag_start_enhance_bootup_diag ()
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;    
  
    return diag_oper_run_diagnostic(p_oper, FALSE);

}

/* Added by liuht for bug26642, 2013-01-20 */
int32 get_log_file_name_with_time_stamp(char *file_name)
{
    char year[5], month[3], day[3],hour[3],minute[3];
    char *file_name_prefix = "/mnt/flash/cold/diag/bootup_diagnostic.";
    char *file_name_postfix = ".log";
    char underline = '_';

    time_t timep;
    struct tm *p;

    time(&timep);
    p=localtime(&timep);

    sal_sprintf(year, "%d", (1900 + p->tm_year));
    if(1+p->tm_mon >= 10)
    {  
        sal_sprintf(month, "%d", (1+p->tm_mon));
    }
    else
    {   
        sal_sprintf(month, "%c%d", '0',(1+p->tm_mon));
    }
    if(p->tm_mday >= 10)
    { 
        sal_sprintf(day, "%d", p->tm_mday);
    }
    else
    {
        sal_sprintf(day, "%c%d", '0', p->tm_mday);
    }
    if(p->tm_hour >= 10)
    { 
        sal_sprintf(hour, "%d", p->tm_hour);
    }
    else
    {  
        sal_sprintf(hour, "%c%d", '0', p->tm_hour);
    }
    if(p->tm_min >= 10)
    {  
        sal_sprintf(minute, "%d", p->tm_min);
    }
    else
    {  
        sal_sprintf(minute, "%c%d", '0', p->tm_min);
    }	
    sal_sprintf(file_name, "%s%s%c%s%s%c%s%s%s", 
        file_name_prefix, 
        year, 
        underline,
        month, 
        day, 
        underline,
        hour, 
        minute,
        file_name_postfix);
    return 0 ;
}


#ifndef _GLB_DISTRIBUTE_SYSTEM_
static int32 _lcm_diag_port_info_init (glb_card_t* p_card)
{
    uint32 i;     
    uint32 min_mac_id = 52;   
    uint16 min_gport_id = 0xffff;  

    req.port_nums = p_card->port_num;
    
    if(g_p_port_info == NULL)
    {
        g_p_port_info = (diag_port_info_t *)sal_calloc(sizeof(diag_port_info_t)*(req.port_nums));
    }
    if (!g_p_port_info)
    {
        return -1;
    }
    req.p_port_info = g_p_port_info;
    for(i=0; i<req.port_nums; i++)
    {
        /*merge bug31179, liangf, 2014-12-17*/
        if(p_card->pp_port[i]->lp_support)
        {
            g_p_port_info[i].port_exist = 1;
            g_p_port_info[i].mac_id = p_card->pp_port[i]->mac_idx;
            /* Modified by liuht for bug26853, 2013-01-20 */
            g_p_port_info[i].gport_id= p_card->pp_port[i]->g_port_index;
            if(min_mac_id > g_p_port_info[i].mac_id)
            {
                min_mac_id = g_p_port_info[i].mac_id;         
            } 
            if(min_gport_id > g_p_port_info[i].gport_id)
            {
                min_gport_id = g_p_port_info[i].gport_id;
            } 
        }
    }
    req.min_mac_id = min_mac_id;
    req.min_gport_id = min_gport_id;	

    diag_init_run_info(&req); 
    
    return 0;

}

static int32 _lcm_diag_common_info_init (glb_card_t* p_card)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    char log_file_name[DIAG_STR_LEN];	
    
    LCM_IF_ERROR_RETURN(_lcm_diag_port_info_init(p_card));
    
    sal_memset(p_oper, 0, sizeof(diag_operator_t));
    /* Modified by liuht for bug26642, 2013-01-20 */
    get_log_file_name_with_time_stamp(log_file_name);
    sal_strncpy(p_oper->name, DIAG_STR_BOOTUP_DIAG, DIAG_STR_LEN);
    sal_strncpy(p_oper->log_file_name, log_file_name, DIAG_STR_LEN);
    /* Modified by liuht for bug27084, 2014-01-27 */
    sal_strncpy(p_oper->diag_level_file_name, DIAG_STR_BOOTUP_LOG_PATH, DIAG_STR_LEN);	
    p_oper->log_fp = NULL;
    p_oper->level_fp = NULL;	
    p_oper->diag_type = E_DIAG_TYPE_BOOTUP;
    p_oper->cpu_type = p_card->cpu_type;    
    p_oper->diag_level = p_card->bootup_diag_level;
    p_oper->finish_all_items_cb = lcm_finish_all_diag_items_cb;

    return 0;
}
#endif

int32
lcm_diag_start_stage1 (glb_card_t* p_card)
{
#ifdef _GLB_DISTRIBUTE_SYSTEM_
#ifdef _GLB_UML_SYSTEM_

#else // !_GLB_UML_SYSTEM_

#endif // _GLB_UML_SYSTEM_ end
#else // !_GLB_DISTRIBUTE_SYSTEM_
#ifdef _GLB_UML_SYSTEM_

#else // !_GLB_UML_SYSTEM_
    _lcm_diag_common_info_init(p_card);

    if(GLB_SERIES_PTN722 == p_card->board_type.series)
    {
        switch (p_card->board_type.type)
        {
            case GLB_BOARD_PTN722:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_ptn722_bootup_diag(p_card));     
                break;
            default:
                LCM_LOG_WARN("Bootup diag PTN722  series unsupport board: type %d",p_card->board_type.type);
                return LCM_E_INVALID_BOARD;
        }              
    }
    else if(GLB_SERIES_E350 == p_card->board_type.series)
    {
        switch (p_card->board_type.type)
        {
            case GLB_BOARD_E350_48T4XG:
            case GLB_BOARD_E350_48T4X2Q:
            case GLB_BOARD_E350_24T4XG:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e350_48t_bootup_diag(p_card));
                break;
            case GLB_BOARD_E350_8T12XG:
            case GLB_BOARD_E350_PHICOMM_8T12XG:
            case GLB_BOARD_E350_MT_8T12XG:
            case GLB_BOARD_E350_MTRJ_8T12XG:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e350_8t12x_bootup_diag(p_card));
                break;
            case GLB_BOARD_E350_8T4S12XG:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e350_8t4s12x_bootup_diag(p_card));
                break;
            case GLB_BOARD_E350_8TS12X:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e350_8t4s12x_bootup_diag(p_card));
                break;
            case GLB_BOARD_E350_24X:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e350_24x_bootup_diag(p_card));
                break;
            default:
                LCM_LOG_WARN("Bootup diag E350 series unsupport board: type %d",p_card->board_type.type);
                return LCM_E_INVALID_BOARD;
        }        
    }
    else if(GLB_SERIES_GREATBELT_DEMO == p_card->board_type.series)
    {
        switch (p_card->board_type.type)
        {
            case GLB_BOARD_GREATBELT_DEMO:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_gb_demon_bootup_diag(p_card));
                break;
            default:
                LCM_LOG_WARN("Bootup diag GB DEMON series unsupport board: type %d",p_card->board_type.type);
                return LCM_E_INVALID_BOARD;
        }        
    }
    else if(GLB_SERIES_E580 == p_card->board_type.series)
    {
        switch (p_card->board_type.type)
        {
            case GLB_BOARD_E580_24Q:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e580_20Q4Z_bootup_diag(p_card));
                break;
            case GLB_BOARD_E580_48X2Q4Z:
            case GLB_BOARD_E580_48X6Q:
            case GLB_BOARD_E580_32X2Q:
                LCM_IF_ERROR_RETURN(_lcm_diag_start_e580_48x2q4z_bootup_diag(p_card));
                break;
            default:
                LCM_LOG_WARN("Bootup diag E580 series unsupport board: type %d",p_card->board_type.type);
                return LCM_E_INVALID_BOARD;
        }        
    }
#endif // _GLB_UML_SYSTEM_ end
#endif // _GLB_DISTRIBUTE_SYSTEM_ end
    
    return LCM_E_SUCCESS;
}

/* Added by liuht to test sdk init for bug24982, 2013-12-21 */
int32
lcm_diag_start_sdk_init()
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;    
    p_oper->current = 0;
  
    return diag_oper_run_item_sdk_init(p_oper);
}

/* Added by liuht to test sdk init for bug24982, 2013-12-21 */
int32
lcm_diag_finish_sdk_init(int32 result)
{
    diag_operator_t *p_oper = &g_diag_bootup_oper;
    return diag_oper_finish_item_sdk_init (p_oper, result);
}

int32
lcm_diag_start_stage2 (void)
{
#ifdef _GLB_DISTRIBUTE_SYSTEM_
#ifdef _GLB_UML_SYSTEM_

#else // !_GLB_UML_SYSTEM_

#endif // _GLB_UML_SYSTEM_ end
#else // !_GLB_DISTRIBUTE_SYSTEM_
#ifdef _GLB_UML_SYSTEM_

#else // !_GLB_UML_SYSTEM_
    int32 ret = 0;
    diag_oper_install_packet_check_timer(lcm_diag_stop_timer);
    ret = lcm_diag_start_enhance_bootup_diag();
    return ret;

#endif // _GLB_UML_SYSTEM_ end
#endif // _GLB_DISTRIBUTE_SYSTEM_ end
    
    return LCM_E_SUCCESS;
}
#endif

