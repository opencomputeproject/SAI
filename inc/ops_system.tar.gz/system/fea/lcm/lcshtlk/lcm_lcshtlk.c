/****************************************************************************
 * lcm_lcshtlk.c:    lcm communicate with lcsh
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     :       R0.01
 * Author       :       weij
 * Date         :       2010-08-07
 * Reason       :       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "lcm_srv.h"
#include "glb_const.h"
#include "glb_if_define.h"
#include "glb_hw_define.h"
#ifndef _GLB_UML_SYSTEM_
#include "phy_api.h"
#include "ad9517_api.h"
#include "ad9559_api.h"     /* chani 20130930 for DPLL */
#include "ds3104_api.h"
#include "ds21348_api.h"
#include "ds26503_api.h"
#include "l2switch_api.h"
#include "epld_api.h"
#include "fiber_api.h"
#include "sensor_api.h"
#include "fan_api.h"
#include "power_api.h"
#include "vsc3308_api.h"
#include "eeprom_api.h"
#include "gpio_api.h"
#include "mux_api.h"
#include "fpga_api.h"
#include "i2c_cpm.h"
#include "poe_api.h"
#endif /* _GLB_UML_SYSTEM_ */
#include "ctc_api.h"
#include "lcm_mgt.h"
#include "lcm_debug.h"
#include "lcm_show_tcam_sram.h"
#include "lcm_show_sdk.h"
// TODO: Commented by xgu for compile, 20121120  #include <drv_io.h> 
#include "diag_chip.h"
#include "ctclib_show.h"
// TODO: Commented by xgu for compile, 20121120 #include "sys_humber_ftm.h"
/****************************************************************************
 *  
* Global and Declaration
*
*****************************************************************************/
lcm_srv_cb_t lcm_lcsh_srv_cb_tbl[];

extern int32 
hagt_intr_debug_dump();
extern int32 
hagt_acl_debug_dump();
/* modified by cuixl for bug 22441, 2013-03-18 */
/* We don't do resource check before, so we need store these failed entries when resource is ok*/
/* Now we do resource check, so function is no need any more */
/*modification start*/
#if 0
extern int32 
hagt_qos_debug_dump();
#endif

extern int32
hagt_pdu_debug_dump();

extern int32
hagt_rmt_debug_dump(void);

extern void *epld_base;
#ifndef _GLB_UML_SYSTEM_
static void gpio_delay()
{ 
    volatile int32 loop = 0x10;
    while(loop--);
}
extern int32 cpu_debug_gephy_mdio_read(unsigned int phy_addr, unsigned int reg, unsigned int* value);
extern int32 cpu_debug_gephy_mdio_write(unsigned int phy_addr, unsigned int reg, unsigned int value);
extern int32 drv_chip_read(uint8 lchip, uint32 offset, uint32* value);
extern int32 drv_chip_write(uint8 lchip, uint32 offset, uint32 value);
#endif
/*********************************************************************
 * Name    : lcm_lcsh_msg_rx_test1
 * Purpose : this function is used to test rcv message form lcsh and return value
 * Input   : 
 * Output  : 
 * Return  : hsrv_e_***  - hal server return type
 * Note    : if the fid is already alloced, it will return HSRV_E_ENTRY_EXIST
*********************************************************************/
int32 
lcm_lcsh_msg_rx_test1(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    lcapi_lcm_lcsh_test1_msg_t lcapi_lcm_lcsh_test1_msg;
        
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0 , sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&lcapi_lcm_lcsh_test1_msg, 0 , sizeof(lcapi_lcm_lcsh_test1_msg));

    lcapi_lcm_lcsh_test1_msg.int_value = 111;
    sal_snprintf(lcapi_lcm_lcsh_test1_msg.str_value, 100, "I get it :)");
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, &lcapi_lcm_lcsh_test1_msg, sizeof(lcapi_lcm_lcsh_test1_msg_t));
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_TEST1;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(lcapi_lcm_lcsh_test1_msg_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;
}
extern int32 asic_gb_gephy_xgmdio_read(uint8 bus, uint8 phy_addr, uint16 reg, uint8 dev, uint16* value);
extern int32 asic_gb_gephy_xgmdio_write(uint8 bus, uint8 phy_addr, uint16 reg, uint8 dev, uint16 value);

/*********************************************************************
 * Name    : lcsh_lcm_msg_rx_read_regs
 * Purpose : this function is used to test rcv message form lcsh and return value
 * Input   : 
 * Output  : 
 * Return  : hsrv_e_***  - hal server return type
 * Note    : if the fid is already alloced, it will return HSRV_E_ENTRY_EXIST
*********************************************************************/
int32 
lcsh_lcm_msg_rx_read_regs(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    read_regs_reg_t* req_msg;
    reg_values_t ret_val[MAX_DIAG_ENTRY_NUM];
#ifndef _GLB_UML_SYSTEM_
    epld_para_t epld_para;
    fiber_para_t xfp_para;
    fiber_para_t sfp_para;
    poe_para_t   poe_para;
    uint8 buf[MAX_DIAG_ENTRY_NUM];
    eeprom_para_t eeprom_para;
#endif
    int ret = 0;

    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
#ifdef _GLB_UML_SYSTEM_

    req_msg = (read_regs_reg_t* )(req->msg);

    LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG, "Recv message: %d %d %d %d\n",
                            req_msg->opcode, req_msg->chip, req_msg->addr, req_msg->count);
    
    ret_val[0].addr = 0x1234;
    ret_val[0].value = 0x5678;
    ret_val[1].addr = 0xabcd;
    ret_val[1].value = 0xdcba;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_READ_REGS;
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t)*2);
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t)*2 + LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }

    return ret;
#else
    uint32 port_id;
    uint32 chip;
    uint32 address, device, ret_cnt, ii;
    uint16 tmpval;
    uint32 tmpval_32;
    uint16 tmpval_16;
    uint32 count = 0;
    FILE* fp;
    uint8* tmpbuf;
    uint8 byte_width;
    uint8 indirect = 0;
    
    ret_cnt = 0;
    req_msg = (read_regs_reg_t* )(req->msg);
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_READ_REGS;
    st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;

    switch(req_msg->opcode) 
    {
        case INIT_PHY:
            if(req_msg->chip < req_msg->addr)
            {
                for(port_id=(req_msg->chip-1); port_id<req_msg->addr; port_id++)
                {
                    phy_re_init(port_id);
                }
            }
            else
            {
                phy_re_init(req_msg->chip);
            }
            break;
        case CHECK_QSGMII:
#if 0 /*Commented by xgu for compile pass, 2014-4-21*/            
            ctc_port_get_qsgmii_code_err(req_msg->chip*4, &tmpval_32);
            ctc_port_get_qsgmii_code_err(req_msg->chip*4, &tmpval_32);
            if(tmpval_32!=0)
            {
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
#else
            return -1;
#endif            
            break;
        case REG_GBVTSS8211_R:
            ret = cpu_debug_gephy_mdio_read(0x11, req_msg->addr, &tmpval_32); 
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = req_msg->addr;
                ret_val[0].value = tmpval_32;
                ret_cnt = 1;
            }            

            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;

        case REG_GEPHY_R:
            port_id = req_msg->chip - 1;
            address = req_msg->addr;
            count = req_msg->count;
            for(ii = 0; ii < count; ii++)
            {
                ret = gephy_reg_read(port_id, (uint8)(address + ii), &tmpval);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
            
        case REG_XGPHY_R:
            port_id = req_msg->chip - 1;
            device = (req_msg->addr >> 16) & 0xffff;
            address = (req_msg->addr) & 0xffff;
            count = req_msg->count;
            for(ii = 0; ii < count; ii++)
            {
                ret = xgphy_reg_read(port_id, (uint8)device, (uint16)(address+ii), &tmpval);

                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_C45_BY_C22_R:
            device = (req_msg->addr >> 16) & 0xffff;
            address = (req_msg->addr) & 0xffff;
            count = req_msg->count;
            for(ii = 0; ii < count; ii++)
            {
                ret = asic_gb_gephy_xgmdio_read((req_msg->chip>>8)&0xff, req_msg->chip&0xff,(uint16)(address+ii),(uint8)device, &tmpval);

                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }            
            break;
        case REG_AD9517_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to ad917 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x3; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            for(ii = 0; ii < count; ii++)
            {
                ret = ad9517_read(chip, (uint16)(address + ii), &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   

        case REG_DS3104_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to ds3104 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x2; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            
            for(ii = 0; ii < count; ii++)
            {
                ret = ds3104_read(chip, (uint16)(address + ii), &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;       

        case REG_DS21348_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            indirect = req_msg->indirect;
            tmpval_32 = 0;
            if(indirect)
            {
                /*switch cpu epld to ds21348 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x7; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            for(ii = 0; ii < count; ii++)
            {
                ret = ds21348_read(chip, (uint8)(address + ii), &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   
            
        case REG_L2SWITCH_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to l2switch */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4;  
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            for(ii = 0; ii < count; ii++)
            {
                ret = l2switch_register_read(chip, (address + ii), &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break; 

        case REG_L2SWITCH_PHY_R:
            chip = req_msg->chip;            
            port_id = req_msg->addr;
            address = req_msg->addr_1;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to l2switch */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                 *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = l2switch_phy_read(chip, port_id, address, &tmpval_16);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = address;
                ret_val[0].value = tmpval_16;
                ret_cnt = 1;
            }    
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
            
        case REG_XFP_R:
            sal_memset(&xfp_para, 0, sizeof(fiber_para_t));
            port_id = req_msg->chip - 1;
            xfp_para.subdev = (req_msg->addr >> 8)&0xff;
            xfp_para.offset = (req_msg->addr)&0xff;
            xfp_para.len = req_msg->count > LCAPI_LCM_LCSH_REG_NUM ? LCAPI_LCM_LCSH_REG_NUM : req_msg->count;
            xfp_para.val = buf;
            ret = fiber_read(port_id, &xfp_para);
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                for(ii = 0; ii< xfp_para.len; ii++)
                {
                    ret_val[ii].addr = xfp_para.offset + ii;
                    ret_val[ii].value = xfp_para.val[ii];
                }
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * xfp_para.len);
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE + sizeof(reg_values_t) * xfp_para.len;
            }
            break;

        case REG_DUMP_L2SWITCH_REG:
            chip = req_msg->chip;            
            port_id = req_msg->addr;            
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to l2switch */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            dump_l2switch_key_register(chip, port_id);
            
            ret_cnt = 1;
 
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_READ_REGS;
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;       
            
        case REG_SFP_R:
            sal_memset(&sfp_para, 0, sizeof(fiber_para_t));
            port_id = req_msg->chip - 1;
            ret = (req_msg->addr >> 8)&0xff;
            if(ret==3)
            {
                sfp_para.subdev = FIBER_DEV_ADDR3;
            }
            else if(ret == 2)
            {
                sfp_para.subdev = FIBER_DEV_ADDR2;
            }
            else
            {
                sfp_para.subdev = FIBER_DEV_ADDR1;
            }            
            sfp_para.offset = (req_msg->addr)&0xff;
            sfp_para.len = req_msg->count > LCAPI_LCM_LCSH_REG_NUM ? LCAPI_LCM_LCSH_REG_NUM : req_msg->count;
            sfp_para.val = buf;
            ret = fiber_read(port_id, &sfp_para);
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                for(ii = 0; ii< sfp_para.len; ii++)
                {
                    ret_val[ii].addr = sfp_para.offset + ii;
                    ret_val[ii].value = sfp_para.val[ii];
                }
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * sfp_para.len);
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE + sizeof(reg_values_t) * sfp_para.len;
            }
            break;

         case REG_POE_R:
            sal_memset(&poe_para, 0, sizeof(poe_para_t));
            /* if poe port, port !=0, else poe sys, port == 0 */
            port_id = req_msg->chip;
            poe_para.offset = (req_msg->addr) & 0xffff;
            poe_para.len = req_msg->count;
            poe_para.val = buf;

            if(port_id)
            {
                /* poe port */
                ret = poe_port_read(port_id - 1, &poe_para);
            }
            else
            {
                /* poe system */
                ret = poe_sys_read(&poe_para);
            }

            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                ret_val[0].addr = poe_para.offset;
                ret_val[0].value = poe_para.val[0] << 8 | poe_para.val[1];
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t));
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE + sizeof(reg_values_t);
            }          
            /*Fix bug 23086, add break after process.*/
            break;
        case REG_EPLD_R:
            sal_memset(&epld_para, 0, sizeof(epld_para_t));
            chip = req_msg->chip;
            epld_para.addr = req_msg->addr;
            count = req_msg->count;
            for(ii = 0; ii < count; ii++)
            {
                ret = epld_read(chip, &epld_para);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = epld_para.addr++;
                ret_val[ii].value = epld_para.val;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
}
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
            
        case REG_XGPHY_LOAD:
            st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            port_id = req_msg->chip - 1;
#if 1
            tmpbuf = (uint8* )LCM_MALLOC(CTCLIB_MEM_LCM_MODULE, 16);
            fp = sal_fopen("/etc/vsc8488_firmware_mdio.bin", "rb");
            if(fp < 0) 
            {
                LCM_FREE(CTCLIB_MEM_LCM_MODULE, tmpbuf);
                break;
            }
            tmpval_32=0;
            while((count = sal_fread(tmpbuf, 1, 16, fp))>0)
            {
                for(ii=0; ii<count/4; ii++)
                {
                    tmpval_16 = (tmpbuf[ii*4+3]<<8) | tmpbuf[ii*4+2];
                    xgphy_reg_write(port_id, 0x1f, tmpval_32++, tmpval_16);
                    tmpval_16 = (tmpbuf[ii*4+1]<<8) | tmpbuf[ii*4];
                    xgphy_reg_write(port_id, 0x1f, tmpval_32++, tmpval_16);
                }        
            }
            
            while(tmpval_32 < 0x8000)
            {
                xgphy_reg_write(port_id, 0x1f, tmpval_32++, 0);
            }
            st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_OK;
            sal_fclose(fp);
            LCM_FREE(CTCLIB_MEM_LCM_MODULE, tmpbuf);
#else
            LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG, "QT2X25 start......."); 
            fp = sal_fopen("/etc/qt2x25_firmware_mdio.bin", "rb");
            if(NULL == fp) {
                LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG,"Open /etc/qt2x25_firmware_mdio.bin failed.");
                break;
            }

            tmpbuf = (uint8* )LCM_MALLOC(CTCLIB_MEM_LCM_MODULE, 0x6000);
            if(NULL == tmpbuf)
            {
                sal_fclose(fp);
                LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG,"QT2x25 load firmware, out of memory");
                break;
            }
            count = sal_fread(tmpbuf, 1, 0x6000, fp);
            LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG, "QT2x25 load, read %d bytes", count); 
            if(count < 0)
            {
                    LCM_FREE(CTCLIB_MEM_LCM_MODULE, tmpbuf);
                    LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG,"QT2x25 load, read failed"); 
                    sal_fclose(fp);
                    break;
            }
            
            device = 3;
            for(ii = 0; ii < 0x4000; ii++)
            {
                address = 0x8000 + ii;
                ret = xgphy_reg_write(port_id, device, address, tmpbuf[ii]);
                if(ret)
                {
                    LCM_FREE(CTCLIB_MEM_LCM_MODULE, tmpbuf);
                    sal_fclose(fp);
                    LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG,"QT2x25 load, write failed"); 
                    break;
                }
            }

            device = 4;
            for(ii = 0x4000; ii < count; ii++)
            {
                address = 0x8000 + ii;
                ret = xgphy_reg_write(port_id, device, address, tmpbuf[ii]);
                if(ret)
                {
                    LCM_FREE(CTCLIB_MEM_LCM_MODULE, tmpbuf);
                    sal_fclose(fp);
                    LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG,"QT2x25 load, write failed"); 
                    break;
                }
            }
            st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_OK;
            LCM_FREE(CTCLIB_MEM_LCM_MODULE, tmpbuf);
            sal_fclose(fp);
#endif            
            break;
            
        case REG_HUMBER_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            for(ii = 0; ii < count; ii++)
            {
                ret = drv_chip_read(chip, address + ii *4 , &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii * 4;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;

        case REG_SENSOR_R:            
            chip = req_msg->chip;               
            ret = sensor_reg_read(chip, req_msg->addr, buf, req_msg->count);
            /* IIC operate, ret >=0 mean success. jqiu modify.bug 13956. 2011-01-22*/
            if(ret<0)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = req_msg->addr;
                ret_cnt = 1;
                if(req_msg->count == 1)
                    ret_val[0].value = buf[0];
                else if(req_msg->count == 2)
                    ret_val[0].value = (buf[0]<<8) + buf[1];
                else
                    ret_cnt = 0;                
            }    
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   
        case REG_SENSOR_TMP_R:
            chip = req_msg->chip;
            ret = sensor_dev_get_temp(chip, req_msg->addr, (int16*)&tmpval_16);
            if(ret != RESULT_OK)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = req_msg->addr;
                ret_val[0].value = tmpval_16;
                ret_cnt = 1;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_GPIO_CHIP_R:            
            chip = req_msg->chip;               
            ret = gpio_reg_read(chip, req_msg->addr, buf, req_msg->count);
            if(ret<0)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = req_msg->addr;
                ret_cnt = 1;
                ret_val[0].value = buf[0];                 
            }    
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;  
        case REG_MUX_CHIP_R:            
            chip = req_msg->chip;               
            ret = mux_reg_read(chip, req_msg->addr, buf, req_msg->count);
            if(ret<0)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = req_msg->addr;
                ret_cnt = 1;
                ret_val[0].value = buf[0];                 
            }    
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break; 
        case REG_FAN_R:            
            chip = req_msg->chip;               
            ret = fan_reg_read(chip, req_msg->addr, buf);
            /* IIC operate, ret >=0 mean success. jqiu modify.bug 13956. 2011-01-22*/
            if(ret<0)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = req_msg->addr;
                ret_cnt = 1;
                ret_val[0].value = buf[0];      
            }    
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   
        case REG_PSU_R:            
            chip = req_msg->chip;  
            ret = psu_reg_read(chip, req_msg->addr, buf, req_msg->count);
            if(ret >= 0)
            {
                for(ii=0; ii<req_msg->count; ii++)
                {
                    ret_val[ii].addr = req_msg->addr + ii;
                    ret_val[ii].value = buf[ii];
                    ret_cnt ++;
                }
            }
            else
            {
                ret_cnt =0;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;               
        case REG_VSC3308_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            for(ii = 0; ii < count; ii++)
            {
                ret = vsc3308_read(chip, address, &buf[ii]);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address++;
                ret_val[ii].value = buf[ii];
                ret_cnt++;
            }
            
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_EEPROM_R:
            sal_memset(&eeprom_para, 0, sizeof(eeprom_para_t));
            chip = req_msg->chip;
            eeprom_para.offset = req_msg->addr;
            eeprom_para.len = req_msg->count;
            eeprom_para.p_val = sal_calloc(eeprom_para.len);
            if (eeprom_para.p_val)
            {
                ret = eeprom_read(chip, &eeprom_para);
                if (ret >=0)
                {
                    for (ii= 0; ii < eeprom_para.len; ii++)
                    {
                        ret_val[ii].addr = eeprom_para.offset + ii;
                        ret_val[ii].value = eeprom_para.p_val[ii];
                        ret_cnt ++;
                    }
                }
                else
                {
                    ret_cnt =0;
                }
                sal_free(eeprom_para.p_val);
            }
            else
            {
                ret_cnt =0;
            }       
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;  
        case REG_I2C_R:       
            /* Added by qicx for bug 21474: 2012-11-27 */
            /* increase one more parameter "i2c_bus_idx(8-bit variable)", use the last 8-bit of "req_msg->addr_1" */
            ret = raw_i2c_read((req_msg->addr_1&0xff), (req_msg->chip & 0xff), req_msg->addr, (req_msg->addr_1>>8), 
                            buf, (req_msg->count & 0xff));
            if(ret >= 0)
            {
                for(ii=0; ii<req_msg->count; ii++)
                {
                    ret_val[ii].addr = req_msg->addr + ii;
                    ret_val[ii].value = buf[ii];
                    ret_cnt ++;
                }
            }
            else
            {
                ret_cnt =0;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break; 
        case REG_FPGA_R:
            byte_width = req_msg->chip;
            address = req_msg->addr;
            ret = fpga_read(byte_width, address, &tmpval_32);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = address;
                ret_val[0].value = tmpval_32;
                ret_cnt = 1;
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;     
            
        case REG_DS26503_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            indirect = req_msg->indirect;
            tmpval_32 = 0;            
            if(indirect)
            {
                /*switch cpu epld to ds21348 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x7; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            for(ii = 0; ii < count; ii++)
            {
                ret = ds26503_read(chip, (uint8)(address + ii), &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;     
            
#if 1	/* chani 20130930 for DPLL */
        case REG_AD9559_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
				// Don't support it
            }
            
            for(ii = 0; ii < count; ii++)
            {
                ret = ad9559_read(chip, (uint16)(address + ii), &tmpval_32);
                if(ret)
                {
                    break;
                }
                ret_val[ii].addr = address + ii;
                ret_val[ii].value = tmpval_32;
                ret_cnt++;
            }
            sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   
#endif /* chani 20130930 for DPLL */
         case REG_CHIP_SHIM_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            ret = epld_shim_read(0, chip,address,&tmpval_32);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = address;
                ret_val[0].value = tmpval_32;
                ret_cnt = 1;
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;    

        case REG_CHIP_DDR_R:
            chip = req_msg->chip;
            address = req_msg->addr;
            ret = epld_ddr_read(0, chip,address,&tmpval_32);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = address;
                ret_val[0].value = tmpval_32;
                ret_cnt = 1;
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;        

        case REG_CHIP_SUP_R:
            address = req_msg->addr;
            ret = epld_sup_read(0, address, &tmpval_32);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_val[0].addr = address;
                ret_val[0].value = tmpval_32;
                ret_cnt = 1;
                sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, ret_val, sizeof(reg_values_t) * ret_cnt);
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;     

        case REG_SHIM_TEST:
            count = req_msg->count;
            ret = epld_shim_test(count);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_cnt = 1;
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;           

        case REG_SUP_TEST:
            count = req_msg->count;
            ret = epld_sup_test(count);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_cnt = 1;
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;      

        case REG_SHIM_SUP_TEST:
            count = req_msg->count;
            ret = epld_sup_shim_test(count);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_cnt = 1;
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;      

        case REG_DDR_TEST:
            count = req_msg->count;
            chip = req_msg->chip;
            ret = epld_ddr_test(count,chip);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_cnt = 1;
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;          

        case REG_DOWNLOAD_FPGA:
            chip = req_msg->chip;
            address = req_msg->addr;
            count = req_msg->count;
            ret = epld_download_fpga(chip,address,count);
            if(ret)
            {
                ret_cnt = 0;
            }
            else
            {
                ret_cnt = 1;
            }                
            if(ret_cnt <= 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = sizeof(reg_values_t) * ret_cnt + LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;              
        default:
            break;
    }
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;
#endif  /* _GLB_UML_SYSTEM_ */     
}
/*********************************************************************
 * Name    : lcsh_lcm_msg_rx_write_regs
 * Purpose : this function is write register
 * Input   : 
 * Output  : 
 * Return  : hsrv_e_***  - hal server return type
 * Note    : if the fid is already alloced, it will return HSRV_E_ENTRY_EXIST
*********************************************************************/
int32 
lcsh_lcm_msg_rx_write_regs(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    write_regs_reg_t* req_msg;
    int ret = 0;

    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }

    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));

#ifdef _GLB_UML_SYSTEM_

    req_msg = (write_regs_reg_t* )(req->msg);

    LCM_LOG_DEBUG(lcm, lcsh, LCM_LCSH_MSG, "Recv message: %d %d %d %d\n",
                            req_msg->opcode, req_msg->chip, req_msg->addr, req_msg->value);

    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
    st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }

    return ret;
#else
    uint32 port_id;
    uint32 chip;
    uint32 address,device;
    uint16 tmpval;
    uint32 tmpval_32;
    uint16 tmpval_16;
    uint32 enable;
    epld_para_t epld_para;
    eeprom_para_t eeprom_para;
    fiber_para_t fiber_para;
    poe_para_t poe_para;
    uint8 tmpval_8;
    uint8 byte_width;
    uint8 indirect = 0;
    uint8 offset_buf[4];

    //glb_vtss_phy_recov_clk_t phy_clk_port;
    glb_vtss_phy_clock_conf_t phy_clk_conf;
    
    req_msg = (write_regs_reg_t* )(req->msg);
    switch(req_msg->opcode) 
    {
        case REG_GBVTSS8211_W:
            ret = cpu_debug_gephy_mdio_write(0x11, req_msg->addr, req_msg->value);
            
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;  
        case REG_GEPHY_W:
            port_id = req_msg->chip -1 ;
            address = req_msg->addr;
            tmpval = req_msg->value;

            ret = gephy_reg_write(port_id, (uint8)address, tmpval);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_XGPHY_W:
            port_id = req_msg->chip - 1;
            device = (req_msg->addr >> 16) & 0xffff;
            address = (req_msg->addr) & 0xffff;
            tmpval = req_msg->value;

            ret = xgphy_reg_write(port_id, device, address, tmpval);


            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_C45_BY_C22_W:
            device = (req_msg->addr >> 16) & 0xffff;
            address = (req_msg->addr) & 0xffff;
            tmpval = req_msg->value;

            ret = asic_gb_gephy_xgmdio_write((req_msg->chip>>8)&0xff, req_msg->chip&0xff, address, device, tmpval);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;    
        case REG_AD9517_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to ad9517 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x3; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = ad9517_write(chip, (uint16)address, tmpval_32);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;    

        case REG_DS3104_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to ds3104 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x2; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = ds3104_write(chip, (uint16)address, tmpval_32);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;        

        case REG_DS21348_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to ds21348 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x7; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = ds21348_write(chip, (uint8)address, tmpval_32);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;        

        case REG_L2SWITCH_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to l2switch */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
            
            ret = l2switch_register_write((uint8)chip, address, tmpval_32);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;     

        case REG_L2SWITCH_PHY_W:
            chip = req_msg->chip;
            port_id = req_msg->addr;
            address = req_msg->addr_1;
            tmpval_16 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to l2switch */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = l2switch_phy_write(chip, port_id, address, tmpval_16);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   

        case REG_CONFIG_L2SWITCH_PORT:
            chip = req_msg->chip;
            port_id = req_msg->addr;  
            enable = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to l2switch */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = l2switch_enable_port(chip, port_id, enable);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;   
        case REG_SFP_W:
            sal_memset(&fiber_para, 0, sizeof(fiber_para_t));
            port_id = req_msg->chip - 1;            
            ret = (req_msg->addr >> 8)&0xff;
            if(ret==3)
            {
                fiber_para.subdev = FIBER_DEV_ADDR3;
            }
            else if(ret == 2)
            {
                fiber_para.subdev = FIBER_DEV_ADDR2;
            }
            else
            {
                fiber_para.subdev = FIBER_DEV_ADDR1;
            }  
            fiber_para.offset = (req_msg->addr)&0xff;
            if(fiber_para.subdev==FIBER_DEV_ADDR3)
            {
                fiber_para.len = 2;
                tmpval = (req_msg->value & 0xffff);
                fiber_para.val = (uint8*)&tmpval;                
            }
            else
            {
                fiber_para.len = 1;
                tmpval_8 = (req_msg->value & 0xff);
                fiber_para.val = &tmpval_8;
            }
            ret = fiber_write(port_id, &fiber_para);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
            
        case REG_POE_W:
            sal_memset(&poe_para, 0, sizeof(poe_para_t));
            /* if poe port, port !=0, else poe sys, port == 0 */
            port_id = req_msg->chip;
            poe_para.offset = (req_msg->addr) & 0xffff;
            poe_para.len = 2;
            tmpval = (req_msg->value & 0xffff);
            poe_para.val = (uint8*)&tmpval;

            if(port_id)
            {
                /* poe port */
                ret = poe_port_write(port_id - 1, &poe_para);
            }
            else
            {
                /* poe system */
                ret = poe_sys_write(&poe_para);
            }

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;

        case REG_EPLD_W:
            sal_memset(&epld_para, 0, sizeof(epld_para_t));
            chip = req_msg->chip;
            epld_para.addr = req_msg->addr;
            epld_para.val = req_msg->value;

            ret = epld_write(chip, &epld_para);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break; 

        case REG_HUMBER_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;

            ret = drv_chip_write(chip, address, tmpval_32);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;

        case REG_SENSOR_W:            
            chip = req_msg->chip;
            tmpval_8 = req_msg->value;
            ret = sensor_reg_write(chip, req_msg->addr, &tmpval_8, 1);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            /* IIC operate, ret >=0 mean success. jqiu modify.bug 13956. 2011-01-22*/
            if(ret<0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;    

        case REG_SENSOR_TMP_W:            
            chip = req_msg->chip;
            ret = sensor_dev_set_temp(chip, req_msg->addr, (int16)req_msg->value);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_GPIO_CHIP_W:            
            chip = req_msg->chip;
            tmpval_8 = req_msg->value;
            ret = gpio_reg_write(chip, req_msg->addr, &tmpval_8, 1);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret<0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;  
        case REG_MUX_CHIP_W:            
            chip = req_msg->chip;
            tmpval_8 = req_msg->value;
            ret = mux_reg_write(chip, req_msg->addr, &tmpval_8, 1);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret<0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_FAN_W:            
            chip = req_msg->chip;
            tmpval_8 = req_msg->value;
            ret = fan_reg_write(chip, req_msg->addr, tmpval_8);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            /* IIC operate, ret >=0 mean success. jqiu modify.bug 13956. 2011-01-22*/
            if(ret<0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;  
        case REG_PSU_W:            
            chip = req_msg->chip;
            tmpval_8 = req_msg->value;
            ret = psu_reg_write(chip, req_msg->addr, tmpval_8, 1);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            /* IIC operate, ret >=0 mean success. jqiu modify.bug 13956. 2011-01-22*/
            if(ret<0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;       
        case REG_VSC3308_W:
            chip = req_msg->chip;
            tmpval_8 = req_msg->value;
            ret = vsc3308_write(chip, req_msg->addr, tmpval_8);
            
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret<0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_VSC3308_CONF:
            chip = req_msg->chip;
            ret = vsc3308_config_input_output_pin(chip, (req_msg->addr & 0xff), (req_msg->addr_1 & 0xff));

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_PHY_CLK_CONF:
            port_id = req_msg->chip - 1;
            //phy_clk_port = req_msg->addr;
            phy_clk_conf.src = (req_msg->value>>16) & 0xff;
            phy_clk_conf.freq =(req_msg->value>>8) & 0xff; 
            phy_clk_conf.squelch = req_msg->value & 0xff;
            
            ret = phy_cfg_clock(port_id, phy_clk_conf);
            
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;
        case REG_EEPROM_W:
            sal_memset(&eeprom_para, 0, sizeof(eeprom_para_t));
            chip = req_msg->chip;
            eeprom_para.offset = req_msg->addr;
            tmpval_8 = req_msg->value;
            eeprom_para.p_val = &tmpval_8;
            eeprom_para.len = 1;

            ret = eeprom_write(chip, &eeprom_para);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;      
        case REG_I2C_W:
            /* Added by qicx for bug 21474: 2012-11-27 */
            /* increase one more parameter "i2c_bus_idx(8-bit variable)", use the last 8-bit of "req_msg->addr_1" */
            tmpval_8 = (req_msg->addr_1 >> 8) & 0xff;  /* get value length */
            if(1 == tmpval_8)
            {
                offset_buf[0] = (uint8)(req_msg->value & 0xff);
            }
            else if (2 == tmpval_8)
            {
                offset_buf[0] = (uint8)((req_msg->value >> 8) & 0xff);
                offset_buf[1] = (uint8)(req_msg->value & 0xff);
            }
            else if (3 == tmpval_8)
            {
                offset_buf[0] = (uint8)((req_msg->value >> 16) & 0xff);
                offset_buf[1] = (uint8)((req_msg->value >> 8) & 0xff);
                offset_buf[2] = (uint8)(req_msg->value & 0xff);
            }
            else if (4 == tmpval_8)
            {
                offset_buf[0] = (uint8)((req_msg->value >> 24) & 0xff);
                offset_buf[1] = (uint8)((req_msg->value >> 16) & 0xff);
                offset_buf[2] = (uint8)((req_msg->value >> 8) & 0xff);
                offset_buf[3] = (uint8)(req_msg->value & 0xff);
            }
            ret = raw_i2c_write((req_msg->addr_1&0xff), (req_msg->chip&0xffff), req_msg->addr, 
                    ((req_msg->addr_1>>16) & 0xff), offset_buf, tmpval_8);
            
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break; 

        case REG_FPGA_W:            
            byte_width = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            ret = fpga_write(byte_width, address, tmpval_32);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;           
            
        case REG_DS26503_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
                /*switch cpu epld to ds21348 */
                *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x7; 
                gpio_delay();
                *((uint8 *)(epld_base + 0xa)) = 0x1; 
                *((uint8 *)(epld_base + 0xa)) = 0x0; 
            }
    
            ret = ds26503_write(chip, (uint8)address, tmpval_32);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;                 
#if 1	/* chani 20130930 for DPLL */
        case REG_AD9559_W:
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            indirect = req_msg->indirect;
            
            if(indirect)
            {
				/* Don't Support it */
            }
    
            ret = ad9559_write(chip, (uint16)address, tmpval_32);

            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;    
#endif /* chani 20130930 for DPLL */
        case REG_CHIP_SHIM_W: 
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            ret = epld_shim_write(0, chip,address, tmpval_32);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;        

        case REG_CHIP_DDR_W: 
            chip = req_msg->chip;
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            ret = epld_ddr_write(0, chip,address, tmpval_32);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;         
            

        case REG_CHIP_SUP_W:            
            address = req_msg->addr;
            tmpval_32 = req_msg->value;
            ret = epld_sup_write(0, address, tmpval_32);
            st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_WRITE_REGS;
            if(ret < 0)
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
                st_lcapi_lcm_lcsh_msg.errcode = ret;
            }
            else
            {
                st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
            }
            break;             
        default:
            break;
    }
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;
#endif  /* _GLB_UML_SYSTEM_ */     
}

/*********************************************************************
 * Name    : lcsh_lcm_msg_rx_get_port_info
 * Purpose : this function get port info
 * Input   : 
 * Output  : 
 * Return  : hsrv_e_***  - hal server return type
 * Note    : if the fid is already alloced, it will return HSRV_E_ENTRY_EXIST
*********************************************************************/
int32 
lcsh_lcm_msg_rx_get_port_info(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    showport_t* req_msg;
    showport_t st_msg;
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    portdesc_t *port_desc;
    int ret = 0;
    uint16 ii, port_num, counts;

    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    if(NULL == p_card)
    {
        return -1;
    }

    port_num = p_card->port_num;
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(&st_msg, 0, sizeof(showport_t));

    req_msg = (showport_t* )(req->msg);
    if(GET_PORT_NUM == req_msg->opcode)
    {
        st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_GET_PORT_INFO;
        st_msg.opcode = GET_PORT_NUM;
        st_msg.port_num = port_num;
        sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, &st_msg, sizeof(showport_t));
        st_lcapi_lcm_lcsh_msg.msg_len = sizeof(showport_t) + LCAPI_LCM_LCSH_HEAD_SIZE;
        if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
        {
            return ret;
        }
    }
    else if(GET_PORT_INFO == req_msg->opcode)
    {
        counts = req_msg->port_num;
        port_desc = (portdesc_t* )LCM_CALLOC(CTCLIB_MEM_LCM_MODULE, sizeof(portdesc_t) * counts);

        if (!port_desc)
        {
            ret = -1;
        }

        for(ii = 0; ii< counts; ii++)
        {
            if((req_msg->offset + ii) >= port_num)
            {
                counts = ii;
                break;
            }
            p_port = p_card->pp_port[req_msg->offset + ii];
            port_desc[ii].admin.up = p_port->port_cfg.enable;
            port_desc[ii].admin.speed= p_port->port_cfg.speed;
            port_desc[ii].admin.duplex = p_port->port_cfg.duplex;
            port_desc[ii].admin.loopback= p_port->port_cfg.loopback;
            port_desc[ii].curstatus.up = p_port->port_status.link_up;
            port_desc[ii].curstatus.speed= p_port->port_status.speed;
            port_desc[ii].curstatus.duplex= p_port->port_status.duplex;
            port_desc[ii].present = p_port->port_state;
            port_desc[ii].portno = p_port->port_idx;  
            port_desc[ii].mac_id = p_port->mac_idx;
            port_desc[ii].phy_type = p_port->phy_type;
            port_desc[ii].is_combo = p_port->is_combo;
        }
        st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_GET_PORT_INFO;
        sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, port_desc, sizeof(portdesc_t)*counts);
        st_lcapi_lcm_lcsh_msg.msg_len = sizeof(portdesc_t)*counts + LCAPI_LCM_LCSH_HEAD_SIZE;
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, port_desc);
        if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
        {
            return ret;
        }
    }
    return ret;
  
}

/*********************************************************************
 * Name    : lcsh_lcm_msg_rx_conport_regs
 * Purpose : this function is used to test rcv message form lcsh and return value
 * Input   : 
 * Output  : 
 * Return  : hsrv_e_***  - hal server return type
 * Note    : if the fid is already alloced, it will return HSRV_E_ENTRY_EXIST
*********************************************************************/
int32 
lcsh_lcm_msg_rx_conport_regs(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    conport_t* con_msg;
    int ret = 0;

    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }

    con_msg = (conport_t* )(req->msg);
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));

#ifdef _GLB_UML_SYSTEM_
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;
#else

    switch(con_msg->opcode)
    {
        case CONFIG_SPEED:
            ret = phy_cfg_speed(con_msg->port_id - 1, con_msg->speed);
            break;
        case CONFIG_DUPLEX:
            ret = phy_cfg_duplex(con_msg->port_id - 1, con_msg->duplex);
            break;
        case CONFIG_ENABLE:
            ret = phy_cfg_enable(con_msg->port_id - 1, con_msg->enable);
            break;
        case CONFIG_LB:
            ret = phy_cfg_loopback(con_msg->port_id - 1, con_msg->loopback);
            break;
        case CONFIG_MEDIA:
            if(con_msg->media_type == GLB_PORT_TYPE_AUTO)
                ret = phy_cfg_medium(con_msg->port_id - 1, GLB_MEDIA_AMS_CU_1000BX);
            else if(con_msg->media_type == GLB_PORT_TYPE_COPPER)
                ret = phy_cfg_medium(con_msg->port_id - 1, GLB_MEDIA_RJ45);
            else
                ret = phy_cfg_medium(con_msg->port_id - 1, GLB_MEDIA_1000BX);
            break;

        default:
            break;
    }
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_CONFIG_PORT;
    st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;

#endif  /* _GLB_UML_SYSTEM_ */     
}

/*********************************************************************
 * Name    : lcsh_lcm_msg_rx_l2switch_stats
 * Purpose : this function get l2switch stats
 * Input   : 
 * Output  : 
 * Return  : 
 * Note    : 
*********************************************************************/
int32 
lcsh_lcm_msg_rx_l2switch_stats(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    int32 i = 0;
    int32 ret = 0;
    int8 count = 1;
    uint8 chip = 0;
    uint8 port = 0;
    uint8 all_port;
    l2switch_stats_t stats[24];    
#ifndef _GLB_UML_SYSTEM_   
    uint8 indirect = 0;
    l2switch_port_stats_t l2switch_port_stats;
    glb_card_t* p_card = NULL; 
#endif
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    l2switch_dump_t *p_l2switch_dump;

    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }
    
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    sal_memset(&stats, 0, sizeof(stats));

    p_l2switch_dump = (l2switch_dump_t* )(req->msg);
    
    all_port = p_l2switch_dump->all_port;
    chip = p_l2switch_dump->chip;
    port = p_l2switch_dump->port;
    
#ifdef _GLB_UML_SYSTEM_
    for (i = 0; i < count; i++)
    {                
        stats[i].txPkt = i;
        stats[i].txByte = i;
        stats[i].txDrop = i;
        stats[i].txErr = i;
        stats[i].rxPkt = i;
        stats[i].rxByte = i;
        stats[i].rxDrop = i;
        stats[i].rxErr = i;        
    }   
    goto err;
#else
    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    if(0 == p_card->l2switch_num)
    {
        ret = LCAPI_LCM_LCSH_ERR;
        goto err;
    }
    
    indirect = p_l2switch_dump->indirect;
            
    if(indirect)
    {
        /*switch cpu epld to l2switch */
       *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4; 
        gpio_delay();
        *((uint8 *)(epld_base + 0xa)) = 0x1; 
        *((uint8 *)(epld_base + 0xa)) = 0x0; 
    }
    
    if(all_port)
    {
        count = l2switch_get_port_num(chip);
    }
        
    for (i = 0; i < count; i++)
    {
        sal_memset(&l2switch_port_stats, 0, sizeof(l2switch_port_stats));

        if(count > 1)
        {
            ret = l2switch_port_get_stats(chip, i, &l2switch_port_stats);
        }
        else
        {
            ret = l2switch_port_get_stats(chip, port, &l2switch_port_stats);
        }
        if(ret)
        {
            count = 0;   
            break;
        }
        stats[i].txPkt = l2switch_port_stats.tx_packets;
        stats[i].txByte = l2switch_port_stats.tx_bytes;
        stats[i].txDrop = l2switch_port_stats.tx_dropped;
        stats[i].txErr = l2switch_port_stats.tx_errors;
        stats[i].rxPkt = l2switch_port_stats.rx_packets;
        stats[i].rxByte = l2switch_port_stats.rx_bytes;
        stats[i].rxDrop = l2switch_port_stats.rx_dropped;
        stats[i].rxErr = l2switch_port_stats.rx_errors;        
    }     
#endif  
err: 
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_DUMP_L2SWITCH_STATS;
    sal_memcpy(&(st_lcapi_lcm_lcsh_msg.msg[0]), &count, sizeof(uint8));
    sal_memcpy(&(st_lcapi_lcm_lcsh_msg.msg[1]), stats, sizeof(l2switch_stats_t)*count);
   
    if(ret)
    {
        st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
        st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
    }
    else
    {
        st_lcapi_lcm_lcsh_msg.msg_len = sizeof(uint8) + sizeof(l2switch_stats_t)*count + LCAPI_LCM_LCSH_HEAD_SIZE;
    }
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }

    return ret;
    
}

/*********************************************************************
 * Name    : lcsh_lcm_msg_rx_clear_l2switch_stats
 * Purpose : this function clear l2switch stats
 * Input   : 
 * Output  : 
 * Return  : 
 * Note    : 
*********************************************************************/
int32 
lcsh_lcm_msg_rx_clear_l2switch_stats(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
#ifndef _GLB_UML_SYSTEM_    
    int32 i = 0;
    int8 count = 1;
    uint8 indirect = 0;
    glb_card_t* p_card = NULL; 
#endif
    int32 ret = 0;
    
    uint8 chip = 0;
    uint8 port = 0; 
    uint8 all_port;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    l2switch_dump_t *p_l2switch_dump;
    
    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }
    
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));

    p_l2switch_dump = (l2switch_dump_t* )(req->msg);
    
    all_port = p_l2switch_dump->all_port;
    chip = p_l2switch_dump->chip;
    port = p_l2switch_dump->port;

#ifdef _GLB_UML_SYSTEM_
goto err;
#else
    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    if(0 == p_card->l2switch_num)
    {
        ret = LCAPI_LCM_LCSH_ERR;
        goto err;
    }

    indirect = p_l2switch_dump->indirect;
                
    if(indirect)
    {
        /*switch cpu epld to l2switch */
        *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x4;     
        gpio_delay();
        *((uint8 *)(epld_base + 0xa)) = 0x1; 
        *((uint8 *)(epld_base + 0xa)) = 0x0; 
    }

    if(all_port)
    {
        count = l2switch_get_port_num(chip);
    }
    
    for (i = 0; i < count; i++)
    {

        if(count > 1)
        {
            ret += l2switch_clear_port_stat(chip, i);
        }
        else
        {
            ret += l2switch_clear_port_stat(chip, port);
        }

    } 
#endif
err:
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_CLEAR_L2SWITCH_STATS;
    if(ret)
    {
        st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
        st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
    }
    else
    {
        st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    }

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }

    return ret;
}

/*********************************************************************
 * Name    : lcm_lcsh_msg_rx_test1
 * Purpose : this function is used to test rcv message form lcsh and return value
 * Input   : 
 * Output  : 
 * Return  : hsrv_e_***  - hal server return type
 * Note    : if the fid is already alloced, it will return HSRV_E_ENTRY_EXIST
*********************************************************************/
int32 
lcm_lcsh_msg_rx_show_transceiver(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
#ifdef _GLB_UML_SYSTEM_

    return LCM_E_SUCCESS;
#else
    int ret = 0;
    uint8 detail;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    glb_card_t* p_card = NULL; 
    glb_port_t* p_port = NULL;
    int32 port_id;
    char port_name[GLB_PHY_PORT_FULL_NAME_SZ];
    
    if (NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess or req\n");
        return LCM_E_INVALID_PARAM;
    }

    /*get local line card*/
    p_card= lcm_mgt_get_card();  
    if (NULL == p_card)
    {
        return -1;
    }

    detail = req->msg[0];
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0 , sizeof(lcapi_lcm_lcsh_msg_t));
    sal_memset(port_name, 0 , sizeof(port_name));

    CTCLIB_DUMP_PREPARE();
    
    for(port_id = 0; port_id< p_card->port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];
        if (p_port && p_port->p_fiber)
        {
            if (p_port->p_host_card)
            {
                /*Fix bug 14686. jqiu 2011-06-15*/
                if_build_port_shortname_by_slot_port(port_name, p_port->panel_slot_no, p_port->panel_port_no, p_port->panel_sub_port_no);
            }
            else
            {
                sal_snprintf(port_name, 10, "port-%d", p_port->port_idx); 
            }
            fiber_dump_basic_info(port_name, p_port->p_fiber, g_fp_dumpfile);
            if(detail)
            {
                fiber_dump_diag_info(port_name, p_port->p_fiber, g_fp_dumpfile);
            }
        }
    }
    
    CTCLIB_DUMP_CLOSE_FILE();
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_DUMP_TRANSCEIVER_INFO;
    st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;
#endif
}





/*****************************************************************************
 * Name        :_lcm_msg_rx_show_acl_entries(lcm_sess_t *p_sess, 
                                                            lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose     : 
 * Input       : 
 *                  
 * Output       : 
 * Return       : DEV_E_NONE = SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
 ****************************************************************************/
static int32
_lcm_msg_rx_show_acl_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_acl_tcam_get_req_t req;
    diag_acl_tcam_data_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_acl_tcam_get_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_acl_tcam_get_req_t));
    sal_memset(&resp, 0, sizeof(diag_acl_tcam_data_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_acl_tcam_get_req_t *)p_reqmsg->msg;  

    req.chip_id= reqmsg->chip_id;
    req.key_type = reqmsg->key_type;
    req.table_type = reqmsg->table_type;

    lcm_get_all_acl_or_qos_entries(&req, &resp);

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,"OK",sizeof("OK"));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ACL_ENTRIES;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof("OK")+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_acl_entries() %d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}



/******************************************************************************
 * Name         :_lcm_msg_rx_show_one_acl_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : this function get a entry form tcam 
 * Input        :  
 * Output       : 
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
******************************************************************************/
static int32
_lcm_msg_rx_show_one_acl_entry(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_reqmsg)
{
    int32 ret = 0;
    diag_acl_tcam_get_req_t req;
    diag_acl_tcam_entry_t resp;
    
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_acl_tcam_get_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_acl_tcam_get_req_t));
    sal_memset(&resp, 0, sizeof(diag_acl_tcam_data_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_acl_tcam_get_req_t *)p_reqmsg->msg;  

    req.chip_id = reqmsg->chip_id;
    req.key_type = reqmsg->key_type;
    req.index = reqmsg->index;

    lcm_get_one_acl_or_qos_entry(&req, &resp);

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_acl_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_ACL_ENTRY;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_acl_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_one_acl_entry() %d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : _lcm_msg_rx_show_l2_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_l2_entries(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_reqmsg)
{
    int32 ret = 0;
    diag_l2_tcam_entry_req_t req;
    diag_l2_tcam_entries_resp_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l2_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l2_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_l2_tcam_entries_resp_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l2_tcam_entry_req_t *)p_reqmsg->msg;  
    req.chip_id = reqmsg->chip_id;

    lcm_msg_rx_l2_get_all_entries(&req,&resp);

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,"OK",sizeof("OK"));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_MAC_ENTRIES;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof("OK")+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_l2_entries() %d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipuc_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipuc_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;

    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  
    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entries_resp_t));  

    lcm_ipuc_v4_get_entries((void*)&req, (void*)&resp);

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,"OK",sizeof("OK"));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPUC_ENTRIES;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof("OK")+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipuc_entries() ret= %d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_msg_rx_show_l2_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_l2_one_entry(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_reqmsg)
{
    int32 ret = 0;
    diag_l2_tcam_entry_req_t req;
    diag_l2_tcam_entry_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l2_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l2_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_l2_tcam_entry_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l2_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id = reqmsg->chip_id;
    req.index = reqmsg->index;
    req.type = reqmsg->type;

    lcm_get_one_l2_entry(&req,&resp);
    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_l2_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_MAC_ENTRY;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_l2_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_l2_one_entry()  ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipuc_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipuc_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entry_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id  =reqmsg->chip_id;
    req.index = reqmsg->index;
    resp.chip_id = reqmsg->chip_id;
    resp.index = reqmsg->index;
    resp.position= reqmsg->position;
    resp.ip_ver= DIAG_IP_VER_4;
        
    lcm_get_one_ipuc_entry(&resp);
    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv4_v6_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPUC_ENTRY;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv4_v6_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipuc_one_entry() ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;

}
/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipv6uc_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipv6uc_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{  
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entry_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id = resp.chip_id= reqmsg->chip_id;
    req.index = resp.index = reqmsg->index;
    resp.chip_id = reqmsg->chip_id;
    resp.index = reqmsg->index;
    resp.position= reqmsg->position;
    resp.ip_ver= DIAG_IP_VER_6;

    lcm_get_one_ipuc_entry(&resp);    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv4_v6_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPV6UC_ENTRY;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv4_v6_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipv6uc_one_entry()  ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;

}

/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipv6uc_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipv6uc_entries(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entries_resp_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  
    req.chip_id = reqmsg->chip_id;

    lcm_ipuc_v6_get_entries(&req, &resp);    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv4_v6_tcam_entries_resp_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPV6UC_ENTRIES;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv6_tcam_entries_resp_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipv6uc_entries()  ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;

}


/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipmc_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipmc_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entry_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id = reqmsg->chip_id;

    lcm_ipmc_get_entries(&req,&resp);
    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv4_v6_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPMC_ENTRIES;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv4_v6_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipmc_entries() ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipmc_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipmc_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entry_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id = reqmsg->chip_id;
    req.index = reqmsg->index;

    lcm_get_one_ipmc_entry(&req,&resp);
    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv4_v6_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPMC_ENTRY;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv4_v6_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipmc_one_entry() ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipmcv6_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipmcv6_one_entry(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entry_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv6_tcam_entry_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id = reqmsg->chip_id;
    req.index = reqmsg->index;

    lcm_get_one_ipuc_v6_entry(&req,&resp);
    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv6_tcam_entry_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ONE_IPMCV6_ENTRY;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv6_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipmcv6_one_entry()  ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : _lcm_msg_rx_show_ipmcv6_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
static int32
_lcm_msg_rx_show_ipmcv6_entries(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t *p_reqmsg)
{
    int32 ret = 0;
    diag_l3_tcam_entry_req_t req;
    diag_ipv4_v6_tcam_entries_resp_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_l3_tcam_entry_req_t *reqmsg = NULL;

    sal_memset(&req, 0, sizeof(diag_l3_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_ipv4_v6_tcam_entries_resp_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_l3_tcam_entry_req_t *)p_reqmsg->msg;  

    req.chip_id = reqmsg->chip_id;

    lcm_ipmc_v6_get_entries(&req,&resp);
    
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_ipv4_v6_tcam_entries_resp_t));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_ALL_IPMCV6_ENTRIES;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_ipv4_v6_tcam_entry_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_msg_rx_show_ipmcv6_entries() ret=%d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_lcsh_msg_rx_show_usrid(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* p_req)
 * Purpose      : 
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
 * Note         : do not write db, write hard directly
*****************************************************************************/
 static int32 
_lcm_lcsh_msg_rx_show_usrid(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* p_req)
{
    int32 ret = 0;
    diag_usrid_tcam_entry_req_t* reqmsg = NULL;
    diag_usrid_tcam_entry_req_t req;
    diag_usrid_tcam_entries_resp_t resp;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;

    sal_memset(&req, 0, sizeof(diag_usrid_tcam_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_usrid_tcam_entries_resp_t));  
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));  

    reqmsg = (diag_usrid_tcam_entry_req_t *)&p_req->msg;
    req.chip_id = reqmsg->chip_id;
    req.index = reqmsg->index;
    req.key_type = reqmsg->key_type;
    resp.key_type = req.key_type;

    ret = lcm_get_usrid_entry(&req,&resp);

    if ( req.index >= 0)
    {
        ret = lcm_wr_file_usrid(&resp);
        if (ret < 0)
        {
            return LCM_E_FILE;
        }
    }
    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,"OK",sizeof("OK"));
    st_lcapi_lcm_lcsh_msg.errcode= LCM_E_SUCCESS;
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_TCAM_USRID;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof("OK")+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_lcsh_msg_rx_show_usrid()  %d ",ret);
        return ret;
    }

    return LCM_E_SUCCESS;
}

/*****************************************************************************
 * Name         : _lcm_get_sram_from_table(diag_sram_entry_req_t* req, diag_sram_entry_resp_t *resp)
 * Purpose      : The function get a entry  and send them up to nsm
 * Input        : diag_sram_entry_req_t* req,request para
 * Output       : diag_sram_entry_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
static int32 
_lcm_get_sram_from_table(diag_sram_entry_req_t* req, diag_sram_entry_resp_t *resp)
{
// TODO: Commented by xgu for compile, 20121120      
    return -1;
   #if 0

    uint32 cmd = 0;
    uint32 table_size = 0;

    LCM_PTR_VALID_CHECK(req);
    LCM_PTR_VALID_CHECK(resp);

    LCM_IF_ERROR_RETURN(sys_alloc_get_table_entry_num(req->table_type,&table_size));

    if ( req->index >= table_size )
    {
        resp->chip_id = 0xff;
        resp->index = table_size;
        LCM_LOG_ERR( "The index can not be more than %d\n" , resp->index -1 );
        return LCM_E_INVALID_PARAM;
    }

    cmd = DRV_IOR( IOC_TABLE, req->table_type, DRV_ENTRY_FLAG);

    switch(req->table_type)
    {
        case DIAG_EPE_NEXT_HOP_INTERNAL4W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_nexthop_interl_4w_t));
            break;
        case DIAG_EPE_NEXT_HOP_INTERNAL8W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_nexthop_interl_8w_t));
            break;
        case DIAG_DS_DEST_PHY_PORT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_dest_phy_port_t));
            break;
        case DIAG_DS_NEXTHOP8W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_nexthop8w_t));
            break;
        case DIAG_DS_VPLS_PORT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_vpls_port_t));
            break;
        case DIAG_DS_L3_EDIT_TUNNEL_V6_IP:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_l3_edit_tunnel_v6_ip_t));
            break;
        case DIAG_DS_L3_EDIT_TUNNEL_V4_IP_SA :
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_l3_edit_tunnel_v4_ip_sa_t));
            break;
        case DIAG_DS_L3_EDIT_SEQUENCE_NUM :
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_l3_edit_sequence_num_t));
            break;
        case DIAG_DS_LINK_AGGREAGATION_GROUP:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_link_aggreagation_group_t));
            break;
        case DIAG_FWDEXTTABLE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->fwdexttable_t));
            break;
        case DIAG_APSSELECTTABLE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->apsselecttable_t));
            break;
        case DIAG_APSBRIDGETABLE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->apsbridgetable_t));
            break;
        case DIAG_DS_PHY_PORT_EXT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_phy_port_ext_t));
            break;
        case DIAG_DS_CHANNEL_SHAPE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_channel_shape));
            break;
        case DIAG_DS_QUEUE_SHAPE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_queue_shape));
            break;
        case DIAG_DS_LINK_AGGREGATION:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_link_agg));
            break;
        case DIAG_DS_LINK_AGG_MEMBER_NUM:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_linkagg_memnum));
            break;
        case DIAG_DS_SRC_INTERFACE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->src_interface));
            break;
        case DIAG_DS_DEST_INTERFACE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_dst_if));
            break;
        case DIAG_DS_CHANNEL_SHAPE_PROFILE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_csp));
            break;
        case DIAG_DS_QUEUE_SHAPE_PROFILE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_qsp));
            break;
        case DIAG_DS_QUEUE_DROP_PROFILE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_profile));
            break;
        case DIAG_DS_QUEUE_MAP:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->que_map));
            break;
        case DIAG_DS_MAC:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsmac));
            break;
        case DIAG_DS_MPLS:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->mpls));
            break;   
        case DIAG_DS_MAC_ACL:
        case DIAG_DS_IPV4_ACL:
        case DIAG_DS_MPLS_ACL:
        case DIAG_DS_IPV6_ACL:
        case DIAG_DS_MAC_QOS:
        case DIAG_DS_IPV4_QOS:
        case DIAG_DS_MPLS_QOS:
        case DIAG_DS_IPV6_QOS:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsaclqos));
            break;
        case DIAG_DS_IPV4_UCAST_DA:
        case DIAG_DS_IPV6_UCAST_DA:
        case DIAG_DS_IPV6_MCAST_DA:
        case DIAG_DS_IPV4_UCAST_PBR_DUAL_DA:
        case DIAG_DS_IPV6_UCAST_PBR_DUAL_DA:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsipda));
            break;         
        case DIAG_DS_IPV4_UCAST_SA:
        case DIAG_DS_IPV6_UCAST_SA:
        case DIAG_DS_IPV6_MCAST_RPF:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsipsa));
            break;
        case DIAG_DS_IPV4_MCAST_DA:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_ipv4_mcast_da));
            break;
        case DIAG_DS_IPV4_MCAST_RPF:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_ipv4_mcast_rpf));
            break;
        case DIAG_DS_IPV4_SA_NAT:
        case DIAG_DS_IPV6_SA_NAT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->sa_nat));	
            break;
        case DIAG_DS_USER_ID_IPV4:
        case DIAG_DS_USER_ID_IPV6:
        case DIAG_DS_USER_ID_MAC:
        case DIAG_DS_USER_ID_VLAN:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->usr_id));
            break;        
        case DIAG_DS_FWD:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsfwd));
            break;
        case DIAG_DS_NEXTHOP:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsnh));
            break;
        case DIAG_DS_MET_ENTRY:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->met));
            break;
        case DIAG_DS_L2_EDIT_LOOPBACK:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->lookback));
            break;
        case DIAG_DS_L3EDIT_FLEX:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->flex));
            break;
        case DIAG_DS_L3EDIT_TUNNEL_V4:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->tunnelv4));
            break;
        case DIAG_DS_L3EDIT_TUNNEL_V6:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->tunnelv6));
            break;
        case DIAG_DS_SRC_PORT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->src_port));
            break;
        case DIAG_DS_DEST_PORT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dest_port));
            break;
        case DIAG_DS_PHY_PORT:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->phy_port));
            break;
        case DIAG_DS_PROTOCOL_VLAN:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->protocol_vlan));
            break;
        case DIAG_DS_VLAN_STATUS:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->vlan_status));
            break;
        case DIAG_DS_MPLS_CTL:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_mpls_ctl_t));
            break;
        case DIAG_DS_POLICER:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->policer));
            break;
        case DIAG_DS_ROUTER_MAC:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->router_mac));
            break;
        case DIAG_STP_STATE_RAM:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->stp_state));
            break;
        case DIAG_DS_L2_EDIT_ETH4W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->eth4w));
            break;            
        case DIAG_DS_L2_EDIT_ETH8W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->eth8w));
            break;
        case DIAG_DS_L3EDIT_MPLS4W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->mpls4w));
            break;
        case DIAG_DS_L3EDIT_MPLS8W:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->mpls8w));
            break;
        case DIAG_DS_STORM_CTL_TABLE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsstm_ctl));
            break;

        case DIAG_IPE_AGING_RAM:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->dsaging.aging_status));
            break;
        case DIAG_DS_POLICER_PROFILE:
            LCM_IF_ERROR_RETURN(drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->policer_profile));
            break;        
        case DIAG_DS_VLAN:
            drv_tbl_ioctl(req->chip_id, req->index, cmd, &resp->ds_vlan);
            break;

         default:
            LCM_LOG_ERR("table type is not surported .\n");
            break;
    }
    
    resp->index = req->index;
    resp->chip_id= req->chip_id;
#endif

    return LCM_E_SUCCESS;
}
/*****************************************************************************
 * Name         : _lcm_lcsh_msg_rx_show_sram_tbl(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_req)
 * Purpose      : The function get a entry  and send them up to nsm
 * Input        : diag_sram_entry_req_t* req,request para
 * Output       : diag_sram_entry_resp_t* resp resp,out para
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
static int32
_lcm_lcsh_msg_rx_show_sram_tbl(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_sram_entry_req_t req;
    diag_sram_entry_resp_t resp;
    diag_sram_entry_req_t *temp = (diag_sram_entry_req_t *)p_req->msg;

    sal_memset(&st_lcapi_lcm_lcsh_msg, 0 , sizeof(lcapi_lcm_lcsh_msg_t));    
    sal_memset(&req, 0, sizeof(diag_sram_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_sram_entry_resp_t));  

    req.chip_id = temp->chip_id;
    req.index = temp->index;
    req.table_type = temp->table_type;

    resp.chip_id = temp->chip_id;
    resp.index = temp->index;
    resp.table_type = temp->table_type;
    
    _lcm_get_sram_from_table (&req, &resp);

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg, &resp, sizeof(diag_sram_entry_resp_t));

    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_GET_SRAM_TABLE_MSG;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_sram_entry_resp_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_lcsh_msg_rx_show_sram_tbl() 3 %d ",ret);
        return ret;
    }
    
    return ret;    
}

/*********************************************************************
 * Name    : lcm_msg_rx_diagChip
 * Purpose : 
 * Input   : 
 * Output  : 
 * Return  : 
 * Note    :
*********************************************************************/
int32 
lcm_msg_rx_diagChip(lcm_sess_t *p_sess, lcapi_lcm_lcsh_msg_t* req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_chip_req_t* p_req;
    
    uint32 chip;
    uint32 opcode;
    uint32 from_idx;
    uint32 to_idx;
    
    if(NULL == p_sess || NULL == req)
    {
        LCM_LOG_ERR("Invalid p_sess o req\n");
        return LCM_E_INVALID_PARAM;
    }
    
    p_req = (diag_chip_req_t* )(req->msg);        
    chip = p_req->chip_id;
    opcode = p_req->opcode;
    from_idx = p_req->fromIdx;
    to_idx = p_req->toIdx;

    sal_memset(&st_lcapi_lcm_lcsh_msg, 0, sizeof(lcapi_lcm_lcsh_msg_t));

#ifdef _GLB_UML_SYSTEM_
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_DIAG_CHIP;
    st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;
#else
        
    switch (opcode)
    {
        case DIAG_CHIP_WRITE_TCAM_ENTRY:
            ret = diag_chip_write_tcam_entry(chip, from_idx, to_idx, (uint32 *)p_req->buf1,(uint32 *)p_req->buf2);
            break;

        case DIAG_CHIP_READ_TCAM_ENTRY:
            ret = diag_chip_read_tcam_entry(chip, from_idx, to_idx);
            break;

        case DIAG_CHIP_READ_TCAM_REG:
            ret = diag_chip_read_tcam_register(chip, from_idx);
            break;  

        case DIAG_CHIP_WRITE_TCAM_REG:
            ret = diag_chip_write_tcam_register(chip, from_idx,(uint32 *)p_req->buf1);
            break;    

        case DIAG_CHIP_CAPTURE_START:
            ret = diag_chip_capture_start(chip, from_idx);
            break;          

        case DIAG_CHIP_CAPTURE_STOP:
            ret = diag_chip_capture_stop(chip, from_idx);
            break;       

		case DIAG_CHIP_BIST_START:
            ret = diag_chip_bist_start(chip, from_idx);
            break;          

        case DIAG_CHIP_BIST_STOP:
            ret = diag_chip_bist_stop(chip, from_idx);
            break;      	

        case DIAG_CHIP_SHOW_DISCARD_TYPE:
            ret = diag_chip_show_discard(chip);
            break;  

        case DIAG_CHIP_SHOW_BUS_INFO:
            ret = diag_chip_show_bus_info(chip, from_idx, to_idx);
            break;  

		case DIAG_CHIP_SHOW_INFO:
            ret = diag_chip_show_info(chip, from_idx, to_idx);
            break;     

        case DIAG_OAM_REGWALK:
            ret = diag_oam_register_walk(to_idx);
            break;      

        case DIAG_OAM_DEBUG_STATS:
            ret = diag_oam_debug_stats();
            break; 

        case DIAG_OAM_BIST_START:
            ret = diag_oam_bist_start();
            break; 

        case DIAG_OAM_BIST_STOP:
            ret = diag_oam_bist_stop();
            break; 
            
        default:
            LCM_LOG_ERR("Unsupported diag chip type \n");
        break;    
    }
   
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_DIAG_CHIP;
    if(ret)
    {
        st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
        st_lcapi_lcm_lcsh_msg.errcode = LCAPI_LCM_LCSH_ERR;
    }
    else
    {
        st_lcapi_lcm_lcsh_msg.msg_len = LCAPI_LCM_LCSH_HEAD_SIZE;
    }
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        return ret;
    }
    return ret;

#endif  /* _GLB_UML_SYSTEM_ */     
} 

/*****************************************************************************
 * Name         : _lcm_msg_rx_get_stp_status(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_req)
 * Purpose      : The function get a stp status
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
static int32
_lcm_msg_rx_get_stp_status(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_sram_get_stp_status_req_t req;
    diag_sram_get_stp_status_resp_t resp;
    
    diag_sram_get_stp_status_req_t *temp = (diag_sram_get_stp_status_req_t *)p_req->msg;

    sal_memset(&st_lcapi_lcm_lcsh_msg, 0 , sizeof(lcapi_lcm_lcsh_msg_t));    
    sal_memset(&req, 0, sizeof(diag_sram_get_stp_status_req_t));
    sal_memset(&resp, 0, sizeof(diag_sram_get_stp_status_resp_t));  

    req.chip_id = temp->chip_id;
    req.vlan_id = temp->vlan_id;
    req.table_type = temp->table_type;
    req.gport= temp->gport;
    req.port_id= temp->port_id;
    
    lcm_get_stp_status (&req, &resp);

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_sram_get_stp_status_resp_t));
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_SHOW_STP_STATUS;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_sram_get_stp_status_resp_t)+LCAPI_LCM_LCSH_HEAD_SIZE;

    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_lcsh_msg_rx_show_sram_tbl() 3 %d ",ret);
        return ret;
    }
    
    return ret;    
}
/*****************************************************************************
 * Name         : _lcm_msg_rx_show_by_dump_file(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_req)
 * Purpose      : The function call dump functions and response result to lcsh
 * Input        : 
 * Output       : 
 * Return       : SUCCESS
 *                Other = ErrCode
*****************************************************************************/
static int32
_lcm_msg_rx_show_by_dump_file(lcm_sess_t* p_sess, lcapi_lcm_lcsh_msg_t* p_req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    lcapi_show_req_t *p_show_req = NULL;
#ifdef FOAM_SUPPORT  /* Added by kcao 2011-05-13 */
// TODO: Commented by xgu for compile, 20121120     glb_card_t* p_card = lcm_mgt_get_card();
#endif

    p_show_req = (lcapi_show_req_t *)p_req->msg;
    sal_memset(&st_lcapi_lcm_lcsh_msg, 0 , sizeof(lcapi_lcm_lcsh_msg_t));
    CTCLIB_DUMP_PREPARE();
    switch (p_show_req->opcode)
    {
    // TODO: Commented by xgu for compile, 20121120 
#if 0

    case LCAPI_SHOW_HAGT_INTR:
        ret = hagt_intr_debug_dump();
        break;

    case LCAPI_SHOW_HAGT_ACL:
        ret = hagt_acl_debug_dump();
        break;
/* modified by cuixl for bug 22441, 2013-03-18 */
/* We don't do resource check before, so we need store these failed entries when resource is ok*/
/* Now we do resource check, so function is no need any more */
/*modification start*/
#if 0
    case LCAPI_SHOW_HAGT_QOS:
        ret = hagt_qos_debug_dump();
        break;
#endif
    case LCAPI_SHOW_HAGT_PDU:
        ret = hagt_pdu_debug_dump();
        break;

    case LCAPI_SHOW_HAGT_RMT:
        ret = hagt_rmt_debug_dump();
        break;

    case LCAPI_SHOW_SDK_NEXTHOP:
        ret = lcm_dump_sdk_nexthop(p_show_req);
        break;

    case LCAPI_SHOW_SDK_ALLOC:
        ret = lcm_dump_sdk_alloc(p_show_req);
        break;

    case LCAPI_SHOW_SDK_MASTER:
        ret = lcm_dump_sdk_master(p_show_req);
        break;

    case LCAPI_CHIP_ACCESS:
        ret = lcm_dump_chip(p_show_req);
        break;

#ifdef FOAM_SUPPORT  /* Added by kcao 2011-05-13 */
    case LCAPI_FOAM_ACCESS:
        if (p_card->is_foam_supported)
        {
            ret = lcm_dump_foam(p_show_req);
        }
        break;
    case LCAPI_FOAM_MEP:
        if (p_card->is_foam_supported)
        {
            ret = lcm_dump_foam_mep(p_show_req);
        }
        break;
#endif /* !FOAM_SUPPORT */

    case LCAPI_SHOW_SDK_MEM:
        ret = lcm_dump_sdk_mem(p_show_req); 
        break;

    case LCAPI_SHOW_SDK_OPF:
        ret = lcm_dump_sdk_opf(p_show_req); 
        break;

    case LCAPI_SHOW_SDK_QUEUE:
        ret = lcm_dump_sdk_queue(p_show_req); 
        break;
#endif
    default:
        break;
    }

    CTCLIB_DUMP_CLOSE_FILE();
    st_lcapi_lcm_lcsh_msg.msg_type = p_req->msg_type;
    st_lcapi_lcm_lcsh_msg.errcode = ret;
    st_lcapi_lcm_lcsh_msg.msg_len = 0 + LCAPI_LCM_LCSH_HEAD_SIZE;
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" %s opcode %d errcode %d ", __FUNCTION__, p_show_req->opcode, ret);
        return ret;
    }
    
    return ret;    
}
/*********************************************************************
 * Name    : _lcm_lcsh_msg_rx_show_reg_tbl(lcm_sess_t*p_sess, lcapi_lcm_lcsh_msg_t* p_req)
 * Purpose : 
 * Input   : 
 * Output  : 
 * Return  : 
 * Note    :
*********************************************************************/

static int32
_lcm_lcsh_msg_rx_show_reg_tbl(lcm_sess_t*p_sess, lcapi_lcm_lcsh_msg_t* p_req)
{
    int32 ret = 0;
    lcapi_lcm_lcsh_msg_t st_lcapi_lcm_lcsh_msg;
    diag_reg_entry_req_t req;
    diag_reg_entry_resp_t resp;
    diag_reg_entry_req_t *temp = (diag_reg_entry_req_t *)p_req->msg;

    sal_memset(&st_lcapi_lcm_lcsh_msg, 0 , sizeof(lcapi_lcm_lcsh_msg_t));    
    sal_memset(&req, 0, sizeof(diag_reg_entry_req_t));
    sal_memset(&resp, 0, sizeof(diag_reg_entry_resp_t));  

    req.chip_id = temp->chip_id;
    req.reg_type = temp->reg_type;
    
    lcm_get_register_table (&req, &resp);
    resp.reg_type = req.reg_type;

    sal_memcpy(st_lcapi_lcm_lcsh_msg.msg,&resp,sizeof(diag_reg_entry_resp_t));
    st_lcapi_lcm_lcsh_msg.msg_type = LCAPI_LCM_LCSH_GET_REG_TABLE_MSG;
    st_lcapi_lcm_lcsh_msg.msg_len = sizeof(diag_reg_entry_resp_t)+LCAPI_LCM_LCSH_HEAD_SIZE;
    
    if ((ret = lcm_sess_send(p_sess, &st_lcapi_lcm_lcsh_msg)) < 0)
    {
        LCM_LOG_ERR(" _lcm_lcsh_msg_rx_show_sram_tbl()  %d ",ret);
        return ret;
    }
    
    return ret;    
}
lcm_srv_cb_t lcm_lcsh_srv_cb_tbl[LCM_SRV_CB_TBL_SZ] = {
    [LCAPI_LCM_LCSH_TEST1]                      = lcm_lcsh_msg_rx_test1,
    [LCAPI_LCM_LCSH_READ_REGS]                  = lcsh_lcm_msg_rx_read_regs,    
    [LCAPI_LCM_LCSH_DUMP_L2SWITCH_STATS]        = lcsh_lcm_msg_rx_l2switch_stats,
    [LCAPI_LCM_LCSH_CLEAR_L2SWITCH_STATS]       = lcsh_lcm_msg_rx_clear_l2switch_stats,   
    [LCAPI_LCM_LCSH_WRITE_REGS]                 = lcsh_lcm_msg_rx_write_regs,
    [LCAPI_LCM_LCSH_GET_PORT_INFO]              = lcsh_lcm_msg_rx_get_port_info,
    [LCAPI_LCM_LCSH_CONFIG_PORT]                = lcsh_lcm_msg_rx_conport_regs,
    [LCAPI_LCM_LCSH_DUMP_TRANSCEIVER_INFO]      = lcm_lcsh_msg_rx_show_transceiver,
    [LCAPI_LCM_LCSH_GET_SRAM_TABLE_MSG]         = _lcm_lcsh_msg_rx_show_sram_tbl,
    [LCAPI_LCM_LCSH_GET_REG_TABLE_MSG]          = _lcm_lcsh_msg_rx_show_reg_tbl,
    [LCAPI_LCM_LCSH_SHOW_TCAM_USRID]            = _lcm_lcsh_msg_rx_show_usrid,
    [LCAPI_LCM_LCSH_SHOW_ACL_ENTRIES]           = _lcm_msg_rx_show_acl_entries,    
    [LCAPI_LCM_LCSH_SHOW_ONE_ACL_ENTRY]         = _lcm_msg_rx_show_one_acl_entry,    
    [LCAPI_LCM_LCSH_SHOW_ALL_MAC_ENTRIES]       = _lcm_msg_rx_show_l2_entries,      
    [LCAPI_LCM_LCSH_SHOW_ONE_MAC_ENTRY]         = _lcm_msg_rx_show_l2_one_entry,      
    [LCAPI_LCM_LCSH_SHOW_ONE_IPUC_ENTRY]        = _lcm_msg_rx_show_ipuc_one_entry,      
    [LCAPI_LCM_LCSH_SHOW_ALL_IPUC_ENTRIES]      = _lcm_msg_rx_show_ipuc_entries,      
    [LCAPI_LCM_LCSH_SHOW_ALL_IPV6UC_ENTRIES]    = _lcm_msg_rx_show_ipv6uc_entries,    
    [LCAPI_LCM_LCSH_SHOW_ONE_IPV6UC_ENTRY]      = _lcm_msg_rx_show_ipv6uc_one_entry,      
    [LCAPI_LCM_LCSH_SHOW_ALL_IPMC_ENTRIES]      = _lcm_msg_rx_show_ipmc_entries,    
    [LCAPI_LCM_LCSH_SHOW_ONE_IPMC_ENTRY]        = _lcm_msg_rx_show_ipmc_one_entry,    
    [LCAPI_LCM_LCSH_SHOW_ONE_IPMCV6_ENTRY]      = _lcm_msg_rx_show_ipmcv6_one_entry, 
    [LCAPI_LCM_LCSH_SHOW_ALL_IPMCV6_ENTRIES]    = _lcm_msg_rx_show_ipmcv6_entries, 
    [LCAPI_LCM_LCSH_DIAG_CHIP]                  = lcm_msg_rx_diagChip,  
    [LCAPI_LCM_LCSH_SHOW_STP_STATUS]            = _lcm_msg_rx_get_stp_status,  
    [LCAPI_LCM_LCSH_SHOW_BY_DUMP_FILE]          = _lcm_msg_rx_show_by_dump_file,
};

