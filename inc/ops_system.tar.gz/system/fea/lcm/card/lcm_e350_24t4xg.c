/****************************************************************************
* $Id$
*  E350-24T4XG board init functions
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Chenxi Qi
* Date          : 2013-04-23
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal_common.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "lcm_log.h"
#include "lcm_card.h"
#include "ctc_pci.h"
#include "ctc_spi.h"
#include "ctc_i2c.h"
#include "epld_api.h"
#include "fpga_api.h"
#include "ad9517_api.h"
#include "phy_api.h"
#include "fiber_api.h"
#include "sensor_api.h"
#include "fan_api.h"
#include "power_api.h"
#include "eeprom_api.h"
#include "led_api.h"
#include "lcm_mgt.h"
#include "ds3104_api.h"
#ifdef BOOTUP_DIAG
#include "diag_types.h"
#endif
#include "ctc_api.h"
#include "ctc_chip.h"
#include "glb_distribute_system_define.h"
#include "glb_if_define.h"
#ifndef _GLB_UML_SYSTEM_

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
#define E350_24T4XG_SENSOR_NUM                      0x01
#define E350_24T4XG_ADDR_SENSOR                     0x48

#define E350_24T4XG_ADDR_FAN                        0x2f
#define E350_24T4XG_FAN_MODULE_MAX                  0x01

#define E350_24T4XG_ADDR0_PSU                       0x50
#define E350_24T4XG_ADDR1_PSU                       0x51
#define E350_24T4XG_PSU_MODULE_MAX                  0x02

#define E350_24T4XG_EEPROM_NUM                      0x01
#define E350_24T4XG_ADDR_EEPROM                     0x57  /* boot info */

#define E350_24T4XG_I2C_BRIDGE_ADDR                 0x70

/* should be adapted per board */
#define E350_24T4XG_MIN_INTERNAL_PHY_ADDR              0
#define E350_24T4XG_LAST_INTERNAL_PHY_ADDR            11

#define E350_24T4XG_PORT_NUM_PER_PHY_CHIP             12
#define E350_24T4XG_DS3104_NUM                       0x1
#define E350_24T4XG_PHY_INT_BITS_SUM                   2

/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
static const glb_card_t* glb_card;
static int32 spi_fd = 0;

extern int32 lcm_card_init_callback(card_init_callback_t func);

//lcm_card_port_t lcm_e350_24t4xg_port[E350_24T4XG_48T_MAX_PORT+E350_24T4XG_4XG_MAX_PORT+E350_24T4XG_2QSFPP_MAX_PORT] =
lcm_card_port_t lcm_e350_24t4xg_port[GLB_E350_24T4X_24T_MAX_PORT + GLB_E350_48T4X2Q_4XG_MAX_PORT] =
{
    /* HSS 1 */
    {0,  8,  8,  0},  /* Port  1 <-> QSGMII  2 <-> GMAC  8 */
    {0,  9,  9,  1},  /* Port  2 <-> QSGMII  2 <-> GMAC  9 */
    {0, 10, 10,  2},  /* Port  3 <-> QSGMII  2 <-> GMAC 10 */
    {0, 11, 11,  3},  /* Port  4 <-> QSGMII  2 <-> GMAC 11 */
    {0, 32, 32,  4},  /* Port  5 <-> QSGMII  8 <-> GMAC 32 */
    {0, 33, 33,  5},  /* Port  6 <-> QSGMII  8 <-> GMAC 33 */
    {0, 34, 34,  6},  /* Port  7 <-> QSGMII  8 <-> GMAC 34 */
    {0, 35, 35,  7},  /* Port  8 <-> QSGMII  8 <-> GMAC 35 */
    {0, 12, 12,  8},  /* Port  9 <-> QSGMII  3 <-> GMAC 12 */
    {0, 13, 13,  9},  /* Port 10 <-> QSGMII  3 <-> GMAC 13 */
    {0, 14, 14, 10},  /* Port 11 <-> QSGMII  3 <-> GMAC 14 */
    {0, 15, 15, 11},  /* Port 12 <-> QSGMII  3 <-> GMAC 15 */

    /* HSS 2 */
    {0, 36, 36, 12},  /* Port 13 <-> QSGMII  9 <-> GMAC 36 */
    {0, 37, 37, 13},  /* Port 14 <-> QSGMII  9 <-> GMAC 37 */
    {0, 38, 38, 14},  /* Port 15 <-> QSGMII  9 <-> GMAC 38 */
    {0, 39, 39, 15},  /* Port 16 <-> QSGMII  9 <-> GMAC 39 */
    {0, 16, 16, 16},  /* Port 17 <-> QSGMII  4 <-> GMAC 16 */
    {0, 17, 17, 17},  /* Port 18 <-> QSGMII  4 <-> GMAC 17 */
    {0, 18, 18, 18},  /* Port 19 <-> QSGMII  4 <-> GMAC 18 */
    {0, 19, 19, 19},  /* Port 20 <-> QSGMII  4 <-> GMAC 19 */
    {0, 40, 40, 20},  /* Port 21 <-> QSGMII 10 <-> GMAC 40 */
    {0, 41, 41, 21},  /* Port 22 <-> QSGMII 10 <-> GMAC 41 */
    {0, 42, 42, 22},  /* Port 23 <-> QSGMII 10 <-> GMAC 42 */
    {0, 43, 43, 23},  /* Port 24 <-> QSGMII 10 <-> GMAC 43 */
    
     /*added by liuht to  support 48+4,2013-08-29*/
#if 1
    /* HSS 0 */
    {0, 48, 48, },    /* Port 49 <-> XFI  8 <->  SGMAC  48 */
    {0, 50, 50, },    /* Port 50 <-> XFI 10 <->  SGMAC 50 */
    {0, 49, 49, },    /* Port 51 <-> XFI  9 <->  SGMAC  49 */
    {0, 51, 51, },    /* Port 52 <-> XFI 11 <->  SGMAC 51 */
#endif
};

glb_port_range_t lcm_e350_24t4xg_phy_chip_port_range[E350_24T4XG_PHY_INT_BITS_SUM] =
{
    { 1, 12},
    {13, 24},
};

//fiber_port_info_t lcm_e350_24t4xg_fiber[E350_24T4XG_48T_MAX_PORT+E350_24T4XG_4XG_MAX_PORT+E350_24T4XG_2QSFPP_MAX_PORT] =
fiber_port_info_t lcm_e350_24t4xg_fiber[GLB_E350_24T4X_24T_MAX_PORT + GLB_E350_48T4X2Q_4XG_MAX_PORT] =
{
    /* 48T */
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
     /*added by liuht to  support 48+4,2013-08-29*/
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 0,  0, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 1,  1, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 2,  2, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 3,  3, 0},
#if 0
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 4,  4, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 5,  5, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 6,  6, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 7,  7, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 8,  8, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 9,  9, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 10, 10, },
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 11, 11, },
#endif
};
uint8 lcm_e350_24t4xg_mac_led[]={59,57,58,56};
static uint8 g_slot_id = 0;

/* Modify by liuht to configure XFI, 2013-11-21 */
uint8 
lcm_e350_24t4xg_serdes_trace_len[][2]=
{{8,1},{9,1},{12,1},
 {13,1}, {16,1},{17,1},
 {21,1},{22,1}, {23,1},
 {18,0},{19,0},{20,0},
 {0,0},{1,0},{4,0},
 {5,0}};

/****************************************************************************
 *
* Function
*
****************************************************************************/
static int32
_lcm_init_e350_24t4xg_cpu_info()
{
    FILE * fp;

    fp = sal_fopen(GLB_CPU_IF_INFO_FILE, "w+");
    if(fp ==NULL)
    {
        LCM_LOG_ERR("Open cpu info file error.");
        return LCM_E_FILE_OPEN;
    }
    sal_fprintf(fp, "MGMT_IF eth0\n");
    sal_fprintf(fp, "CPU_IF NOTUSE\n");
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_port(glb_card_t* p_card)
{
    int32 port_id;

    /* alloc ports */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port begin.");

    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }

        p_card->pp_port[port_id]->p_fiber = NULL;
        p_card->pp_port[port_id]->is_combo = 0;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = 1;
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
        /*Fix bug 14686. jqiu 2011-06-15*/
        p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_id+1;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 0;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_cfg.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        p_card->pp_port[port_id]->port_status.link_up = GLB_LINK_DOWN;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_status.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_status.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->poe_support = NOT_POE_PORT;

        p_card->pp_port[port_id]->logic_port_idx = lcm_e350_24t4xg_port[port_id].logic_port_idx;
        p_card->pp_port[port_id]->local_chip_idx = lcm_e350_24t4xg_port[port_id].chip_idx;
        p_card->pp_port[port_id]->mac_idx = lcm_e350_24t4xg_port[port_id].mac_idx;
        p_card->pp_port[port_id]->port_led_mode_change = GLB_PORT_LED_MODE_CHANGE_UNSUPPORT;
        /* Modified by liuht for bug26853, 2013-01-20 */
        /* global port id */
        p_card->pp_port[port_id]->g_port_index = (p_card->pp_port[port_id]->glb_chip_idx << 8) | (p_card->pp_port[port_id]->logic_port_idx);
        if (port_id < GLB_E350_24T4X_24T_MAX_PORT)  /* 24T */
        {
            p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
            p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
            p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
            p_card->pp_port[port_id]->lp_support = 1;
            p_card->pp_port[port_id]->eee_support = 1;    /* support eee function for bug 28298, 2014-04-21 */
        }
        else
        {
            p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_FIBER;
            p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_UNKNOWN;
			/* E350 24T4XG supports 10G/1G dynamic switch. */
            p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_10G | GLB_SUPPORT_SPEED_1G;
            p_card->pp_port[port_id]->lp_support = 0;
            p_card->pp_port[port_id]->eee_support = 0;    /* support eee function for bug 28298, 2014-04-21 */
        }
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port end.");

    return LCM_E_SUCCESS;
}

static int32_t
_lcm_reg_e350_24t4xg_epld(uint8 hw_ver, epld_info_t * p_epld_info)
{
    p_epld_info->base_addr = epld_localbus_addr_get();
    p_epld_info->epld_bus_type = EPLD_LOCALBUS_TYPE;

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_EPLD_VERSION]),          0x1, 0, 7, 8);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SYS_LED_SYS]),           0x2, 4, 7, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU1_LED]),              0x2, 2, 3, 2); /* master power */
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU2_LED]),              0x2, 0, 1, 2); /* slave power */
    /* Added by liuht for bug 25341, 2013-12-19 */	
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_LED]),              0x3, 2, 3, 2);	

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_PCIE_RST]),           0x4, 2, 2, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_POR_RST]),            0x4, 1, 1, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_HARD_RST]),           0x4, 0, 0, 1);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PHY_RST]),               0x5, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_CPUPHY_RST]),            0x5, 4, 4, 1);

    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_LED_RST]),           0x6, 0, 0, 1);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PHY_INT_MASK]),          0x9, 0, 3, 4);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_PRESENT1]),          0xb, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_DISABLE1]),          0xd, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_LOS1]),              0xe, 0, 3, 4);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_PRESENT_STATUS]),    0xf, 4, 5, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_WORK_STATUS]),       0xf, 6, 7, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_ALERT_STATUS]),      0xf, 2, 3, 2);
    /* Added by qicx for V350 XG MAC LED, bug24348, 2013-08-13 */
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SERIAL_LED_RST]),        0x6, 0, 0, 1);	

    /* Added by liuht for bug27036, 2014-02-21 */
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_POWER_RST]),               0xf6, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_MANUAL_OTHER_RST]),  0xf7, 0, 7, 8);	

#ifdef BOOTUP_DIAG
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_TEST]),                 0x7f, 0, 7, 8);
#endif
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_epld(glb_card_t* p_card, uint8 epld_version)
{
    epld_info_t *p_epld_info = NULL;
    int32 ret = 0;

    p_epld_info = epld_get_info(&p_card->board_type, epld_version);
    if (!p_epld_info)
    {
        LCM_LOG_ERR("Get EPLD info fail.");
        return LCM_E_INVALID_PTR;
    }

    _lcm_reg_e350_24t4xg_epld(p_card->hw_ver, p_epld_info);
    ret = epld_init(p_epld_info);
    if (0 != ret)
    {
        LCM_LOG_ERR("EPLD Init fail.");
        return LCM_E_INIT_FAILED;
    }

    /* Added by liuht for bug27036, 2014-02-21 */
    if(epld_version >= 0x20)
    {
        p_card->support_reboot_info = 1;
    }
    else
    {
        p_card->support_reboot_info = 0;
    }	

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init epld end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_e350_24t4xg_eeprom_info(glb_card_t* p_card)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom info begin.");

    p_card->p_eeprom_alloc = (eeprom_info_t *)XCALLOC(MTYPE_BUFFER_DATA, sizeof(eeprom_info_t)*EEPROM_MAX);
    if(NULL == p_card->p_eeprom_alloc)
    {
        LCM_LOG_ERR("alloc p_eeprom_alloc array fail.");
        return LCM_E_INVALID_PTR;
    }
    p_card->p_eeprom_alloc[EEPROM_SERIAL_PARAM].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SERIAL_PARAM].base_addr = 0x1050;
    p_card->p_eeprom_alloc[EEPROM_BOOTVER].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTVER].base_addr = 0x1110;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].base_addr = 0x1300;
    p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].base_addr = 0x1900;
#ifdef BOOTUP_DIAG
    p_card->p_eeprom_alloc[EEPROM_BOOTUP_DIAG_LEVEL].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTUP_DIAG_LEVEL].base_addr = 0x1921;
#endif
    p_card->p_eeprom_alloc[EEPROM_SERIALNO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SERIALNO].base_addr = 0x1220;
    p_card->p_eeprom_alloc[EEPROM_SYS_MAC].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SYS_MAC].base_addr = 0x1240;
    p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].base_addr = 0x1260;
    p_card->p_eeprom_alloc[EEPROM_BR_PROFILE].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BR_PROFILE].base_addr = 0x1280;

    p_card->p_eeprom_alloc[EEPROM_BOOTCMD].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTCMD].base_addr = 0x0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].base_addr = 0x1300;
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    p_card->p_eeprom_alloc[EEPROM_SMARTCFG].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SMARTCFG].base_addr = 0x1265;
#endif /* !HAVE_SMARTCFG */
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_fiber(void)
{
    int32 ret = 0;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber begin.");

    /* Release reset for GreatBelt mac led signal, before fiber init */
    /*modified by liuht to  support 48+4,2013-08-29*/
    ret = fiber_init(GLB_E350_48T4X2Q_4XG_MAX_PORT, /* fiber num */
                 GLB_E350_48T4X2Q_4XG_MAX_PORT+GLB_E350_24T4X_24T_MAX_PORT, /* port num */
                 lcm_e350_24t4xg_fiber);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber end.");

    return ret;
}

static int32
_lcm_init_e350_24t4xg_sensor(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[E350_24T4XG_SENSOR_NUM];
    sensor_chip_t sensor_chip[E350_24T4XG_SENSOR_NUM];
    void *p_data[E350_24T4XG_SENSOR_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = E350_24T4XG_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 7;
    i2c_gen[0].addr = E350_24T4XG_ADDR_SENSOR;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[0].io_type = SENSOR_I2C;
    i2c_gen[0].alen = LM75_OFFSET_WIDTH;
    sensor_chip[0].chip_type = SENSOR_LM75;

    for(i=0; i<E350_24T4XG_SENSOR_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = sensor_init(p_data, sensor_chip, E350_24T4XG_SENSOR_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Temperature sensor init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(i=0; i<E350_24T4XG_SENSOR_NUM; i++)
    {
        sensor_dev_init(i);
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_fan(void)
{
    int32 ret = 0;
    uint8 fan_module_idx;
    i2c_gen_t i2c_gen[E350_24T4XG_FAN_MODULE_MAX];
    fan_chip_t fan_chip[E350_24T4XG_FAN_MODULE_MAX];
    void *p_data[E350_24T4XG_FAN_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = E350_24T4XG_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 0;
    i2c_gen[0].addr = E350_24T4XG_ADDR_FAN;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = ADT7470_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    fan_chip[0].chip_type = FAN_ADT7470;
    fan_chip[0].io_type = E_FAN_I2C;
    fan_chip[0].support_hot_swap = 0;  /* stable on GB mother board, do not support hot swap */
    p_data[0] = &i2c_gen[0];
    fan_chip[0].fan_num = 3;
    fan_chip[0].speed_adjust = 1;
    fan_chip[0].rpm = 13000;   /*Revolutions per minites, bug29436, qicx, 2014-08-08*/

    ret = fan_init(p_data, fan_chip, E350_24T4XG_FAN_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Fan driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(fan_module_idx=0; fan_module_idx<E350_24T4XG_FAN_MODULE_MAX; fan_module_idx++)
    {
        fan_dev_init(fan_module_idx);
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_psu(void)
{
    int32 ret;
    /* modified by liuht for bug 24525,2013-10-24 */
    #if 0
    uint8 psu_module_idx;
    #endif
    uint8 epld_idx[E350_24T4XG_PSU_MODULE_MAX];
    i2c_gen_t i2c_gen[E350_24T4XG_PSU_MODULE_MAX];
    psu_chip_t psu_chip[E350_24T4XG_PSU_MODULE_MAX];
    #if 0
    void *p_data[E350_24T4XG_PSU_MODULE_MAX];
    #endif
    psu_private_t p_data[E350_24T4XG_PSU_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init psu module begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    epld_idx[0] = 0;
    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = E350_24T4XG_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 6;
    i2c_gen[0].addr = E350_24T4XG_ADDR0_PSU;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[0].chip_type = PSU_I2C_EPLD;
    psu_chip[0].io_type = PSU_IO_I2C_EPLD;
    psu_chip[0].psu_type = PSU_SHOW_FULL_STATUS;
    psu_chip[0].psu_mode_type = 1<<PSU_MODE_TYPE_REG_50_01_04;
    p_data[0].p_data_i2c= &i2c_gen[0];
    p_data[0].p_data_epld= &epld_idx[0];

    epld_idx[1] = 0;
    i2c_gen[1].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[1].p_br.bridge_addr = E350_24T4XG_I2C_BRIDGE_ADDR;
    i2c_gen[1].p_br.channel = 6;
    i2c_gen[1].addr = E350_24T4XG_ADDR1_PSU;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[1].bridge_flag = 1;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[1].chip_type = PSU_I2C_EPLD;
    psu_chip[1].io_type = PSU_IO_I2C_EPLD;
    psu_chip[1].psu_type = PSU_SHOW_FULL_STATUS;
    psu_chip[1].psu_mode_type = 1<<PSU_MODE_TYPE_REG_51_01_04;
    p_data[1].p_data_i2c= &i2c_gen[1];
    p_data[1].p_data_epld= &epld_idx[1];

#if 0
    for(psu_module_idx=0; psu_module_idx<E350_24T4XG_PSU_MODULE_MAX; psu_module_idx++)
    {
        epld_idx[psu_module_idx] = 0;
        psu_chip[psu_module_idx].chip_type = PSU_EPLD;
        psu_chip[psu_module_idx].io_type = PSU_IO_EPLD;
        psu_chip[psu_module_idx].psu_type = PSU_SHOW_FULL_STATUS;
        p_data[psu_module_idx] = &epld_idx[psu_module_idx];
    }
#endif
    ret = psu_init(p_data, psu_chip, E350_24T4XG_PSU_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Psu driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_eeprom(void)
{
    int32 ret = 0;
    i2c_gen_t i2c_gen[E350_24T4XG_EEPROM_NUM];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = E350_24T4XG_ADDR_EEPROM;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = EEPROM_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;

    ret = eeprom_init(i2c_gen, E350_24T4XG_EEPROM_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm EEPROM init fail.");
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_phy(void)
{
    uint16 port_id;
    phy_info_t phyinfo;
    phy_handle_t** pphdl = NULL;
    uint32 eee_enable = 1;
    int32 ret;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy begin.");
    /* release GE phy */
    epld_item_write(0, EPLD_PHY_RST, 0xf);

    sal_delay(5);
    sal_memset(&phyinfo, 0, sizeof(phy_info_t));
    pphdl = (phy_handle_t**)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE,
        sizeof(phy_handle_t*)*(glb_card->port_num));

    if(NULL == pphdl)
    {
        LCM_LOG_ERR("LCM phy no memory.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < (glb_card->port_num); port_id++)
    {
        if(port_id < GLB_E350_24T4X_24T_MAX_PORT) /* 48G with PHYs */
        {
            phyinfo.phy_device_type = PORT_PHY_VSC8512;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_RJ45;
            phyinfo.phy_manage_info.mac_if = GLB_MAC_INTERFACE_QSGMII;
            phyinfo.phy_manage_info.trace_length = 15;
            phyinfo.vct_support = 1;
            phyinfo.port.phy_addr = lcm_e350_24t4xg_port[port_id].phy_addr;
            phyinfo.mdio_bus = ASIC_GB_PHY_1G_TYPE;
            if (port_id < 24)
            {
                phyinfo.base_addr = 0;
            }
            else
            {
                phyinfo.base_addr = 1;
            }
            phyinfo.phy_manage_info.speed = GLB_SPEED_AUTO;
            phyinfo.phy_manage_info.duplex = GLB_DUPLEX_AUTO;

            /* start on the minimum internal phy addr of each phy chip */
            if (E350_24T4XG_MIN_INTERNAL_PHY_ADDR == (port_id % E350_24T4XG_PORT_NUM_PER_PHY_CHIP))
            {
                phyinfo.phy_manage_info.phy_init_seq_flag = GLB_PRE_INIT_FLAG;
            }  /* end on the last internal phy addr of each phy chip */
            else if (E350_24T4XG_LAST_INTERNAL_PHY_ADDR == (port_id % E350_24T4XG_PORT_NUM_PER_PHY_CHIP))
            {
                phyinfo.phy_manage_info.phy_init_seq_flag = GLB_POST_INIT_FLAG;
            }
            else
            {
                phyinfo.phy_manage_info.phy_init_seq_flag = GLB_NO_INIT_FLAG;
            }
        }
        else  /* 12XG without PHYs */
        {
            phyinfo.phy_device_type = PORT_PHY_NULL;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_SFP_PLUS;
            phyinfo.phy_manage_info.mac_if = GLB_MAC_INTERFACE_SERDES;
            phyinfo.phy_manage_info.speed = GLB_SPEED_10G;
            phyinfo.phy_manage_info.duplex = GLB_DUPLEX_FULL;
            if (lcm_mgt_is_enable_stack())
            {
                phyinfo.port.port_info.port_id = GLB_TRANS_PORTID_TO_GPORT(
                    lcm_mgt_get_stack_member(), lcm_e350_24t4xg_port[port_id].mac_idx);
            }
            else
            {
                phyinfo.port.port_info.port_id = lcm_e350_24t4xg_port[port_id].mac_idx;
            }
        }
        phyinfo.port.port_info.lchip = glb_card->pp_port[port_id]->local_chip_idx;
        phyinfo.port.port_info.serdes_id = glb_card->pp_port[port_id]->chip_serdes_id;
        /* Modified by liuht for access port id in phy handle for bug 25808 */
        phyinfo.port_num = port_id;
        phyinfo.led_type = GLB_PHY_LED_DEFAULT;



        /*********************************************************************
         * Default:
         * PHY_WORK_MODE_NORMAL GLB_LB_NONE GLB_SPEED_AUTO
         * GLB_DUPLEX_AUTO
         ********************************************************************/
        phyinfo.phy_manage_info.mode = PHY_WORK_MODE_NORMAL;
        phyinfo.phy_manage_info.lb_mode = GLB_LB_NONE;
        phyinfo.phy_manage_info.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl.recv= GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl_ability.asymmetric_pause = 0;
        phyinfo.phy_manage_info.flowctrl_ability.symmetric_pause = 0;

        phyinfo.phy_stat_flag.duplex = phyinfo.phy_manage_info.duplex;
        phyinfo.phy_stat_flag.speed = phyinfo.phy_manage_info.speed;
        phyinfo.phy_stat_flag.link_up = GLB_LINK_DOWN;
        phyinfo.phy_stat_flag.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_stat_flag.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        pphdl[port_id] = phy_dev_register(&phyinfo);
        if(NULL ==  pphdl[port_id])
        {
            LCM_LOG_ERR("Register phy handle failed\n");
            return LCM_E_INIT_FAILED;
        }
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm ready to init phy.");
    ret = phy_init(pphdl, (glb_card->port_num));
    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }
    for(port_id = 0; port_id < GLB_E350_24T4X_24T_MAX_PORT; port_id++)
    {
        /* configure 10M mode LED works the same as 100M mode, liuht, 2013-10-22 */
        gephy_reg_write(port_id, 0x1d, 0x8061);
    }

    ctc_chip_set_property(0, CTC_CHIP_PROP_EEE_EN, &eee_enable);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_reset_device(void)
{
    /* make sure the states of every device before init is reset */

    /* reset ad9517 */
    /*epld_item_write(0, EPLD_AD9517_RST, 0x0);*//*Modified by zhujian, checkIn by xgu 2010-12-14*/
    /* reset I2C bridge */
    //epld_item_write(0, EPLD_I2C_BRIDGE_RST, 0x0);
    /* reset GE phy */
    epld_item_write(0, EPLD_PHY_RST, 0x0);
    /* reset XG phy */
    //epld_item_write(0, EPLD_XGPHY_RST, 0x0);

    sal_task_sleep(100);

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_clk_gen(void)
{
    spi_gen_t spi_gen[E350_24T4XG_DS3104_NUM];
    int32 ret;
    int32 i;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init ds3104 begin.");

    spi_gen[0].spi_type = E_SPI_CPU;
    spi_gen[0].spi_info.spi_cpu_info.fd = spi_fd;
    spi_gen[0].spi_info.spi_cpu_info.chip_sel = SPI_CPU_CHIP_SEL_0;

    ret = ds3104_init(spi_gen, E350_24T4XG_DS3104_NUM);
    if ( ret < 0 )
    {
        LCM_LOG_ERR("Init ds3104 failed.");
        return LCM_E_HW_CLKGEN_GEN;
    }

    for (i = 0; i < E350_24T4XG_DS3104_NUM; i++)
    {
        ret  = ds3104_write(i, 0X0020, 0XC1);
        ret += ds3104_write(i, 0X0021, 0XC1);
        ret += ds3104_write(i, 0X0022, 0XC1);
        ret += ds3104_write(i, 0X0023, 0XC1);
        ret += ds3104_write(i, 0X0027, 0XC1);
        ret += ds3104_write(i, 0X0028, 0XC1);
        ret += ds3104_write(i, 0X004B, 0X00);
        ret += ds3104_write(i, 0X0018, 0X21);
        ret += ds3104_write(i, 0X0019, 0X43);
        ret += ds3104_write(i, 0X001A, 0X00);
        ret += ds3104_write(i, 0X001B, 0X50);
        ret += ds3104_write(i, 0X001C, 0X06);
        ret += ds3104_write(i, 0X004B, 0X10);
        ret += ds3104_write(i, 0X0018, 0X00);
        ret += ds3104_write(i, 0X0019, 0X00);
        ret += ds3104_write(i, 0X001A, 0X00);
        ret += ds3104_write(i, 0X001B, 0X00);
        ret += ds3104_write(i, 0X001C, 0X00);
        ret += ds3104_write(i, 0X004B, 0X00);
        ret += ds3104_write(i, 0X0065, 0X4A);
        ret += ds3104_write(i, 0X004F, 0X01);
        ret += ds3104_write(i, 0X0060, 0X04);
        ret += ds3104_write(i, 0X0061, 0X00);
        ret += ds3104_write(i, 0X0062, 0X00);
        ret += ds3104_write(i, 0X0063, 0X00);
        ret += ds3104_write(i, 0X0041, 0x99);
        ret += ds3104_write(i, 0X0042, 0x00);
        ret += ds3104_write(i, 0X0069, 0X0E);
        ret += ds3104_write(i, 0X0073, 0X22);
        ret += ds3104_write(i, 0X0074, 0XE5);
        if (ret)
        {
            LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Init ds3104 failed when configuring.\n");
            return LCM_E_INIT_FAILED;
        }
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm int ds3104 end.");

    return LCM_E_SUCCESS;
}


static int32
_lcm_init_e350_24t4xg_i2c(void)
{
    int32 ret;

    epld_item_write(0, EPLD_I2C_BRIDGE_RST, 0x1);
    sal_task_sleep(100);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus begin.");

    ret = i2c_open(E_I2C_CPM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init i2c bus failed.");
        return LCM_E_HW_CLKGEN_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_24t4xg_led(void)
{
    int32 ret = 0;
    led_info_t led_info[E_MAX_LED];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED begin.");
    sal_memset(led_info, 0, sizeof(led_info_t)*E_MAX_LED);
    /* On e330 board, the sys led and alarm led is the same led and
       the led has three colors. */
    /* init sys led */
    led_info[E_SYS_LED].exist = 0;
	/* Merge from openflow by liuht for bug 26911, 2014-03-27 */
#if 0	
    led_info[E_SYS_LED].led_para[E_LED_SYS_INIT].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_INIT].val = 0x9;	
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].val = 0x7;
#endif	
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].val = 0x7;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].val = 0xb;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].val = 0x7;
    /* End of Merge */	
    led_info[E_FAN_LED].exist = 1;
    led_info[E_FAN_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    led_info[E_PSU1_LED].exist = 1;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    led_info[E_PSU2_LED].exist = 1;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_PSU2_LED;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_PSU2_LED;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_PSU2_LED;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    ret = led_init(led_info);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init LEDs failed.");
        return LCM_E_HW_LED_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED end.");

    return LCM_E_SUCCESS;
}
/* Added by qicx for E350 XG MAC LED, bug24348, 2013-08-13 */
static int32
_lcm_init_e350_24t4xg_ctc_chip_led(void)
{
    mac_led_api_para_t port_led[32];
    uint8 port_num, port;
    int32 ret;
    
    /*release serial LED reset*/
    epld_item_write(0, EPLD_SERIAL_LED_RST, 0x1);

    port_num = GLB_E350_48T4X2Q_4XG_MAX_PORT; /* only the last 4 ports are controlled by GB*/
    for(port=0; port<port_num; port++)
    {
        port_led[port].port_id = lcm_e350_24t4xg_mac_led[port] \
                                     | (glb_card->pp_port[port+GLB_E350_24T4X_24T_MAX_PORT]->glb_chip_idx << 8);
        port_led[port].lchip   = lcm_e350_24t4xg_port[port+GLB_E350_24T4X_24T_MAX_PORT].chip_idx;
        port_led[port].mode    = LED_MODE_2_RXLNKBIACT_OFF;
    }

    ret = mac_led_init(port_led, port_num);
    if (ret < 0)
    {
        LCM_LOG_ERR("Init CTC Chip LEDs failed.");
        return LCM_E_HW_LED_GEN;
    }
    return LCM_E_SUCCESS;
}

int32
lcm_init_e350_24t4xg_serdes(void)
{
    ctc_chip_serdes_ffe_t serdes_ffe;
    uint8 serdes_id, index;

    serdes_ffe.board_material = 0;
    /* Modify by liuht to configure XFI, 2013-11-21 */
    for(index=0; index<16; index++)
    {
        serdes_id = lcm_e350_24t4xg_serdes_trace_len[index][0];
        serdes_ffe.serdes_id = serdes_id;
        serdes_ffe.trace_len = lcm_e350_24t4xg_serdes_trace_len[index][1];
        ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
    }
    return LCM_E_SUCCESS;
}

#ifdef BOOTUP_DIAG
/* Added by liuht to support bootup diag for bug24982, 2013-12-21 */
static int32
_lcm_init_e350_24t4xg_bootup_diag(glb_card_t* p_card)
{
    /* get bootup diagnostic level */
    char buf[1024];
    FILE *fp;
   
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init e350 24t4xg bootup diag begin.");
 
    fp = sal_fopen(GLB_STARTUP_CONFIG_FILE_PATH, "r");
    if(NULL == fp)
    {
        p_card->bootup_diag_level = E_DIAG_LEVEL_NO;
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init e350 24t4xg bootup diag end.");
        return LCM_E_SUCCESS;
    }

    /* Added by liuht for bug26642, 2013-01-20 */
    p_card->bootup_diag_level = E_DIAG_LEVEL_NO;
    while(sal_fgets(buf, 1024, fp))
    {
        if(NULL != sal_strstr(buf, "diagnostic bootup level"))
        {
            if(NULL != sal_strstr(buf, "complete"))
            {
                 p_card->bootup_diag_level = E_DIAG_LEVEL_COMPLETE;
            }
            else if(NULL != sal_strstr(buf, "minimal"))
            {
                p_card->bootup_diag_level = E_DIAG_LEVEL_MINIMAL;
            }
            else
            {
                p_card->bootup_diag_level = E_DIAG_LEVEL_NO;
            }
            break;
        }
    }
    sal_fclose(fp);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init e330 48s bootup diag end.");

    return LCM_E_SUCCESS;

}
#endif  

int32
lcm_init_e350_24t4xg_cb(void)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback begin.");
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_fiber());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_phy());
    /* Added by qicx for E350 XG MAC LED, bug24348, 2013-08-13 */
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_ctc_chip_led());
    LCM_IF_ERROR_RETURN(lcm_init_e350_24t4xg_serdes());
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback end.");

    return LCM_E_SUCCESS;
}

int32
lcm_init_e350_24t4xg(glb_card_t* p_card)
{
    FILE *fp;
    char buf[BUFSIZ];
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board begin.");
    glb_card = p_card;
    p_card->asic_chip_num = 1;
    
    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        fgets (buf, BUFSIZ, fp);
        p_card->logic_slot_no = atoi(buf);
        p_card->phy_slot_no = p_card->logic_slot_no;
        sal_fclose(fp);
    }
    else
    {
        p_card->logic_slot_no = 1;
        p_card->phy_slot_no = 0;
    }
    /* modified by liuht for bug 27331, 2014-04-22 */
    g_slot_id = p_card->phy_slot_no;
    /* end of liuht modified */
    p_card->l2switch_num = 0;
    p_card->sensor_num = E350_24T4XG_SENSOR_NUM;
    p_card->fan_module_num = E350_24T4XG_FAN_MODULE_MAX;
    p_card->psu_module_num = E350_24T4XG_PSU_MODULE_MAX;
    p_card->phy_interrupt_mode = GLB_PHY_INTERRUPT_MODE_EPLD;   /*get phy interrupt info from EPLD*/
    p_card->cpu_type = GLB_CPU_PPC_P1010;
    p_card->phy_chip_num = 2;   /* 4 VSC8512 PHYs */
    p_card->phy_int_bit_num = E350_24T4XG_PHY_INT_BITS_SUM;
    //p_card->port_num = E350_24T4XG_48T_MAX_PORT + E350_24T4XG_4XG_MAX_PORT + E350_24T4XG_2QSFPP_MAX_PORT;
    /*modified by liuht to  support 48+4,2013-08-29*/
    p_card->port_num = GLB_E350_24T4X_24T_MAX_PORT + GLB_E350_48T4X2Q_4XG_MAX_PORT;
    p_card->p_port_range = lcm_e350_24t4xg_phy_chip_port_range;

    /* for some board like e350 8t12xg don't support ptp, added by jcao for bug 25500, 2013-10-25 */
    p_card->ptp_en = 1;
    p_card->epld_type = GLB_EPLD_TYPE_JAM;
    p_card->bootrom_type = E_BOOTROM_TYPE_4M;

    /* E350-24T4X still use E350-48T4X datapath, 2013-11-18 */
    sal_snprintf(p_card->cfg_profile_name, DATAPATH_LEN_MAX, "%s%s",
        DATAPATH_PROFILE_PATH, E350_48T4XG_DATAPATH_NAME);
    _lcm_init_e350_24t4xg_cpu_info();
    ctc_hw_fd_init();
    /* Modified by liuht for bug 27657, 2014-03-25 */
    ctc_power_fd_init();
    /* Added by liuht for bug 27412, 2014-03-27 */
    ctc_sys_led_fd_init();

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,
                  "card product type %x, board type %x.", p_card->board_type.series, p_card->board_type.type);

    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_epld(p_card, p_card->epld_ver));
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_eeprom_info(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_led());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_reset_device());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_clk_gen());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_i2c());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_eeprom());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_port(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_sensor());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_fan());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_psu());
    /* Enable 4XG TX */
    LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_SFP_DISABLE1, 0x0));
#ifdef BOOTUP_DIAG
    LCM_IF_ERROR_RETURN(_lcm_init_e350_24t4xg_bootup_diag(p_card));
#endif
    lcm_card_init_callback(lcm_init_e350_24t4xg_cb);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board end.");

    return LCM_E_SUCCESS;
}
#endif
