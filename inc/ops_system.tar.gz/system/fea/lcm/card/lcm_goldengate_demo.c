/****************************************************************************
* $Id$
*  E580-24Q board init functions
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Liuht
* Date          : 2015-01-27
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal_common.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "lcm_log.h"
#include "lcm_card.h"
#include "ctc_pci.h"
#include "ctc_spi.h"
#include "ctc_i2c.h"
#include "epld_api.h"
#include "fpga_api.h"
#include "ad9517_api.h"
#include "phy_api.h"
#include "fiber_api.h"
#include "sensor_api.h"
#include "gpio_api.h"
#include "mux_api.h"
#include "fan_api.h"
#include "power_api.h"
#include "eeprom_api.h"
#include "led_api.h"
#include "lcm_mgt.h"
#include "ds3104_api.h"
#ifdef BOOTUP_DIAG
#include "diag_types.h"
#endif
#include "ctc_api.h"
#include "ctc_chip.h"
#include "glb_distribute_system_define.h"
#include "glb_if_define.h"
#include "ad9559_api.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
#define GOLDENGATE_DEMO_SENSOR_NUM                      0x04
#define GOLDENGATE_DEMO_ADDR_SENSOR1                    0x48
#define GOLDENGATE_DEMO_ADDR_SENSOR2                    0x4b
#define GOLDENGATE_DEMO_ADDR_SENSOR3                    0x49
#define GOLDENGATE_DEMO_ADDR_SENSOR4                    0x4a

#define GOLDENGATE_DEMO_GPIO_CHIP_NUM                   0x04
#define GOLDENGATE_DEMO_GPIO_CHIP1_ADDR                 0x21
#define GOLDENGATE_DEMO_GPIO_CHIP2_ADDR                 0x22
#define GOLDENGATE_DEMO_GPIO_CHIP3_ADDR                 0x23
#define GOLDENGATE_DEMO_GPIO_CHIP4_ADDR                 0x24

#define GOLDENGATE_DEMO_MUX_CHIP_NUM                   0x02
#define GOLDENGATE_DEMO_MUX_CHIP1_ADDR                 0x1
#define GOLDENGATE_DEMO_MUX_CHIP2_ADDR                 0x2
#define GOLDENGATE_DEMO_MUX_PORT_NUM                   3
#define GOLDENGATE_DEMO_MUX_LAN_NUM                    4

#define GOLDENGATE_DEMO_ADDR_FAN                        0x2f
#define GOLDENGATE_DEMO_FAN_MODULE_MAX                  0x1

#define GOLDENGATE_DEMO_ADDR0_PSU                       0x38
#define GOLDENGATE_DEMO_ADDR1_PSU                       0x38
#define GOLDENGATE_DEMO_PSU_MODULE_MAX                  0x2
#define GOLDENGATE_DEMO_PSU_MODULE_KINDS                0x2
#define GOLDENGATE_DEMO_I2C_BRIDGE_ADDR                 0x70

#define GOLDENGATE_DEMO_EEPROM_NUM                      0x01
#define GOLDENGATE_DEMO_ADDR_EEPROM                     0x56

#define GOLDENGATE_DEMO_DPLL_NUM                      0x01
#define GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX                    24*4
#define GOLDENGATE_DEMO_PANEL_PORT_NUM                        24
#define GOLDENGATE_DEMO_FIBER_PORT_NUM                        24
#define GOLDENGATE_DEMO_FIBER_COMBO_PORT_NUM                   4

#define GOLDENGATE_DEMO_PANEL_COMBO_PORT_NUM                   1

#define GOLDENGATE_DEMO_SLICE0_LED_MAC_NUM                     20
#define GOLDENGATE_DEMO_LED_MAC_NUM                            36
#define GOLDENGATE_DEMO_LED_TBL_NUM                            4

/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
static glb_card_t* glb_card;
static lcm_card_port_t *glb_lcm_goldengate_demo_port=NULL;
static fiber_port_info_t *glb_lcm_goldengate_demo_fiber=NULL;
static lcm_card_serdes_info_t* glb_lcm_goldengate_demo_serdes_mode=NULL;
int32 goldengate_demo_dpll_spi_0_fd = 0;

struct lcm_goldengate_demo_combo_info_s
{
    uint8                    mux_chip_id;
    glb_port_media_type_t    port_media_type;
};
typedef struct lcm_goldengate_demo_combo_info_s lcm_goldengate_demo_combo_info_t;

static lcm_goldengate_demo_combo_info_t g_goldengate_demo_combo_info;

extern int32 lcm_card_init_callback(card_init_callback_t func);
lcm_card_port_t lcm_goldengate_demo_combo_port_max[4] =
{
    {0, 0, 0, },    /* Port  1 <-> SerDes 2 <-> SGMII  1 */
    {0, 1, 1, },    /* Port  2 <-> SerDes 1 <-> SGMII  0 */
    {0, 2, 2, },    /* Port  3 <-> SerDes 3 <-> SGMII  3 */    
    {0, 3, 3, },    /* Port  4 <-> SerDes 0 <-> SGMII  2 */
};

lcm_card_port_t lcm_goldengate_demo_port_max[GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX] =
{
    /* HSS 0 */
    {0, 2, 2, },    /* Port  1 <-> SerDes 2 <-> SGMII  1 */
    {0, 1, 1, },    /* Port  2 <-> SerDes 1 <-> SGMII  0 */
    {0, 3, 3, },    /* Port  3 <-> SerDes 3 <-> SGMII  3 */    
    {0, 0, 0, },    /* Port  4 <-> SerDes 0 <-> SGMII  2 */
    {0, 6, 6, },    /* Port  5 <-> SerDes 6 <-> SGMII  5 */
    {0, 5, 5, },    /* Port  6 <-> SerDes 5 <-> SGMII  4 */
    {0, 7, 7, },    /* Port  7 <-> SerDes 7 <-> SGMII  7 */
    {0, 4, 4, },    /* Port  8 <-> SerDes 4 <-> SGMII  6 */

    {0, 10, 10,},    /* Port  9  <-> SerDes 10 <-> SGMII  1 */
    {0, 9 , 9 ,},    /* Port  10 <-> SerDes 9  <-> SGMII  0 */
    {0, 11, 11,},    /* Port  11 <-> SerDes 11 <-> SGMII  3 */    
    {0, 8 , 8 ,},    /* Port  12 <-> SerDes 8  <-> SGMII  2 */
    {0, 14, 14,},    /* Port  13 <-> SerDes 14 <-> SGMII  5 */
    {0, 13, 13,},    /* Port  14 <-> SerDes 13 <-> SGMII  4 */
    {0, 15, 15,},    /* Port  15 <-> SerDes 15 <-> SGMII  7 */
    {0, 12, 12,},    /* Port  16 <-> SerDes 12 <-> SGMII  6 */

    {0, 18, 18,},    /* Port  17 <-> SerDes 18 <-> SGMII  1 */
    {0, 17, 17,},    /* Port  18 <-> SerDes 17 <-> SGMII  0 */
    {0, 19, 19,},    /* Port  19 <-> SerDes 19 <-> SGMII  3 */    
    {0, 16, 16,},    /* Port  20 <-> SerDes 16 <-> SGMII  2 */
    {0, 22, 22,},    /* Port  21 <-> SerDes 22 <-> SGMII  5 */
    {0, 21, 21,},    /* Port  22 <-> SerDes 21 <-> SGMII  4 */
    {0, 23, 23,},    /* Port  23 <-> SerDes 23 <-> SGMII  7 */
    {0, 20, 20,},    /* Port  24 <-> SerDes 20 <-> SGMII  6 */

    {0, 26, 26,},    /* Port  25 <-> SerDes 26 <-> SGMII  1 */
    {0, 25, 25,},    /* Port  26 <-> SerDes 25 <-> SGMII  0 */
    {0, 27, 27,},    /* Port  27 <-> SerDes 27 <-> SGMII  3 */    
    {0, 24, 24,},    /* Port  28 <-> SerDes 24 <-> SGMII  2 */
    {0, 30, 30,},    /* Port  29 <-> SerDes 30 <-> SGMII  5 */
    {0, 29, 29,},    /* Port  30 <-> SerDes 29 <-> SGMII  4 */
    {0, 31, 31,},    /* Port  31 <-> SerDes 31 <-> SGMII  7 */
    {0, 28, 28,},    /* Port  32 <-> SerDes 28 <-> SGMII  6 */

    {0, 34, 34,},    /* Port  33 <-> SerDes 34 <-> SGMII  1 */
    {0, 33, 33,},    /* Port  34 <-> SerDes 33 <-> SGMII  0 */
    {0, 35, 35,},    /* Port  35 <-> SerDes 35 <-> SGMII  3 */    
    {0, 32, 32,},    /* Port  36 <-> SerDes 32 <-> SGMII  2 */
    {0, 42, 42,},    /* Port  37 <-> SerDes 38 <-> SGMII  5 */
    {0, 41, 41,},    /* Port  38 <-> SerDes 37 <-> SGMII  4 */
    {0, 43, 43,},    /* Port  39 <-> SerDes 39 <-> SGMII  7 */
    {0, 40, 40,},    /* Port  40 <-> SerDes 36 <-> SGMII  6 */

    /* CS0 */
    {0, 38, 38,},    /* Port  41 <-> SerDes 42 <-> SGMII  1 */
    {0, 37, 37,},    /* Port  42 <-> SerDes 41 <-> SGMII  0 */
    {0, 39, 39,},    /* Port  43 <-> SerDes 43 <-> SGMII  3 */    
    {0, 36, 36,},    /* Port  44 <-> SerDes 40 <-> SGMII  2 */
    {0, 45, 45,},    /* Port  45 <-> SerDes 45 <-> SGMII  5 */
    {0, 46, 46,},    /* Port  46 <-> SerDes 46 <-> SGMII  4 */
    {0, 44, 44,},    /* Port  47 <-> SerDes 44 <-> SGMII  7 */
    {0, 47, 47,},    /* Port  48 <-> SerDes 47 <-> SGMII  6 */

    /* HSS 1 */
    {0, 46+GG_SLICE1_BASE, 46+GG_SLICE1_BASE,},    /* Port  49 <-> SerDes 93 <-> SGMII  1 */
    {0, 45+GG_SLICE1_BASE, 45+GG_SLICE1_BASE,},    /* Port  50 <-> SerDes 94 <-> SGMII  0 */
    {0, 47+GG_SLICE1_BASE, 47+GG_SLICE1_BASE,},    /* Port  51 <-> SerDes 92 <-> SGMII  3 */    
    {0, 44+GG_SLICE1_BASE, 44+GG_SLICE1_BASE,},    /* Port  52 <-> SerDes 95 <-> SGMII  2 */
    {0, 37+GG_SLICE1_BASE, 37+GG_SLICE1_BASE,},    /* Port  53 <-> SerDes 89 <-> SGMII  5 */
    {0, 38+GG_SLICE1_BASE, 38+GG_SLICE1_BASE,},    /* Port  54 <-> SerDes 90 <-> SGMII  4 */
    {0, 36+GG_SLICE1_BASE, 36+GG_SLICE1_BASE,},    /* Port  55 <-> SerDes 88 <-> SGMII  7 */
    {0, 39+GG_SLICE1_BASE, 39+GG_SLICE1_BASE,},    /* Port  56 <-> SerDes 91 <-> SGMII  6 */

    {0, 41+GG_SLICE1_BASE, 41+GG_SLICE1_BASE,},    /* Port  57 <-> SerDes 85 <-> SGMII  1 */
    {0, 42+GG_SLICE1_BASE, 42+GG_SLICE1_BASE,},    /* Port  58 <-> SerDes 86 <-> SGMII  0 */
    {0, 40+GG_SLICE1_BASE, 40+GG_SLICE1_BASE,},    /* Port  59 <-> SerDes 84 <-> SGMII  3 */    
    {0, 43+GG_SLICE1_BASE, 43+GG_SLICE1_BASE,},    /* Port  60 <-> SerDes 87 <-> SGMII  2 */
    {0, 33+GG_SLICE1_BASE, 33+GG_SLICE1_BASE,},    /* Port  61 <-> SerDes 81 <-> SGMII  5 */
    {0, 34+GG_SLICE1_BASE, 34+GG_SLICE1_BASE,},    /* Port  62 <-> SerDes 82 <-> SGMII  4 */
    {0, 32+GG_SLICE1_BASE, 32+GG_SLICE1_BASE,},    /* Port  63 <-> SerDes 80 <-> SGMII  7 */
    {0, 35+GG_SLICE1_BASE, 35+GG_SLICE1_BASE,},    /* Port  64 <-> SerDes 83 <-> SGMII  6 */

    {0, 29+GG_SLICE1_BASE, 29+GG_SLICE1_BASE,},    /* Port  65 <-> SerDes 77 <-> SGMII  1 */
    {0, 30+GG_SLICE1_BASE, 30+GG_SLICE1_BASE,},    /* Port  66 <-> SerDes 78 <-> SGMII  0 */
    {0, 28+GG_SLICE1_BASE, 28+GG_SLICE1_BASE,},    /* Port  67 <-> SerDes 76 <-> SGMII  3 */    
    {0, 31+GG_SLICE1_BASE, 31+GG_SLICE1_BASE,},    /* Port  68 <-> SerDes 79 <-> SGMII  2 */
    {0, 25+GG_SLICE1_BASE, 25+GG_SLICE1_BASE,},    /* Port  69 <-> SerDes 73 <-> SGMII  5 */
    {0, 26+GG_SLICE1_BASE, 26+GG_SLICE1_BASE,},    /* Port  70 <-> SerDes 74 <-> SGMII  4 */
    {0, 24+GG_SLICE1_BASE, 24+GG_SLICE1_BASE,},    /* Port  71 <-> SerDes 72 <-> SGMII  7 */
    {0, 27+GG_SLICE1_BASE, 27+GG_SLICE1_BASE,},    /* Port  72 <-> SerDes 75 <-> SGMII  6 */

    {0, 21+GG_SLICE1_BASE, 21+GG_SLICE1_BASE,},    /* Port  73 <-> SerDes 69 <-> SGMII  1 */
    {0, 22+GG_SLICE1_BASE, 22+GG_SLICE1_BASE,},    /* Port  74 <-> SerDes 70 <-> SGMII  0 */
    {0, 20+GG_SLICE1_BASE, 20+GG_SLICE1_BASE,},    /* Port  75 <-> SerDes 68 <-> SGMII  3 */    
    {0, 23+GG_SLICE1_BASE, 23+GG_SLICE1_BASE,},    /* Port  76 <-> SerDes 71 <-> SGMII  2 */
    {0, 17+GG_SLICE1_BASE, 17+GG_SLICE1_BASE,},    /* Port  77 <-> SerDes 65 <-> SGMII  5 */
    {0, 18+GG_SLICE1_BASE, 18+GG_SLICE1_BASE,},    /* Port  78 <-> SerDes 66 <-> SGMII  4 */
    {0, 16+GG_SLICE1_BASE, 16+GG_SLICE1_BASE,},    /* Port  79 <-> SerDes 64 <-> SGMII  7 */
    {0, 19+GG_SLICE1_BASE, 19+GG_SLICE1_BASE,},    /* Port  80 <-> SerDes 67 <-> SGMII  6 */

    {0, 13+GG_SLICE1_BASE, 13+GG_SLICE1_BASE,},    /* Port  81 <-> SerDes 61 <-> SGMII  1 */
    {0, 14+GG_SLICE1_BASE, 14+GG_SLICE1_BASE,},    /* Port  82 <-> SerDes 62 <-> SGMII  0 */
    {0, 12+GG_SLICE1_BASE, 12+GG_SLICE1_BASE,},    /* Port  83 <-> SerDes 60 <-> SGMII  3 */    
    {0, 15+GG_SLICE1_BASE, 15+GG_SLICE1_BASE,},    /* Port  84 <-> SerDes 63 <-> SGMII  2 */
    {0, 9+GG_SLICE1_BASE , 9+GG_SLICE1_BASE ,},    /* Port  85 <-> SerDes 57 <-> SGMII  5 */
    {0, 10+GG_SLICE1_BASE, 10+GG_SLICE1_BASE,},    /* Port  86 <-> SerDes 58 <-> SGMII  4 */
    {0, 8+GG_SLICE1_BASE , 8+GG_SLICE1_BASE ,},    /* Port  87 <-> SerDes 56 <-> SGMII  7 */
    {0, 11+GG_SLICE1_BASE, 11+GG_SLICE1_BASE,},    /* Port  88 <-> SerDes 59 <-> SGMII  6 */

    /* CS1 */
    {0, 5+GG_SLICE1_BASE, 5+GG_SLICE1_BASE,},    /* Port  89 <-> SerDes 53 <-> SGMII  1 */
    {0, 6+GG_SLICE1_BASE, 6+GG_SLICE1_BASE,},    /* Port  90 <-> SerDes 54 <-> SGMII  0 */
    {0, 4+GG_SLICE1_BASE, 4+GG_SLICE1_BASE,},    /* Port  91 <-> SerDes 52 <-> SGMII  3 */    
    {0, 7+GG_SLICE1_BASE, 7+GG_SLICE1_BASE,},    /* Port  92 <-> SerDes 55 <-> SGMII  2 */
    {0, 1+GG_SLICE1_BASE, 1+GG_SLICE1_BASE,},    /* Port  93 <-> SerDes 49 <-> SGMII  5 */
    {0, 2+GG_SLICE1_BASE, 2+GG_SLICE1_BASE,},    /* Port  94 <-> SerDes 50 <-> SGMII  4 */
    {0, 0+GG_SLICE1_BASE, 0+GG_SLICE1_BASE,},    /* Port  95 <-> SerDes 48 <-> SGMII  7 */
    {0, 3+GG_SLICE1_BASE, 3+GG_SLICE1_BASE,},    /* Port  96 <-> SerDes 51 <-> SGMII  6 */
};

fiber_port_info_t lcm_goldengate_demo_combo_fiber_max[4] = 
{
    {E_FIBER_SFP_P,   E_FIBER_SFP_CTC_CHIP_GPIO,  0,  0, 6, 3, 0, 3, 16, 3, 24},
    {E_FIBER_SFP_P,   E_FIBER_SFP_CTC_CHIP_GPIO,  1,  0, 7, 3, 1, 3, 17, 3, 25},
    {E_FIBER_SFP_P,   E_FIBER_SFP_CTC_CHIP_GPIO,  2,  0, 5, 3, 2, 3, 18, 3, 26},
    {E_FIBER_SFP_P,   E_FIBER_SFP_CTC_CHIP_GPIO,  3,  0, 4, 3, 3, 3, 19, 3, 27},
};

fiber_port_info_t lcm_goldengate_demo_fiber_max[GOLDENGATE_DEMO_FIBER_PORT_NUM] =
{
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  0,  0, 1,  0xff, 0xff, 0, 24, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  1,  0, 0,  0xff, 0xff, 0, 25, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  2,  0, 3,  0xff, 0xff, 0, 26, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  3,  0, 2,  0xff, 0xff, 0, 27, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  4,  0, 9,  0xff, 0xff, 0, 28, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  5,  0, 8,  0xff, 0xff, 0, 29, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  6,  0, 14, 0xff, 0xff, 0, 30, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  7,  0, 15, 0xff, 0xff, 0, 31, 0xff, 0xff},

    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  8,  0, 12, 0xff, 0xff, 1, 24, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  9,  0, 13, 0xff, 0xff, 1, 25, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  10, 0, 11, 0xff, 0xff, 1, 26, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  11, 0, 10, 0xff, 0xff, 1, 27, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  12, 1, 5 , 0xff, 0xff, 1, 28, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  13, 1, 4 , 0xff, 0xff, 1, 29, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  14, 1, 2 , 0xff, 0xff, 1, 30, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  15, 1, 3 , 0xff, 0xff, 1, 31, 0xff, 0xff},

    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  16, 1, 0 , 0xff, 0xff, 2, 24, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  17, 1, 1 , 0xff, 0xff, 2, 25, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  18, 1, 7 , 0xff, 0xff, 2, 26, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  19, 1, 6 , 0xff, 0xff, 2, 27, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  20, 1, 11, 0xff, 0xff, 2, 28, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  21, 1, 10, 0xff, 0xff, 2, 29, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  22, 1, 13, 0xff, 0xff, 2, 30, 0xff, 0xff},
    {E_FIBER_QSFP_P,   E_FIBER_QSFP_CTC_CHIP_GPIO,  23, 1, 12, 0xff, 0xff, 2, 31, 0xff, 0xff},
};

uint8 lcm_goldengate_demo_combo_mac_led[GOLDENGATE_DEMO_FIBER_COMBO_PORT_NUM]=
{
    0, 1, 2, 3,  //SFP 1 - 4
};

/* table entry defination:
 * 0 -11 : QSFP+ 0 - 11 led
 * 12-15 : SFP+  0 - 3 led
 * 16-20 : fanout led 0 - 3
 * 23-31 : QSFP+ 12-23 led
 * 32-35 : fanout led 0 - 3
*/
/* Modified by liuht for bug 34540, 2015-09-09 */
mac_led_api_para_t lcm_goldengate_demo_mac_led_default_entry[GOLDENGATE_DEMO_LED_MAC_NUM]=
{
    {0, 0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+0
    {4, 0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+1
    {8, 0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+2
    {12,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+3
    {16,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+4
    {20,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+5
    {24,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+6
    {28,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+7
    {32,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+8
    {48,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+9
    {36,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+10
    {52,0, 0, LED_MODE_1_FORCE_OFF}, //QSFP+11

    {56, 0, 0, LED_MODE_2_FORCE_OFF},
    {56, 0, 0, LED_MODE_2_FORCE_OFF},
    {56, 0, 0, LED_MODE_2_FORCE_OFF},
    {56, 0, 0, LED_MODE_2_FORCE_OFF},

    {57, 0, 0, LED_MODE_1_FORCE_OFF},
    {57, 0, 0, LED_MODE_1_FORCE_OFF},
    {57, 0, 0, LED_MODE_1_FORCE_OFF},
    {57, 0, 0, LED_MODE_1_FORCE_OFF},

    {52, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+12
    {36, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+13
    {48, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+14
    {32, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+15
    {28, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+16
    {24, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+17
    {20, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+18
    {16, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+19
    {12, 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+20
    {8 , 0, 1, LED_MODE_1_FORCE_OFF}, //QSFP+21
    {4 , 0 ,1, LED_MODE_1_FORCE_OFF}, //QSFP+22
    {0 , 0 ,1, LED_MODE_1_FORCE_OFF}, //QSFP+23
    
    {57, 0, 1, LED_MODE_1_FORCE_OFF},
    {57, 0, 1, LED_MODE_1_FORCE_OFF},
    {57, 0, 1, LED_MODE_1_FORCE_OFF},
    {57, 0, 1, LED_MODE_1_FORCE_OFF}
}; 

lcm_card_serdes_ffe_t 
lcm_goldengate_demo_serdes_ffe_max[GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX]=
{
    {2 , 2}, {1 , 2}, {3 , 2}, {0 , 2},   /* unused */
    {6 , 2}, {5 , 2}, {7 , 2}, {4 , 2},   /* QSFP+ 2 */
    {10, 1}, {9 , 1}, {11, 1}, {8 , 1},   /* QSFP+ 3 */
    {14, 2}, {13, 1}, {15, 1}, {12, 1},   /* QSFP+ 4 */
    {18, 1}, {17, 1}, {19, 1}, {16, 1},   /* QSFP+ 5 */
    {22, 1}, {21, 1}, {23, 1}, {20, 1},   /* QSFP+ 6 */
    {26, 1}, {25, 1}, {27, 0}, {24, 0},   /* QSFP+ 7 */
    {30, 1}, {29, 1}, {31, 0}, {28, 0},   /* QSFP+ 8 */
    {34, 0}, {33, 0}, {35, 0}, {32, 0},   /* QSFP+ 9 */
    {38, 1}, {37, 0}, {39, 0}, {36, 0},   /* QSFP+ 10 */
    {42, 0}, {41, 0}, {43, 0}, {40, 0},   /* QSFP+ 11 */
    {45, 0}, {46, 0}, {44, 0}, {47, 0},   /* QSFP+ 12 */
    {94, 0}, {93, 0}, {95, 0}, {92, 0},   /* QSFP+ 13 */
    {89, 0}, {90, 0}, {88, 0}, {91, 0},   /* QSFP+ 14 */
    {85, 0}, {86, 0}, {84, 0}, {87, 0},   /* QSFP+ 15 */
    {81, 0}, {82, 0}, {80, 0}, {83, 0},   /* QSFP+ 16 */
    {77, 0}, {78, 0}, {76, 0}, {79, 0},   /* QSFP+ 17 */
    {73, 0}, {74, 0}, {72, 0}, {75, 0},   /* QSFP+ 18 */
    {69, 1}, {70, 1}, {68, 1}, {71, 1},   /* QSFP+ 19 */
    {65, 1}, {66, 1}, {64, 1}, {67, 1},   /* QSFP+ 20 */
    {61, 1}, {62, 1}, {60, 1}, {63, 1},   /* QSFP+ 21 */
    {57, 1}, {58, 1}, {56, 1}, {59, 1},   /* QSFP+ 22 */
    {53, 1}, {54, 1}, {52, 1}, {55, 1},   /* QSFP+ 23 */
    {49, 2}, {50, 2}, {48, 2}, {51, 2},   /* unused */
};
uint16 lcm_goldengate_demo_serdes_usrdef_coeff[][4]={
    /* ffe of serdes 0,1,2,3 for qsfp+ */
    {0x00, 0x27, 0x10, 0x00},
    {0x06, 0x2a, 0x0c, 0x00},
    {0x00, 0x27, 0x10, 0x00},
    {0x00, 0x27, 0x10, 0x00},

    /* ffe of serdes 48,49,50,51 */
    {0x07, 0x25, 0x10, 0x00},
    {0x07, 0x28, 0x0d, 0x00},
    {0x07, 0x28, 0x0d, 0x00},
    {0x07, 0x28, 0x0d, 0x00},

    /* ffe of serdes 0,1,2,3 for sfp+ */
    {0x00, 0x20, 0x09, 0x00},
    {0x07, 0x25, 0x06, 0x00},
    {0x00, 0x20, 0x09, 0x00},
    {0x00, 0x20, 0x09, 0x00},
};

uint8 lcm_goldengate_demo_combo_serdes_mode_max[4] =
{
    0, 1, 2, 3
};

mux_info_t lcm_goldengate_demo_mux[GOLDENGATE_DEMO_MUX_CHIP_NUM][GOLDENGATE_DEMO_MUX_PORT_NUM*GOLDENGATE_DEMO_MUX_LAN_NUM] =
{
    {
        /* For chip0 */
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 0, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 1, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 2, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 3, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 0, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 1, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 2, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 3, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 0, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 1, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 2, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 3, 0, 0x11, 0xc},
    },

    {
        /* For chip1 */
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 0, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 1, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 2, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL0    , MUX_PORTA, 3, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 0, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 1, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 2, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL1    , MUX_PORTB, 3, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 0, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 1, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 2, 0, 0x11, 0xc},
        {GLB_MUX_CHANNEL_NONE, MUX_PORTC, 3, 0, 0x11, 0xc},
    },
};

/****************************************************************************
 *
* Function
*
****************************************************************************/
static int32
_lcm_init_goldengate_demo_cpu_info()
{
    FILE * fp;

    fp = sal_fopen(GLB_CPU_IF_INFO_FILE, "w+");
    if(fp ==NULL)
    {
        LCM_LOG_ERR("Open cpu info file error.");
        return LCM_E_FILE_OPEN;
    }
    sal_fprintf(fp, "MGMT_IF eth0\n");
    sal_fprintf(fp, "CPU_IF NOTUSE\n");
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_port_table(glb_card_t* p_card)
{
    uint8 port_id, panel_port_no, panel_subport_no;
    uint8 pos;

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        panel_port_no = p_card->pp_port[port_id]->panel_port_no;
        panel_subport_no = p_card->pp_port[port_id]->panel_sub_port_no;
        if(panel_subport_no)
        {
            pos = (panel_port_no-1)*4+panel_subport_no-1;
        }
        else
        {
            /* For panel port 1 - 11, the forth entry based on (panel_port_no-1)*4 is needed
             * For panel port 12, the third entry based on (panel_port_no-1)*4 is needed
             * For panel port 13, the forth entry based on (panel_port_no-1)*4 is needed
             * For panel port 14- 24, the third entry based on (panel_port_no-1)*4 is needed
             * All this is rest with hardware
            */
            if(panel_port_no<14)
            {
                if(panel_port_no == 12)
                {
                    pos = (panel_port_no-1)*4+2;
                }
                else
                {
                    pos = (panel_port_no-1)*4+3;
                }
            }
            else
            {
                pos = (panel_port_no-1)*4+2;
            }
        }
        sal_memcpy(&glb_lcm_goldengate_demo_port[port_id], &lcm_goldengate_demo_port_max[pos], sizeof(lcm_card_port_t));
    }

    return LCM_E_SUCCESS;
}

static int32
lcm_init_goldengate_demo_init_serdes_table(glb_card_t* p_card)
{
    uint8 port_id, panel_port_no, panel_subport_no;
    uint8 pos;

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        panel_port_no = p_card->pp_port[port_id]->panel_port_no;
        panel_subport_no = p_card->pp_port[port_id]->panel_sub_port_no;
        if(panel_subport_no)
        {
            pos = (panel_port_no-1)*4+panel_subport_no-1;
        }
        else
        {
            /* For panel port 1 - 11, the forth entry based on (panel_port_no-1)*4 is needed
             * For panel port 12, the third entry based on (panel_port_no-1)*4 is needed
             * For panel port 13, the forth entry based on (panel_port_no-1)*4 is needed
             * For panel port 14- 24, the third entry based on (panel_port_no-1)*4 is needed
             * All this is rest with hardware
            */
            if(panel_port_no<14)
            {
                if(panel_port_no == 12)
                {
                    pos = (panel_port_no-1)*4+2;
                }
                else
                {
                    pos = (panel_port_no-1)*4+3;
                }
            }
            else
            {
                pos = (panel_port_no-1)*4+2;
            }
        }
        glb_lcm_goldengate_demo_serdes_mode[port_id].serdes_id = lcm_goldengate_demo_serdes_ffe_max[pos].serdes_id;
    }
    
    return LCM_E_SUCCESS;
}

static int32
lcm_init_goldengate_demo_init_fiber_table(glb_card_t* p_card)
{
    uint8 port_id, panel_port_no, panel_subport_no;
    uint8 fiber_channel;

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        panel_port_no = p_card->pp_port[port_id]->panel_port_no;
        panel_subport_no = p_card->pp_port[port_id]->panel_sub_port_no;
        if(panel_subport_no)
        {
            fiber_channel = panel_subport_no;
        }
        else
        {
            fiber_channel = 0;
        }
        sal_memcpy(&glb_lcm_goldengate_demo_fiber[port_id], &lcm_goldengate_demo_fiber_max[panel_port_no-1], sizeof(fiber_port_info_t));
        glb_lcm_goldengate_demo_fiber[port_id].fiber_channel = fiber_channel;
        glb_lcm_goldengate_demo_fiber[port_id].fiber_id = port_id;
    }
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_serdes_mode(void)
{
    uint8 i;
    uint8 pos;
    uint8 panel_port;
    ctc_chip_serdes_info_t serdes_info;

    /* Modified by liuht for bug 32804, 2015-04-15 */
    /* disable all 40G/100G Mac for serdes mode switch */
    for(panel_port=1; panel_port<=glb_card->panel_port_num; panel_port++)
    {
        /* For panel port 1 - 11, the forth entry based on (panel_port_no-1)*4 is needed
         * For panel port 12, the third entry based on (panel_port_no-1)*4 is needed
         * For panel port 13, the forth entry based on (panel_port_no-1)*4 is needed
         * For panel port 14- 24, the third entry based on (panel_port_no-1)*4 is needed
         * All this is rest with hardware
        */
        if(panel_port<14)
        {
            if(panel_port == 12)
            {
                pos = (panel_port-1)*4+2;
            }
            else
            {
                pos = (panel_port-1)*4+3;
            }
        }
        else
        {
            pos = (panel_port-1)*4+2;
        }
        ctc_port_set_mac_en(lcm_goldengate_demo_port_max[pos].logic_port_idx, 0);
    }

    for(panel_port=0; panel_port<glb_card->panel_port_num; panel_port++)
    {
        if(GLB_PPT_NUMCHG_TYPE_NONE == glb_card->pp_ppt[panel_port]->ppt_numchg_type)
        {
            continue;
        }
        else if(GLB_PPT_NUMCHG_TYPE_10G == glb_card->pp_ppt[panel_port]->ppt_numchg_type)
        {
            serdes_info.serdes_mode = CTC_CHIP_SERDES_XFI_MODE;
            for(i=0; i<4; i++)
            {
                serdes_info.serdes_id = lcm_goldengate_demo_serdes_ffe_max[panel_port*4+i].serdes_id;
                ctc_chip_set_serdes_mode(0, &serdes_info);
            }
        }
        else if(GLB_PPT_NUMCHG_TYPE_1G == glb_card->pp_ppt[panel_port]->ppt_numchg_type)
        {
            serdes_info.serdes_mode = CTC_CHIP_SERDES_SGMII_MODE;
            for(i=0; i<4; i++)
            {
                serdes_info.serdes_id = lcm_goldengate_demo_serdes_ffe_max[panel_port*4+i].serdes_id;
                ctc_chip_set_serdes_mode(0, &serdes_info);
            }
        }
    }
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_combo_port_table(glb_card_t* p_card)
{
    uint8 i;
    if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP)
    {
        for (i = 0; i < 4; i++)
        {
            sal_memcpy(&glb_lcm_goldengate_demo_port[i], &lcm_goldengate_demo_combo_port_max[i], sizeof(lcm_card_port_t));
            sal_memcpy(&glb_lcm_goldengate_demo_serdes_mode[i], &lcm_goldengate_demo_combo_serdes_mode_max[i], sizeof(lcm_card_serdes_info_t));
            sal_memcpy(&glb_lcm_goldengate_demo_fiber[i], &lcm_goldengate_demo_combo_fiber_max[i], sizeof(fiber_port_info_t));
        }
    }

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_mux_chan(void)
{
    int chip_id;
    int ret;

    chip_id = g_goldengate_demo_combo_info.mux_chip_id;
    if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP)
    {
        ret = mux_channel_select(chip_id, GLB_MUX_CHANNEL1);
    }
    else if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_QSFP)
    {
        ret = mux_channel_select(chip_id, GLB_MUX_CHANNEL0);
    }

    if (ret < 0)
        return ret;
    
    return LCM_E_SUCCESS;
}

/***************************************************************************************************
 * Name         : lcm_common_parse_port_media_info 
 * Purpose      : parse port media info           
 * Input        :    
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32
lcm_common_parse_port_media_info(glb_card_t* p_card)
{
    FILE *startup_config_fp = NULL;
    uint32 panel_slot_no, panel_port_no;
    uint8 comb_port_id=0;
    char buf[256];   
    char media_type[32];
    
    startup_config_fp = sal_fopen(GLB_STARTUP_CONFIG_FILE_PATH, "r");
    if (startup_config_fp)
    {
        while (sal_fgets(buf, 128, startup_config_fp))
        {
            if (!sal_strstr(buf, "switch interface"))
            {
                continue;
            }

            if (lcm_parse_switch_cli(p_card, buf, &panel_slot_no, &panel_port_no, media_type))
            {
                continue;
            }
            if((panel_port_no>p_card->panel_port_num) || (panel_port_no < 1))
            {
                continue;
            }
            //if(glb_p_port_split_info[panel_port_no-1].port_split_type==GLB_PORT_SPLIT_TYPE_NONE
            //    || glb_p_port_split_info[panel_port_no-1].port_split_num==0)
            if ((GLB_PPT_NUMCHG_TYPE_NONE == p_card->pp_ppt[panel_port_no-1]->ppt_numchg_type)
                || (0 == p_card->pp_ppt[panel_port_no-1]->ppt_numchg_num))///TODO: different comparison item?
            {
                continue;
            }
            if(comb_port_id > GOLDENGATE_DEMO_PANEL_COMBO_PORT_NUM)
            {
                break;
            }
            if(!sal_memcmp(media_type, "sfp", 3))
            {
                g_goldengate_demo_combo_info.port_media_type = GLB_PORT_MEDIA_TYPE_SFP;
                break;
            }
        }
        sal_fclose(startup_config_fp);
    }
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_panel_port(glb_card_t* p_card)
{
    uint8 ppt_id;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init panel port begin.");

    /* 1, Allocate panel port memory */
    p_card->pp_ppt = (glb_panel_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, 
        sizeof(glb_panel_port_t* )* p_card->panel_port_num);
    if (!p_card->pp_ppt)
    {
        LCM_LOG_ERR("Allocate pointer to global panel ports fail.");
        return LCM_E_NO_MEMORY;
    }

    /* 2, init panel port split/merge related data structure */
    for(ppt_id = 0; ppt_id < p_card->panel_port_num; ppt_id++)
    {
        p_card->pp_ppt[ppt_id] = (glb_panel_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_panel_port_t));
        if(!p_card->pp_ppt[ppt_id])
        {
            LCM_LOG_ERR("Allocate global panel ports fail.");
            return LCM_E_NO_MEMORY;
        }
        
        p_card->pp_ppt[ppt_id]->ppt_idx = ppt_id + 1;
        p_card->pp_ppt[ppt_id]->pslt_id = p_card->phy_slot_no;
        p_card->pp_ppt[ppt_id]->ppt_numchg_type = GLB_PPT_NUMCHG_TYPE_NONE;
        p_card->pp_ppt[ppt_id]->op = GLB_PPT_OP_SPLIT;
        p_card->pp_ppt[ppt_id]->ppt_numchg_num = 1;///TODO: need optimize
        if(ppt_id>=10 && ppt_id<=13)
        {
            /*Bug33327, support 100G, but current default is 40G. This affect phy init, the phy default speed is 100G 
            or 40G. */
            p_card->pp_ppt[ppt_id]->ppt_speed_ability = GLB_SUPPORT_SPEED_100G|GLB_SUPPORT_SPEED_40G;
            //p_card->pp_ppt[ppt_id]->ppt_speed_real = GLB_SUPPORT_SPEED_100G;
            p_card->pp_ppt[ppt_id]->ppt_speed_real = GLB_SUPPORT_SPEED_40G;
        }
        else
        {
            p_card->pp_ppt[ppt_id]->ppt_speed_ability = GLB_SUPPORT_SPEED_40G;
            p_card->pp_ppt[ppt_id]->ppt_speed_real = GLB_SUPPORT_SPEED_40G;
        }

    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init panel port end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_port(glb_card_t* p_card)
{
    int32 port_id = 0;
    uint32 ppt_idx;
    uint16 logic_port_idx;
    lcm_card_port_panel_mapping_t port_panel_mapping[256];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port begin.");

    /* 1, init panel port */
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_panel_port(p_card));

    /* 2, read '/mnt/flash/startup-config.conf' file, get port split/merge info */
    LCM_IF_ERROR_RETURN(lcm_common_parse_port_numchg_info(p_card));

    if(p_card->port_num != GOLDENGATE_DEMO_PANEL_PORT_NUM)
    {
        p_card->split_flag = 1;
    }
    else
    {
        p_card->split_flag = 0;
    }

    /* 2a, init combo port */
    g_goldengate_demo_combo_info.mux_chip_id= 0;
    g_goldengate_demo_combo_info.port_media_type = GLB_PORT_MEDIA_TYPE_QSFP;
    LCM_IF_ERROR_RETURN(lcm_common_parse_port_media_info(p_card));

    /* 3, get panel_port/sub_port mapping */
    LCM_IF_ERROR_RETURN(lcm_common_ppt_map_port(p_card, port_panel_mapping));

    /* 4, integrate port info */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }
        p_card->pp_port[port_id]->panel_slot_no = port_panel_mapping[port_id].panel_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_panel_mapping[port_id].panel_port_no;
        p_card->pp_port[port_id]->panel_sub_port_no = port_panel_mapping[port_id].panel_subport_no;
    }

    /* 5, allocate memory for port/fiber/serdes data structure */
    glb_lcm_goldengate_demo_port = (lcm_card_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(lcm_card_port_t)* p_card->port_num);
    if (!glb_lcm_goldengate_demo_port)
    {
        LCM_LOG_ERR("Allocate pointer to lcm_card_port_t fail.");
        return LCM_E_NO_MEMORY;
    }

    glb_lcm_goldengate_demo_fiber = (fiber_port_info_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(fiber_port_info_t)*p_card->port_num);
    if (!glb_lcm_goldengate_demo_fiber)
    {
        LCM_LOG_ERR("Allocate pointer to fiber_port_info_t fail.");
        return LCM_E_NO_MEMORY;
    }

    glb_lcm_goldengate_demo_serdes_mode = (lcm_card_serdes_info_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(lcm_card_serdes_info_t)* p_card->port_num);
    if (!glb_lcm_goldengate_demo_serdes_mode)
    {
        LCM_LOG_ERR("Allocate pointer to int fail.");
        return LCM_E_NO_MEMORY;
    }

    /* 6, init current running port/fiber/serdes info */
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_port_table(p_card));
    LCM_IF_ERROR_RETURN(lcm_init_goldengate_demo_init_fiber_table(p_card));
    LCM_IF_ERROR_RETURN(lcm_init_goldengate_demo_init_serdes_table(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_combo_port_table(p_card));

    /* 7, init port properties */
    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        logic_port_idx = glb_lcm_goldengate_demo_port[port_id].logic_port_idx;
        ppt_idx = p_card->pp_port[port_id]->panel_port_no;
        if(port_id==0) ///TODO: port id or panel idx?
        {
            p_card->pp_port[port_id]->support_media_switch = 1;
        }
        else
        {
            p_card->pp_port[port_id]->support_media_switch = 0;
        }
        p_card->pp_port[port_id]->p_fiber = NULL;
        p_card->pp_port[port_id]->create_done = 1;
        p_card->pp_port[port_id]->is_combo = 0;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = 1;
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 0;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_cfg.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        p_card->pp_port[port_id]->port_status.link_up = GLB_LINK_DOWN;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_status.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_status.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->poe_support = NOT_POE_PORT;
        p_card->pp_port[port_id]->is_combo_to = 0;

        p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_UNKNOWN;
        p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_FIBER;
        p_card->pp_port[port_id]->port_speed_ability = p_card->pp_ppt[ppt_idx-1]->ppt_speed_ability;
        p_card->pp_port[port_id]->port_speed_real = p_card->pp_ppt[ppt_idx-1]->ppt_speed_real;
        p_card->pp_port[port_id]->mux_chip_id = 0;
        p_card->pp_port[port_id]->lp_support = 0;
        /* support eee function for bug 28298, 2014-04-21 */
        p_card->pp_port[port_id]->eee_support = 0;        
        p_card->pp_port[port_id]->logic_port_idx = logic_port_idx;
        p_card->pp_port[port_id]->local_chip_idx = glb_lcm_goldengate_demo_port[port_id].chip_idx;
        p_card->pp_port[port_id]->mac_idx = glb_lcm_goldengate_demo_port[port_id].mac_idx;
        p_card->pp_port[port_id]->chip_serdes_id = glb_lcm_goldengate_demo_serdes_mode[port_id].serdes_id;
        p_card->pp_port[port_id]->g_port_index = p_card->pp_port[port_id]->logic_port_idx = logic_port_idx;
        /* Modified by liuht for bug 34540, 2015-09-09 */
        if((ppt_idx == 1) && (g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP))
        {
            p_card->pp_port[port_id]->port_led_mode_change = GLB_PORT_LED_MODE_CHANGE_SFP_TWO_LED;
        }
        else
        {
            p_card->pp_port[port_id]->port_led_mode_change = GLB_PORT_LED_MODE_CHANGE_QSFP_ONE_LED;

        }
        p_card->pp_port[port_id]->ctl_id = (logic_port_idx >= GG_SLICE1_BASE)?1:0;
        if(p_card->pp_port[port_id]->ctl_id==1)
        {
            logic_port_idx = logic_port_idx -GG_SLICE1_BASE;
        }
        p_card->pp_port[port_id]->port_led_mac = (logic_port_idx >= 40)?
            (logic_port_idx+8):logic_port_idx;
    }

    /* 8, create file '/tmp/ctcos_port_info' */
    LCM_IF_ERROR_RETURN(lcm_common_save_port_info_file(p_card));
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port end.");

    return LCM_E_SUCCESS;
}

static int32_t
_lcm_reg_goldengate_demo_epld(uint8 hw_ver, epld_info_t * p_epld_info)
{
    p_epld_info->base_addr = epld_localbus_addr_get();
    p_epld_info->epld_bus_type = EPLD_LOCALBUS_TYPE;

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_EPLD_VERSION]),          0x1, 0, 7, 8);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SYS_LED_SYS]),           0x2, 4, 7, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_LED]),               0x3, 4, 5, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU1_LED]),              0x2, 2, 3, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_STACKING_LED]),          0x3, 2, 3, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_IND_LED]),               0x3, 0, 0, 1);

    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_PCIE_RST]),           0x9, 2, 2, 1);
    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_POR_RST]),            0x9, 1, 1, 1);
    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_HARD_RST]),           0x9, 0, 0, 1);

    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PHY_RST]),               0xc, 0, 0, 1);
    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SERIAL_LED_RST]),        0xe, 6, 7, 2);

    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PHY_INT_MASK]),           0x13, 0, 0, 1);
    //epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_RESET_INT_MASK]),         0x9, 0, 0, 1);


    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_PRESENT_STATUS]),    0x16, 4, 5, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_WORK_STATUS]),       0x16, 6, 7, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_ALERT_STATUS]),      0x16, 2, 3, 2);

    /* Added by liuht for bug27036, 2014-02-21 */
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_POWER_RST]),         0xf6, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_MANUAL_OTHER_RST]),  0xf7, 0, 7, 8);	
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_I2C_BRIDGE_RST]),           0x08, 5, 5, 1);	
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GG_I2C_BRIDGE_RST]),        0x09, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GPIO_RST]),                 0x08, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_MUX1_RST]),                 0x1d, 0, 0, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_MUX2_RST]),                 0x1d, 1, 1, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SDPLL_RST]),                0x08, 4, 4, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_POWER_DOWN]),               0x23, 0, 1, 2);

#ifdef BOOTUP_DIAG
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_TEST]),                 0x7f, 0, 7, 8);
#endif
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_epld(glb_card_t* p_card, uint8 epld_version)
{
    epld_info_t *p_epld_info = NULL;
    int32 ret = 0;

    p_epld_info = epld_get_info(&p_card->board_type, epld_version);
    if (!p_epld_info)
    {
        LCM_LOG_ERR("Get EPLD info fail.");
        return LCM_E_INVALID_PTR;
    }

    _lcm_reg_goldengate_demo_epld(p_card->hw_ver, p_epld_info);
    ret = epld_init(p_epld_info);
    if (0 != ret)
    {
        LCM_LOG_ERR("EPLD Init fail.");
        return LCM_E_INIT_FAILED;
    }
    /* Fix bug29772, cr9895, qicx, 2014-08-26 */
    p_card->support_reboot_info = 1;
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init epld end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_goldengate_demo_eeprom_info(glb_card_t* p_card)
    {
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom info begin.");
    
        p_card->p_eeprom_alloc = (eeprom_info_t *)XCALLOC(MTYPE_BUFFER_DATA, sizeof(eeprom_info_t)*EEPROM_MAX);
        if(NULL == p_card->p_eeprom_alloc)
        {
            LCM_LOG_ERR("alloc p_eeprom_alloc array fail.");
            return LCM_E_INVALID_PTR;
        }
    
        p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].base_addr = 0x1000;
    
        p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].base_addr = 0x1001;
    
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
        p_card->p_eeprom_alloc[EEPROM_SMARTCFG].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_SMARTCFG].base_addr = 0x1007;
#endif /* !HAVE_SMARTCFG */
    
        p_card->p_eeprom_alloc[EEPROM_MGMT_CFG].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_MGMT_CFG].base_addr = 0x1100;
    
        p_card->p_eeprom_alloc[EEPROM_OEM_INFO].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_OEM_INFO].base_addr = 0x1300;
    
    
        p_card->p_eeprom_alloc[EEPROM_PORT_INFO].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_PORT_INFO].base_addr = 0x1400;
    
    /* 
        TODO
        p_card->p_eeprom_alloc[EEPROM_BOOTCMD].eeprom_idx = 0;
        p_card->p_eeprom_alloc[EEPROM_BOOTCMD].base_addr = 0x0;
    */    
        
        return LCM_E_SUCCESS;

}

static int32
_lcm_init_goldengate_demo_fiber(void)
{
    int32 ret = 0;
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber begin.");
    ret = fiber_init(glb_card->port_num,         /* fiber num */
                     glb_card->port_num,         /* port num */
                     glb_lcm_goldengate_demo_fiber);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber end.");

    return ret;
}

static int32
_lcm_init_goldengate_demo_sensor(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[GOLDENGATE_DEMO_SENSOR_NUM];
    sensor_chip_t sensor_chip[GOLDENGATE_DEMO_SENSOR_NUM];
    void *p_data[GOLDENGATE_DEMO_SENSOR_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    /* sensor1 */
    i2c_gen[0].addr = GOLDENGATE_DEMO_ADDR_SENSOR1;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[0].io_type = SENSOR_I2C;
    i2c_gen[0].alen = LM77_OFFSET_WIDTH;
    sensor_chip[0].chip_type = SENSOR_LM77;
    sensor_chip[0].pos = SENSOR_BEFORE_CHIP;

    i2c_gen[1].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[1].p_br.bridge_addr = GOLDENGATE_DEMO_I2C_BRIDGE_ADDR;
    i2c_gen[1].p_br.channel = 0;
    i2c_gen[1].addr = GOLDENGATE_DEMO_ADDR_SENSOR2;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].bridge_flag = 1;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[1].io_type = SENSOR_I2C;
    i2c_gen[1].alen = LM77_OFFSET_WIDTH;
    sensor_chip[1].chip_type = SENSOR_LM77;
    sensor_chip[1].pos = SENSOR_PSU;

    i2c_gen[2].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[2].p_br.bridge_addr = GOLDENGATE_DEMO_I2C_BRIDGE_ADDR;
    i2c_gen[2].p_br.channel = 6;
    i2c_gen[2].addr = GOLDENGATE_DEMO_ADDR_SENSOR3;
    i2c_gen[2].i2c_type = E_I2C_CPM;
    i2c_gen[2].bridge_flag = 1;
    i2c_gen[2].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[2].io_type = SENSOR_I2C;
    i2c_gen[2].alen = LM77_OFFSET_WIDTH;
    sensor_chip[2].chip_type = SENSOR_LM77;
    sensor_chip[2].pos = SENSOR_FAN;

    i2c_gen[3].addr = GOLDENGATE_DEMO_ADDR_SENSOR4;
    i2c_gen[3].i2c_type = E_I2C_CPM;
    i2c_gen[3].bridge_flag = 0;
    i2c_gen[3].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[3].io_type = SENSOR_I2C;
    i2c_gen[3].alen = LM77_OFFSET_WIDTH;
    sensor_chip[3].chip_type = SENSOR_LM77;
    sensor_chip[3].pos = SENSOR_CPU;
    
    
    for(i=0; i<GOLDENGATE_DEMO_SENSOR_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = sensor_init(p_data, sensor_chip, GOLDENGATE_DEMO_SENSOR_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Temperature sensor init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(i=0; i<GOLDENGATE_DEMO_SENSOR_NUM; i++)
    {
        sensor_dev_init(i);
    }
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_goldengate_demo_cfg_gpio(uint32 chip_id)
{
    uint8 reg, val;

    /* release pca9505 */
    epld_item_write(0, EPLD_GPIO_RST, 0xf);
    
    /* bank0-2:output port
     * bank3-4:input port  
    */
    if (chip_id < 3)
    {
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* release reset */
        reg = PCA9505_OUTPUT_PORT_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        
        /* cs enable  */
        reg = PCA9505_OUTPUT_PORT_REG_BANK1;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
    }
    else
    {
        /* bank0:output port
         * bank1-3:input port  
        */
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* tx enable */
        reg = PCA9505_OUTPUT_PORT_REG_BANK0;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
    }

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_gpio(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[GOLDENGATE_DEMO_GPIO_CHIP_NUM];
    gpio_chip_t gpio_chip[GOLDENGATE_DEMO_GPIO_CHIP_NUM];
    void *p_data[GOLDENGATE_DEMO_GPIO_CHIP_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = GOLDENGATE_DEMO_GPIO_CHIP1_ADDR;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[0].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[0].io_type = GPIO_I2C;    
    gpio_chip[0].chip_type = GPIO_PCA9505;
    gpio_chip[0].scan_group_bitmap = 0x8; /*group 3*/

    i2c_gen[1].addr = GOLDENGATE_DEMO_GPIO_CHIP2_ADDR;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].bridge_flag = 0;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[1].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[1].io_type = GPIO_I2C;    
    gpio_chip[1].chip_type = GPIO_PCA9505;
    gpio_chip[1].scan_group_bitmap = 0x8; /*group 3*/

    i2c_gen[2].addr = GOLDENGATE_DEMO_GPIO_CHIP3_ADDR;
    i2c_gen[2].i2c_type = E_I2C_CPM;
    i2c_gen[2].bridge_flag = 0;
    i2c_gen[2].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[2].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[2].io_type = GPIO_I2C;    
    gpio_chip[2].chip_type = GPIO_PCA9505;
    gpio_chip[2].scan_group_bitmap = 0x8; /*group 3*/

    i2c_gen[3].addr = GOLDENGATE_DEMO_GPIO_CHIP4_ADDR;
    i2c_gen[3].i2c_type = E_I2C_CPM;
    i2c_gen[3].bridge_flag = 0;
    i2c_gen[3].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[3].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[3].io_type = GPIO_I2C;    
    gpio_chip[3].chip_type = GPIO_PCA9505;
    gpio_chip[3].scan_group_bitmap = 0xc; /*group 2,3*/

    for(i=0; i<GOLDENGATE_DEMO_GPIO_CHIP_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = gpio_init(p_data, gpio_chip, GOLDENGATE_DEMO_GPIO_CHIP_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Gpio device init fail.");
        return LCM_E_INIT_FAILED;
    }

    for(i=0; i<GOLDENGATE_DEMO_GPIO_CHIP_NUM; i++)
    {
        _lcm_goldengate_demo_cfg_gpio(i);
    }

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_mux(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[GOLDENGATE_DEMO_MUX_CHIP_NUM];
    mux_chip_t mux_chip[GOLDENGATE_DEMO_MUX_CHIP_NUM];
    mux_info_t *p_mux_info[GOLDENGATE_DEMO_MUX_CHIP_NUM];
    void *p_data[GOLDENGATE_DEMO_MUX_CHIP_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = GOLDENGATE_DEMO_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 7;
    i2c_gen[0].addr = GOLDENGATE_DEMO_MUX_CHIP1_ADDR;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    mux_chip[0].io_type = MUX_I2C;
    i2c_gen[0].alen = SN65LVCP114_OFFSET_WIDTH;
    mux_chip[0].chip_type = MUX_SN65LVCP114;
    mux_chip[0].cfg_type = MUX_CONFIG_AS_SWITCH;
    mux_chip[0].port_num = GOLDENGATE_DEMO_MUX_PORT_NUM;
    mux_chip[0].lane_num = GOLDENGATE_DEMO_MUX_LAN_NUM;
    p_mux_info[0] = lcm_goldengate_demo_mux[0];

    i2c_gen[1].addr = GOLDENGATE_DEMO_MUX_CHIP2_ADDR;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].bridge_flag = 0;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    mux_chip[1].io_type = MUX_I2C;
    i2c_gen[1].alen = SN65LVCP114_OFFSET_WIDTH;
    mux_chip[1].chip_type = MUX_SN65LVCP114;
    mux_chip[1].cfg_type = MUX_CONFIG_AS_SWITCH;
    mux_chip[1].port_num = GOLDENGATE_DEMO_MUX_PORT_NUM;
    mux_chip[1].lane_num = GOLDENGATE_DEMO_MUX_LAN_NUM;
    p_mux_info[1] = lcm_goldengate_demo_mux[1];
    
    for(i=0; i<GOLDENGATE_DEMO_MUX_CHIP_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = mux_init(p_data, mux_chip, p_mux_info, GOLDENGATE_DEMO_MUX_CHIP_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Mux device init fail.");
        return LCM_E_INIT_FAILED;
    }
    
    for(i=0; i<GOLDENGATE_DEMO_MUX_CHIP_NUM; i++)
    {
        mux_dev_init(i);
    }
    
    mux_channel_select(0, GLB_MUX_CHANNEL0);
    mux_channel_select(1, GLB_MUX_CHANNEL1);

    _lcm_init_goldengate_demo_mux_chan();
    
    return LCM_E_SUCCESS;
}

/* Added by liuht for bug26671, 2014-02-14 */
static int32
_lcm_init_goldengate_demo_fan(void)
{
    int32 ret = 0;
    uint8 fan_module_idx;
    i2c_gen_t i2c_gen[GOLDENGATE_DEMO_FAN_MODULE_MAX];
    fan_chip_t fan_chip[GOLDENGATE_DEMO_FAN_MODULE_MAX];
    void *p_data[GOLDENGATE_DEMO_FAN_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = GOLDENGATE_DEMO_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 5;
    i2c_gen[0].addr = GOLDENGATE_DEMO_ADDR_FAN;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = ADT7470_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    fan_chip[0].chip_type = FAN_ADT7470;
    fan_chip[0].io_type = E_FAN_I2C;
    fan_chip[0].support_hot_swap = 0;  /* stable on GG mother board, do not support hot swap */
    p_data[0] = &i2c_gen[0];
    fan_chip[0].fan_num = 4;
    fan_chip[0].speed_adjust = 1;
    fan_chip[0].rpm = 15000;

    ret = fan_init(p_data, fan_chip, GOLDENGATE_DEMO_FAN_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Fan driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(fan_module_idx=0; fan_module_idx<GOLDENGATE_DEMO_FAN_MODULE_MAX; fan_module_idx++)
    {
        fan_dev_init(fan_module_idx);
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_psu(void)
{
    int32 ret;
    uint8 epld_idx[GOLDENGATE_DEMO_PSU_MODULE_MAX];
    i2c_gen_t i2c_gen[GOLDENGATE_DEMO_PSU_MODULE_MAX];
    psu_chip_t psu_chip[GOLDENGATE_DEMO_PSU_MODULE_MAX];
    psu_private_t p_data[GOLDENGATE_DEMO_PSU_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init psu module begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));
        
    epld_idx[0] = 0;
    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = GOLDENGATE_DEMO_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 3;
    i2c_gen[0].addr = GOLDENGATE_DEMO_ADDR0_PSU;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[0].chip_type = PSU_I2C_EPLD;
    psu_chip[0].io_type = PSU_IO_I2C_EPLD;
    psu_chip[0].psu_type = PSU_SHOW_FULL_STATUS;
    psu_chip[0].psu_mode_type = (1<<PSU_MODE_TYPE_REG_38_26_0d)|(1<<PSU_MODE_TYPE_REG_50_50_08)
                                |(1<<PSU_MODE_TYPE_REG_5b_9a_0a);
    p_data[0].p_data_i2c= &i2c_gen[0];
    p_data[0].p_data_epld= &epld_idx[0];

    epld_idx[1] = 0;
    i2c_gen[1].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[1].p_br.bridge_addr = GOLDENGATE_DEMO_I2C_BRIDGE_ADDR;
    i2c_gen[1].p_br.channel = 1;
    i2c_gen[1].addr = GOLDENGATE_DEMO_ADDR1_PSU;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[1].bridge_flag = 1;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[1].chip_type = PSU_I2C_EPLD;
    psu_chip[1].io_type = PSU_IO_I2C_EPLD;
    psu_chip[1].psu_type = PSU_SHOW_FULL_STATUS;
    psu_chip[1].psu_mode_type = (1<<PSU_MODE_TYPE_REG_38_26_0d)|(1<<PSU_MODE_TYPE_REG_50_50_08)
                                |(1<<PSU_MODE_TYPE_REG_5b_9a_0a);
    p_data[1].p_data_i2c= &i2c_gen[1];
    p_data[1].p_data_epld= &epld_idx[1]; 

    ret = psu_init(p_data, psu_chip, GOLDENGATE_DEMO_PSU_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Psu driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_goldengate_demo_eeprom(void)
{
    int32 ret = 0;
    i2c_gen_t i2c_gen[GOLDENGATE_DEMO_EEPROM_NUM];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = GOLDENGATE_DEMO_ADDR_EEPROM;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = EEPROM_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;

    ret = eeprom_init(i2c_gen, GOLDENGATE_DEMO_EEPROM_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm EEPROM init fail.");
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_phy(void)
{
    uint16 port_id;
    phy_info_t phyinfo;
    phy_handle_t** pphdl = NULL;
    glb_port_t* p_port;
    int32 ret;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy begin.");
    /* release GE phy */
    epld_item_write(0, EPLD_PHY_RST, 0x1);
    sal_delay(1);
    sal_memset(&phyinfo, 0, sizeof(phy_info_t));
    pphdl = (phy_handle_t**)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE,
        sizeof(phy_handle_t*)*(glb_card->port_num));

    if(NULL == pphdl)
    {
        LCM_LOG_ERR("LCM phy no memory.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < (glb_card->port_num); port_id++)
    {
        p_port = glb_card->pp_port[port_id];
        /*bug33327, this sequence is affected by port default speed 40G or 100G. */
        if(p_port->port_speed_ability & GLB_SUPPORT_SPEED_40G)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_40G;
        }
        else if(p_port->port_speed_ability & GLB_SUPPORT_SPEED_100G)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_100G;
        }
        else if(p_port->port_speed_ability & GLB_SUPPORT_SPEED_10G)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_10G;
        }
        else if(p_port->port_speed_ability & GLB_SUPPORT_SPEED_1G)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_1G;
        }

        phyinfo.phy_device_type = PORT_PHY_NULL;
        phyinfo.phy_manage_info.media_type = GLB_MEDIA_QSFP_PLUS;
        phyinfo.phy_manage_info.mac_if = GLB_MAC_INTERFACE_SERDES;
        
        phyinfo.phy_manage_info.duplex = GLB_DUPLEX_FULL;
        if (lcm_mgt_is_enable_stack())
        {
            phyinfo.port.port_info.port_id = GLB_TRANS_PORTID_TO_GPORT(
                    lcm_mgt_get_stack_member(), p_port->logic_port_idx);            
        }
        else
        {
            phyinfo.port.port_info.port_id = p_port->logic_port_idx;
        }
        phyinfo.port.port_info.lchip = p_port->local_chip_idx;
        phyinfo.port.port_info.serdes_id = p_port->chip_serdes_id;
        /* Modified by liuht for access port id in phy handle for bug 25808 */	
        phyinfo.port_num = port_id;


        /*********************************************************************
         * Default:
         * PHY_WORK_MODE_NORMAL GLB_LB_NONE GLB_SPEED_AUTO
         * GLB_DUPLEX_AUTO
         ********************************************************************/
        phyinfo.phy_manage_info.mode = PHY_WORK_MODE_NORMAL;
        phyinfo.phy_manage_info.lb_mode = GLB_LB_NONE;
        phyinfo.phy_manage_info.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl.recv= GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl_ability.asymmetric_pause = 0;
        phyinfo.phy_manage_info.flowctrl_ability.symmetric_pause = 0;

        phyinfo.phy_stat_flag.duplex = phyinfo.phy_manage_info.duplex;
        phyinfo.phy_stat_flag.speed = phyinfo.phy_manage_info.speed;
        phyinfo.phy_stat_flag.link_up = GLB_LINK_DOWN;
        phyinfo.phy_stat_flag.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_stat_flag.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        pphdl[port_id] = phy_dev_register(&phyinfo);
        if(NULL ==  pphdl[port_id])
        {
            LCM_LOG_ERR("Register phy handle failed\n");
            return LCM_E_INIT_FAILED;
        }
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm ready to init phy.");
    ret = phy_init(pphdl, (glb_card->port_num));
    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_goldengate_demo_i2c(void)
{
    int32 ret;

    sal_task_sleep(100);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus begin.");
    epld_item_write(0, EPLD_I2C_BRIDGE_RST, 0x1);
    epld_item_write(0, EPLD_GG_I2C_BRIDGE_RST, 0xf);

    epld_item_write(0, EPLD_MUX1_RST, 0x1);
    epld_item_write(0, EPLD_MUX2_RST, 0x1);
    
    ret = i2c_open(E_I2C_CPM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init i2c bus failed.");
        return LCM_E_HW_CLKGEN_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus end.");

    return LCM_E_SUCCESS;
}
int32
_lcm_goldengate_demo_cfg_dpll(void)
{
    int32 ret = 0;
    uint32 val;
    uint32 timeout = 20000;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm config ad9559 begin.");
    
    /* step 1 */
	ret += ad9559_write(0, 0x0a22, 0x01);
	ret += ad9559_write(0, 0x0a42, 0x01);
	
	/* step 2 */
	ret += ad9559_write(0, 0x0005, 0x01);
	
	/* step 3 */
	ret += ad9559_write(0, 0x0, 0x80);
	ret += ad9559_write(0, 0x4, 0x02);
	ret += ad9559_write(0, 0x5, 0x00);
	ret += ad9559_write(0, 0xa, 0x12);
	ret += ad9559_write(0, 0xb, 0x0f);
	ret += ad9559_write(0, 0xc, 0x02);
	ret += ad9559_write(0, 0xd, 0x00);
	ret += ad9559_write(0, 0xe, 0x01);
	ret += ad9559_write(0, 0xf, 0x00);
	
	ret += ad9559_write(0, 0x100, 0x00);
	ret += ad9559_write(0, 0x101, 0x00);
	//ret += ad9559_write(0, 0x102, 0x91);
	ret += ad9559_write(0, 0x102, 0x00);
	
	ret += ad9559_write(0, 0x103, 0x00);
	ret += ad9559_write(0, 0x104, 0x00);
	ret += ad9559_write(0, 0x105, 0x00);
	ret += ad9559_write(0, 0x106, 0x00);
	ret += ad9559_write(0, 0x107, 0x00);
	ret += ad9559_write(0, 0x108, 0x00);
	ret += ad9559_write(0, 0x109, 0x00);
	ret += ad9559_write(0, 0x10a, 0x00);
	ret += ad9559_write(0, 0x10b, 0x00);
	ret += ad9559_write(0, 0x10c, 0x00);
	
	//ret += ad9559_write(0, 0x10d, 0x00);
	ret += ad9559_write(0, 0x10d, 0x00);
	//ret += ad9559_write(0, 0x10e, 0x00);
	ret += ad9559_write(0, 0x10e, 0x00);
	
	ret += ad9559_write(0, 0x10f, 0x00);
	
	//ret += ad9559_write(0, 0x110, 0x00);
	ret += ad9559_write(0, 0x110, 0x00);
	//ret += ad9559_write(0, 0x111, 0x00);
	ret += ad9559_write(0, 0x111, 0x00);
	
	ret += ad9559_write(0, 0x112, 0x00);
	ret += ad9559_write(0, 0x200, 0x1e);
	ret += ad9559_write(0, 0x201, 0x01);
	ret += ad9559_write(0, 0x202, 0x43);
	ret += ad9559_write(0, 0x203, 0xde);
	ret += ad9559_write(0, 0x204, 0x13);
	ret += ad9559_write(0, 0x205, 0x32);
	ret += ad9559_write(0, 0x206, 0x00);
	ret += ad9559_write(0, 0x207, 0x00);
	                  
	/* step 4 */
	ret += ad9559_write(0, 0x0005, 0x01);
	
	/* step 5 */
	ret += ad9559_read(0, 0x0d01, &val);
    while ((1 != ((val >> 1) & 0x1)) && (timeout--))
    {
        ret += ad9559_read(0, 0x0d01, &val);
    }
    if (!timeout)
    {
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "LCM config AD9559 step 5 timeout!");
        return -1;
    }
	
	/* step 6 */
	/* For the outputs to toggle prior to DPLL phase or frequency lock */
	ret += ad9559_write(0, 0x0a20, 0x4 );
	ret += ad9559_write(0, 0x0a40, 0x4 );
	ret += ad9559_write(0, 0x0005, 0x01);
	
	
	/* step 7 */
	ret += ad9559_write(0, 0x300, 0x00);
	ret += ad9559_write(0, 0x301, 0x82);
	ret += ad9559_write(0, 0x302, 0x00);
	ret += ad9559_write(0, 0x303, 0x00);
	ret += ad9559_write(0, 0x304, 0x00);
	ret += ad9559_write(0, 0x305, 0xb4);
	ret += ad9559_write(0, 0x306, 0xc4);
	ret += ad9559_write(0, 0x307, 0x04);
	ret += ad9559_write(0, 0x308, 0x00);
	ret += ad9559_write(0, 0x309, 0x14);
	ret += ad9559_write(0, 0x30a, 0x00);
	ret += ad9559_write(0, 0x30b, 0x00);
	ret += ad9559_write(0, 0x30c, 0x0a);
	ret += ad9559_write(0, 0x30d, 0x00);
	ret += ad9559_write(0, 0x30e, 0x00);
       //ret += ad9559_write(0, 0x30f, 0x0a);
       ret += ad9559_write(0, 0x30f, 0x0a);
	//ret += ad9559_write(0, 0x310, 0x00);
	ret += ad9559_write(0, 0x310, 0x00);
	//ret += ad9559_write(0, 0x311, 0xbc);
	ret += ad9559_write(0, 0x311, 0xbc);//tmp from huj
	
	//ret += ad9559_write(0, 0x312, 0x02);
	ret += ad9559_write(0, 0x312, 0x02);//tmp from huj
	ret += ad9559_write(0, 0x313, 0x00);
	ret += ad9559_write(0, 0x314, 0x0a);
	ret += ad9559_write(0, 0x315, 0x0a);
	ret += ad9559_write(0, 0x316, 0xbc);
	ret += ad9559_write(0, 0x317, 0x02);
	ret += ad9559_write(0, 0x318, 0x00);
	ret += ad9559_write(0, 0x319, 0x0a);
	ret += ad9559_write(0, 0x31a, 0x0a);
	ret += ad9559_write(0, 0x320, 0x00);
	ret += ad9559_write(0, 0x321, 0x82);
	ret += ad9559_write(0, 0x322, 0x00);
	ret += ad9559_write(0, 0x323, 0x00);
	ret += ad9559_write(0, 0x324, 0x00);
	ret += ad9559_write(0, 0x325, 0xb4);
	ret += ad9559_write(0, 0x326, 0xc4);
	ret += ad9559_write(0, 0x327, 0x04);
	ret += ad9559_write(0, 0x328, 0x00);
	ret += ad9559_write(0, 0x329, 0x14);
	ret += ad9559_write(0, 0x32a, 0x00);
	ret += ad9559_write(0, 0x32b, 0x00);
	ret += ad9559_write(0, 0x32c, 0x0a);
	ret += ad9559_write(0, 0x32d, 0x00);
	ret += ad9559_write(0, 0x32e, 0x00);
	ret += ad9559_write(0, 0x32f, 0x0a);
	ret += ad9559_write(0, 0x330, 0x00);
	ret += ad9559_write(0, 0x331, 0xbc);
	ret += ad9559_write(0, 0x332, 0x02);
	ret += ad9559_write(0, 0x333, 0x00);
	ret += ad9559_write(0, 0x334, 0x0a);
	ret += ad9559_write(0, 0x335, 0x0a);
	ret += ad9559_write(0, 0x336, 0xbc);
	ret += ad9559_write(0, 0x337, 0x02);
	ret += ad9559_write(0, 0x338, 0x00);
	ret += ad9559_write(0, 0x339, 0x0a);
	ret += ad9559_write(0, 0x33a, 0x0a);
	ret += ad9559_write(0, 0x340, 0x00);
	ret += ad9559_write(0, 0x341, 0x32);
	ret += ad9559_write(0, 0x342, 0x04);
	ret += ad9559_write(0, 0x343, 0x00);
	ret += ad9559_write(0, 0x344, 0xca);
	ret += ad9559_write(0, 0x345, 0xf6);
	ret += ad9559_write(0, 0x346, 0x93);
	ret += ad9559_write(0, 0x347, 0x00);
	ret += ad9559_write(0, 0x348, 0x00);
	ret += ad9559_write(0, 0x349, 0x14);
	ret += ad9559_write(0, 0x34a, 0x00);
	ret += ad9559_write(0, 0x34b, 0x00);
	ret += ad9559_write(0, 0x34c, 0x0a);
	ret += ad9559_write(0, 0x34d, 0x00);
	ret += ad9559_write(0, 0x34e, 0x00);
	//ret += ad9559_write(0, 0x34f, 0x0a);
	ret += ad9559_write(0, 0x34f, 0x0a);
	ret += ad9559_write(0, 0x350, 0x00);
	ret += ad9559_write(0, 0x350, 0x00);
	//ret += ad9559_write(0, 0x351, 0xbc);
	ret += ad9559_write(0, 0x351, 0xbc);//tmp from huj
	
	//ret += ad9559_write(0, 0x352, 0x02);
	ret += ad9559_write(0, 0x352, 0x02);//tmp from huj
	ret += ad9559_write(0, 0x353, 0x00);
	ret += ad9559_write(0, 0x354, 0x0a);
	ret += ad9559_write(0, 0x355, 0x0a);
	ret += ad9559_write(0, 0x356, 0xbc);
	ret += ad9559_write(0, 0x357, 0x02);
	ret += ad9559_write(0, 0x358, 0x00);
	ret += ad9559_write(0, 0x359, 0x0a);
	ret += ad9559_write(0, 0x35a, 0x0a);
	ret += ad9559_write(0, 0x360, 0x00);
	ret += ad9559_write(0, 0x361, 0x32);
	ret += ad9559_write(0, 0x362, 0x04);
	ret += ad9559_write(0, 0x363, 0x00);
	ret += ad9559_write(0, 0x364, 0xca);
	ret += ad9559_write(0, 0x365, 0xf6);
	ret += ad9559_write(0, 0x366, 0x93);
	ret += ad9559_write(0, 0x367, 0x00);
	ret += ad9559_write(0, 0x368, 0x00);
	ret += ad9559_write(0, 0x369, 0x14);
	ret += ad9559_write(0, 0x36a, 0x00);
	ret += ad9559_write(0, 0x36b, 0x00);
	ret += ad9559_write(0, 0x36c, 0x0a);
	ret += ad9559_write(0, 0x36d, 0x00);
	ret += ad9559_write(0, 0x36e, 0x00);
	ret += ad9559_write(0, 0x36f, 0x0a);
	ret += ad9559_write(0, 0x370, 0x00);
	ret += ad9559_write(0, 0x371, 0xbc);
	ret += ad9559_write(0, 0x372, 0x02);
	ret += ad9559_write(0, 0x373, 0x00);
	ret += ad9559_write(0, 0x374, 0x0a);
	ret += ad9559_write(0, 0x375, 0x0a);
	ret += ad9559_write(0, 0x376, 0xbc);
	ret += ad9559_write(0, 0x377, 0x02);
	ret += ad9559_write(0, 0x378, 0x00);
	ret += ad9559_write(0, 0x379, 0x0a);
	ret += ad9559_write(0, 0x37a, 0x0a);
	ret += ad9559_write(0, 0x400, 0x23);
	ret += ad9559_write(0, 0x401, 0x15);
	ret += ad9559_write(0, 0x402, 0xc6);
	ret += ad9559_write(0, 0x403, 0x16);
	ret += ad9559_write(0, 0x404, 0x08);
	ret += ad9559_write(0, 0x405, 0x51);
	ret += ad9559_write(0, 0x406, 0xb8);
	ret += ad9559_write(0, 0x407, 0x02);
	ret += ad9559_write(0, 0x408, 0x3e);
	ret += ad9559_write(0, 0x409, 0x0a);
	ret += ad9559_write(0, 0x40a, 0x0b);
//	ret += ad9559_write(0, 0x40b, 0x0a);
//	ret += ad9559_write(0, 0x40c, 0x00);
	//ret += ad9559_write(0, 0x40b, 0xd0);
       ret += ad9559_write(0, 0x40b, 0x0a);
	//ret += ad9559_write(0, 0x40c, 0x07);
	ret += ad9559_write(0, 0x40c, 0x00);
	
	ret += ad9559_write(0, 0x40d, 0x00);
	ret += ad9559_write(0, 0x40e, 0x00);
	ret += ad9559_write(0, 0x40f, 0x00);
	ret += ad9559_write(0, 0x410, 0x00);
	ret += ad9559_write(0, 0x411, 0x00);
	ret += ad9559_write(0, 0x412, 0x00);
	ret += ad9559_write(0, 0x413, 0x00);
	ret += ad9559_write(0, 0x414, 0x00);
	ret += ad9559_write(0, 0x415, 0x00);
	ret += ad9559_write(0, 0x420, 0x81);
	ret += ad9559_write(0, 0x421, 0x11);
	ret += ad9559_write(0, 0x422, 0x47);
	ret += ad9559_write(0, 0x423, 0x00);
	ret += ad9559_write(0, 0x424, 0x02);
	ret += ad9559_write(0, 0x425, 0x00);
	ret += ad9559_write(0, 0x426, 0x00);
	ret += ad9559_write(0, 0x427, 0x10);
	ret += ad9559_write(0, 0x428, 0x04);
	ret += ad9559_write(0, 0x429, 0x00);
	ret += ad9559_write(0, 0x42a, 0x00);
	ret += ad9559_write(0, 0x42b, 0x10);
	ret += ad9559_write(0, 0x42c, 0x04);
	ret += ad9559_write(0, 0x42d, 0x00);
	ret += ad9559_write(0, 0x42e, 0x00);
	ret += ad9559_write(0, 0x440, 0x01);
	ret += ad9559_write(0, 0x441, 0xf4);
	ret += ad9559_write(0, 0x442, 0x01);
	ret += ad9559_write(0, 0x443, 0x00);
	ret += ad9559_write(0, 0x444, 0x85);
	ret += ad9559_write(0, 0x445, 0x07);
	ret += ad9559_write(0, 0x446, 0x00);
	ret += ad9559_write(0, 0x447, 0x08);
	ret += ad9559_write(0, 0x448, 0x00);
	ret += ad9559_write(0, 0x449, 0x00);
	ret += ad9559_write(0, 0x44a, 0x11);
	ret += ad9559_write(0, 0x44b, 0x00);
	ret += ad9559_write(0, 0x44c, 0x00);
	ret += ad9559_write(0, 0x44d, 0x01);
	ret += ad9559_write(0, 0x44e, 0xf4);
	ret += ad9559_write(0, 0x44f, 0x01);
	ret += ad9559_write(0, 0x450, 0x00);
	ret += ad9559_write(0, 0x451, 0x85);
	ret += ad9559_write(0, 0x452, 0x07);
	ret += ad9559_write(0, 0x453, 0x00);
	ret += ad9559_write(0, 0x454, 0x08);
	ret += ad9559_write(0, 0x455, 0x00);
	ret += ad9559_write(0, 0x456, 0x00);
	ret += ad9559_write(0, 0x457, 0x11);
	ret += ad9559_write(0, 0x458, 0x00);
	ret += ad9559_write(0, 0x459, 0x00);
	ret += ad9559_write(0, 0x45a, 0x01);
	ret += ad9559_write(0, 0x45b, 0xf4);
	ret += ad9559_write(0, 0x45c, 0x01);
	ret += ad9559_write(0, 0x45d, 0x00);
	ret += ad9559_write(0, 0x45e, 0x7b);
	ret += ad9559_write(0, 0x45f, 0x07);
	ret += ad9559_write(0, 0x460, 0x00);
	ret += ad9559_write(0, 0x461, 0x7c);
	ret += ad9559_write(0, 0x462, 0x00);
	ret += ad9559_write(0, 0x463, 0x00);
	ret += ad9559_write(0, 0x464, 0x31);
	ret += ad9559_write(0, 0x465, 0x02);
	ret += ad9559_write(0, 0x466, 0x00);
	ret += ad9559_write(0, 0x467, 0x01);
	ret += ad9559_write(0, 0x468, 0xf4);
	ret += ad9559_write(0, 0x469, 0x01);
	ret += ad9559_write(0, 0x46a, 0x00);
	ret += ad9559_write(0, 0x46b, 0x7b);
	ret += ad9559_write(0, 0x46c, 0x07);
	ret += ad9559_write(0, 0x46d, 0x00);
	ret += ad9559_write(0, 0x46e, 0x7c);
	ret += ad9559_write(0, 0x46f, 0x00);
	ret += ad9559_write(0, 0x470, 0x00);
	ret += ad9559_write(0, 0x471, 0x31);
	ret += ad9559_write(0, 0x472, 0x02);
	ret += ad9559_write(0, 0x473, 0x00);
	ret += ad9559_write(0, 0x500, 0x20);
	ret += ad9559_write(0, 0x501, 0x79);
	ret += ad9559_write(0, 0x502, 0xa6);
	ret += ad9559_write(0, 0x503, 0x15);
	ret += ad9559_write(0, 0x504, 0x08);
	ret += ad9559_write(0, 0x505, 0x51);
	ret += ad9559_write(0, 0x506, 0xb8);
	ret += ad9559_write(0, 0x507, 0x02);
	ret += ad9559_write(0, 0x508, 0x3e);
	ret += ad9559_write(0, 0x509, 0x0a);
	ret += ad9559_write(0, 0x50a, 0x0b);
//	ret += ad9559_write(0, 0x50b, 0x0a);
//	ret += ad9559_write(0, 0x50c, 0x00);
	//ret += ad9559_write(0, 0x50b, 0xd0);
	ret += ad9559_write(0, 0x50b, 0x0a);
	//ret += ad9559_write(0, 0x50c, 0x07);
	ret += ad9559_write(0, 0x50c, 0x00);
	ret += ad9559_write(0, 0x50d, 0x00);
	ret += ad9559_write(0, 0x50e, 0x00);
	ret += ad9559_write(0, 0x50f, 0x00);
	ret += ad9559_write(0, 0x510, 0x00);
	ret += ad9559_write(0, 0x511, 0x00);
	ret += ad9559_write(0, 0x512, 0x00);
	ret += ad9559_write(0, 0x513, 0x00);
	ret += ad9559_write(0, 0x514, 0x00);
	ret += ad9559_write(0, 0x515, 0x00);
	ret += ad9559_write(0, 0x520, 0x81);
	ret += ad9559_write(0, 0x521, 0x13);
	ret += ad9559_write(0, 0x522, 0x47);
	ret += ad9559_write(0, 0x523, 0x00);
	ret += ad9559_write(0, 0x524, 0x05);
	ret += ad9559_write(0, 0x525, 0x00);
	ret += ad9559_write(0, 0x526, 0x00);
	ret += ad9559_write(0, 0x527, 0x10);
	ret += ad9559_write(0, 0x528, 0x03);
	ret += ad9559_write(0, 0x529, 0x00);
	ret += ad9559_write(0, 0x52a, 0x00);
	ret += ad9559_write(0, 0x52b, 0x10);
	ret += ad9559_write(0, 0x52c, 0x09);
	ret += ad9559_write(0, 0x52d, 0x00);
	ret += ad9559_write(0, 0x52e, 0x00);
	ret += ad9559_write(0, 0x540, 0x01);
	ret += ad9559_write(0, 0x541, 0xf4);
	ret += ad9559_write(0, 0x542, 0x01);
	ret += ad9559_write(0, 0x543, 0x00);
	ret += ad9559_write(0, 0x544, 0x7f);
	ret += ad9559_write(0, 0x545, 0x07);
	ret += ad9559_write(0, 0x546, 0x00);
	ret += ad9559_write(0, 0x547, 0xa0);
	ret += ad9559_write(0, 0x548, 0x00);
	ret += ad9559_write(0, 0x549, 0x00);
	ret += ad9559_write(0, 0x54a, 0x73);
	ret += ad9559_write(0, 0x54b, 0x02);
	ret += ad9559_write(0, 0x54c, 0x00);
	ret += ad9559_write(0, 0x54d, 0x01);
	ret += ad9559_write(0, 0x54e, 0xf4);
	ret += ad9559_write(0, 0x54f, 0x01);
	ret += ad9559_write(0, 0x550, 0x00);
	ret += ad9559_write(0, 0x551, 0x7f);
	ret += ad9559_write(0, 0x552, 0x07);
	ret += ad9559_write(0, 0x553, 0x00);
	ret += ad9559_write(0, 0x554, 0xa0);
	ret += ad9559_write(0, 0x555, 0x00);
	ret += ad9559_write(0, 0x556, 0x00);
	ret += ad9559_write(0, 0x557, 0x73);
	ret += ad9559_write(0, 0x558, 0x02);
	ret += ad9559_write(0, 0x559, 0x00);
	ret += ad9559_write(0, 0x55a, 0x01);
	ret += ad9559_write(0, 0x55b, 0xf4);
	ret += ad9559_write(0, 0x55c, 0x01);
	ret += ad9559_write(0, 0x55d, 0x00);
	ret += ad9559_write(0, 0x55e, 0x89);
	ret += ad9559_write(0, 0x55f, 0x07);
	ret += ad9559_write(0, 0x560, 0x00);
	ret += ad9559_write(0, 0x561, 0x0a);
	ret += ad9559_write(0, 0x562, 0x00);
	ret += ad9559_write(0, 0x563, 0x00);
	ret += ad9559_write(0, 0x564, 0x13);
	ret += ad9559_write(0, 0x565, 0x00);
	ret += ad9559_write(0, 0x566, 0x00);
	ret += ad9559_write(0, 0x567, 0x01);
	ret += ad9559_write(0, 0x568, 0xf4);
	ret += ad9559_write(0, 0x569, 0x01);
	ret += ad9559_write(0, 0x56a, 0x00);
	ret += ad9559_write(0, 0x56b, 0x89);
	ret += ad9559_write(0, 0x56c, 0x07);
	ret += ad9559_write(0, 0x56d, 0x00);
	ret += ad9559_write(0, 0x56e, 0x0a);
	ret += ad9559_write(0, 0x56f, 0x00);
	ret += ad9559_write(0, 0x570, 0x00);
	ret += ad9559_write(0, 0x571, 0x13);
	ret += ad9559_write(0, 0x572, 0x00);
	ret += ad9559_write(0, 0x573, 0x00);
	ret += ad9559_write(0, 0x800, 0x24);
	ret += ad9559_write(0, 0x801, 0x8c);
	ret += ad9559_write(0, 0x802, 0x49);
	ret += ad9559_write(0, 0x803, 0x55);
	ret += ad9559_write(0, 0x804, 0xc9);
	ret += ad9559_write(0, 0x805, 0x7b);
	ret += ad9559_write(0, 0x806, 0x9c);
	ret += ad9559_write(0, 0x807, 0xfa);
	ret += ad9559_write(0, 0x808, 0x55);
	ret += ad9559_write(0, 0x809, 0xea);
	ret += ad9559_write(0, 0x80a, 0xe2);
	ret += ad9559_write(0, 0x80b, 0x57);
	ret += ad9559_write(0, 0x80c, 0x8c);
	ret += ad9559_write(0, 0x80d, 0xad);
	ret += ad9559_write(0, 0x80e, 0x4c);
	ret += ad9559_write(0, 0x80f, 0xf5);
	ret += ad9559_write(0, 0x810, 0xcb);
	ret += ad9559_write(0, 0x811, 0x73);
	ret += ad9559_write(0, 0x812, 0x24);
	ret += ad9559_write(0, 0x813, 0xd8);
	ret += ad9559_write(0, 0x814, 0x59);
	ret += ad9559_write(0, 0x815, 0xd2);
	ret += ad9559_write(0, 0x816, 0x8d);
	ret += ad9559_write(0, 0x817, 0x5a);
	ret += ad9559_write(0, 0xa00, 0x00);
	ret += ad9559_write(0, 0xa01, 0x00);
	ret += ad9559_write(0, 0xa02, 0x00);
	ret += ad9559_write(0, 0xa03, 0x00);
	ret += ad9559_write(0, 0xa04, 0x00);
	ret += ad9559_write(0, 0xa05, 0x00);
	ret += ad9559_write(0, 0xa06, 0x00);
	ret += ad9559_write(0, 0xa07, 0x00);
	ret += ad9559_write(0, 0xa08, 0x00);
	ret += ad9559_write(0, 0xa09, 0x00);
	ret += ad9559_write(0, 0xa0a, 0x00);
	ret += ad9559_write(0, 0xa0b, 0x00);
	ret += ad9559_write(0, 0xa0c, 0x00);
	ret += ad9559_write(0, 0xa0d, 0x00);
	ret += ad9559_write(0, 0xa0e, 0x00);
	ret += ad9559_write(0, 0xa20, 0x00);
	ret += ad9559_write(0, 0xa21, 0x00);
	ret += ad9559_write(0, 0xa22, 0x00);
	ret += ad9559_write(0, 0xa23, 0x00);
	ret += ad9559_write(0, 0xa24, 0x00);
	ret += ad9559_write(0, 0xa40, 0x00);
	ret += ad9559_write(0, 0xa41, 0x00);
	ret += ad9559_write(0, 0xa42, 0x00);
	ret += ad9559_write(0, 0xa43, 0x00);
	ret += ad9559_write(0, 0xa44, 0x00);
	ret += ad9559_write(0, 0xd00, 0x00);
	ret += ad9559_write(0, 0xd01, 0x00);
	ret += ad9559_write(0, 0xd02, 0x00);
	ret += ad9559_write(0, 0xd03, 0x00);
	ret += ad9559_write(0, 0xd04, 0x00);
	ret += ad9559_write(0, 0xd05, 0x00);
	ret += ad9559_write(0, 0xd08, 0x00);
	ret += ad9559_write(0, 0xd09, 0x00);
	ret += ad9559_write(0, 0xd0a, 0x00);
	ret += ad9559_write(0, 0xd0b, 0x00);
	ret += ad9559_write(0, 0xd0c, 0x00);
	ret += ad9559_write(0, 0xd0d, 0x00);
	ret += ad9559_write(0, 0xd0e, 0x00);
	ret += ad9559_write(0, 0xd0f, 0x00);
	ret += ad9559_write(0, 0xd10, 0x00);
	ret += ad9559_write(0, 0xd20, 0x00);
	ret += ad9559_write(0, 0xd21, 0x00);
	ret += ad9559_write(0, 0xd22, 0x00);
	ret += ad9559_write(0, 0xd23, 0x00);
	ret += ad9559_write(0, 0xd24, 0x00);
	ret += ad9559_write(0, 0xd25, 0x00);
	ret += ad9559_write(0, 0xd26, 0x00);
	ret += ad9559_write(0, 0xd27, 0x00);
	ret += ad9559_write(0, 0xd28, 0x00);
	ret += ad9559_write(0, 0xd29, 0x00);
	ret += ad9559_write(0, 0xd2a, 0x00);
	ret += ad9559_write(0, 0xd40, 0x00);
	ret += ad9559_write(0, 0xd41, 0x00);
	ret += ad9559_write(0, 0xd42, 0x00);
	ret += ad9559_write(0, 0xd43, 0x00);
	ret += ad9559_write(0, 0xd44, 0x00);
	ret += ad9559_write(0, 0xd45, 0x00);
	ret += ad9559_write(0, 0xd46, 0x00);
	ret += ad9559_write(0, 0xd47, 0x00);
	ret += ad9559_write(0, 0xd48, 0x00);
	ret += ad9559_write(0, 0xd49, 0x00);
	ret += ad9559_write(0, 0xd4a, 0x00);
	ret += ad9559_write(0, 0xe00, 0x00);
	ret += ad9559_write(0, 0xe01, 0x00);
	ret += ad9559_write(0, 0xe02, 0x00);
	ret += ad9559_write(0, 0xe03, 0x00);
	ret += ad9559_write(0, 0xe10, 0x98);
	ret += ad9559_write(0, 0xe11, 0x01);
	ret += ad9559_write(0, 0xe12, 0x00);
	ret += ad9559_write(0, 0xe13, 0x0e);
	ret += ad9559_write(0, 0xe14, 0x12);
	ret += ad9559_write(0, 0xe15, 0x01);
	ret += ad9559_write(0, 0xe16, 0x00);
	ret += ad9559_write(0, 0xe17, 0x07);
	ret += ad9559_write(0, 0xe18, 0x02);
	ret += ad9559_write(0, 0xe19, 0x00);
	ret += ad9559_write(0, 0xe1a, 0x80);
	ret += ad9559_write(0, 0xe1b, 0x1a);
	ret += ad9559_write(0, 0xe1c, 0x03);
	ret += ad9559_write(0, 0xe1d, 0x00);
	ret += ad9559_write(0, 0xe1e, 0x1a);
	ret += ad9559_write(0, 0xe1f, 0x03);
	ret += ad9559_write(0, 0xe20, 0x20);
	ret += ad9559_write(0, 0xe21, 0x1a);
	ret += ad9559_write(0, 0xe22, 0x03);
	ret += ad9559_write(0, 0xe23, 0x40);
	ret += ad9559_write(0, 0xe24, 0x1a);
	ret += ad9559_write(0, 0xe25, 0x03);
	ret += ad9559_write(0, 0xe26, 0x60);
	ret += ad9559_write(0, 0xe27, 0x15);
	ret += ad9559_write(0, 0xe28, 0x04);
	ret += ad9559_write(0, 0xe29, 0x00);
	ret += ad9559_write(0, 0xe2a, 0x0e);
	ret += ad9559_write(0, 0xe2b, 0x04);
	ret += ad9559_write(0, 0xe2c, 0x20);
	ret += ad9559_write(0, 0xe2d, 0x33);
	ret += ad9559_write(0, 0xe2e, 0x04);
	ret += ad9559_write(0, 0xe2f, 0x40);
	ret += ad9559_write(0, 0xe30, 0x15);
	ret += ad9559_write(0, 0xe31, 0x05);
	ret += ad9559_write(0, 0xe32, 0x00);
	ret += ad9559_write(0, 0xe33, 0x0e);
	ret += ad9559_write(0, 0xe34, 0x05);
	ret += ad9559_write(0, 0xe35, 0x20);
	ret += ad9559_write(0, 0xe36, 0x33);
	ret += ad9559_write(0, 0xe37, 0x05);
	ret += ad9559_write(0, 0xe38, 0x40);
	ret += ad9559_write(0, 0xe39, 0x17);
	ret += ad9559_write(0, 0xe3a, 0x08);
	ret += ad9559_write(0, 0xe3b, 0x00);
	ret += ad9559_write(0, 0xe3c, 0x0e);
	ret += ad9559_write(0, 0xe3d, 0x0a);
	ret += ad9559_write(0, 0xe3e, 0x00);
	ret += ad9559_write(0, 0xe3f, 0x04);
	ret += ad9559_write(0, 0xe40, 0x0a);
	ret += ad9559_write(0, 0xe41, 0x20);
	ret += ad9559_write(0, 0xe42, 0x04);
	ret += ad9559_write(0, 0xe43, 0x0a);
	ret += ad9559_write(0, 0xe44, 0x40);
	ret += ad9559_write(0, 0xe45, 0x80);
	ret += ad9559_write(0, 0xe46, 0xa0);
	ret += ad9559_write(0, 0xe47, 0xff);
	ret += ad9559_write(0, 0xe48, 0x00);
	ret += ad9559_write(0, 0xe49, 0x00);
	ret += ad9559_write(0, 0xe4a, 0x00);
	ret += ad9559_write(0, 0xe4b, 0x00);
	ret += ad9559_write(0, 0xe4c, 0x00);
	ret += ad9559_write(0, 0xe4d, 0x00);
	ret += ad9559_write(0, 0xe4e, 0x00);
	ret += ad9559_write(0, 0xe4f, 0x00);
	
	
	/* step 8 */
	ret += ad9559_write(0, 0x0a20, 0x2);
	ret += ad9559_write(0, 0x0a40, 0x2);
	
	/* step 9 */
	ret += ad9559_write(0, 0x0005, 0x1);
	
	/* step 10 */
	ret += ad9559_write(0, 0x0a22, 0x0);
	ret += ad9559_write(0, 0x0a42, 0x0);
	
	/* step 11 */
	ret += ad9559_write(0, 0x0005, 0x1);

#if 0/* step 12: enable DPLL interrupt */
    ret += ad9559_write(0, 0x0102, 0x90);
    ret += ad9559_write(0, 0x010d, 0x04);
    ret += ad9559_write(0, 0x010e, 0x60);
    ret += ad9559_write(0, 0x0110, 0x04);
    ret += ad9559_write(0, 0x0111, 0x60);

    ret += ad9559_write(0, 0x040b, 0xd0);
    ret += ad9559_write(0, 0x040c, 0x07);

    ret += ad9559_write(0, 0x050b, 0xd0);
    ret += ad9559_write(0, 0x050c, 0x07);
#endif 	
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm config ad9559 end, ret val: %d.", ret);
    
    return ret;
}
static int32
_lcm_init_goldengate_demo_dpll(void)
{
	spi_gen_t       spi_gen[GOLDENGATE_DEMO_DPLL_NUM];
	int32           ret = 0;

	LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init ad9559 begin.");
	spi_gen[0].spi_type = E_SPI_CPU;
	spi_gen[0].spi_info.spi_cpu_info.fd = goldengate_demo_dpll_spi_0_fd;
	spi_gen[0].spi_info.spi_cpu_info.chip_sel = SPI_CPU_CHIP_SEL_0;

	/* Reset DPLL */
    LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_SDPLL_RST, 0));
	usleep(10*1000);

	LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_SDPLL_RST, 1));
	usleep(100*1000);

	/* Init AD9559 */
	ret = ad9559_init(spi_gen, GOLDENGATE_DEMO_DPLL_NUM);
	if ( ret < 0 )
	{
		LCM_LOG_ERR("Lcm init ad9559 failed.");
		return LCM_E_HW_AD9559;
	}

    /* Config AD9559 to fit DUBLIN */
      LCM_IF_ERROR_RETURN(_lcm_goldengate_demo_cfg_dpll());
    
	LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init ad9559 end.");

	return LCM_E_SUCCESS;
}

static int32
_lcm_init_goldengate_demo_led(void)
{
    int32 ret = 0;
    led_info_t led_info[E_MAX_LED];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED begin.");
    sal_memset(led_info, 0, sizeof(led_info_t)*E_MAX_LED);

    /* Modified by liuht to support system led in E350-8T12X for bug 25677, 2013-12-09 */
    /* init sys led */
    led_info[E_SYS_LED].exist = 1;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].val = 0x5;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].val = 0xb;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].val = 0x5;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].val = 0x7;
    /* End of Merge */
    led_info[E_FAN_LED].exist = 1;
    led_info[E_FAN_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    led_info[E_PSU1_LED].exist = 1;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    led_info[E_IND_LED].exist = 1;
    led_info[E_IND_LED].led_para[E_LED_SYS_OFF].op_reg = EPLD_IND_LED;
    led_info[E_IND_LED].led_para[E_LED_SYS_OFF].val = 0x1;
    led_info[E_IND_LED].led_para[E_LED_SYS_ON].op_reg = EPLD_IND_LED;
    led_info[E_IND_LED].led_para[E_LED_SYS_ON].val = 0x0;
	
    ret = led_init(led_info);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init LEDs failed.");
        return LCM_E_HW_LED_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED end.");

    return LCM_E_SUCCESS;
}

/* slice0 output 24 bit:
 * bit0 -11:for first 12 40G led
 * bit12-19:for 8 combo SFP+ led
 * bit20-23:for 4 fan out led
 * slice1 output 16 bit:
 * bit0 -11:for last 12 40G led
 * bit12-15:for 4 fan out led
*/
static int32
_lcm_init_goldengate_demo_ctc_chip_led(void)
{
    uint8 split_flag=0;
    uint8 media_switch_flag=0;
    uint8 i;
    uint8 table_id;
    uint8 table_num;
    uint8 panel_port_id;
    uint8 src_pos, des_pos;
    uint8 port_id;
    uint16 logic_port_idx;
    mac_led_info_t mac_led_info;
    mac_led_api_para_t* p_mac_led_api_para;
    mac_led_api_para_t glb_lcm_goldengate_demo_mac_led[GOLDENGATE_DEMO_LED_TBL_NUM][GOLDENGATE_DEMO_LED_MAC_NUM];
    uint16 lcm_goldengate_demo_mac_led_split[GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init MAC LED begin.");

    for(port_id = 0; port_id < GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX; port_id++)
    {
        logic_port_idx = lcm_goldengate_demo_port_max[port_id].logic_port_idx;
        lcm_goldengate_demo_mac_led_split[port_id] = (logic_port_idx >= GG_SLICE1_BASE)? 
            (logic_port_idx - GG_SLICE1_BASE):logic_port_idx;
        /* Added by liuht for bug 33109, 2015-05-05 */
        /* conversion channel id to mac id */
        if(lcm_goldengate_demo_mac_led_split[port_id]>=40)
            lcm_goldengate_demo_mac_led_split[port_id] += 8;
    }
    
    split_flag = glb_card->split_flag;
    if(split_flag)
    {
        table_num = GOLDENGATE_DEMO_LED_TBL_NUM;
    }
    else
    {
        table_num = 1;
    }

    /* check any media switch port */
    if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP)
    {
        media_switch_flag = 1;
    }
    
    /* if any port split:
     * table0 : for fan out led : led0 force on and led1,2,3 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 1 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 1 mac of this port and port 1 40G led force off
     * table1 : for fan out led : led1 force on and led0,2,3 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 2 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 2 mac of this port and port 1 40G led force off
     * table2 : for fan out led : led2 force on and led0,1,3 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 3 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 3 mac of this port and port 1 40G led force off
     * table3 : for fan out led : led3 force on and led0,1,2 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 4 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 4 mac of this port and port 1 40G led force off
     * if no port split:
     * table0   : for fan out led  : all force off
     *          : for 40G port led : led status depend on 40G mac of this port
     *          : for 10G port led : all force off
     */
     /* MAC 56-59 can be used to force led on/off  */
    for(table_id=0; table_id < table_num; table_id++)
    {
        sal_memcpy(glb_lcm_goldengate_demo_mac_led[table_id], lcm_goldengate_demo_mac_led_default_entry, 
            sizeof(mac_led_api_para_t)*GOLDENGATE_DEMO_LED_MAC_NUM);

        for(panel_port_id=0; panel_port_id<GOLDENGATE_DEMO_PANEL_PORT_NUM; panel_port_id++)
        {
            if(GLB_PPT_NUMCHG_TYPE_10G == glb_card->pp_ppt[panel_port_id]->ppt_numchg_type)
            {
                if(panel_port_id<GOLDENGATE_DEMO_PANEL_PORT_NUM/2)
                {
                    des_pos = panel_port_id;
                }
                else
                {
                    des_pos = panel_port_id+8;  // skip combo port
                }
                src_pos = panel_port_id*4+table_id;
                p_mac_led_api_para = &glb_lcm_goldengate_demo_mac_led[table_id][des_pos];
                p_mac_led_api_para->port_id = lcm_goldengate_demo_mac_led_split[src_pos]; // skip gg slice
            }
        }

        /* When any port split, light on fan out LED periodically */
        if(split_flag)
        {
            for(i=0; i < GOLDENGATE_DEMO_LED_TBL_NUM; i++)
            {
                if(table_id == i)
                {
                    /* slice 0: channel 58 to force on fan out led
                     *          channel 57 to force off fan out led
                     * slice 1: channel 58 to force on fan out led
                     *          channel 57 to force off fan out led
                     */
                    src_pos = 16 + i;
                    glb_lcm_goldengate_demo_mac_led[table_id][src_pos].port_id = 58;
                    glb_lcm_goldengate_demo_mac_led[table_id][src_pos].mode= LED_MODE_1_FORCE_ON;
                    src_pos = 32 + i;
                    glb_lcm_goldengate_demo_mac_led[table_id][src_pos].port_id = 58;
                    glb_lcm_goldengate_demo_mac_led[table_id][src_pos].mode= LED_MODE_1_FORCE_ON;
                }
            }
        }

        if(media_switch_flag)
        {
            for(i=0; i < 4; i++)
            {
                src_pos = 12 + i;
                glb_lcm_goldengate_demo_mac_led[table_id][src_pos].port_id = lcm_goldengate_demo_combo_mac_led[i];
                glb_lcm_goldengate_demo_mac_led[table_id][src_pos].mode= LED_MODE_2_FORCE_OFF;
            }
            /* use channel 56 to force off port 1 40G led */
            glb_lcm_goldengate_demo_mac_led[table_id][0].port_id = 56;
            glb_lcm_goldengate_demo_mac_led[table_id][0].mode= LED_MODE_1_FORCE_OFF;
        }
    }

    mac_led_info.mac_led_api_para = (mac_led_api_para_t **)XCALLOC(CTCLIB_MEM_LCM_MODULE, 
        sizeof(mac_led_api_para_t*)*table_num);
    if(NULL == mac_led_info.mac_led_api_para)
    {
        LCM_LOG_ERR("alloc mac_led_api_para_t array fail.");
        return LCM_E_NO_MEMORY;
    }

    for(table_id = 0; table_id < table_num; table_id++)
    {
        mac_led_info.mac_led_api_para[table_id] = glb_lcm_goldengate_demo_mac_led[table_id];
    }
    mac_led_info.table_num = table_num;
    mac_led_info.mac_num = GOLDENGATE_DEMO_LED_MAC_NUM;
    mac_led_info.slice0_mac_num = GOLDENGATE_DEMO_SLICE0_LED_MAC_NUM;
    mac_led_info_register(&mac_led_info);
    led_mgt_port_led();

    XFREE(CTCLIB_MEM_LCM_MODULE, mac_led_info.mac_led_api_para);
    
    return LCM_E_SUCCESS;
}
int32
lcm_goldengate_demo_get_sum_ffe_cfg(lcm_chip_serdes_ffe_t* serdes_ffe)
{
    uint8 serdes_id;
    uint8 index;

    serdes_id = serdes_ffe->serdes_id;
        
    serdes_ffe->board_material = 1; /*M4*/
    
    if(serdes_id <4)
    {
        serdes_ffe->mode = CTC_CHIP_SERDES_FFE_MODE_DEFINE;             /* user-defined */
        if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP)
        {
            index = 8;
            serdes_ffe->c0 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][0];
            serdes_ffe->c1 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][1];
            serdes_ffe->c2 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][2];
            serdes_ffe->c3 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][3];
        }
        else
        {
            index = 0;
            serdes_ffe->c0 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][0];
            serdes_ffe->c1 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][1];
            serdes_ffe->c2 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][2];
            serdes_ffe->c3 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id][3];
        }
    }        
    else if((serdes_id <= 51)&&(serdes_id >= 48))
    {
        serdes_ffe->mode = CTC_CHIP_SERDES_FFE_MODE_DEFINE;             /* user-defined */
        index = 4;
        serdes_ffe->c0 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id-48][0];
        serdes_ffe->c1 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id-48][1];
        serdes_ffe->c2 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id-48][2];
        serdes_ffe->c3 = lcm_goldengate_demo_serdes_usrdef_coeff[index+serdes_id-48][3];
    }
    else
    {
        serdes_ffe->mode = CTC_CHIP_SERDES_FFE_MODE_TYPICAL;             /* typical */
        for(index=4; index<GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX-4; index++)
        {
            if(serdes_id == lcm_goldengate_demo_serdes_ffe_max[index].serdes_id)
            {                
                serdes_ffe->trace_len = lcm_goldengate_demo_serdes_ffe_max[index].trace_len;               
                return 0;
            }  
        }
        LCM_LOG_ERR("Lcm find serdes id %d failed", serdes_id);
        return -1;
    }        
    return 0;
}


int32
lcm_init_goldengate_demo_serdes(void)
{
    ctc_chip_serdes_polarity_t  polarity_param;
    ctc_chip_serdes_ffe_t serdes_ffe;
    uint8 serdes_id, serdes_start;
    uint8 index, index_start, index_end;
    int ret = 0;
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init serdes begin.");

    /* Set serdes 0,1,2,3 ffe */
    serdes_ffe.mode = CTC_CHIP_SERDES_FFE_MODE_DEFINE;                /* user define */
    serdes_start = 0;
    if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP)
    {
        index_start = 8;
        index_end = 11;
    }
    else
    {
        index_start = 0;
        index_end = 3;
    }

    for(index=index_start, serdes_id=serdes_start; index<=index_end; index++, serdes_id++)
    {
        serdes_ffe.serdes_id = serdes_id;
        serdes_ffe.coefficient[0] = lcm_goldengate_demo_serdes_usrdef_coeff[index][0];
        serdes_ffe.coefficient[1] = lcm_goldengate_demo_serdes_usrdef_coeff[index][1];
        serdes_ffe.coefficient[2] = lcm_goldengate_demo_serdes_usrdef_coeff[index][2];
        serdes_ffe.coefficient[3] = lcm_goldengate_demo_serdes_usrdef_coeff[index][3];
        ret = ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
        if (ret < 0)
        {
            LCM_LOG_ERR("LCM set serdes ffe parameter failed.\n");
            return LCM_E_INIT_FAILED;
        }  
    }

    /* Set serdes 48,49,50,51 ffe */
    serdes_ffe.mode = CTC_CHIP_SERDES_FFE_MODE_DEFINE;                 /* user define */
    serdes_start = 48;
    index_start = 4;
    index_end = 7;
    for(index=index_start, serdes_id=serdes_start; index<=index_end; index++, serdes_id++)
    {
        serdes_ffe.serdes_id = serdes_id;
        serdes_ffe.coefficient[0] = lcm_goldengate_demo_serdes_usrdef_coeff[index][0];
        serdes_ffe.coefficient[1] = lcm_goldengate_demo_serdes_usrdef_coeff[index][1];
        serdes_ffe.coefficient[2] = lcm_goldengate_demo_serdes_usrdef_coeff[index][2];
        serdes_ffe.coefficient[3] = lcm_goldengate_demo_serdes_usrdef_coeff[index][3];
        ret = ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
        if (ret < 0)
        {
            LCM_LOG_ERR("LCM set serdes ffe parameter failed.\n");
            return LCM_E_INIT_FAILED;
        }  
    }

    /* Set other serdes ffe */
    serdes_ffe.mode = CTC_CHIP_SERDES_FFE_MODE_TYPICAL;                 /* typical */
    serdes_ffe.board_material = 1;       /* M4 */
    for(index=4; index<GOLDENGATE_DEMO_PANEL_PORT_NUM_MAX-4; index++)
    {
        serdes_ffe.serdes_id = lcm_goldengate_demo_serdes_ffe_max[index].serdes_id;
        serdes_ffe.trace_len = lcm_goldengate_demo_serdes_ffe_max[index].trace_len;
        ret = ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
        if (ret < 0)
        {
            LCM_LOG_ERR("LCM set serdes ffe parameter failed.\n");
            return LCM_E_INIT_FAILED;
        }  
    }

    /* For SFP, there is no need of P/N swap for serdes 2 */
    if(g_goldengate_demo_combo_info.port_media_type == GLB_PORT_MEDIA_TYPE_SFP)
    {
        sal_memset(&polarity_param, 0, sizeof(ctc_chip_serdes_polarity_t));
        polarity_param.serdes_id = 2;
        polarity_param.polarity_mode = 0;
        polarity_param.dir = 1;
        ret = ctc_chip_set_property(0, CTC_CHIP_PEOP_SERDES_POLARITY, (void*)&polarity_param);
        if (ret < 0)
        {
            LCM_LOG_ERR("Set serdes %d polarity fail ret %d.\n", polarity_param.serdes_id, ret);
            return LCM_E_NO_MEMORY;
            return ret;
        }
    }

    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_serdes_mode());

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init serdes end.");
    
    return LCM_E_SUCCESS;
}

int32
lcm_init_goldengate_demo_cb(void)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback begin.");
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_fiber());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_phy());
    /* Added by qicx for E350 XG MAC LED, bug24348, 2013-08-13 */
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_ctc_chip_led());
    //LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_ctc_reset());
    /* Added by liuht for E350-8T12X to initialize serdes, 2013-11-21 */
    LCM_IF_ERROR_RETURN(lcm_init_goldengate_demo_serdes());
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback end.");

    return LCM_E_SUCCESS;
}

extern int32 lcm_port_init_ffe_cfg_callback(lcm_port_get_sum_ffe_cfg_callback_t func);
int32
lcm_init_goldengate_demo(glb_card_t* p_card)
{
    FILE *fp;
    char buf[BUFSIZ];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board begin.");
    glb_card = p_card;
    p_card->asic_chip_num = 1;
    p_card->chip_sensor_num = 1;

    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        sal_fgets (buf, BUFSIZ, fp);
        p_card->logic_slot_no = atoi(buf);
        p_card->phy_slot_no = p_card->logic_slot_no;
        sal_fclose(fp);
    }
    else
    {
        p_card->logic_slot_no = 1;
        p_card->phy_slot_no = 0;
    }

    p_card->logic_slot_no = 1;
    p_card->phy_slot_no = 0;

    p_card->panel_port_num = GOLDENGATE_DEMO_PANEL_PORT_NUM;
    p_card->l2switch_num = 0;
    p_card->sensor_num = GOLDENGATE_DEMO_SENSOR_NUM;
    if(p_card->chip_sensor_num+p_card->sensor_num > MAX_TMPR_SENSOR_NUM)
    {
        LCM_LOG_ERR("Sensor structure is too small to store sensor info on board.\n");        
        return LCM_E_NO_MEMORY;
    }
    p_card->fan_module_num = GOLDENGATE_DEMO_FAN_MODULE_MAX;
    p_card->psu_module_num = GOLDENGATE_DEMO_PSU_MODULE_MAX;
    //p_card->phy_interrupt_mode = GLB_PHY_INTERRUPT_MODE_EPLD;   /*get phy interrupt info from EPLD*/
    p_card->cpu_type = GLB_CPU_PPC_P1010;
    p_card->phy_chip_num = 0;

    /* for some board like e350 8t12xg don't support ptp, added by jcao for bug 25500, 2013-10-25 */
    p_card->ptp_en = 0;
    p_card->epld_type = GLB_EPLD_TYPE_VME;
    p_card->bootrom_type = E_BOOTROM_TYPE_512K;
    p_card->board_material_M4 = 1;
    sal_snprintf(p_card->cfg_profile_name, DATAPATH_LEN_MAX, "%s%s",
        DATAPATH_PROFILE_PATH, GOLDENDATE_24Q_DATAPATH_NAME);    

    _lcm_init_goldengate_demo_cpu_info();
    ctc_hw_fd_init();
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,
                  "card product type %x, board type %x.", p_card->board_type.series, p_card->board_type.type);
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_epld(p_card, p_card->epld_ver));
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_eeprom_info(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_led());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_i2c());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_dpll());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_eeprom());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_port(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_sensor());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_gpio());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_mux());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_fan());
    LCM_IF_ERROR_RETURN(_lcm_init_goldengate_demo_psu());
    
    LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_STACKING_LED, 0));
    
#ifdef BOOTUP_DIAG
    LCM_IF_ERROR_RETURN(lcm_common_parse_bootup_diag(p_card));
#endif

    lcm_card_init_callback(lcm_init_goldengate_demo_cb);
    lcm_port_init_ffe_cfg_callback(lcm_goldengate_demo_get_sum_ffe_cfg);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board end.");

    return LCM_E_SUCCESS;
}
