/****************************************************************************
* $Id$
*  GreatBelt demo board init functions
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Chenxi Qi
* Date          : 2012-10-25
* Reason        : First Create.
****************************************************************************/
#ifndef _GLB_UML_SYSTEM_
/****************************************************************************
 *
* Header Files
* 
****************************************************************************/
#include "sal_common.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "lcm_log.h"
#include "lcm_card.h"
#include "ctc_pci.h"
#include "ctc_spi.h"
#include "ctc_i2c.h"
#include "epld_api.h"
#include "fpga_api.h"
#include "ad9517_api.h"
#include "phy_api.h"
#include "l2switch_api.h"
#include "l2switch_vsc7395_drv.h"
#include "fiber_api.h"
#include "sensor_api.h"
#include "fan_api.h"
#include "eeprom_api.h"
#include "led_api.h"
#include "lcm_mgt.h"
#include "vsc3308_api.h"
#include "ds3104_api.h"
#ifdef BOOTUP_DIAG
#include "diag_types.h"
#endif
#include "ctc_api.h"
#include "ctc_chip.h"

#include "glb_distribute_system_define.h"
#include "glb_if_define.h"
/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/
//#define CLK_GEN_SPI_BASE     0xd00
//#define CLK_GEN_SPI_BUSY     0x01000000

#define GREATBELT_DEMO_L2SWITCH_NUM          0x01

#define GREATBELT_DEMO_SENSOR_NUM            0x06
#define GREATBELT_DEMO_ADDR_SENSOR0          0x48
#define GREATBELT_DEMO_ADDR_SENSOR1          0x49
#define GREATBELT_DEMO_ADDR_SENSOR2          0x4A
#define GREATBELT_DEMO_ADDR_SENSOR3          0x4B
#define GREATBELT_DEMO_ADDR_SENSOR4          0x48
#define GREATBELT_DEMO_ADDR_SENSOR5          0x49

#define GREATBELT_DEMO_FAN_MODULE_MAX        0x00
#define GREATBELT_DEMO_PSU_MODULE_MAX        0x00

#define GREATBELT_DEMO_ADDR_MB_VSC3308       0x07
#define GREATBELT_DEMO_ADDR_SLOT0_VSC3308    0x04
#define GREATBELT_DEMO_ADDR_SLOT1_VSC3308    0x05

#define GREATBELT_DEMO_EEPROM_NUM            0x01
#define GREATBELT_DEMO_ADDR_EEPROM           0x57

#define GREATBELT_DEMO_L2SWICH_PORT_SIZE     0x07

#define GREATBELT_DEMO_MIN_INTERNAL_PHY_ADDR    6  /* should be adapted per board */
#define GREATBELT_DEMO_LAST_INTERNAL_PHY_ADDR   7

#define GREATBELT_DEMO_PORT_NUM_PER_PHY_CHIP    8
#define GREATBELT_DEMO_PORT_NUM_PER_SLOT_CARD  16

#define GREATBELT_DEMO_DS3104_NUM            0x3

#define GREATBELT_DEMO_PHY_INT_BITS_SUM 24  /*Three epld register, 8*3=24 */
/****************************************************************************
*
* Global and Declarations  
*
****************************************************************************/
static const glb_card_t* glb_card;
int32 spi_1_fd = 0;


extern int32 lcm_card_init_callback(card_init_callback_t func);

#define GLB_GG_DEMO_24XLG_MAX_PORT 24

#define GLB_GG_DEMO_48XG_6XLG_MAX_PORT 48+6
 
#define GLB_GG_SLOT_CARD_24XLG 1
#define GLB_GG_SLOT_CARD_48XG_6XLG 2


/*24XLG*/
lcm_card_port_t lcm_gg_emulation_24xlg_port[GLB_GG_DEMO_24XLG_MAX_PORT ] = 
{
    {0, 0, 0},      /* Port  1 <->  XLG MAC 0 */
    {0, 4, 4},      /* Port  2 <->  XLG MAC 4 */
    {0, 8, 8},      /* Port  3 <->  XLG MAC 8 */
    {0, 12, 12},    /* Port  4 <->  XLG MAC 12 */
    {0, 16, 16},    /* Port  5 <->  XLG MAC 16 */
    {0, 20, 20},    /* Port  6 <->  XLG MAC 20 */
    {0, 24, 24},    /* Port  7 <->  XLG MAC 24 */
    {0, 28, 28},    /* Port  8 <->  XLG MAC 28 */
    {0, 32, 32},    /* Port  9 <->  XLG MAC 32 */
    {0, 36, 36},    /* Port  10 <->  XLG MAC 36 */
    {0, 40, 40},    /* Port  11 <->  XLG MAC 40 */
    {0, 44, 44},    /* Port  12 <->  XLG MAC 44 */


    {0, 64, 64},     /* Port  13 <->  XLG MAC 0 */
    {0, 68, 68},    /* Port  14 <->  XLG MAC 4 */
    {0, 72, 72},    /* Port  15 <->  XLG MAC 8 */
    {0, 76, 76},    /* Port  16 <->  XLG MAC 12 */
    {0, 80, 80},    /* Port  17 <->  XLG MAC 16 */
    {0, 84, 84},    /* Port  18 <->  XLG MAC 20 */
    {0, 88, 88},    /* Port  19 <->  XLG MAC 24 */
    {0, 92, 92},    /* Port  20 <->  XLG MAC 28 */
    {0, 96, 96},    /* Port  21 <->  XLG MAC 32 */
    {0, 100, 100},    /* Port  22 <->  XLG MAC 36 */
    {0, 104, 104},    /* Port  23 <->  XLG MAC 40 */
    {0, 108, 108},    /* Port  24 <->  XLG MAC 44 */  
};

/*48XG + 6XLG*/
lcm_card_port_t lcm_gg_emulation_48xg_6xlg_port[GLB_GG_DEMO_48XG_6XLG_MAX_PORT ] = 
{
    {0, 0, 0},      /* Port  1 <->  XG MAC 0 */
    {0, 1, 1},      /* Port  2 <->  XG MAC 1 */
    {0, 2, 2},      /* Port  3 <->  XG MAC 2*/
    {0, 3, 3},    /* Port  4 <->  XG MAC 3*/
    {0, 4, 4},    /* Port  5 <->  XG MAC 4*/
    {0, 5, 5},    /* Port  6 <->  XG MAC 5*/
    {0, 6, 6},    /* Port  7 <->  XG MAC 6*/
    {0, 7, 7},    /* Port  8 <->  XG MAC 7*/
        
    {0, 8, 8},    /* Port  9 <->  XG MAC 8*/        
    {0, 9, 9},    /* Port  10 <->  XG MAC 9*/
    {0, 10, 10},    /* Port  11 <->  XG MAC 10 */
    {0, 11, 11},    /* Port  12 <->  XG MAC 11*/
    {0, 12, 12},    /* Port  13 <->  XG MAC 12*/
    {0, 13, 13},    /* Port  14 <->  XG MAC 13*/
    {0, 14, 14},    /* Port  15 <->  XG MAC 14*/
    {0, 15, 15},    /* Port  16 <->  XG MAC 15*/

    {0, 16, 16},    /* Port  17 <->  XG MAC 16*/        
    {0, 17, 17},    /* Port  18 <->  XG MAC 17*/
    {0, 18, 18},    /* Port  19 <->  XG MAC 18*/
    {0, 19, 19},    /* Port  20 <->  XG MAC 19*/
    {0, 20, 20},    /* Port  21 <->  XG MAC 20*/
    {0, 21, 21},    /* Port  22 <->  XG MAC 21*/
    {0, 22, 22},    /* Port  23 <->  XG MAC 22*/
    {0, 23, 23},    /* Port  24 <->  XG MAC 23*/

    {0, 24, 24},    /* Port  25 <->  XLG MAC 24 */        
    {0, 28, 28},    /* Port  26 <->  XLG MAC 28 */
    {0, 32, 32},    /* Port  27 <->  XLG MAC 32 */
    
    {0, 48, 48},      /* Port  28 <->  XG MAC 0 */
    {0, 49, 49},      /* Port  29 <->  XG MAC 1 */
    {0, 50, 50},      /* Port  30 <->  XG MAC 2*/
    {0, 51, 51},    /* Port  31 <->  XG MAC 3*/
    {0, 52, 52},    /* Port  32 <->  XG MAC 4*/
    {0, 53, 53},    /* Port  33 <->  XG MAC 5*/
    {0, 54, 54},    /* Port  34 <->  XG MAC 6*/
    {0, 55, 55},    /* Port  35 <->  XG MAC 7*/
        
    {0, 56, 56},    /* Port  36 <->  XG MAC 8*/        
    {0, 57, 57},    /* Port  37 <->  XG MAC 9*/
    {0, 58, 58},    /* Port  38 <->  XG MAC 10 */
    {0, 59, 59},    /* Port  39 <->  XG MAC 11*/
    {0, 60, 60},    /* Port  40 <->  XG MAC 12*/
    {0, 61, 61},    /* Port  41 <->  XG MAC 13*/
    {0, 62, 62},    /* Port  42 <->  XG MAC 14*/
    {0, 63, 63},    /* Port  43 <->  XG MAC 15*/

    {0, 64, 64},    /* Port  44 <->  XG MAC 16*/        
    {0, 65, 65},    /* Port  45 <->  XG MAC 17*/
    {0, 66, 66},    /* Port  46 <->  XG MAC 18*/
    {0, 67, 67},    /* Port  47 <->  XG MAC 19*/
    {0, 68, 68},    /* Port  48 <->  XG MAC 20*/
    {0, 69, 69},    /* Port  49 <->  XG MAC 21*/
    {0, 70, 70},    /* Port  50 <->  XG MAC 22*/
    {0, 71, 71},    /* Port  51 <->  XG MAC 23*/

    {0, 72, 72},    /* Port  52 <->  XLG MAC 24 */        
    {0, 76, 76},    /* Port  53 <->  XLG MAC 28 */
    {0, 80, 80},    /* Port  54 <->  XLG MAC 32 */    
    
};


fiber_port_info_t lcm_gg_emulation_48xg_6xlg_fiber[GLB_GG_DEMO_48XG_6XLG_MAX_PORT] = 
{
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1},    

};

fiber_port_info_t lcm_gg_emulation_24xlg_fiber[GLB_GG_DEMO_24XLG_MAX_PORT] = 
{
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
    };


uint8 g_l2switch_port_down_greatbelt_demo[GREATBELT_DEMO_L2SWICH_PORT_SIZE] = {-1,0,0,0,0,0,0};

/* Setup port map for board */
vtss_mapped_port_t g_l2switch_port_map_greatbelt_demo[GREATBELT_DEMO_L2SWICH_PORT_SIZE] = 
{ 
    { -1,                     -1,     -1 }       /* unused */,
    {  0, VTSS_MIIM_CONTROLLER_0,      0 },      /* L2Switch RJ45 */
    {  1, VTSS_MIIM_CONTROLLER_0,      1 },      /* Link to VSC8211/GreatBelt chip */
    {  2, VTSS_MIIM_CONTROLLER_0,      2 },
    {  3, VTSS_MIIM_CONTROLLER_0,      3 },
    {  4, VTSS_MIIM_CONTROLLER_0,      4 },
    {  6, VTSS_MIIM_CONTROLLER_NONE,  -1 }       /* Link to CPU thru RGMII */
};

vtss_speed_t g_port_speed_greatbelt_demo[GREATBELT_DEMO_L2SWICH_PORT_SIZE] = 
{
    VTSS_SPEED_UNDEFINED,
    VTSS_SPEED_1G,             /* L2Switch RJ45 */
    VTSS_SPEED_1G,             /* Link to VSC8211/GreatBelt chip */
    VTSS_SPEED_1G,
    VTSS_SPEED_1G,
    VTSS_SPEED_1G,
    VTSS_SPEED_100M              /* Link to CPU thru RGMII */
};

vtss_port_interface_t g_port_interface_greatbelt_demo[GREATBELT_DEMO_L2SWICH_PORT_SIZE] = 
{
    VTSS_PORT_INTERFACE_NO_CONNECTION,
    VTSS_PORT_INTERFACE_INTERNAL,      /* L2Switch RJ45 */
    VTSS_PORT_INTERFACE_INTERNAL,      /* Link to VSC8211/GreatBelt chip */
    VTSS_PORT_INTERFACE_INTERNAL,
    VTSS_PORT_INTERFACE_INTERNAL,
    VTSS_PORT_INTERFACE_INTERNAL,
    VTSS_PORT_INTERFACE_MII          /* Link to CPU thru RGMII */
};

/****************************************************************************
 *
* Function
* 
****************************************************************************/ 

static int32
_lcm_init_greatbelt_cpu_info()
{
    FILE * fp;

    fp = sal_fopen(GLB_CPU_IF_INFO_FILE, "w+");
    if(fp ==NULL)
    {
        LCM_LOG_ERR("Open cpu info file error.");
        return LCM_E_FILE_OPEN;
    }
    sal_fprintf(fp, "MGMT_IF eth1\n");
    sal_fprintf(fp, "CPU_IF NOTUSE\n");
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_greatbelt_demo_port(glb_card_t* p_card)
{
    int32 port_id;

    /* alloc ports */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port begin.");

    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }
        
        p_card->pp_port[port_id]->p_fiber = NULL;
        p_card->pp_port[port_id]->is_combo = 0;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = 1;
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
        /*Fix bug 14686. jqiu 2011-06-15*/
        p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_id+1;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 1;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_cfg.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        
        p_card->pp_port[port_id]->port_status.link_up = GLB_LINK_DOWN;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_FULL;
        p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_1G;        
        p_card->pp_port[port_id]->port_status.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_status.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->poe_support = NOT_POE_PORT;
        p_card->pp_port[port_id]->is_combo_to = 0;  /* No combo ports */

 
        if (p_card->slot_card_type == GLB_GG_SLOT_CARD_24XLG)  /* 24xlg */            
        {
            p_card->pp_port[port_id]->logic_port_idx = lcm_gg_emulation_24xlg_port[port_id].logic_port_idx;
            p_card->pp_port[port_id]->local_chip_idx = lcm_gg_emulation_24xlg_port[port_id].chip_idx;
            p_card->pp_port[port_id]->mac_idx = lcm_gg_emulation_24xlg_port[port_id].mac_idx;
            p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
            p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
            p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
            
        }
        else if (p_card->slot_card_type == GLB_GG_SLOT_CARD_48XG_6XLG)  /* 48 + 6 */
        {
            p_card->pp_port[port_id]->logic_port_idx = lcm_gg_emulation_48xg_6xlg_port[port_id].logic_port_idx;
            p_card->pp_port[port_id]->local_chip_idx = lcm_gg_emulation_48xg_6xlg_port[port_id].chip_idx;
            p_card->pp_port[port_id]->mac_idx = lcm_gg_emulation_48xg_6xlg_port[port_id].mac_idx;
            p_card->pp_port[port_id]->lp_support = 0;
            if (port_id < 24)  
            {
                p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
                p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
                p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
            }
            else if(port_id >= 24
                    && port_id < 27)
            {
                /*Fix bug 14686. jqiu 2011-06-15*/
                p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
                p_card->pp_port[port_id]->panel_port_no = port_id+1;
                p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
                p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
                p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
            }
            else if(port_id >= 27
                    && port_id < 51)
            {
                /*Fix bug 14686. jqiu 2011-06-15*/
                p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
                p_card->pp_port[port_id]->panel_port_no = port_id+1;
                p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
                p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
                p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
            }
            else 
            {
                p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
                p_card->pp_port[port_id]->panel_port_no = port_id+1;
                p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
                p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
                p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
            }
        }
        else
        {
            LCM_LOG_ERR("Slot card type %d is error for port id %d.", p_card->slot_card_type, port_id);
        }
    } 
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port end.");

    return LCM_E_SUCCESS;
}

static int32_t
_lcm_reg_greatbelt_demo_epld(uint8 hw_ver, epld_info_t * p_epld_info)
{
    p_epld_info->base_addr = epld_localbus_addr_get();
    p_epld_info->epld_bus_type = EPLD_LOCALBUS_TYPE;
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_greatbelt_demo_epld(glb_card_t* p_card, uint8 epld_version)
{
    epld_info_t *p_epld_info = NULL;
    int32 ret = 0;
    epld_para_t  epld_para;
    uint32 value;

    p_epld_info = epld_get_info(&p_card->board_type, epld_version);
    if (!p_epld_info)
    {
        LCM_LOG_ERR("Get EPLD info fail.");
        return LCM_E_INVALID_PTR;
    }

    _lcm_reg_greatbelt_demo_epld(p_card->hw_ver, p_epld_info);
    ret = epld_init(p_epld_info);
    if (0 != ret)
    {
        LCM_LOG_ERR("EPLD Init fail.");
        return LCM_E_INIT_FAILED;
    }


//########  reboot: 
//
//
//#########################
//# sdk&cmodel use
//#####################
//lcsh
//
//# set internal clock & logic reset signal
//# write epld 0 0x20002 0xe7
//
//# release clock reset 
//write epld 0 0x20002 0xef
    epld_para.addr = 0x20002;
    epld_para.val = 0xef;
    epld_write(0, &epld_para);

//
//# release logic reset
//write epld 0 0x20002 0xff
    epld_para.addr = 0x20002;
    epld_para.val = 0xff;
    epld_write(0, &epld_para);

//
//
//###########################
//#expect value is 0xd
//read chip shim 3 0x8018
//read chip shim 4 0x8018
    epld_shim_read(0, 3, 0x8018, &value);
    epld_shim_read(0, 4, 0x8018, &value);

//
//#reset macshim reset
//read epld 0 0x2000b
    epld_write(0, &epld_para);
//write epld 0 0x2000b 0xfd
    epld_para.addr = 0x2000b;
    epld_para.val = 0xfd;
    epld_write(0, &epld_para);

//write epld 0 0x2000b 0xff
    epld_para.addr = 0x2000b;
    epld_para.val = 0xff;
    epld_write(0, &epld_para);

//
//##############################
//#config macshim vlan id
//write chip shim 3 0x106c4 0x003000
    epld_shim_write(0, 3, 0x106c4, 0x003000);

//write chip shim 3 0x206c4 0x003410
    epld_shim_write(0, 3, 0x206c4, 0x003410);
//write chip shim 3 0x306c4 0x3c3820
    epld_shim_write(0, 3, 0x306c4, 0x3c3820);

//write chip shim 3 0x406c4 0x3e3a28
    epld_shim_write(0, 3, 0x406c4, 0x3e3a28);
//
//read chip shim 3 0x106c4
    epld_shim_read(0, 3, 0x106c4, &value);

//read chip shim 3 0x206c4
    epld_shim_read(0, 3, 0x206c4, &value);

//read chip shim 3 0x306c4
    epld_shim_read(0, 3, 0x206c4, &value);

//read chip shim 3 0x406c4
    epld_shim_read(0, 3, 0x206c4, &value);

//
//############
//write chip shim 4 0x106c4 0x003000
    epld_shim_write(0, 4, 0x106c4, 0x003000);

//write chip shim 4 0x206c4 0x003410
    epld_shim_write(0, 4, 0x206c4, 0x003410);

//write chip shim 4 0x306c4 0x3c3820
    epld_shim_write(0, 4, 0x306c4, 0x3c3820);

//write chip shim 4 0x406c4 0x3e3a28
    epld_shim_write(0, 4, 0x406c4, 0x3e3a28);

//
//read chip shim 4 0x106c4
    epld_shim_read(0, 4, 0x106c4, &value);

//read chip shim 4 0x206c4
    epld_shim_read(0, 4, 0x206c4, &value);

//read chip shim 4 0x306c4
    epld_shim_read(0, 4, 0x306c4, &value);

//read chip shim 4 0x406c4
    epld_shim_read(0, 4, 0x406c4, &value);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init epld end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_greatbelt_demo_sensor(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[GREATBELT_DEMO_SENSOR_NUM];
    sensor_chip_t sensor_chip[GREATBELT_DEMO_SENSOR_NUM];
    void *p_data[GREATBELT_DEMO_SENSOR_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));
   
    i2c_gen[0].addr = GREATBELT_DEMO_ADDR_SENSOR0;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = LM77_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_1;
    sensor_chip[0].chip_type = SENSOR_LM77;
    sensor_chip[0].io_type = SENSOR_I2C;
   
    i2c_gen[1].addr = GREATBELT_DEMO_ADDR_SENSOR1;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].alen = LM77_OFFSET_WIDTH;
    i2c_gen[1].bridge_flag = 0;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_1;
    sensor_chip[1].chip_type = SENSOR_LM77;
    sensor_chip[1].io_type = SENSOR_I2C;
    
    i2c_gen[2].addr = GREATBELT_DEMO_ADDR_SENSOR2;
    i2c_gen[2].i2c_type = E_I2C_CPM;
    i2c_gen[2].alen = LM77_OFFSET_WIDTH;
    i2c_gen[2].bridge_flag = 0;
    i2c_gen[2].i2c_bus_idx = GLB_I2C_IDX_1;
    sensor_chip[2].chip_type = SENSOR_LM77;
    sensor_chip[2].io_type = SENSOR_I2C;

    i2c_gen[3].addr = GREATBELT_DEMO_ADDR_SENSOR3;
    i2c_gen[3].i2c_type = E_I2C_CPM;
    i2c_gen[3].alen = LM77_OFFSET_WIDTH;
    i2c_gen[3].bridge_flag = 0;
    i2c_gen[3].i2c_bus_idx = GLB_I2C_IDX_1;
    sensor_chip[3].chip_type = SENSOR_LM77;
    sensor_chip[3].io_type = SENSOR_I2C;

    i2c_gen[4].addr = GREATBELT_DEMO_ADDR_SENSOR4;
    i2c_gen[4].i2c_type = E_I2C_CPM;
    i2c_gen[4].alen = LM77_OFFSET_WIDTH;
    i2c_gen[4].bridge_flag = 0;
    i2c_gen[4].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[4].chip_type = SENSOR_LM77;
    sensor_chip[4].io_type = SENSOR_I2C;

    i2c_gen[5].addr = GREATBELT_DEMO_ADDR_SENSOR5;
    i2c_gen[5].i2c_type = E_I2C_CPM;
    i2c_gen[5].alen = LM77_OFFSET_WIDTH;
    i2c_gen[5].bridge_flag = 0;
    i2c_gen[5].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[5].chip_type = SENSOR_LM77;
    sensor_chip[5].io_type = SENSOR_I2C;

    for(i=0; i<GREATBELT_DEMO_SENSOR_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = sensor_init(p_data, sensor_chip, GREATBELT_DEMO_SENSOR_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Temperature sensor init fail.");
        return LCM_E_INIT_FAILED;
    }    
    for(i=0; i<GREATBELT_DEMO_SENSOR_NUM; i++)
    {
        sensor_dev_init(i);
    }
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_greatbelt_demo_phy(void)
{
    uint16 port_id;
    phy_info_t phyinfo;
    phy_handle_t** pphdl = NULL;
    int32 ret;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy begin.");

    sal_memset(&phyinfo, 0, sizeof(phy_info_t));
    pphdl = (phy_handle_t**)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE,
        sizeof(phy_handle_t*)*(glb_card->port_num));

    if(NULL == pphdl)
    {
        LCM_LOG_ERR("LCM phy no memory.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < (glb_card->port_num); port_id++)
    {
        phyinfo.phy_device_type = PORT_PHY_NULL; /* No phy on board */

        phyinfo.port_num = port_id;
        
        phyinfo.led_type = GLB_PHY_LED_DEFAULT;


        /*********************************************************************
         * Default:   
         * PHY_WORK_MODE_NORMAL GLB_LB_NONE GLB_SPEED_AUTO
         * GLB_DUPLEX_AUTO
         ********************************************************************/
        phyinfo.phy_manage_info.mode = PHY_WORK_MODE_NORMAL;
        phyinfo.phy_manage_info.lb_mode = GLB_LB_NONE;

        phyinfo.phy_manage_info.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl.recv= GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl_ability.asymmetric_pause = 0;
        phyinfo.phy_manage_info.flowctrl_ability.symmetric_pause = 0;

        phyinfo.phy_stat_flag.duplex = phyinfo.phy_manage_info.duplex;
        phyinfo.phy_stat_flag.speed = phyinfo.phy_manage_info.speed;
        phyinfo.phy_stat_flag.link_up = GLB_LINK_DOWN;
        phyinfo.phy_stat_flag.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_stat_flag.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_stat_flag.linkup_media = GLB_PORT_TYPE_FIBER;

        pphdl[port_id] = phy_dev_register(&phyinfo);
        if(NULL ==  pphdl[port_id])
        {
            LCM_LOG_ERR("Register phy handle failed\n");
            return LCM_E_INIT_FAILED;
        }
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm ready to init phy.");
    ret = phy_init(pphdl, glb_card->port_num);
    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy end.");

    return LCM_E_SUCCESS;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm ready to init phy.");
    ret = phy_init(pphdl, (glb_card->port_num));
    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy end.");
    return LCM_E_SUCCESS;
}


/*********************************************************************
 * Name    : lcm_init_greatbelt_demo_l2switch_fixup
 * Purpose :  according to greatbelt demo board connecting with vsc7395 l2switch,
            we do special configuration
 * Input   : N/A
                              
 * Output  : N/A
 * Return  : 
           
 * Note    : we can reference to the chapter 6.8.4 of vsc7395 specification
*********************************************************************/
void lcm_init_greatbelt_demo_l2switch_fixup(void)
{
   
    uint8 chip = 0;
    uint32 address = 0;
    uint16 value = 0;

    address = ((1&0x7)<<12) | ((6&0xf)<<8) | (0x0&0xff);
    l2switch_register_write(chip, address, 0x15656444);

    address = ((1&0x7)<<12) | ((6&0xf)<<8) | (0x19&0xff);
    l2switch_register_write(chip, address, 0x20);


    /* enable l2switch---greatbelt port autonegotiation enable*/
    l2switch_phy_read(chip, 0, 0, &value);
    value |= 0x1000;
    l2switch_phy_write(chip, 0, 0, value);

    /* enable l2switch---RJ45 port autonegotiation enable*/
    l2switch_phy_read(chip, 1, 0, &value);
    value |= 0x1000;
    l2switch_phy_write(chip, 1, 0, value);

}

static int32
_lcm_init_greatbelt_demo_l2switch(void)
{
    l2switch_info_t l2switch_info;
    l2switch_fixup_t l2switch_fixup[GREATBELT_DEMO_L2SWITCH_NUM];
    int32 ret = 0;
    vtss7395_switch_data_t vtss7395_data;
    switch_7395_port_t port;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init greatbelt demo l2switch begin.");

    sal_task_sleep(100);
    
    {                
        l2switch_info.switch_type = L2_SWITCH_VSC7395;
        l2switch_info.port_nums = L2_SWITCH_VSC7395_PORT_NUM;
        
        l2switch_info.spi_info.spi_type = E_SPI_CPU;
        l2switch_info.spi_info.spi_info.spi_cpu_info.fd = spi_1_fd;
        l2switch_info.spi_info.spi_info.spi_cpu_info.chip_sel = SPI_CPU_CHIP_SEL_1;

        vtss7395_data.port = &port;
        vtss7395_data.port_map = g_l2switch_port_map_greatbelt_demo;
        vtss7395_data.port->p_port_down = g_l2switch_port_down_greatbelt_demo;
        vtss7395_data.port->p_port_speed = g_port_speed_greatbelt_demo;
        vtss7395_data.port->p_port_intf = g_port_interface_greatbelt_demo;
        l2switch_info.data = (void *)&vtss7395_data;
        l2switch_fixup[0] = lcm_init_greatbelt_demo_l2switch_fixup;      
    }
    
    ret = l2switch_init(&l2switch_info, GREATBELT_DEMO_L2SWITCH_NUM, l2switch_fixup);
    if (ret < 0)
    {
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "l2switch init fail.");
        LCM_LOG_ERR("Init l2switch fail.");
        return -1;
    }

       
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init greatbelt demo l2switch end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_greatbelt_demo_i2c(void)
{
    int32 ret;

    //epld_item_write(0, EPLD_I2C_BRIDGE_RST, 0x1);
    sal_task_sleep(100);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init greatbelt demo i2c bus begin.");

    ret = i2c_open(E_I2C_CPM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init greatbelt demo i2c bus failed.");
        return LCM_E_HW_CLKGEN_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init greatbelt demo i2c bus end.");
    
    return LCM_E_SUCCESS;
}

int32 
lcm_init_greatbelt_demo_cb(void)
{
    LCM_IF_ERROR_RETURN(_lcm_init_greatbelt_demo_phy());
    return LCM_E_SUCCESS;
}

int32
lcm_init_greatbelt_demo(glb_card_t* p_card)
{    
    FILE *fp;
    char buf[BUFSIZ];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init greatbelt demo begin.");
    glb_card = p_card;
    p_card->asic_chip_num = 1;
    p_card->logic_slot_no = 1;
    p_card->phy_slot_no = 0;
    p_card->cpu_type = GLB_CPU_PPC_P1020;
    p_card->p_port_range = NULL;
    p_card->phy_chip_num = 0;
    p_card->phy_int_bit_num = 0;
    p_card->is_gbdemo = 1;

    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        fgets (buf, BUFSIZ, fp);
        p_card->logic_slot_no = atoi(buf);
        p_card->phy_slot_no = p_card->logic_slot_no;
        sal_fclose(fp);
    }
    else
    {
        p_card->logic_slot_no = 1;
        p_card->phy_slot_no = 0;
    }
    
    //ctc_hw_fd_init();
    LCM_IF_ERROR_RETURN(_lcm_init_greatbelt_demo_epld(p_card, p_card->epld_ver));

    p_card->slot_card_type = GLB_GG_SLOT_CARD_24XLG;

     if (p_card->slot_card_type == GLB_GG_SLOT_CARD_24XLG) /*24*40G*/
     {
        p_card->port_num = GLB_GG_DEMO_24XLG_MAX_PORT;
        sal_snprintf(p_card->cfg_profile_name, DATAPATH_LEN_MAX, "%s%s", 
            DATAPATH_PROFILE_PATH, GREATBELT_DEMO_24SFP8XG_DATAPATH_NAME);        
    }
    else /*48*10g + 6*40G*/   
    {
        p_card->port_num = GLB_GG_DEMO_48XG_6XLG_MAX_PORT;
        sal_snprintf(p_card->cfg_profile_name, DATAPATH_LEN_MAX, "%s%s", 
            DATAPATH_PROFILE_PATH, GREATBELT_DEMO_MB_DATAPATH_NAME);
    }
    p_card->board_type.series = GLB_SERIES_GREATBELT_DEMO;
    p_card->board_type.type = GLB_BOARD_GREATBELT_DEMO;
    
    _lcm_init_greatbelt_cpu_info();
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, 
                  "card product type %x, board type %x.", p_card->board_type.series, p_card->board_type.type);

    LCM_IF_ERROR_RETURN(_lcm_init_greatbelt_demo_i2c());
    LCM_IF_ERROR_RETURN(_lcm_init_greatbelt_demo_port(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_greatbelt_demo_l2switch());    
    LCM_IF_ERROR_RETURN(_lcm_init_greatbelt_demo_sensor());
    lcm_card_init_callback(lcm_init_greatbelt_demo_cb);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init greatbelt demo end.");
    
    return LCM_E_SUCCESS;
}
#endif
