/****************************************************************************
* $Id$
*  E580-48X6Q board init functions
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Matthew Qi
* Date          : 2015-04-09
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal_common.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "lcm_log.h"
#include "lcm_card.h"
#include "ctc_pci.h"
#include "ctc_spi.h"
#include "ctc_i2c.h"
#include "epld_api.h"
#include "fpga_api.h"
#include "ad9517_api.h"
#include "phy_api.h"
#include "fiber_api.h"
#include "sensor_api.h"
#include "gpio_api.h"
#include "fan_api.h"
#include "power_api.h"
#include "eeprom_api.h"
#include "led_api.h"
#include "ltc2991_api.h"
#include "lcm_mgt.h"
#include "ds3104_api.h"
#ifdef BOOTUP_DIAG
#include "diag_types.h"
#endif
#include "ctc_api.h"
#include "ctc_chip.h"
#include "glb_distribute_system_define.h"
#include "glb_if_define.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
/*
 * CPU I2C slave device
 */

/* Thermal sensor */
#define E580_48X6Q_SENSOR_NUM                      0x04
/* Sensor 0/1/2 on motherboard */
#define E580_48X6Q_ADDR0_SENSOR                    0x4b
#define E580_48X6Q_ADDR1_SENSOR                    0x48
#define E580_48X6Q_ADDR2_SENSOR                    0x49
/* Sensor 3 on CPU card */
#define E580_48X6Q_ADDR3_SENSOR                    0x4a

/* EEPROM */
#define E580_48X6Q_EEPROM_NUM                      0x01
#define E580_48X6Q_ADDR_EEPROM                     0x56

/* Voltage monitor: LTC2991 */
#define E580_48X6Q_VOLT_MON_NUM                    0x01
#define E580_48X6Q_ADDR_VOLT_MON                   0x4c

/* I2C bridge */
#define E580_48X6Q_I2C_BRIDGE_ADDR                 0x70

/*
 * CPU I2C slave device, after i2c bridge
 */ 

/* Power supply */
#define E580_48X6Q_PSU_MODULE_MAX                  0x2
#define E580_48X6Q_ADDR0_PSU                       0x38
#define E580_48X6Q_ADDR1_PSU                       0x38

/* Fan */
#define E580_48X6Q_FAN_MODULE_MAX                  0x1
/* Fan controller0, controll fan 0/1/2/3 */
#define E580_48X6Q_ADDR0_FAN                       0x2f
/* Fan controller1, controll fan 4/5/6/7, Not connected */
#define E580_48X6Q_ADDR1_FAN                       0x2c

/* I2C to GPIO: PCA9505 */
#define E580_48X6Q_GPIO_CHIP_NUM                   0x05
#define E580_48X6Q_ADDR0_GPIO                      0x20
#define E580_48X6Q_ADDR1_GPIO                      0x21
#define E580_48X6Q_ADDR2_GPIO                      0x22
#define E580_48X6Q_ADDR3_GPIO                      0x23
#define E580_48X6Q_ADDR4_GPIO                      0x24

#define E580_48X6Q_PANEL_PORT_NUM_MAX              (48+6*4)
#define E580_48X6Q_PANEL_PORT_NUM                  (48+6)
#define E580_48X6Q_FIBER_PORT_NUM                  (48+6)

#define E580_48X6Q_SLICE0_LED_MAC_NUM              34
#define E580_48X6Q_LED_MAC_NUM                     (48+6+4)
#define E580_48X6Q_LED_TBL_NUM                     4

/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
static const glb_card_t         *glb_card;
static lcm_card_port_t          *glb_lcm_e580_48x6q_port             = NULL;
static fiber_port_info_t        *glb_lcm_e580_48x6q_fiber            = NULL;
static lcm_card_serdes_info_t   *glb_lcm_e580_48x6q_serdes_mode      = NULL;

extern int32 lcm_card_init_callback(card_init_callback_t func);

lcm_card_port_t lcm_e580_48x6q_port_max[E580_48X6Q_PANEL_PORT_NUM_MAX] =
{
    { 0,   4,                    4,                   },    /* Port  1 <-> SerDes  4 */
    { 0,   5,                    5,                   },    /* Port  2 <-> SerDes  5 */
    { 0,   6,                    6,                   },    /* Port  3 <-> SerDes  6 */    
    { 0,   8,                    8,                   },    /* Port  4 <-> SerDes  8 */
    { 0,   9,                    9,                   },    /* Port  5 <-> SerDes  9 */
    { 0,  10,                   10,                   },    /* Port  6 <-> SerDes 10 */
    { 0,  12,                   12,                   },    /* Port  7 <-> SerDes 12 */
    { 0,  13,                   13,                   },    /* Port  8 <-> SerDes 13 */
                                  
    { 0,  14,                   14,                   },    /* Port  9 <-> SerDes 14 */
    { 0,  16,                   16,                   },    /* Port 10 <-> SerDes 16 */
    { 0,  17,                   17,                   },    /* Port 11 <-> SerDes 17 */    
    { 0,  18,                   18,                   },    /* Port 12 <-> SerDes 18 */
    { 0,  20,                   20,                   },    /* Port 13 <-> SerDes 20 */
    { 0,  21,                   21,                   },    /* Port 14 <-> SerDes 21 */
    { 0,  22,                   22,                   },    /* Port 15 <-> SerDes 22 */
    { 0,  24,                   24,                   },    /* Port 16 <-> SerDes 24 */
                                  
    { 0,  25,                   25,                   },    /* Port 17 <-> SerDes 25 */
    { 0,  26,                   26,                   },    /* Port 18 <-> SerDes 26 */
    { 0,  28,                   28,                   },    /* Port 19 <-> SerDes 28 */    
    { 0,  30,                   30,                   },    /* Port 20 <-> SerDes 30 */
    { 0,  31,                   31,                   },    /* Port 21 <-> SerDes 31 */
    { 0,  32,                   32,                   },    /* Port 22 <-> SerDes 32 */
    { 0,  34,                   34,                   },    /* Port 23 <-> SerDes 34 */
    { 0,  35,                   35,                   },    /* Port 24 <-> SerDes 35 */
                                  
    { 0,  40,                   40,                   },    /* Port 25 <-> SerDes 36 */
    { 0,  41,                   41,                   },    /* Port 26 <-> SerDes 37 */
    { 0,  43,                   43,                   },    /* Port 27 <-> SerDes 39 */    
    { 0,  36,                   36,                   },    /* Port 28 <-> SerDes 40 */
    { 0,  37,                   37,                   },    /* Port 29 <-> SerDes 41 */
    { 0,  39,                   39,                   },    /* Port 30 <-> SerDes 43 */
    { 0,  47,                   47,                   },    /* Port 31 <-> SerDes 47 */
    { 0,  46,                   46,                   },    /* Port 32 <-> SerDes 46 */
                                  
    { 0,  45,                   45,                   },    /* Port 33 <-> SerDes 45 */
    { 0,  44,                   44,                   },    /* Port 34 <-> SerDes 44 */
    { 0,  44 + GG_SLICE1_BASE,  44 + GG_SLICE1_BASE,  },    /* Port 35 <-> SerDes 92 */    
    { 0,  45 + GG_SLICE1_BASE,  45 + GG_SLICE1_BASE,  },    /* Port 36 <-> SerDes 93 */
    { 0,  46 + GG_SLICE1_BASE,  46 + GG_SLICE1_BASE,  },    /* Port 37 <-> SerDes 94 */
    { 0,  47 + GG_SLICE1_BASE,  47 + GG_SLICE1_BASE,  },    /* Port 38 <-> SerDes 95 */
    { 0,  38 + GG_SLICE1_BASE,  38 + GG_SLICE1_BASE,  },    /* Port 39 <-> SerDes 90 */
    { 0,  37 + GG_SLICE1_BASE,  37 + GG_SLICE1_BASE,  },    /* Port 40 <-> SerDes 89 */
                                  
    { 0,  36 + GG_SLICE1_BASE,  36 + GG_SLICE1_BASE,  },    /* Port 41 <-> SerDes 88 */
    { 0,  43 + GG_SLICE1_BASE,  43 + GG_SLICE1_BASE,  },    /* Port 42 <-> SerDes 87 */
    { 0,  42 + GG_SLICE1_BASE,  42 + GG_SLICE1_BASE,  },    /* Port 43 <-> SerDes 86 */    
    { 0,  41 + GG_SLICE1_BASE,  41 + GG_SLICE1_BASE,  },    /* Port 44 <-> SerDes 85 */
    { 0,  40 + GG_SLICE1_BASE,  40 + GG_SLICE1_BASE,  },    /* Port 45 <-> SerDes 84 */
    { 0,  34 + GG_SLICE1_BASE,  34 + GG_SLICE1_BASE,  },    /* Port 46 <-> SerDes 82 */
    { 0,  33 + GG_SLICE1_BASE,  33 + GG_SLICE1_BASE,  },    /* Port 47 <-> SerDes 81 */
    { 0,  32 + GG_SLICE1_BASE,  32 + GG_SLICE1_BASE,  },    /* Port 48 <-> SerDes 80 */
                                  
    { 0,  29 + GG_SLICE1_BASE,  29 + GG_SLICE1_BASE,  },    /* Port 49 <-> SerDes 77 */
    { 0,  30 + GG_SLICE1_BASE,  30 + GG_SLICE1_BASE,  },    /* Port 50 <-> SerDes 78 */
    { 0,  28 + GG_SLICE1_BASE,  28 + GG_SLICE1_BASE,  },    /* Port 51 <-> SerDes 76 */
    { 0,  31 + GG_SLICE1_BASE,  31 + GG_SLICE1_BASE,  },    /* Port 52 <-> SerDes 79 */
    { 0,  25 + GG_SLICE1_BASE,  25 + GG_SLICE1_BASE,  },    /* Port 53 <-> SerDes 73 */
    { 0,  26 + GG_SLICE1_BASE,  26 + GG_SLICE1_BASE,  },    /* Port 54 <-> SerDes 74 */
    { 0,  24 + GG_SLICE1_BASE,  24 + GG_SLICE1_BASE,  },    /* Port 55 <-> SerDes 72 */
    { 0,  27 + GG_SLICE1_BASE,  27 + GG_SLICE1_BASE,  },    /* Port 56 <-> SerDes 75 */
                                  
    { 0,  22 + GG_SLICE1_BASE,  22 + GG_SLICE1_BASE,  },    /* Port 57 <-> SerDes 70 */
    { 0,  23 + GG_SLICE1_BASE,  23 + GG_SLICE1_BASE,  },    /* Port 58 <-> SerDes 71 */
    { 0,  21 + GG_SLICE1_BASE,  21 + GG_SLICE1_BASE,  },    /* Port 59 <-> SerDes 69 */
    { 0,  20 + GG_SLICE1_BASE,  20 + GG_SLICE1_BASE,  },    /* Port 60 <-> SerDes 68 */
    { 0,  13 + GG_SLICE1_BASE,  13 + GG_SLICE1_BASE,  },    /* Port 61 <-> SerDes 61 */
    { 0,  15 + GG_SLICE1_BASE,  15 + GG_SLICE1_BASE,  },    /* Port 62 <-> SerDes 63 */
    { 0,  12 + GG_SLICE1_BASE,  12 + GG_SLICE1_BASE,  },    /* Port 63 <-> SerDes 60 */
    { 0,  14 + GG_SLICE1_BASE,  14 + GG_SLICE1_BASE,  },    /* Port 64 <-> SerDes 62 */
                                  
    { 0,  11 + GG_SLICE1_BASE,  11 + GG_SLICE1_BASE,  },    /* Port 65 <-> SerDes 59 */
    { 0,   9 + GG_SLICE1_BASE,   9 + GG_SLICE1_BASE,  },    /* Port 66 <-> SerDes 57 */
    { 0,  10 + GG_SLICE1_BASE,  10 + GG_SLICE1_BASE,  },    /* Port 67 <-> SerDes 58 */
    { 0,   8 + GG_SLICE1_BASE,   8 + GG_SLICE1_BASE,  },    /* Port 68 <-> SerDes 56 */
    { 0,   5 + GG_SLICE1_BASE,   5 + GG_SLICE1_BASE,  },    /* Port 69 <-> SerDes 53 */
    { 0,   7 + GG_SLICE1_BASE,   7 + GG_SLICE1_BASE,  },    /* Port 70 <-> SerDes 55 */
    { 0,   6 + GG_SLICE1_BASE,   6 + GG_SLICE1_BASE,  },    /* Port 71 <-> SerDes 54 */
    { 0,   4 + GG_SLICE1_BASE,   4 + GG_SLICE1_BASE,  },    /* Port 72 <-> SerDes 52 */
};

fiber_port_info_t lcm_e580_48x6q_fiber_max[E580_48X6Q_FIBER_PORT_NUM] =
{
    /* fiber_flg+fiber access mode+fbid+busid+btmp+enable_chip+enable_No+present_chip+present_No+los_chip+los_No */
    /* panel port 1~8 */
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  0,  0,  0,  0, 24,  0, 32,  1,  0},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  1,  0,  1,  0, 25,  0, 33,  1,  1},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  2,  0,  2,  0, 26,  0, 34,  1,  2},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  3,  0,  3,  0, 27,  0, 35,  1,  3},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  4,  0,  4,  0, 28,  0, 36,  1,  4},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  5,  0,  5,  0, 29,  0, 37,  1,  5},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  6,  0,  6,  0, 30,  0, 38,  1,  6},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  7,  0,  7,  0, 31,  0, 39,  1,  7},

    /* panel port 9~16 */
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  8,  0, 14,  1,  8,  1, 16,  1, 24},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO,  9,  0, 13,  1,  9,  1, 17,  1, 25},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 10,  0, 15,  1, 10,  1, 18,  1, 26},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 11,  0, 12,  1, 11,  1, 19,  1, 27},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 12,  0,  8,  1, 12,  1, 20,  1, 28},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 13,  0, 11,  1, 13,  1, 21,  1, 29},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 14,  0,  9,  1, 14,  1, 22,  1, 30},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 15,  0, 10,  1, 15,  1, 23,  1, 31},

    /* panel port 17~24 */
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 16,  0, 22,  1, 32,  2,  0,  2,  8},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 17,  0, 21,  1, 33,  2,  1,  2,  9},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 18,  0, 23,  1, 34,  2,  2,  2, 10},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 19,  0, 20,  1, 35,  2,  3,  2, 11},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 20,  0, 16,  1, 36,  2,  4,  2, 12},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 21,  0, 19,  1, 37,  2,  5,  2, 13},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 22,  0, 17,  1, 38,  2,  6,  2, 14},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 23,  0, 18,  1, 39,  2,  7,  2, 15},

    /* panel port 25~32 */
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 24,  1,  4,  2, 16,  2, 24,  2, 32},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 25,  1,  3,  2, 17,  2, 25,  2, 33},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 26,  1,  5,  2, 18,  2, 26,  2, 34},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 27,  1,  2,  2, 19,  2, 27,  2, 35},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 28,  1,  6,  2, 20,  2, 28,  2, 36},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 29,  1,  1,  2, 21,  2, 29,  2, 37},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 30,  1,  7,  2, 22,  2, 30,  2, 38},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 31,  1,  0,  2, 23,  2, 31,  2, 39},

    /* panel port 33~40 */
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 32,  1,  8,  3,  0,  3,  8,  3, 16},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 33,  1, 15,  3,  1,  3,  9,  3, 17},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 34,  1,  9,  3,  2,  3, 10,  3, 18},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 35,  1, 14,  3,  3,  3, 11,  3, 19},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 36,  1, 10,  3,  4,  3, 12,  3, 20},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 37,  1, 13,  3,  5,  3, 13,  3, 21},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 38,  1, 11,  3,  6,  3, 14,  3, 22},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 39,  1, 12,  3,  7,  3, 15,  3, 23},

    /* panel port 41~48 */
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 40,  1, 22,  3, 24,  3, 32,  4,  0},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 41,  1, 21,  3, 25,  3, 33,  4,  1},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 42,  1, 23,  3, 26,  3, 34,  4,  2},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 43,  1, 20,  3, 27,  3, 35,  4,  3},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 44,  1, 16,  3, 28,  3, 36,  4,  4},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 45,  1, 19,  3, 29,  3, 37,  4,  5},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 46,  1, 17,  3, 30,  3, 38,  4,  6},
    {E_FIBER_SFP_P, E_FIBER_SFP_CTC_CHIP_GPIO, 47,  1, 18,  3, 31,  3, 39,  4,  7},

    /* panel port 49~54 */
    {E_FIBER_QSFP_P, E_FIBER_QSFP_CTC_CHIP_GPIO, 48,  1, 28, 0xff, 0xff, 4, 24, 0xff, 0xff},
    {E_FIBER_QSFP_P, E_FIBER_QSFP_CTC_CHIP_GPIO, 49,  1, 29, 0xff, 0xff, 4, 25, 0xff, 0xff},
    {E_FIBER_QSFP_P, E_FIBER_QSFP_CTC_CHIP_GPIO, 50,  1, 26, 0xff, 0xff, 4, 26, 0xff, 0xff},
    {E_FIBER_QSFP_P, E_FIBER_QSFP_CTC_CHIP_GPIO, 51,  1, 27, 0xff, 0xff, 4, 27, 0xff, 0xff},
    {E_FIBER_QSFP_P, E_FIBER_QSFP_CTC_CHIP_GPIO, 52,  1, 24, 0xff, 0xff, 4, 28, 0xff, 0xff},
    {E_FIBER_QSFP_P, E_FIBER_QSFP_CTC_CHIP_GPIO, 53,  1, 25, 0xff, 0xff, 4, 29, 0xff, 0xff},
};

/* Modified by liuht for bug 34540, 2015-09-09 */
mac_led_api_para_t lcm_e580_48x6q_mac_led_default_entry[E580_48X6Q_LED_MAC_NUM]=
{
    /* panel port 1~8 */
    { 4, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    { 5, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    { 6, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    { 8, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    { 9, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {10, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {12, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {13, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},

    /* panel port 9~16 */
    {14, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {16, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {17, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {18, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {20, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {21, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {22, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {24, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},

    /* panel port 17~24 */
    {25, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {26, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {28, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {30, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {31, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {32, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {34, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {35, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},

    /* panel port 25~32 */
    {48, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {49, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {51, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {36, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {37, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {39, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {55, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {54, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},

    /* panel port 33~40 */
    {53, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {52, 0, 0, LED_MODE_2_OFF_RXLNKBIACT},
    {52, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {53, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {54, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {55, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {38, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {37, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},

    /* panel port 41~48 */
    {36, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {51, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {50, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {49, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {48, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {34, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {33, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},
    {32, 0, 1, LED_MODE_2_OFF_RXLNKBIACT},

    /* panel port 49~54 */
    {28, 0, 1, LED_MODE_1_FORCE_OFF},
    {24, 0, 1, LED_MODE_1_FORCE_OFF},
    {20, 0, 1, LED_MODE_1_FORCE_OFF},
    {12, 0, 1, LED_MODE_1_FORCE_OFF},
    { 8, 0, 1, LED_MODE_1_FORCE_OFF},
    { 4, 0, 1, LED_MODE_1_FORCE_OFF},

    /* fanout led, anytime there is only 1 or 0 LED is on 
     * using a NA mac 0 to send LED signal
     */
    { 0, 0, 1, LED_MODE_1_FORCE_OFF},
    { 0, 0, 1, LED_MODE_1_FORCE_OFF},
    { 0, 0, 1, LED_MODE_1_FORCE_OFF},
    { 0, 0, 1, LED_MODE_1_FORCE_OFF},
};

lcm_card_serdes_ffe_t 
lcm_e580_48x6q_serdes_ffe_max[E580_48X6Q_PANEL_PORT_NUM_MAX]=
{
    /* Panel Port 1~8 */
    { 4, 2, 0xff},
    { 5, 2, 0xff},
    { 6, 2, 0xff},    
    { 8, 2, 0xff},
    { 9, 2, 0xff},
    {10, 2, 0xff},
    {12, 2, 2},
    {13, 2, 2},

    /* Panel Port 9~16 */
    {14, 1, 1},
    {16, 1, 1},
    {17, 1, 1},    
    {18, 1, 1},
    {20, 1, 1},
    {21, 1, 1},
    {22, 1, 1},
    {24, 1, 1},

    /* Panel Port 17~24 */
    {25, 1, 0},
    {26, 1, 0},
    {28, 0, 0},    
    {30, 0, 0},
    {31, 0, 0},
    {32, 0, 0},
    {34, 0, 0},
    {35, 0, 0},

    /* Panel Port 25~32 */
    {36, 0, 0},
    {37, 0, 0},
    {39, 0, 0},    
    {40, 0, 0},    /* HSS28G */
    {41, 0, 0},    /* HSS28G */
    {43, 0, 0},    /* HSS28G */
    {47, 0, 0},    /* HSS28G */
    {46, 0, 0},    /* HSS28G */

    /* Panel Port 33~40 */
    {45, 0, 0},    /* HSS28G */
    {44, 0, 0},    /* HSS28G */
    {92, 0, 0},    /* HSS28G */    
    {93, 0, 0},    /* HSS28G */
    {94, 0, 0},    /* HSS28G */
    {95, 0, 0},    /* HSS28G */
    {90, 0, 0},    /* HSS28G */
    {89, 1, 0},    /* HSS28G */

    /* Panel Port 41~48 */
    {88, 0, 0},    /* HSS28G */
    {87, 1, 1},
    {86, 1, 0},    
    {85, 1, 1},
    {84, 1, 0},
    {82, 1, 1},
    {81, 1, 1},
    {80, 1, 1},

    /* Panel Port 49/50 */
    {77, 1, 1},
    {78, 1, 1},
    {76, 1, 1},
    {79, 1, 1},
    {73, 1, 1},
    {74, 1, 1},
    {72, 1, 1},
    {75, 1, 1},

    /* Panel Port 51/52 */
    {70, 1, 1},
    {71, 1, 1},
    {69, 1, 1},
    {68, 2, 2},
    {61, 1, 1},
    {63, 1, 1},
    {60, 2, 2},
    {62, 1, 1},

    /* Panel Port 53/54 */
    {59, 2, 2},
    {57, 2, 2},
    {58, 2, 2},
    {56, 2, 2},
    {53, 2, 0xff},
    {55, 2, 2},
    {54, 2, 2},
    {52, 2, 0xff},
};

uint16 lcm_e580_48x6q_serdes_usrdef_coeff[E580_48X6Q_PANEL_PORT_NUM_MAX][4] =
{
    /* Panel port 1~8 */
    {0x02, 0x1a, 0x20, 0x00},
    {0x02, 0x1a, 0x20, 0x00},
    {0x02, 0x19, 0x20, 0x00},
    {0x02, 0x19, 0x20, 0x00},
    {0x02, 0x19, 0x20, 0x00},
    {0x02, 0x19, 0x20, 0x00},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 9~16 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 17~24 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 25~32 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 33~40 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 41~48 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 49~50 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 51~52 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},

    /* Panel port 53~54 */
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0x02, 0x19, 0x20, 0x00},
    {0xff, 0xff, 0xff, 0xff},
    {0xff, 0xff, 0xff, 0xff},
    {0x02, 0x19, 0x20, 0x00},
};
/****************************************************************************
 *
* Function
*
****************************************************************************/
static int32
_lcm_init_e580_48x6q_cpu_info()
{
    FILE * fp;

    fp = sal_fopen(GLB_CPU_IF_INFO_FILE, "w+");
    if(fp ==NULL)
    {
        LCM_LOG_ERR("Open cpu info file error.");
        return LCM_E_FILE_OPEN;
    }
    sal_fprintf(fp, "MGMT_IF eth0\n");
    sal_fprintf(fp, "CPU_IF NOTUSE\n");
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

static int32
lcm_init_e580_48x6q_init_port_table(glb_card_t* p_card)
{
    uint8 port_id, panel_port_no, panel_subport_no;
    uint8 pos;

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        panel_port_no = p_card->pp_port[port_id]->panel_port_no;
        panel_subport_no = p_card->pp_port[port_id]->panel_sub_port_no;
        if (port_id < 48)  /* no port num change */
        {
            pos = panel_port_no - 1;
        }
        else
        {
            if(panel_subport_no)  /* port split */
            {
                pos = 48 + (panel_port_no-48-1) * 4 + panel_subport_no - 1;
            }
            else
            {
                /* For panel port 49/50/52, the 3rd entry based on (panel_port_no-1)*4 is needed
                 * For panel port 51/53/54, the 4th entry based on (panel_port_no-1)*4 is needed
                 */
                if ((panel_port_no == 49)||(panel_port_no == 50)||(panel_port_no == 52))
                {
                    pos = 48 + (panel_port_no-48-1)*4+2;
                }
                else
                {
                    pos = 48 + (panel_port_no-48-1)*4+3;
                }
            }
        }
        sal_memcpy(&glb_lcm_e580_48x6q_port[port_id], &lcm_e580_48x6q_port_max[pos], sizeof(lcm_card_port_t));
    }

    return LCM_E_SUCCESS;
}

static int32
lcm_init_e580_48x6q_init_serdes_table(glb_card_t* p_card)
{
    uint8 port_id, panel_port_no, panel_subport_no;
    uint8 pos;

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        panel_port_no = p_card->pp_port[port_id]->panel_port_no;
        panel_subport_no = p_card->pp_port[port_id]->panel_sub_port_no;
        if (port_id < 48)  /* no port num change */
        {
            pos = panel_port_no - 1;
        }
        else
        {
            if(panel_subport_no)
            {
                pos = 48 + (panel_port_no-48-1) * 4 + panel_subport_no - 1;
            }
            else
            {
                /* For panel port 49/50/52, the 3rd entry based on (panel_port_no-1)*4 is needed
                 * For panel port 51/53/54, the 4th entry based on (panel_port_no-1)*4 is needed
                 */
                if ((panel_port_no == 49)||(panel_port_no == 50)||(panel_port_no == 52))
                {
                    pos = 48 + (panel_port_no-48-1)*4+2;
                }
                else
                {
                    pos = 48 + (panel_port_no-48-1)*4+3;
                }
            }
        }
        glb_lcm_e580_48x6q_serdes_mode[port_id].serdes_id = lcm_e580_48x6q_serdes_ffe_max[pos].serdes_id;
    }
    
    return LCM_E_SUCCESS;
}

static int32
lcm_init_e580_48x6q_init_fiber_table(glb_card_t* p_card)
{
    uint8 port_id, panel_port_no, panel_subport_no;
    uint8 fiber_channel;

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        panel_port_no = p_card->pp_port[port_id]->panel_port_no;
        panel_subport_no = p_card->pp_port[port_id]->panel_sub_port_no;
        if(panel_subport_no)
        {
            fiber_channel = panel_subport_no;
        }
        else
        {
            fiber_channel = 0;
        }
        sal_memcpy(&glb_lcm_e580_48x6q_fiber[port_id], &lcm_e580_48x6q_fiber_max[panel_port_no-1], sizeof(fiber_port_info_t));
        glb_lcm_e580_48x6q_fiber[port_id].fiber_channel = fiber_channel;
        glb_lcm_e580_48x6q_fiber[port_id].fiber_id = port_id;
    }
    
    return LCM_E_SUCCESS;
}

#ifndef _GLB_UML_SYSTEM_
static int32
_lcm_init_e580_48x6q_serdes_mode(void)
{
    uint8 i;
    uint8 pos;
    uint8 panel_port;
    int32 ret = 0;
    ctc_chip_serdes_info_t serdes_info;

    /* Modified by liuht for bug 32804, 2015-04-15 */
    /* disable all 40G/100G Mac for serdes mode switch */
    for(panel_port=1; panel_port<=glb_card->panel_port_num; panel_port++)
    {
        if (panel_port <= 48)  /* no need disable 10G mac */
        {
            continue;
        }
        else
        {
            /* For panel port 49/50/52, the 3rd entry based on (panel_port_no-1)*4 is needed
             * For panel port 51/53/54, the 4th entry based on (panel_port_no-1)*4 is needed
             */
            if ((panel_port == 49)||(panel_port == 50)||(panel_port == 52))
            {
                pos = 48 + (panel_port-48-1)*4+2;
            }
            else
            {
                pos = 48 + (panel_port-48-1)*4+3;
            }
        }        
        ctc_port_set_mac_en(lcm_e580_48x6q_port_max[pos].logic_port_idx, 0);
    }

    for(panel_port = 0; panel_port < glb_card->panel_port_num; panel_port++)
    {
        if (panel_port < 48)
        {
            continue;
        }
        else if(GLB_PPT_OP_NONE == glb_card->pp_ppt[panel_port]->op)
        {
            continue;
        }
        else if(GLB_PPT_OP_SPLIT == glb_card->pp_ppt[panel_port]->op)
        {
            if(glb_card->pp_ppt[panel_port]->ppt_numchg_type == GLB_PPT_NUMCHG_TYPE_10G)
            {
                serdes_info.serdes_mode = CTC_CHIP_SERDES_XFI_MODE;
                for(i=0; i<4; i++)
                {
                    serdes_info.serdes_id = lcm_e580_48x6q_serdes_ffe_max[48+(panel_port-48)*4+i].serdes_id;
                    ret += ctc_chip_set_serdes_mode(0, &serdes_info);
                }
            }
            else if(glb_card->pp_ppt[panel_port]->ppt_numchg_type == GLB_PPT_NUMCHG_TYPE_1G)
            {
                serdes_info.serdes_mode = CTC_CHIP_SERDES_SGMII_MODE;
                for(i=0; i<4; i++)
                {
                    serdes_info.serdes_id = lcm_e580_48x6q_serdes_ffe_max[48+(panel_port-48)*4+i].serdes_id;
                    ret += ctc_chip_set_serdes_mode(0, &serdes_info);
                }
            }
        }
    }
    
    return ret;
}
#endif

static int32
_lcm_init_e580_48x6q_panel_port(glb_card_t* p_card)
{
    uint8 ppt_id;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init panel port begin.");

    /* 1, Allocate panel port memory */
    p_card->pp_ppt = (glb_panel_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, 
        sizeof(glb_panel_port_t* )* p_card->panel_port_num);
    if (!p_card->pp_ppt)
    {
        LCM_LOG_ERR("Allocate pointer to global panel ports fail.");
        return LCM_E_NO_MEMORY;
    }

    /* 2, init panel port split/merge related data structure */
    for(ppt_id = 0; ppt_id < p_card->panel_port_num; ppt_id++)
    {
        p_card->pp_ppt[ppt_id] = (glb_panel_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_panel_port_t));
        if(!p_card->pp_ppt[ppt_id])
        {
            LCM_LOG_ERR("Allocate global panel ports fail.");
            return LCM_E_NO_MEMORY;
        }
        
        p_card->pp_ppt[ppt_id]->ppt_idx = ppt_id + 1;
        p_card->pp_ppt[ppt_id]->pslt_id = p_card->phy_slot_no;
        p_card->pp_ppt[ppt_id]->ppt_numchg_type = GLB_PPT_NUMCHG_TYPE_NONE;
        if (ppt_id < 48)
        {
            p_card->pp_ppt[ppt_id]->op = GLB_PPT_OP_NONE;
            p_card->pp_ppt[ppt_id]->ppt_speed_ability = GLB_SUPPORT_SPEED_10G | GLB_SUPPORT_SPEED_1G;
            p_card->pp_ppt[ppt_id]->ppt_speed_real = GLB_SUPPORT_SPEED_10G;
        }
        else
        {
            p_card->pp_ppt[ppt_id]->op = GLB_PPT_OP_SPLIT;
            p_card->pp_ppt[ppt_id]->ppt_numchg_num = 1;///TODO: need optimize
            p_card->pp_ppt[ppt_id]->ppt_speed_ability = GLB_SUPPORT_SPEED_40G;
            p_card->pp_ppt[ppt_id]->ppt_speed_real = GLB_SUPPORT_SPEED_40G;
        }
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init panel port end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_port(glb_card_t* p_card)
{
    int32 port_id = 0;
    uint32 ppt_idx;
    uint16 logic_port_idx;
    lcm_card_port_panel_mapping_t port_panel_mapping[256];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port begin.");

    /* 1, init panel port */
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_panel_port(p_card));

    /* 2, read '/mnt/flash/startup-config.conf' file, get port split/merge info */
    LCM_IF_ERROR_RETURN(lcm_common_parse_port_numchg_info(p_card));

    if(p_card->port_num != E580_48X6Q_PANEL_PORT_NUM)
    {
        p_card->split_flag = 1;
    }
    else
    {
        p_card->split_flag = 0;
    }

    /* 3, get panel_port/sub_port mapping */
    LCM_IF_ERROR_RETURN(lcm_common_ppt_map_port(p_card, port_panel_mapping));
    
    /* 4, integrate port info */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }
        p_card->pp_port[port_id]->panel_slot_no = port_panel_mapping[port_id].panel_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_panel_mapping[port_id].panel_port_no;
        p_card->pp_port[port_id]->panel_sub_port_no = port_panel_mapping[port_id].panel_subport_no;
    }

    /* 5, allocate memory for port/fiber/serdes data structure */
    glb_lcm_e580_48x6q_port = (lcm_card_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(lcm_card_port_t)* p_card->port_num);
    if (!glb_lcm_e580_48x6q_port)
    {
        LCM_LOG_ERR("Allocate pointer to lcm_card_port_t fail.");
        return LCM_E_NO_MEMORY;
    }

    glb_lcm_e580_48x6q_fiber = (fiber_port_info_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(fiber_port_info_t)*p_card->port_num);
    if (!glb_lcm_e580_48x6q_fiber)
    {
        LCM_LOG_ERR("Allocate pointer to fiber_port_info_t fail.");
        return LCM_E_NO_MEMORY;
    }

    glb_lcm_e580_48x6q_serdes_mode = (lcm_card_serdes_info_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(lcm_card_serdes_info_t)* p_card->port_num);
    if (!glb_lcm_e580_48x6q_serdes_mode)
    {
        LCM_LOG_ERR("Allocate pointer to int fail.");
        return LCM_E_NO_MEMORY;
    }

    /* 6, init current running port/fiber/serdes info */
    LCM_IF_ERROR_RETURN(lcm_init_e580_48x6q_init_port_table(p_card));
    LCM_IF_ERROR_RETURN(lcm_init_e580_48x6q_init_fiber_table(p_card));
    LCM_IF_ERROR_RETURN(lcm_init_e580_48x6q_init_serdes_table(p_card));

    /* 7, init port properties */
    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        logic_port_idx = glb_lcm_e580_48x6q_port[port_id].logic_port_idx;
        ppt_idx = p_card->pp_port[port_id]->panel_port_no;

        p_card->pp_port[port_id]->p_fiber = NULL;
        p_card->pp_port[port_id]->create_done = 1;
        p_card->pp_port[port_id]->is_combo = 0;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = 1;
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 0;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_cfg.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        p_card->pp_port[port_id]->port_status.link_up = GLB_LINK_DOWN;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_status.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_status.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->poe_support = NOT_POE_PORT;
        p_card->pp_port[port_id]->is_combo_to = 0;

        p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_UNKNOWN;
        p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_FIBER;
        p_card->pp_port[port_id]->port_speed_ability = p_card->pp_ppt[ppt_idx-1]->ppt_speed_ability;
        p_card->pp_port[port_id]->port_speed_real = p_card->pp_ppt[ppt_idx-1]->ppt_speed_real;
        p_card->pp_port[port_id]->mux_chip_id = 0;
        p_card->pp_port[port_id]->lp_support = 0;
        p_card->pp_port[port_id]->eee_support = 0;    /* support eee function for bug 28298, 2014-04-21 */
        p_card->pp_port[port_id]->logic_port_idx = logic_port_idx;
        p_card->pp_port[port_id]->local_chip_idx = glb_lcm_e580_48x6q_port[port_id].chip_idx;
        p_card->pp_port[port_id]->mac_idx = glb_lcm_e580_48x6q_port[port_id].mac_idx;
        p_card->pp_port[port_id]->chip_serdes_id = glb_lcm_e580_48x6q_serdes_mode[port_id].serdes_id;
        p_card->pp_port[port_id]->g_port_index = (p_card->pp_port[port_id]->glb_chip_idx << 8) | logic_port_idx;
        /* Modified by liuht for bug 34540, 2015-09-09 */
        if(ppt_idx<=48)
        {
            p_card->pp_port[port_id]->port_led_mode_change = GLB_PORT_LED_MODE_CHANGE_SFP_TWO_LED;
        }
        else
        {
            p_card->pp_port[port_id]->port_led_mode_change = GLB_PORT_LED_MODE_CHANGE_QSFP_ONE_LED;
        }
        p_card->pp_port[port_id]->ctl_id = (logic_port_idx >= GG_SLICE1_BASE)?1:0;
        if(p_card->pp_port[port_id]->ctl_id==1)
        {
            logic_port_idx = logic_port_idx -GG_SLICE1_BASE;
        }
        p_card->pp_port[port_id]->port_led_mac = (logic_port_idx >= 40)?
            (logic_port_idx+8):logic_port_idx;
    }

    /* 8, create file '/tmp/ctcos_port_info' */
    LCM_IF_ERROR_RETURN(lcm_common_save_port_info_file(p_card));
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port end.");

    return LCM_E_SUCCESS;
}


static int32_t
_lcm_reg_e580_48x6q_epld(uint8 hw_ver, epld_info_t * p_epld_info)
{
    p_epld_info->base_addr = epld_localbus_addr_get();
    p_epld_info->epld_bus_type = EPLD_LOCALBUS_TYPE;

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_EPLD_VERSION]),          0x1, 0, 7, 8);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SYS_LED_SYS]),           0x2, 4, 7, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_IND_LED]),               0x3, 0, 0, 1);
#if 0
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_PRESENT_STATUS]),    0x16, 4, 5, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_WORK_STATUS]),       0x16, 6, 7, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PSU_ALERT_STATUS]),      0x16, 2, 3, 2);
#endif
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_POWER_RST]),         0xf6, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_MANUAL_OTHER_RST]),  0xf7, 0, 7, 8);	
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GPIO_RST]),                 0x08, 0, 4, 5);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_POWER_DOWN]),               0x23, 0, 1, 2);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_I2C_BRIDGE_RST]),           0x08, 5, 5, 1);

#ifdef BOOTUP_DIAG
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_TEST]),                 0x7f, 0, 7, 8);
#endif
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_epld(glb_card_t* p_card, uint8 epld_version)
{
    epld_info_t *p_epld_info = NULL;
    int32 ret = 0;

    p_epld_info = epld_get_info(&p_card->board_type, epld_version);
    if (!p_epld_info)
    {
        LCM_LOG_ERR("Get EPLD info fail.");
        return LCM_E_INVALID_PTR;
    }

    _lcm_reg_e580_48x6q_epld(p_card->hw_ver, p_epld_info);
    ret = epld_init(p_epld_info);
    if (0 != ret)
    {
        LCM_LOG_ERR("EPLD Init fail.");
        return LCM_E_INIT_FAILED;
    }
    /* Fix bug29772, cr9895, qicx, 2014-08-26 */
    p_card->support_reboot_info = 1;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init epld end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_e580_48x6q_eeprom_info(glb_card_t* p_card)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom info begin.");

    p_card->p_eeprom_alloc = (eeprom_info_t *)XCALLOC(MTYPE_BUFFER_DATA, sizeof(eeprom_info_t)*EEPROM_MAX);
    if(NULL == p_card->p_eeprom_alloc)
    {
        LCM_LOG_ERR("alloc p_eeprom_alloc array fail.");
        return LCM_E_INVALID_PTR;
    }

    p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].base_addr = 0x1000;

    p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].base_addr = 0x1001;

#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    p_card->p_eeprom_alloc[EEPROM_SMARTCFG].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SMARTCFG].base_addr = 0x1007;
#endif /* !HAVE_SMARTCFG */

    p_card->p_eeprom_alloc[EEPROM_MGMT_CFG].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_MGMT_CFG].base_addr = 0x1100;

    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].base_addr = 0x1300;


    p_card->p_eeprom_alloc[EEPROM_PORT_INFO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_PORT_INFO].base_addr = 0x1400;

/* 
    TODO
    p_card->p_eeprom_alloc[EEPROM_BOOTCMD].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTCMD].base_addr = 0x0;
*/    
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_fiber(void)
{
    int32 ret = 0;
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber begin.");
    ret = fiber_init(glb_card->port_num,  /* fiber num */
                     glb_card->port_num, /* port num */
                     glb_lcm_e580_48x6q_fiber);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber end.");

    return ret;
}

static int32
_lcm_init_e580_48x6q_sensor(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[E580_48X6Q_SENSOR_NUM];
    sensor_chip_t sensor_chip[E580_48X6Q_SENSOR_NUM];
    void *p_data[E580_48X6Q_SENSOR_NUM];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init sensor begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    /* sensor0: on motherboard, before GG chip */
    i2c_gen[0].addr = E580_48X6Q_ADDR0_SENSOR;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[0].io_type = SENSOR_I2C;
    i2c_gen[0].alen = LM77_OFFSET_WIDTH;
    sensor_chip[0].chip_type = SENSOR_LM77;
    sensor_chip[0].pos = SENSOR_BEFORE_CHIP;

    /* sensor1: on motherboard, behind GG chip */
    i2c_gen[1].addr = E580_48X6Q_ADDR1_SENSOR;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].bridge_flag = 0;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[1].io_type = SENSOR_I2C;
    i2c_gen[1].alen = LM77_OFFSET_WIDTH;
    sensor_chip[1].chip_type = SENSOR_LM77;
    sensor_chip[1].pos = SENSOR_BEHIND_CHIP;

    /* sensor2: on motherboard, near fan module */
    i2c_gen[2].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[2].p_br.bridge_addr = E580_48X6Q_I2C_BRIDGE_ADDR;
    i2c_gen[2].p_br.channel = 6;
    i2c_gen[2].addr = E580_48X6Q_ADDR2_SENSOR;
    i2c_gen[2].i2c_type = E_I2C_CPM;
    i2c_gen[2].bridge_flag = 1;
    i2c_gen[2].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[2].io_type = SENSOR_I2C;
    i2c_gen[2].alen = LM77_OFFSET_WIDTH;
    sensor_chip[2].chip_type = SENSOR_LM77;
    sensor_chip[2].pos = SENSOR_FAN;

    /* sensor2: on cpu card */
    i2c_gen[3].addr = E580_48X6Q_ADDR3_SENSOR;
    i2c_gen[3].i2c_type = E_I2C_CPM;
    i2c_gen[3].bridge_flag = 0;
    i2c_gen[3].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[3].io_type = SENSOR_I2C;
    i2c_gen[3].alen = LM77_OFFSET_WIDTH;
    sensor_chip[3].chip_type = SENSOR_LM77;
    sensor_chip[3].pos = SENSOR_CPU;

    for(i=0; i<E580_48X6Q_SENSOR_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = sensor_init(p_data, sensor_chip, E580_48X6Q_SENSOR_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Temperature sensor init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(i=0; i<E580_48X6Q_SENSOR_NUM; i++)
    {
        sensor_dev_init(i);
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init sensor end.");
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_e580_48x6q_cfg_gpio(uint32 chip_id) ///TODO: need review by myself
{
    uint8 reg, val;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm cfg i2c to gpio module begin.");
    switch (chip_id)
    {
    case 0:    
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0x3f;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* tx enable */
        reg = PCA9505_OUTPUT_PORT_REG_BANK0;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_OUTPUT_PORT_REG_BANK3;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        break;
        
    case 1:
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK4;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* tx enable */
        reg = PCA9505_OUTPUT_PORT_REG_BANK1;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_OUTPUT_PORT_REG_BANK4;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        break;
    case 2:
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* tx enable */
        reg = PCA9505_OUTPUT_PORT_REG_BANK2;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        break;
    case 3:
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* tx enable */
        reg = PCA9505_OUTPUT_PORT_REG_BANK0;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_OUTPUT_PORT_REG_BANK3;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        break;
    case 4:
        /* for QSFP+ */
        reg = PCA9505_DIR_CTRL_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK1;
        val = 0xc0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_DIR_CTRL_REG_BANK4;
        val = 0xc0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* mask all interrupt */
        reg = PCA9505_INT_MASK_REG_BANK0;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK1;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK2;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK3;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_INT_MASK_REG_BANK4;
        val = 0xff;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);

        /* release reset */
        reg = PCA9505_OUTPUT_PORT_REG_BANK1;
        val = 0x0;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        reg = PCA9505_OUTPUT_PORT_REG_BANK4;
        val = 0x3f;
        gpio_reg_write(chip_id, reg, &val, PCA9505_VALUE_LEN);
        break;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm cfg i2c to gpio module begin.");
    
    return RESULT_OK;
}

static int32
_lcm_init_e580_48x6q_gpio(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[E580_48X6Q_GPIO_CHIP_NUM];
    gpio_chip_t gpio_chip[E580_48X6Q_GPIO_CHIP_NUM];
    void *p_data[E580_48X6Q_GPIO_CHIP_NUM];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c to gpio module begin.");
    /* release pca9505 */
    epld_item_write(0, EPLD_GPIO_RST, 0x1f);
    sal_delay(1);
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = E580_48X6Q_ADDR0_GPIO;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[0].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[0].io_type = GPIO_I2C;    
    gpio_chip[0].chip_type = GPIO_PCA9505;
    gpio_chip[0].scan_group_bitmap = 0x17; /*group 0,1,2,4*/

    i2c_gen[1].addr = E580_48X6Q_ADDR1_GPIO;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].bridge_flag = 0;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[1].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[1].io_type = GPIO_I2C;    
    gpio_chip[1].chip_type = GPIO_PCA9505;
    gpio_chip[1].scan_group_bitmap = 0xd; /*group 0,2,3*/

    i2c_gen[2].addr = E580_48X6Q_ADDR2_GPIO;
    i2c_gen[2].i2c_type = E_I2C_CPM;
    i2c_gen[2].bridge_flag = 0;
    i2c_gen[2].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[2].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[2].io_type = GPIO_I2C;    
    gpio_chip[2].chip_type = GPIO_PCA9505;
    gpio_chip[2].scan_group_bitmap = 0x1b; /*group 0,1,3,4*/ 

    i2c_gen[3].addr = E580_48X6Q_ADDR3_GPIO;
    i2c_gen[3].i2c_type = E_I2C_CPM;
    i2c_gen[3].bridge_flag = 0;
    i2c_gen[3].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[3].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[3].io_type = GPIO_I2C;    
    gpio_chip[3].chip_type = GPIO_PCA9505;
    gpio_chip[3].scan_group_bitmap = 0x16; /*group 1,2,4*/

    i2c_gen[4].addr = E580_48X6Q_ADDR4_GPIO;
    i2c_gen[4].i2c_type = E_I2C_CPM;
    i2c_gen[4].bridge_flag = 0;
    i2c_gen[4].i2c_bus_idx = GLB_I2C_IDX_0;
    i2c_gen[4].alen = PCA9505_OFFSET_WIDTH;
    gpio_chip[4].io_type = GPIO_I2C;    
    gpio_chip[4].chip_type = GPIO_PCA9505;
    gpio_chip[4].scan_group_bitmap = 0x9; /*group 0,3*/


    for(i=0; i<E580_48X6Q_GPIO_CHIP_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = gpio_init(p_data, gpio_chip, E580_48X6Q_GPIO_CHIP_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Gpio device init fail.");
        return LCM_E_INIT_FAILED;
    }

    for(i=0; i<E580_48X6Q_GPIO_CHIP_NUM; i++)
    {
        _lcm_e580_48x6q_cfg_gpio(i);
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c to gpio module end.");

    return LCM_E_SUCCESS;
}

/* Added by liuht for bug26671, 2014-02-14 */
static int32
_lcm_init_e580_48x6q_fan(void)
{
    int32 ret = 0;
    uint8 fan_module_idx;
    i2c_gen_t i2c_gen[E580_48X6Q_FAN_MODULE_MAX];
    fan_chip_t fan_chip[E580_48X6Q_FAN_MODULE_MAX];
    void *p_data[E580_48X6Q_FAN_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = E580_48X6Q_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 5;
    i2c_gen[0].addr = E580_48X6Q_ADDR0_FAN;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = ADT7470_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    fan_chip[0].chip_type = FAN_ADT7470;
    fan_chip[0].io_type = E_FAN_I2C;
    fan_chip[0].support_hot_swap = 0;  /* stable on GG mother board, do not support hot swap */
    p_data[0] = &i2c_gen[0];
    fan_chip[0].fan_num = 4;
    fan_chip[0].speed_adjust = 1;
    fan_chip[0].rpm = 15000;

    ret = fan_init(p_data, fan_chip, E580_48X6Q_FAN_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Fan driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(fan_module_idx=0; fan_module_idx<E580_48X6Q_FAN_MODULE_MAX; fan_module_idx++)
    {
        fan_dev_init(fan_module_idx);
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_psu(void)
{
    int32 ret;
    i2c_gen_t i2c_gen[E580_48X6Q_PSU_MODULE_MAX];
    psu_data_gpio psu_gpio[E580_48X6Q_PSU_MODULE_MAX];
    psu_chip_t psu_chip[E580_48X6Q_PSU_MODULE_MAX];
    psu_private_t p_data[E580_48X6Q_PSU_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init psu module begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));
        
    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = E580_48X6Q_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 3;
    i2c_gen[0].addr = E580_48X6Q_ADDR0_PSU;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[0].chip_type = PSU_I2C_GPIO;
    psu_chip[0].io_type = PSU_IO_I2C_GPIO;
    psu_chip[0].psu_type = PSU_SHOW_FULL_STATUS;
    psu_chip[0].psu_mode_type = (1<<PSU_MODE_TYPE_REG_38_26_0d)|(1<<PSU_MODE_TYPE_REG_50_50_08)
                                |(1<<PSU_MODE_TYPE_REG_5b_9a_0a);
    psu_gpio[0].present_chip = 0;
    psu_gpio[0].present_no = 17;
    psu_gpio[0].workstate_chip = 0;
    psu_gpio[0].workstate_no = 21;
    psu_gpio[0].alert_chip = 0;
    psu_gpio[0].alert_no = 18;
    p_data[0].p_data_i2c= &i2c_gen[0];
    p_data[0].p_data_gpio = &psu_gpio[0];

    i2c_gen[1].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[1].p_br.bridge_addr = E580_48X6Q_I2C_BRIDGE_ADDR;
    i2c_gen[1].p_br.channel = 1;
    i2c_gen[1].addr = E580_48X6Q_ADDR1_PSU;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[1].bridge_flag = 1;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[1].chip_type = PSU_I2C_GPIO;
    psu_chip[1].io_type = PSU_IO_I2C_GPIO;
    psu_chip[1].psu_type = PSU_SHOW_FULL_STATUS;
    psu_chip[1].psu_mode_type = (1<<PSU_MODE_TYPE_REG_38_26_0d)|(1<<PSU_MODE_TYPE_REG_50_50_08)
                                |(1<<PSU_MODE_TYPE_REG_5b_9a_0a);
    psu_gpio[1].present_chip = 0;
    psu_gpio[1].present_no = 9;
    psu_gpio[1].workstate_chip = 0;
    psu_gpio[1].workstate_no = 13;
    psu_gpio[1].alert_chip = 0;
    psu_gpio[1].alert_no = 10;
    p_data[1].p_data_i2c= &i2c_gen[1];
    p_data[1].p_data_gpio= &psu_gpio[1];

    ret = psu_init(p_data, psu_chip, E580_48X6Q_PSU_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Psu driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init psu module end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_volt_mon(glb_board_type_t board_type)
{    
#if 0
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[E580_48X6Q_VOLT_MON_NUM];
    ltc2991_chip_t ltc2991_chip[E580_48X6Q_VOLT_MON_NUM];
    void *p_data[E580_48X6Q_VOLT_MON_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));
   
    i2c_gen[0].addr = E580_48X6Q_ADDR_VOLT_MON;
    for(i=0; i<E580_48X6Q_VOLT_MON_NUM; i++)
    {
        i2c_gen[i].i2c_type = E_I2C_CPM;
        i2c_gen[i].alen = LTC2991_OFFSET_WIDTH;
        i2c_gen[i].bridge_flag = 0;
        ltc2991_chip[i].chip_type = LTC2991_CMS;
        ltc2991_chip[i].io_type = LTC2991_I2C;
        p_data[i] = &i2c_gen[i];
    }
    ret = ltc2991_init(p_data, ltc2991_chip, E580_48X6Q_VOLT_MON_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Ltc2991 init fail.");
        return LCM_E_INIT_FAILED;
    }    
    for(i=0; i<E580_48X6Q_VOLT_MON_NUM; i++)
    {
        ret = ltc2991_dev_init(board_type, i);
        if(ret < 0)
        {
            LCM_LOG_ERR("Ltc2991 dev init fail.");
            return LCM_E_INIT_FAILED;
        }
    }
#endif
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_eeprom(void)
{
    int32 ret = 0;
    i2c_gen_t i2c_gen[E580_48X6Q_EEPROM_NUM];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = E580_48X6Q_ADDR_EEPROM;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = EEPROM_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;

    ret = eeprom_init(i2c_gen, E580_48X6Q_EEPROM_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm EEPROM init fail.");
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_phy(void)
{
    uint16 port_id;
    phy_info_t phyinfo;
    phy_handle_t** pphdl = NULL;
    glb_port_t* p_port;
    uint8 panel_port;
    int32 ret;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy begin.");

    sal_memset(&phyinfo, 0, sizeof(phy_info_t));
    pphdl = (phy_handle_t**)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE,
        sizeof(phy_handle_t*)*(glb_card->port_num));

    if(NULL == pphdl)
    {
        LCM_LOG_ERR("LCM phy no memory.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < (glb_card->port_num); port_id++)
    {
        p_port = glb_card->pp_port[port_id];
        panel_port = p_port->panel_port_no;
        if (port_id < 48)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_10G;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_SFP_PLUS;
        }
        else if(GLB_PPT_NUMCHG_TYPE_NONE == glb_card->pp_ppt[panel_port-1]->ppt_numchg_type)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_40G;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_QSFP_PLUS;
        }
        else if(GLB_PPT_NUMCHG_TYPE_10G == glb_card->pp_ppt[panel_port-1]->ppt_numchg_type)
        {
            phyinfo.phy_manage_info.speed = GLB_SPEED_10G;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_QSFP_PLUS;
        }

        phyinfo.phy_device_type = PORT_PHY_NULL;
        phyinfo.phy_manage_info.mac_if = GLB_MAC_INTERFACE_SERDES;
        
        phyinfo.phy_manage_info.duplex = GLB_DUPLEX_FULL;
        if (lcm_mgt_is_enable_stack())
        {
            phyinfo.port.port_info.port_id = GLB_TRANS_PORTID_TO_GPORT(
                    lcm_mgt_get_stack_member(), p_port->logic_port_idx);            
        }
        else
        {
            phyinfo.port.port_info.port_id = p_port->logic_port_idx;
        }
        phyinfo.port.port_info.lchip = p_port->local_chip_idx;
        phyinfo.port.port_info.serdes_id = p_port->chip_serdes_id;
        /* Modified by liuht for access port id in phy handle for bug 25808 */	
        phyinfo.port_num = port_id;


        /*********************************************************************
         * Default:
         * PHY_WORK_MODE_NORMAL GLB_LB_NONE GLB_SPEED_AUTO
         * GLB_DUPLEX_AUTO
         ********************************************************************/
        phyinfo.phy_manage_info.mode = PHY_WORK_MODE_NORMAL;
        phyinfo.phy_manage_info.lb_mode = GLB_LB_NONE;
        phyinfo.phy_manage_info.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl.recv= GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl_ability.asymmetric_pause = 0;
        phyinfo.phy_manage_info.flowctrl_ability.symmetric_pause = 0;

        phyinfo.phy_stat_flag.duplex = phyinfo.phy_manage_info.duplex;
        phyinfo.phy_stat_flag.speed = phyinfo.phy_manage_info.speed;
        phyinfo.phy_stat_flag.link_up = GLB_LINK_DOWN;
        phyinfo.phy_stat_flag.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_stat_flag.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        pphdl[port_id] = phy_dev_register(&phyinfo);
        if(NULL ==  pphdl[port_id])
        {
            LCM_LOG_ERR("Register phy handle failed\n");
            return LCM_E_INIT_FAILED;
        }
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm ready to init phy.");
    ret = phy_init(pphdl, (glb_card->port_num));
    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_e580_48x6q_i2c(void)
{
    int32 ret;

    sal_task_sleep(100);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus begin.");

    /* Added by liuht for bug34164, 2015-06-30 */
    epld_item_write(0, EPLD_I2C_BRIDGE_RST, 0x1);
    
    ret = i2c_open(E_I2C_CPM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init i2c bus failed.");
        return LCM_E_HW_CLKGEN_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_led(void)
{
    int32 ret = 0;
    led_info_t led_info[E_MAX_LED];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED begin.");
    sal_memset(led_info, 0, sizeof(led_info_t)*E_MAX_LED);

    /* init sys led */
    led_info[E_SYS_LED].exist = 1;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].val = 0x5;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].val = 0xb;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].val = 0x5;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].val = 0x7;
    /* End of Merge */
    led_info[E_FAN_LED].exist = 0;
    led_info[E_FAN_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_FAN_LED;
    led_info[E_FAN_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    led_info[E_PSU1_LED].exist = 0;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_PSU1_LED;
    led_info[E_PSU1_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;
    led_info[E_PSU2_LED].exist = 0;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_PSU2_LED;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_NO_ALARM].val = 1;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_PSU2_LED;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ALARM].val = 0x2;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ABSENT].op_reg = EPLD_PSU2_LED;
    led_info[E_PSU2_LED].led_para[E_LED_SYS_ABSENT].val = 0x0;	
    led_info[E_IND_LED].exist = 1;
    led_info[E_IND_LED].led_para[E_LED_SYS_OFF].op_reg = EPLD_IND_LED;
    led_info[E_IND_LED].led_para[E_LED_SYS_OFF].val = 0x1;
    led_info[E_IND_LED].led_para[E_LED_SYS_ON].op_reg = EPLD_IND_LED;
    led_info[E_IND_LED].led_para[E_LED_SYS_ON].val = 0x0;
	
    ret = led_init(led_info);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init LEDs failed.");
        return LCM_E_HW_LED_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e580_48x6q_ctc_chip_led(void)
{
    uint8 split_flag=0;
    uint8 i;
    uint8 table_id;
    uint8 table_num;
    uint8 panel_port_id;
    uint8 src_pos, des_pos;
    uint8 port_id;
    uint16 logic_port_idx;
    mac_led_info_t mac_led_info;
    mac_led_api_para_t* p_mac_led_api_para;
    mac_led_api_para_t glb_lcm_e580_48x6q_mac_led[E580_48X6Q_LED_TBL_NUM][E580_48X6Q_LED_MAC_NUM];
    uint16 lcm_e580_48x6q_mac_led_split[E580_48X6Q_PANEL_PORT_NUM_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init MAC LED begin.");
    for(port_id = 0; port_id < E580_48X6Q_PANEL_PORT_NUM_MAX; port_id++)
    {
        logic_port_idx = lcm_e580_48x6q_port_max[port_id].logic_port_idx;
        lcm_e580_48x6q_mac_led_split[port_id] = (logic_port_idx >= GG_SLICE1_BASE)? 
            (logic_port_idx - GG_SLICE1_BASE):logic_port_idx;
        /* Added by liuht for bug 33109, 2015-05-05 */
        /* conversion channel id to mac id */
        if(lcm_e580_48x6q_mac_led_split[port_id] >= 40)
            lcm_e580_48x6q_mac_led_split[port_id] += 8;
    }

    split_flag = glb_card->split_flag;
    if(split_flag)
    {
        table_num = E580_48X6Q_LED_TBL_NUM;
    }
    else
    {
        table_num = 1;
    }
    
    /* if any port split:
     * table0 : for fan out led : led0 force on and led1,2,3 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 1 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 1 mac of this port and port 1 40G led force off
     * table1 : for fan out led : led1 force on and led0,2,3 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 2 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 2 mac of this port and port 1 40G led force off
     * table2 : for fan out led : led2 force on and led0,1,3 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 3 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 3 mac of this port and port 1 40G led force off
     * table3 : for fan out led : led3 force on and led0,1,2 force off
     *          for 40G port led: if not split,led status depend on 40G mac of this port
     *                            if split, led status depend on subport 4 mac of this port
     *          for 10G port led: if work on sfp+ media, then normal
     *                            if work on qsfp+ media, then led status depend on 
     *                               subport 4 mac of this port and port 1 40G led force off
     * if no port split:
     * table0   : for fan out led  : all force off
     *          : for 40G port led : led status depend on 40G mac of this port
     *          : for 10G port led : all force off
     */
    for(table_id = 0; table_id < table_num; table_id++)
    {
        sal_memcpy(glb_lcm_e580_48x6q_mac_led[table_id], lcm_e580_48x6q_mac_led_default_entry, 
            sizeof(mac_led_api_para_t)*E580_48X6Q_LED_MAC_NUM);

        for(panel_port_id=0; panel_port_id<E580_48X6Q_PANEL_PORT_NUM; panel_port_id++)
        {
            if (GLB_PPT_NUMCHG_TYPE_10G == glb_card->pp_ppt[panel_port_id]->ppt_numchg_type)
            {
                des_pos = panel_port_id;
                src_pos = 48 + (panel_port_id-48)*4 + table_id;
                p_mac_led_api_para = &glb_lcm_e580_48x6q_mac_led[table_id][des_pos];
                p_mac_led_api_para->port_id = lcm_e580_48x6q_mac_led_split[src_pos];
            }
        }

        /* When any port split, light on fan out LED periodically */
        if(split_flag)
        {
            for(i=0; i < E580_48X6Q_LED_TBL_NUM; i++)
            {
                if(table_id == i)
                {
                    /* channel 1: force on fan out led
                     * channel 0: force off fan out led
                     */
                    src_pos = 48+4+2 + i;
                    glb_lcm_e580_48x6q_mac_led[table_id][src_pos].port_id = 1;
                    glb_lcm_e580_48x6q_mac_led[table_id][src_pos].mode = LED_MODE_1_FORCE_ON;
                }
            }
        }        
    }

    mac_led_info.mac_led_api_para = (mac_led_api_para_t **)XCALLOC(CTCLIB_MEM_LCM_MODULE, 
        sizeof(mac_led_api_para_t*)*table_num);
    if(NULL == mac_led_info.mac_led_api_para)
    {
        LCM_LOG_ERR("alloc mac_led_api_para_t array fail.");
        return LCM_E_NO_MEMORY;
    }

    for(table_id = 0; table_id < table_num; table_id++)
    {
        mac_led_info.mac_led_api_para[table_id] = glb_lcm_e580_48x6q_mac_led[table_id];
    }
    mac_led_info.table_num = table_num;
    mac_led_info.mac_num = E580_48X6Q_LED_MAC_NUM;
    mac_led_info.slice0_mac_num = E580_48X6Q_SLICE0_LED_MAC_NUM;
    mac_led_info_register(&mac_led_info);
    led_mgt_port_led();

    XFREE(CTCLIB_MEM_LCM_MODULE, mac_led_info.mac_led_api_para);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init MAC LED end.");
    
    return LCM_E_SUCCESS;
}

static int32
_lcm_e580_48x6q_get_board_material(uint8 *bm)
{
    FILE *fp;
    uint32 val;
    char buf[256];

    fp = sal_fopen(GLB_BOARD_INFO_FILE, "r");
    if(NULL == fp)
    {
        *bm = 0xff;  /* default: M4 */
        return LCM_E_FILE_OPEN;
    }

    while(fgets(buf, 256, fp) != NULL)
    {
        uint8 tmp[256];

        if(!sal_strncmp(buf, GLB_BOARD_MATERIAL_STRING, 14))
        {
            sal_sscanf(buf, "%s %x", tmp, &val);
            *bm = (uint8)val;
        }
    }

    sal_fclose(fp);

    return LCM_E_SUCCESS;
}

int32
lcm_e580_48x6q_get_sum_ffe_cfg(lcm_chip_serdes_ffe_t* serdes_ffe)
{
    uint8 serdes_id;
    uint8 index;

    serdes_id = serdes_ffe->serdes_id;
    if (glb_card->board_material_M4)    /* M4 */
    {
        serdes_ffe->board_material = 1;
        serdes_ffe->mode = CTC_CHIP_SERDES_FFE_MODE_TYPICAL;             /* typical */
        for(index = 0; index < E580_48X6Q_PANEL_PORT_NUM_MAX; index++)
        {
            if(serdes_id == lcm_e580_48x6q_serdes_ffe_max[index].serdes_id)
            {                
                serdes_ffe->trace_len = lcm_e580_48x6q_serdes_ffe_max[index].trace_len;
                return 0;
            }  
        }        
    }
    else         /*FR4*/
    {
        serdes_ffe->board_material = 0;
        for(index = 0; index < E580_48X6Q_PANEL_PORT_NUM_MAX; index++)
        {
            if(serdes_id == lcm_e580_48x6q_serdes_ffe_max[index].serdes_id)
            {
                if(0xff == lcm_e580_48x6q_serdes_usrdef_coeff[index][0])  
                {
                    serdes_ffe->mode = CTC_CHIP_SERDES_FFE_MODE_TYPICAL;  /*typical*/
                    serdes_ffe->trace_len = lcm_e580_48x6q_serdes_ffe_max[index].trace_len2;                    
                }
                else
                {
                    serdes_ffe->mode = CTC_CHIP_SERDES_FFE_MODE_DEFINE;  /*user-defined*/
                    serdes_ffe->c0 = lcm_e580_48x6q_serdes_usrdef_coeff[index][0];
                    serdes_ffe->c1 = lcm_e580_48x6q_serdes_usrdef_coeff[index][1];
                    serdes_ffe->c2 = lcm_e580_48x6q_serdes_usrdef_coeff[index][2];
                    serdes_ffe->c3 = lcm_e580_48x6q_serdes_usrdef_coeff[index][3];
                }
                return 0;
            }  
        }    
    } 
    LCM_LOG_ERR("Lcm get sum ffe cfg error, doesn't find ffe param.");
    return -1;
}


int32
lcm_init_e580_48x6q_serdes(void)
{
    int32 ret = LCM_E_SUCCESS;
#ifndef _GLB_UML_SYSTEM_
    ctc_chip_serdes_ffe_t serdes_ffe;
    uint8 index;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init serdes begin.");

    if (glb_card->board_material_M4)    /* M4 */
    {
        serdes_ffe.mode = CTC_CHIP_SERDES_FFE_MODE_TYPICAL;             /* typical */
        serdes_ffe.board_material = 1;   /* M4 */
        for(index = 0; index < E580_48X6Q_PANEL_PORT_NUM_MAX; index++)
        {
            serdes_ffe.serdes_id = lcm_e580_48x6q_serdes_ffe_max[index].serdes_id;
            serdes_ffe.trace_len = lcm_e580_48x6q_serdes_ffe_max[index].trace_len;
            ret = ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
            if (ret < 0)
            {
                LCM_LOG_ERR("LCM set serdes ffe parameter failed.\n");
                return LCM_E_INIT_FAILED;
            }  
        }
    }
    else/* FR4 */
    {
        /* 1. init user-defined ffe */
        serdes_ffe.mode = CTC_CHIP_SERDES_FFE_MODE_DEFINE;             /* user-defined */
        for(index = 0; index < E580_48X6Q_PANEL_PORT_NUM_MAX; index++)
        {
            if (0xff == lcm_e580_48x6q_serdes_usrdef_coeff[index][0])
                continue;
            
            serdes_ffe.serdes_id = lcm_e580_48x6q_serdes_ffe_max[index].serdes_id;
            serdes_ffe.coefficient[0] = lcm_e580_48x6q_serdes_usrdef_coeff[index][0];
            serdes_ffe.coefficient[1] = lcm_e580_48x6q_serdes_usrdef_coeff[index][1];
            serdes_ffe.coefficient[2] = lcm_e580_48x6q_serdes_usrdef_coeff[index][2];
            serdes_ffe.coefficient[3] = lcm_e580_48x6q_serdes_usrdef_coeff[index][3];
            ret = ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
            if (ret < 0)
            {
                LCM_LOG_ERR("LCM set serdes ffe parameter failed.\n");
                return LCM_E_INIT_FAILED;
            }
        }
        
        /* 2. init typical ffe */
        serdes_ffe.mode = CTC_CHIP_SERDES_FFE_MODE_TYPICAL;             /* typical */
        serdes_ffe.board_material = 0;   /* FR4 */
        for(index = 0; index < E580_48X6Q_PANEL_PORT_NUM_MAX; index++)
        {
            if (0xff != lcm_e580_48x6q_serdes_usrdef_coeff[index][0])
                continue;
            
            serdes_ffe.serdes_id = lcm_e580_48x6q_serdes_ffe_max[index].serdes_id;
            serdes_ffe.trace_len = lcm_e580_48x6q_serdes_ffe_max[index].trace_len2;
            ret = ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
            if (ret < 0)
            {
                LCM_LOG_ERR("LCM set serdes ffe parameter failed.\n");
                return LCM_E_INIT_FAILED;
            }  
        }
    }

    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_serdes_mode());

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init serdes end.");
#endif    
    return ret;
}

/* Added by liuht for bug34164, 2015-06-30 */
int32
lcm_init_e580_48x6q_ctc_gpio_init(void)
{
    int ret = 0;

    /* set gpio 1,2,3,4,5,6,7,8 output mode */
    ret  = ctc_chip_set_gpio_mode(1, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(2, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(3, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(4, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(5, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(6, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(7, CTC_CHIP_OUTPUT_MODE);
    ret += ctc_chip_set_gpio_mode(8, CTC_CHIP_OUTPUT_MODE);

    /* set gpio 1,2,3,4,5,6,7,8 output 0 to reset i2c bridge */
    ret += ctc_chip_set_gpio_output(1, 0);
    ret += ctc_chip_set_gpio_output(2, 0);
    ret += ctc_chip_set_gpio_output(3, 0);
    ret += ctc_chip_set_gpio_output(4, 0);
    ret += ctc_chip_set_gpio_output(5, 0);
    ret += ctc_chip_set_gpio_output(6, 0);
    ret += ctc_chip_set_gpio_output(7, 0);
    ret += ctc_chip_set_gpio_output(8, 0);

    /* set gpio 1,2,3,4,5,6,7,8 output 1 to release i2c bridge */
    ret += ctc_chip_set_gpio_output(1, 1);
    ret += ctc_chip_set_gpio_output(2, 1);
    ret += ctc_chip_set_gpio_output(3, 1);
    ret += ctc_chip_set_gpio_output(4, 1);
    ret += ctc_chip_set_gpio_output(5, 1);
    ret += ctc_chip_set_gpio_output(6, 1);
    ret += ctc_chip_set_gpio_output(7, 1);
    ret += ctc_chip_set_gpio_output(8, 1);

    return ret;
}

int32
lcm_init_e580_48x6q_cb(void)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback begin.");
    LCM_IF_ERROR_RETURN(lcm_init_e580_48x6q_ctc_gpio_init());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_fiber());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_phy());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_ctc_chip_led());
    LCM_IF_ERROR_RETURN(lcm_init_e580_48x6q_serdes());
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback end.");

    return LCM_E_SUCCESS;
}
extern int32 lcm_port_init_ffe_cfg_callback(lcm_port_get_sum_ffe_cfg_callback_t func);
int32
lcm_init_e580_48x6q(glb_card_t* p_card)
{
    FILE *fp;
    uint8 bm;
    char buf[BUFSIZ];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board begin.");
    glb_card = p_card;
    p_card->asic_chip_num = 1;
    p_card->chip_sensor_num = 1;

    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        sal_fgets (buf, BUFSIZ, fp);
        p_card->logic_slot_no = atoi(buf);
        p_card->phy_slot_no = p_card->logic_slot_no;
        sal_fclose(fp);
    }
    else
    {
        p_card->logic_slot_no = 1;
        p_card->phy_slot_no = 0;
    }

    p_card->logic_slot_no = 1;
    p_card->phy_slot_no = 0;

    p_card->panel_port_num = E580_48X6Q_PANEL_PORT_NUM;
    p_card->l2switch_num = 0;
    p_card->sensor_num = E580_48X6Q_SENSOR_NUM;
    if(p_card->chip_sensor_num+p_card->sensor_num > MAX_TMPR_SENSOR_NUM)
    {
        LCM_LOG_ERR("Sensor structure is too small to store sensor info on board.\n");        
        return LCM_E_NO_MEMORY;
    }
    p_card->fan_module_num = E580_48X6Q_FAN_MODULE_MAX;
    p_card->psu_module_num = E580_48X6Q_PSU_MODULE_MAX;
    //p_card->volt_cur_monitor_num = E580_48X6Q_VOLT_MON_NUM;
    //p_card->phy_interrupt_mode = GLB_PHY_INTERRUPT_MODE_EPLD;   /*get phy interrupt info from EPLD*/
    p_card->cpu_type = GLB_CPU_PPC_P1010;
    p_card->phy_chip_num = 0;

    /* for some board like e350 8t12xg don't support ptp, added by jcao for bug 25500, 2013-10-25 */
    p_card->ptp_en = 0;
    p_card->epld_type = GLB_EPLD_TYPE_VME;
    p_card->bootrom_type = E_BOOTROM_TYPE_512K;
    _lcm_e580_48x6q_get_board_material(&bm);
    if(0xff == bm) /*M4*/
    {
        p_card->board_material_M4 = 1;
    }
    else
    {
        p_card->board_material_M4 = 0;
    }

    sal_snprintf(p_card->cfg_profile_name, DATAPATH_LEN_MAX, "%s%s",
                DATAPATH_PROFILE_PATH, E580_48X6Q_DATAPATH_NAME);

    _lcm_init_e580_48x6q_cpu_info();
    ctc_hw_fd_init();
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,
                  "card product type %x, board type %x.", p_card->board_type.series, p_card->board_type.type);
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_epld(p_card, p_card->epld_ver));
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_eeprom_info(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_led());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_i2c());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_eeprom());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_port(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_sensor());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_volt_mon(p_card->board_type));
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_gpio());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_fan());
    LCM_IF_ERROR_RETURN(_lcm_init_e580_48x6q_psu());

    LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_STACKING_LED, 0));
    
#ifdef BOOTUP_DIAG
    LCM_IF_ERROR_RETURN(lcm_common_parse_bootup_diag(p_card));
#endif

    lcm_card_init_callback(lcm_init_e580_48x6q_cb);
    lcm_port_init_ffe_cfg_callback(lcm_e580_48x6q_get_sum_ffe_cfg);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board end.");

    return LCM_E_SUCCESS;
}

