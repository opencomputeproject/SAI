/****************************************************************************
* $Id$
*  E350-48T4X2Q board init functions
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Chenxi Qi
* Date          : 2013-04-23
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal_common.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "lcm_log.h"
#include "lcm_card.h"
#include "ctc_pci.h"
#include "ctc_spi.h"
#include "ctc_i2c.h"
#include "epld_api.h"
#include "fpga_api.h"
#include "ad9517_api.h"
#include "phy_api.h"
#include "fiber_api.h"
#include "sensor_api.h"
#include "fan_api.h"
#include "power_api.h"
#include "eeprom_api.h"
#include "led_api.h"
#include "lcm_mgt.h"
#include "ds3104_api.h"
#ifdef BOOTUP_DIAG
#include "diag_types.h"
#endif
#include "ctc_api.h"
#include "ctc_chip.h"
#include "glb_distribute_system_define.h"
#include "glb_if_define.h"
#ifndef _GLB_UML_SYSTEM_
/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
#define E350_8T12X_SENSOR_NUM                      0x01
#define E350_8T12X_ADDR_SENSOR                     0x48

#define E350_8T12X_FAN_MODULE_MAX                  0x1
#define E350_8T12X_PSU_MODULE_MAX                  0x0

#define E350_8T12X_EEPROM_NUM                      0x01
#define E350_8T12X_ADDR_EEPROM                     0x57  /* boot info */

#define E350_8T12X_PHY_INT_BITS_SUM                   1

/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
static const glb_card_t* glb_card;

extern int32 lcm_card_init_callback(card_init_callback_t func);

lcm_card_port_t lcm_e350_8t12x_port[GLB_E350_8T12X_8T_MAX_PORT+GLB_E350_8T12X_12XG_MAX_PORT] =
{
    /* HSS 1 */
    {0, 12, 12, 0},   /* Port  1 <-> SGMII    8 <-> GMAC  12 */
    {0, 13, 13, 1},   /* Port  2 <-> SGMII    9 <-> GMAC  13 */
    {0, 14, 14, 2},   /* Port  3 <-> SGMII  10 <-> GMAC 14 */
    {0, 15, 15, 3},   /* Port  4 <-> SGMII  11 <-> GMAC 15 */
    {0, 16, 16, 4},   /* Port  5 <-> SGMII  12 <-> GMAC 16 */
    {0, 17, 17, 5},   /* Port  6 <-> SGMII  13 <-> GMAC 17 */
    {0, 18, 18, 6},   /* Port  7 <-> SGMII  14 <-> GMAC 18 */
    {0, 19, 19, 7},   /* Port  8 <-> SGMII  15 <-> GMAC 19 */

    /* HSS 2 */
    {0,   8,   8},  /* Port   9  <-> SFI  0 <->  SGMAC 8 */
    {0,   9,   9},  /* Port  10 <-> SFI  1 <->  SGMAC 9 */
    {0, 10, 10},  /* Port  11 <-> SFI  2 <->  SGMAC 10 */
    {0, 11, 11},  /* Port  12 <-> SFI  3 <->  SGMAC 11 */    

   /* HSS 3 */
    {0, 0, 0, },    /* Port 13 <-> SFI   4  <->  SGMAC 0 */
    {0, 1, 1, },    /* Port 14 <-> SFI   5  <->  SGMAC 1 */
    {0, 2, 2, },    /* Port 15 <-> SFI   6  <->  SGMAC 2 */
    {0, 3, 3, },    /* Port 16 <-> SFI   7  <->  SGMAC 3 */ 
    {0, 4, 4, },    /* Port 17 <-> SFI   8  <->  SGMAC 4 */
    {0, 5, 5, },    /* Port 18 <-> SFI   9  <->  SGMAC 5 */
    {0, 6, 6, },    /* Port 19 <-> SFI  10 <->  SGMAC 6 */
    {0, 7, 7, },    /* Port 20 <-> SFI  11 <->  SGMAC 7 */
};

glb_port_range_t lcm_e350_8t12x_phy_chip_port_range[E350_8T12X_PHY_INT_BITS_SUM] =
{
    { 1, 8},
};

fiber_port_info_t lcm_e350_8t12x_fiber[GLB_E350_8T12X_8T_MAX_PORT+GLB_E350_8T12X_12XG_MAX_PORT] =
{
    /* 8T */
    {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
     /*12 Fiber*/
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 0,  0, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 1,  1, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 2,  4, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 3,  5, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 4,  24, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 5,  25, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 6,  26, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 7,  27, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 8,  28, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 9,  29, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 10, 30, 0},
    {E_FIBER_SFP_P, E_FIBER_CTC_CHIP, 11, 31, 0},
};
uint8 lcm_e350_8t12x_mac_led[]={8,9,10,11,12,13,14,15,56,57,58,59,48,49,50,51,52,53,54,55};
static uint8 g_slot_id = 0;

/* Added by liuht for E350-8T12X to initialize serdes, 2013-11-21 */
uint8 
lcm_e350_8t12x_serdes_trace_len[][2]=
{{18,0},{19,0},{22,0},
 {23,0}, {24,0},{25,0},
 {26,0},{27,0}, {28,0},
 {29,0},{30,0},{31,0}};

/* bug25647, qicx modified to support 10G/1G XFI/XSGMII dynamic switch,2013-11-30 */
int8 lcm_e350_8t12x_serdes_mode[GLB_E350_8T12X_8T_MAX_PORT+GLB_E350_8T12X_12XG_MAX_PORT] =
{
    -1, -1, -1, -1, -1, -1, -1, -1,   /* 8T, don't care their serdes modes */
    18, 19, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31  /* 12X, care them */
};
/* end of qicx added for bug25647 */
/****************************************************************************
 *
* Function
*
****************************************************************************/
static int32
_lcm_init_e350_8t12x_cpu_info()
{
    FILE * fp;

    fp = sal_fopen(GLB_CPU_IF_INFO_FILE, "w+");
    if(fp ==NULL)
    {
        LCM_LOG_ERR("Open cpu info file error.");
        return LCM_E_FILE_OPEN;
    }
    sal_fprintf(fp, "MGMT_IF eth0\n");
    sal_fprintf(fp, "CPU_IF NOTUSE\n");
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_port(glb_card_t* p_card)
{
    int32 port_id;
    /* alloc ports */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port begin.");

    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }

        p_card->pp_port[port_id]->p_fiber = NULL;
        p_card->pp_port[port_id]->is_combo = 0;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = 1;
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
        /*Fix bug 14686. jqiu 2011-06-15*/
        p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_id+1;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 0;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_cfg.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        p_card->pp_port[port_id]->port_status.link_up = GLB_LINK_DOWN;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_status.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->port_status.flowctrl.recv = GLB_FLOWCTRL_DISABLE;
        p_card->pp_port[port_id]->poe_support = NOT_POE_PORT;

        p_card->pp_port[port_id]->logic_port_idx = lcm_e350_8t12x_port[port_id].logic_port_idx;
        p_card->pp_port[port_id]->local_chip_idx = lcm_e350_8t12x_port[port_id].chip_idx;
        p_card->pp_port[port_id]->mac_idx = lcm_e350_8t12x_port[port_id].mac_idx;
        p_card->pp_port[port_id]->chip_serdes_id = lcm_e350_8t12x_serdes_mode[port_id];
        p_card->pp_port[port_id]->port_led_mode_change = GLB_PORT_LED_MODE_CHANGE_UNSUPPORT;
        /* Modified by liuht for bug26853, 2013-01-20 */
        /* global port id */
        p_card->pp_port[port_id]->g_port_index = (p_card->pp_port[port_id]->glb_chip_idx << 8) | (p_card->pp_port[port_id]->logic_port_idx);
        if (port_id < GLB_E350_8T12X_8T_MAX_PORT)  /* 48T */
        {
            p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
            p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
            p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
            p_card->pp_port[port_id]->lp_support = 1;
            p_card->pp_port[port_id]->eee_support = 0;    /* support eee function for bug 28298, 2014-04-21 */
        }
        else
        {
            p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_FIBER;
            p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_UNKNOWN;
			/* E350 8T12XG supports 10G/1G dynamic switch. */
            p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G | GLB_SUPPORT_SPEED_10G;
            p_card->pp_port[port_id]->lp_support = 0;
            p_card->pp_port[port_id]->eee_support = 0;    /* support eee function for bug 28298, 2014-04-21 */
        }
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init port end.");

    return LCM_E_SUCCESS;
}

static int32_t
_lcm_reg_e350_8t12x_epld(uint8 hw_ver, epld_info_t * p_epld_info)
{
    p_epld_info->base_addr = epld_localbus_addr_get();
    p_epld_info->epld_bus_type = EPLD_LOCALBUS_TYPE;

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_EPLD_VERSION]),          0x1, 0, 7, 8);

     /* Modified by liuht to support system led in E350-8T12X for bug 25677, 2013-12-09 */
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SYS_LED_SYS]),            0x2, 4, 7, 4);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_PCIE_RST]),            0x4, 2, 2, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_POR_RST]),             0x4, 1, 1, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_GB_HARD_RST]),           0x4, 0, 0, 1);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PHY_RST]),                    0x5, 1, 1, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SERIAL_LED_RST]),        0x5, 0, 0, 1);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_PHY_INT_MASK]),           0x7, 0, 0, 1);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_RESET_INT_MASK]),         0x9, 0, 0, 1);

    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_PRESENT1]),           0x20, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_DISABLE1]),           0x21, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_LOS1]),                  0x22, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_PRESENT2]),           0x23, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_DISABLE2]),           0x24, 0, 3, 4);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_SFP_LOS2]),                  0x25, 0, 3, 4);

    /* Added by liuht for bug26671, 2014-02-14 */
    /* When hardware version > 1.0,  support fan management */
    if(hw_ver > 0x10)
    {
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_SET_SPEED]),  0x26, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_GET_SPEED1_LOW]),  0x27, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_GET_SPEED1_HIGH]),  0x28, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_GET_SPEED2_LOW]),  0x29, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_GET_SPEED2_HIGH]),  0x30, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_GET_SPEED3_LOW]),  0x31, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_MODULE0_GET_SPEED3_HIGH]),  0x32, 0, 7, 8);
        epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_FAN_STATUS]),  0x33, 0, 2, 3);
    }

    /* Added by liuht for bug27036, 2014-02-21 */
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_POWER_RST]),               0xf6, 0, 7, 8);
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_REBOOT_MANUAL_OTHER_RST]),  0xf7, 0, 7, 8);	

#ifdef BOOTUP_DIAG
    epld_set_reg_desc(&(p_epld_info->reg_desc[EPLD_TEST]),                 0xf8, 0, 7, 8);
#endif
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_epld(glb_card_t* p_card, uint8 epld_version)
{
    epld_info_t *p_epld_info = NULL;
    int32 ret = 0;

    p_epld_info = epld_get_info(&p_card->board_type, epld_version);
    if (!p_epld_info)
    {
        LCM_LOG_ERR("Get EPLD info fail.");
        return LCM_E_INVALID_PTR;
    }

    _lcm_reg_e350_8t12x_epld(p_card->hw_ver, p_epld_info);
    ret = epld_init(p_epld_info);
    if (0 != ret)
    {
        LCM_LOG_ERR("EPLD Init fail.");
        return LCM_E_INIT_FAILED;
    }
    /* Added by liuht for bug27036, 2014-02-21 */
    if(epld_version >= 0x12)
    {
        p_card->support_reboot_info = 1;
    }
    else
    {
        p_card->support_reboot_info = 0;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init epld end.");
    return LCM_E_SUCCESS;
}


static int32
_lcm_init_e350_8t12x_eeprom_info(glb_card_t* p_card)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom info begin.");

    p_card->p_eeprom_alloc = (eeprom_info_t *)XCALLOC(MTYPE_BUFFER_DATA, sizeof(eeprom_info_t)*EEPROM_MAX);
    if(NULL == p_card->p_eeprom_alloc)
    {
        LCM_LOG_ERR("alloc p_eeprom_alloc array fail.");
        return LCM_E_INVALID_PTR;
    }
    p_card->p_eeprom_alloc[EEPROM_SERIAL_PARAM].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SERIAL_PARAM].base_addr = 0x1050;
    p_card->p_eeprom_alloc[EEPROM_BOOTVER].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTVER].base_addr = 0x1110;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].base_addr = 0x1300;
    p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_0_MANU_TEST].base_addr = 0x1900;
#ifdef BOOTUP_DIAG
    p_card->p_eeprom_alloc[EEPROM_BOOTUP_DIAG_LEVEL].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTUP_DIAG_LEVEL].base_addr = 0x1921;
#endif
    p_card->p_eeprom_alloc[EEPROM_SERIALNO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SERIALNO].base_addr = 0x1220;
    p_card->p_eeprom_alloc[EEPROM_SYS_MAC].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SYS_MAC].base_addr = 0x1240;
    p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE].base_addr = 0x1260;
    p_card->p_eeprom_alloc[EEPROM_BR_PROFILE].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BR_PROFILE].base_addr = 0x1280;

    p_card->p_eeprom_alloc[EEPROM_BOOTCMD].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_BOOTCMD].base_addr = 0x0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_OEM_INFO].base_addr = 0x1300;
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    p_card->p_eeprom_alloc[EEPROM_SMARTCFG].eeprom_idx = 0;
    p_card->p_eeprom_alloc[EEPROM_SMARTCFG].base_addr = 0x1265;
#endif /* !HAVE_SMARTCFG */
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_fiber(void)
{
    int32 ret = 0;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber begin.");
	
    /* Release reset for GreatBelt mac led signal, before fiber init */
    ret = fiber_init(GLB_E350_8T12X_12XG_MAX_PORT, /* fiber num */
                 GLB_E350_8T12X_12XG_MAX_PORT+GLB_E350_8T12X_8T_MAX_PORT, /* port num */
                 lcm_e350_8t12x_fiber);

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fiber end.");

    return ret;
}

static int32
_lcm_init_e350_8t12x_sensor(void)
{
    int32 i, ret = 0;
    i2c_gen_t i2c_gen[E350_8T12X_SENSOR_NUM];
    sensor_chip_t sensor_chip[E350_8T12X_SENSOR_NUM];
    void *p_data[E350_8T12X_SENSOR_NUM];

    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = E350_8T12X_ADDR_SENSOR;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    sensor_chip[0].io_type = SENSOR_I2C;
    i2c_gen[0].alen = LM75_OFFSET_WIDTH;
    sensor_chip[0].chip_type = SENSOR_LM75;

    for(i=0; i<E350_8T12X_SENSOR_NUM; i++)
    {
        p_data[i] = &i2c_gen[i];
    }
    ret = sensor_init(p_data, sensor_chip, E350_8T12X_SENSOR_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Temperature sensor init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(i=0; i<E350_8T12X_SENSOR_NUM; i++)
    {
        sensor_dev_init(i);
    }
    return LCM_E_SUCCESS;
}

/* Added by liuht for bug26671, 2014-02-14 */
static int32
_lcm_init_e350_8t12x_fan(void)
{
    int32 ret = 0;
    uint8 fan_module_idx;
    fan_chip_t fan_chip[E350_8T12X_FAN_MODULE_MAX];
    uint8 epld_idx[E350_8T12X_FAN_MODULE_MAX];	
    void *p_data[E350_8T12X_FAN_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module begin.");

    epld_idx[0] = 0;
    fan_chip[0].chip_type = FAN_EPLD;
    fan_chip[0].io_type = E_FAN_EPLD;
    fan_chip[0].support_hot_swap = 0;  /* stable on GB mother board, do not support hot swap */
    fan_chip[0].fan_num = 3;
    fan_chip[0].speed_adjust = 1;
    p_data[0]= &epld_idx[0];	

    ret = fan_init(p_data, fan_chip, E350_8T12X_FAN_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Fan driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    for(fan_module_idx=0; fan_module_idx<E350_8T12X_FAN_MODULE_MAX; fan_module_idx++)
    {
        fan_dev_init(fan_module_idx);
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init fan module end.");
    return LCM_E_SUCCESS;
}

#if 0
static int32
_lcm_init_e350_8t12x_psu(void)
{
    int32 ret;
    uint8 psu_module_idx;
    uint8 epld_idx[E350_8T12X_PSU_MODULE_MAX];
    //i2c_gen_t i2c_gen[V350_PSU_MODULE_MAX];
    psu_chip_t psu_chip[E350_8T12X_PSU_MODULE_MAX];
    void *p_data[E350_8T12X_PSU_MODULE_MAX];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init psu module begin.");
    //sal_memset(i2c_gen, 0, sizeof(i2c_gen));

#if 0
    i2c_gen[0].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[0].p_br.bridge_addr = V350_I2C_BRIDGE_ADDR;
    i2c_gen[0].p_br.channel = 6;
    i2c_gen[0].addr = V350_ADDR0_PSU;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 1;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[0].chip_type = PSU_I2C;
    psu_chip[0].io_type = PSU_IO_I2C;
    psu_chip[0].psu_type = PSU_SHOW_FULL_STATUS;
    p_data[0] = &i2c_gen[0];

    i2c_gen[1].p_br.i2c_br_type = I2C_BR_CPM;
    i2c_gen[1].p_br.bridge_addr = V350_I2C_BRIDGE_ADDR;
    i2c_gen[1].p_br.channel = 6;
    i2c_gen[1].addr = V350_ADDR1_PSU;
    i2c_gen[1].i2c_type = E_I2C_CPM;
    i2c_gen[1].alen = PSU_I2C_OFFSET_WIDTH;
    i2c_gen[1].bridge_flag = 1;
    i2c_gen[1].i2c_bus_idx = GLB_I2C_IDX_0;
    psu_chip[1].chip_type = PSU_I2C;
    psu_chip[1].io_type = PSU_IO_I2C;
    psu_chip[1].psu_type = PSU_SHOW_FULL_STATUS;
    p_data[1] = &i2c_gen[1];
#endif

    for(psu_module_idx=0; psu_module_idx<E350_8T12X_PSU_MODULE_MAX; psu_module_idx++)
    {
        epld_idx[psu_module_idx] = 0;
        psu_chip[psu_module_idx].chip_type = PSU_EPLD;
        psu_chip[psu_module_idx].io_type = PSU_IO_EPLD;
        psu_chip[psu_module_idx].psu_type = PSU_SHOW_FULL_STATUS;
        p_data[psu_module_idx] = &epld_idx[psu_module_idx];
    }

    ret = psu_init(p_data, psu_chip, E350_8T12X_PSU_MODULE_MAX);
    if(ret < 0)
    {
        LCM_LOG_ERR("Psu driver init fail.");
        return LCM_E_INIT_FAILED;
    }
    return LCM_E_SUCCESS;
}
#endif
static int32
_lcm_init_e350_8t12x_eeprom(void)
{
    int32 ret = 0;
    i2c_gen_t i2c_gen[E350_8T12X_EEPROM_NUM];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom begin.");
    sal_memset(i2c_gen, 0, sizeof(i2c_gen));

    i2c_gen[0].addr = E350_8T12X_ADDR_EEPROM;
    i2c_gen[0].i2c_type = E_I2C_CPM;
    i2c_gen[0].alen = EEPROM_OFFSET_WIDTH;
    i2c_gen[0].bridge_flag = 0;
    i2c_gen[0].i2c_bus_idx = GLB_I2C_IDX_0;

    ret = eeprom_init(i2c_gen, E350_8T12X_EEPROM_NUM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm EEPROM init fail.");
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init eeprom end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_phy(void)
{
    uint16 port_id;
    phy_info_t phyinfo;
    phy_handle_t** pphdl = NULL;
    int32 ret;

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy begin.");
    /* release GE phy */
    epld_item_write(0, EPLD_PHY_RST, 0x1);

    sal_delay(5);
    sal_memset(&phyinfo, 0, sizeof(phy_info_t));
    pphdl = (phy_handle_t**)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE,
        sizeof(phy_handle_t*)*(glb_card->port_num));

    if(NULL == pphdl)
    {
        LCM_LOG_ERR("LCM phy no memory.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < (glb_card->port_num); port_id++)
    {
        if(port_id < GLB_E350_8T12X_8T_MAX_PORT) /* 8G with PHYs */
        {
            phyinfo.phy_device_type = PORT_PHY_VSC8x58;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_RJ45;
            phyinfo.phy_manage_info.mac_if = GLB_MAC_INTERFACE_SGMII;
            phyinfo.vct_support = 1;
            phyinfo.port.phy_addr = lcm_e350_8t12x_port[port_id].phy_addr;
            phyinfo.mdio_bus = ASIC_GB_PHY_1G_TYPE;
            phyinfo.led_type = GLB_PHY_LED_5;
            phyinfo.base_addr = 0;


            phyinfo.phy_manage_info.speed = GLB_SPEED_AUTO;
            phyinfo.phy_manage_info.duplex = GLB_DUPLEX_AUTO;
        }
        else  /* 12XG without PHYs */
        {
            phyinfo.phy_device_type = PORT_PHY_NULL;
            phyinfo.phy_manage_info.media_type = GLB_MEDIA_SFP_PLUS;
            phyinfo.phy_manage_info.mac_if = GLB_MAC_INTERFACE_SERDES;
            phyinfo.phy_manage_info.speed = GLB_SPEED_10G;
            phyinfo.phy_manage_info.duplex = GLB_DUPLEX_FULL;
            if (lcm_mgt_is_enable_stack())
            {
                phyinfo.port.port_info.port_id = GLB_TRANS_PORTID_TO_GPORT(
                    lcm_mgt_get_stack_member(), lcm_e350_8t12x_port[port_id].mac_idx);
            }
            else
            {
                phyinfo.port.port_info.port_id = lcm_e350_8t12x_port[port_id].mac_idx;
            }
        }
        phyinfo.port.port_info.lchip = glb_card->pp_port[port_id]->local_chip_idx;
        phyinfo.port.port_info.serdes_id = glb_card->pp_port[port_id]->chip_serdes_id;

        /* Modified by liuht for access port id in phy handle for bug 25808 */	
        phyinfo.port_num = port_id;


        /*********************************************************************
         * Default:
         * PHY_WORK_MODE_NORMAL GLB_LB_NONE GLB_SPEED_AUTO
         * GLB_DUPLEX_AUTO
         ********************************************************************/
        phyinfo.phy_manage_info.mode = PHY_WORK_MODE_NORMAL;
        phyinfo.phy_manage_info.lb_mode = GLB_LB_NONE;
        phyinfo.phy_manage_info.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl.recv= GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_manage_info.flowctrl_ability.asymmetric_pause = 0;
        phyinfo.phy_manage_info.flowctrl_ability.symmetric_pause = 0;

        phyinfo.phy_stat_flag.duplex = phyinfo.phy_manage_info.duplex;
        phyinfo.phy_stat_flag.speed = phyinfo.phy_manage_info.speed;
        phyinfo.phy_stat_flag.link_up = GLB_LINK_DOWN;
        phyinfo.phy_stat_flag.flowctrl.send = GLB_FLOWCTRL_DISABLE;
        phyinfo.phy_stat_flag.flowctrl.recv = GLB_FLOWCTRL_DISABLE;

        pphdl[port_id] = phy_dev_register(&phyinfo);
        if(NULL ==  pphdl[port_id])
        {
            LCM_LOG_ERR("Register phy handle failed\n");
            return LCM_E_INIT_FAILED;
        }
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm ready to init phy.");
    ret = phy_init(pphdl, (glb_card->port_num));
    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init phy end.");
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_reset_device(void)
{
    /* make sure the states of every device before init is reset */

    /* reset GE phy */
    epld_item_write(0, EPLD_PHY_RST, 0x0);


    sal_task_sleep(100);

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_i2c(void)
{
    int32 ret;

    epld_item_write(0, EPLD_I2C_BRIDGE_RST, 0x1);
    sal_task_sleep(100);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus begin.");

    ret = i2c_open(E_I2C_CPM);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init i2c bus failed.");
        return LCM_E_HW_CLKGEN_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init i2c bus end.");

    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_led(void)
{
    int32 ret = 0;
    led_info_t led_info[E_MAX_LED];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED begin.");
    sal_memset(led_info, 0, sizeof(led_info_t)*E_MAX_LED);

    /* Modified by liuht to support system led in E350-8T12X for bug 25677, 2013-12-09 */
    /* init sys led */
    led_info[E_SYS_LED].exist = 1;
    led_info[E_SYS_LED].led_para[E_LED_SYS_INIT].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_INIT].val = 0x6;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_RUN].val = 0x5;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ABNORMAL].val = 0x7;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_ALARM].val = 0x7;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].op_reg = EPLD_SYS_LED_SYS;
    led_info[E_SYS_LED].led_para[E_LED_SYS_NO_ALARM].val = 0x5;
	
    ret = led_init(led_info);
    if(ret < 0)
    {
        LCM_LOG_ERR("Init LEDs failed.");
        return LCM_E_HW_LED_GEN;
    }
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init LED end.");

    return LCM_E_SUCCESS;
}
/* Added by qicx for E350 XG MAC LED, bug24348, 2013-08-13 */
static int32
_lcm_init_e350_8t12x_ctc_chip_led(void)
{
    mac_led_api_para_t port_led[32];
    uint8 port_num, port;
    int32 ret;
    
    /*release serial LED reset*/
    sal_task_sleep(1000);
    epld_item_write(0, EPLD_SERIAL_LED_RST, 0x1);

    port_num = 20; /* all ports LED are controlled by GB */
    for(port=0; port<port_num; port++)
    {
        port_led[port].port_id = lcm_e350_8t12x_mac_led[port] \
                                     | (glb_card->pp_port[port]->glb_chip_idx << 8);
        port_led[port].lchip   = lcm_e350_8t12x_port[port].chip_idx;
        port_led[port].mode    = LED_MODE_2_RXLNK_BIACT;
    }
        
    ret = mac_led_init(port_led, port_num);
    if (ret < 0)
    {
        LCM_LOG_ERR("Init CTC Chip LEDs failed.");
        return LCM_E_HW_LED_GEN;
    }
    return LCM_E_SUCCESS;
}

static int32
_lcm_init_e350_8t12x_ctc_reset(void)
{    
    /*release serial LED reset*/
    epld_item_write(0, EPLD_RESET_INT_MASK, 0x0);
    return LCM_E_SUCCESS;
}

/* Added by liuht for E350-8T12X to initialize serdes, 2013-11-21 */
int32
lcm_init_e350_8t12x_serdes(void)
{
    ctc_chip_serdes_ffe_t serdes_ffe;
    uint8 serdes_id, index;

    serdes_ffe.board_material = 0;
    for(index=0; index<12; index++)
    {
        serdes_id = lcm_e350_8t12x_serdes_trace_len[index][0];
        serdes_ffe.serdes_id = serdes_id;
        serdes_ffe.trace_len = lcm_e350_8t12x_serdes_trace_len[index][1];
        ctc_chip_set_property(0, CTC_CHIP_PROP_SERDES_FFE, (void *)&serdes_ffe);
    }
    return LCM_E_SUCCESS;
}

#ifdef BOOTUP_DIAG
/* Added by liuht to support bootup diag for bug24982, 2013-12-21 */
static int32
_lcm_init_e350_8t12xg_bootup_diag(glb_card_t* p_card)
{
    /* get bootup diagnostic level */
    char buf[1024];
    FILE *fp;
   
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init e350 8t12xg bootup diag begin.");
 
    fp = sal_fopen(GLB_STARTUP_CONFIG_FILE_PATH, "r");
    if(NULL == fp)
    {
        p_card->bootup_diag_level = E_DIAG_LEVEL_NO;
        LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init e350 8t12xg bootup diag end.");
        return LCM_E_SUCCESS;
    }

    /* Added by liuht for bug26642, 2013-01-20 */
    p_card->bootup_diag_level = E_DIAG_LEVEL_NO;   
    while(sal_fgets(buf, 1024, fp))
    {
        if(NULL != sal_strstr(buf, "diagnostic bootup level"))
        {
            if(NULL != sal_strstr(buf, "complete"))
            {
                 p_card->bootup_diag_level = E_DIAG_LEVEL_COMPLETE;
            }
            else if(NULL != sal_strstr(buf, "minimal"))
            {
                p_card->bootup_diag_level = E_DIAG_LEVEL_MINIMAL;
            }
            else
            {
                p_card->bootup_diag_level = E_DIAG_LEVEL_NO;
            }
            break;
        }
    }
    sal_fclose(fp);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init e330 48s bootup diag end.");

    return LCM_E_SUCCESS;

}
#endif  

int32
lcm_init_e350_8t12x_cb(void)
{
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback begin.");
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_fiber());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_phy());
    /* Added by qicx for E350 XG MAC LED, bug24348, 2013-08-13 */
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_ctc_chip_led());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_ctc_reset());
    /* Added by liuht for E350-8T12X to initialize serdes, 2013-11-21 */
    LCM_IF_ERROR_RETURN(lcm_init_e350_8t12x_serdes());
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init callback end.");

    return LCM_E_SUCCESS;
}

int32
lcm_init_e350_8t12x(glb_card_t* p_card)
{
    FILE *fp;
    char buf[BUFSIZ];

    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board begin.");
    glb_card = p_card;
    p_card->asic_chip_num = 1;
    
    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        fgets (buf, BUFSIZ, fp);
        p_card->logic_slot_no = atoi(buf);
        p_card->phy_slot_no = p_card->logic_slot_no;
        sal_fclose(fp);
    }
    else
    {
        p_card->logic_slot_no = 1;
        p_card->phy_slot_no = 0;
    }
    /* modified by liuht for bug 27331, 2014-04-22 */
    g_slot_id = p_card->phy_slot_no;
    /* end of liuht modified */
    p_card->l2switch_num = 0;
    p_card->sensor_num = E350_8T12X_SENSOR_NUM;
    /* Added by liuht for bug26671, 2014-02-14 */
    /* When hardware version > 1.0,  support fan management */
    if(p_card->hw_ver > 0x10)
    {
        p_card->fan_module_num = E350_8T12X_FAN_MODULE_MAX;
    }
    else
    {
        p_card->fan_module_num = 0;
    }
    p_card->psu_module_num = E350_8T12X_PSU_MODULE_MAX;
    p_card->phy_interrupt_mode = GLB_PHY_INTERRUPT_MODE_EPLD;   /*get phy interrupt info from EPLD*/
    p_card->cpu_type = GLB_CPU_PPC_P1014;
    p_card->phy_chip_num = 1;   /* 1 VSC8558 PHYs */
    p_card->phy_int_bit_num = E350_8T12X_PHY_INT_BITS_SUM;

    p_card->port_num = GLB_E350_8T12X_8T_MAX_PORT + GLB_E350_8T12X_12XG_MAX_PORT;
    p_card->p_port_range = lcm_e350_8t12x_phy_chip_port_range;

    /* for some board like e350 8t12xg don't support ptp, added by jcao for bug 25500, 2013-10-25 */
    p_card->ptp_en = 0;
    p_card->epld_type = GLB_EPLD_TYPE_JAM;
    p_card->bootrom_type = E_BOOTROM_TYPE_512K;
    
    sal_snprintf(p_card->cfg_profile_name, DATAPATH_LEN_MAX, "%s%s",
        DATAPATH_PROFILE_PATH, E350_8T12X_DATAPATH_NAME);
    _lcm_init_e350_8t12x_cpu_info();
    ctc_hw_fd_init();
    ctc_reset_fd_init();
    
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL,
                  "card product type %x, board type %x.", p_card->board_type.series, p_card->board_type.type);
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_epld(p_card, p_card->epld_ver));
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_eeprom_info(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_led());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_reset_device());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_i2c());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_eeprom());
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_port(p_card));
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_sensor());
    /* Added by liuht for bug26671, 2014-02-14 */
    /* When hardware version > 1.0,  support fan management */
    if(p_card->hw_ver > 0x10)
    {
        LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_fan());
    }
#if 0	
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12x_psu());
#endif	
    /* Enable 12XG TX */
    LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_SFP_DISABLE1, 0x0));
    LCM_IF_ERROR_RETURN(epld_item_write(0, EPLD_SFP_DISABLE2, 0x0));
#ifdef BOOTUP_DIAG
    LCM_IF_ERROR_RETURN(_lcm_init_e350_8t12xg_bootup_diag(p_card));
#endif
    lcm_card_init_callback(lcm_init_e350_8t12x_cb);
    LCM_LOG_DEBUG(lcm, card, LCM_CARD_NORMAL, "Lcm init board end.");

    return LCM_E_SUCCESS;
}
#endif
