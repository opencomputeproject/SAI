/****************************************************************************
* $Id$
*  sw eumlation (UML) init functions
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : zhuj
* Date          : 2010-08-11
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
* 
****************************************************************************/
#include "sal_common.h"
#include "lcm_specific.h"
#include "glb_hw_define.h"
#include "glb_if_define.h"
#include "lcm_debug.h"
#include "lcm_error.h"
#include "glb_distribute_system_define.h"
#include "glb_tempfile_define.h"
#include "lcm_card.h"
/****************************************************************************
*
* Global and Declarations  
*
****************************************************************************/

#define SW_EMU_PANEL_PORT_NUM 24

uint8_t E300_SW_EUM_PORT_MAP[48][5] = 
{
    {22,  1, -1, -1, -1},
    {23,  0, -1, -1, -1},
    {20,  3, -1, -1, -1},
    {21,  2, -1, -1, -1},
    {18,  5, -1, -1, -1},
    {19,  4, -1, -1, -1},
    {16,  7, -1, -1, -1},
    {17,  6, -1, -1, -1},
    {14,  9, -1, -1, -1},
    {15,  8, -1, -1, -1},
    {12, 11, -1, -1, -1},
    {13, 10, -1, -1, -1},
    {10, 13, -1, -1, -1}, 
    {11, 12, -1, -1, -1},
    {8,  15, -1, -1, -1},
    {9,  14, -1, -1, -1},
    {6,  17, -1, -1, -1},
    {7,  16, -1, -1, -1},
    {4,  19, -1, -1, -1},
    {5,  18, -1, -1, -1},
    {2,  21, -1, -1, -1},
    {3,  20, -1, -1, -1},
    {0,  23, -1, -1, -1},
    {1,  22, -1, -1, -1},
    {22,  1, -1, -1, -1},
    {23,  0, -1, -1, -1},
    {20,  3, -1, -1, -1},
    {21,  2, -1, -1, -1},
    {18,  5, -1, -1, -1},
    {19,  4, -1, -1, -1},
    {16,  7, -1, -1, -1},
    {17,  6, -1, -1, -1},
    {14,  9, -1, -1, -1},
    {15,  8, -1, -1, -1},
    {12, 11, -1, -1, -1},
    {13, 10, -1, -1, -1},
    {10, 13, -1, -1, -1}, 
    {11, 12, -1, -1, -1},
    {8,  15, -1, -1, -1},
    {9,  14, -1, -1, -1},
    {6,  17, -1, -1, -1},
    {7,  16, -1, -1, -1},
    {4,  19, -1, -1, -1},
    {5,  18, -1, -1, -1},
    {2,  21, -1, -1, -1},
    {3,  20, -1, -1, -1},
    {0,  23, -1, -1, -1},
    {1,  22, -1, -1, -1},
};

extern bool lcm_def_port_prefix;
extern int32 lcm_get_port_info(glb_card_t* p_card);
//extern int32 lcm_parse_split_cli(char *cli_str, uint32 *panel_slot, uint32 *panel_port, uint32 *speed);

/****************************************************************************
 *
* Function
* 
****************************************************************************/ 
static int32
_lcm_init_sw_emu_cpu_info()
{
    FILE * fp;

    fp = sal_fopen(GLB_CPU_IF_INFO_FILE, "w+");
    if(fp ==NULL)
    {
        LCM_LOG_ERR("Open cpu info file error.");
        return LCM_E_FILE_OPEN;
    }
    sal_fprintf(fp, "MGMT_IF eth99\n");
    sal_fprintf(fp, "CPU_IF NOTUSE\n");
    sal_fclose(fp);
    return LCM_E_SUCCESS;
}

extern int32 lcm_parse_numchg_cli(glb_card_t* p_card, char *cli_str, uint32 *panel_slot, uint32 *panel_port, uint32 *speed);

#ifdef GOLDENGATE
static int32
_sw_emu_parse_port_split_info(glb_card_t* p_card,/*lcm_card_port_split_info_t* port_split_info,*/ uint8* port_num)
{
    FILE *startup_config_fp = NULL;
    uint32 panel_slot_no, panel_port_no, speed;
    uint8 ppt_id;
    uint8 tmp_port_num;
    char buf[256];

    /* 1, Allocate panel port memory */
    p_card->pp_ppt = (glb_panel_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, 
        sizeof(glb_panel_port_t* )* p_card->panel_port_num);
    if (!p_card->pp_ppt)
    {
        LCM_LOG_ERR("Allocate pointer to global panel ports fail.");
        return LCM_E_NO_MEMORY;
    }

    for(ppt_id = 0; ppt_id < SW_EMU_PANEL_PORT_NUM; ppt_id++)
    {
        p_card->pp_ppt[ppt_id] = (glb_panel_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_panel_port_t));
        if(!p_card->pp_ppt[ppt_id])
        {
            LCM_LOG_ERR("Allocate global panel ports fail.");
            return LCM_E_NO_MEMORY;
        }
        
        p_card->pp_ppt[ppt_id]->ppt_idx = ppt_id + 1;
        p_card->pp_ppt[ppt_id]->pslt_id = p_card->phy_slot_no;
        p_card->pp_ppt[ppt_id]->ppt_numchg_type = GLB_PPT_NUMCHG_TYPE_NONE;
        p_card->pp_ppt[ppt_id]->op = GLB_PPT_OP_SPLIT;
        p_card->pp_ppt[ppt_id]->ppt_numchg_num = 1;///TODO: need optimize
        p_card->pp_ppt[ppt_id]->ppt_speed_ability = GLB_SUPPORT_SPEED_40G;
        p_card->pp_ppt[ppt_id]->ppt_speed_real = GLB_SUPPORT_SPEED_40G;
    }
    tmp_port_num = SW_EMU_PANEL_PORT_NUM;

    /*get port prefix form eeprom (uml form flash), should be used to parse/check split cli*/
    lcm_get_port_info(p_card);
    startup_config_fp = sal_fopen(GLB_STARTUP_CONFIG_FILE_PATH, "r");
    if (startup_config_fp)
    {
        while (sal_fgets(buf, 128, startup_config_fp))
        {
            if (sal_strncmp(buf, "split interface", sal_strlen("split interface")))
            {
                continue;
            }
            if (lcm_parse_numchg_cli(p_card, buf, &panel_slot_no, &panel_port_no, &speed))
            {
                continue;
            }
            if (panel_port_no > SW_EMU_PANEL_PORT_NUM)
            {
                continue;
            }
            if (panel_slot_no == p_card->pp_ppt[panel_port_no-1]->pslt_id)
            {
                p_card->pp_ppt[panel_port_no-1]->ppt_speed_ability = GLB_SUPPORT_SPEED_10G | GLB_SUPPORT_SPEED_1G;
                p_card->pp_ppt[panel_port_no-1]->ppt_numchg_type = GLB_PPT_NUMCHG_TYPE_10G;
                p_card->pp_ppt[panel_port_no-1]->ppt_numchg_num = 4;
                tmp_port_num += 3;
            }
        }
        sal_fclose(startup_config_fp);
    }
    *port_num = tmp_port_num;
    return 0;
}


static int32
_sw_emu_mapping_port(glb_card_t* p_card, lcm_card_port_panel_mapping_t* port_panel_mapping)
{
    int32 port_id=0;
    uint8 ppt_id=0;
    uint8 panel_subport_no=0;

    /* mapping panel port info with port id */
    for (ppt_id = 0; ppt_id < SW_EMU_PANEL_PORT_NUM; ppt_id++)
    {
        if (GLB_PPT_NUMCHG_TYPE_NONE == p_card->pp_ppt[ppt_id]->ppt_numchg_type)
        {
            port_panel_mapping[port_id].panel_slot_no = p_card->pp_ppt[ppt_id]->pslt_id;
            port_panel_mapping[port_id].panel_port_no = p_card->pp_ppt[ppt_id]->ppt_idx;
            port_panel_mapping[port_id].panel_subport_no = 0;
            port_id++;
        }
        else
        {
            for (panel_subport_no = 0; panel_subport_no < p_card->pp_ppt[ppt_id]->ppt_numchg_num; panel_subport_no++)
            {
                port_panel_mapping[port_id].panel_slot_no = p_card->pp_ppt[ppt_id]->pslt_id;
                port_panel_mapping[port_id].panel_port_no = p_card->pp_ppt[ppt_id]->ppt_idx;
                port_panel_mapping[port_id].panel_subport_no = panel_subport_no+1;
                port_id++;
            }
        }

    }
    return 0;
}

static int32
_sw_emu_init_port(glb_card_t* p_card)
{
    int32 port_id;
    uint8 panel_port_idx = 0;
    uint8 port_num=0;
    lcm_card_port_panel_mapping_t port_panel_mapping[256];
    //lcm_card_port_split_info_t port_split_info[SW_EMU_PANEL_PORT_NUM];
                  
    _sw_emu_parse_port_split_info(p_card, &port_num);
    _sw_emu_mapping_port(p_card, port_panel_mapping);
    p_card->port_num = port_num;
    /* alloc ports */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }

    for (port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }

        panel_port_idx = port_panel_mapping[port_id].panel_port_no;
        p_card->pp_port[port_id]->logic_port_idx = port_id;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = p_card->logic_slot_no;
#ifdef _GLB_DISTRIBUTE_SYSTEM_
        p_card->pp_port[port_id]->glb_chip_idx = p_card->logic_slot_no - 3;
#else
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
#endif
        p_card->pp_port[port_id]->local_chip_idx = 0;
        /*Fix bug 14686. jqiu 2011-06-15*/
        p_card->pp_port[port_id]->panel_slot_no = port_panel_mapping[port_id].panel_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_panel_mapping[port_id].panel_port_no;
        p_card->pp_port[port_id]->panel_sub_port_no = port_panel_mapping[port_id].panel_subport_no;
        p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_AUTO;
        p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_UNKNOWN;
        p_card->pp_port[port_id]->port_speed_ability = p_card->pp_ppt[panel_port_idx-1]->ppt_speed_ability;
        p_card->pp_port[port_id]->port_speed_real = p_card->pp_ppt[panel_port_idx-1]->ppt_speed_real;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_FULL;
        if (p_card->pp_ppt[panel_port_idx-1]->ppt_speed_ability & GLB_SUPPORT_SPEED_40G)
        {
            p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_40G;
        }
        else if (p_card->pp_ppt[panel_port_idx-1]->ppt_speed_ability & GLB_SUPPORT_SPEED_10G)
        {
            p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_10G;
        }
        else
        {
            p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_1G;
        }
        
        p_card->pp_port[port_id]->port_status.link_up = 0;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 1;
    }
     lcm_common_save_port_info_file(p_card);
    return LCM_E_SUCCESS;
}
#else

static int32
_sw_emu_save_port_file(glb_card_t* p_card)
{
    uint16 port_id = 0;
    FILE *port_info_fd = NULL;
    glb_port_t *p_port = NULL;
    
    /*add by weij for interface expend, bug 14686*/
    port_info_fd = sal_fopen(GLB_PORT_INFO_FILE, "w");
    if (port_info_fd == NULL)
    {
        LCM_LOG_ERR("Open the interface info file failed!\n");
        return -1;
    }

    /*
        add by weij for tmp test cli
        port_type: 0->NULL(shouldn't be used); 1->eth; 2->NAME1; 3->NAME2; ......
        slot_id:prefix-*-1  or prefix-*-1-1
        port_id:prefix-0-*  or prefix-0-*-1
        sub_port_id:0->isn't sub-port; 4->is sub_port and the id is 4
    */
    for (port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];
        sal_fprintf (port_info_fd, "port %d %d %d %d\n", 1, p_port->panel_slot_no, p_port->panel_port_no, p_port->panel_sub_port_no);
    }
    sal_fclose(port_info_fd);
    
    return 0;
}

/* GREATBELT */

static int32
_sw_emu_init_port(glb_card_t* p_card)
{
    int32 port_id;
    //uint8 port_num;
    
    p_card->port_num = 24;

    /* alloc ports */
    p_card->pp_port = (glb_port_t** )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t* )* p_card->port_num);
    if (!p_card->pp_port)
    {
        LCM_LOG_ERR("Allocate pointer to global ports fail.");
        return LCM_E_NO_MEMORY;
    }

    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_card->pp_port[port_id] = (glb_port_t* )XCALLOC(CTCLIB_MEM_LCM_PORT, sizeof(glb_port_t));
        if(!p_card->pp_port[port_id])
        {
            LCM_LOG_ERR("Allocate global ports fail.");
            return LCM_E_NO_MEMORY;
        }

        p_card->pp_port[port_id]->logic_port_idx = port_id;
        p_card->pp_port[port_id]->port_idx = port_id + 1;
        p_card->pp_port[port_id]->logic_slot_idx = p_card->logic_slot_no;
#ifdef _GLB_DISTRIBUTE_SYSTEM_
        p_card->pp_port[port_id]->glb_chip_idx = p_card->logic_slot_no - 3;
#else
        p_card->pp_port[port_id]->glb_chip_idx = p_card->phy_slot_no;
#endif
        p_card->pp_port[port_id]->local_chip_idx = 0;
        /*Fix bug 14686. jqiu 2011-06-15*/
        p_card->pp_port[port_id]->panel_slot_no = p_card->phy_slot_no;
        p_card->pp_port[port_id]->panel_port_no = port_id+1;
        p_card->pp_port[port_id]->port_cfg.media = GLB_PORT_TYPE_COPPER;
        p_card->pp_port[port_id]->phy_type = GLB_PHY_TYPE_1000BASE_T;
        p_card->pp_port[port_id]->port_speed_ability = GLB_SUPPORT_SPEED_1G;
        p_card->pp_port[port_id]->port_status.duplex = GLB_DUPLEX_FULL;
        p_card->pp_port[port_id]->port_status.speed = GLB_SPEED_1G;
        p_card->pp_port[port_id]->port_status.link_up = 0;
        p_card->pp_port[port_id]->port_cfg.duplex = GLB_DUPLEX_AUTO;
        p_card->pp_port[port_id]->port_cfg.speed = GLB_SPEED_AUTO;
        p_card->pp_port[port_id]->port_cfg.loopback = GLB_LB_NONE;
        p_card->pp_port[port_id]->port_cfg.enable = 1;
    } 
    _sw_emu_save_port_file(p_card);
   // _sw_emu_parse_port_split_info(p_card, &port_num);
    return LCM_E_SUCCESS;
}

#endif /* GOLDENGATE */

int32
lcm_init_sw_emu(glb_card_t* p_card)
{    
    FILE *fp;
    char buf[BUFSIZ];
    
    p_card->asic_chip_num = 1;
    
    fp = sal_fopen(GLB_SLOT_NO_FILE, "r");
    if (fp)
    {
        sal_fgets (buf, BUFSIZ, fp);
        p_card->logic_slot_no = atoi(buf);
        p_card->phy_slot_no = p_card->logic_slot_no;
        sal_fclose(fp);
    }
    else
    {
        p_card->logic_slot_no = 1;
        p_card->phy_slot_no = 0;
    }

    p_card->board_type.series = GLB_SERIES_E350;
    p_card->board_type.type = GLB_BOARD_E350_48T4XG;
    p_card->panel_port_num = SW_EMU_PANEL_PORT_NUM;
    _lcm_init_sw_emu_cpu_info();
    LCM_IF_ERROR_RETURN(_sw_emu_init_port(p_card));
    
    return LCM_E_SUCCESS;
}

