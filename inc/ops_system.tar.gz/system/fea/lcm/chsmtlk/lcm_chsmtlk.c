/****************************************************************************
 * lcm_chsmtlk.c:   lcm communicate with chassis manager 
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     :       R0.01
 * Author       :       Zhuj
 * Date         :       2010-08-11
 * Reason       :       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "glb_hw_define.h"
#include "lcapi.h"
#include "lcm_client.h"
#include "lcm_mgt.h"
#include "lcm_card.h"
#include "lcm_error.h"
#include "lcm_debug.h"
#include "lcm_chsmtlk.h"
#include "lcm_hagttlk.h"
#include "ctc_pci.h"
#include "eeprom_api.h"
#include "glb_stm_define.h"
#include "led_api.h"
#include "sensor_api.h"
#include "sensor_drv.h"
#include "epld_api.h"
#include "power_api.h"
#include "fan_api.h"
#include "mux_api.h"
#include "bootrom_drv.h"
#include "ctclib_show.h"
#include "fiber_api.h"
#include "epld_api.h"
#include "poe_api.h"
#include "phy_api.h"
#include "lcm_log.h"
#include "dal.h"
#ifdef BOOTUP_DIAG
#include "lcm_diag.h"
#include "diag_types.h"
#include "diag_pkt_drv.h"
#endif

#ifdef _GLB_SHOW_FORWARD_ENABLE_ 
#include "ctcutil_pkt.h"
#include "lcm_show_forward.h"
#endif /* _GLB_SHOW_FORWARD_ENABLE_ */
#include "lcm_client.h"
#include "glb_distribute_system_define.h"

#include "glb_if_define.h"
#include "ctclib_sys_cmd.h"

#include "sai.h"
#include "ctc_sai_common.h"
#include "laiinc.h"
/****************************************************************************
 *  
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *  
* Global and Declaration
*
*****************************************************************************/
lcm2hagt_callback_t lcm2hagt_cb[LCM2HAGT_CB_TYPE_MAX] = {0};
card_init_callback_t lcm_card_init_cb;
static struct timespec g_last_update_bootrom_time;

int g_bDebug = 0;   /* debug flag : will not do keepalive if set */
int g_bSDKinit = FALSE; 
/* Modified by liuht for bug 26911, 2014-03-27 */
int g_sys_led_alarm = 0;

#ifndef _GLB_UML_SYSTEM_
extern int32
lcm_poe_daughter_card_mode(uint32 mode);
#endif
/* Modified by liuht for bug 24982, 2014-03-19 */
#ifdef BOOTUP_DIAG
extern int32 
lcm_diag_tx_bootup_diag_result(lcm_clnt_t *clnt);
#endif

extern int32 lcm_ftm_read_profile_mode(uint32* p_mode);
extern int32 lcm_ftm_read_memory_profile(uint8 tcam_mode, glb_stm_profile_info_t* p_asic_info);
extern int32 lcm_notify_fiber_info(glb_port_t* p_port, lcm_fiber_notify_event_e notify_flag);

void lcm_chk_rx_keepalive_cb(void* p_data);
LCM_DEFINE_TASK_ENCAP(lcm_chk_rx_keepalive_cb)

#ifndef _GLB_UML_SYSTEM_
void lcm_vct_async_timeout(void* p_data);
LCM_DEFINE_TASK_ENCAP(lcm_vct_async_timeout)
#endif

#ifdef _LCM_OSP_
int32 
lcm_msg_tx_lcAttach_sock(int32 sock)
{
    lcm_clnt_t *p_clnt = lcm_get_lcm_client();
    lcm_msg_tx_lcAttach(p_clnt);
#ifndef _GLB_UML_SYSTEM_
    lcm_msg_tx_lcRebootInfo(p_clnt);
#endif
    return LCM_E_SUCCESS;
}
#endif

/****************************************************************************
 *  
* Function
*
*****************************************************************************/
int32 
lcm_msg_tx_lcAttach(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 ret = 0;
    glb_card_t* p_card = NULL;
//#ifdef _GLB_UML_SYSTEM_
    uint32 stm_mode = 0;
//#endif /*_GLB_DISTRIBUTE_SYSTEM_*/
       
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm send lcAttach : card is NULL.");
        return LCM_E_INVALID_PTR;
    }

    lcm_mgt_get_sw_info(p_card);
    sal_memset(&msg, 0, sizeof(LcmMsg_t));

    msg.op.present = op_PR_lcAttach;
    msg.op.lcAttach.logicSlot = p_card->logic_slot_no;
    msg.op.lcAttach.phySlot= p_card->phy_slot_no;
    msg.op.lcAttach.portNum = p_card->port_num;
    msg.op.lcAttach.poePortNum = p_card->poe_port_num;
    msg.op.lcAttach.lcType.series = p_card->board_type.series;
    msg.op.lcAttach.lcType.type = p_card->board_type.type;
    msg.op.lcAttach.hwVer = p_card->hw_ver;
    msg.op.lcAttach.epldVer = p_card->epld_ver;
    msg.op.lcAttach.epldDate = p_card->epld_date;
    msg.op.lcAttach.epldTime = p_card->epld_time;
    msg.op.lcAttach.fpgaVer = p_card->fpga_ver;
    msg.op.lcAttach.flashSize = p_card->flash_size;
    msg.op.lcAttach.dramSize = p_card->dram_size;
    msg.op.lcAttach.tcamType = p_card->tcam_type;
    msg.op.lcAttach.sramType = p_card->sram_type;
    msg.op.lcAttach.swVer.buf = (uint8 *)p_card->sw_ver;
    msg.op.lcAttach.swVer.size = strlen(p_card->sw_ver);
    msg.op.lcAttach.serialNo.buf = (uint8 *)p_card->serial_no;
    msg.op.lcAttach.serialNo.size = strlen(p_card->serial_no);
    msg.op.lcAttach.bootromVer.buf = (uint8 *)p_card->bootrom_ver;
    msg.op.lcAttach.bootromVer.size = strlen(p_card->bootrom_ver); 
    msg.op.lcAttach.extCardType = p_card->daughter_card_type;
    msg.op.lcAttach.extCardVer = p_card->daughter_card_ver;
    
    msg.op.lcAttach.datapathMode = p_card->datapath_mode;
//#ifdef _GLB_UML_SYSTEM_    
    //commented by jcao for gg emulation board bringup 2014.04.30
    //uncommented by chenxw for overlay profile test on UML, 2014-09-18.
//#ifdef _GLB_UML_SYSTEM_    
    ret = lcm_ftm_read_profile_mode(&stm_mode);
//#endif
    if (ret < 0)
    {
        LCM_LOG_ERR("Lcm attach get stm profile mode : failed to get stm mode, use default mode.");
        stm_mode = 0;
    }
    msg.op.lcAttach.stmMode = stm_mode; 
//#endif /*_GLB_DISTRIBUTE_SYSTEM_*/
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcAttach");
    LCM_PRINT_CON("Line card send lcAttach");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;
}

int32 
lcm_msg_tx_lcDeattach(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 logic_slot;
    int32 ret;

    LCM_MGT_CHK_SLOT(logic_slot);
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcDeattach;
    msg.op.lcDeattach.slot = logic_slot;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcDeattach");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

int32
lcm_msg_tx_lcPortInfo(lcm_clnt_t* clnt, glb_port_t* p_port)
{
    LcmMsg_t msg;
    int32 logic_slot;
    int32 ret;
    unsigned char mac[6];
    int mac_length;
    char ifname[GLB_PHY_PORT_FULL_NAME_SZ];
    
    LCM_MGT_CHK_SLOT(logic_slot);
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcPortInfo;
    msg.op.lcPortInfo.portIdx = p_port->port_idx;
    msg.op.lcPortInfo.portLogicIdx = p_port->logic_port_idx;
    msg.op.lcPortInfo.portMedia = p_port->port_cfg.media;
    msg.op.lcPortInfo.portPhyType = p_port->phy_type;
    /*Fix bug 14686. jqiu 2011-06-15*/
    msg.op.lcPortInfo.portPanelSlot = p_port->panel_slot_no;
    msg.op.lcPortInfo.portPanelPort = p_port->panel_port_no;
    msg.op.lcPortInfo.subportPanelPort = p_port->panel_sub_port_no;

    /*Fix bug 18162. zhangjx 2012-05-30*/
    msg.op.lcPortInfo.poesupport = p_port->poe_support;
    msg.op.lcPortInfo.portspeedability = p_port->port_speed_ability;
    msg.op.lcPortInfo.portspeedreal = p_port->port_speed_real;
    msg.op.lcPortInfo.lpsupport = p_port->lp_support;
    msg.op.lcPortInfo.iscombo = p_port->is_combo;
    /* Modified by liuht for bug 29005, 2014-06-17 */
    msg.op.lcPortInfo.eeesupport = p_port->eee_support;
    /* End of liuht modified */
    msg.op.lcPortInfo.mediaSwitchSupport = p_port->support_media_switch;
    if_build_port_shortname_by_slot_port(ifname, p_port->panel_slot_no, p_port->panel_port_no, p_port->panel_sub_port_no);
    lcm_mgt_get_if_hwaddr(ifname, (unsigned char *)mac, &mac_length);
    if (mac_length)
    {
        msg.op.lcPortInfo.mac.buf = (uint8_t *)mac;
        msg.op.lcPortInfo.mac.size = mac_length;
    }
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send port %d logic_port %d media %d max speed %d.", 
                  p_port->port_idx, p_port->logic_port_idx, p_port->port_cfg.media, p_port->port_speed_ability);

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

int32 
lcm_msg_tx_lcChsmInitSdkAck(lcm_clnt_t* clnt, int32 ret)
{
    uint32 port_id;
    LcmMsg_t msg;    
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
#ifndef _GLB_UML_SYSTEM_    
    eeprom_info_t *p_eeprom_info = NULL;
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    uint8 scfgFlags = 0;
    eeprom_para_t para;
#endif /* !HAVE_SMARTCFG */
#endif
    struct stat stat_buf;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card tx init SDK ack message.");
    LCM_PRINT_CON("Line card tx init SDK ack message.");

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm send init SDK ack : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
//jcao debug    

#ifndef _GLB_UML_SYSTEM_
     p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_SYS_MAC]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm send init SDK ack : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }

    /* sysmac has been saved in p_card */
    //ret += eeprom_get_system_mac(buf , p_eeprom_info);
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_SMARTCFG]);
    para.len = 1;
    para.offset = p_eeprom_info->base_addr;
    para.p_val = &scfgFlags;
    ret += eeprom_read(p_eeprom_info->eeprom_idx, &para);
#endif /* !HAVE_SMARTCFG */
#endif    
 
    for(port_id = 0; port_id < p_card->port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];
        if (!p_port)
        {
            continue;
        }
        lcm_msg_tx_lcPortInfo(clnt, p_port);
        if (p_port->p_fiber)
        {
            lcm_notify_fiber_info(p_port, LCM_FIBER_INSERT);
        }
//wangw , for stacking system, temp code
        if (port_id % 5 == 0 && (!stat("/tmp/startup_cfg_done", &stat_buf)))
        {
            sleep(1);
        }
    }
    
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmInitSdkAck;
    msg.op.lcChsmInitSdkAck.errCode = ret;
#ifndef _GLB_UML_SYSTEM_    
    msg.op.lcChsmInitSdkAck.sysMac.buf = p_card->sysmac;
    msg.op.lcChsmInitSdkAck.sysMac.size = GLB_ETH_ADDR_LEN + 1;
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    msg.op.lcChsmInitSdkAck.scfgFlags = scfgFlags;
#endif /* !HAVE_SMARTCFG */
#endif    
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send init SDK ack.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
#if 0
    for (i = 0; i < p_card->port_num; i++)
    {
        p_port = &p_card->port[i];
        if (!p_port)
        {
            continue;
        }
        if (p_port->psfp)
        {
            lcm_msg_tx_lcFiberModuleAttach(clnt, p_port);
            lcm_port_update_sfp_state(p_port);
        }
        else if (p_port->pxfp)
        {
            lcm_msg_tx_lcFiberModuleAttach(clnt, p_port);
            lcm_port_update_xfp_state(p_port);
        }
    }
#endif
    //p_card->p_asic_chip->chip_states = LC_CHIP_INIT_DONE;

    return LCM_E_SUCCESS;
}
#if 1


/*void fiber_get_type_str(fiber_info_t *fiber_info, char *type_str)   fiber_api.c*/
void 
lcm_port_get_fiber_type_str(lai_fiber_info_t *fiber_info, char *type_str)
{   
    if (!fiber_info)
        return;
    switch(fiber_info->fiber_type)
    {
        case GLB_PHY_TYPE_BASE_PX:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "BASE-PX");
            break;
        case GLB_PHY_TYPE_BASE_BX10:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "BASE-BX10");  
            break;
        case GLB_PHY_TYPE_100BASE_FX:
            if(((fiber_info->compliance_code[3] >> 5 )& 0x1) != 0)
                snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100BASE-FX");  
            else if (((fiber_info->compliance_code[2] >> 2 )& 0x1) == 0x1)
            {
                if(((fiber_info->compliance_code[1] >> 3 )& 0x3) == 0x3)
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 single-mode SONET LR-3");
                else if (((fiber_info->compliance_code[1] >> 3 )& 0x3) == 0x1)
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 single-mode SONET LR-2");
                else
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 single-mode SONET LR-1");
            }
            else if (((fiber_info->compliance_code[2] >> 1 )& 0x1) == 0x1)
            {
                if (((fiber_info->compliance_code[1] >> 3 )& 0x3) == 0x1)
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 single-mode SONET IR-2");
                else
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 single-mode SONET IR-1");
            }
            else
            {
                if (((fiber_info->compliance_code[1] >> 3 )& 0x3) == 0x2)
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 single-mode SONET SR-1");
                else
                    snprintf(type_str, FIBER_TRANS_TYPE_LEN, "OC-3 SONET SR");        
            }
            break;
        case GLB_PHY_TYPE_100BASE_LX:
            /*Fix bug 20083. update SFP string.*/
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100BASE-LX/LX10");
            break;
        case GLB_PHY_TYPE_1000BASE_T_SFP:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "1000BASE-T_SFP");
            break;
        case GLB_PHY_TYPE_1000BASE_CX:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "1000BASE-CX");
            break;
        case GLB_PHY_TYPE_1000BASE_LX:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "1000BASE-LX");
            break;
        case GLB_PHY_TYPE_1000BASE_SX:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "1000BASE-SX");
            break;
        case GLB_PHY_TYPE_10GBASE_ER:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "10G Base-ER");
            break;
        case GLB_PHY_TYPE_10GBASE_LRM:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "10G Base-LRM");
            break;
        case GLB_PHY_TYPE_10GBASE_LR:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "10G Base-LR");
            break;
        case GLB_PHY_TYPE_10GBASE_SR:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "10G Base-SR");
            break;
        case GLB_PHY_TYPE_10GBASE_PASSIVE_COPPER:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "10G Passive Copper");  
            break;
        case GLB_PHY_TYPE_10GBASE_ACTIVE_COPPER:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "10G Active Copper");
            break;
        case GLB_PHY_TYPE_40GBASE_CR4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "40GBASE_CR4");
            break;
        case GLB_PHY_TYPE_40GBASE_SR4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "40GBASE_SR4");
            break;
        case GLB_PHY_TYPE_40GBASE_LR4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "40GBASE_LR4");
            break;
        case GLB_PHY_TYPE_40GBASE_XLPPI:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "40GBASE_XLPPI");
            break;
        case GLB_PHY_TYPE_100G_AOC:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100G_AOC");
            break;
        case GLB_PHY_TYPE_100GBASE_SR4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100GBASE_SR4");
            break;
        case GLB_PHY_TYPE_100GBASE_LR4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100GBASE_LR4");
            break;
        case GLB_PHY_TYPE_100GBASE_ER4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100GBASE_ER4");
            break;
        case GLB_PHY_TYPE_100GBASE_SR10:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100GBASE_SR10");
            break;
        case GLB_PHY_TYPE_100G_CWDM4_MSA_FEC:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100G_CWDM4_MSA_FEC");
            break;
        case GLB_PHY_TYPE_100G_PSM4_SMF:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100G_PSM4_SMF");
            break;
        case GLB_PHY_TYPE_100G_ACC:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100G_ACC");
            break;
        case GLB_PHY_TYPE_100G_CWDM4_MSA_NOFEC:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100G_CWDM4_MSA_NOFEC");
            break;
        case GLB_PHY_TYPE_100GBASE_CR4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "100GBASE_CR4");
            break;
        case GLB_PHY_TYPE_40GBASE_ER4:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "40GBASE_ER4");
            break;
        case GLB_PHY_TYPE_4X10GBASE_SR:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "4X10GBASE_SR");
            break;
        case GLB_PHY_TYPE_40G_PSM4_SMF:
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "40G_PSM4_SMF");
            break;
        case GLB_PHY_TYPE_UNKNOWN: /*same with default*/
        default:    
            snprintf(type_str, FIBER_TRANS_TYPE_LEN, "Unknown");  
            break;
    }
  
    return ;
    
}


int32 
lcm_lai_get_FiberInfo(lai_fiber_info_t** fiber, glb_port_t *p_port)
{
    glb_card_t* p_card = NULL;
    char type_str[FIBER_TRANS_TYPE_LEN]={0};
 
    p_card = lcm_mgt_get_card();

    (*fiber)->slot_id = p_card->phy_slot_no;
    (*fiber)->port_id = p_port->port_idx - 1;
    (*fiber)->oid = p_port->port_idx - 1 + (p_card->phy_slot_no << 16);
    (*fiber)->pannel_port_id = p_port->panel_port_no;
    (*fiber)->pannel_sub_port_id = p_port->panel_sub_port_no;

    if(NULL == p_port || NULL == p_port->p_fiber)
    {
        return LCM_E_SUCCESS;
    }

    (*fiber)->fiber_type = (((fiber_info_t*)p_port->p_fiber)->fiber_type);
    (*fiber)->channel_idx = (((fiber_info_t*)p_port->p_fiber)->channel_idx);
    (*fiber)->channel_num = (((fiber_info_t*)p_port->p_fiber)->channel_num);
    sal_memcpy((*fiber)->name, (((fiber_info_t*)p_port->p_fiber)->name),FIBER_VENDOR_NAME_LEN+1);
    sal_strncpy((*fiber)->pn, (((fiber_info_t*)p_port->p_fiber)->pn),FIBER_VENDOR_NAME_LEN+1);    
    sal_strncpy((*fiber)->sn, (((fiber_info_t*)p_port->p_fiber)->sn),FIBER_VENDOR_NAME_LEN+1); 
    (*fiber)->wavelength[0] = ((fiber_info_t*)p_port->p_fiber)->wavelength[0];
    (*fiber)->wavelength[1] = ((fiber_info_t*)p_port->p_fiber)->wavelength[1];
    sal_memcpy((*fiber)->length, (((fiber_info_t*)p_port->p_fiber)->length),
         sizeof(((fiber_info_t*)p_port->p_fiber)->length)); 
    sal_memcpy((*fiber)->compliance_code, (((fiber_info_t*)p_port->p_fiber)->compliance_code),
        sizeof(((fiber_info_t*)p_port->p_fiber)->compliance_code)); 
    
    (*fiber)->ddm_support = ((fiber_info_t*)p_port->p_fiber)->ddm_support;
    if((*fiber)->ddm_support)
    {
        (*fiber)->tx_pwr2[0] = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE1];
        (*fiber)->tx_pwr2[1] = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE2];
        (*fiber)->tx_pwr2[2]       = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE3];
        (*fiber)->tx_pwr2[3]  = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE4];
        (*fiber)->tx_pwr[0] = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_HIGH_ALARM_VALUE];
        (*fiber)->tx_pwr[1] = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_LOW_ALARM_VALUE];
        (*fiber)->tx_pwr[2] = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_HIGH_WARN_VALUE];
        (*fiber)->tx_pwr[3]  = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_LOW_WARN_VALUE];

        (*fiber)->rx_pwr2[0] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE1];
        (*fiber)->rx_pwr2[1] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE2];
        (*fiber)->rx_pwr2[2] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE3];
        (*fiber)->rx_pwr2[3] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE4];
        (*fiber)->rx_pwr[0] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_HIGH_ALARM_VALUE];
        (*fiber)->rx_pwr[1] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_LOW_ALARM_VALUE];
        (*fiber)->rx_pwr[2] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_HIGH_WARN_VALUE];
        (*fiber)->rx_pwr[3] = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_LOW_WARN_VALUE];

        (*fiber)->tmpr2[0] = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE1];
        (*fiber)->tmpr2[1] = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE2];
        (*fiber)->tmpr2[2] = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE3];
        (*fiber)->tmpr2[3] = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE4];
        (*fiber)->tmpr[0] = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_HIGH_ALARM_VALUE];
        (*fiber)->tmpr[1] = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_LOW_ALARM_VALUE];
        (*fiber)->tmpr[2] = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_HIGH_WARN_VALUE];
        (*fiber)->tmpr[3]= ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_LOW_WARN_VALUE];

        (*fiber)->voltage2[0] = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE1];
        (*fiber)->voltage2[1] = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE2];
        (*fiber)->voltage2[2] = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE3];
        (*fiber)->voltage2[3] = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE4];
        (*fiber)->voltage[0] = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_HIGH_ALARM_VALUE];
        (*fiber)->voltage[1] = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_LOW_ALARM_VALUE];
        (*fiber)->voltage[2] = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_HIGH_WARN_VALUE];
        (*fiber)->voltage[3] = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_LOW_WARN_VALUE];

        (*fiber)->bias2[0] = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE1];
        (*fiber)->bias2[1] = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE2];
        (*fiber)->bias2[2] = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE3];
        (*fiber)->bias2[3] = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE4];
        (*fiber)->bias[0] = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_HIGH_ALARM_VALUE];
        (*fiber)->bias[1] = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_LOW_ALARM_VALUE];
        (*fiber)->bias[2]  = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_HIGH_WARN_VALUE];
        (*fiber)->bias[3] = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_LOW_WARN_VALUE];
        
    }

    lcm_port_get_fiber_type_str(*fiber, type_str);
    sal_strcpy((*fiber)->fiber_type_name, type_str);
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send Fiber attach on port %d.", p_port->port_idx);

    return LCM_E_SUCCESS;
}


int32 
lcm_msg_tx_lcFiberAttach(lcm_clnt_t* clnt,    glb_port_t *p_port)
{
    LcmMsg_t msg;
    int32 ret;
    
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcFiberModuleAttach;
    msg.op.lcFiberModuleAttach.slot = p_port->logic_slot_idx;
    msg.op.lcFiberModuleAttach.port = p_port->port_idx;
    msg.op.lcFiberModuleAttach.type = (((fiber_info_t*)p_port->p_fiber)->fiber_type);
    msg.op.lcFiberModuleAttach.channelidx = (((fiber_info_t*)p_port->p_fiber)->channel_idx);
    msg.op.lcFiberModuleAttach.channelnum = (((fiber_info_t*)p_port->p_fiber)->channel_num);
    msg.op.lcFiberModuleAttach.name.size = FIBER_VENDOR_NAME_LEN+1;
    msg.op.lcFiberModuleAttach.name.buf = (uint8*)(((fiber_info_t*)p_port->p_fiber)->name);
    msg.op.lcFiberModuleAttach.pn.size = FIBER_VENDOR_PN_LEN+1;
    msg.op.lcFiberModuleAttach.pn.buf = (uint8*)(((fiber_info_t*)p_port->p_fiber)->pn);
    msg.op.lcFiberModuleAttach.sn.size = FIBER_VENDOR_SN_LEN+1;
    msg.op.lcFiberModuleAttach.sn.buf = (uint8*)(((fiber_info_t*)p_port->p_fiber)->sn);
    msg.op.lcFiberModuleAttach.wavelength.size = sizeof(((fiber_info_t*)p_port->p_fiber)->wavelength);
    msg.op.lcFiberModuleAttach.wavelength.buf = ((fiber_info_t*)p_port->p_fiber)->wavelength;
    msg.op.lcFiberModuleAttach.length.size = sizeof(((fiber_info_t*)p_port->p_fiber)->length);
    msg.op.lcFiberModuleAttach.length.buf = ((fiber_info_t*)p_port->p_fiber)->length;
    msg.op.lcFiberModuleAttach.complianceCode.size = sizeof(((fiber_info_t*)p_port->p_fiber)->compliance_code);
    msg.op.lcFiberModuleAttach.complianceCode.buf = ((fiber_info_t*)p_port->p_fiber)->compliance_code;
    msg.op.lcFiberModuleAttach.ddm = ((fiber_info_t*)p_port->p_fiber)->ddm_support;
    if(msg.op.lcFiberModuleAttach.ddm)
    {
        msg.op.lcFiberModuleAttach.txPwr.curr1          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE1];
        msg.op.lcFiberModuleAttach.txPwr.curr2          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE2];
        msg.op.lcFiberModuleAttach.txPwr.curr3          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE3];
        msg.op.lcFiberModuleAttach.txPwr.curr4          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE4];
        msg.op.lcFiberModuleAttach.txPwr.highAlarm      = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_HIGH_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.txPwr.lowAlarm       = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_LOW_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.txPwr.highWarn       = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_HIGH_WARN_VALUE];
        msg.op.lcFiberModuleAttach.txPwr.lowWarn        = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_LOW_WARN_VALUE];

        msg.op.lcFiberModuleAttach.rxPwr.curr1          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE1];
        msg.op.lcFiberModuleAttach.rxPwr.curr2          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE2];
        msg.op.lcFiberModuleAttach.rxPwr.curr3          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE3];
        msg.op.lcFiberModuleAttach.rxPwr.curr4          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE4];
        msg.op.lcFiberModuleAttach.rxPwr.highAlarm      = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_HIGH_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.rxPwr.lowAlarm       = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_LOW_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.rxPwr.highWarn       = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_HIGH_WARN_VALUE];
        msg.op.lcFiberModuleAttach.rxPwr.lowWarn        = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_LOW_WARN_VALUE];

        msg.op.lcFiberModuleAttach.tmpr.curr1            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE1];
        msg.op.lcFiberModuleAttach.tmpr.curr2            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE2];
        msg.op.lcFiberModuleAttach.tmpr.curr3            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE3];
        msg.op.lcFiberModuleAttach.tmpr.curr4            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE4];
        msg.op.lcFiberModuleAttach.tmpr.highAlarm       = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_HIGH_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.tmpr.lowAlarm        = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_LOW_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.tmpr.highWarn        = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_HIGH_WARN_VALUE];
        msg.op.lcFiberModuleAttach.tmpr.lowWarn         = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_LOW_WARN_VALUE];

        msg.op.lcFiberModuleAttach.vcc.curr1         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE1];
        msg.op.lcFiberModuleAttach.vcc.curr2         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE2];
        msg.op.lcFiberModuleAttach.vcc.curr3         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE3];
        msg.op.lcFiberModuleAttach.vcc.curr4         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE4];
        msg.op.lcFiberModuleAttach.vcc.highAlarm    = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_HIGH_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.vcc.lowAlarm     = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_LOW_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.vcc.highWarn     = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_HIGH_WARN_VALUE];
        msg.op.lcFiberModuleAttach.vcc.lowWarn      = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_LOW_WARN_VALUE];

        msg.op.lcFiberModuleAttach.bias.curr1        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE1];
        msg.op.lcFiberModuleAttach.bias.curr2        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE2];
        msg.op.lcFiberModuleAttach.bias.curr3        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE3];
        msg.op.lcFiberModuleAttach.bias.curr4        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE4];
        msg.op.lcFiberModuleAttach.bias.highAlarm    = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_HIGH_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.bias.lowAlarm     = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_LOW_ALARM_VALUE];
        msg.op.lcFiberModuleAttach.bias.highWarn     = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_HIGH_WARN_VALUE];
        msg.op.lcFiberModuleAttach.bias.lowWarn      = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_LOW_WARN_VALUE];
    }
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send Fiber attach on port %d.", p_port->port_idx);
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    return LCM_E_SUCCESS;
}

int32 
lcm_msg_tx_lcFiberDeAttach(lcm_clnt_t* clnt,    glb_port_t *p_port)
{
    LcmMsg_t msg;
    int32 ret;
        
    memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcFiberModuleDeattach;
    msg.op.lcFiberModuleDeattach.slot = p_port->logic_slot_idx;
    msg.op.lcFiberModuleDeattach.port = p_port->port_idx;    
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcFiberUpdate(lcm_clnt_t* clnt,    glb_port_t *p_port)
{
    LcmMsg_t msg;
    int32 ret;
        
    memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcFiberModuleUpdate;
    msg.op.lcFiberModuleUpdate.slot = p_port->logic_slot_idx;
    msg.op.lcFiberModuleUpdate.port = p_port->port_idx;
    msg.op.lcFiberModuleUpdate.txPwr.curr1          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE1];
    msg.op.lcFiberModuleUpdate.txPwr.curr2          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE2];
    msg.op.lcFiberModuleUpdate.txPwr.curr3          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE3];
    msg.op.lcFiberModuleUpdate.txPwr.curr4          = ((fiber_info_t*)p_port->p_fiber)->tx_pwr2[FIBER_CURRENT_VALUE4];
    msg.op.lcFiberModuleUpdate.txPwr.highAlarm      = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_HIGH_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.txPwr.lowAlarm       = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_LOW_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.txPwr.highWarn       = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_HIGH_WARN_VALUE];
    msg.op.lcFiberModuleUpdate.txPwr.lowWarn        = ((fiber_info_t*)p_port->p_fiber)->tx_pwr[FIBER_LOW_WARN_VALUE];

    msg.op.lcFiberModuleUpdate.rxPwr.curr1          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE1];
    msg.op.lcFiberModuleUpdate.rxPwr.curr2          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE2];
    msg.op.lcFiberModuleUpdate.rxPwr.curr3          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE3];
    msg.op.lcFiberModuleUpdate.rxPwr.curr4          = ((fiber_info_t*)p_port->p_fiber)->rx_pwr2[FIBER_CURRENT_VALUE4];
    msg.op.lcFiberModuleUpdate.rxPwr.highAlarm      = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_HIGH_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.rxPwr.lowAlarm       = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_LOW_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.rxPwr.highWarn       = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_HIGH_WARN_VALUE];
    msg.op.lcFiberModuleUpdate.rxPwr.lowWarn        = ((fiber_info_t*)p_port->p_fiber)->rx_pwr[FIBER_LOW_WARN_VALUE];

    msg.op.lcFiberModuleUpdate.tmpr.curr1            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE1];
    msg.op.lcFiberModuleUpdate.tmpr.curr2            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE2];
    msg.op.lcFiberModuleUpdate.tmpr.curr3            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE3];
    msg.op.lcFiberModuleUpdate.tmpr.curr4            = ((fiber_info_t*)p_port->p_fiber)->tmpr2[FIBER_CURRENT_VALUE4];
    msg.op.lcFiberModuleUpdate.tmpr.highAlarm       = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_HIGH_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.tmpr.lowAlarm        = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_LOW_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.tmpr.highWarn        = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_HIGH_WARN_VALUE];
    msg.op.lcFiberModuleUpdate.tmpr.lowWarn         = ((fiber_info_t*)p_port->p_fiber)->tmpr[FIBER_LOW_WARN_VALUE];

    msg.op.lcFiberModuleUpdate.vcc.curr1         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE1];
    msg.op.lcFiberModuleUpdate.vcc.curr2         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE2];
    msg.op.lcFiberModuleUpdate.vcc.curr3         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE3];
    msg.op.lcFiberModuleUpdate.vcc.curr4         = ((fiber_info_t*)p_port->p_fiber)->voltage2[FIBER_CURRENT_VALUE4];
    msg.op.lcFiberModuleUpdate.vcc.highAlarm    = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_HIGH_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.vcc.lowAlarm     = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_LOW_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.vcc.highWarn     = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_HIGH_WARN_VALUE];
    msg.op.lcFiberModuleUpdate.vcc.lowWarn      = ((fiber_info_t*)p_port->p_fiber)->voltage[FIBER_LOW_WARN_VALUE];

    msg.op.lcFiberModuleUpdate.bias.curr1        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE1];
    msg.op.lcFiberModuleUpdate.bias.curr2        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE2];
    msg.op.lcFiberModuleUpdate.bias.curr3        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE3];
    msg.op.lcFiberModuleUpdate.bias.curr4        = ((fiber_info_t*)p_port->p_fiber)->bias2[FIBER_CURRENT_VALUE4];
    msg.op.lcFiberModuleUpdate.bias.highAlarm    = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_HIGH_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.bias.lowAlarm     = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_LOW_ALARM_VALUE];
    msg.op.lcFiberModuleUpdate.bias.highWarn     = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_HIGH_WARN_VALUE];
    msg.op.lcFiberModuleUpdate.bias.lowWarn      = ((fiber_info_t*)p_port->p_fiber)->bias[FIBER_LOW_WARN_VALUE];
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    return LCM_E_SUCCESS;    
}

#endif

int32
lcm_msg_tx_lcAsicFatal(lcm_clnt_t* clnt, uint8 type, uint8* buf, uint16 size)
{
    LcmMsg_t msg;
    int32 ret;
    glb_card_t *p_card = NULL;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm send ASIC fatal info: card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    
    memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcAsicFatalInfo;
    msg.op.lcAsicFatalInfo.slot = p_card->logic_slot_no;
    msg.op.lcAsicFatalInfo.type = type;
    msg.op.lcAsicFatalInfo.loginfo.buf = buf;
    msg.op.lcAsicFatalInfo.loginfo.size = size;

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    
    return LCM_E_SUCCESS;    
}

#ifndef _LCM_OSP_
void
lcm_chk_rx_keepalive_cb(void* p_data)
{
    lcm_clnt_t *clnt = (lcm_clnt_t *)p_data;
    if (!g_bDebug)
    {
        clnt->keepalive_cnt++;
        if (KEEPALIVE_TIME_OUT_COUNT <= clnt->keepalive_cnt)
        {
            LCM_LOG_ERR("connect to supervisor timeout %d times, reload ...\n", clnt->keepalive_cnt); 
            lcm_clnt_close(clnt);
            lcm_reload();
        }
    }
    return;
}
#endif

static int32 
lcm_msg_rx_chsmLcAttachAck(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    CTC_TASK_GET_MASTER
    glb_card_t *p_card = NULL;
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "############lcm_msg_rx_chsmLcAttachAck 0");

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv lcAttach ack : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    p_card->card_state = msg->op.chsmLcAttachAck.state;
    clnt->keepalive_cnt = 0;
    lcm_mgt_set_priority_flag(msg->op.chsmLcAttachAck.lcFlag);
    lcm_mgt_set_err_reboot_flag(msg->op.chsmLcAttachAck.errReboot);

    g_last_update_bootrom_time.tv_sec = 0;
#ifndef _LCM_OSP_
    if (msg->op.chsmLcAttachAck.debugEn && g_p_timer_chk_rx_keepalive == NULL)
    {
        g_p_timer_chk_rx_keepalive = CTC_TASK_ADD_TIME_MSEC(lcm_chk_rx_keepalive_cb, p_card, KEEPALIVE_INTERVAL);
    }
#endif
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "############lcm_msg_rx_chsmLcAttachAck 1");
LCM_PRINT_CON( "############lcm_msg_rx_chsmLcAttachAck 1");
    return LCM_E_SUCCESS;
}

int lcm_msg_tx_lcChsmKeepaliveAck(lcm_clnt_t *clnt)
{
    LcmMsg_t msg;
    int      ret;
    glb_card_t* p_card;

    p_card = lcm_mgt_get_card();
    
    memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmKeepaliveAck;
    msg.op.lcChsmKeepaliveAck.slot = p_card->logic_slot_no;
    
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        LCM_LOG_ERR("%d", ret);
        return ret;
    }
    
    clnt->send_keepalive_cnt++;
    return 0;
}

static int 
lcm_msg_rx_chsmKeepalive(lcm_clnt_t *clnt, LcmMsg_t *msg)
{
    clnt->keepalive_cnt = 0;
    lcm_msg_tx_lcChsmKeepaliveAck(clnt);
    clnt->recv_keepalive_cnt++;
    return 0;
}

#if 0
uint8 lcm_stack_get_member_id()
{
    struct stat stat_buf;
    int chipId = 1;
    FILE *fp;
    char buf[1024];

    if(!stat(GLB_STACK_ENABLE_FILE, &stat_buf))
    {
        fp = sal_fopen (GLB_STARTUP_CONFIG_FILE_PATH, "r");
        if (fp == NULL)
        {
            return 0;
        }
        while (sal_fgets (buf, 1024, fp))
        {
            if (sal_strlen(buf) > 0 && buf[sal_strlen(buf) -1] == '\n')
            {
                buf[sal_strlen(buf) -1] = '\0';
            }

            if (!sal_strncmp(buf, "stack member", sal_strlen("stack member")))
            {
                sal_sscanf(buf, "stack member %d", &chipId);      
                break;
            }
        }

        sal_fclose(fp);
    }
    
    return chipId;
}
#endif

int32
hagt_modules_init(void *arg);
int32
hsrv_switch_init();

extern void hsrv_packet_event_notification(
        void *buffer, 
        sai_size_t buffer_size, 
        uint32_t attr_count,
        const sai_attribute_t *attr_list);

extern void hsrv_interface_port_state_change_notification_cb(
    uint32 count,
    sai_port_oper_status_notification_t *noti_data);


extern void hsrv_fdb_event_notification_cb(
    _In_ uint32_t count,
    _In_ sai_fdb_event_notification_data_t *data);

    sai_switch_notification_t g_sai_switch_notifications = {0};

int32 
lcm_InitSdk(uint32 profile_type)
{
    int32 ret = LCM_E_SUCCESS;
    glb_card_t* p_card;     
    sai_switch_api_t*  switch_api;

    LCM_PRINT_CON( "############lcm_InitSdk 0");    


    LCM_PRINT_CON("############lcm_InitSdk 1");
    g_bSDKinit = TRUE;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("lcm_InitSdk : card is NULL.");
        return LCM_E_INVALID_PTR;
    } 

 
    LCM_PRINT_CON("############lcm_InitSdk init start");
    ret = sai_api_initialize(0,NULL);
    if(ret)
    {
        LCM_PRINT_CON("############lcm_InitSdk init fai. ret = %d\n", ret);
    }
      
    LCM_PRINT_CON("############lcm_msg_rx_chsmInitSAI init done");

   // sal_memset(&switch_notifications, 0, sizeof(switch_notifications));
   // switch_notifications.on_packet_event = NULL;//(void *)hsrv_packet_event_notification;
    //switch_notifications.on_port_state_change = NULL;//(void *)hsrv_interface_port_state_change_notification_cb;
    //switch_notifications.on_fdb_event = NULL;//(void *)hsrv_fdb_event_notification_cb;
    ret = sai_api_query(SAI_API_SWITCH,(void**)&switch_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        LCM_PRINT_CON("%% %s, ret= %d \n", "fail query sai_api_switch", ret);
        return 0;
    }
    LCM_PRINT_CON("%% %s, profile id = %d \n", "sai_api_switch", profile_type);

    ret = switch_api->initialize_switch(profile_type,NULL,p_card->cfg_profile_name,&g_sai_switch_notifications);
    if(SAI_STATUS_SUCCESS != ret)
    {
        LCM_PRINT_CON("%% %s, ret = %d\n", "fail  sai_api_switch initialize_switch", ret);
    }

#ifndef _GLB_UML_SYSTEM_
    ret = lcm_card_init_cb();
    if(ret < 0)
    {
        LCM_PRINT_CON("Lcm init hagt and SDK fail, ret %d.", ret);
        ret = LCM_E_INIT_FAILED;
        return ret;
    }
#ifdef BOOTUP_DIAG    
    ret =lcm_diag_start_stage2();
    if(ret < 0)
    {
        LCM_PRINT_CON("Lcm bootup diag stage2 fail.");
    }
#endif /*BOOTUP_DIAG*/    
#endif /*!_GLB_UML_SYSTEM_*/


    lcm_mgt_monitor_lc();

   // ret = hsrv_switch_init();
    if(SAI_STATUS_SUCCESS != ret)
    {
        LCM_PRINT_CON("%% %s, ret = %d\n", "fail  hsrv_switch_init", ret);
        return 0;
    }
    LCM_PRINT_CON("############lcm_InitSdk init success");

    return ret;
}


static int32 
lcm_msg_rx_chsmInitSdk(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret = LCM_E_SUCCESS;
    glb_card_t* p_card;     
    SAL_FILE *fp = NULL;
    sai_switch_api_t*  switch_api;
    sai_switch_notification_t switch_notifications;

    LCM_PRINT_CON( "############lcm_msg_rx_chsmInitSdk 0");    
    if (g_bSDKinit == TRUE)
    {
        lcm_msg_tx_lcChsmInitSdkAck(clnt, ret);
        return 0;
    }

    LCM_PRINT_CON("############lcm_msg_rx_chsmInitSdk 1");
    g_bSDKinit = TRUE;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv chsm init sdk : card is NULL.");
        return LCM_E_INVALID_PTR;
    } 

 
    LCM_PRINT_CON("############lcm_msg_rx_chsmInitSAI init start");
    ret = sai_api_initialize(0,NULL);
    if(ret)
    {
        LCM_PRINT_CON("############lcm_msg_rx_chsmInitSAI init fai. ret = %d\n", ret);
    }
      
    LCM_PRINT_CON("############lcm_msg_rx_chsmInitSAI init done");

    sal_memset(&switch_notifications, 0, sizeof(switch_notifications));
    switch_notifications.on_packet_event = NULL;//(void *)hsrv_packet_event_notification;
    switch_notifications.on_port_state_change = NULL;//(void *)hsrv_interface_port_state_change_notification_cb;
    switch_notifications.on_fdb_event = NULL;//(void *)hsrv_fdb_event_notification_cb;
    ret = sai_api_query(SAI_API_SWITCH,(void**)&switch_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        LCM_PRINT_CON("%% %s, ret= %d \n", "fail query sai_api_switch", ret);
        return 0;
    }

    ret = switch_api->initialize_switch(0,NULL,p_card->cfg_profile_name,&switch_notifications);
    if(SAI_STATUS_SUCCESS != ret)
    {
        LCM_PRINT_CON("%% %s, ret = %d\n", "fail  sai_api_switch initialize_switch", ret);
        return 0;
    }

#ifndef _GLB_UML_SYSTEM_
    ret = lcm_card_init_cb();
    if(ret < 0)
    {
        LCM_PRINT_CON("Lcm init hagt and SDK fail, ret %d.", ret);
        ret = LCM_E_INIT_FAILED;
        return ret;
    }
#ifdef BOOTUP_DIAG    
    ret =lcm_diag_start_stage2();
    if(ret < 0)
    {
        LCM_PRINT_CON("Lcm bootup diag stage2 fail.");
    }
#endif /*BOOTUP_DIAG*/    
#endif /*!_GLB_UML_SYSTEM_*/

    LCM_LOG_ERR("%% %s \n", "hsrv_switch_init");
    //ret = hsrv_switch_init();
    if(SAI_STATUS_SUCCESS != ret)
    {
        LCM_PRINT_CON("%% %s, ret = %d\n", "fail  hsrv_switch_init", ret);
        return 0;
    }
    LCM_PRINT_CON("############lcm_msg_rx_chsmInitSAI init success");

    if ((fp = sal_fopen(GLB_HSRV_DONE_FILE, SAL_OPEN_RW)) != NULL)
    {
        sal_fclose(fp);
    }
    lcm_mgt_monitor_lc();
    lcm_msg_tx_lcChsmInitSdkAck(clnt, ret);

    return ret;
}

#ifndef _GLB_UML_SYSTEM_

#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
static int32
lcm_msg_tx_lcSmartCfgGet(lcm_clnt_t* clnt, uint8 flags)
{
    LcmMsg_t msg;
    int32 ret;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcSmartCfgGet");
    sal_memset(&msg, 0x00, sizeof(LcmMsg_t));
    msg.op.present = op_PR_chsmSmartCfgGet;
    msg.op.chsmSmartCfgGet.flags = flags;
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    return LCM_E_SUCCESS;
}
#endif /* !HAVE_SMARTCFG */
static int32 
lcm_msg_tx_lcSerialNoGetAck(lcm_clnt_t* clnt, uint8 * p_buf)
{
    LcmMsg_t msg;
    int32 ret;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcSerialNoGetAck");
        
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcSerialNoGetAck;
    msg.op.lcSerialNoGetAck.serialNo.buf = p_buf;
    msg.op.lcSerialNoGetAck.serialNo.size = MAX_SERIAL_NO_LEN+1;
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

/* Added by liuht for bug 27788, 2014-03-24 */
static int32 
lcm_msg_tx_lcBootromVerGetAck(lcm_clnt_t* clnt, uint8 * p_buf)
{
    LcmMsg_t msg;
    int32 ret;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcBootromVerGetAck");
        
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcBootromVerGetAck;
    msg.op.lcBootromVerGetAck.bootromVer.buf = p_buf;
    msg.op.lcBootromVerGetAck.bootromVer.size = MAX_BOOTROM_VER_LEN;
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

/* Added by liuht for bug 27788, 2014-03-24 */
int32 
lcm_msg_tx_lcUptimeGetAck(lcm_clnt_t* clnt)
{
    int ret = 0;
    LcmMsg_t msg;
    time_t diff = 0;
	struct sal_timeval uptime;
	
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send Uptime");
	
    #ifndef _GLB_UML_SYSTEM_
    /* get system uptime */
    /* modified by jqiu 2013-03-06
     * some platform don't support param -1 in gettimeofday.
     * use another sys call clock_gettime() */
    sal_ctc_clock_gettime(&uptime);
    #else
    gettimeofday(&uptime, (struct sal_timezone *)-1);
    #endif
    diff = uptime.tv_sec;
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcUptimeGetAck;

    msg.op.lcUptimeGetAck.day  = diff/86400;
    msg.op.lcUptimeGetAck.hour = (diff/3600)%24;
    msg.op.lcUptimeGetAck.min  = (diff/60)%60;
	
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

static int32 
lcm_msg_tx_lcOemInfoGetAck(lcm_clnt_t* clnt, uint8 * p_buf)
{
    LcmMsg_t msg;
    int32 ret;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcOemInfoGetAck");
        
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcOemInfoGetAck;
    msg.op.lcOemInfoGetAck.oemInfo.buf = p_buf;
    msg.op.lcOemInfoGetAck.oemInfo.size = MAX_EEPROM_OEM_INFO_LEN;
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

/* Added by liuht for bug 27788, 2014-03-24 */
int32 
lcm_msg_tx_lcOemInfo(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint8 buf[MAX_EEPROM_OEM_INFO_LEN+1];
    eeprom_info_t *p_eeprom_info = NULL;
	
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcOemInfo");
	
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get oem info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_OEM_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv get oem info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    sal_memset(buf, 0, sizeof(buf));
    ret += eeprom_get_oem_info(buf, p_eeprom_info);

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcOemInfoTx;
    msg.op.lcOemInfoTx.oemInfo.buf = buf;
    msg.op.lcOemInfoTx.oemInfo.size = MAX_EEPROM_OEM_INFO_LEN;
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}

int32 
lcm_msg_tx_lcchsmGetBootcmdAck(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 ret;
    glb_card_t *p_card = NULL;
    char bootcmd[M_FULLPATH_MAX_LEN+1];
    //char cmd[M_FULLPATH_MAX_LEN+1];
    char buf[M_FULLPATH_MAX_LEN+1];
    FILE *fd = NULL;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx lcchsmGetBootcmdAck : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send lcchsmGetBootcmdAck");

#if 0
    /*fix bug32715, liangf, 2015-04-15*/
    sal_memset(cmd, 0, sizeof(cmd));
    sal_strcpy(cmd, "fw_printenv -n hw_load > ");
    sal_strcat(cmd, GLB_BOOT_CMD_INFO_FILE);
    ret = ctclib_reconstruct_system_cmd_chld_clone(ctclib_reconstruct_system_cmd_exec_str, (void*)cmd);    

    fd = sal_fopen(GLB_BOOT_CMD_INFO_FILE, "r");
    if(fd)
    {
        sal_fgets(bootcmd, M_FULLPATH_MAX_LEN, fd);
        sal_fclose(fd);
    }
#endif
    fd = sal_fopen(GLB_BOARD_INFO_FILE, "r");
    if(fd)
    {
        while(sal_fgets(buf, 256, fd) != NULL)
        {
            if(sal_strstr(buf, "bootimage") != NULL)
            {
                sal_strncpy(bootcmd, buf, M_FULLPATH_MAX_LEN);
            }
        }
        sal_fclose(fd);
    }
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmBootcmdGetAck;
    msg.op.lcChsmBootcmdGetAck.bootcmd.buf = (uint8 *)bootcmd;
    msg.op.lcChsmBootcmdGetAck.bootcmd.size = M_FULLPATH_MAX_LEN;
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;    
}



int32 
lcm_msg_tx_lcChsmTmprGetAck(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 ret;
    uint32 sensor_sum, i = 0;
    TmprValue_t tmpr_value[MAX_TMPR_SENSOR_NUM];
    glb_card_t *p_card = NULL;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx ChsmTmprGet ack : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    

    sensor_sum = p_card->sensor_num + p_card->chip_sensor_num;
    for (i = 0; i < sensor_sum; i++)
    {
        tmpr_value[i].index= i; 
        tmpr_value[i].value= p_card->tmpr_status[i].tmpr_val;
        tmpr_value[i].pos = p_card->tmpr_status[i].pos;
    }
        
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmTmprGetAck;
    msg.op.lcChsmTmprGetAck.count = sensor_sum;
    for (i = 0; i < sensor_sum; i++)
    {
        ASN_SET_ADD(&(msg.op.lcChsmTmprGetAck.tmpr.list), &tmpr_value[i]);
    }
        
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send sensor temperature.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        asn_set_empty(&(msg.op.lcChsmTmprGetAck.tmpr.list));
        return ret;
    }

    asn_set_empty(&(msg.op.lcChsmTmprGetAck.tmpr.list));
    return LCM_E_SUCCESS;
}


/* Added by liuht for bug27036, 2014-02-27 */
int32
lcm_lai_get_lcRebootInfo(lai_reboot_info_t** reboot_info)
{
#ifndef _GLB_UML_SYSTEM_
    glb_card_t *p_card = NULL;
    int32 ret;
    int32 i = 0;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx lc get reboot info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    if(0 == p_card->support_reboot_info)
    {
        return LCM_E_SUCCESS;
    }
    if(NULL == reboot_info)
    {
        return LCM_E_INVALID_PARAM;
    }
    ret = lcm_mgt_mount_reboot_info(p_card);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm mount reboot info fail.");
        return LCM_E_INVALID_PTR;
    }

    (*reboot_info)->reboot_times = p_card->reboot_times;


    for (i = 0; i < p_card->reboot_times; i++)
    {
        sal_memcpy((*reboot_info)->reboot_type[i], p_card->reboot_info[i].reboot_type, sizeof(p_card->reboot_info[i].reboot_type));
        sal_memcpy((*reboot_info)->reboot_time[i], p_card->reboot_info[i].reboot_time, sizeof(p_card->reboot_info[i].reboot_time));
    }

    lcm_mgt_unmount_reboot_info(p_card);	
    if(ret < 0)
        return ret;

#endif 
    return LCM_E_SUCCESS;
}


/* Added by liuht for bug27036, 2014-02-27 */
int32
lcm_msg_tx_lcRebootInfo(lcm_clnt_t* clnt)
{
#ifndef _GLB_UML_SYSTEM_
    glb_card_t *p_card = NULL;
    LcmMsg_t msg;
    int32 ret;
    int32 i = 0;
    struct RebootInfo *p_msg_rebootinfo = NULL;	
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx lc get reboot info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    if(0 == p_card->support_reboot_info)
    {
        return LCM_E_SUCCESS;
    }
    ret = lcm_mgt_mount_reboot_info(p_card);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm mount reboot info fail.");
        return LCM_E_INVALID_PTR;
    }

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmRebootInfo;
    msg.op.lcChsmRebootInfo.count  = p_card->reboot_times;

    p_msg_rebootinfo = sal_calloc(sizeof(struct RebootInfo) * p_card->reboot_times);
    if (!p_msg_rebootinfo)
    {
        LCM_LOG_ERR("Lcm no alloc memory fail.");
        return LCM_E_NO_MEMORY;
    }

    for (i = 0; i < p_card->reboot_times; i++)
    {
        p_msg_rebootinfo[i].rebootType.buf= (uint8 *)p_card->reboot_info[i].reboot_type;
        p_msg_rebootinfo[i].rebootType.size= sizeof(p_card->reboot_info[i].reboot_type);	
        p_msg_rebootinfo[i].rebootTimes.buf= (uint8 *)p_card->reboot_info[i].reboot_time;
        p_msg_rebootinfo[i].rebootTimes.size= sizeof(p_card->reboot_info[i].reboot_time);			
        ASN_SET_ADD(&(msg.op.lcChsmRebootInfo.rebootInfo.list), &p_msg_rebootinfo[i]);
    }

    ret = lcm_clnt_send(clnt, &msg); 
    asn_set_empty(&(msg.op.lcDiagResult.items.list));
    sal_free(p_msg_rebootinfo);	
    p_msg_rebootinfo = NULL;
    lcm_mgt_unmount_reboot_info(p_card);	
    if(ret < 0)
        return ret;

#endif 
    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcChsmPOEport(lcm_clnt_t* clnt, glb_port_t* p_port)
{
    LcmMsg_t msg;
    int32 ret = 0;

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmPOEGetPort;
    msg.op.lcChsmPOEGetPort.poeSupport = p_port->poe_support;
    msg.op.lcChsmPOEGetPort.slot = p_port->logic_slot_idx;
    msg.op.lcChsmPOEGetPort.port = p_port->port_idx;
    msg.op.lcChsmPOEGetPort.subPort = p_port->panel_sub_port_no;
    msg.op.lcChsmPOEGetPort.poePort.admin = p_port->poe_port_status.admin;    
    msg.op.lcChsmPOEGetPort.poePort.averConsump = p_port->poe_port_status.aver_consump;
    msg.op.lcChsmPOEGetPort.poePort.budget = p_port->poe_port_status.budget;
    msg.op.lcChsmPOEGetPort.poePort.Class = p_port->poe_port_status.class;
    msg.op.lcChsmPOEGetPort.poePort.curConsump = p_port->poe_port_status.cur_consump;
    msg.op.lcChsmPOEGetPort.poePort.oper = p_port->poe_port_status.oper;
    msg.op.lcChsmPOEGetPort.poePort.peakConsump = p_port->poe_port_status.peak_consump;
    msg.op.lcChsmPOEGetPort.poePort.priority = p_port->poe_port_status.priority;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send POE port status.");
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    
    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcChsmPOEsys(lcm_clnt_t* clnt, glb_card_t* p_card)
{
    LcmMsg_t msg;
    int32 ret = 0;

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmPOEGetSys;
    msg.op.lcChsmPOEGetSys.poeSys.averConsump = p_card->poe_sys_status.aver_consump;
    msg.op.lcChsmPOEGetSys.poeSys.averVolt = p_card->poe_sys_status.aver_volt;
    msg.op.lcChsmPOEGetSys.poeSys.budget = p_card->poe_sys_status.budget;
    msg.op.lcChsmPOEGetSys.poeSys.budgetReserve = p_card->poe_sys_status.budget_reserved;
    msg.op.lcChsmPOEGetSys.poeSys.bugetWarnThres = p_card->poe_sys_status.budget_warn_threshold;
    msg.op.lcChsmPOEGetSys.poeSys.curConsump = p_card->poe_sys_status.cur_consump;
    msg.op.lcChsmPOEGetSys.poeSys.curVolt = p_card->poe_sys_status.cur_volt;
    msg.op.lcChsmPOEGetSys.poeSys.legacyCap = p_card->poe_sys_status.legacy_cap;
    msg.op.lcChsmPOEGetSys.poeSys.peakConsump = p_card->poe_sys_status.peak_consump;
    msg.op.lcChsmPOEGetSys.poeSys.peakVolt = p_card->poe_sys_status.peak_volt;
    msg.op.lcChsmPOEGetSys.poeSys.pm = p_card->poe_sys_status.pm;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send POE sys status.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    
    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcchsm8023APStatus(lcm_clnt_t* clnt, glb_port_t* p_port)
{
    LcmMsg_t msg;
    int32 ret = 0;

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsm8023APStatus;
    msg.op.lcChsm8023APStatus.portIdx = p_port->port_idx;
    msg.op.lcChsm8023APStatus.apEnable = p_port->ap_enable;
    msg.op.lcChsm8023APStatus.apStatus = p_port->dac_train_flag;
        
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send 802.3AP training status.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    
    return LCM_E_SUCCESS;    
}

int32 
lcm_msg_tx_lcchsmGetPsuStatusAck(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 ret;
    uint32 i = 0;
    glb_card_t *p_card = NULL;
    PsuValue_t psu_val[MAX_PSU_NUM];

    sal_memset(&psu_val, 0, (sizeof(PsuValue_t))*MAX_PSU_NUM);
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx chsmGetPsuStatus ack : card is NULL.");
        return LCM_E_INVALID_PTR;
    } 

    for (i = 0; i < p_card->psu_module_num; i++)
    {
        psu_val[i].index = i;
        psu_val[i].psuMode = p_card->psu_status[i].psu_mode;
        psu_val[i].psuWorkStatus = p_card->psu_status[i].psu_work_status;
        psu_val[i].psuAlert = p_card->psu_status[i].psu_alert;	
        psu_val[i].psuAbsent = p_card->psu_status[i].psu_absent;
        psu_val[i].psuType = p_card->psu_status[i].psu_type;
    }

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmPsuStatusGetAck;
    msg.op.lcChsmPsuStatusGetAck.count = p_card->psu_module_num;
    
    for (i = 0; i < p_card->psu_module_num; i++)
    {
        ASN_SET_ADD(&(msg.op.lcChsmPsuStatusGetAck.psu.list), &psu_val[i]);
    }
    
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send psu status.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        asn_set_empty(&(msg.op.lcChsmPsuStatusGetAck.psu.list));
        return ret;
    }

    asn_set_empty(&(msg.op.lcChsmPsuStatusGetAck.psu.list));
    return LCM_E_SUCCESS;
}

int32 
lcm_msg_tx_lcchsmGetFanStatusAck(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    int32 ret;
    uint8 i = 0;
    glb_card_t *p_card = NULL;
    FanValue_t fan_val[MAX_FAN_TRAY_NUM];

    sal_memset(&fan_val, 0, (sizeof(FanValue_t))*MAX_FAN_TRAY_NUM);
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx chsmGetFanStatus ack : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    for(i=0; i<p_card->fan_module_num; i++)
    {
        fan_val[i].index = i;
        fan_val[i].num = p_card->fan_status[i].num;
        fan_val[i].speedAdjust = p_card->fan_status[i].speed_adjust;
        fan_val[i].present = p_card->fan_status[i].present;
        fan_val[i].status = p_card->fan_status[i].status;
        fan_val[i].speedLevel = p_card->fan_status[i].speed_level;
        fan_val[i].speedRate = p_card->fan_status[i].speed_rate;
    }
    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcChsmFanStatusGetAck;
    msg.op.lcChsmFanStatusGetAck.count = p_card->fan_module_num;
    for (i = 0; i < p_card->fan_module_num; i++)
    {
        ASN_SET_ADD(&(msg.op.lcChsmFanStatusGetAck.fan.list), &fan_val[i]);
    }
    
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send fan status.");

    ret = lcm_clnt_send(clnt, &msg);
    asn_set_empty(&(msg.op.lcChsmFanStatusGetAck.fan.list));
    return ret;
}

int32 
lcm_msg_tx_lcchsmGetPoeStatusAck(void)
{
    /* LC_CHSM_GET_POE_PORT_NUM_MAX must bigger than p_card->port_num */
    #define LC_CHSM_GET_POE_PORT_NUM_MAX 100
    glb_card_t* p_card = NULL;
    glb_port_t* p_port = NULL;
    int32 port_id, ret = 0;
    glb_poe_port_stat_info_t port_info[LC_CHSM_GET_POE_PORT_NUM_MAX];
    glb_poe_port_stat_change_t port_change[LC_CHSM_GET_POE_PORT_NUM_MAX];
    glb_poe_sys_stat_info_t sys_info;
    glb_poe_sys_stat_change_t sys_change;
    static int32 first_ack = 0;
    int32 port_num;
    lcm_clnt_t* clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    uint8 poe_psu_status = POE_PSU_FAIL;

    ret += poe_get_psu_status(&poe_psu_status);
    if(poe_psu_status == POE_PSU_FAIL)
    {
        return ret;
    }

    /*get local line card*/
    p_card= lcm_mgt_get_card();
    if(NULL == p_card)
    {
        LCM_LOG_ERR("Pointer to card is invalid.");
        return LCM_E_INVALID_PTR;
    }

    if(p_card->poe_card_mode != POE_DAUGHTER_CARD_USER_MODE)
    {
        LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Getting PoE status is break as PoE daughter card don't works in user mode.\n");
        return LCM_E_SUCCESS;
    }
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "LCM POE timer.\n");
    
    if(NULL == clnt)
    {
        LCM_LOG_ERR("LCM poe timer: get lcm client failed.");
        return LCM_E_INVALID_PTR;
    }

    /* first: trigger POE soft clac */
    sal_memset(port_info, 0,sizeof(glb_poe_port_stat_info_t)*LC_CHSM_GET_POE_PORT_NUM_MAX);
    sal_memset(port_change, 0,sizeof(glb_poe_port_stat_change_t)*LC_CHSM_GET_POE_PORT_NUM_MAX);
    sal_memset(&sys_info, 0,sizeof(glb_poe_sys_stat_info_t));
    sal_memset(&sys_change, 0,sizeof(glb_poe_sys_stat_change_t));
    port_num = 0;
    ret = poe_sys_pm_soft_calc(port_info, port_change, &sys_info, &sys_change, &port_num);

    if(port_num > p_card->port_num)
    {
        LCM_LOG_ERR("LCM poe timer: port num not match, failed.");
        return LCM_E_INVALID_PARAM;
    }
    /* update poe each port status */
    for(port_id = 0; port_id < port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];       
        if(!p_port || !p_port->create_done)
        {
            LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm port %d not create.", port_id+1);
            continue;
        }

        if(p_port->poe_support)
        {
            //sal_memset(&port_change, 0, sizeof(glb_poe_port_stat_change_t));
            //sal_memset(&port_info, 0, sizeof(glb_poe_port_stat_info_t));
            //ret += poe_get_port_status(port_id, &port_info, &port_change);

            p_port->poe_port_status.admin = port_info[port_id].admin;
            p_port->poe_port_status.aver_consump = port_info[port_id].aver_consump;
            p_port->poe_port_status.budget = port_info[port_id].budget;
            p_port->poe_port_status.class = port_info[port_id].class;
            p_port->poe_port_status.cur_consump = port_info[port_id].cur_consump;
            p_port->poe_port_status.oper = port_info[port_id].oper;
            p_port->poe_port_status.peak_consump = port_info[port_id].peak_consump;
            p_port->poe_port_status.priority = port_info[port_id].priority;

            if(first_ack != 0)
            {
                if(1 == port_change[port_id].admin_change || 1 == port_change[port_id].aver_consump_change || 1 == port_change[port_id].budget_change ||
                    1 == port_change[port_id].class_change || 1 == port_change[port_id].cur_consump_change || 1 == port_change[port_id].oper_change ||
                    1 == port_change[port_id].peak_consump_change || 1 == port_change[port_id].priority_change)
                {
                    ret += lcm_msg_tx_lcChsmPOEport(clnt, p_port);
                    
                    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm POE timer port %d,admin %d,aver_consump %d, \
                        budget %d,class %u,cur_consump %d,oper %d,peak_consump %d,priority %d.\n.", port_id+1, port_info[port_id].admin,
                        port_info[port_id].aver_consump,port_info[port_id].budget,port_info[port_id].class,port_info[port_id].cur_consump,
                        port_info[port_id].oper, port_info[port_id].peak_consump, port_info[port_id].priority);        
                }
            }
            else
            {
                ret += lcm_msg_tx_lcChsmPOEport(clnt, p_port);
            }
        }
    }

    if(p_card->poe_port_num)
    {
        /* update POE system status */
        //sal_memset(&sys_info, 0, sizeof(glb_poe_sys_stat_info_t));
        //sal_memset(&sys_change, 0, sizeof(glb_poe_sys_stat_change_t));
        //ret += poe_get_sys_status(&sys_info, &sys_change);
        
        p_card->poe_sys_status.aver_consump = sys_info.aver_consump;
        p_card->poe_sys_status.aver_volt = sys_info.aver_volt;
        p_card->poe_sys_status.budget = sys_info.budget;
        p_card->poe_sys_status.budget_reserved = sys_info.budget_reserved;
        p_card->poe_sys_status.budget_warn_threshold = sys_info.budget_warn_threshold;
        p_card->poe_sys_status.cur_consump = sys_info.cur_consump;
        p_card->poe_sys_status.cur_volt = sys_info.cur_volt;
        p_card->poe_sys_status.legacy_cap = sys_info.legacy_cap;
        p_card->poe_sys_status.peak_consump = sys_info.peak_consump;
        p_card->poe_sys_status.peak_volt = sys_info.peak_volt;
        p_card->poe_sys_status.pm = sys_info.pm;

        if(first_ack != 0)
        {
            if(1 == sys_change.aver_consump_change || 1 == sys_change.aver_volt_change || 1 == sys_change.budget_change ||
                1 == sys_change.budget_reserved_change || 1 == sys_change.budget_warn_threshold_change ||
                1 == sys_change.budget_warn_threshold_change || 1 == sys_change.cur_consump_change || 1 == sys_change.cur_volt_change ||
                1 == sys_change.legacy_cap_change || 1 == sys_change.peak_consump_change || 1 == sys_change.peak_volt_change ||
                1 == sys_change.pm_change)
            {
                ret += lcm_msg_tx_lcChsmPOEsys(clnt, p_card);
                LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT,"Lcm POE timer sys,aver_consump %d,aver_volt %d,budget%d,\
                    budget_reserved %d%%,budget_warn_threshold %d%%,cur_consump %d,cur_volt %d,legacy_cap %d,peak_consump %d,peak_volt %d,pm %d.\n",
                    sys_info.aver_consump, sys_info.aver_volt, sys_info.budget, sys_info.budget_reserved, sys_info.budget_warn_threshold,
                    sys_info.cur_consump, sys_info.cur_volt, sys_info.legacy_cap,sys_info.peak_consump, sys_info.peak_volt,sys_info.pm);
            }
        }
        else
        {
            ret += lcm_msg_tx_lcChsmPOEsys(clnt, p_card);
        }
    }

    if(first_ack == 0)
    {
        first_ack = 1;                
    }

    if(ret)
    {
        return LCM_E_INIT_FAILED;
    }

    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcchsmPoeCardUpdate(lcm_clnt_t* clnt,uint8 poe_psu_stat)
{
    LcmMsg_t msg;
    glb_card_t* p_card = NULL;
    int32 ret = 0;

    /*get local line card*/
    p_card= lcm_mgt_get_card();
    if(NULL == p_card)
    {
        LCM_LOG_ERR("Pointer to card is invalid.");
        return LCM_E_INVALID_PTR;
    }

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "LCM POE hot swap card update begin.\n");
    
    if(NULL == clnt)
    {
        LCM_LOG_ERR("LCM poe card update: get lcm client failed.");
        return LCM_E_INVALID_PTR;
    }

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_lcPoeCardUpdate;
    msg.op.lcPoeCardUpdate.poePsuStat = poe_psu_stat;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, 
                  "Line card send POE hot swap card update info.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcchsmReset(lcm_clnt_t* clnt)
{
    LcmMsg_t msg;
    glb_card_t* p_card = NULL;
    int32 ret = 0;

    /*get local line card*/
    p_card= lcm_mgt_get_card();
    if(NULL == p_card)
    {
        LCM_LOG_ERR("Pointer to card is invalid.");
        return LCM_E_INVALID_PTR;
    }

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "LCM reset begin.\n");
    
    if(NULL == clnt)
    {
        LCM_LOG_ERR("LCM reset update: get lcm client failed.");
        return LCM_E_INVALID_PTR;
    }

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    msg.op.present = op_PR_chsmRecoverSystem;
    msg.op.chsmRecoverSystem.reset = TRUE;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Line card send reset board info.");

    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }

    return LCM_E_SUCCESS;
}

extern void glb_enable_phy_fast_detect(uint8 flag);
static int32
lcm_msg_rx_chsmSetLcFlag(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    uint8 flag;
    
    clnt->keepalive_cnt = 0;
    flag = msg->op.chsmSetLcFlag.lcFlag;
    glb_enable_phy_fast_detect(flag);
    return 0;
}

/*bug30363 jqiu add 2014-10-23 for customer request*/
extern int32 lcm_port_config_phy_test_signal_mode(uint8 panel_slot, uint8 panel_port, uint8 panel_subport, uint8 mode);
static int32
lcm_msg_rx_chsmSetPhyTestFlag(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    uint8 panel_slot;
    uint8 panel_port;
    uint8 panel_subport;
    uint8 flag;

    panel_slot = msg->op.chsmSetPhyTestFlag.slotid;
    panel_port = msg->op.chsmSetPhyTestFlag.portid;
    panel_subport = msg->op.chsmSetPhyTestFlag.subportid;
    flag = msg->op.chsmSetPhyTestFlag.testFlag;
    lcm_port_config_phy_test_signal_mode(panel_slot, panel_port, panel_subport, flag);
    return 0;
}

static int32 
lcm_msg_rx_chsmSerialNoGet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint8 buf[MAX_SERIAL_NO_LEN+1];
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get serial no : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    clnt->keepalive_cnt = 0;

    sal_memcpy(buf, p_card->serial_no, MAX_SERIAL_NO_LEN+1);
    ret += lcm_msg_tx_lcSerialNoGetAck(clnt, buf);   
    return ret;
}

/* Added by liuht for bug 27788, 2014-03-24 */
static int32 
lcm_msg_rx_chsmGetBootromVerGet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint8 buf[MAX_BOOTROM_VER_LEN+1];
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get bootrom version : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    clnt->keepalive_cnt = 0;

    //lcm_mgt_get_current_bootromver((char *)buf);
    //sal_memcpy(p_card->bootrom_ver, buf, MAX_BOOTROM_VER_LEN+1);
    sal_memcpy(buf, p_card->bootrom_ver, MAX_BOOTROM_VER_LEN+1);
    ret = lcm_msg_tx_lcBootromVerGetAck(clnt, buf);   
    return ret;
}

/* Added by liuht for bug 27788, 2014-03-24 */
static int32 
lcm_msg_rx_chsmUptimeGet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    return lcm_msg_tx_lcUptimeGetAck(clnt);
}

#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
static int32
lcm_msg_rx_chsmSmartCfgGet(lcm_clnt_t *clnt, LcmMsg_t *msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    eeprom_para_t para;
    uint8 flags = 0;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get smartcfg: card is NULL.");
        return LCM_E_INVALID_PTR;
    } 
    clnt->keepalive_cnt = 0;

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_SMARTCFG]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv get smartcfg: eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }

    para.len = 1;
    para.offset = p_eeprom_info->base_addr;
    para.p_val = &flags;
    ret += eeprom_read(p_eeprom_info->eeprom_idx, &para);
    ret += lcm_msg_tx_lcSmartCfgGet(clnt, flags);
    return ret;
}

static int32
lcm_msg_rx_chsmSmartCfgSet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    eeprom_para_t para;
    unsigned char flags;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        return LCM_E_INVALID_PTR;
    }
    clnt->keepalive_cnt = 0;
    flags = msg->op.chsmSmartCfgSet.flags;

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_SMARTCFG]);
    if(NULL == p_eeprom_info)
    {
        return LCM_E_INVALID_PTR;
    }

    para.len = 1;
    para.offset = p_eeprom_info->base_addr;
    para.p_val = &flags;  

    if (eeprom_write (p_eeprom_info->eeprom_idx, &para) < 0)
    {
        ret = RESULT_ERROR;
    }  
    return ret;
}
#endif /* !HAVE_SMARTCFG */


int32 
lcm_lai_rx_laiOemInfoGet(char* buf)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get oem info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_OEM_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv get oem info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    sal_memset(buf, 0, sizeof(buf));
    ret += eeprom_get_oem_info((uint8*)buf, p_eeprom_info);

    return ret;
}


int32 
lcm_lai_rx_laiOemInfoSet(char* buf)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get oem info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_OEM_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv set oem info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    sal_memcpy(buf, buf, MAX_EEPROM_OEM_INFO_LEN);    
    ret = eeprom_set_oem_info((uint8*)buf, p_eeprom_info);
    return ret;
}


static int32 
lcm_msg_rx_chsmOemInfoGet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint8 buf[MAX_EEPROM_OEM_INFO_LEN+1];
    eeprom_info_t *p_eeprom_info = NULL;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get oem info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    clnt->keepalive_cnt = 0;

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_OEM_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv get oem info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    sal_memset(buf, 0, sizeof(buf));
    ret += eeprom_get_oem_info(buf, p_eeprom_info);

    ret += lcm_msg_tx_lcOemInfoGetAck(clnt, buf);
    return ret;
}

static int32 
lcm_msg_rx_chsmOemInfoSet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint8 buf[MAX_EEPROM_OEM_INFO_LEN+1];
    eeprom_info_t *p_eeprom_info = NULL;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv get oem info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    clnt->keepalive_cnt = 0;

    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_OEM_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv set oem info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    sal_memcpy(buf, msg->op.chsmOemInfoSet.oemInfo.buf, MAX_EEPROM_OEM_INFO_LEN);    
    ret = eeprom_set_oem_info(buf, p_eeprom_info);
    return ret;
}

static int32 
lcm_msg_rx_chsmReloadLc(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;

    LCM_LOG_ERR("Recieve reload message, reloading...\n");
    ret = lcm_reload();
    return ret;
}

static int32 
lcm_msg_rx_chsmCpuMacSet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 enable;
    int32 ret;
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx set cpu mac message.");

    enable = msg->op.chsmCpuMacSet.enable;
    clnt->keepalive_cnt = 0;

    /* Modified by liuht for bug 32536, 2015-04-14 */
    /* Cpu mac is not used, so just return */
    return LCM_E_SUCCESS;
    
    ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_CPU_MAC_EN, &enable);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm set cpu mac fail.");
        return LCM_E_INIT_FAILED;
    }
    return ret;
}


int32 
lcm_lai_rx_laiLedSet(int32 led, int32 status)
{
    int32 ret;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive set led message.");


    ret = led_api_op(led, status);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm set led fail.");
        return LCM_E_HW_LED_GEN;
    }

    return LCM_E_SUCCESS;
}


static int32 
lcm_msg_rx_chsmLedSet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    glb_led_type_t type;
    glb_led_stat_t status;
    int32 ret;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive set led message.");
    type = msg->op.chsmLedSet.reserved;
    status = msg->op.chsmLedSet.ledStatus;
    clnt->keepalive_cnt = 0;

    ret = led_api_op(type, status);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm set led fail.");
        return LCM_E_HW_LED_GEN;
    }

    return LCM_E_SUCCESS;
}

/* Modified by liuht for bug 26911, 2014-03-27 */
static int32 
lcm_msg_rx_chsmLedAlarmFlagSet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive set led alarm flag message.");
    g_sys_led_alarm = msg->op.chsmLedAlarmFlagSet.ledAlarmFlag;
    lcm_mgt_set_led_flag_to_kernal(&g_sys_led_alarm);
	
    return LCM_E_SUCCESS;
}



int32  
lcm_lai_Updatebootrom(char* path)
{
    int ret;
    char dst_file[M_FULLPATH_MAX_LEN+1];
    FILE *fp;
    struct timespec cur_time;
    uint8 bootrom_type;
    glb_card_t *p_card = NULL;
     
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv chsmUpdatebootrom : card is NULL.");
        return LCM_E_INVALID_PTR;
    }  
#define MAX_BOOTROM_UPDATE_INTERVAL 10

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive Updatebootrom message.");

    sal_strncpy(dst_file, (char *)path, M_FULLPATH_MAX_LEN);

    sal_getuptime(&cur_time);
    if((0 == g_last_update_bootrom_time.tv_sec)
        || ((cur_time.tv_sec - g_last_update_bootrom_time.tv_sec) > MAX_BOOTROM_UPDATE_INTERVAL))
    {
        bootrom_type = p_card->bootrom_type;
        ret = update_bootrom(dst_file, bootrom_type);
        g_last_update_bootrom_time.tv_sec = cur_time.tv_sec;
        if(ret < 0)
        {
            LCM_LOG_USER(E_ERROR,LCM_3_UPDATE_BOOTROM_FAIL);
            LCM_LOG_ERR("update_bootrom fail.");
            return LCM_E_HW_UPDATEBTROM_GEN;
        }
    }
    else
    {
        LCM_LOG_USER(E_ERROR,LCM_3_UPDATE_BOOTROM_FREQUENTLY);
        LCM_LOG_ERR("please don't update bootrom frequently, try again after 30 seconds.");
        return LCM_E_HW_UPDATEBTROM_GEN;
    }
    
    /* Create bootrom update done flag file */
    if ((fp = sal_fopen(GLB_UPDATE_BOOTROM_DONE, "w+")) != NULL)
    {
        sal_fclose(fp);
    }

    return LCM_E_SUCCESS;
}


static int32  
lcm_msg_rx_chsmUpdatebootrom(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int ret;
    char dst_file[M_FULLPATH_MAX_LEN+1];
    FILE *fp;
    struct timespec cur_time;
    uint8 bootrom_type;
    glb_card_t *p_card = NULL;
     
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv chsmUpdatebootrom : card is NULL.");
        return LCM_E_INVALID_PTR;
    }  
#define MAX_BOOTROM_UPDATE_INTERVAL 10

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive Updatebootrom message.");
    clnt->keepalive_cnt = 0;
    sal_strncpy(dst_file, (char *)msg->op.chsmUpdatebootrom.dstfile.buf, msg->op.chsmUpdatebootrom.dstfile.size);

    sal_getuptime(&cur_time);
    if((0 == g_last_update_bootrom_time.tv_sec)
        || ((cur_time.tv_sec - g_last_update_bootrom_time.tv_sec) > MAX_BOOTROM_UPDATE_INTERVAL))
    {
        bootrom_type = p_card->bootrom_type;
        ret = update_bootrom(dst_file, bootrom_type);
        g_last_update_bootrom_time.tv_sec = cur_time.tv_sec;
        if(ret < 0)
        {
            LCM_LOG_USER(E_ERROR,LCM_3_UPDATE_BOOTROM_FAIL);
            LCM_LOG_ERR("update_bootrom fail.");
            return LCM_E_HW_UPDATEBTROM_GEN;
        }
    }
    else
    {
        LCM_LOG_USER(E_ERROR,LCM_3_UPDATE_BOOTROM_FREQUENTLY);
        LCM_LOG_ERR("please don't update bootrom frequently, try again after 30 seconds.");
        return LCM_E_HW_UPDATEBTROM_GEN;
    }
    
    /* Create bootrom update done flag file */
    if ((fp = sal_fopen(GLB_UPDATE_BOOTROM_DONE, "w+")) != NULL)
    {
        sal_fclose(fp);
    }

    return LCM_E_SUCCESS;
}


int32  
lcm_lai_UpdateEpld(char* path)
{
    int ret;
    char dst_file[M_FULLPATH_MAX_LEN+1];
    FILE *fp;
    struct stat stat_buf;
    glb_card_t *p_card = NULL;
     
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv chsmConfigbootcmd : card is NULL.");
        return LCM_E_INVALID_PTR;
    }  
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive Update EPLD message.");
    sal_strncpy(dst_file, (char *)path, M_FULLPATH_MAX_LEN);

    /* Must disable all irqs */
    if(ctc_disable_all_irqs() < 0)
    {
        LCM_LOG_ERR("Disable all irqs fail.");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }

    /* Create epld update flag */
    if ((fp = sal_fopen(GLB_UPDATE_EPLD_FLAG, "w+")) != NULL)
    {
        sal_fclose(fp);
    }
    
    ret = epld_update(dst_file, p_card->epld_type);
    if(ret < 0)
    {
        LCM_LOG_USER(E_ERROR, LCM_3_UPDATE_EPLD_FAIL);
        LCM_LOG_ERR("Update EPLD fail.");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }

    if(sal_stat(GLB_UPDATE_EPLD_DONE, &stat_buf))
    {
        LCM_LOG_USER(E_ERROR, LCM_3_UPDATE_EPLD_FAIL);
        LCM_LOG_ERR("Update EPLD fail.");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }
    
    if (sal_unlink(GLB_UPDATE_EPLD_FLAG))
    {
        LCM_LOG_ERR("Remove update EPLD flag fail.\n");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }

    return LCM_E_SUCCESS;
}


static int32  
lcm_msg_rx_chsmUpdateEpld(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int ret;
    char dst_file[M_FULLPATH_MAX_LEN+1];
    FILE *fp;
    struct stat stat_buf;
    glb_card_t *p_card = NULL;
     
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv chsmConfigbootcmd : card is NULL.");
        return LCM_E_INVALID_PTR;
    }  
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Receive Update EPLD message.");
    clnt->keepalive_cnt = 0;
    sal_strncpy(dst_file, (char *)msg->op.chsmUpdatebootrom.dstfile.buf, msg->op.chsmUpdatebootrom.dstfile.size);

    /* Must disable all irqs */
    if(ctc_disable_all_irqs() < 0)
    {
        LCM_LOG_ERR("Disable all irqs fail.");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }

    /* Create epld update flag */
    if ((fp = sal_fopen(GLB_UPDATE_EPLD_FLAG, "w+")) != NULL)
    {
        sal_fclose(fp);
    }
    
    ret = epld_update(dst_file, p_card->epld_type);
    if(ret < 0)
    {
        LCM_LOG_USER(E_ERROR, LCM_3_UPDATE_EPLD_FAIL);
        LCM_LOG_ERR("Update EPLD fail.");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }

    if(sal_stat(GLB_UPDATE_EPLD_DONE, &stat_buf))
    {
        LCM_LOG_USER(E_ERROR, LCM_3_UPDATE_EPLD_FAIL);
        LCM_LOG_ERR("Update EPLD fail.");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }
    
    if (sal_unlink(GLB_UPDATE_EPLD_FLAG))
    {
        LCM_LOG_ERR("Remove update EPLD flag fail.\n");
        return LCM_E_HW_UPDATEEPLD_GEN;
    }

    return LCM_E_SUCCESS;
}



int32
lcm_lai_set_Configbootcmd(char* cmd)
{
     int ret;
     glb_card_t *p_card = NULL;
     char bootcmd[M_FULLPATH_MAX_LEN+1]; /*max len is 18+128+10+8+15+15=194 byte.*/
     
     p_card = lcm_mgt_get_card();
     if (!p_card)
     {
         LCM_LOG_ERR("Lcm recv chsmConfigbootcmd : card is NULL.");
         return LCM_E_INVALID_PTR;
     }    

     sal_strncpy(bootcmd, cmd, M_FULLPATH_MAX_LEN);

     ret = ctclib_reconstruct_system_cmd_chld_clone(ctclib_reconstruct_system_cmd_exec_str, (void*)bootcmd);    
     
     if(ret < 0)
     {
         LCM_LOG_USER(E_ERROR,LCM_3_CONFIG_BOOTCMD_FAIL);
         LCM_LOG_ERR("config bootcmd fail.");
         return LCM_E_HW_UPDATEBTROM_GEN;
     }

     return LCM_E_SUCCESS;

}


int32
lcm_msg_rx_chsmConfigbootcmd(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
     int ret;
     glb_card_t *p_card = NULL;
     char bootcmd[M_FULLPATH_MAX_LEN+1]; /*max len is 18+128+10+8+15+15=194 byte.*/
     
     p_card = lcm_mgt_get_card();
     if (!p_card)
     {
         LCM_LOG_ERR("Lcm recv chsmConfigbootcmd : card is NULL.");
         return LCM_E_INVALID_PTR;
     }    
     clnt->keepalive_cnt = 0;
     sal_strncpy(bootcmd, (char *)msg->op.chsmConfigbootcmd.bootcmd.buf, msg->op.chsmConfigbootcmd.bootcmd.size);

     ret = ctclib_reconstruct_system_cmd_chld_clone(ctclib_reconstruct_system_cmd_exec_str, (void*)bootcmd);    
     
     if(ret < 0)
     {
         LCM_LOG_USER(E_ERROR,LCM_3_CONFIG_BOOTCMD_FAIL);
         LCM_LOG_ERR("config bootcmd fail.");
         return LCM_E_HW_UPDATEBTROM_GEN;
     }

     return LCM_E_SUCCESS;

}
#ifdef BOOTUP_DIAG
int32
lcm_msg_rx_chsmConfigbootuplevel(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
     int32 ret;
     glb_card_t *p_card = NULL;
     eeprom_info_t *p_eeprom_info = NULL;
     uint8 bootup_diag_level=0;
     
     p_card = lcm_mgt_get_card();
     if (!p_card)
     {
         LCM_LOG_ERR("Lcm recv chsmConfigbootuplevel : card is NULL.");
         return LCM_E_INVALID_PTR;
     }    
     clnt->keepalive_cnt = 0;
     bootup_diag_level = msg->op.chsmConfigdiaglevel.level ;
    
     p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_BOOTUP_DIAG_LEVEL]);
     if(NULL == p_eeprom_info)
     {
         LCM_LOG_ERR("Lcm recv chsmConfigbootuplevel : eeprom alloc is NULL.");
         return LCM_E_INVALID_PTR;
     }
       
     
     ret = eeprom_set_bootup_diag_level(bootup_diag_level,p_eeprom_info);
     if(ret < 0)
     {
         LCM_LOG_ERR("set bootup diag level fail.");
         return LCM_E_CFG_GEN;
     }
     return LCM_E_SUCCESS;

}
#endif

void
lcm_vct_async_timeout(void* p_data)
{
    CTC_TASK_GET_MASTER
    int32 ret;
    uint32 port_id;
    glb_port_cable_info_t port_cable_info;
    lcm_clnt_t *clnt;
    vct_msg_t* p_vct_msg = (vct_msg_t* )p_data;
        
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm VCT async timeout!\n");
    port_id = p_vct_msg->port_id;

    clnt = (lcm_clnt_t *)lcm_get_lcm_client();
    if(NULL == clnt)
    {
        LCM_LOG_ERR("LCM lcm_vct_async_timeout: get lcm client failed.");
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, p_vct_msg);
        return;
    }

    ret = phy_get_cable_info(port_id, &port_cable_info);
    if(ret != GLB_VCT_OK)
    {
        if(ret == GLB_VCT_WAIT)
        {
            CTC_TASK_ADD_TIME_MSEC(lcm_vct_async_timeout, (void*)p_vct_msg, GLB_VCT_DETECT_TIME);
            return;
        }
        LCM_LOG_ERR("Lcm get VCT cable info fail!\n");
    }
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm get VCT cable info: pair_a = %d, pair_b = %d, pair_c = %d, pair_d = %d\n",
                   port_cable_info.pair_A.pair_length, port_cable_info.pair_B.pair_length,
                   port_cable_info.pair_C.pair_length, port_cable_info.pair_D.pair_length);
    ret = lcm_msg_tx_lcChsmVCT(clnt, port_id, &port_cable_info);

    if (NULL != p_vct_msg)
    {
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, p_vct_msg);
    }
    
    return;
}

int32
lcm_vct_start_timer(void* arg)
{
    CTC_TASK_GET_MASTER
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm VCT start timer!\n");
    
    CTC_TASK_ADD_TIME_MSEC(lcm_vct_async_timeout, arg, GLB_VCT_DETECT_TIME);
    return LCM_E_SUCCESS;
}

int32
lcm_msg_tx_lcChsmVCT(lcm_clnt_t *clnt, uint32 port_id, glb_port_cable_info_t* p_cable_info)
{
    LcmMsg_t msg;
    int32 ret;

    sal_memset(&msg, 0, sizeof(LcmMsg_t));
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm send VCT message!\n");

    msg.op.present = op_PR_lcChsmVCTGetInfo;
    msg.op.lcChsmVCTGetInfo.portId     = port_id;
    msg.op.lcChsmVCTGetInfo.remotePair = p_cable_info->remote_pair;
    msg.op.lcChsmVCTGetInfo.portSpeed  = p_cable_info->cable_speed;
    msg.op.lcChsmVCTGetInfo.portLinkup = p_cable_info->port_link_up;
    msg.op.lcChsmVCTGetInfo.portEnable = p_cable_info->port_enable;
    msg.op.lcChsmVCTGetInfo.pairA.pairLength = p_cable_info->pair_A.pair_length;
    msg.op.lcChsmVCTGetInfo.pairB.pairLength = p_cable_info->pair_B.pair_length;
    msg.op.lcChsmVCTGetInfo.pairC.pairLength = p_cable_info->pair_C.pair_length;
    msg.op.lcChsmVCTGetInfo.pairD.pairLength = p_cable_info->pair_D.pair_length;
    msg.op.lcChsmVCTGetInfo.pairA.pairState = p_cable_info->pair_A.pair_status;
    msg.op.lcChsmVCTGetInfo.pairB.pairState = p_cable_info->pair_B.pair_status;
    msg.op.lcChsmVCTGetInfo.pairC.pairState = p_cable_info->pair_C.pair_status;
    msg.op.lcChsmVCTGetInfo.pairD.pairState = p_cable_info->pair_D.pair_status;
    msg.op.lcChsmVCTGetInfo.pairA.pairAccuracy = p_cable_info->pair_A.pair_accuracy;
    msg.op.lcChsmVCTGetInfo.pairB.pairAccuracy = p_cable_info->pair_B.pair_accuracy;
    msg.op.lcChsmVCTGetInfo.pairC.pairAccuracy = p_cable_info->pair_C.pair_accuracy;
    msg.op.lcChsmVCTGetInfo.pairD.pairAccuracy = p_cable_info->pair_D.pair_accuracy;
    

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm get VCT cable info: pair_A = %x, pair_B = %x, pair_C = %x, pair_D = %x\n",
                    p_cable_info->pair_A.pair_length, p_cable_info->pair_B.pair_length, p_cable_info->pair_C.pair_length,
                    p_cable_info->pair_D.pair_length);
    if ((ret = lcm_clnt_send(clnt, &msg)) < 0)
    {
        return ret;
    }
    
    return LCM_E_SUCCESS;
}

int32
lcm_msg_rx_chsmSetVctMod(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret;
    int32 slot_id = 0xff;
    int32 port_id = 0xff;
    vct_msg_t* p_vct_msg;
    glb_card_t* p_card = NULL;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm rx set VCT mod message!\n");
    clnt->keepalive_cnt = 0;

    slot_id = msg->op.chsmSysSetVCT.slot;
    port_id = msg->op.chsmSysSetVCT.port;
    
    p_vct_msg = (vct_msg_t*)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE, sizeof(vct_msg_t));
    if (NULL == p_vct_msg)
    {
        return LCM_E_NO_MEMORY;
    }
    p_vct_msg->port_id = port_id;
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm set VCT mod slot = %d,port = %d\n", slot_id, port_id);
    
    ret = lcm_vct_start_timer(p_vct_msg);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm set VCT start timer fail!\n");
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, p_vct_msg);
        return LCM_E_CFG_GEN;
    }
    
    p_card = lcm_mgt_get_card();
    if ((port_id+1) > p_card->port_num)
    {
        LCM_LOG_ERR("Port index %d is out of range, port numbers is %d",
                    port_id, p_card->port_num);
        return LCM_E_INVALID_PORT;
    }
    /* fix bug: port can't work on shutdown mode, otherwise the port works abnormal */
    if(!p_card->pp_port[port_id]->port_cfg.enable)
    {
        LCM_LOG_ERR("slot = %d,port = %d VCT test, but port is shutdown!\n", slot_id, port_id);
        LCM_LOG_USER(E_WARNING,LCM_4_VCT_TEST_BUT_PORT_SHUTDOWN);
        return LCM_E_CFG_GEN;
    }

    ret = phy_set_vct_mod(port_id);
    if(ret < 0)
    {
        LCM_LOG_ERR("Lcm set VCT mod fail!\n");
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, p_vct_msg);
        return LCM_E_CFG_GEN;
    }
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "Lcm set VCT mod end\n");

    return LCM_E_SUCCESS;

}

int32 
lcm_msg_rx_chsmTmprGet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx get sensor temperature message.");
    clnt->keepalive_cnt = 0;

    ret = lcm_msg_tx_lcChsmTmprGetAck(clnt);   
    return ret;
}

int32 
lcm_msg_rx_chsmGetPsuStatus(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx get psu status message.");
    clnt->keepalive_cnt = 0;

    ret = lcm_msg_tx_lcchsmGetPsuStatusAck(clnt);   
    return ret;
}
int32 
lcm_msg_rx_chsmGetBootcmd(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx get bootcmd info.");
    clnt->keepalive_cnt = 0;

   

    ret = lcm_msg_tx_lcchsmGetBootcmdAck(clnt);   
    return ret;
}


int32 
lcm_msg_rx_chsmGetFanStatus(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx get fan status message.");
    clnt->keepalive_cnt = 0;

    ret = lcm_msg_tx_lcchsmGetFanStatusAck(clnt);   
    return ret;
}

int32
lcm_msg_rx_chsmGetPoeStatus(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret = 0;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx get POE stauts message.");
    clnt->keepalive_cnt = 0;

    //ret = lcm_msg_tx_lcchsmGetPoeStatusAck();
    return ret;
}


int32 
lcm_lai_rx_laiTmprThreshold(uint32 low, uint32 high, uint32 crit)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint32 sensor_num = 0;
    uint32 i;
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx set sensor temperature threshold message.");

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv set sensor temperature threshold: card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    
    //clnt->keepalive_cnt = 0;

    sensor_num = p_card->sensor_num;
    
    p_card->tmpr_cfg.low = low;
    p_card->tmpr_cfg.high = high;
    p_card->tmpr_cfg.crit = crit;

    /*modified by liuht for bug 24525 to support LM75,2013-09-18*/
    if (GLB_SERIES_E580 == p_card->board_type.series)
    {
        for (i = 0; i < sensor_num; i++)
        {
            ret = sensor_dev_set_temp(i, THSYT_TEMP, 2);
            ret |= sensor_dev_set_temp(i, LOW_TEMP, p_card->tmpr_cfg.low);
            ret |= sensor_dev_set_temp(i, HIGH_TEMP, p_card->tmpr_cfg.high);
            ret |= sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
        }
    }
    else if (GLB_SERIES_E350 == p_card->board_type.series)
    {
        if((GLB_BOARD_E350_48T4X2Q== p_card->board_type.type)
            ||(GLB_BOARD_E350_8T4S12XG == p_card->board_type.type)
            ||(GLB_BOARD_E350_8TS12X == p_card->board_type.type)
            ||(GLB_BOARD_E350_24X == p_card->board_type.type))
        {
    	    for (i = 0; i < sensor_num; i++)
    	    {
    	        ret = sensor_dev_set_temp(i, THSYT_TEMP, 2);
    	        ret |= sensor_dev_set_temp(i, LOW_TEMP, p_card->tmpr_cfg.low);
    	        ret |= sensor_dev_set_temp(i, HIGH_TEMP, p_card->tmpr_cfg.high);
    	        ret |= sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
    	    }
        }
        /* Modified by liuht for bug27056, 2014-01-24 */
        /* To distinguish phicomm board and centec board for 8T12X */	
        else if((GLB_BOARD_E350_48T4XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_PHICOMM_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_MT_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_MTRJ_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_24T4XG == p_card->board_type.type))
        {
    	    for (i = 0; i < sensor_num; i++)
    	    {
    	        ret = sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
    	        /* Added by liuht for bug25658, 2014-02-12 */	
    	        ret |= sensor_dev_set_temp(i, THSYT_TEMP, p_card->tmpr_cfg.crit - 2);	
    	    }
        }	
    }
    else
    {
        for (i = 0; i < sensor_num; i++)
        {
            ret = sensor_dev_set_temp(i, THSYT_TEMP, 2);
            ret |= sensor_dev_set_temp(i, LOW_TEMP, p_card->tmpr_cfg.low);
            ret |= sensor_dev_set_temp(i, HIGH_TEMP, p_card->tmpr_cfg.high);
            ret |= sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
        }
    }
    return ret;
}


int32 
lcm_msg_rx_chsmTmprThreshold(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    glb_card_t *p_card = NULL;
    uint32 sensor_num = 0;
    uint32 i;
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx set sensor temperature threshold message.");

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv set sensor temperature threshold: card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    
    clnt->keepalive_cnt = 0;

    sensor_num = p_card->sensor_num;
    
    p_card->tmpr_cfg.low = msg->op.chsmTmprThreshold.low;
    p_card->tmpr_cfg.high = msg->op.chsmTmprThreshold.high;
    p_card->tmpr_cfg.crit = msg->op.chsmTmprThreshold.crit;

    /*modified by liuht for bug 24525 to support LM75,2013-09-18*/
    if (GLB_SERIES_E580 == p_card->board_type.series)
    {
        for (i = 0; i < sensor_num; i++)
        {
            ret = sensor_dev_set_temp(i, THSYT_TEMP, 2);
            ret |= sensor_dev_set_temp(i, LOW_TEMP, p_card->tmpr_cfg.low);
            ret |= sensor_dev_set_temp(i, HIGH_TEMP, p_card->tmpr_cfg.high);
            ret |= sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
        }
    }
    else if (GLB_SERIES_E350 == p_card->board_type.series)
    {
        if((GLB_BOARD_E350_48T4X2Q== p_card->board_type.type)
            ||(GLB_BOARD_E350_8T4S12XG == p_card->board_type.type)
            ||(GLB_BOARD_E350_8TS12X == p_card->board_type.type)
            ||(GLB_BOARD_E350_24X == p_card->board_type.type))
        {
    	    for (i = 0; i < sensor_num; i++)
    	    {
    	        ret = sensor_dev_set_temp(i, THSYT_TEMP, 2);
    	        ret |= sensor_dev_set_temp(i, LOW_TEMP, p_card->tmpr_cfg.low);
    	        ret |= sensor_dev_set_temp(i, HIGH_TEMP, p_card->tmpr_cfg.high);
    	        ret |= sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
    	    }
        }
        /* Modified by liuht for bug27056, 2014-01-24 */
        /* To distinguish phicomm board and centec board for 8T12X */	
        else if((GLB_BOARD_E350_48T4XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_PHICOMM_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_MT_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_MTRJ_8T12XG == p_card->board_type.type)
               ||(GLB_BOARD_E350_24T4XG == p_card->board_type.type))
        {
    	    for (i = 0; i < sensor_num; i++)
    	    {
    	        ret = sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
    	        /* Added by liuht for bug25658, 2014-02-12 */	
    	        ret |= sensor_dev_set_temp(i, THSYT_TEMP, p_card->tmpr_cfg.crit - 2);	
    	    }
        }	
    }
    else
    {
        for (i = 0; i < sensor_num; i++)
        {
            ret = sensor_dev_set_temp(i, THSYT_TEMP, 2);
            ret |= sensor_dev_set_temp(i, LOW_TEMP, p_card->tmpr_cfg.low);
            ret |= sensor_dev_set_temp(i, HIGH_TEMP, p_card->tmpr_cfg.high);
            ret |= sensor_dev_set_temp(i, CRIT_TEMP, p_card->tmpr_cfg.crit);
        }
    }
    return ret;
}


/* Added by liuht for bug 27036, 2014-03-20 */
/* clear reboot info file */
int32 
lcm_lai_ResetRebootInfo()
{
#ifndef _GLB_UML_SYSTEM_
    FILE *fp = NULL;
    glb_card_t *p_card = NULL;
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv reset reboot info: card is NULL.");
        return LCM_E_INVALID_PTR;
    } 
    if(p_card->support_reboot_info)
    {    
        p_card->reboot_times = 0;
        fp = sal_fopen(REBOOT_INFO_SAVE_PATH, "w");
        if(NULL == fp)
        {
            return LCM_E_FILE_OPEN;
        }
        sal_fclose(fp);
    }
#endif
    return LCM_E_SUCCESS;
}


/* Added by liuht for bug 27036, 2014-03-20 */
/* clear reboot info file */
int32 
lcm_msg_rx_chsmResetRebootInfo(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
#ifndef _GLB_UML_SYSTEM_
    FILE *fp = NULL;
    glb_card_t *p_card = NULL;
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv reset reboot info: card is NULL.");
        return LCM_E_INVALID_PTR;
    } 	
    if(p_card->support_reboot_info)
    {    
        p_card->reboot_times = 0;
        fp = sal_fopen(REBOOT_INFO_SAVE_PATH, "w");
        if(NULL == fp)
        {
            return LCM_E_FILE_OPEN;
        }
        sal_fclose(fp);
    }
#endif	
    return LCM_E_SUCCESS;
}

int32
lcm_msg_rx_chsmSetDatapathMode(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx set datapath mode message.");

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv set datapath mode: card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
    
    clnt->keepalive_cnt = 0;

    p_card->datapath_mode = msg->op.chsmSetDatapathMode.mode;
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_DATAPATH_MODE]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv set datapath mode : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    eeprom_set_datapath(p_card->datapath_mode, p_eeprom_info);
    return LCM_E_SUCCESS;    
}

int32
lcm_msg_rx_chsmPOE(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret = 0;
    glb_card_t *p_card = NULL;
    poe_pm_t poe_pm;
    poe_legacy_cap_t poe_legacy;
    uint32 poe_budget, poe_reserve, poe_threshold, poe_mode;

    LCM_LOG_DEBUG(lcm, chsmtlk, LCM_CHSMTLK_EVENT, "rx set POE enable or disable message.");

    p_card = lcm_mgt_get_card();
    if(NULL == p_card)
    {
        LCM_LOG_ERR("Lcm recv set POE enable or disable: card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    
    clnt->keepalive_cnt = 0;

    if(msg->op.chsmSysSetPOE.type == CHSMSysPOETypeDefine_pm)
    {
        poe_pm = msg->op.chsmSysSetPOE.value;
        p_card->poe_cfg.pm = msg->op.chsmSysSetPOE.value;
        ret += poe_set_sys_pm(poe_pm);
    }
    else if(msg->op.chsmSysSetPOE.type == CHSMSysPOETypeDefine_legacy)
    {
        poe_legacy = msg->op.chsmSysSetPOE.value;
        p_card->poe_cfg.legacy_cap = msg->op.chsmSysSetPOE.value;
        ret += poe_set_sys_legacy_cap(poe_legacy);
    }
    else if(msg->op.chsmSysSetPOE.type == CHSMSysPOETypeDefine_budget)
    {
        poe_budget = msg->op.chsmSysSetPOE.value;
        p_card->poe_cfg.budget = msg->op.chsmSysSetPOE.value;
        ret += poe_set_sys_budget(poe_budget);
    }
    else if(msg->op.chsmSysSetPOE.type == CHSMSysPOETypeDefine_reserve)
    {
        poe_reserve = msg->op.chsmSysSetPOE.value;
        p_card->poe_cfg.budget_reserve = msg->op.chsmSysSetPOE.value;
        ret += poe_set_sys_budget_reserved(poe_reserve);
    }
    else if(msg->op.chsmSysSetPOE.type == CHSMSysPOETypeDefine_threshold)
    {
        poe_threshold = msg->op.chsmSysSetPOE.value;
        p_card->poe_cfg.budget_threshold = msg->op.chsmSysSetPOE.value;
        ret += poe_set_sys_consump_warn_threshold(poe_threshold);
    }
    else if(msg->op.chsmSysSetPOE.type == CHSMSysPOETypeDefine_mode)
    {
        poe_mode = msg->op.chsmSysSetPOE.value;
        ret += lcm_poe_daughter_card_mode(poe_mode);
    }
    else
    {
        LCM_LOG_ERR("Lcm recv set POE enable or disable: Invalid parameter.");
        return LCM_E_INVALID_PARAM;
    }

    return ret;
}

#ifdef BOOTUP_DIAG
int32 
lcm_msg_tx_lcBootupDiagResult(lcm_clnt_t *clnt, diag_operator_t *p_oper)
{
       
    glb_card_t *p_card = NULL;
    LcmMsg_t msg;
    struct DiagItem *p_msg_item = NULL;
    int32 delta;
    int32 ret;
    int32 i = 0;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm tx lc bootup diag result : card is NULL.");
        return LCM_E_INVALID_PTR;
    }    
          
    sal_memset(&msg, 0, sizeof(LcmMsg_t));

  
    msg.op.present = op_PR_lcDiagResult;
    msg.op.lcDiagResult.logicSlotNo = p_card->logic_slot_no;    
    msg.op.lcDiagResult.itemNum = p_oper->max_item_num;

    p_msg_item = sal_calloc(sizeof(struct DiagItem) * p_oper->max_item_num);
    if (!p_msg_item)
    {
        return -1;
    }
    
    for (i = 0; i < p_oper->max_item_num; i++)
    {
        delta = (p_oper->p_items[i].rslt->end_tv.tv_sec - p_oper->p_items[i].rslt->start_tv.tv_sec)*1000000 + 
        (p_oper->p_items[i].rslt->end_tv.tv_usec - p_oper->p_items[i].rslt->start_tv.tv_usec);
        
        p_msg_item[i].itemId = p_oper->p_items[i].item_id;
        p_msg_item[i].level = p_oper->p_items[i].level;
        p_msg_item[i].attr = p_oper->p_items[i].attr;
        p_msg_item[i].rslt = p_oper->p_items[i].rslt->result;
        p_msg_item[i].runTime = delta;
        p_msg_item[i].name.buf = (uint8 *)(p_oper->p_items[i].name);
        p_msg_item[i].name.size = strlen(p_oper->p_items[i].name);
        ASN_SET_ADD(&(msg.op.lcDiagResult.items.list), &p_msg_item[i]);
    }

    ret = lcm_clnt_send(clnt, &msg); 
    asn_set_empty(&(msg.op.lcDiagResult.items.list));
    sal_free(p_msg_item);
    p_msg_item = NULL;
    
    if(ret < 0)
        return ret;

   
    return LCM_E_SUCCESS;
}
#endif
#endif/*_GLB_UML_SYSTEM_*/

#ifndef _GLB_DISTRIBUTE_SYSTEM_  
static int32
lcm_msg_rx_chsmSetStmMode(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
#ifdef _GLB_UML_SYSTEM_
#define STM_LINE_LEN_MAX                128
    char file_name[STM_LINE_LEN_MAX];  
    char description[2*STM_LINE_LEN_MAX];
    char profile_mode[STM_LINE_LEN_MAX];
    FILE* fp = NULL;    
    uint32 stm_mode = 0;

    stm_mode = msg->op.chsmSetStmMode.stmMode;
    /*get file path*/
    sal_snprintf(file_name, sizeof(file_name), "%s%s", GLB_STM_PROFILE_PATH, GLB_STM_PROFILE_MODE);

    /*OPEN FILE*/
    fp = sal_fopen(file_name, "w+");
    if((NULL == fp))
    {
        return LCM_E_FILE_OPEN;
    }

    /*write file information*/
    sal_snprintf(description, sizeof(description), "%s\r\n%s\r\n", 
              "#this file is only used for storing tcam allocation profile mode.",
              "#0=default, 1=access, 2=ipv4 route, 3=vlan, 4=l2vpn 5=ipv6.\r\n");
    sal_snprintf(profile_mode, sizeof(profile_mode), "[PROFILE_MODE] = %d", 
            stm_mode);
    
    sal_fputs(description, fp);
    sal_fputs(profile_mode, fp);

    /*close file*/
    sal_fclose(fp);
    fp = NULL;
#else
    glb_card_t* p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    uint32 stm_mode = 0;
    int32 ret = LCM_E_SUCCESS;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv stm set profile mode : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm attach get stm profile mode : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }

    stm_mode = msg->op.chsmSetStmMode.stmMode;
    ret = eeprom_set_tcam_profile(stm_mode, p_eeprom_info);
    if (ret < 0)
    {
        LCM_LOG_ERR("Lcm attach get stm profile mode : failed to set stm mode.");
        return ret;
    }
#endif

    return LCM_E_SUCCESS;
}
#endif /*_GLB_DISTRIBUTE_SYSTEM_*/

int32
lcm_lai_SetStmMode(uint32 mode)
{
#ifdef _GLB_UML_SYSTEM_
#define STM_LINE_LEN_MAX                128
    char file_name[STM_LINE_LEN_MAX];  
    char description[2*STM_LINE_LEN_MAX];
    char profile_mode[STM_LINE_LEN_MAX];
    FILE* fp = NULL;    
    uint32 stm_mode = 0;

    stm_mode = mode;
    /*get file path*/
    sal_snprintf(file_name, sizeof(file_name), "%s%s", GLB_STM_PROFILE_PATH, GLB_STM_PROFILE_MODE);

    /*OPEN FILE*/
    fp = sal_fopen(file_name, "w+");
    if((NULL == fp))
    {
        return LCM_E_FILE_OPEN;
    }

    /*write file information*/
    sal_snprintf(description, sizeof(description), "%s\r\n%s\r\n", 
              "#this file is only used for storing tcam allocation profile mode.",
              "#0=default, 1=access, 2=ipv4 route, 3=vlan, 4=l2vpn 5=ipv6.\r\n");
    sal_snprintf(profile_mode, sizeof(profile_mode), "[PROFILE_MODE] = %d", 
            stm_mode);
    
    sal_fputs(description, fp);
    sal_fputs(profile_mode, fp);

    /*close file*/
    sal_fclose(fp);
    fp = NULL;
#else
    glb_card_t* p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    uint32 stm_mode = 0;
    int32 ret = LCM_E_SUCCESS;

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv stm set profile mode : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_TCAM_PROFILE]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm attach get stm profile mode : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }

    stm_mode = mode;
    ret = eeprom_set_tcam_profile(stm_mode, p_eeprom_info);
    if (ret < 0)
    {
        LCM_LOG_ERR("Lcm attach get stm profile mode : failed to set stm mode.");
        return ret;
    }
#endif

    return LCM_E_SUCCESS;
}


#ifdef _GLB_SHOW_FORWARD_ENABLE_ 
/***************************************************************************
 * Name     :  lcm_msg_tx_chsmforwardinfo
 * Purpose :  send log file to chsm
 * Input     :  arg : lcm client. buffer:msg buffer. length : buffer length
 * Output   :  N/A.  
 * Return   :  LCM_E_XX
 * Note     :   N/A.
****************************************************************************/
int32 
lcm_msg_tx_chsmforwardinfo(void *pv_arg,uint8 *pc_buffer, int32 length)
{    
    lcm_clnt_t *p_lcm_clnt = (lcm_clnt_t*)pv_arg;;    
    LcmMsg_t respmsg; 
    int32 ret = 0;

    sal_memset(&respmsg, 0, sizeof(LcmMsg_t));
    respmsg.op.present = op_PR_diagShowCmodelInfo;    
    respmsg.op.diagShowCmodelInfo.msgInfo.buf = pc_buffer;
    respmsg.op.diagShowCmodelInfo.msgInfo.size = length;
  
    ret = lcm_clnt_send(p_lcm_clnt, &respmsg);
   
    return ret;
}

/***************************************************************************
 * Name     :  lcm_msg_tx_chsmshowfowardack
 * Purpose :  send to chsm 
 * Input     :  buffer : mem buffer.  length : buffer length
 * Output   :  N/A.  
 * Return   :  LCM_E_XX
 * Note     :   N/A.
****************************************************************************/
int32
lcm_msg_tx_chsmshowfowardack(void *pv_arg, ctc_pkt_t *pst_outpkt)
{
    lcm_clnt_t *pst_clnt = (lcm_clnt_t*)pv_arg;
    LcmMsg_t respmsg;   
    
    sal_memset(&respmsg, 0, sizeof(LcmMsg_t));
    respmsg.op.present = op_PR_diagShowForwardResp;
    respmsg.op.diagShowForwardResp.chipid = pst_outpkt->chip_id;
    respmsg.op.diagShowForwardResp.chanid = pst_outpkt->chan_id;
    if (pst_outpkt->pkt_len >= LCM_SHOW_FORWARD_MTU)
    {
        if (pst_outpkt->pkt)
        {
            sal_free(pst_outpkt->pkt);
        }
        return LCM_E_INVALID_LENGTH;
    }
    
    if (pst_outpkt->pkt != NULL)
    {
        respmsg.op.diagShowForwardResp.pktLen = pst_outpkt->pkt_len;
        respmsg.op.diagShowForwardResp.pktInfo.buf = pst_outpkt->pkt;
        respmsg.op.diagShowForwardResp.pktInfo.size = pst_outpkt->pkt_len;
    }
    lcm_clnt_send(pst_clnt, &respmsg);

    if (pst_outpkt->pkt != NULL)
    {
       sal_free(pst_outpkt->pkt);
    }

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name     :  _lcm_msg_rx_chsmfowardipe
 * Purpose :  receive msg from chsm do ipe process
 * Input     :  clnt : lcm client.  reqmsg : request message
 * Output   :  N/A.  
 * Return   :  LCM_E_XX
 * Note     :   N/A.
****************************************************************************/
static int32
_lcm_msg_rx_chsmfowardipe(lcm_clnt_t *pst_clnt, LcmMsg_t *pst_reqmsg)
{
    ctc_pkt_t inpkt;
    int32 ret = 0;

    sal_memset(&inpkt, 0, sizeof(ctc_pkt_t));
    inpkt.pkt_len = pst_reqmsg->op.diagShowForwardIPEReq.pktLen;
    inpkt.pkt =(uint8 *)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE, LCM_SHOW_FORWARD_MTU);
    if (NULL == inpkt.pkt)
    {
        return LCM_E_NO_MEMORY;
    }
    sal_memset(inpkt.pkt, 0, LCM_SHOW_FORWARD_MTU);
   
    inpkt.chip_id = pst_reqmsg->op.diagShowForwardIPEReq.chipid;
    inpkt.chan_id = pst_reqmsg->op.diagShowForwardIPEReq.chanid;
    inpkt.pkt_id = pst_reqmsg->op.diagShowForwardIPEReq.pktid;  
    if (NULL != pst_reqmsg->op.diagShowForwardIPEReq.pktInfo.buf)
    {
        sal_memcpy(inpkt.pkt, pst_reqmsg->op.diagShowForwardIPEReq.pktInfo.buf, inpkt.pkt_len);
    }

    ret = lcm_show_forward_process(&inpkt, (void*)pst_clnt);    
    if ( 0 > ret )
    {
        if (NULL != inpkt.pkt)
        {
            LCM_FREE(CTCLIB_MEM_LCM_MODULE, inpkt.pkt);
            inpkt.pkt = NULL;
        }
        LCM_LOG_ERR("[ipe]Lcm show forward process fail.");
    
        return LCM_E_INVALID_PARAM;
    }
    
    /*free packet memory in function lcm_show_forward_process(), where to free reqmsg memory??*/    
    if (NULL != inpkt.pkt)
    {
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, inpkt.pkt);
        inpkt.pkt = NULL;
    }

    return LCM_E_SUCCESS;
}

/***************************************************************************
 * Name     :  _lcm_msg_rx_chsmfowardepe
 * Purpose :  receive msg from chsm do epe process
 * Input     :  clnt : lcm client.  reqmsg : request message
 * Output   :  N/A.  
 * Return   :  LCM_E_XX
 * Note     :   N/A.
****************************************************************************/
static int32
_lcm_msg_rx_chsmfowardepe(lcm_clnt_t *pst_clnt, LcmMsg_t *pst_reqmsg)
{
    ctc_pkt_t inpkt;
    LcmMsg_t respmsg; 
    int32 ret = 0;

    inpkt.pkt_len = pst_reqmsg->op.diagShowForwardEPEReq.pktLen;
    inpkt.pkt =(uint8 *)LCM_CALLOC(CTCLIB_MEM_LCM_MODULE, LCM_SHOW_FORWARD_MTU);
    if (NULL == inpkt.pkt)
    {
        return LCM_E_NO_MEMORY;
    }
    sal_memset(inpkt.pkt, 0, LCM_SHOW_FORWARD_MTU);
    sal_memset(&respmsg, 0, sizeof(LcmMsg_t));      
    
    inpkt.chip_id = pst_reqmsg->op.diagShowForwardEPEReq.chipid;
    inpkt.chan_id = pst_reqmsg->op.diagShowForwardEPEReq.chanid;
    inpkt.pkt_id = pst_reqmsg->op.diagShowForwardEPEReq.pktid;     

    if (NULL != pst_reqmsg->op.diagShowForwardEPEReq.pktInfo.buf)
    {
        sal_memcpy(inpkt.pkt, pst_reqmsg->op.diagShowForwardEPEReq.pktInfo.buf, inpkt.pkt_len);
    }

    ret = lcm_show_forward_process((void*)pst_clnt,&inpkt);  
    if ( 0 > ret )
    {
        if (NULL != inpkt.pkt)
        {
            LCM_FREE(CTCLIB_MEM_LCM_MODULE, inpkt.pkt);
            inpkt.pkt = NULL;
        }
        LCM_LOG_ERR("[epe]Lcm show forward process fail.");
    
        return LCM_E_INVALID_PARAM;
    }

    if (NULL != inpkt.pkt)
    {
        LCM_FREE(CTCLIB_MEM_LCM_MODULE, inpkt.pkt);
        inpkt.pkt = NULL;
    }

    return LCM_E_SUCCESS;

}

static int32
_lcm_msg_rx_chsmforwardflags(lcm_clnt_t *clnt, LcmMsg_t *reqmsg)
{
    uint64 flags = 0;
    uint32 module = 0;

    flags = reqmsg->op.diagDebugCmodel.switches;
    module = reqmsg->op.diagDebugCmodel.module;

    LCM_IF_ERROR_RETURN(lcm_show_forward_set_flags(module, flags));
    
    return LCM_E_SUCCESS;
}

#endif

static int32
lcm_msg_rx_chsmShowSDKallocinfo(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    uint32 detailed = 0;
    //int32 ret = LCM_E_SUCCESS;    
 
    detailed = msg->op.chsmShowSDKallocInfo.detailed;   

    //ret = LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SHOW_SDK_ALLOC_INFO, &detailed);
    LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SHOW_SDK_ALLOC_INFO, &detailed);

    return LCM_E_SUCCESS;
}

static int 
lcm_msg_rx_chsmSetKeepaliveEn(lcm_clnt_t *clnt, LcmMsg_t *msg)
{
    g_bDebug = msg->op.chsmSetKeepaliveEn.enable;
    clnt->keepalive_cnt = 0;
    clnt->send_keepalive_cnt = 0;
    clnt->recv_keepalive_cnt = 0;
    return 0;
}

#ifdef _GLB_UML_SYSTEM_    
extern int g_active_sup_slot ; 

int lcm_msg_rx_chsmSwitchoverSim(lcm_clnt_t *clnt, LcmMsg_t *msg)
{    
    uint32_t logic_slot = 0;
    
    logic_slot = msg->op.chsmSwitchoverSim.slot;
    g_active_sup_slot = msg->op.chsmSwitchoverSim.slot;
    log_sys(M_MOD_LCM, E_INFORMATIONAL, "%s switchover to slot %d", __FUNCTION__, logic_slot);

    lcm_clnt_fini(lcm_get_lcm_client());
    lcm_clnt_init(lcm_get_lcm_client(), logic_slot);
    LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_MESSAGE_REINIT, NULL);

    return 0;
}
#endif /* !_GLB_UML_SYSTEM_ */

#ifdef HAVE_STACK    
extern struct lcm_mgt_stack_config g_lcm_stack;
int lcm_msg_rx_chsmStackingMaster(lcm_clnt_t *clnt, LcmMsg_t *msg)
{    
    uint32_t master = 0;
    
    master = msg->op.chsmStackingMaster.master;
    g_lcm_stack.master = master;
    log_sys(M_MOD_LCM, E_INFORMATIONAL, "%s master slot %d", __FUNCTION__, master);
    return 0;
}

int lcm_msg_rx_chsmStackingTxTrunk(lcm_clnt_t *clnt, LcmMsg_t *msg)
{    
    lcapi_hagt_set_stack_swtich_tx_trunk_t tx_info;
    
    tx_info.member = msg->op.chsmStackingTxTrunk.member;
    tx_info.trunk = msg->op.chsmStackingTxTrunk.trunk;
    log_sys(M_MOD_LCM, E_INFORMATIONAL, "%s master member %d trunk %d", __FUNCTION__, 
                tx_info.member, tx_info.trunk);

    LCM2HAGT_CALLBACK_SEND(LCM2HAGT_CB_SET_STACK_SWITCH_TX_TRUNK, &tx_info);
    return 0;
}

#endif

#ifndef _GLB_UML_SYSTEM_  
int lcm_msg_rx_chsmMediaTypeSet(lcm_clnt_t *clnt, LcmMsg_t *msg)
{
#if 0
    uint8 panel_slot, panel_port, media_type;
    uint8 port_id;
    glb_card_t* p_card = NULL;
    glb_port_t* p_port;
    uint8 channel;
    uint8 chipid;
    
    panel_slot = msg->op.chsmMediaTypeSet.panelSlot;
    panel_port = msg->op.chsmMediaTypeSet.panelPort;
    media_type = msg->op.chsmMediaTypeSet.mediaType;
    log_sys(M_MOD_LCM, E_INFORMATIONAL, "%s slot no %d port id %d media type %d", __FUNCTION__, 
                panel_slot, panel_port, media_type);

    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv stm set media type : card is NULL.");
        return LCM_E_INVALID_PTR;
    }
    if(FIBER_MEDIA_QSFP_PLUS == media_type)
    {
        channel = GLB_MUX_CHANNEL0;
    }
    else
    {
        channel = GLB_MUX_CHANNEL1;
    }

    for(port_id=0; port_id<p_card->port_num; port_id++)
    {
        p_port = p_card->pp_port[port_id];
        if(!p_port)
            continue;
        if((p_port->panel_slot_no == panel_slot)&&(p_port->panel_port_no == panel_port))
        {
            chipid = p_port->mux_chip_id;
            if(chipid<0)
                continue;
            mux_channel_select(chipid, channel);
            fiber_change_handle(port_id, media_type);
        }
    }
#endif
    return 0;
}

int lcm_msg_rx_chsmPowerDownSet(lcm_clnt_t *clnt, LcmMsg_t *msg)
{    
    uint8 powerdownflag;
    
    powerdownflag = msg->op.chsmPowerDownSet.powerDownFlag;
    log_sys(M_MOD_LCM, E_INFORMATIONAL, "power down flag %d", __FUNCTION__, 
                powerdownflag);

    epld_item_write(0, EPLD_POWER_DOWN, 0);
    epld_item_write(0, EPLD_POWER_DOWN, 3);

    return 0;
}

#endif /* !_GLB_UML_SYSTEM_ */


int32 
lcm_lai_set_PortInfoSet(char* info)
{
    int32 ret =0;
    char buffer[MAX_PORT_INFO_LEN+1];    
    
    
    sal_memset(buffer, 0, MAX_PORT_INFO_LEN);
    sal_memcpy(buffer, info, MAX_PORT_INFO_LEN);  

#ifndef _GLB_UML_SYSTEM_
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv set port info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }  
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_PORT_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv set port info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    ret = eeprom_set_port_info((uint8*)buffer, p_eeprom_info);
#else
    FILE *port_flash_fd = NULL;

    port_flash_fd = sal_fopen(GLB_UML_PORT_INFO_FILE, "w");
    if(!port_flash_fd)
    {
        LCM_LOG_ERR("Open the interface info file for write failed!");
        return -1;
    }
    sal_fputs(buffer, port_flash_fd);
    sal_fclose(port_flash_fd);
#endif
    return ret;
}


static int32 
lcm_msg_rx_chsmPortInfoSet(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
    int32 ret =0;
    char buffer[MAX_PORT_INFO_LEN+1];    
    
    clnt->keepalive_cnt = 0;
    
    sal_memset(buffer, 0, MAX_PORT_INFO_LEN);
    sal_memcpy(buffer, msg->op.chsmPortInfoSet.portInfo.buf, MAX_PORT_INFO_LEN);  

#ifndef _GLB_UML_SYSTEM_
    glb_card_t *p_card = NULL;
    eeprom_info_t *p_eeprom_info = NULL;
    
    p_card = lcm_mgt_get_card();
    if (!p_card)
    {
        LCM_LOG_ERR("Lcm recv set port info : card is NULL.");
        return LCM_E_INVALID_PTR;
    }  
    p_eeprom_info = &(p_card->p_eeprom_alloc[EEPROM_PORT_INFO]);
    if(NULL == p_eeprom_info)
    {
        LCM_LOG_ERR("Lcm recv set port info : eeprom alloc is NULL.");
        return LCM_E_INVALID_PTR;
    }
    ret = eeprom_set_port_info((uint8*)buffer, p_eeprom_info);
#else
    FILE *port_flash_fd = NULL;

    port_flash_fd = sal_fopen(GLB_UML_PORT_INFO_FILE, "w");
    if(!port_flash_fd)
    {
        LCM_LOG_ERR("Open the interface info file for write failed!");
        return -1;
    }
    sal_fputs(buffer, port_flash_fd);
    sal_fclose(port_flash_fd);
#endif
    return ret;
}

static int32
lcm_msg_rx_chsmPortSetTrain(lcm_clnt_t* clnt, LcmMsg_t* msg)
{
#ifndef _GLB_UML_SYSTEM_    
    uint8 panel_slot, panel_port, panel_subport, enable;
    
    panel_slot = msg->op.chsmPortSetTrain.slot;
    panel_port = msg->op.chsmPortSetTrain.port;
    panel_subport = msg->op.chsmPortSetTrain.subPort;
    enable = msg->op.chsmPortSetTrain.enable;
    log_sys(M_MOD_LCM, E_INFORMATIONAL, "%s slot no %d port id %d sub port id %d set training %d", __FUNCTION__, 
                panel_slot, panel_port, panel_subport, enable);
    lcm_port_set_8023ap_training(panel_slot, panel_port, panel_subport, enable);
#endif    
    return 0;
}


lcm_clnt_cb_t lcm_clnt_cb_tbl[LCM_SRV_CB_TBL_SZ] = {
    [op_PR_chsmLcAttachAck]      = lcm_msg_rx_chsmLcAttachAck,
    [op_PR_chsmKeepalive]               = lcm_msg_rx_chsmKeepalive,
    [op_PR_chsmInitSdk]          = lcm_msg_rx_chsmInitSdk,
    [op_PR_chsmDebugReq]         = lcm_msg_rx_debug_set,
    [op_PR_chsmDebugCtrlReq]     = lcm_msg_rx_debugctrl_set,
#ifndef _GLB_UML_SYSTEM_     
    [op_PR_chsmSetLcFlag]        = lcm_msg_rx_chsmSetLcFlag,
    [op_PR_chsmSetPhyTestFlag]   = lcm_msg_rx_chsmSetPhyTestFlag,
    [op_PR_chsmSerialNoGet]      = lcm_msg_rx_chsmSerialNoGet,
    [op_PR_chsmBootromVerGet]    = lcm_msg_rx_chsmGetBootromVerGet,
    [op_PR_chsmUptimeGet]        = lcm_msg_rx_chsmUptimeGet,
    [op_PR_chsmOemInfoGet]      = lcm_msg_rx_chsmOemInfoGet,
#ifdef HAVE_SMARTCFG /* added by liuyang 2011-10-27 */
    [op_PR_chsmSmartCfgGet]      = lcm_msg_rx_chsmSmartCfgGet,
    [op_PR_chsmSmartCfgSet]      = lcm_msg_rx_chsmSmartCfgSet,
#endif /* !HAVE_SMARTCFG */
    [op_PR_chsmOemInfoSet]      = lcm_msg_rx_chsmOemInfoSet,
    [op_PR_chsmReloadLc]         = lcm_msg_rx_chsmReloadLc,
    [op_PR_chsmCpuMacSet]        = lcm_msg_rx_chsmCpuMacSet,
    [op_PR_chsmLedSet]           = lcm_msg_rx_chsmLedSet,
    [op_PR_chsmLedAlarmFlagSet]  = lcm_msg_rx_chsmLedAlarmFlagSet,    
    [op_PR_chsmUpdatebootrom]        = lcm_msg_rx_chsmUpdatebootrom,
    [op_PR_chsmUpdateEpld]        = lcm_msg_rx_chsmUpdateEpld,
    [op_PR_chsmConfigbootcmd]    = lcm_msg_rx_chsmConfigbootcmd,
#ifdef BOOTUP_DIAG    
    [op_PR_chsmConfigdiaglevel]    = lcm_msg_rx_chsmConfigbootuplevel,
#endif        
    [op_PR_chsmSysSetVCT]     = lcm_msg_rx_chsmSetVctMod,  
    [op_PR_chsmGetBootcmd]     = lcm_msg_rx_chsmGetBootcmd,
    [op_PR_chsmTmprGet]          = lcm_msg_rx_chsmTmprGet,
    [op_PR_chsmGetPsuStatus]     = lcm_msg_rx_chsmGetPsuStatus,
    [op_PR_chsmGetFanStatus]     = lcm_msg_rx_chsmGetFanStatus,
    [op_PR_chsmGetPoeStatus]     = lcm_msg_rx_chsmGetPoeStatus,
    [op_PR_chsmTmprThreshold]    = lcm_msg_rx_chsmTmprThreshold,
    /* Added by liuht for bug 27036, 2014-03-20 */
    /* clear reboot info file */
    [op_PR_chsmResetRebootInfo]    = lcm_msg_rx_chsmResetRebootInfo,      
    [op_PR_chsmSetDatapathMode]  = lcm_msg_rx_chsmSetDatapathMode,
    [op_PR_chsmSysSetPOE]    = lcm_msg_rx_chsmPOE,    
#endif /*_GLB_UML_SYSTEM_*/ 
#ifndef _GLB_DISTRIBUTE_SYSTEM_   
    [op_PR_chsmSetStmMode]      = lcm_msg_rx_chsmSetStmMode,
#endif /*_GLB_DISTRIBUTE_SYSTEM_*/
    [op_PR_chsmShowSDKallocInfo] = lcm_msg_rx_chsmShowSDKallocinfo,
#ifdef _GLB_SHOW_FORWARD_ENABLE_
    [op_PR_diagShowForwardIPEReq]        = _lcm_msg_rx_chsmfowardipe,
    [op_PR_diagShowForwardEPEReq]        = _lcm_msg_rx_chsmfowardepe,
    [op_PR_diagDebugCmodel]              = _lcm_msg_rx_chsmforwardflags,
#endif
    [op_PR_chsmSetKeepaliveEn]   = lcm_msg_rx_chsmSetKeepaliveEn,
#ifdef _GLB_UML_SYSTEM_ 
    [op_PR_chsmSwitchoverSim]           = lcm_msg_rx_chsmSwitchoverSim,
#endif /* !CTC_IS_UML */
#ifdef HAVE_STACK
    [op_PR_chsmStackingMaster]           = lcm_msg_rx_chsmStackingMaster,
    [op_PR_chsmStackingTxTrunk]           = lcm_msg_rx_chsmStackingTxTrunk,
#endif
#ifndef _GLB_UML_SYSTEM_  
    [op_PR_chsmMediaTypeSet]            = lcm_msg_rx_chsmMediaTypeSet,
    [op_PR_chsmPowerDownSet]            = lcm_msg_rx_chsmPowerDownSet,
#endif
    [op_PR_chsmPortInfoSet]     = lcm_msg_rx_chsmPortInfoSet,
    [op_PR_chsmPortSetTrain]    = lcm_msg_rx_chsmPortSetTrain,  
};

int32 
lcm2hagt_set_callback(lcm2hagt_cb_msg_type_t msg_type, lcm2hagt_callback_t func)
{
    if(msg_type >= LCM2HAGT_CB_TYPE_MAX)
        return LCM_E_INVALID_PARAM;

    lcm2hagt_cb[msg_type] = func;

    return LCM_E_SUCCESS;
}

int32
lcm_card_init_callback(card_init_callback_t func)
{
    lcm_card_init_cb = func;
    return LCM_E_SUCCESS;
}

