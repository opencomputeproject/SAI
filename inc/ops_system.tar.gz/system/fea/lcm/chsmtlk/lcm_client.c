/****************************************************************************
* $Id$
*  Line Card socket client
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : kcao
* Date          : 2010-08-11
* Reason        : First Create.
****************************************************************************/
#include "lcm_error.h"
#include "lcm_debug.h"
#include "lcm_client.h"
#include "glb_tempfile_define.h"
#include "lcm_mgt.h"
#include "lcm_chsmtlk.h"

extern asn_TYPE_descriptor_t asn_DEF_LcmMsg;
static lcm_clnt_t g_lcm_clnt;

int32 
lcm_clnt_init(lcm_clnt_t *clnt, uint8 slot)
{
#if 0
    ctclib_thread_master_t* p_master = NULL;
    int ret;

#ifdef _GLB_DISTRIBUTE_SYSTEM_
    lcm_clnt_connect_remote(clnt, slot);
#else
    if (lcm_mgt_is_enable_stack())
    {
        ret = lcm_clnt_connect_remote(clnt, slot);
        if (ret < 0)
        {
            return ret;
        }
    }
    else
    {
        lcm_clnt_connect_local(clnt);
    }
#endif

    clnt->connecting_in_progress = 0;
    clnt->logic_slot = slot;
    clnt->is_connected = 1;

    if (lcm_msg_tx_lcAttach(clnt)<0)
    {
        LCM_CLNT_CLOSE(clnt);
        return LCM_E_SOCK_SEND;
    }
    p_master = lc_get_thread_master();
    if(!p_master)
    {
        LCM_LOG_ERR("Get lc master failed!");
        return LCM_E_INVALID_PTR;
    }
    g_p_clnt_read = ctclib_thread_add_read(p_master, _lcm_clnt_read, clnt, clnt->sock);
#endif
    return LCM_E_SUCCESS;
}

void lcm_clnt_fini(lcm_clnt_t *clnt)
{
#if 0
    LCM_CLNT_CLOSE(clnt);
#endif
}

void *
lcm_get_lcm_client()
{
    return &g_lcm_clnt;
}

static inline int32
_lcm_clnt_call_lcm_cb(int32 sock, LcmMsg_t *p_lcm_msg)
{
    lcm_clnt_t *p_clnt = lcm_get_lcm_client();
    lcm_clnt_cb_t cb = NULL;

    cb = lcm_clnt_cb_tbl[p_lcm_msg->op.present];
    if (!cb)
    {
        LCM_LOG_ERR("Can't get message callback function!");
        return LCM_E_NOT_FOUND;
    }
    return cb(p_clnt, p_lcm_msg);
}

int32
lcm_clnt_process_lcm_msg(int32 sock, ctc_msg_t *p_msg)
{
    asn_dec_rval_t dec_rc;
    LcmMsg_t *p_lcm_msg = NULL;
    int32 rc = 0;
    
    dec_rc = ber_decode(0, &asn_DEF_LcmMsg, (void **)&p_lcm_msg, p_msg->data, p_msg->data_len);
    if (RC_OK != dec_rc.code) 
    {
        LCM_LOG_ERR("Decode error %d.", dec_rc.code);
        return -1;
    }
    rc = _lcm_clnt_call_lcm_cb(sock, p_lcm_msg);
    
    asn_DEF_LcmMsg.free_struct(&asn_DEF_LcmMsg, p_lcm_msg, 0);
    return rc;
}

static int32
_lcm_clnt_send_sock(int32 sock, LcmMsg_t *req)
{
    ctc_msg_t msg;
    ctc_msg_t *p_msg = &msg;
    asn_enc_rval_t enc_rc;
    uint8_t buf[CTC_SOCK_BUF_SIZE];
    uint32 len;

    len = sizeof(buf);
    enc_rc = der_encode_to_buffer(&asn_DEF_LcmMsg, req, buf, &len);
    if (enc_rc.encoded < 0)
    {
        return -1;
    }
    
    sal_memset(&msg, 0, sizeof(msg));
    MSG_BUILD_HDR(p_msg, MSG_OPER_LCM, len);
    p_msg->u_hdr.lcm.slot = 1;
    p_msg->data_len = len;
    p_msg->data_len = len;
    p_msg->data = buf;

    return ctc_sock_send(sock, IGNORE_SOCK_PEER, p_msg);
}

int32 
lcm_clnt_send(lcm_clnt_t *clnt, LcmMsg_t *req)
{
    return _lcm_clnt_send_sock(clnt->sock, req);
}

int32
lcm_clnt_connect_remote(lcm_clnt_t *p_clnt, uint8 slot)
{
    int32 sock = INVALID_SOCK_ID;
    const char *path = GLB_CHSM_LCM_SOCK_PATH;
    int32 rc = 0;
    char srv_addr[32];

    sal_memset(srv_addr, 0, sizeof(srv_addr));
    
    sal_snprintf(srv_addr, sizeof(srv_addr), "172.16.0.%d:6000", slot);
    
    sock = ctc_socket(CTC_SOCK_TCP, 0, "LcmClntTcp");
    ctc_sock_register_connect_fn(sock, lcm_msg_tx_lcAttach_sock);
    rc = ctc_sock_connect(sock, path, 0);
    if (rc < 0)
    {
        return rc;
    }

    p_clnt->sock = sock;
    return LCM_E_SUCCESS;
}

int32
lcm_clnt_connect_local(lcm_clnt_t *p_clnt)
{
    int32 sock = INVALID_SOCK_ID;
    const char *path = GLB_CHSM_LCM_SOCK_PATH;
    int32 rc = 0;
    
    sock = ctc_socket(CTC_SOCK_IPC, 0, "LcmClntIpc");
    ctc_sock_set_mutex(sock, TRUE);
    ctc_sock_register_connect_fn(sock, lcm_msg_tx_lcAttach_sock);
    rc = ctc_sock_connect(sock, path, 0);
    if (rc < 0)
    {
        return rc;
    }

    p_clnt->sock = sock;
    return LCM_E_SUCCESS;
}

int32
lcm_clnt_start(void)
{
    int32 slot = 0;
    int32 ret = 0;

    lcm_clnt_t *p_clnt = &g_lcm_clnt;
    sal_memset(p_clnt, 0, sizeof(lcm_clnt_t));
    p_clnt->sock = INVALID_SOCK_ID;
#ifdef _GLB_DISTRIBUTE_SYSTEM_
    return lcm_clnt_connect_remote(p_clnt, slot);
#else
    if (lcm_mgt_is_enable_stack())
    {
        ret = lcm_clnt_connect_remote(p_clnt, slot);
        if (ret < 0)
        {
            return ret;
        }
    }
    else
    {
        ret = lcm_clnt_connect_local(p_clnt);
    }
#endif
    return 0;
}

