
#include "sai.h"
#include "lai.h"
#include "sal.h"
#include "ctc_task.h"


#define DEBUG_PRINT_CON(fmt, args...)                      \
{                                                            \
    FILE * fp_console = NULL;                                \
    fp_console = fopen("/dev/console", "w+");                \
    fprintf(fp_console, fmt"\n", ##args);                    \
    fclose(fp_console);                                      \
}

void
lai_sample_port_event_cb(lai_port_event_t  event,lai_port_info_t* p_port)
{
    char buff[64] = {0};
    char str[64] = {0};


    DEBUG_PRINT_CON("Enter into %s.\n", __FUNCTION__);
    if(NULL == p_port)
    {
        DEBUG_PRINT_CON("lsrv_port_evnent_cb, PORT is null!\n");
    }

    if(event == LAI_PORT_EVENT_ADD)
    {
        buff[0] = '\0';
        str[0] = '\0';
        sal_strcat(buff, "port");
        sal_sprintf(str, "%d", (int32_t)p_port->oid);
        sal_strcat(buff, str);


        DEBUG_PRINT_CON("PORT %s insert in, slot %d, id %lld\n, logic_port_id(SDK port) is %d, pannel_port_no is %d, speed caps %x",
               buff, p_port->slot_id, p_port->oid, p_port->portid, p_port->pannel_port_id, p_port->speed_caps);

    }
    else if(event == LAI_PORT_EVENT_DELETE)
    {
        DEBUG_PRINT_CON("PORT plugged, slot %d, id %lld\n", p_port->slot_id,p_port->oid);
    }
    else if(event == LAI_PORT_EVENT_UP)
    {
        DEBUG_PRINT_CON("PORT status up, slot %d, id %lld\n", p_port->slot_id,p_port->oid);

    }
    else if(event == LAI_PORT_EVENT_DOWN)
    {
        DEBUG_PRINT_CON("PORT status down, slot %d, id %lld\n", p_port->slot_id,p_port->oid);

    }
        
   
    return;
}

 

void 
sai_sample_packet_event_notification(
    void *buffer, 
    sai_size_t buffer_size, 
    uint32_t attr_count,
    const sai_attribute_t *attr_list)
{
    const sai_attribute_t *attr_vlan = NULL;
    const sai_attribute_t *attr_trap = NULL;
    const sai_attribute_t *attr_port = NULL;
    const sai_attribute_t *attr_lag = NULL;
    uint16 vlan_id = 0;
    sai_object_id_t portid = 0;
    int i;


    attr_trap = attr_list;
    attr_port = attr_trap + 1;
    attr_vlan = attr_trap + 2;
    attr_lag = attr_trap + 3;

    if (attr_trap->value.u32 == SAI_HOSTIF_TRAP_ID_LACP)
    {
        if(attr_port->id == SAI_HOSTIF_PACKET_INGRESS_PORT)
        {
            portid = attr_port->value.oid;
        }
    }
    else
    {
        if(4 == attr_count && attr_lag->id == SAI_HOSTIF_PACKET_INGRESS_LAG)
        {
            portid = attr_lag->value.oid;
        }
        else if(attr_port->id == SAI_HOSTIF_PACKET_INGRESS_PORT)
        {
            portid = attr_port->value.oid;
        }
    }
    if (attr_vlan->id == SAI_HOSTIF_PACKET_VLAN_ID)
    {
        vlan_id = attr_vlan->value.u16;
    }

    DEBUG_PRINT_CON("sai packet event, from port %lld, vlan %d, type = %d\n", portid, vlan_id, attr_trap->value.u32);
    for(i=0; i<buffer_size; i++)
    {
       if((i%8) == 0 )
        {
            DEBUG_PRINT_CON("\n");    
        }
        DEBUG_PRINT_CON("sai packet: %x", *((uint8_t*)(buffer)+i));
    }
    


}


void sai_sample_port_state_change_notification_cb(
    uint32 count,
    sai_port_oper_status_notification_t *noti_data)
{
    uint32 i;

    if( 0 == count )
    {
        DEBUG_PRINT_CON("sai_interface_port_state_change_notification_cb FAIL, count = 0 \n");
        return;
    }
    if( NULL == noti_data)
    {
        DEBUG_PRINT_CON("sai_interface_port_state_change_notification_cb FAIL, noti data is NULL\n");
        return;
    }
    for(i=0; i<count; i++)
    {
        DEBUG_PRINT_CON("sai_interface_port_state_change_notification_cb state is %d, port_id is %llx",
           noti_data->port_state, (noti_data->port_id));
        
        if(noti_data->port_state > SAI_PORT_OPER_STATUS_NOT_PRESENT)
        {
            DEBUG_PRINT_CON("sai_interface_port_state_change_notification_cb state is out of scope!\n");
            continue;
        }

            
    }

    return;
}



void
lsrv_card_init(void* data)
{
    lai_card_notification_t noti_cb = {0};

    extern sai_switch_notification_t g_sai_switch_notifications;
    int32 rc = 0;

    /**SAI Init will be called by "card_api->init", sai_init will use notification data from "g_sai_switch_notifications"*/
    /*so user only need add callback function here**/
    sal_memset(&g_sai_switch_notifications, 0, sizeof(g_sai_switch_notifications));
    g_sai_switch_notifications.on_packet_event = (void *)sai_sample_packet_event_notification;
    g_sai_switch_notifications.on_port_state_change = (void *)sai_sample_port_state_change_notification_cb;

   /**LAI(Linecard Abstration Interface) init*/
   /*LAI manage board hardware including card, port, fiber, fan, psu, thermal**/
   /*for Demo, only port add/delete event need callback function to create inerface **/
    noti_cb.on_card_event = NULL;
    noti_cb.on_fiber_event = NULL;
    noti_cb.on_port_event = lai_sample_port_event_cb;
    noti_cb.on_fan_event = NULL;
    noti_cb.on_psu_event = NULL;
    noti_cb.on_thermal_event = NULL;
    lai_api_initialize(0, &noti_cb);

    lai_card_api_t*  card_api = NULL;

    DEBUG_PRINT_CON("Enter into %s.", __FUNCTION__);

    lai_api_query(LAI_API_CARD,(void**)&card_api);
    if(card_api)
    {
        /*card init will init board including ASIC, port, fan, psu, thermal.*/
        /*SAI init will be called inner of this card_init*/
        rc = card_api->init();
        if(rc)
        {
            DEBUG_PRINT_CON("lsrv_card_init FAIL !!!");
        }
    }
    
    return ;
}


int32_t
hsrv_start(int32_t daemon_mode)
{
    int32 rc = 0;

    rc = memory_init(1);
    if (rc)
    {
        DEBUG_PRINT_CON("memory_init FAIL !!!");
        return 0;
    }

    rc = ctc_sock_init();
    if (rc)
    {
        DEBUG_PRINT_CON("ctc_sock_init FAIL !!!");
        return 0;
    }
    
    ctc_task_init();

    /*SAI init will be called after card init*/
    lsrv_card_init(NULL);

    ctc_task_main();

    return 0;
}

void
usage(void)
{
    sal_printf("./hsrv -d -h\n");
    sal_printf("    -d, --daemon       Runs in daemon mode\n");
    sal_printf("    -h print this help message\n");
    return;
}

int32
main(int32 argc, char **argv)
{
    int32 opt;
    int32 daemon_mode = 0;

    while ((opt = getopt(argc, argv, "dh")) != -1)
    {
        switch (opt)
        {
        case 'd':
            daemon_mode = 1;
            break;
        case 'h':
        default:
            usage();
            exit(1);
            break;
        }
    }

    hsrv_start(daemon_mode);
    exit(0);
}


