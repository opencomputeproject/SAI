// TODO: Commented by xgu for compile 20121120//
#if 0
#ifndef __LCM_SHOW_SDK_H__
#define __LCM_SHOW_SDK_H__

int32 
lcm_dump_sdk_nexthop(lcapi_show_req_t *req); 
int32 
lcm_dump_sdk_alloc(lcapi_show_req_t* req);
int32 
lcm_dump_sdk_master(lcapi_show_req_t* req);
int32 
lcm_dump_chip(lcapi_show_req_t* req);
#ifdef FOAM_SUPPORT  /* Added by kcao 2011-05-13 */
int32 
lcm_dump_foam(lcapi_show_req_t* req);
int32 
lcm_dump_foam_mep(lcapi_show_req_t* req);
#endif /* !FOAM_SUPPORT */

/*SYSTEM_MODIFIED by sunw for bug 14736, 2011-4-13*/
int32 
lcm_dump_sdk_mem(lcapi_show_req_t* req);
int32 
lcm_dump_sdk_opf(lcapi_show_req_t* req);
int32 
lcm_dump_sdk_queue(lcapi_show_req_t* req);
#endif /*__LCM_SHOW_SDK_H__*/
#endif
