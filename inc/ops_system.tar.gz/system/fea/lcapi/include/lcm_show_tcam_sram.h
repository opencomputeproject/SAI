#ifndef __LCM_SHOW_TCAM_SRAM_H__
#define __LCM_SHOW_TCAM_SRAM_H__

int32 
lcm_get_usrid_entry(diag_usrid_tcam_entry_req_t* req,diag_usrid_tcam_entries_resp_t* resp);
int32 
lcm_get_all_acl_or_qos_entries(diag_acl_tcam_get_req_t* req,diag_acl_tcam_data_t *resp);
int32 
lcm_get_one_acl_or_qos_entry(diag_acl_tcam_get_req_t* req,diag_acl_tcam_entry_t *resp);
int32
lcm_get_all_l2_fdb(diag_l2_tcam_entry_req_t* req);
int32 
lcm_msg_rx_l2_get_all_entries(diag_l2_tcam_entry_req_t* req,  diag_l2_tcam_entries_resp_t*resp);
int32 
lcm_get_one_l2_entry(diag_l2_tcam_entry_req_t* req,  diag_l2_tcam_entry_t* resp);
int32
lcm_get_one_ipuc_entry( diag_ipv4_v6_tcam_entry_t* data);
int32 
lcm_ipuc_v4_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp);
int32 
lcm_ipuc_v6_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp);
int32 
lcm_get_one_ipuc_v6_entry(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp);
int32 
lcm_get_stp_status(diag_sram_get_stp_status_req_t* req, diag_sram_get_stp_status_resp_t *resp);
int32 
lcm_ipmc_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp);
int32 
lcm_ipmc_v6_get_entries(diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entries_resp_t *resp);
int32
lcm_get_one_ipmc_entry( diag_l3_tcam_entry_req_t* req, diag_ipv4_v6_tcam_entry_t *resp );
 int32
lcm_wr_file_usrid(diag_usrid_tcam_entries_resp_t* resp);
 int32 
lcm_get_register_table(diag_reg_entry_req_t* req, diag_reg_entry_resp_t *resp);
 

#endif /*__LCM_SHOW_TCAM_SRAM_H__*/
