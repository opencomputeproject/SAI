#ifndef __DIAG_CHIP_CLI_H__
#define __DIAG_CHIP_CLI_H__

#define DIAG_CHIP_TEMP_FILE           "/tmp/diag_chip_temp_file"

#define TCAM_BIST_MAX_ENTRY 64
#define SRAM_BIST_MAX_ENTRY 64

#define DDR_DFT_BISTEXP_LATENCY     6
#define QDR_DFT_BISTEXP_LATENCY     6
#define EXT_TCAM_DFT_BISTEXP_LATENCY    0x25   /*external tcam*/
#define INT_TCAM_DFT_BISTEXP_LATENCY    0   /*internal tcam*/

#define EXTCAM_BISTREQRAM_ADDR   0x0b801000
#define EXTCAM_BISTCTRL_ADDR     0x0b800070
#define EXTCAM_BISTRLTRAM_ADDR   0x0b801800

#define INTCAM_BISTREQRAM_ADDR   0x0bc01000
#define INTCAM_BISTCTRL_ADDR     0x0bc00040
#define INTCAM_BISTRLTRAM_ADDR   0x0bc01a00

#define DDR_CONTROL_ADDR         0x0cc00000
#define DDR_BISTCTRL_ADDR        0x0cc00008
#define DDR_BISTINIT_ADDR        0x0cc00020
#define DDR_BISTREQRAM_ADDR      0x0cc01800
#define DDR_BISTEXPRAM_ADDR      0x0cc01400
#define DDR_BISTRLTRAM_ADDR      0x0cc01000

#define QDR_CONTROL_ADDR         0x0e000000
#define QDR_BISTCTRL_ADDR        0x0e000008
#define QDR_BISTINIT_ADDR        0x0e000020
#define QDR_BISTREQRAM_ADDR      0x0e001800
#define QDR_BISTEXPRAM_ADDR      0x0e001400
#define QDR_BISTRLTRAM_ADDR      0x0e001000

#define DDR_SRAM_BASE 0x05000000
#define QDR_SRAM_BASE 0x0f000000

#define EXT_TCAM_CTRL_SETUP      0x0b800000
#define EXT_TCAM_BISTCTRL_ADDR   0x0b800070
#define EXT_TCAM_BISTINIT_ADDR   0x0b800050
#define EXT_TCAM_BISTREQRAM_ADDR 0x0b801000
#define EXT_TCAM_BISTEXPRAM_ADDR 0x0b801a00
#define EXT_TCAM_BISTRLTRAM_ADDR 0x0b801800

#define EXT_TCAM_ACCESS_ADDR      0x0b800004
#define EXT_TCAM_WRITEDATA_ADDR   0x0b800010
#define EXT_TCAM_READDATA_ADDR    0x0b800030

#define EXT_TCAM_WRITEMASK_ADDR      0x0b800020

#define INT_TCAM_BISTCTRL_ADDR   0x0bc00040
#define INT_TCAM_BISTINIT_ADDR   0x0bc00050
#define INT_TCAM_BISTREQRAM_ADDR 0x0bc01000
#define INT_TCAM_BISTEXPRAM_ADDR 0x0bc01800
#define INT_TCAM_BISTRLTRAM_ADDR 0x0bc01a00

#define INT_TCAM_KEYSIZECFG_ADDR 0x0bc001b0
#define INT_TCAM_KEYTYPECFG_ADDR 0x0bc001C0

#define INT_TCAM_ACCESS_ADDR      0x0bc00004
#define INT_TCAM_WRITEDATA_ADDR   0x0bc00010
#define INT_TCAM_WRITEMASK_ADDR   0x0bc00020

#define ZBT_BISTCTRL_ADDR        0x000a0104
#define ZBT_BISTREQRAM_ADDR      0x000a0080
#define ZBT_BISTEXPRAM_ADDR      0x000a0040

#define CHSM_HUMBER_MAX_INT_MODULE 135

#define CHSM_HUMBER_MAX_BUS_MESSAGE 11

#define string_to_asccii(a)   ((a) > '9') ? (toupper(a) - 'A' + 10) : ((a) - '0')
#define CON_BREAK(exp)      if(exp) break
/* pointer valid check macro define */
#define PTR_CHECK(ptr)\
if ( NULL == (ptr) )\
{\
    return -1;\
}

enum capture_type_e
{
    CAPTURE_EXTCAM = 2,
    CAPTURE_INTCAM,
    CAPTURE_DDR,
    CAPTURE_QDR
};
typedef enum capture_type_e capture_type_t;

enum bist_type_e
{
    BIST_EXTCAM = 2,
    BIST_INTCAM,
    BIST_DDR,
    BIST_QDR
};
typedef enum bist_type_e bist_type_t;

enum regwalk_type_e
{
    REG_WALK_SUP ,
    REG_WALK_CORE
};
typedef enum regwalk_type_e regwalk_type_t;


enum direction
{
    HOST_2_NETWORK,
    NETWORK_2_HOST
};

struct tcam_bist_control_struct
{
	uint32 cfgBistMismatchCount	:16;
    uint32 rsv1                 :2;
	uint32 trainingEn			:1;
	uint32 cfgCaptureEn			:1;
	uint32 cfgCaptureOnce 		:1;
	uint32 cfgBistEn			:1;
	uint32 cfgStopOnError 		:1;
	uint32 cfgBistOnce			:1;
    uint32 rsv2                 :2;
	uint32 cfgBistEntries		:6;

    uint32 rsv3                 :25;
    uint32 expectLatency        :7;
};
typedef struct tcam_bist_control_struct tcam_bist_control_struct_t;

struct tcam_bist_req_ram_struct
{
	uint32 key_valid	:1;
	uint32 rsv1			:21;
	uint32 keySize		:2;
	uint32 keyCmd		:8;

	uint32 rsv2			:16;
	uint32 key159To144	:16;

	uint32 key143To112	:32;

	uint32 key111To80	:32;

	uint32 rsv3			:32;

	uint32 rsv4			:16;
	uint32 key79To64	:16;

	uint32 key63To32 	:32;

	uint32 key31To0		:32;
 };
typedef struct tcam_bist_req_ram_struct tcam_bist_req_ram_struct_t;

struct tcam_bist_result_ram_struct
{
	uint32 resultCompareValid		:1;
	uint32 rsv1						:6;
	uint32 indexValid				:1;
	uint32 rsv2						:3;
	uint32 indexAclCompEn			:1;
	uint32 indexAcl					:20;

	uint32 rsv3						:11;
	uint32 indexQosCompEn			:1;
	uint32 indexQos					:20;
 };
typedef struct tcam_bist_result_ram_struct tcam_bist_result_ram_struct_t;

union tcam_bist_control_union
{
    uint32 bist_control[2];
    tcam_bist_control_struct_t bistControl;
};
typedef union tcam_bist_control_union tcam_bist_control_union_t;

union tcam_bist_req_ram_union
{
    uint32 result_ram[8];
    tcam_bist_req_ram_struct_t bistRequest;
};
typedef union tcam_bist_req_ram_union tcam_bist_req_ram_union_t;

union tcam_bist_result_ram_union
{
    uint32 result_ram[2];
    tcam_bist_result_ram_struct_t bistResult;
};
typedef union tcam_bist_result_ram_union tcam_bist_result_ram_union_t;

enum humber_info_type_e
{
    HUMBER_INFO_GMAC = 0,
    HUMBER_INFO_XGMAC,
    HUMBER_INFO_SGMAC,
    HUMBER_INFO_QMAC,
    HUMBER_INFO_MUXNETRXTX,
    HUMBER_INFO_IPE,
    HUMBER_INFO_FWD,
    HUMBER_INFO_EPE,
    HUMBER_INFO_CPUMAC,
    HUMBER_INFO_ELOOP,
    HUMBER_INFO_FABRIC,
    HUMBER_INFO_INTERRUPT,
    HUMBER_INFO_INTERNAL,
    HUMBER_INFO_OAM,
    HUMBER_INFO_PARSER,
    HUMBER_INFO_SHAREDS,
    HUMBER_INFO_TBINFOARB,
    HUMBER_INFO_TCAM,
    HUMBER_INFO_QUEUEID,
    HUMBER_INFO_QUEUEDEPTH,
    HUMBER_INFO_HASHDS,    
};
typedef enum humber_info_type_e humber_info_type_t;

enum humber_bus_info_type_e
{
    HUMBER_BUS_INFO_BUSHA2IM = 0,
    HUMBER_BUS_INFO_BUSIM2LMPI,
    HUMBER_BUS_INFO_BUSIM2LMPR,
    HUMBER_BUS_INFO_BUSLM2PPPI,
    HUMBER_BUS_INFO_BUSLM2PPPR,
    HUMBER_BUS_INFO_BUSMFENQMSGFIFO,
    HUMBER_BUS_INFO_HA2NHPIBUS,
    HUMBER_BUS_INFO_NH2HPPIBUS,
    HUMBER_BUS_INFO_PR2HPPRBUS,
    HUMBER_BUS_INFO_AQOS2EDITPIBUS,
    HUMBER_BUS_INFO_CLA2EDITPIBUS,
};
typedef enum humber_bus_info_type_e humber_bus_info_type_t;

enum diag_chip_opcode_e
{
    DIAG_CHIP_READ_TCAM_REG,
    DIAG_CHIP_READ_TCAM_ENTRY, 
    DIAG_CHIP_WRITE_TCAM_REG,
    DIAG_CHIP_WRITE_TCAM_ENTRY,    
    DIAG_CHIP_CAPTURE_START,
    DIAG_CHIP_CAPTURE_STOP,
    DIAG_CHIP_BIST_START,
    DIAG_CHIP_BIST_STOP,
    DIAG_CHIP_SHOW_DISCARD_TYPE,
    DIAG_CHIP_SHOW_BUS_INFO,
    DIAG_CHIP_SHOW_INFO,
    DIAG_OAM_REGWALK,
    DIAG_OAM_DEBUG_STATS,
    DIAG_OAM_BIST_START,
    DIAG_OAM_BIST_STOP,
    DIAG_CHIP_OPCODE_MAX,
};
typedef enum diag_chip_opcode_e diag_chip_opcode_t;

typedef struct chsm_humber_bus_field_s
{
    char*  field_name;
    uint16 start_bit;
    uint16 stop_bit;
}chsm_humber_bus_field_t;

typedef struct chsm_humber_bus_message_s
{
    char*  bus_name;
    uint32 start_addr;
    uint8  entry_num;
    uint8  word_num;
    uint8  invalid;
    uint8  max_msg_num;
    chsm_humber_bus_field_t* module_field;
    uint8  field_len;
    uint8  is_seq_num;
}chsm_humber_bus_message_t;

struct diag_chip_req_s
{
    diag_chip_opcode_t opcode;
    uint32 chip_id; 
    uint32 fromIdx; 
    uint32 toIdx; 
    uint8  buf1[256];
    uint8  buf2[256];
};
typedef struct diag_chip_req_s  diag_chip_req_t;

struct humber_fatal_field_s
{
   char *string;
   uint16 bit;
   uint16 reset_humber;
   uint16 mask_off;
};
typedef struct humber_fatal_field_s  humber_fatal_field_t;


struct humber_fatal_reg_s
{
   char   *module_name;
   uint32   value_reg_addr;
   uint32   value_mask;
   uint32   value_reset_reg_addr;
   uint32   value_mask_reset_reg_addr;
   uint32   init_mask_value;
   uint32   reset_value;
   humber_fatal_field_t *module_field;
   uint8    field_len;
} ;
typedef struct humber_fatal_reg_s  humber_fatal_reg_t;


int32 
diag_chip_write_tcam_entry(uint32 chip_id, 
        uint32 key_index, uint32 is_internal, uint32* data, uint32* mask);

int32 
diag_chip_read_tcam_entry(uint32 chip_id, uint32 key_index, uint32 is_internal);

int32 
diag_chip_read_tcam_register(uint32 chip_id, uint32 index);

int32 
diag_chip_write_tcam_register(uint32 chip_id, uint32 index, uint32* data);

int32 diag_chip_capture_start(uint32 chip_id, uint32 capture_type);

int32 diag_chip_capture_stop(uint32 chip_id, uint32 capture_type);

int32 diag_chip_show_discard(uint32 chip_id);

int32 diag_chip_show_info(uint32 chip_id, uint32 humber_info_type, uint32 index);

int32 diag_chip_bist_start(uint32 chip_id, uint32 bist_type);

int32 diag_chip_bist_stop(uint32 chip_id, uint32 bist_type);

int32 diag_oam_register_walk( uint32 regwalk_type);

int32 diag_oam_debug_stats( );

int32 diag_oam_bist_start( );
int32 diag_oam_bist_stop( );
int32 diagnostic_show_ha2NhPiBus_bus_one_msg_info(FILE *pf, uint8 humber_id, chsm_humber_bus_message_t bus_message_info, uint32 addr, uint8 addr_word_num);
int32 diagnostic_show_bus_one_msg_info(FILE *pf, uint8 humber_id, chsm_humber_bus_message_t bus_message_info, uint32 addr, uint8 addr_word_num);
int32 diagnostic_show_bus_info(uint8 humber_id, chsm_humber_bus_message_t bus_message_info, uint32 start_msg, uint32 msg_num);
int32 diag_chip_show_bus_info(uint32 chip_id, uint32 humber_bus_info_type, uint32 index);

#ifdef BOOTUP_DIAG
int32 diag_ext_tcam_read(uint32 chip_id, int32 *data, int32 *mask, uint32 index, uint8  is_register);

int32 diag_ext_tcam_write(uint8 chip_id, int32 *data, int32 *mask, uint32 index, uint8 is_register); 

int32 diag_int_tcam_write(uint8 chip_id, int32 *data, int32 *mask, uint32 index, uint8 is_register);

int32 diag_int_tcam_read(uint32 chip_id, int32 *data, int32 *mask, uint32 index, uint8  is_register);

int32 stringtochar(char *str, uint8 *buff, int32 *length);

int32 swap_32(uint32 *data, int32 len, uint8 direction);
#endif
#endif 

