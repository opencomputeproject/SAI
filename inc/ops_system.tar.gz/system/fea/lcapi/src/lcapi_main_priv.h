#ifndef __LC_MAIN_PRIV_H__
#define __LC_MAIN_PRIV_H__
#include "lcapi.h"
#include "lcm_specific.h"
struct lcapi_master_s
{
#ifdef _LCM_OSP_
#else
    ctclib_thread_master_t *p_thread_master;
#endif 
};
typedef struct lcapi_master_s lcapi_master_t;

#endif /*__LC_MAIN_PRIV_H__*/
